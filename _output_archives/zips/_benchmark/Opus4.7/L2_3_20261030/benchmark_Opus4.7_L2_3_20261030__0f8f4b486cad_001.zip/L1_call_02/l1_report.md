## Doability
Doable. SRD-46 provides DTPA protonation and 1:1 M–DTPA complexes for Ca(II), Pb(II), and Zn(II) at 25 °C, I=0.1 M; a 1-D pH sweep over 6–8 at fixed non-redox totals is exactly the pH_sweep method's scope.

## Result
- System: 1.00 mM Pb(II) + 1.00 mM Zn(II) + 1.00 mM Ca(II) + 5.00 mM DTPA (ligand excess ≈1.67×).
- Method: pH_sweep, 21 points pH 6.0–8.0, T = 25.0 °C, I-target = 0.1 M (calculated I = 0.022–0.029 M, lower than target because DTPA complexes replace free ions), redox excluded.
- Convergence: 21/21 points converged for every component. No solid formed over the window ([Ca(OH)₂], PbO(red), Zn(OH)₂(α) all 0 mol/L).

## Analysis
**Dominant metal species (all pH 6–8).** Every metal is sequestered as the fully deprotonated 1:1 chelate [M(DTPA)]³⁻. The verdict shows [Pb(DTPA)]³⁻ reaching 100.0 % of Pb at pH 8 and [Ca(DTPA)]³⁻ 99.7 %, [Zn(DTPA)]³⁻ 99.9 %. At pH 6 the protonated chelates [M(DTPA)H]²⁻ carry a residual share (Ca 22 %, Zn 8 %, Pb much less) because HDTPA⁴⁻ is still a minor DTPA form (card log β for [M(DTPA)H]²⁻ via H+HDTPA⁴⁻+M²⁺: Ca 16.86, Pb 23.32, Zn 23.80). As pH rises past the HDTPA⁴⁻/DTPA⁵⁻ regime (DTPA ladder dominance flips H₂DTPA³⁻ → HDTPA⁴⁻ between pH 7.5 and 7.6), the protonated chelate relaxes into [M(DTPA)]³⁻ (log β: Ca 10.75, Pb 18.80, Zn 18.20). No hydrolysis species (e.g. [Pb(OH)]⁺, [Pb₄(OH)₄]⁴⁺, [Zn(OH)]⁺) exceed 10⁻¹³ M — DTPA fully outcompetes hydroxide, so no PbO or Zn(OH)₂ precipitates despite the near-neutral pH where free Pb(II) and Zn(II) would otherwise be nearing saturation.

**Free aqueous [M²⁺] vs pH** (from the concentrations CSV; mol/L):

| pH | free [Ca²⁺] | free [Pb²⁺] | free [Zn²⁺] |
|---:|---:|---:|---:|
| 6.0 | 2.24e-05 | 2.62e-13 | 9.64e-13 |
| 6.5 | 2.89e-06 | 2.81e-14 | 1.09e-13 |
| 7.0 | 3.64e-07 | 3.33e-15 | 1.32e-14 |
| 7.5 | 5.59e-08 | 5.03e-16 | 2.00e-15 |
| 8.0 | 1.24e-08 | 1.11e-16 | 4.40e-16 |

Every free [M²⁺] falls ~3 orders of magnitude from pH 6 to 8 because the controlling equilibrium M²⁺ + HDTPA⁴⁻ ⇌ [M(DTPA)]³⁻ + H⁺ is driven forward by consuming H⁺; equivalently, as HDTPA⁴⁻ and DTPA⁵⁻ grow with pH, the apparent conditional formation constant of [M(DTPA)]³⁻ rises in near-proportion.

**Free-ion selectivity ratios** (dimensionless):

| pH | free[Zn²⁺]/free[Pb²⁺] | free[Ca²⁺]/free[Pb²⁺] |
|---:|---:|---:|
| 6.0 | 3.7 | 8.5e+07 |
| 6.5 | 3.9 | 1.03e+08 |
| 7.0 | 4.0 | 1.09e+08 |
| 7.5 | 4.0 | 1.11e+08 |
| 8.0 | 4.0 | 1.12e+08 |

**Interpretation.**
- *Pb vs Zn is essentially a wash.* The ratio free[Zn²⁺]/free[Pb²⁺] ≈ 4 across pH 6–8 reflects the small log β difference for the 1:1 chelates (Pb 18.80 vs Zn 18.20 → ΔlogK = 0.60, so free[Zn²⁺]/free[Pb²⁺] = 10^0.60 ≈ 4). DTPA cannot kinetically or thermodynamically distinguish Pb(II) from Zn(II) under these conditions; both are >99.99 % bound. If the goal is Pb removal from a Zn-containing matrix with excess DTPA, Zn will be co-sequestered to the same extent — DTPA is not a Pb-selective reagent against Zn.
- *Ca is almost completely out-competed.* The ratio free[Ca²⁺]/free[Pb²⁺] ≈ 10⁸ reflects the 8-log-unit difference in [M(DTPA)]³⁻ log β (Ca 10.75 vs Pb 18.80, Δ = 8.05, 10^8.05 ≈ 1.1e8), modulated slightly at low pH by the Ca protonated-chelate equilibrium. Free Ca²⁺ (10⁻⁵–10⁻⁸ M) is 7–8 orders of magnitude higher than free Pb²⁺ (10⁻¹³–10⁻¹⁶ M), yet because 1 mM Ca only consumes 1 mM DTPA from the 5 mM pool, there is still ample DTPA (≈3 mM) left to fully bind Pb and Zn. In other words, Ca is a "sacrificial" sink for DTPA, not a competitor that releases Pb; selectivity for Pb removal is preserved only because the ligand is in excess.

**Practical implications.**
- DTPA at 5× total-metal stoichiometry fully masks all three divalent metals as [M(DTPA)]³⁻ across pH 6–8 with no risk of PbO or Zn(OH)₂ precipitation.
- For Pb/Zn discrimination, DTPA is unsuitable; a softer donor set (e.g. thiolate ligands) would be required.
- Ca(II) is thermodynamically outcompeted by ≈8 log units, so hard-water Ca background does not threaten Pb sequestration provided the DTPA dose exceeds Σ[M²⁺]; however, each equivalent of Ca does consume one equivalent of DTPA, so dosing must account for Ca load.

## Artifacts
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_verdict.md
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_concentrations.csv
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Pb.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Zn.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Ca.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
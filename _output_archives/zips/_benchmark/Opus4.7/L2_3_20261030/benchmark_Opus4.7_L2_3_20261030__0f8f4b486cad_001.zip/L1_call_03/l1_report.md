## Doability
Not doable as requested. SRD-46 contains no complexation data for Ca(II) with D-penicillamine, so the three-metal competition brief cannot be represented from the database. LC1 refused to build the card before any solve was attempted.

## Result
- System requested: Pb(II) 1 mM + Zn(II) 1 mM + Ca(II) 1 mM + D-penicillamine 5 mM, pH 6–8, 25 °C, I = 0.1 M, no redox.
- Pipeline stage reached: LC1 (eq-card alignment).
- Deterministic error returned (verbatim): "SRD-46 has no data for the requested metal-ligand system (not in database): metal(s) with no complexation data against any requested ligand: Ca. Missing metal x ligand pairs: Ca x Penicillamine. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card. Report the missing data — do not substitute a different system or estimate constants."
- Elapsed: 15.4 s. No free-energy card, no solver run, no verdict artifacts were produced.

## Analysis
The gap is specifically the Ca(II)–D-penicillamine pair. D-penicillamine (β,β-dimethylcysteine, HS–C(CH3)2–CH(NH2)–COOH) is a soft, thiolate-containing amino acid; its chemistry is dominated by binding to soft/borderline cations through the thiolate S−. Ca(II), a hard oxophilic cation, is not expected to form strong complexes with the thiolate group and is routinely treated in the aqueous-coordination literature as effectively non-complexed by penicillamine beyond weak carboxylate interactions. The absence of Ca–penicillamine constants in SRD-46 is consistent with that chemistry — the critically evaluated compilation simply does not carry stability constants for a pair whose complexes are too weak to have been measured and tabulated.

Because the brief explicitly asks for all three metals in one pot and for the free[Ca2+]/free[Pb2+] selectivity ratio, I cannot answer it by silently dropping Ca: doing so would change the chemistry of the competition (Ca would no longer compete for protons via its hydration/activity contribution, and more importantly the requested Ca-based selectivity ratio would be fabricated). Per the pipeline's hard rule, I am reporting the missing data rather than substituting a different system or estimating constants.

Practical implications for the user's selectivity question, stated qualitatively from the chemistry (NOT from a computed result):
1. The Ca/Pb selectivity ratio is effectively a lower bound set by the Pb–penicillamine binding alone; with no measurable Ca–penicillamine complex, free[Ca2+] is essentially the analytical Ca concentration (minus modest activity corrections) across pH 6–8, so free[Ca2+]/free[Pb2+] will be very large and penicillamine is expected to be highly Pb-selective over Ca. This is the physical reason the pair is absent from SRD-46.
2. The Pb vs Zn selectivity question IS representable in SRD-46 (both Pb–penicillamine and Zn–penicillamine systems are tabulated). If the user wants that part answered quantitatively, resubmit a two-metal brief (Pb + Zn + penicillamine, same pH range and conditions) and the pipeline will run.
3. If a quantitative Ca ratio is genuinely required, it must come from a database that carries Ca–penicillamine constants (or from explicit experimental measurement); SRD-46 cannot supply it and the pipeline will not estimate it.

## Artifacts
(None — pipeline stopped at LC1 before any output files were written.)
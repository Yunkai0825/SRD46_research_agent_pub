# Speciation Calculation Report: Ca$+2 + Ca$+0 + Pb$+2 + Pb$+0 + Pb$+3 + Pb$+4 + Zn$+2 + Zn$+0 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0137013 – 0.0152945 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 21
- Converged: 21/21
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Ca$+0]_total | 0 | redox-state subtotal |
| [Ca$+2]_total | 0.001 | redox-state subtotal |
| [Pb$+0]_total | 0 | redox-state subtotal |
| [Pb$+2]_total | 0.001 | redox-state subtotal |
| [Pb$+3]_total | 0 | redox-state subtotal |
| [Pb$+4]_total | 0 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6277]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Pb$+0 | Pb(s) | 0.00e+00 | metal |
| Pb$+2 | Pb2+ | 1.00e-03 | metal |
| Pb$+3 | Pb(+3) | 0.00e+00 | metal |
| Pb$+4 | Pb(+4) | 0.00e+00 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H6EDTA2+ | aqueous | L1:+1 H:+6 | — | -127.3957 | -7.9908 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -127.3957 | -7.9908 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -119.4049 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -107.8754 | +11.5295 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -93.4920 | +25.9129 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +61.2435 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +119.4049 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(EDTA)H]- | aqueous | L1:+1 Ca$+2:+1 H:+1 | — | -78.4808 | +40.9242 |
| [Ca(EDTA)]2- | aqueous | L1:+1 Ca$+2:+1 | — | -60.7869 | +58.6180 |
| Pb2+ | aqueous | Pb$+2:+1 | — | -0.0000 | +0.0000 |
| [Pb2(OH)]3+ | aqueous | H:-1 Pb$+2:+2 | — | +36.5292 | +36.5292 |
| [Pb(OH)]+ | aqueous | H:-1 Pb$+2:+1 | — | +45.6615 | +45.6615 |
| [Pb(OH)2] | aqueous | H:-2 Pb$+2:+1 | — | +97.6015 | +97.6015 |
| [Pb(OH)3]- | aqueous | H:-3 Pb$+2:+1 | — | +160.3861 | +160.3861 |
| [Pb4(OH)4]4+ | aqueous | H:-4 Pb$+2:+4 | — | +117.0077 | +117.0077 |
| [Pb3(OH)4]2+ | aqueous | H:-4 Pb$+2:+3 | — | +136.4138 | +136.4138 |
| [Pb6(OH)8]4+ | aqueous | H:-8 Pb$+2:+6 | — | +248.8554 | +248.8554 |
| [Pb(EDTA)H]- | aqueous | L1:+1 H:+1 Pb$+2:+1 | — | -118.7200 | +0.6849 |
| [Pb(EDTA)]2- | aqueous | L1:+1 Pb$+2:+1 | — | -102.7385 | +16.6665 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(EDTA)H2] | aqueous | L1:+1 H:+2 Zn$+2:+1 | — | -118.1492 | +1.2557 |
| [Zn(EDTA)H]- | aqueous | L1:+1 H:+1 Zn$+2:+1 | — | -111.3000 | +8.1049 |
| [Zn(EDTA)]2- | aqueous | L1:+1 Zn$+2:+1 | — | -94.1769 | +25.2280 |
| [Zn(EDTA)(OH)]3- | aqueous | L1:+1 H:-1 Zn$+2:+1 | — | -27.9677 | +91.4372 |
| [Ca(OH)2](s) | solid | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| [(Pb2O((OH))2)0.5](s) | solid | H:-2 Pb$+2:+1 | — | +74.7708 | +74.7708 |
| Pb | solid | Pb$+0:+1 | — | +0.0000 | +0.0000 |
| [Zn(OH)2(s,epsilon)] | solid | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Ca(EDTA)]2-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Ca(EDTA)]2-

Crossover pH values:

=== Pb(s) (Pb$+0) speciation ===
[Pb$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb2+ (Pb$+2) speciation ===
[Pb$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Pb(EDTA)]2-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Pb(EDTA)]2-

Crossover pH values:

=== Pb(+3) (Pb$+3) speciation ===
[Pb$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb(+4) (Pb$+4) speciation ===
[Pb$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Zn(EDTA)]2-        peak 100.0% at pH 6.8

Dominant species by pH region:
  pH   6.0–  8.0  →  [Zn(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2EDTA2-            peak 10.5% at pH 6.0
  HEDTA3-             peak 39.0% at pH 7.4
  [Ca(EDTA)]2-        peak 20.0% at pH 8.0
  [Pb(EDTA)]2-        peak 20.0% at pH 8.0
  [Zn(EDTA)]2-        peak 20.0% at pH 6.8

Dominant species by pH region:
  pH   6.0–  8.0  →  HEDTA3-

```
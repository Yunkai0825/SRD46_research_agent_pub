# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose fixes this as an aqueous speciation / selectivity problem at fixed pH 6–8, 25 °C, 0.1 m, with no applied potential; redox branches (Pb(III), Pb(IV), elemental metals as competing phases) are decorative and should be pruned, keeping only ground-state M(0) as a formal reference.
- Working regime is 1 mM metal + 5 mM EDTA near neutral pH: EDTA complexes (ML, MHL, M(OH)L) dominate and must all be retained; hydroxo monomers through M(OH)3-/M(OH)4^2- are real; Pb polynuclear hydroxo species (Pb2OH, Pb3(OH)4, Pb4(OH)4, Pb6(OH)8) stay because free Pb2+ in the EDTA-poor fraction can still populate them.
- Spellings [M(OH)n]^(2-n) (SRD-46) and [HMOn]^- / [MOn]^2- (Atlas) denote the same aqueous species; collapse to one copy, preferring SRD-46 for internal consistency with the EDTA set.
- Solids: no evaporation or precipitation question is posed, but one ground-state hydroxide per metal is retained as a saturation ceiling. Collapse Zn(OH)2 polymorphs to the thermodynamically stable form (ε-Zn(OH)2) and drop the rest; keep one Ca(OH)2 and one PbO·H2O-equivalent solid. Anhydrous oxides and higher Pb oxides are not competing phases at 25 °C in solution and are dropped.
- Carbonates are not in the inventory; the near-neutral pot is implicitly CO2-free as given, so no counterion gap to flag.
- Phase question is 'which species forms and at what fraction' — a speciation problem, not a stability-diagram ground-state collapse — so distinct protonation and mixed-ligand EDTA species are kept even if close in μ.
- Treatment differs by element: Pb needs its polynuclear hydroxo set and loses its high-valent branch; Zn needs polymorph collapse; Ca is simple with only one EDTA, one MHL, one hydroxo, one solid.

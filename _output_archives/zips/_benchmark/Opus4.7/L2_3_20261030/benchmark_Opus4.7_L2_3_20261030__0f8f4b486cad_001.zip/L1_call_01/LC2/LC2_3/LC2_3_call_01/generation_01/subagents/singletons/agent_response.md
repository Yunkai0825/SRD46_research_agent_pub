# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent/empty aqueous reference entry; harmless to retain."},
{"phase":"aqueous","core_label":"Ca$+2:1 H:-1","keep":true,"rationale":"[Ca(OH)]+ monomer explicitly kept per Ca instruction."},
{"phase":"aqueous","core_label":"Ca$+2:1 L1:1","keep":true,"rationale":"[Ca(EDTA)]2- is the primary Ca–EDTA complex and is explicitly retained."},
{"phase":"aqueous","core_label":"Ca$+2:1 L1:1 H:1","keep":true,"rationale":"[Ca(EDTA)H]- protonated complex explicitly retained."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free EDTA4- ligand required for speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"HEDTA3- protonation state needed near pH 6–8."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"H2EDTA2- protonation state needed in working pH range."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"H3EDTA- distinct protonation state kept for ligand mass balance."},
{"phase":"aqueous","core_label":"L1:1 H:4","keep":true,"rationale":"H4EDTA neutral form kept as reference."},
{"phase":"aqueous","core_label":"L1:1 H:5","keep":true,"rationale":"H5EDTA+ kept for complete ligand ladder."},
{"phase":"aqueous","core_label":"L1:1 H:6","keep":true,"rationale":"H6EDTA2+ kept for complete ligand ladder."},
{"phase":"aqueous","core_label":"Pb$+2:1 H:-2","keep":true,"rationale":"[Pb(OH)2] mononuclear hydroxo species explicitly retained."},
{"phase":"aqueous","core_label":"Pb$+2:1 L1:1","keep":true,"rationale":"[Pb(EDTA)]2- primary Pb–EDTA complex retained."},
{"phase":"aqueous","core_label":"Pb$+2:1 L1:1 H:1","keep":true,"rationale":"[Pb(EDTA)H]- protonated complex retained."},
{"phase":"aqueous","core_label":"Pb$+2:2 H:-1","keep":true,"rationale":"[Pb2(OH)]3+ polynuclear hydroxo species explicitly retained."},
{"phase":"aqueous","core_label":"Pb$+4:1","keep":false,"rationale":"Pb(IV) species out of scope at pH 6–8 with no applied potential."},
{"phase":"aqueous","core_label":"Pb$+4:1 H:-6","keep":false,"rationale":"[PbO3]2- Pb(IV) species out of scope per case recommendations."},
{"phase":"aqueous","core_label":"Pb$+4:1 H:-8","keep":false,"rationale":"[PbO4]4- Pb(IV) species out of scope per case recommendations."},
{"phase":"aqueous","core_label":"Zn$+2:1 H:-2","keep":true,"rationale":"[Zn(OH)2] in SRD-46 hydroxo ladder explicitly retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1","keep":true,"rationale":"[Zn(EDTA)]2- primary Zn–EDTA complex retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:-1","keep":true,"rationale":"Mixed-hydroxo [Zn(EDTA)(OH)]3- explicitly retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:1","keep":true,"rationale":"[Zn(EDTA)H]- protonated complex retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:2","keep":true,"rationale":"[Zn(EDTA)H2] diprotonated complex retained."},
{"phase":"solid","core_label":"Ca$+0:1","keep":false,"rationale":"Ca(s) metal out-of-scope non-aqueous reference at pH 6–8."},
{"phase":"solid","core_label":"Ca$+2:1 H:-4","keep":false,"rationale":"CaO2 anhydrous peroxide not a competing phase in solution."},
{"phase":"solid","core_label":"Pb$+0:1","keep":true,"rationale":"Pb(s) retained as formal M(0) ground-state reference per Pb instruction."},
{"phase":"solid","core_label":"Pb$+2:2 Pb$+4:1 H:-8","keep":false,"rationale":"Pb3O4 mixed Pb(II/IV) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Pb$+3:1 H:-3","keep":false,"rationale":"Pb2O3 Pb(III) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Pb$+4:1 H:-4","keep":false,"rationale":"PbO2 Pb(IV) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Zn$+0:1","keep":false,"rationale":"Zn(s) metal decorative at pH 6–8 in solution, dropped per Zn instruction."}
]}

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose fixes this as an aqueous speciation / selectivity problem at fixed pH 6–8, 25 °C, 0.1 m, with no applied potential; redox branches (Pb(III), Pb(IV), elemental metals as competing phases) are decorative and should be pruned, keeping only ground-state M(0) as a formal reference.
- Working regime is 1 mM metal + 5 mM EDTA near neutral pH: EDTA complexes (ML, MHL, M(OH)L) dominate and must all be retained; hydroxo monomers through M(OH)3-/M(OH)4^2- are real; Pb polynuclear hydroxo species (Pb2OH, Pb3(OH)4, Pb4(OH)4, Pb6(OH)8) stay because free Pb2+ in the EDTA-poor fraction can still populate them.
- Spellings [M(OH)n]^(2-n) (SRD-46) and [HMOn]^- / [MOn]^2- (Atlas) denote the same aqueous species; collapse to one copy, preferring SRD-46 for internal consistency with the EDTA set.
- Solids: no evaporation or precipitation question is posed, but one ground-state hydroxide per metal is retained as a saturation ceiling. Collapse Zn(OH)2 polymorphs to the thermodynamically stable form (ε-Zn(OH)2) and drop the rest; keep one Ca(OH)2 and one PbO·H2O-equivalent solid. Anhydrous oxides and higher Pb oxides are not competing phases at 25 °C in solution and are dropped.
- Carbonates are not in the inventory; the near-neutral pot is implicitly CO2-free as given, so no counterion gap to flag.
- Phase question is 'which species forms and at what fraction' — a speciation problem, not a stability-diagram ground-state collapse — so distinct protonation and mixed-ligand EDTA species are kept even if close in μ.
- Treatment differs by element: Pb needs its polynuclear hydroxo set and loses its high-valent branch; Zn needs polymorph collapse; Ca is simple with only one EDTA, one MHL, one hydroxo, one solid.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Keep one Ca2+ (prefer SRD-46 [Ca]2+ and drop the Atlas duplicate), the single [Ca(OH)]+ monomer, both EDTA complexes [Ca(EDTA)]2- and [Ca(EDTA)H]-, and one Ca(OH)2 solid (prefer SRD-46 [Ca(OH)2](s), drop the Atlas duplicate). Drop CaO, CaO2, and Ca(s) metal as out-of-scope non-aqueous references with no competing role at pH 6–8 in solution.
- Pb: Keep one Pb2+ (prefer SRD-46 [Pb]2+, drop Atlas duplicate), the full mononuclear hydroxo ladder [Pb(OH)]+ / [Pb(OH)2] / [Pb(OH)3]- (collapse Atlas [HPbO2]- into the SRD-46 [Pb(OH)3]- as the same species), all polynuclear hydroxo species [Pb2OH]3+, [Pb3(OH)4]2+, [Pb4(OH)4]4+, [Pb6(OH)8]4+, and both EDTA complexes [Pb(EDTA)]2- and [Pb(EDTA)H]-. Drop every Pb(IV)/Pb(III) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and the anhydrous PbO polymorphs as out-of-scope redox phases; retain Pb(s) metal and one hydrated Pb(II) hydroxide [(Pb2O(OH)2)0.5](s) as the sole solid saturation reference.
- Zn: Keep one Zn2+ (prefer SRD-46 [Zn]2+, drop Atlas duplicate and the Atlas [ZnOH]+ whose μ disagrees with SRD-46 [Zn(OH)]+), the SRD-46 hydroxo ladder [Zn(OH)]+ / [Zn(OH)2] / [Zn(OH)3]- / [Zn(OH)4]2- (collapse the Atlas notations [HZnO2]- and [ZnO2]2- into their SRD-46 equivalents as the same species), and all four EDTA complexes including the mixed-hydroxo [Zn(EDTA)(OH)]3- and protonated [Zn(EDTA)H]-, [Zn(EDTA)H2]. For solids, keep only the thermodynamically stable ε-Zn(OH)2 (prefer SRD-46 [Zn(OH)2(s,epsilon)]) as the single saturation reference and drop all other polymorphs, both ZnO entries, and Zn(s) metal as decorative at pH 6–8 in solution.

[Singletons: n=30]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ca | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +1 | 74.428 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | SRD-46 | -2 | 58.618 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | SRD-46 | -1 | 40.924 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Pb | aqueous | aqueous | `Pb$+2:1 H:-2` | `[Pb(OH)2]` | SRD-46 | +0 | 97.602 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1` | `[Pb(EDTA)]2-` | SRD-46 | -2 | 16.666 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1 H:1` | `[Pb(EDTA)H]-` | SRD-46 | -1 | 0.685 |
| Pb | aqueous | aqueous | `Pb$+2:2 H:-1` | `[Pb2(OH)]3+` | SRD-46 | +3 | 36.529 |
| Pb | aqueous | aqueous | `Pb$+4:1` | `Pb4+` | Atlas | +4 | 326.812 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-6` | `[PbO3]2-` | Atlas | -2 | 458.315 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-8` | `[PbO4]4-` | Atlas | -4 | 690.983 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | -2 | 25.228 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | -3 | 91.437 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | -1 | 8.105 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +0 | 1.256 |
| Ca | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +0 | 553.041 |
| Ca | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +0 | 429.111 |
| Pb | solid | elemental_solid | `Pb$+0:1` | `Pb` | Atlas | +0 | 24.309 |
| Pb | solid | anhydrous_solid | `Pb$+2:2 Pb$+4:1 H:-8` | `Pb3O4` | Atlas | +0 | 406.643 |
| Pb | solid | anhydrous_solid | `Pb$+3:1 H:-3` | `Pb2O3` | Atlas | +0 | 348.414 |
| Pb | solid | anhydrous_solid | `Pb$+4:1 H:-4` | `PbO2` | Atlas | +0 | 279.700 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |

## Assistant
<summary>Applying case-specific recommendations: drop all Pb(III)/Pb(IV) species, drop CaO2, Ca(s), Zn(s) solids per instructions. Keep Pb(s) as reference metal per Pb instruction. Keep all aqueous EDTA/hydroxo species and empty aqueous solvent entry.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Need to properly call the tool with full JSON payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full decisions payload per case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full singleton decisions per case-specific recommendations: keep aqueous EDTA ladder, metal-EDTA complexes, hydroxo species including Pb polynuclear; drop Pb(III)/Pb(IV) aqueous species; drop CaO2, Ca(s), Zn(s) solids; keep Pb(s) per Pb instruction.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full JSON payload with all 30 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full decisions JSON per case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full JSON payload with explicit verdicts for all 30 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting proper full JSON payload for all 30 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent/empty aqueous reference entry; harmless to retain."},
{"phase":"aqueous","core_label":"Ca$+2:1 H:-1","keep":true,"rationale":"[Ca(OH)]+ monomer explicitly kept per Ca instruction."},
{"phase":"aqueous","core_label":"Ca$+2:1 L1:1","keep":true,"rationale":"[Ca(EDTA)]2- is the primary Ca–EDTA complex and is explicitly retained."},
{"phase":"aqueous","core_label":"Ca$+2:1 L1:1 H:1","keep":true,"rationale":"[Ca(EDTA)H]- protonated complex explicitly retained."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free EDTA4- ligand required for speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"HEDTA3- protonation state needed near pH 6–8."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"H2EDTA2- protonation state needed in working pH range."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"H3EDTA- distinct protonation state kept for ligand mass balance."},
{"phase":"aqueous","core_label":"L1:1 H:4","keep":true,"rationale":"H4EDTA neutral form kept as reference."},
{"phase":"aqueous","core_label":"L1:1 H:5","keep":true,"rationale":"H5EDTA+ kept for complete ligand ladder."},
{"phase":"aqueous","core_label":"L1:1 H:6","keep":true,"rationale":"H6EDTA2+ kept for complete ligand ladder."},
{"phase":"aqueous","core_label":"Pb$+2:1 H:-2","keep":true,"rationale":"[Pb(OH)2] mononuclear hydroxo species explicitly retained."},
{"phase":"aqueous","core_label":"Pb$+2:1 L1:1","keep":true,"rationale":"[Pb(EDTA)]2- primary Pb–EDTA complex retained."},
{"phase":"aqueous","core_label":"Pb$+2:1 L1:1 H:1","keep":true,"rationale":"[Pb(EDTA)H]- protonated complex retained."},
{"phase":"aqueous","core_label":"Pb$+2:2 H:-1","keep":true,"rationale":"[Pb2(OH)]3+ polynuclear hydroxo species explicitly retained."},
{"phase":"aqueous","core_label":"Pb$+4:1","keep":false,"rationale":"Pb(IV) species out of scope at pH 6–8 with no applied potential."},
{"phase":"aqueous","core_label":"Pb$+4:1 H:-6","keep":false,"rationale":"[PbO3]2- Pb(IV) species out of scope per case recommendations."},
{"phase":"aqueous","core_label":"Pb$+4:1 H:-8","keep":false,"rationale":"[PbO4]4- Pb(IV) species out of scope per case recommendations."},
{"phase":"aqueous","core_label":"Zn$+2:1 H:-2","keep":true,"rationale":"[Zn(OH)2] in SRD-46 hydroxo ladder explicitly retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1","keep":true,"rationale":"[Zn(EDTA)]2- primary Zn–EDTA complex retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:-1","keep":true,"rationale":"Mixed-hydroxo [Zn(EDTA)(OH)]3- explicitly retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:1","keep":true,"rationale":"[Zn(EDTA)H]- protonated complex retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:2","keep":true,"rationale":"[Zn(EDTA)H2] diprotonated complex retained."},
{"phase":"solid","core_label":"Ca$+0:1","keep":false,"rationale":"Ca(s) metal out-of-scope non-aqueous reference at pH 6–8."},
{"phase":"solid","core_label":"Ca$+2:1 H:-4","keep":false,"rationale":"CaO2 anhydrous peroxide not a competing phase in solution."},
{"phase":"solid","core_label":"Pb$+0:1","keep":true,"rationale":"Pb(s) retained as formal M(0) ground-state reference per Pb instruction."},
{"phase":"solid","core_label":"Pb$+2:2 Pb$+4:1 H:-8","keep":false,"rationale":"Pb3O4 mixed Pb(II/IV) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Pb$+3:1 H:-3","keep":false,"rationale":"Pb2O3 Pb(III) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Pb$+4:1 H:-4","keep":false,"rationale":"PbO2 Pb(IV) oxide out-of-scope redox phase."},
{"phase":"solid","core_label":"Zn$+0:1","keep":false,"rationale":"Zn(s) metal decorative at pH 6–8 in solution, dropped per Zn instruction."}
]}
</answer>

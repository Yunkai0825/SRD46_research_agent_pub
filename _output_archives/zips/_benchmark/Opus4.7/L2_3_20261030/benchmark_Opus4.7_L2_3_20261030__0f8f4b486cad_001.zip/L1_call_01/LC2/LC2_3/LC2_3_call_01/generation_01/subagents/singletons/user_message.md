[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Keep one Ca2+ (prefer SRD-46 [Ca]2+ and drop the Atlas duplicate), the single [Ca(OH)]+ monomer, both EDTA complexes [Ca(EDTA)]2- and [Ca(EDTA)H]-, and one Ca(OH)2 solid (prefer SRD-46 [Ca(OH)2](s), drop the Atlas duplicate). Drop CaO, CaO2, and Ca(s) metal as out-of-scope non-aqueous references with no competing role at pH 6–8 in solution.
- Pb: Keep one Pb2+ (prefer SRD-46 [Pb]2+, drop Atlas duplicate), the full mononuclear hydroxo ladder [Pb(OH)]+ / [Pb(OH)2] / [Pb(OH)3]- (collapse Atlas [HPbO2]- into the SRD-46 [Pb(OH)3]- as the same species), all polynuclear hydroxo species [Pb2OH]3+, [Pb3(OH)4]2+, [Pb4(OH)4]4+, [Pb6(OH)8]4+, and both EDTA complexes [Pb(EDTA)]2- and [Pb(EDTA)H]-. Drop every Pb(IV)/Pb(III) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and the anhydrous PbO polymorphs as out-of-scope redox phases; retain Pb(s) metal and one hydrated Pb(II) hydroxide [(Pb2O(OH)2)0.5](s) as the sole solid saturation reference.
- Zn: Keep one Zn2+ (prefer SRD-46 [Zn]2+, drop Atlas duplicate and the Atlas [ZnOH]+ whose μ disagrees with SRD-46 [Zn(OH)]+), the SRD-46 hydroxo ladder [Zn(OH)]+ / [Zn(OH)2] / [Zn(OH)3]- / [Zn(OH)4]2- (collapse the Atlas notations [HZnO2]- and [ZnO2]2- into their SRD-46 equivalents as the same species), and all four EDTA complexes including the mixed-hydroxo [Zn(EDTA)(OH)]3- and protonated [Zn(EDTA)H]-, [Zn(EDTA)H2]. For solids, keep only the thermodynamically stable ε-Zn(OH)2 (prefer SRD-46 [Zn(OH)2(s,epsilon)]) as the single saturation reference and drop all other polymorphs, both ZnO entries, and Zn(s) metal as decorative at pH 6–8 in solution.

[Singletons: n=30]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ca | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +1 | 74.428 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | SRD-46 | -2 | 58.618 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | SRD-46 | -1 | 40.924 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Pb | aqueous | aqueous | `Pb$+2:1 H:-2` | `[Pb(OH)2]` | SRD-46 | +0 | 97.602 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1` | `[Pb(EDTA)]2-` | SRD-46 | -2 | 16.666 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1 H:1` | `[Pb(EDTA)H]-` | SRD-46 | -1 | 0.685 |
| Pb | aqueous | aqueous | `Pb$+2:2 H:-1` | `[Pb2(OH)]3+` | SRD-46 | +3 | 36.529 |
| Pb | aqueous | aqueous | `Pb$+4:1` | `Pb4+` | Atlas | +4 | 326.812 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-6` | `[PbO3]2-` | Atlas | -2 | 458.315 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-8` | `[PbO4]4-` | Atlas | -4 | 690.983 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | -2 | 25.228 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | -3 | 91.437 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | -1 | 8.105 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +0 | 1.256 |
| Ca | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +0 | 553.041 |
| Ca | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +0 | 429.111 |
| Pb | solid | elemental_solid | `Pb$+0:1` | `Pb` | Atlas | +0 | 24.309 |
| Pb | solid | anhydrous_solid | `Pb$+2:2 Pb$+4:1 H:-8` | `Pb3O4` | Atlas | +0 | 406.643 |
| Pb | solid | anhydrous_solid | `Pb$+3:1 H:-3` | `Pb2O3` | Atlas | +0 | 348.414 |
| Pb | solid | anhydrous_solid | `Pb$+4:1 H:-4` | `PbO2` | Atlas | +0 | 279.700 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
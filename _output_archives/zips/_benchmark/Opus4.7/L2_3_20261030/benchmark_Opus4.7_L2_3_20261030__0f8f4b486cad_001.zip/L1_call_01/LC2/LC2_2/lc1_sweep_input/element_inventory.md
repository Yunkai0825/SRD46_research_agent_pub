# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ca

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b6c302137447026a` | aqueous | aqueous | `Ca$+2:1` | `Ca2+` | `Ca$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-e299d16ea468bc20` | aqueous | aqueous | `Ca$+2:1` | `[Ca]2+` | `[Ca$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-e839c527d55bf1cb` | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | `[Ca$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +74.428 | true |
| `DEDUP-faedbd84bcd76b54` | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | `[Ca$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +58.618 | true |
| `DEDUP-0a589b4ad87d054e` | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | `[Ca$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +40.924 | true |
| `DEDUP-490b8a5a371510a8` | solid | anhydrous_solid | `Ca$+2:1 H:-2` | `CaO` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +186.062 | true |
| `DEDUP-fa87b80c5829b549` | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | `Ca$+2.OH4.z+0(s)` | Atlas | +0 | 1 | +429.111 | true |
| `DEDUP-670205cb5c260f22` | solid | elemental_solid | `Ca$+0:1` | `Ca` | `Ca$+0.z+0(s)` | Atlas | +0 | 1 | +553.041 | true |
| `DEDUP-24fbc9dcfcd8e007` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `Ca(OH)2` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +130.666 | true |
| `DEDUP-b89dc7ad7b6d082d` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | `[Ca$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +130.192 | true |

## Pb

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-ae70ee8833ae7e04` | aqueous | aqueous | `Pb$+2:1` | `Pb2+` | `Pb$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-7626e2d7e3d9fd08` | aqueous | aqueous | `Pb$+2:1` | `[Pb]2+` | `[Pb$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-8b4310dd2b02884d` | aqueous | aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+` | `[Pb$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +45.661 | true |
| `DEDUP-5a5e1aca7183b7ba` | aqueous | aqueous | `Pb$+2:1 H:-1` | `[Pb4(OH)4]4+` | `[Pb$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +117.008 | true |
| `DEDUP-63e4b317197bcadd` | aqueous | aqueous | `Pb$+2:1 H:-2` | `[Pb(OH)2]` | `[Pb$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +97.602 | true |
| `DEDUP-2f94e031967bfc02` | aqueous | aqueous | `Pb$+2:1 H:-3` | `[HPbO2]-` | `Pb$+2.OH3.z-1` | Atlas | -1 | 1 | +159.787 | true |
| `DEDUP-5967796de560f31a` | aqueous | aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` | `[Pb$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +160.386 | true |
| `DEDUP-8bd2a77f29a12f4d` | aqueous | aqueous | `Pb$+2:1 L1:1` | `[Pb(EDTA)]2-` | `[Pb$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +16.666 | true |
| `DEDUP-857dcee7b14181ba` | aqueous | aqueous | `Pb$+2:1 L1:1 H:1` | `[Pb(EDTA)H]-` | `[Pb$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +0.685 | true |
| `DEDUP-375c7fb931c092d9` | aqueous | aqueous | `Pb$+2:2 H:-1` | `[Pb2(OH)]3+` | `[Pb$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +36.529 | true |
| `DEDUP-2d64800d2a324a13` | aqueous | aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+` | `[Pb$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +136.414 | true |
| `DEDUP-e0676f6c4b01323a` | aqueous | aqueous | `Pb$+2:3 H:-4` | `[Pb6(OH)8]4+` | `[Pb$+2]6.[OH]8.[z+4]` | SRD-46 | +4 | 2 | +248.855 | true |
| `DEDUP-b85122e7963955f4` | aqueous | aqueous | `Pb$+4:1` | `Pb4+` | `Pb$+4.z+4` | Atlas | +4 | 1 | +326.812 | true |
| `DEDUP-5e0c15a561382fef` | aqueous | aqueous | `Pb$+4:1 H:-6` | `[PbO3]2-` | `Pb$+4.OH6.z-2` | Atlas | -2 | 1 | +458.315 | true |
| `DEDUP-2c346d3e29958673` | aqueous | aqueous | `Pb$+4:1 H:-8` | `[PbO4]4-` | `Pb$+4.OH8.z-4` | Atlas | -4 | 1 | +690.983 | true |
| `DEDUP-fc3bc3018ed80da1` | solid | anhydrous_solid | `Pb$+2:1 H:-2` | `[PbO(s,red)]` | `[Pb$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +72.488 | true |
| `DEDUP-9dccc3b71caf065f` | solid | anhydrous_solid | `Pb$+2:1 H:-2` | `[PbO(s,yellow)]` | `[Pb$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +73.629 | true |
| `DEDUP-4926a8b87350673e` | solid | anhydrous_solid | `Pb$+2:2 Pb$+4:1 H:-8` | `Pb3O4` | `Pb$+2(2).Pb$+4.OH8.z+0(s)` | Atlas | +0 | 1 | +406.643 | true |
| `DEDUP-524a66acd8c6e449` | solid | anhydrous_solid | `Pb$+3:1 H:-3` | `Pb2O3` | `Pb$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +348.414 | true |
| `DEDUP-f4272ab80a16bf41` | solid | anhydrous_solid | `Pb$+4:1 H:-4` | `PbO2` | `Pb$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +279.700 | true |
| `DEDUP-7589f1f3fc8ca586` | solid | elemental_solid | `Pb$+0:1` | `Pb` | `Pb$+0.z+0(s)` | Atlas | +0 | 1 | +24.309 | true |
| `DEDUP-3b467791d6a07680` | solid | hydrated_solid | `Pb$+2:1 H:-2` | `[(Pb2O((OH))2)0.5](s)` | `[Pb$+2].[OH]2.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +74.771 | true |

## Zn

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | `Zn$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | `[Zn$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | `Zn$+2.OH.z+1` | Atlas | +1 | 1 | +91.521 | true |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | `[Zn$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +53.081 | true |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | `[Zn$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +101.597 | true |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | `Zn$+2.OH3.z-1` | Atlas | -1 | 1 | +164.281 | true |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | `[Zn$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +160.386 | true |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | `Zn$+2.OH4.z-2` | Atlas | -2 | 1 | +190.640 | true |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | `[Zn$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +231.161 | true |
| `DEDUP-c23350dbb148af67` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | `[Zn$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +25.228 | true |
| `DEDUP-076ec57a14e420dc` | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | `[Zn$+2].[OH].[L1].[z-3]` | SRD-46 | -3 | 1 | +91.437 | true |
| `DEDUP-64c3f6e7e7290153` | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | `[Zn$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +8.105 | true |
| `DEDUP-b128a70c457c8b6a` | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | `[Zn$+2].[[H]2[L1]].[z+0]` | SRD-46 | +0 | 1 | +1.256 | true |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +65.747 | true |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +60.141 | true |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +54.869 | true |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | `[Zn$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +68.721 | true |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | `Zn$+0.z+0(s)` | Atlas | +0 | 1 | +147.210 | true |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +61.204 | true |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +69.915 | true |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +64.555 | true |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +62.501 | true |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +63.810 | true |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | `[Zn$+2].[OH]2.[[z+0(s)[7]]]` | SRD-46 | +0 | 1 | +75.227 | true |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | `[Zn$+2].[OH]2.[[z+0(s)[4]]]` | SRD-46 | +0 | 1 | +71.118 | true |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | `[Zn$+2].[OH]2.[[z+0(s)[5]]]` | SRD-46 | +0 | 1 | +71.346 | true |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | `[Zn$+2].[OH]2.[[z+0(s)[6]]]` | SRD-46 | +0 | 1 | +71.632 | true |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | `[Zn$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +69.805 | true |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | `[Zn$+2].[OH]2.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +71.004 | true |

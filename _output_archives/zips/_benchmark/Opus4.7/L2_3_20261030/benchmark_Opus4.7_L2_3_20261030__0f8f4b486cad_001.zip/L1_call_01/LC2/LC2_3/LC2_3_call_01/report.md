# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    456.15
- elapsed_s (total):  456.15
- llm_iterations:     53
- llm_tool_calls:     39

- n_groups:           42
- n_multi_groups:     12
- n_singletons:       30
- n_decisions:        42
- n_dropped:          34
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` [SRD-46] | Same Ca2+ aqueous ion in both sources; prefer SRD-46 per element instructions. |
| aqueous | `Pb$+2:1` | `[Pb]2+` [SRD-46] | Same Pb2+ aqueous ion in both notations; prefer SRD-46 per element instructions and drop Atlas duplicate. |
| aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+` [SRD-46], `[Pb4(OH)4]4+` [SRD-46] | Mononuclear and tetranuclear Pb(II) hydroxo species are distinct by nuclearity and charge; both retained per plan. |
| aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` [SRD-46] | Atlas [HPbO2]- and SRD-46 [Pb(OH)3]- denote the same aqueous Pb(II) trihydroxo species; keep SRD-46 per element instructions. |
| aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+` [SRD-46], `[Pb6(OH)8]4+` [SRD-46] | Distinct polynuclear Pb(II) hydroxo species (different nuclearity and charge); both explicitly retained per element instructions. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Prefer SRD-46 Zn2+ over Atlas duplicate per element instructions. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Element instructions: keep SRD-46 [Zn(OH)]+ and drop Atlas [ZnOH]+ whose mu disagrees. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Atlas [HZnO2]- is the same aqueous species as SRD-46 [Zn(OH)3]-; collapse to SRD-46 per element instructions. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Collapse Atlas [ZnO2]2- notation into its SRD-46 equivalent [Zn(OH)4]2- as the same species; prefer SRD-46. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` [SRD-46] | Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| solid | `Pb$+2:1 H:-2` | `[(Pb2O((OH))2)0.5](s)` [SRD-46] | Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` [SRD-46] | Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/empty aqueous reference species, in scope. |
| aqueous | `Ca$+2:1 H:-1` | yes | [Ca(OH)]+ monomer retained per Ca instruction. |
| aqueous | `Ca$+2:1 L1:1` | yes | [Ca(EDTA)]2- is a required EDTA complex. |
| aqueous | `Ca$+2:1 L1:1 H:1` | yes | [Ca(EDTA)H]- protonated EDTA complex retained. |
| aqueous | `L1:1` | yes | Free EDTA4- ligand required for speciation. |
| aqueous | `L1:1 H:1` | yes | HEDTA3- protonation state in near-neutral speciation. |
| aqueous | `L1:1 H:2` | yes | H2EDTA2- dominant near-neutral protonation form. |
| aqueous | `L1:1 H:3` | yes | H3EDTA- protonation state retained. |
| aqueous | `L1:1 H:4` | yes | H4EDTA neutral protonation state retained. |
| aqueous | `L1:1 H:5` | yes | H5EDTA+ protonation state retained for completeness. |
| aqueous | `L1:1 H:6` | yes | H6EDTA2+ fully protonated form retained. |
| aqueous | `Pb$+2:1 H:-2` | yes | [Pb(OH)2] mononuclear hydroxo species retained. |
| aqueous | `Pb$+2:1 L1:1` | yes | [Pb(EDTA)]2- required EDTA complex. |
| aqueous | `Pb$+2:1 L1:1 H:1` | yes | [Pb(EDTA)H]- protonated EDTA complex retained. |
| aqueous | `Pb$+2:2 H:-1` | yes | [Pb2(OH)]3+ polynuclear hydroxo species retained per Pb instruction. |
| aqueous | `Pb$+4:1` | NO | Pb(IV) aqueous species out of scope at pH 6-8 without applied potential. |
| aqueous | `Pb$+4:1 H:-6` | NO | [PbO3]2- Pb(IV) species dropped per Pb instruction. |
| aqueous | `Pb$+4:1 H:-8` | NO | [PbO4]4- Pb(IV) species dropped per Pb instruction. |
| aqueous | `Zn$+2:1 H:-2` | yes | [Zn(OH)2] hydroxo species retained in SRD-46 ladder. |
| aqueous | `Zn$+2:1 L1:1` | yes | [Zn(EDTA)]2- required EDTA complex. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | [Zn(EDTA)(OH)]3- mixed-hydroxo EDTA complex retained. |
| aqueous | `Zn$+2:1 L1:1 H:1` | yes | [Zn(EDTA)H]- protonated EDTA complex retained. |
| aqueous | `Zn$+2:1 L1:1 H:2` | yes | [Zn(EDTA)H2] diprotonated EDTA complex retained. |
| solid | `Ca$+0:1` | NO | Ca(s) metal out of scope at pH 6-8 aqueous conditions. |
| solid | `Ca$+2:1 H:-4` | NO | CaO2 peroxide out-of-scope non-aqueous reference per Ca instruction. |
| solid | `Pb$+0:1` | yes | Pb(s) metal retained as formal M(0) reference per Pb instruction. |
| solid | `Pb$+2:2 Pb$+4:1 H:-8` | NO | Pb3O4 mixed-valence higher Pb oxide out of scope at 25 C in solution. |
| solid | `Pb$+3:1 H:-3` | NO | Pb2O3 Pb(III) oxide out of scope redox phase. |
| solid | `Pb$+4:1 H:-4` | NO | PbO2 Pb(IV) oxide out of scope redox phase. |
| solid | `Zn$+0:1` | NO | Zn(s) metal decorative at pH 6-8 in solution per Zn instruction. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | LC2 element review: Same Ca2+ aqueous ion in both sources; prefer SRD-46 per element instructions. |
| `Pb2+` | Atlas | aqueous | LC2 element review: Same Pb2+ aqueous ion in both notations; prefer SRD-46 per element instructions and drop Atlas duplicate. |
| `[HPbO2]-` | Atlas | aqueous | LC2 element review: Atlas [HPbO2]- and SRD-46 [Pb(OH)3]- denote the same aqueous Pb(II) trihydroxo species; keep SRD-46 per element instructions. |
| `Pb4+` | Atlas | aqueous | LC2 element review: Pb(IV) aqueous species out of scope at pH 6-8 without applied potential. |
| `[PbO3]2-` | Atlas | aqueous | LC2 element review: [PbO3]2- Pb(IV) species dropped per Pb instruction. |
| `[PbO4]4-` | Atlas | aqueous | LC2 element review: [PbO4]4- Pb(IV) species dropped per Pb instruction. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Prefer SRD-46 Zn2+ over Atlas duplicate per element instructions. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Element instructions: keep SRD-46 [Zn(OH)]+ and drop Atlas [ZnOH]+ whose mu disagrees. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Atlas [HZnO2]- is the same aqueous species as SRD-46 [Zn(OH)3]-; collapse to SRD-46 per element instructions. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Collapse Atlas [ZnO2]2- notation into its SRD-46 equivalent [Zn(OH)4]2- as the same species; prefer SRD-46. |
| `Ca(OH)2` | Atlas | dissolution | LC2 element review: Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| `CaO` | Atlas | dissolution | LC2 element review: Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| `CaO2` | Atlas | dissolution | LC2 element review: CaO2 peroxide out-of-scope non-aqueous reference per Ca instruction. |
| `Ca` | Atlas | dissolution | LC2 element review: Ca(s) metal out of scope at pH 6-8 aqueous conditions. |
| `[PbO(s,red)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| `[PbO(s,yellow)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| `Pb3O4` | Atlas | dissolution | LC2 element review: Pb3O4 mixed-valence higher Pb oxide out of scope at 25 C in solution. |
| `Pb2O3` | Atlas | dissolution | LC2 element review: Pb2O3 Pb(III) oxide out of scope redox phase. |
| `PbO2` | Atlas | dissolution | LC2 element review: PbO2 Pb(IV) oxide out of scope redox phase. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `ZnO` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `Zn` | Atlas | dissolution | LC2 element review: Zn(s) metal decorative at pH 6-8 in solution per Zn instruction. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 9f15ebbdaecb423faa810e276cb394da
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup verdicts align with committed element instructions: SRD-46 preferred over Atlas for all duplicate aqueous metal ions (Ca2+, Pb2+, Zn2+) and for notational collapses ([HPbO2]-/[Pb(OH)3]-, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-, Atlas [ZnOH]+ dropped for mu mismatch). Pb mononuclear and polynuclear hydroxo ladder (Pb2OH, Pb3(OH)4, Pb4(OH)4, Pb6(OH)8) retained; all Pb(III)/Pb(IV) species and anhydrous PbO polymorphs dropped; one hydrated Pb(II) hydroxide and Pb(s) retained. Zn(OH)2 polymorphs collapsed to the thermodynamically stable epsilon form; both ZnO entries, Zn(s), and other polymorphs dropped. Ca reduced to one hydroxide solid, with CaO/CaO2/Ca(s) dropped. EDTA protonation ladder (H6..EDTA4-) and all required M-EDTA complexes including Zn(EDTA)(OH)3- and Zn(EDTA)H2 kept. No internal inconsistencies and no out-of-scope entries remain.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (15/15)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_3_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

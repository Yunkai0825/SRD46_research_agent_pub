# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose fixes this as an aqueous speciation / selectivity problem at fixed pH 6–8, 25 °C, 0.1 m, with no applied potential; redox branches (Pb(III), Pb(IV), elemental metals as competing phases) are decorative and should be pruned, keeping only ground-state M(0) as a formal reference.
- Working regime is 1 mM metal + 5 mM EDTA near neutral pH: EDTA complexes (ML, MHL, M(OH)L) dominate and must all be retained; hydroxo monomers through M(OH)3-/M(OH)4^2- are real; Pb polynuclear hydroxo species (Pb2OH, Pb3(OH)4, Pb4(OH)4, Pb6(OH)8) stay because free Pb2+ in the EDTA-poor fraction can still populate them.
- Spellings [M(OH)n]^(2-n) (SRD-46) and [HMOn]^- / [MOn]^2- (Atlas) denote the same aqueous species; collapse to one copy, preferring SRD-46 for internal consistency with the EDTA set.
- Solids: no evaporation or precipitation question is posed, but one ground-state hydroxide per metal is retained as a saturation ceiling. Collapse Zn(OH)2 polymorphs to the thermodynamically stable form (ε-Zn(OH)2) and drop the rest; keep one Ca(OH)2 and one PbO·H2O-equivalent solid. Anhydrous oxides and higher Pb oxides are not competing phases at 25 °C in solution and are dropped.
- Carbonates are not in the inventory; the near-neutral pot is implicitly CO2-free as given, so no counterion gap to flag.
- Phase question is 'which species forms and at what fraction' — a speciation problem, not a stability-diagram ground-state collapse — so distinct protonation and mixed-ligand EDTA species are kept even if close in μ.
- Treatment differs by element: Pb needs its polynuclear hydroxo set and loses its high-valent branch; Zn needs polymorph collapse; Ca is simple with only one EDTA, one MHL, one hydroxo, one solid.

## Element instructions

- **Ca**: Keep one Ca2+ (prefer SRD-46 [Ca]2+ and drop the Atlas duplicate), the single [Ca(OH)]+ monomer, both EDTA complexes [Ca(EDTA)]2- and [Ca(EDTA)H]-, and one Ca(OH)2 solid (prefer SRD-46 [Ca(OH)2](s), drop the Atlas duplicate). Drop CaO, CaO2, and Ca(s) metal as out-of-scope non-aqueous references with no competing role at pH 6–8 in solution.
- **Pb**: Keep one Pb2+ (prefer SRD-46 [Pb]2+, drop Atlas duplicate), the full mononuclear hydroxo ladder [Pb(OH)]+ / [Pb(OH)2] / [Pb(OH)3]- (collapse Atlas [HPbO2]- into the SRD-46 [Pb(OH)3]- as the same species), all polynuclear hydroxo species [Pb2OH]3+, [Pb3(OH)4]2+, [Pb4(OH)4]4+, [Pb6(OH)8]4+, and both EDTA complexes [Pb(EDTA)]2- and [Pb(EDTA)H]-. Drop every Pb(IV)/Pb(III) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and the anhydrous PbO polymorphs as out-of-scope redox phases; retain Pb(s) metal and one hydrated Pb(II) hydroxide [(Pb2O(OH)2)0.5](s) as the sole solid saturation reference.
- **Zn**: Keep one Zn2+ (prefer SRD-46 [Zn]2+, drop Atlas duplicate and the Atlas [ZnOH]+ whose μ disagrees with SRD-46 [Zn(OH)]+), the SRD-46 hydroxo ladder [Zn(OH)]+ / [Zn(OH)2] / [Zn(OH)3]- / [Zn(OH)4]2- (collapse the Atlas notations [HZnO2]- and [ZnO2]2- into their SRD-46 equivalents as the same species), and all four EDTA complexes including the mixed-hydroxo [Zn(EDTA)(OH)]3- and protonated [Zn(EDTA)H]-, [Zn(EDTA)H2]. For solids, keep only the thermodynamically stable ε-Zn(OH)2 (prefer SRD-46 [Zn(OH)2(s,epsilon)]) as the single saturation reference and drop all other polymorphs, both ZnO entries, and Zn(s) metal as decorative at pH 6–8 in solution.

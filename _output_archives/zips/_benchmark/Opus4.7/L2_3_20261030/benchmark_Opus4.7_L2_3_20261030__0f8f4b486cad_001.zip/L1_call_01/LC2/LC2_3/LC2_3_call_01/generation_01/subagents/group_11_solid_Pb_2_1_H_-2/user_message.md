[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Pb: Keep one Pb2+ (prefer SRD-46 [Pb]2+, drop Atlas duplicate), the full mononuclear hydroxo ladder [Pb(OH)]+ / [Pb(OH)2] / [Pb(OH)3]- (collapse Atlas [HPbO2]- into the SRD-46 [Pb(OH)3]- as the same species), all polynuclear hydroxo species [Pb2OH]3+, [Pb3(OH)4]2+, [Pb4(OH)4]4+, [Pb6(OH)8]4+, and both EDTA complexes [Pb(EDTA)]2- and [Pb(EDTA)H]-. Drop every Pb(IV)/Pb(III) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and the anhydrous PbO polymorphs as out-of-scope redox phases; retain Pb(s) metal and one hydrated Pb(II) hydroxide [(Pb2O(OH)2)0.5](s) as the sole solid saturation reference.

[Group: elements=Pb phase=solid core_label=Pb$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fc3bc3018ed80da1` | anhydrous_solid | `[PbO(s,red)]` | SRD-46 | +0 | 72.488 | 1 | *** |
| `DEDUP-9dccc3b71caf065f` | anhydrous_solid | `[PbO(s,yellow)]` | SRD-46 | +0 | 73.629 | 1 | *** |
| `DEDUP-3b467791d6a07680` | hydrated_solid | `[(Pb2O((OH))2)0.5](s)` | SRD-46 | +0 | 74.771 | 1 | *** |
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Keep one Ca2+ (prefer SRD-46 [Ca]2+ and drop the Atlas duplicate), the single [Ca(OH)]+ monomer, both EDTA complexes [Ca(EDTA)]2- and [Ca(EDTA)H]-, and one Ca(OH)2 solid (prefer SRD-46 [Ca(OH)2](s), drop the Atlas duplicate). Drop CaO, CaO2, and Ca(s) metal as out-of-scope non-aqueous references with no competing role at pH 6–8 in solution.

[Group: elements=Ca phase=solid core_label=Ca$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b89dc7ad7b6d082d` | hydrated_solid | `[Ca(OH)2](s)` | SRD-46 | +0 | 130.192 | 1 | *** |
| `DEDUP-24fbc9dcfcd8e007` | hydrated_solid | `Ca(OH)2` | Atlas | +0 | 130.666 | 1 | — |
| `DEDUP-490b8a5a371510a8` | anhydrous_solid | `CaO` | Atlas | +0 | 186.062 | 1 | — |
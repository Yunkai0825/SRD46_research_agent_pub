# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | generation 1: dropped — Same Ca2+ aqueous ion in both sources; prefer SRD-46 per element instructions. |
| `DEDUP-e299d16ea468bc20` | `[Ca]2+` | SRD-46 | generation 1: kept — Same Ca2+ aqueous ion in both sources; prefer SRD-46 per element instructions. |
| `DEDUP-e839c527d55bf1cb` | `[Ca(OH)]+` | SRD-46 | generation 1: kept — [Ca(OH)]+ monomer retained per Ca instruction. |
| `DEDUP-faedbd84bcd76b54` | `[Ca(EDTA)]2-` | SRD-46 | generation 1: kept — [Ca(EDTA)]2- is a required EDTA complex. |
| `DEDUP-0a589b4ad87d054e` | `[Ca(EDTA)H]-` | SRD-46 | generation 1: kept — [Ca(EDTA)H]- protonated EDTA complex retained. |
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | generation 1: dropped — Ca(s) metal out of scope at pH 6-8 aqueous conditions. |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | generation 1: dropped — Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | generation 1: dropped — Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| `DEDUP-b89dc7ad7b6d082d` | `[Ca(OH)2](s)` | SRD-46 | generation 1: kept — Keep single SRD-46 Ca(OH)2 solid; drop Atlas duplicate and out-of-scope CaO per element instructions. |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | generation 1: dropped — CaO2 peroxide out-of-scope non-aqueous reference per Ca instruction. |
| `DEDUP-ae70ee8833ae7e04` | `Pb2+` | Atlas | generation 1: dropped — Same Pb2+ aqueous ion in both notations; prefer SRD-46 per element instructions and drop Atlas duplicate. |
| `DEDUP-7626e2d7e3d9fd08` | `[Pb]2+` | SRD-46 | generation 1: kept — Same Pb2+ aqueous ion in both notations; prefer SRD-46 per element instructions and drop Atlas duplicate. |
| `DEDUP-8b4310dd2b02884d` | `[Pb(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Pb(II) hydroxo species are distinct by nuclearity and charge; both retained per plan. |
| `DEDUP-5a5e1aca7183b7ba` | `[Pb4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Pb(II) hydroxo species are distinct by nuclearity and charge; both retained per plan. |
| `DEDUP-63e4b317197bcadd` | `[Pb(OH)2]` | SRD-46 | generation 1: kept — [Pb(OH)2] mononuclear hydroxo species retained. |
| `DEDUP-2f94e031967bfc02` | `[HPbO2]-` | Atlas | generation 1: dropped — Atlas [HPbO2]- and SRD-46 [Pb(OH)3]- denote the same aqueous Pb(II) trihydroxo species; keep SRD-46 per element instructions. |
| `DEDUP-5967796de560f31a` | `[Pb(OH)3]-` | SRD-46 | generation 1: kept — Atlas [HPbO2]- and SRD-46 [Pb(OH)3]- denote the same aqueous Pb(II) trihydroxo species; keep SRD-46 per element instructions. |
| `DEDUP-8bd2a77f29a12f4d` | `[Pb(EDTA)]2-` | SRD-46 | generation 1: kept — [Pb(EDTA)]2- required EDTA complex. |
| `DEDUP-857dcee7b14181ba` | `[Pb(EDTA)H]-` | SRD-46 | generation 1: kept — [Pb(EDTA)H]- protonated EDTA complex retained. |
| `DEDUP-375c7fb931c092d9` | `[Pb2(OH)]3+` | SRD-46 | generation 1: kept — [Pb2(OH)]3+ polynuclear hydroxo species retained per Pb instruction. |
| `DEDUP-2d64800d2a324a13` | `[Pb3(OH)4]2+` | SRD-46 | generation 1: kept — Distinct polynuclear Pb(II) hydroxo species (different nuclearity and charge); both explicitly retained per element instructions. |
| `DEDUP-e0676f6c4b01323a` | `[Pb6(OH)8]4+` | SRD-46 | generation 1: kept — Distinct polynuclear Pb(II) hydroxo species (different nuclearity and charge); both explicitly retained per element instructions. |
| `DEDUP-b85122e7963955f4` | `Pb4+` | Atlas | generation 1: dropped — Pb(IV) aqueous species out of scope at pH 6-8 without applied potential. |
| `DEDUP-5e0c15a561382fef` | `[PbO3]2-` | Atlas | generation 1: dropped — [PbO3]2- Pb(IV) species dropped per Pb instruction. |
| `DEDUP-2c346d3e29958673` | `[PbO4]4-` | Atlas | generation 1: dropped — [PbO4]4- Pb(IV) species dropped per Pb instruction. |
| `DEDUP-7589f1f3fc8ca586` | `Pb` | Atlas | generation 1: kept — Pb(s) metal retained as formal M(0) reference per Pb instruction. |
| `DEDUP-3b467791d6a07680` | `[(Pb2O((OH))2)0.5](s)` | SRD-46 | generation 1: kept — Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| `DEDUP-fc3bc3018ed80da1` | `[PbO(s,red)]` | SRD-46 | generation 1: dropped — Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| `DEDUP-9dccc3b71caf065f` | `[PbO(s,yellow)]` | SRD-46 | generation 1: dropped — Per element instructions, retain only the hydrated Pb(II) hydroxide as the sole solid saturation reference; drop anhydrous PbO polymorphs as out-of-scope. |
| `DEDUP-4926a8b87350673e` | `Pb3O4` | Atlas | generation 1: dropped — Pb3O4 mixed-valence higher Pb oxide out of scope at 25 C in solution. |
| `DEDUP-524a66acd8c6e449` | `Pb2O3` | Atlas | generation 1: dropped — Pb2O3 Pb(III) oxide out of scope redox phase. |
| `DEDUP-f4272ab80a16bf41` | `PbO2` | Atlas | generation 1: dropped — PbO2 Pb(IV) oxide out of scope redox phase. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Prefer SRD-46 Zn2+ over Atlas duplicate per element instructions. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 Zn2+ over Atlas duplicate per element instructions. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Element instructions: keep SRD-46 [Zn(OH)]+ and drop Atlas [ZnOH]+ whose mu disagrees. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Element instructions: keep SRD-46 [Zn(OH)]+ and drop Atlas [ZnOH]+ whose mu disagrees. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — [Zn(OH)2] hydroxo species retained in SRD-46 ladder. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Atlas [HZnO2]- is the same aqueous species as SRD-46 [Zn(OH)3]-; collapse to SRD-46 per element instructions. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Atlas [HZnO2]- is the same aqueous species as SRD-46 [Zn(OH)3]-; collapse to SRD-46 per element instructions. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Collapse Atlas [ZnO2]2- notation into its SRD-46 equivalent [Zn(OH)4]2- as the same species; prefer SRD-46. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Collapse Atlas [ZnO2]2- notation into its SRD-46 equivalent [Zn(OH)4]2- as the same species; prefer SRD-46. |
| `DEDUP-c23350dbb148af67` | `[Zn(EDTA)]2-` | SRD-46 | generation 1: kept — [Zn(EDTA)]2- required EDTA complex. |
| `DEDUP-076ec57a14e420dc` | `[Zn(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — [Zn(EDTA)(OH)]3- mixed-hydroxo EDTA complex retained. |
| `DEDUP-64c3f6e7e7290153` | `[Zn(EDTA)H]-` | SRD-46 | generation 1: kept — [Zn(EDTA)H]- protonated EDTA complex retained. |
| `DEDUP-b128a70c457c8b6a` | `[Zn(EDTA)H2]` | SRD-46 | generation 1: kept — [Zn(EDTA)H2] diprotonated EDTA complex retained. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Zn(s) metal decorative at pH 6-8 in solution per Zn instruction. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: kept — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Keep only thermodynamically stable epsilon-Zn(OH)2 (SRD-46) as the single saturation reference; drop other polymorphs, ZnO entries per case-specific recommendations. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty aqueous reference species, in scope. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- ligand required for speciation. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- dominant near-neutral protonation form. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- protonation state retained. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA neutral protonation state retained. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ protonation state retained for completeness. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ fully protonated form retained. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- protonation state in near-neutral speciation. |

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose fixes this as an aqueous speciation / selectivity problem at fixed pH 6–8, 25 °C, 0.1 m, with no applied potential; redox branches (Pb(III), Pb(IV), elemental metals as competing phases) are decorative and should be pruned, keeping only ground-state M(0) as a formal reference.
- Working regime is 1 mM metal + 5 mM EDTA near neutral pH: EDTA complexes (ML, MHL, M(OH)L) dominate and must all be retained; hydroxo monomers through M(OH)3-/M(OH)4^2- are real; Pb polynuclear hydroxo species (Pb2OH, Pb3(OH)4, Pb4(OH)4, Pb6(OH)8) stay because free Pb2+ in the EDTA-poor fraction can still populate them.
- Spellings [M(OH)n]^(2-n) (SRD-46) and [HMOn]^- / [MOn]^2- (Atlas) denote the same aqueous species; collapse to one copy, preferring SRD-46 for internal consistency with the EDTA set.
- Solids: no evaporation or precipitation question is posed, but one ground-state hydroxide per metal is retained as a saturation ceiling. Collapse Zn(OH)2 polymorphs to the thermodynamically stable form (ε-Zn(OH)2) and drop the rest; keep one Ca(OH)2 and one PbO·H2O-equivalent solid. Anhydrous oxides and higher Pb oxides are not competing phases at 25 °C in solution and are dropped.
- Carbonates are not in the inventory; the near-neutral pot is implicitly CO2-free as given, so no counterion gap to flag.
- Phase question is 'which species forms and at what fraction' — a speciation problem, not a stability-diagram ground-state collapse — so distinct protonation and mixed-ligand EDTA species are kept even if close in μ.
- Treatment differs by element: Pb needs its polynuclear hydroxo set and loses its high-valent branch; Zn needs polymorph collapse; Ca is simple with only one EDTA, one MHL, one hydroxo, one solid.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep one Zn2+ (prefer SRD-46 [Zn]2+, drop Atlas duplicate and the Atlas [ZnOH]+ whose μ disagrees with SRD-46 [Zn(OH)]+), the SRD-46 hydroxo ladder [Zn(OH)]+ / [Zn(OH)2] / [Zn(OH)3]- / [Zn(OH)4]2- (collapse the Atlas notations [HZnO2]- and [ZnO2]2- into their SRD-46 equivalents as the same species), and all four EDTA complexes including the mixed-hydroxo [Zn(EDTA)(OH)]3- and protonated [Zn(EDTA)H]-, [Zn(EDTA)H2]. For solids, keep only the thermodynamically stable ε-Zn(OH)2 (prefer SRD-46 [Zn(OH)2(s,epsilon)]) as the single saturation reference and drop all other polymorphs, both ZnO entries, and Zn(s) metal as decorative at pH 6–8 in solution.

[Group: elements=Zn phase=solid core_label=Zn$+2:1 H:-2 n_species=15]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4462ba0241668c1d` | anhydrous_solid | `ZnO (inactive)` | Atlas | +0 | 54.869 | 1 | — |
| `DEDUP-27b227b4a7aa907e` | anhydrous_solid | `ZnO (active)` | Atlas | +0 | 60.141 | 1 | — |
| `DEDUP-839b79b2ccf7dcaa` | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | +0 | 61.204 | 1 | — |
| `DEDUP-b6df810c336b55af` | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | +0 | 62.501 | 1 | — |
| `DEDUP-5df5a8d267196d7a` | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | +0 | 63.810 | 1 | — |
| `DEDUP-f3c210fa6744ff39` | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | +0 | 64.555 | 1 | — |
| `DEDUP-78ad493537719f09` | anhydrous_solid | `ZnO` | Atlas | +0 | 65.747 | 1 | — |
| `DEDUP-0f363bf6a4df4e64` | anhydrous_solid | `[ZnO](s)` | SRD-46 | +0 | 68.721 | 1 | *** |
| `DEDUP-76fc4312b0e9cf34` | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +0 | 69.805 | 1 | *** |
| `DEDUP-97ad3a88510c90a7` | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | +0 | 69.915 | 1 | — |
| `DEDUP-39e80969c1ece103` | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | +0 | 71.004 | 1 | *** |
| `DEDUP-a9f7e7ba82ac897b` | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | +0 | 71.118 | 1 | *** |
| `DEDUP-659eadbdc714ec67` | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | +0 | 71.346 | 1 | *** |
| `DEDUP-645959ae7d38efba` | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | +0 | 71.632 | 1 | *** |
| `DEDUP-55e0b187c71d3301` | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | +0 | 75.227 | 1 | *** |

## Assistant
<summary>Per element instructions and case recommendations: keep only ε-Zn(OH)2 (SRD-46) as the single saturation reference; drop all other polymorphs and ZnO entries.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept: [Zn(OH)2(s,epsilon)] (SRD-46) as the single saturation ceiling per supervisor instructions; all other polymorphs, ZnO phases, and amorphous forms dropped as decorative.
</answer>
[Orchestration session]
9f15ebbdaecb423faa810e276cb394da

[Calculation purpose]
Evaluate EDTA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.

[Requested tasks]
Model a single pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM together with EDTA at 5 mM, over pH 6 to 8 at 25 C and 0.1 m ionic strength. Report the speciation of each metal, the free [M2+] concentrations, and the fraction of each metal bound by EDTA, so that selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+] can be computed.

[Complete element inventory]
### Element Ca
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b6c302137447026a` | aqueous | aqueous | `Ca$+2:1` | `Ca2+` | Atlas | +0.000 |
| `DEDUP-e299d16ea468bc20` | aqueous | aqueous | `Ca$+2:1` | `[Ca]2+` | SRD-46 | +0.000 |
| `DEDUP-e839c527d55bf1cb` | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +74.428 |
| `DEDUP-faedbd84bcd76b54` | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | SRD-46 | +58.618 |
| `DEDUP-0a589b4ad87d054e` | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | SRD-46 | +40.924 |
| `DEDUP-490b8a5a371510a8` | solid | anhydrous_solid | `Ca$+2:1 H:-2` | `CaO` | Atlas | +186.062 |
| `DEDUP-fa87b80c5829b549` | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +429.111 |
| `DEDUP-670205cb5c260f22` | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +553.041 |
| `DEDUP-24fbc9dcfcd8e007` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `Ca(OH)2` | Atlas | +130.666 |
| `DEDUP-b89dc7ad7b6d082d` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 | +130.192 |

### Element Pb
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-ae70ee8833ae7e04` | aqueous | aqueous | `Pb$+2:1` | `Pb2+` | Atlas | +0.000 |
| `DEDUP-7626e2d7e3d9fd08` | aqueous | aqueous | `Pb$+2:1` | `[Pb]2+` | SRD-46 | +0.000 |
| `DEDUP-8b4310dd2b02884d` | aqueous | aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+` | SRD-46 | +45.661 |
| `DEDUP-5a5e1aca7183b7ba` | aqueous | aqueous | `Pb$+2:1 H:-1` | `[Pb4(OH)4]4+` | SRD-46 | +117.008 |
| `DEDUP-63e4b317197bcadd` | aqueous | aqueous | `Pb$+2:1 H:-2` | `[Pb(OH)2]` | SRD-46 | +97.602 |
| `DEDUP-2f94e031967bfc02` | aqueous | aqueous | `Pb$+2:1 H:-3` | `[HPbO2]-` | Atlas | +159.787 |
| `DEDUP-5967796de560f31a` | aqueous | aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-8bd2a77f29a12f4d` | aqueous | aqueous | `Pb$+2:1 L1:1` | `[Pb(EDTA)]2-` | SRD-46 | +16.666 |
| `DEDUP-857dcee7b14181ba` | aqueous | aqueous | `Pb$+2:1 L1:1 H:1` | `[Pb(EDTA)H]-` | SRD-46 | +0.685 |
| `DEDUP-375c7fb931c092d9` | aqueous | aqueous | `Pb$+2:2 H:-1` | `[Pb2(OH)]3+` | SRD-46 | +36.529 |
| `DEDUP-2d64800d2a324a13` | aqueous | aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+` | SRD-46 | +136.414 |
| `DEDUP-e0676f6c4b01323a` | aqueous | aqueous | `Pb$+2:3 H:-4` | `[Pb6(OH)8]4+` | SRD-46 | +248.855 |
| `DEDUP-b85122e7963955f4` | aqueous | aqueous | `Pb$+4:1` | `Pb4+` | Atlas | +326.812 |
| `DEDUP-5e0c15a561382fef` | aqueous | aqueous | `Pb$+4:1 H:-6` | `[PbO3]2-` | Atlas | +458.315 |
| `DEDUP-2c346d3e29958673` | aqueous | aqueous | `Pb$+4:1 H:-8` | `[PbO4]4-` | Atlas | +690.983 |
| `DEDUP-fc3bc3018ed80da1` | solid | anhydrous_solid | `Pb$+2:1 H:-2` | `[PbO(s,red)]` | SRD-46 | +72.488 |
| `DEDUP-9dccc3b71caf065f` | solid | anhydrous_solid | `Pb$+2:1 H:-2` | `[PbO(s,yellow)]` | SRD-46 | +73.629 |
| `DEDUP-4926a8b87350673e` | solid | anhydrous_solid | `Pb$+2:2 Pb$+4:1 H:-8` | `Pb3O4` | Atlas | +406.643 |
| `DEDUP-524a66acd8c6e449` | solid | anhydrous_solid | `Pb$+3:1 H:-3` | `Pb2O3` | Atlas | +348.414 |
| `DEDUP-f4272ab80a16bf41` | solid | anhydrous_solid | `Pb$+4:1 H:-4` | `PbO2` | Atlas | +279.700 |
| `DEDUP-7589f1f3fc8ca586` | solid | elemental_solid | `Pb$+0:1` | `Pb` | Atlas | +24.309 |
| `DEDUP-3b467791d6a07680` | solid | hydrated_solid | `Pb$+2:1 H:-2` | `[(Pb2O((OH))2)0.5](s)` | SRD-46 | +74.771 |

### Element Zn
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 |
| `DEDUP-c23350dbb148af67` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | +25.228 |
| `DEDUP-076ec57a14e420dc` | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | +91.437 |
| `DEDUP-64c3f6e7e7290153` | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | +8.105 |
| `DEDUP-b128a70c457c8b6a` | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +1.256 |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 |

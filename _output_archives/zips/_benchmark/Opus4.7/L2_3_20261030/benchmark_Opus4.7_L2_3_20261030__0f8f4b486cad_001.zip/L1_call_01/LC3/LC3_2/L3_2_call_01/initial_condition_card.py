inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,         "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,      "value": 0.1,    "basis": "known", "note": "0.1 m ionic strength stated by task"},
  {"id": "CaII", "lhs": lambda s: s.total["Ca$+2"],       "value": 1e-3,   "basis": "known", "note": "1 mM Ca(II) from task"},
  {"id": "Ca0",  "lhs": lambda s: s.total["Ca$+0"],       "value": 0.0,    "basis": "known", "note": "redox excluded; no Ca(0)"},
  {"id": "PbII", "lhs": lambda s: s.total["Pb$+2"],       "value": 1e-3,   "basis": "known", "note": "1 mM Pb(II) from task"},
  {"id": "Pb0",  "lhs": lambda s: s.total["Pb$+0"],       "value": 0.0,    "basis": "known", "note": "redox excluded; no Pb(0)"},
  {"id": "Pb3",  "lhs": lambda s: s.total["Pb$+3"],       "value": 0.0,    "basis": "known", "note": "redox excluded; no Pb(III)"},
  {"id": "Pb4",  "lhs": lambda s: s.total["Pb$+4"],       "value": 0.0,    "basis": "known", "note": "redox excluded; no Pb(IV)"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"],       "value": 1e-3,   "basis": "known", "note": "1 mM Zn(II) from task"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"],       "value": 0.0,    "basis": "known", "note": "redox excluded; no Zn(0)"},
  {"id": "L",    "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3,   "basis": "known", "note": "5 mM EDTA from task"},
]
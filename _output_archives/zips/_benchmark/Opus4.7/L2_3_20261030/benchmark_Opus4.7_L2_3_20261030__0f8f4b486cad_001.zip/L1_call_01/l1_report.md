## Doability
Doable. Three metals + EDTA, pH 6–8, 25 °C, I = 0.1 M, 1-D `pH_sweep` — a direct speciation question matched to the pipeline.

## Result
Single pot: [Ca2+]_T = [Pb2+]_T = [Zn2+]_T = 1.00 mM, [EDTA]_T = 5.00 mM, 25 °C, I ≈ 0.1 M (calculated 0.014–0.015 M; totals are low and the ionic-strength model is held fixed), pH 6.0–8.0, 21 grid points, redox excluded. Convergence 21/21 on every component. No solid is predicted (saturation columns for Ca(OH)2, Pb-hydroxide, and Zn(OH)2(ε) are all at the floor of −50 across the whole scan). EDTA is in 1.67-fold molar excess over total metal, so each metal has enough ligand to form its 1:1 chelate.

## Analysis
At every pH from 6 to 8 the dominant species of all three metals is the simple [M(EDTA)]2- chelate. Fraction tables (metal basis):

| pH | [Ca(EDTA)]2- | [Pb(EDTA)]2- | [Zn(EDTA)]2- |
|----|-------------:|-------------:|-------------:|
| 6.0 | 0.9979 | 0.9998 | 0.9996 |
| 7.0 | 0.9998 | 1.0000 | 0.9999 |
| 8.0 | 1.0000 | 1.0000 | 0.9989 |

Protonated chelates ([M(EDTA)H]-, [Zn(EDTA)H2]) and [Zn(EDTA)(OH)]3- are all ≤ 10^-3 of the metal; free M2+ is many orders of magnitude smaller. The small residual decline of Zn(EDTA)2- at pH 8 is the onset of [Zn(EDTA)(OH)]3- (1.1×10^-3 of Zn), not hydrolysis of free Zn2+.

Free aquo-ion concentrations (log10 [M2+], M) from the log-concentration table:

| pH | log[Ca2+] | log[Pb2+] | log[Zn2+] | free[Zn2+]/free[Pb2+] | free[Ca2+]/free[Pb2+] |
|----|---------:|---------:|---------:|-----------------------:|-----------------------:|
| 6.0 | −5.78 | −13.12 | −11.62 | 3.2 × 10^1 | 2.2 × 10^7 |
| 7.0 | −6.89 | −14.24 | −12.74 | 3.2 × 10^1 | 2.2 × 10^7 |
| 8.0 | −7.88 | −15.23 | −13.73 | 3.2 × 10^1 | 2.2 × 10^7 |

So free [Pb2+] is ~10^-13 to 10^-15 M, free [Zn2+] ~30× higher, and free [Ca2+] ~10^7 × higher. Both ratios are essentially pH-independent across 6–8 because each metal is quantitatively bound; the ratio of free M2+ then collapses to the ratio of 1/K_f for the 1:1 chelates. From the reference-constants table (card log β, 1:1 ML): log β(PbL) = 18.00, log β(ZnL) = 16.50, log β(CaL) = 10.65, giving ΔlogK(Zn−Pb) = −1.50 → 10^1.5 ≈ 32 and ΔlogK(Ca−Pb) = −7.35 → 10^7.35 ≈ 2.2×10^7. The numeric sweep reproduces these differences exactly, confirming the selectivity is driven by thermodynamic stability of the chelate and not by competing hydrolysis in this window.

Chemically: EDTA is a six-donor polyaminocarboxylate; Pb2+ (soft, large, high charge density on N-donors) binds most strongly, Zn2+ (borderline) somewhat less, and Ca2+ (hard, essentially N-indifferent, binding mainly through carboxylates) by far the weakest. Because the metal-dependent protonation/hydrolysis side-reactions of PbL, ZnL and CaL are all minor in pH 6–8, the "effective" (conditional) selectivity equals the ratio of raw log β's. The 1.67-fold ligand excess guarantees that even the weakest binder (Ca) finds free EDTA — the three metals together consume 3 mM out of 5 mM, leaving ~2 mM distributed as HEDTA3- (dominant free-ligand form, peak 39% of total L at pH 7.4) and H2EDTA2-.

Practical implication for Pb removal: in a near-neutral pot with excess EDTA, Pb is sequestered to ~10^-14 M free Pb2+, i.e. essentially complete removal from the aqueous aquo pool. However, EDTA is **not** selective for Pb over Zn — Zn2+ is also driven to ~10^-13 M free. The 32× free-ion advantage for Pb is only a factor of 30, not the ≥10^3 one would need for separation. Only Ca is clearly discriminated against (10^7-fold more free Ca2+ left in solution), but even Ca is >99.8% bound because of the 5× ligand excess; to leave Ca free, one must sub-stoichiometrically dose EDTA (≤ sum of Pb+Zn). EDTA at this stoichiometry is a non-selective Pb+Zn chelator with mild rejection of Ca.

## Artifacts
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_log_conc.csv
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Free [M2+] values at pH 6
  - 7
  - 8 match log_conc.csv to the reported digits; selectivity ratios 32× and 2.2e7 reproduce 10^Δ(log β). Envelope fractions of [M(EDTA)]2- match envelope_Ca/Pb/Zn files. HEDTA3- ~39% at pH 7.4 consistent (log −2.71 vs total 5 mM). No solid predicted (saturation floor −50 across scan).

[Purpose: Evaluate EDTA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.]
[Tasks:
Model a single pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM together with EDTA at 5 mM, over pH 6 to 8 at 25 C and 0.1 m ionic strength. Report the speciation of each metal, the free [M2+] concentrations, and the fraction of each metal bound by EDTA, so that selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+] can be computed.
]
[Pair: pair_key=`m125_l6277`, metal_id=125, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m125_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand6277_beta812_net5069` | `[M] + [L] <=> [ML]` | vlm_108762@(25.0,0.1) = K+18.000 | 1 | +18.000 / +18.000 / +18.000 / +18.000 | vlm_108762@(25.0,0.1) = K+18.000 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal125_ligand6277_beta788_net5069` | `[ML] + [H] <=> [MHL]` | vlm_108765@(20.0,0.1) = K+2.800 | 3 | +2.400 / +2.800 / +2.667 / +2.800 | vlm_108765@(20.0,0.1) = K+2.800 (-5.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Free Energy Analysis Card

**System**: metal_125 + ligand_6277
**Metals**: [Pb]2+
**Ligands**: [EDTA]
**Generated**: 2026-10-31 02:57:48 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Pb$+2 | Metal component: [Pb]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [EDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Pb$+2 | [Pb]2+ | +2 | Not defined | NIST SRD-46 | metal_125 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [EDTA] | -4 | Not defined | [[H]4[L1]] | NIST SRD-46 | ligand_6277 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Pb | Pb$+2 | [Pb]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, 3, 3, 3, 3] | true |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Pb$+2 | [Pb]2+ | metal | [Pb]2+(aq) | +0.0000 | R1 | Pb | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [EDTA] | ligand_canonical | [[H]4[L1]] | +0.0000 | R4 | *** | -4 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [EDTA] | [L1] -> [[H]4[L1]] | 4 | 4 | +20.9200 | +119.4049 | exact | vlm_108233_patched, vlm_108257, vlm_108274, vlm_108284 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Pb]2+ + [EDTA] | 20.0~25.0 | 0.1 | 5069 | 2 |
| [H]+ + [EDTA] | 25.0 | 1 | 4906 | 6 |
| [Pb]2+ + [OH]- | 25.0 | 0~0.5 | 27520, 27522 | 16 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [EDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]5[L1]].[z+1] | [H5EDTA]+ | +1 | aqueous | +22.3200 | -127.3957 | -7.9908 | -7.9908 | [[H]5[L1]]:+1 | vlm_108233_patched, vlm_108257, vlm_108274, vlm_108284, vlm_108291 | true | *** |
| [[H]6[L1]].[z+2] | [H6EDTA]2+ | +2 | aqueous | +22.3200 | -127.3957 | -7.9908 | -7.9908 | [[H]6[L1]]:+1 | vlm_108233_patched, vlm_108257, vlm_108274, vlm_108284, vlm_108291, vlm_108295 | true | *** |
| [[H]4[L1]].[z+0] | [H4EDTA] | +0 | aqueous | +20.9200 | -119.4049 | +0.0000 | +0.0000 | [[H]4[L1]]:+1 | vlm_108233_patched, vlm_108257, vlm_108274, vlm_108284 | true | *** |
| [[H]3[L1]].[z-1] | [H3EDTA]- | -1 | aqueous | +18.9000 | -107.8754 | +11.5295 | +11.5295 | [[H]3[L1]]:+1 | vlm_108233_patched, vlm_108257, vlm_108274 | true | *** |
| [[H]2[L1]].[z-2] | [H2EDTA]2- | -2 | aqueous | +16.3800 | -93.4920 | +25.9129 | +25.9129 | [[H]2[L1]]:+1 | vlm_108233_patched, vlm_108257 | true | *** |
| [[H][L1]].[z-3] | [HEDTA]3- | -3 | aqueous | +10.1900 | -58.1614 | +61.2435 | +61.2435 | [[H][L1]]:+1 | vlm_108233_patched | true | *** |
| [L1].[z-4] | [EDTA] | -4 | aqueous | +0.0000 | -0.0000 | +119.4049 | +119.4049 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Pb]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Pb$+2].[z+2] | [Pb]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pb$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Pb]2+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Pb$+2].[[H][L1]].[z-1] | [Pb(EDTA)H]- | -1 | aqueous | +20.8000 | -118.7200 | +0.6849 | +0.6849 | [Pb$+2]:+1, [[H][L1]]:+1 | vlm_108762, vlm_108765 | true | *** |
| [Pb$+2].[L1].[z-2] | [Pb(EDTA)]2- | -2 | aqueous | +18.0000 | -102.7385 | +16.6665 | +16.6665 | [Pb$+2]:+1, [L1]:+1 | vlm_108762 | true | *** |

#### [Pb]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Pb$+2]2.[OH].[z+3] | [Pb2(OH)]3+ | +3 | aqueous | -6.4000 | +36.5292 | +36.5292 | +36.5292 | [Pb$+2]:+2, [OH]:+1 | vlm_171081 | true | *** |
| [Pb$+2].[OH].[z+1] | [Pb(OH)]+ | +1 | aqueous | -8.0000 | +45.6615 | +45.6615 | +45.6615 | [Pb$+2]:+1, [OH]:+1 | vlm_171068 | true | *** |
| [Pb$+2].[OH]2.[z+0] | [Pb(OH)2] | +0 | aqueous | -17.1000 | +97.6015 | +97.6015 | +97.6015 | [Pb$+2]:+1, [OH]:+2 | vlm_171075 | true | *** |
| [Pb$+2]4.[OH]4.[z+4] | [Pb4(OH)4]4+ | +4 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [Pb$+2]:+4, [OH]:+4 | vlm_171087 | true | *** |
| [Pb$+2]3.[OH]4.[z+2] | [Pb3(OH)4]2+ | +2 | aqueous | -23.9000 | +136.4138 | +136.4138 | +136.4138 | [Pb$+2]:+3, [OH]:+4 | vlm_171084 | true | *** |
| [Pb$+2].[OH]3.[z-1] | [Pb(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [Pb$+2]:+1, [OH]:+3 | vlm_171079 | true | *** |
| [Pb$+2]6.[OH]8.[z+4] | [Pb6(OH)8]4+ | +4 | aqueous | -43.6000 | +248.8554 | +248.8554 | +248.8554 | [Pb$+2]:+6, [OH]:+8 | vlm_171096 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Pb]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Pb$+2].[OH]2.[z+0(s)[1]] | [PbO(s,red)] | +0 | dissolution | -12.7000 | +72.4877 | +72.4877 | +72.4877 | [Pb$+2]:+1, [H]:-2 | vlm_171101 | true | *** |
| [Pb$+2].[OH]2.[z+0(s)[2]] | [PbO(s,yellow)] | +0 | dissolution | -12.9000 | +73.6292 | +73.6292 | +73.6292 | [Pb$+2]:+1, [H]:-2 | vlm_171100 | true | *** |
| [Pb$+2].[OH]2.[z+0(s)[3]] | [(Pb2O((OH))2)0.5](s) | +0 | dissolution | -13.1000 | +74.7708 | +74.7708 | +74.7708 | [Pb$+2]:+1, [H]:-2 | vlm_171099 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 24 |
| Included in calculation | 24 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 18 |
| Unresolved (no species in card) | 6 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_108762 | [<EDTA>] + [<Pb2+>] <=> [<Pb2+><EDTA>] | +18.0000 | 25.0 | 0.100 | yes | [Pb(EDTA)]2-, [Pb(EDTA)H]- |
| 2 | vlm_108765 | [<H+>] + [<Pb2+><EDTA>] <=> [<Pb2+><H+><EDTA>] | +2.8000 | 20.0 | 0.100 | yes | [Pb(EDTA)H]- |
| 3 | vlm_108257 | [<H+><EDTA>] + [<H+>] <=> [<H+>2<EDTA>] | +6.1900 | 25.0 | 1.000 | yes | [H2EDTA]2-, [H3EDTA]-, [H4EDTA], [H5EDTA]+, [H6EDTA]2+ |
| 4 | vlm_108291 | [<H+>4<EDTA>] + [<H+>] <=> [<H+>5<EDTA>] | +1.4000 | 25.0 | 1.000 | yes | [H5EDTA]+, [H6EDTA]2+ |
| 5 | vlm_108295 | [<H+>5<EDTA>] + [<H+>] <=> [<H+>6<EDTA>] | +0.0000 | 25.0 | 1.000 | yes | [H6EDTA]2+ |
| 6 | vlm_108233_patched | [<H+>] + [<EDTA>] <=> [<H+><EDTA>] | +10.1900 | 25.0 | 1.000 | yes | [HEDTA]3-, [H2EDTA]2-, [H3EDTA]-, [H4EDTA], [H5EDTA]+, [H6EDTA]2+ |
| 7 | vlm_108274 | [<H+>2<EDTA>] + [<H+>] <=> [<H+>3<EDTA>] | +2.5200 | 25.0 | 1.000 | yes | [H3EDTA]-, [H4EDTA], [H5EDTA]+, [H6EDTA]2+ |
| 8 | vlm_108284 | [<H+>3<EDTA>] + [<H+>] <=> [<H+>4<EDTA>] | +2.0200 | 25.0 | 1.000 | yes | [H4EDTA], [H5EDTA]+, [H6EDTA]2+ |
| 9 | vlm_171075 | [<OH->]^2 + [<Pb2+>] <=> [<Pb2+><OH->2] | +10.9000 | 25.0 | 0.000 | yes | [Pb(OH)2] |
| 10 | vlm_171079 | [<OH->]^3 + [<Pb2+>] <=> [<Pb2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Pb(OH)3]- |
| 11 | vlm_171081 | [<OH->] + [<Pb2+>]^2 <=> [<Pb2+>2<OH->] | +7.6000 | 25.0 | 0.000 | yes | [Pb2(OH)]3+ |
| 12 | vlm_171084 | [<OH->]^4 + [<Pb2+>]^3 <=> [<Pb2+>3<OH->4] | +32.1000 | 25.0 | 0.000 | yes | [Pb3(OH)4]2+ |
| 13 | vlm_171087 | [<OH->]^4 + [<Pb2+>]^4 <=> [<Pb2+>4<OH->4] | +35.5000 | 25.0 | 0.100 | yes | [Pb4(OH)4]4+ |
| 14 | vlm_171096 | [<OH->]^8 + [<Pb2+>]^6 <=> [<Pb2+>6<OH->8] | +68.4000 | 25.0 | 0.000 | yes | [Pb6(OH)8]4+ |
| 15 | vlm_171068 | [<OH->] + [<Pb2+>] <=> [<Pb2+><OH->] | +6.0000 | 25.0 | 0.100 | yes | [Pb(OH)]+ |
| 16 | vlm_171073 | [<OH->]^2 + [<Pb2+>] <=> [<Pb2+><OH->2] | +10.3000 | 25.0 | 0.500 | yes | — |
| 17 | vlm_171076 | [<OH->]^3 + [<Pb2+>] <=> [<Pb2+><OH->3] | +13.3000 | 25.0 | 0.500 | yes | — |
| 18 | vlm_171082 | [<OH->]^4 + [<Pb2+>]^3 <=> [<Pb2+>3<OH->4] | +31.7000 | 25.0 | 0.500 | yes | — |
| 19 | vlm_171088 | [<OH->]^4 + [<Pb2+>]^4 <=> [<Pb2+>4<OH->4] | +35.2000 | 25.0 | 0.500 | yes | — |
| 20 | vlm_171094 | [<OH->]^8 + [<Pb2+>]^6 <=> [<Pb2+>6<OH->8] | +67.4000 | 25.0 | 0.500 | yes | — |
| 21 | vlm_171069 | [<OH->] + [<Pb2+>] <=> [<Pb2+><OH->] | +6.0000 | 25.0 | 0.500 | yes | — |
| 22 | vlm_171100 | [H2O] + [<Pb2+>O(s,yellow)] <=> [<Pb2+>] + [<OH->]^2 | -15.1000 | 25.0 | 0.000 | yes | [PbO(s,yellow)] |
| 23 | vlm_171099 | [(<Pb2+>2O(<OH->)2)0.5(s)] + [H2O]^0.5 <=> [<Pb2+>] + [<OH->]^2 | -14.9000 | 25.0 | 0.000 | yes | [(Pb2O((OH))2)0.5](s) |
| 24 | vlm_171101 | [H2O] + [<Pb2+>O(s,red)] <=> [<Pb2+>] + [<OH->]^2 | -15.3000 | 25.0 | 0.000 | yes | [PbO(s,red)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

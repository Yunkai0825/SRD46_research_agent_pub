[Purpose: Evaluate EDTA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.]
[Tasks:
Model a single pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM together with EDTA at 5 mM, over pH 6 to 8 at 25 C and 0.1 m ionic strength. Report the speciation of each metal, the free [M2+] concentrations, and the fraction of each metal bound by EDTA, so that selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+] can be computed.
]
[Pair: pair_key=`m125_l10076`, metal_id=125, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal125_ligand10076_beta840_net27520`
  - `metal125_ligand10076_beta872_net27520`
  - `metal125_ligand10076_beta502_net27520`
  - `metal125_ligand10076_beta649_net27520`
  - `metal125_ligand10076_beta349_net27520`
  - `metal125_ligand10076_beta706_net27520`
  - `metal125_ligand10076_beta328_net27520`
  - `metal125_ligand10076_beta348_net27520`
[Screen report]
# Eq-map screen — m125_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **10** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand10076_beta840_net27520` | `[M] + [L]^2 <=> [ML2]` | vlm_171075@(25.0,0.0) = K+10.900 | 3 | +10.300 / +10.900 / +10.700 / +10.900 | vlm_171075@(25.0,0.0) = K+10.900 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal125_ligand10076_beta872_net27520` | `[M] + [L]^3 <=> [ML3]` | vlm_171079@(25.0,0.0) = K+13.900 | 4 | +13.300 / +13.800 / +13.750 / +14.100 | vlm_171079@(25.0,0.0) = K+13.900 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 3 | `metal125_ligand10076_beta502_net27520` | `[M]^2 + [L] <=> [M2L]` | vlm_171081@(25.0,0.0) = K+7.600 | 2 | +7.600 / +7.700 / +7.700 / +7.800 | vlm_171081@(25.0,0.0) = K+7.600 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal125_ligand10076_beta649_net27520` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_171084@(25.0,0.0) = K+32.100 | 3 | +31.700 / +32.100 / +32.600 / +34.000 | vlm_171084@(25.0,0.0) = K+32.100 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal125_ligand10076_beta674_net27520` | `[M]^4 + [L]^4 <=> [M4L4]` | vlm_171087@(25.0,0.1) = K+35.500 | 5 | +35.200 / +36.000 / +36.140 / +37.500 | vlm_171087@(25.0,0.1) = K+35.500 (+0.00 °C, +0.00 M) | `—` |
| 6 | `metal125_ligand10076_beta349_net27520` | `[MO(s,yellow)] + [H2O] <=> [M] + [OH]^2` | vlm_171100@(25.0,0.0) = K-15.100 | 1 | -15.100 / -15.100 / -15.100 / -15.100 | vlm_171100@(25.0,0.0) = K-15.100 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 7 | `metal125_ligand10076_beta706_net27520` | `[M]^6 + [L]^8 <=> [M6L8]` | vlm_171096@(25.0,0.0) = K+68.400 | 3 | +67.400 / +68.400 / +69.033 / +71.300 | vlm_171096@(25.0,0.0) = K+68.400 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 8 | `metal125_ligand10076_beta328_net27520` | `[(M2O(OH)2)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]^2` | vlm_171099@(25.0,0.0) = K-14.900 | 1 | -14.900 / -14.900 / -14.900 / -14.900 | vlm_171099@(25.0,0.0) = K-14.900 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 9 | `metal125_ligand10076_beta812_net27520` | `[M] + [L] <=> [ML]` | vlm_171068@(25.0,0.1) = K+6.000 | 5 | +6.000 / +6.000 / +6.140 / +6.400 | vlm_171068@(25.0,0.1) = K+6.000 (+0.00 °C, +0.00 M) | `—` |
| 10 | `metal125_ligand10076_beta348_net27520` | `[MO(s,red)] + [H2O] <=> [M] + [OH]^2` | vlm_171101@(25.0,0.0) = K-15.300 | 1 | -15.300 / -15.300 / -15.300 / -15.300 | vlm_171101@(25.0,0.0) = K-15.300 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Evaluate EDTA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a share | Model a single pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM together w | 4768 | 992.9 |
| 2 | 2 | dispatch_l1_pipeline | Evaluate DTPA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a share | Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with DTPA (diet | 4857 | 621.8 |
| 3 | 2 | dispatch_l1_pipeline | Evaluate D-penicillamine selectivity for Pb(II) removal versus Zn(II) and Ca(II) | Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with D-penicill | 3392 | 63.3 |
| 4 | 3 | inspect_batch_result |  |  | 4882 | 0.0 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Evaluate EDTA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.",
  "tasks": "Model a single pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM together with EDTA at 5 mM, over pH 6 to 8 at 25 C and 0.1 m ionic strength. Report the speciation of each metal, the free [M2+] concentrations, and the fraction of each metal bound by EDTA, so that selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+] can be computed."
}
```

### Reasoning excerpt
```
<reasoning>
The user wants a chelator recommendation for Pb(II) over Zn(II) and Ca(II). I need to survey SRD-46 ligands with data for all three metals, then run speciation on top candidates.

Let me start by thinking about classic chelators with data for Pb, Zn, Ca:
- EDTA - all three, but not very selective
- DTPA - all three
- NTA - all three
- Citrate - all three
- Penicillamine - good for soft metals like Pb
- Dimercaptosuccinate (DMSA/succimer) - clinical Pb chelator
- EGTA - selective for Ca over others actually

For Pb selectivity, soft/intermediate donors (S, N) favor Pb over hard Ca. DMSA (meso-2,3-dimercaptosuccinic acid) is the clinical Pb chelator. D-penicillamine also used. EDTA (CaNa2EDTA) is used clinically.

Let me dispatch L1 calls for top candidates. I'll pick 3: EDTA, DTPA, and DMSA/penicillamine. Actually, let me first check which are in SRD-46.

Let me run speciation for three candidate systems in parallel: EDTA, DTPA, and penicillamine (or DMSA). Each as a separate pot containing all three metals + the ligand, so we see competition.

Actually the user wants to survey ligands first, then speciation on top 2-3. Let me just dispatch 2-3 parallel calls directly for strong candidates. I'll do EDTA, DTPA, and penicillamine.
</reasoning>

<summary>
Dispatching three parallel speciation calculations for candidate Pb(II)-selective chelators (EDTA, DTPA, penicillamine) each with all three metals (Pb, Zn, Ca at 1 mM) and ligand at 5 mM over pH 6-8, I=0.1. Will comp
```

### Result (4768 chars)
```
## Doability
Doable. Three metals + EDTA, pH 6–8, 25 °C, I = 0.1 M, 1-D `pH_sweep` — a direct speciation question matched to the pipeline.

## Result
Single pot: [Ca2+]_T = [Pb2+]_T = [Zn2+]_T = 1.00 mM, [EDTA]_T = 5.00 mM, 25 °C, I ≈ 0.1 M (calculated 0.014–0.015 M; totals are low and the ionic-strength model is held fixed), pH 6.0–8.0, 21 grid points, redox excluded. Convergence 21/21 on every component. No solid is predicted (saturation columns for Ca(OH)2, Pb-hydroxide, and Zn(OH)2(ε) are all at the floor of −50 across the whole scan). EDTA is in 1.67-fold molar excess over total metal, so each metal has enough ligand to form its 1:1 chelate.

## Analysis
At every pH from 6 to 8 the dominant species of all three metals is the simple [M(EDTA)]2- chelate. Fraction tables (metal basis):

| pH | [Ca(EDTA)]2- | [Pb(EDTA)]2- | [Zn(EDTA)]2- |
|----|-------------:|-------------:|-------------:|
| 6.0 | 0.9979 | 0.9998 | 0.9996 |
| 7.0 | 0.9998 | 1.0000 | 0.9999 |
| 8.0 | 1.0000 | 1.0000 | 0.9989 |

Protonated chelates ([M(EDTA)H]-, [Zn(EDTA)H2]) and [Zn(EDTA)(OH)]3- are all ≤ 10^-3 of the metal; free M2+ is many orders of magnitude smaller. The small residual decline of Zn(EDTA)2- at pH 8 is the onset of [Zn(EDTA)(OH)]3- (1.1×10^-3 of Zn), not hydrolysis of free Zn2+.

Free aquo-ion concentrations (log10 [M2+], M) from the log-concentration table:

| pH | log[Ca2+] | log[Pb2+] | log[Zn2+] | free[Zn2+]/free[Pb2+] | free[Ca2+]/free[Pb2+] |
|----|---------:|---------:|---------:|-----------------------:|-----------------------:|
| 6.0 | −5.78 | −13.12 | −11.62 | 3.2 × 10^1 | 2.2 × 10^7 |
| 7.0 | −6.89 | −14.24 | −12.74 | 3.2 × 10^1 | 2.2 × 10^7 |
| 8.0 | −7.88 | −15.23 | −13.73 | 3.2 × 10^1 | 2.2 × 10^7 |

So free [Pb2+] is ~10^-13 to 10^-15 M, free [Zn2+] ~30× higher, and free [Ca2+] ~10^7 × higher. Both ratios are essentially pH-independent across 6–8 because each metal is quantitatively bound; the ratio of free M2+ then collapses to the ratio of 1/K_f for the 1:1 chelates. From the reference-constants table (card log β, 1:1 ML): log β(PbL) = 18.00, log β(ZnL) = 16.50, log β(CaL) = 10.65, giving ΔlogK(Zn−Pb) = −1.50 → 10^1.5 ≈ 32 and ΔlogK(Ca−Pb) = −7.35 → 10^7.35 ≈ 2.2×10^7. The numeric sweep reproduces these differences exactly, confirming the selectivity is driven by thermodynamic stability of the chelate and not by competing hydrolysis in this window.

Chemically: EDTA is a six-donor polyaminocarboxylate; Pb2+ (soft, large, high charge density on N-donors) binds most strongly, Zn2+ (borderline) somewhat less, and Ca2+ (hard, essentially N-indifferent, binding mainly through carboxylates) by far the weakest. Because the metal-dependent protonation/hydrolysis side-reactions of PbL, ZnL and CaL are all minor in pH 6–8, the "effective" (conditional) selectivity equals the ratio of raw log β's. The 1.67-fold ligand excess guarantees that even the weakest binder (Ca) finds free EDTA — the three metals together consume 3 mM out of 5 mM, leaving ~2 mM distributed as HEDTA3- (dominant free-ligand form, peak 39% of total L at pH 7.4) and H2EDTA2-.

Practical implication for Pb removal: in a near-neutral pot with excess EDTA, Pb is sequestered to ~10^-14 M free Pb2+, i.e. essentially complete removal from the aqueous aquo pool. However, EDTA is **not** selective for Pb over Zn — Zn2+ is also driven to ~10^-13 M free. The 32× free-ion advantage for Pb is only a factor of 30, not the ≥10^3 one would need for separation. Only Ca is clearly discriminated against (10^7-fold more free Ca2+ left in solution), but even Ca is >99.8% bound because of the 5× ligand excess; to leave Ca free, one must sub-stoichiometrically dose EDTA (≤ sum of Pb+Zn). EDTA at this stoichiometry is a non-selective Pb+Zn chelator with mild rejection of Ca.

## Artifacts
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_log_conc.csv
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv
L1_call_01/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Free [M2+] values at pH 6
  - 7
  - 8 match log_conc.csv to the reported digits; selectivity ratios 32× and 2.2e7 reproduce 10^Δ(log β). Envelope fractions of [M(EDTA)]2- match envelope_Ca/Pb/Zn files. HEDTA3- ~39% at pH 7.4 consistent (log −2.71 vs total 5 mM). No solid predicted (saturation floor −50 across scan).

```


## Tool call 2 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Evaluate DTPA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.",
  "tasks": "Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with DTPA (diethylenetriaminepentaacetic acid) at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 M. Report dominant species of each metal, free aqueous [M2+] vs pH, and the free-ion selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+]. No redox."
}
```

### Reasoning excerpt
```
<summary>EDTA call completed and validated. Now dispatching DTPA and D-penicillamine as the other top candidate chelators for Pb(II) selectivity vs Zn(II) and Ca(II). DTPA is known to have higher Pb stability than EDTA; penicillamine is a soft S-donor expected to favor Pb/Zn over Ca.</summary>
```

### Result (4857 chars)
```
## Doability
Doable. SRD-46 provides DTPA protonation and 1:1 M–DTPA complexes for Ca(II), Pb(II), and Zn(II) at 25 °C, I=0.1 M; a 1-D pH sweep over 6–8 at fixed non-redox totals is exactly the pH_sweep method's scope.

## Result
- System: 1.00 mM Pb(II) + 1.00 mM Zn(II) + 1.00 mM Ca(II) + 5.00 mM DTPA (ligand excess ≈1.67×).
- Method: pH_sweep, 21 points pH 6.0–8.0, T = 25.0 °C, I-target = 0.1 M (calculated I = 0.022–0.029 M, lower than target because DTPA complexes replace free ions), redox excluded.
- Convergence: 21/21 points converged for every component. No solid formed over the window ([Ca(OH)₂], PbO(red), Zn(OH)₂(α) all 0 mol/L).

## Analysis
**Dominant metal species (all pH 6–8).** Every metal is sequestered as the fully deprotonated 1:1 chelate [M(DTPA)]³⁻. The verdict shows [Pb(DTPA)]³⁻ reaching 100.0 % of Pb at pH 8 and [Ca(DTPA)]³⁻ 99.7 %, [Zn(DTPA)]³⁻ 99.9 %. At pH 6 the protonated chelates [M(DTPA)H]²⁻ carry a residual share (Ca 22 %, Zn 8 %, Pb much less) because HDTPA⁴⁻ is still a minor DTPA form (card log β for [M(DTPA)H]²⁻ via H+HDTPA⁴⁻+M²⁺: Ca 16.86, Pb 23.32, Zn 23.80). As pH rises past the HDTPA⁴⁻/DTPA⁵⁻ regime (DTPA ladder dominance flips H₂DTPA³⁻ → HDTPA⁴⁻ between pH 7.5 and 7.6), the protonated chelate relaxes into [M(DTPA)]³⁻ (log β: Ca 10.75, Pb 18.80, Zn 18.20). No hydrolysis species (e.g. [Pb(OH)]⁺, [Pb₄(OH)₄]⁴⁺, [Zn(OH)]⁺) exceed 10⁻¹³ M — DTPA fully outcompetes hydroxide, so no PbO or Zn(OH)₂ precipitates despite the near-neutral pH where free Pb(II) and Zn(II) would otherwise be nearing saturation.

**Free aqueous [M²⁺] vs pH** (from the concentrations CSV; mol/L):

| pH | free [Ca²⁺] | free [Pb²⁺] | free [Zn²⁺] |
|---:|---:|---:|---:|
| 6.0 | 2.24e-05 | 2.62e-13 | 9.64e-13 |
| 6.5 | 2.89e-06 | 2.81e-14 | 1.09e-13 |
| 7.0 | 3.64e-07 | 3.33e-15 | 1.32e-14 |
| 7.5 | 5.59e-08 | 5.03e-16 | 2.00e-15 |
| 8.0 | 1.24e-08 | 1.11e-16 | 4.40e-16 |

Every free [M²⁺] falls ~3 orders of magnitude from pH 6 to 8 because the controlling equilibrium M²⁺ + HDTPA⁴⁻ ⇌ [M(DTPA)]³⁻ + H⁺ is driven forward by consuming H⁺; equivalently, as HDTPA⁴⁻ and DTPA⁵⁻ grow with pH, the apparent conditional formation constant of [M(DTPA)]³⁻ rises in near-proportion.

**Free-ion selectivity ratios** (dimensionless):

| pH | free[Zn²⁺]/free[Pb²⁺] | free[Ca²⁺]/free[Pb²⁺] |
|---:|---:|---:|
| 6.0 | 3.7 | 8.5e+07 |
| 6.5 | 3.9 | 1.03e+08 |
| 7.0 | 4.0 | 1.09e+08 |
| 7.5 | 4.0 | 1.11e+08 |
| 8.0 | 4.0 | 1.12e+08 |

**Interpretation.**
- *Pb vs Zn is essentially a wash.* The ratio free[Zn²⁺]/free[Pb²⁺] ≈ 4 across pH 6–8 reflects the small log β difference for the 1:1 chelates (Pb 18.80 vs Zn 18.20 → ΔlogK = 0.60, so free[Zn²⁺]/free[Pb²⁺] = 10^0.60 ≈ 4). DTPA cannot kinetically or thermodynamically distinguish Pb(II) from Zn(II) under these conditions; both are >99.99 % bound. If the goal is Pb removal from a Zn-containing matrix with excess DTPA, Zn will be co-sequestered to the same extent — DTPA is not a Pb-selective reagent against Zn.
- *Ca is almost completely out-competed.* The ratio free[Ca²⁺]/free[Pb²⁺] ≈ 10⁸ reflects the 8-log-unit difference in [M(DTPA)]³⁻ log β (Ca 10.75 vs Pb 18.80, Δ = 8.05, 10^8.05 ≈ 1.1e8), modulated slightly at low pH by the Ca protonated-chelate equilibrium. Free Ca²⁺ (10⁻⁵–10⁻⁸ M) is 7–8 orders of magnitude higher than free Pb²⁺ (10⁻¹³–10⁻¹⁶ M), yet because 1 mM Ca only consumes 1 mM DTPA from the 5 mM pool, there is still ample DTPA (≈3 mM) left to fully bind Pb and Zn. In other words, Ca is a "sacrificial" sink for DTPA, not a competitor that releases Pb; selectivity for Pb removal is preserved only because the ligand is in excess.

**Practical implications.**
- DTPA at 5× total-metal stoichiometry fully masks all three divalent metals as [M(DTPA)]³⁻ across pH 6–8 with no risk of PbO or Zn(OH)₂ precipitation.
- For Pb/Zn discrimination, DTPA is unsuitable; a softer donor set (e.g. thiolate ligands) would be required.
- Ca(II) is thermodynamically outcompeted by ≈8 log units, so hard-water Ca background does not threaten Pb sequestration provided the DTPA dose exceeds Σ[M²⁺]; however, each equivalent of Ca does consume one equivalent of DTPA, so dosing must account for Ca load.

## Artifacts
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_verdict.md
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_concentrations.csv
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Pb.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Zn.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Ca.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
```


## Tool call 3 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Evaluate D-penicillamine selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.",
  "tasks": "Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with D-penicillamine at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 M. Report dominant species of each metal, free aqueous [M2+] vs pH, and the free-ion selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+]. No redox."
}
```

### Reasoning excerpt
```

```

### Result (3392 chars)
```
## Doability
Not doable as requested. SRD-46 contains no complexation data for Ca(II) with D-penicillamine, so the three-metal competition brief cannot be represented from the database. LC1 refused to build the card before any solve was attempted.

## Result
- System requested: Pb(II) 1 mM + Zn(II) 1 mM + Ca(II) 1 mM + D-penicillamine 5 mM, pH 6–8, 25 °C, I = 0.1 M, no redox.
- Pipeline stage reached: LC1 (eq-card alignment).
- Deterministic error returned (verbatim): "SRD-46 has no data for the requested metal-ligand system (not in database): metal(s) with no complexation data against any requested ligand: Ca. Missing metal x ligand pairs: Ca x Penicillamine. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card. Report the missing data — do not substitute a different system or estimate constants."
- Elapsed: 15.4 s. No free-energy card, no solver run, no verdict artifacts were produced.

## Analysis
The gap is specifically the Ca(II)–D-penicillamine pair. D-penicillamine (β,β-dimethylcysteine, HS–C(CH3)2–CH(NH2)–COOH) is a soft, thiolate-containing amino acid; its chemistry is dominated by binding to soft/borderline cations through the thiolate S−. Ca(II), a hard oxophilic cation, is not expected to form strong complexes with the thiolate group and is routinely treated in the aqueous-coordination literature as effectively non-complexed by penicillamine beyond weak carboxylate interactions. The absence of Ca–penicillamine constants in SRD-46 is consistent with that chemistry — the critically evaluated compilation simply does not carry stability constants for a pair whose complexes are too weak to have been measured and tabulated.

Because the brief explicitly asks for all three metals in one pot and for the free[Ca2+]/free[Pb2+] selectivity ratio, I cannot answer it by silently dropping Ca: doing so would change the chemistry of the competition (Ca would no longer compete for protons via its hydration/activity contribution, and more importantly the requested Ca-based selectivity ratio would be fabricated). Per the pipeline's hard rule, I am reporting the missing data rather than substituting a different system or estimating constants.

Practical implications for the user's selectivity question, stated qualitatively from the chemistry (NOT from a computed result):
1. The Ca/Pb selectivity ratio is effectively a lower bound set by the Pb–penicillamine binding alone; with no measurable Ca–penicillamine complex, free[Ca2+] is essentially the analytical Ca concentration (minus modest activity corrections) across pH 6–8, so free[Ca2+]/free[Pb2+] will be very large and penicillamine is expected to be highly Pb-selective over Ca. This is the physical reason the pair is absent from SRD-46.
2. The Pb vs Zn selectivity question IS representable in SRD-46 (both Pb–penicillamine and Zn–penicillamine systems are tabulated). If the user wants that part answered quantitatively, resubmit a two-metal brief (Pb + Zn + penicillamine, same pH range and conditions) and the pipeline will run.
3. If a quantitative Ca ratio is genuinely required, it must come from a database that carries Ca–penicillamine constants (or from explicit experimental measurement); SRD-46 cannot supply it and the pipeline will not estimate it.

## Artifacts
(None — pipeline stopped at LC1 before any output files were written.)
```


## Tool call 4 — `inspect_batch_result` (iteration 3)

### Arguments
```json
{
  "tool_number": 1
}
```

### Reasoning excerpt
```
<summary>Need to inspect DTPA full result. Penicillamine failed (no Ca-penicillamine data in SRD-46). Will inspect the DTPA batch result for its selectivity numbers, then consider another candidate ligand like NTA or CDTA that has data for all three metals.</summary>
```

### Result (4882 chars)
```
### dispatch_l1_pipeline
## Doability
Doable. SRD-46 provides DTPA protonation and 1:1 M–DTPA complexes for Ca(II), Pb(II), and Zn(II) at 25 °C, I=0.1 M; a 1-D pH sweep over 6–8 at fixed non-redox totals is exactly the pH_sweep method's scope.

## Result
- System: 1.00 mM Pb(II) + 1.00 mM Zn(II) + 1.00 mM Ca(II) + 5.00 mM DTPA (ligand excess ≈1.67×).
- Method: pH_sweep, 21 points pH 6.0–8.0, T = 25.0 °C, I-target = 0.1 M (calculated I = 0.022–0.029 M, lower than target because DTPA complexes replace free ions), redox excluded.
- Convergence: 21/21 points converged for every component. No solid formed over the window ([Ca(OH)₂], PbO(red), Zn(OH)₂(α) all 0 mol/L).

## Analysis
**Dominant metal species (all pH 6–8).** Every metal is sequestered as the fully deprotonated 1:1 chelate [M(DTPA)]³⁻. The verdict shows [Pb(DTPA)]³⁻ reaching 100.0 % of Pb at pH 8 and [Ca(DTPA)]³⁻ 99.7 %, [Zn(DTPA)]³⁻ 99.9 %. At pH 6 the protonated chelates [M(DTPA)H]²⁻ carry a residual share (Ca 22 %, Zn 8 %, Pb much less) because HDTPA⁴⁻ is still a minor DTPA form (card log β for [M(DTPA)H]²⁻ via H+HDTPA⁴⁻+M²⁺: Ca 16.86, Pb 23.32, Zn 23.80). As pH rises past the HDTPA⁴⁻/DTPA⁵⁻ regime (DTPA ladder dominance flips H₂DTPA³⁻ → HDTPA⁴⁻ between pH 7.5 and 7.6), the protonated chelate relaxes into [M(DTPA)]³⁻ (log β: Ca 10.75, Pb 18.80, Zn 18.20). No hydrolysis species (e.g. [Pb(OH)]⁺, [Pb₄(OH)₄]⁴⁺, [Zn(OH)]⁺) exceed 10⁻¹³ M — DTPA fully outcompetes hydroxide, so no PbO or Zn(OH)₂ precipitates despite the near-neutral pH where free Pb(II) and Zn(II) would otherwise be nearing saturation.

**Free aqueous [M²⁺] vs pH** (from the concentrations CSV; mol/L):

| pH | free [Ca²⁺] | free [Pb²⁺] | free [Zn²⁺] |
|---:|---:|---:|---:|
| 6.0 | 2.24e-05 | 2.62e-13 | 9.64e-13 |
| 6.5 | 2.89e-06 | 2.81e-14 | 1.09e-13 |
| 7.0 | 3.64e-07 | 3.33e-15 | 1.32e-14 |
| 7.5 | 5.59e-08 | 5.03e-16 | 2.00e-15 |
| 8.0 | 1.24e-08 | 1.11e-16 | 4.40e-16 |

Every free [M²⁺] falls ~3 orders of magnitude from pH 6 to 8 because the controlling equilibrium M²⁺ + HDTPA⁴⁻ ⇌ [M(DTPA)]³⁻ + H⁺ is driven forward by consuming H⁺; equivalently, as HDTPA⁴⁻ and DTPA⁵⁻ grow with pH, the apparent conditional formation constant of [M(DTPA)]³⁻ rises in near-proportion.

**Free-ion selectivity ratios** (dimensionless):

| pH | free[Zn²⁺]/free[Pb²⁺] | free[Ca²⁺]/free[Pb²⁺] |
|---:|---:|---:|
| 6.0 | 3.7 | 8.5e+07 |
| 6.5 | 3.9 | 1.03e+08 |
| 7.0 | 4.0 | 1.09e+08 |
| 7.5 | 4.0 | 1.11e+08 |
| 8.0 | 4.0 | 1.12e+08 |

**Interpretation.**
- *Pb vs Zn is essentially a wash.* The ratio free[Zn²⁺]/free[Pb²⁺] ≈ 4 across pH 6–8 reflects the small log β difference for the 1:1 chelates (Pb 18.80 vs Zn 18.20 → ΔlogK = 0.60, so free[Zn²⁺]/free[Pb²⁺] = 10^0.60 ≈ 4). DTPA cannot kinetically or thermodynamically distinguish Pb(II) from Zn(II) under these conditions; both are >99.99 % bound. If the goal is Pb removal from a Zn-containing matrix with excess DTPA, Zn will be co-sequestered to the same extent — DTPA is not a Pb-selective reagent against Zn.
- *Ca is almost completely out-competed.* The ratio free[Ca²⁺]/free[Pb²⁺] ≈ 10⁸ reflects the 8-log-unit difference in [M(DTPA)]³⁻ log β (Ca 10.75 vs Pb 18.80, Δ = 8.05, 10^8.05 ≈ 1.1e8), modulated slightly at low pH by the Ca protonated-chelate equilibrium. Free Ca²⁺ (10⁻⁵–10⁻⁸ M) is 7–8 orders of magnitude higher than free Pb²⁺ (10⁻¹³–10⁻¹⁶ M), yet because 1 mM Ca only consumes 1 mM DTPA from the 5 mM pool, there is still ample DTPA (≈3 mM) left to fully bind Pb and Zn. In other words, Ca is a "sacrificial" sink for DTPA, not a competitor that releases Pb; selectivity for Pb removal is preserved only because the ligand is in excess.

**Practical implications.**
- DTPA at 5× total-metal stoichiometry fully masks all three divalent metals as [M(DTPA)]³⁻ across pH 6–8 with no risk of PbO or Zn(OH)₂ precipitation.
- For Pb/Zn discrimination, DTPA is unsuitable; a softer donor set (e.g. thiolate ligands) would be required.
- Ca(II) is thermodynamically outcompeted by ≈8 log units, so hard-water Ca background does not threaten Pb sequestration provided the DTPA dose exceeds Σ[M²⁺]; however, each equivalent of Ca does consume one equivalent of DTPA, so dosing must account for Ca load.

## Artifacts
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_verdict.md
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_concentrations.csv
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Pb.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Zn.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_frac_Ca.png
- L1_call_02/solver/Ca$+2_+_Ca$+0_+_Pb$+2_+_Pb$+0_+_Pb$+3_+_Pb$+4_+_Zn$+2_+_Zn$+0_+_DTPA_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
```

def _read_session_file(
    relative_path: str = "",
    max_chars: int = _READ_DEFAULT_MAX_CHARS,
) -> str:
    """Read a text file from the current session directory.

    Parameters
    ----------
    relative_path : str
        Path of the file relative to the session directory, exactly as
        returned by ``list_session_files`` (forward slashes ok).
    max_chars : int
        Truncate the returned content to this many characters.
        Defaults to 8000; hard-capped at 60000.

    The path is resolved against the session directory and rejected if
    it escapes (no ``..`` traversal, no absolute paths).  Binary files
    (PNG / JPG) are not returned — the caller is told their size and
    asked to look at the on-disk path instead.
    """
    sess = _SESSION_DIR_REF["path"]
    if sess is None or not sess.exists():
        return "_(no session directory)_"
    rel = (relative_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return "_(empty path)_"
    try:
        target, relative = resolve_under(sess / rel, sess)
    except ValueError:
        return f"_(refused: path '{relative_path}' escapes session dir)_"
    if tuple(part.lower() for part in relative.parts[:2]) == _RECONSTRUCTION_INTERNAL_PARTS:
        return "_(internal reconstruction records are not analysis evidence)_"
    if not target.exists() or not target.is_file():
        return f"_(no such file: '{relative_path}')_"
    suffix = target.suffix.lower()
    if suffix in {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".bin"}:
        return (f"_(binary file '{relative_path}', "
                f"{target.stat().st_size} bytes — not returned)_")
    cap = max(1, min(int(max_chars or _READ_DEFAULT_MAX_CHARS),
                     _READ_HARD_MAX_CHARS))
    text = target.read_text(encoding="utf-8", errors="replace")
    truncated = len(text) > cap
    body = text[:cap]
    header = (f"# `{rel}` ({target.stat().st_size} bytes"
              + (f", first {cap} chars shown" if truncated else "") + ")\n\n")
    return header + body + ("\n\n_(truncated)_" if truncated else "")

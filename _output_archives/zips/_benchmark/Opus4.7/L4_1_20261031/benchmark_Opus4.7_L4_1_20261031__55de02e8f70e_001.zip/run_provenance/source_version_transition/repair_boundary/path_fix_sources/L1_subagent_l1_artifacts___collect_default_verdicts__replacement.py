def _collect_default_verdicts(output_paths: List[Path]) -> List[tuple[Path, str]]:
    """Load every solver-written Markdown verdict exactly once, in full."""

    verdict_paths = sorted({
        filesystem_path(path).resolve()
        for path in output_paths
        if path.suffix.lower() == ".md"
        and path.name.lower().endswith("verdict.md")
        and filesystem_path(path).is_file()
    })
    return [
        (path, path.read_text(encoding="utf-8", errors="replace"))
        for path in verdict_paths
    ]

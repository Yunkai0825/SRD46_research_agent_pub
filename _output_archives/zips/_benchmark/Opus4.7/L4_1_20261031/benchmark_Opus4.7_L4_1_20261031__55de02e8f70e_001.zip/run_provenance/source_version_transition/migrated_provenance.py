"""Combine actual archived exchange evidence with newly emitted phase calls."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path


def complete_provenance(root,snapshot,audit_root,phase_audit,binding,*,read,sha,save,io):
    receipt_binding=binding['migration_receipt']
    if sha(receipt_binding['path'])!=receipt_binding['sha256']:
        raise RuntimeError('Migration receipt changed before provenance acceptance')
    migration=read(receipt_binding['path'])
    archive=Path(binding['archive_root'])
    def canonical(path):
        value=str(io(path).resolve())
        if value.startswith('\\\\?\\UNC\\'):value='\\\\'+value[8:]
        elif value.startswith('\\\\?\\'):value=value[4:]
        return os.path.normcase(value)
    same_path=lambda first,second:canonical(first)==canonical(second)
    if (migration.get('schema')!='srd46-explicit-path-migration/v1'
            or migration.get('originals_modified') is not False or migration.get('runtime_aliases')!=[]
            or not same_path(root,migration.get('transformed_root','')) or not same_path(archive,migration.get('original_root',''))
            or migration.get('provider_calls')!=0 or migration.get('solver_calls')!=0):
        raise RuntimeError('Migration provenance identity differs')
    rows={row['path'].replace('\\','/'):row for row in migration['files']}
    def original_document(relative):
        row=rows[relative];path=archive/relative
        if sha(path)!=row['sha256']:raise RuntimeError('Original prior-attempt audit bytes changed')
        return path,read(path)
    combined='run_provenance/complete_run_api_provenance_audit.json'
    simple='run_provenance/complete_api_provenance_audit.json'
    if combined in rows:
        original_path,original=original_document(combined)
        if original.get('status')!='passed':raise RuntimeError('Original combined API audit did not pass')
        original_count=original['total_unique_HTTP_attempts']
    else:
        original_path,original=original_document(simple)
        if original.get('status')!='passed_recorded_exchanges':raise RuntimeError('Original preparation API audit did not pass')
        original_count=original['total_recorded_HTTP_attempts']
    if phase_audit.get('status')!='passed_recorded_exchanges':raise RuntimeError('Current phase audit did not pass')
    phase_path=audit_root/'run_provenance/complete_api_provenance_audit.json'
    result={'schema':'srd46-complete-migrated-run-provenance/v1','created':datetime.now(timezone.utc).isoformat(),'status':'passed',
        'canonical_root':str(root),'preparation_snapshot':str(snapshot),'continuation_root':str(audit_root),
        'authentic_prior_attempts':{'archive_root':str(archive),'audit':str(original_path),'sha256':sha(original_path),'HTTP_attempts':original_count},
        'transformed_replay':{'migration_receipt':receipt_binding,'wire_records_were_emitted':False,'provider_calls':0,'accounting_ledger_modified':False},
        'continuation':{'audit':str(phase_path),'sha256':sha(phase_path),'HTTP_attempts':phase_audit['total_recorded_HTTP_attempts']},
        'total_unique_HTTP_attempts':original_count+phase_audit['total_recorded_HTTP_attempts'],
        'inherited_child_exchanges_excluded_from_continuation':phase_audit.get('inherited_nested_HTTP_attempts',0),
        'scope':'Actual prior provider exchanges in unchanged archived evidence plus newly emitted continuation exchanges. Superseded prior replies remain historical evidence; transformed replay records are not additional provider calls.',
        'original_preparation_receipts_preserved':True}
    path=root/'run_provenance/complete_run_api_provenance_audit.json';save(path,result)
    return {'path':str(path),'sha256':sha(path),'status':'passed','total_unique_HTTP_attempts':result['total_unique_HTTP_attempts']}

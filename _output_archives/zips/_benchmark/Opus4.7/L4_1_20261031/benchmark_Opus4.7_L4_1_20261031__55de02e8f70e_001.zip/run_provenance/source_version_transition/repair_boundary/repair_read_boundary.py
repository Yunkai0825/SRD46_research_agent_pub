"""Strict planned continuation at a verified artifact read, without new API work.

The preceding native operation and HTTP ledger is replayed byte-for-byte. A
completed pipeline snapshot restores solver outputs; only the explicitly bound
failed read is re-executed. This is not an authorization interruption.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import copy_context
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import time

try:
    import staged_engine as staged
except ImportError:
    from portable_batch import staged_engine as staged

base = staged._base
io = staged.filesystem_path
Mismatch = staged.ReconstructionMismatch
SCHEMA = 'srd46-planned-artifact-read-repair/v1'
READ = 'analysis.read.read_output_file'
BUILD = 'analysis.build_and_solve'


def read(path):
    return json.loads(io(path).read_text('utf-8'))


def digest(path):
    with io(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_new(path, value):
    io(path).parent.mkdir(parents=True, exist_ok=True)
    with io(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def _verified(row, kind):
    root = io(row['_folder'])
    filename = row.get(kind+'_file')
    if not isinstance(filename, str) or Path(filename).name != filename:
        raise Mismatch('Invalid source result filename')
    path = root / filename
    value = path.read_bytes()
    if hashlib.sha256(value).hexdigest() != row.get(kind+'_sha256'):
        raise Mismatch('Source receipt checksum differs: '+kind)
    return value


def _rows(source):
    source = Path(source).absolute()
    if read(source/'session.json').get('schema') != 'first-principle-reconstruction/v1':
        raise Mismatch('Unsupported native source ledger')
    rows = []
    for folder in ('operations', 'calls'):
        for path in sorted(io(source/folder).glob('*.receipt.json')):
            row = read(path)
            row['_folder'] = str(source/folder)
            rows.append(row)
    events = [json.loads(line) for line in io(source/'events.jsonl').read_text('utf-8').splitlines() if line]
    if [row.get('sequence') for row in events] != list(range(1, len(events)+1)):
        raise Mismatch('Source journal sequence differs')
    starts = {row['sequence'] for row in events if row.get('event') == 'started'}
    ids = {row['id'] for row in rows}
    if starts != ids or len(ids) != len(rows):
        raise Mismatch('Source has missing, duplicate or uncommitted receipts')
    for row in rows:
        try:
            started, ended = events[row['start_sequence']-1], events[row['end_sequence']-1]
        except (KeyError, IndexError, TypeError) as exc:
            raise Mismatch('Source receipt has invalid event boundaries') from exc
        if (row['end_sequence'] <= row['start_sequence'] or started.get('event') != 'started'
                or ended.get('event') != 'completed' or ended.get('id') != row['id']):
            raise Mismatch('Source receipt and event journal disagree')
        for event in (started, ended):
            for key, value in event.items():
                if key not in {'event', 'sequence', 'time'} and row.get(key) != value:
                    raise Mismatch('Source receipt event content differs')
        if row.get('kind') == 'http':
            _verified(row, 'request')
            if row.get('response_file'):
                response = _verified(row, 'response').decode('utf-8')
                if staged._transport.authorization_denied(row['http_status'], response):
                    raise Mismatch('Authorization-denied ledgers need their own native recovery mode')
            elif not (row.get('exception_type') and isinstance(row.get('exception_message'), str)):
                raise Mismatch('Source HTTP failure lacks exact recorded exception')
        elif row.get('kind') == 'operation' and row.get('status') in {'ok', 'failed'}:
            _verified(row, 'result')
    return sorted(rows, key=lambda row: row['start_sequence'])


def _relative(path, root):
    # Resolve symlinks first, normalize the Windows device prefix only for the
    # containment comparison. Returned relative paths never contain an alias.
    return staged._paths.display_path(io(path).resolve()).relative_to(
        staged._paths.display_path(io(root).resolve()))


def build_contract(source_ledger, session_root, *, boundary_event_id=224, completed_build_event_id=183):
    """Read-only validation; no source files, model calls or solver calls change."""
    source, root = Path(source_ledger).absolute(), Path(session_root).absolute()
    launch = read(source/'analysis_run.json')
    if launch.get('session_dir') != str(root):
        raise Mismatch('Source must already declare the exact compact scientific root')
    rows = _rows(source)
    by_id = {row['id']:row for row in rows}
    boundary, build = by_id.get(boundary_event_id), by_id.get(completed_build_event_id)
    if not boundary or boundary.get('name') != READ or boundary.get('status') != 'ok':
        raise Mismatch('The declared boundary is not a completed artifact read')
    if boundary.get('parent_ids'):
        raise Mismatch('This scoped repair supports a read outside unfinished pipeline operations only')
    failed_read = json.loads(_verified(boundary, 'result'))
    text = failed_read.get('result')
    if (failed_read.get('has_snapshot') is not False or not isinstance(text, str)
            or not (text.startswith('_(no such file:') or text.startswith('_(refused:'))):
        raise Mismatch('Boundary does not contain the recorded artifact-path failure')
    if (not build or build.get('name') != BUILD or build.get('status') != 'ok'
            or build['end_sequence'] >= boundary['start_sequence']):
        raise Mismatch('A completed build-and-solve operation must precede the read')
    saved = json.loads(_verified(build, 'result'))
    snapshot = saved.get('snapshot')
    if not saved.get('has_snapshot') or not isinstance(snapshot, dict):
        raise Mismatch('Completed pipeline has no restorable solver state')
    if not {'files','state','working_memory','history','stats'} <= snapshot.keys():
        raise Mismatch('Completed native pipeline snapshot is incomplete')
    call_dir = snapshot['state'].get('call_dir')
    if not isinstance(call_dir, dict) or set(call_dir) != {'__path__'}:
        raise Mismatch('Completed pipeline call directory is not explicitly recorded')
    call_relative = _relative(call_dir['__path__'], root)
    kwargs = boundary.get('arguments', {}).get('kwargs', {})
    relative = Path(kwargs.get('relative_path', ''))
    if (not str(relative) or relative.is_absolute() or '..' in relative.parts
            or not isinstance(kwargs.get('max_chars'), int)):
        raise Mismatch('Read arguments must specify a bounded relative artifact path')
    requested = relative.as_posix()
    matches = [entry for entry in snapshot['files']
               if (call_relative/entry['path']).as_posix() == requested]
    if len(matches) != 1:
        raise Mismatch('The requested artifact is not uniquely present in the completed solver snapshot')
    artifact = matches[0]
    blob = source/'artifacts'/artifact['sha256']
    if (not io(blob).is_file() or io(blob).stat().st_size != artifact['bytes']
            or digest(blob) != artifact['sha256']):
        raise Mismatch('Completed solver artifact blob is missing or altered')
    preceding = [row for row in rows if row['start_sequence'] < boundary['start_sequence']]
    if any(row['end_sequence'] >= boundary['start_sequence'] for row in preceding):
        raise Mismatch('Unfinished earlier work crosses the artifact-read boundary')
    clocks = [row for row in preceding if row.get('name') == 'planned.native_clock.perf_counter'
              and row.get('status') == 'ok']
    if not clocks:
        raise Mismatch('Native monotonic budget anchor is absent')
    clock = clocks[-1]
    perf = float(json.loads(_verified(clock, 'result'))['result'])
    wall = float(boundary['wall_time'])
    perf += max(0.0, wall-float(clock['wall_time']))
    return {'schema':SCHEMA, 'source_ledger':str(source), 'session_root':str(root),
            'boundary_event_id':boundary['id'], 'boundary_operation':READ,
            'boundary_arguments':boundary['arguments'],
            'boundary_result_sha256':boundary['result_sha256'],
            'completed_build_event_id':build['id'], 'completed_build_result_sha256':build['result_sha256'],
            'artifact':{'path':requested,'bytes':artifact['bytes'],'sha256':artifact['sha256']},
            'source_session_sha256':digest(source/'session.json'),
            'source_journal_sha256':digest(source/'events.jsonl'),
            'source_launch_sha256':digest(source/'analysis_run.json'),
            'wall_time':wall,'perf_counter':perf,'authorization_denied':False,
            'completed_solver_reused':True,'runtime_path_bindings':[]}


class RepairReadSession(staged.StageReplaySession):
    def __init__(self, *, contract, controller, before_live_read=None, **kwargs):
        self.repair_contract = json.loads(json.dumps(contract))
        self.before_live_read = before_live_read
        super().__init__(phase='resume', prepared_ledger=contract['source_ledger'],
                         session_root=contract['session_root'], controller=controller, **kwargs)

    def _load_source(self):
        expected = build_contract(self.source_dir, self.session_root,
            boundary_event_id=self.repair_contract['boundary_event_id'],
            completed_build_event_id=self.repair_contract['completed_build_event_id'])
        # source_dir is resolved by the native engine; compare path identity
        # separately without normalizing any model context or tool arguments.
        actual = dict(self.repair_contract, source_ledger=str(self.source_dir))
        if expected != actual:
            raise Mismatch('Artifact repair contract changed after validation')
        rows = _rows(self.source_dir)
        self._boundary = next(row for row in rows if row['id'] == expected['boundary_event_id'])
        self._source = [row for row in rows if row['start_sequence'] <= self._boundary['start_sequence']]
        self.stageinfo = expected

    def __enter__(self):
        result = base.ReconstructionSession.__enter__(self)
        self.stage_controller.session = self
        write_new(self.output_dir/'planned_artifact_read_repair.json', self.repair_contract)
        return result

    def operation(self, name, arguments, live_call, **kwargs):
        if self.live or name != READ:
            return super().operation(name, arguments, live_call, **kwargs)
        lane = kwargs.get('lane') or base._runtime.lane.get()
        next_row = next((row for row in self._source if row.get('lane','') == lane
                         and row['id'] not in self._consumed), None)
        if next_row is None or next_row['id'] != self._boundary['id']:
            return super().operation(name, arguments, live_call, **kwargs)
        try:
            source = self._match('operation', lane, arguments, name=name)
            pending = [row['id'] for row in self._source if row['id'] not in self._consumed]
            if pending:
                self.reject('Artifact repair reached before the full earlier native prefix was consumed')
            artifact = self.repair_contract['artifact']
            restored = self.session_root/artifact['path']
            if (not io(restored).is_file() or io(restored).stat().st_size != artifact['bytes']
                    or digest(restored) != artifact['sha256']):
                self.reject('Completed solver snapshot did not restore the bound artifact')
            if self.before_live_read is not None:
                try:
                    self.before_live_read()
                except Exception as exc:
                    self.reject('Checked artifact reader activation failed: '+type(exc).__name__+': '+str(exc))
            self._live = True
            self.live_started_monotonic = time.monotonic()
            self.live_clock_anchor = self.stageinfo['wall_time']
            record = self._begin('operation', lane, name=name, arguments=arguments,
                                 source_id=source['id'], recorded_wall_time=source.get('wall_time'))
            token = base._runtime.parents.set((*base._runtime.parents.get(), record['id']))
            try:
                result = live_call()
                if not isinstance(result, str) or result.startswith(('_(no such file:', '_(refused:', '_(error:')):
                    raise Mismatch('Corrected artifact read did not return the saved solver evidence')
                cap=max(1,min(int(arguments['kwargs'].get('max_chars') or 8000),60000))
                expected_text=io(restored).read_text(encoding='utf-8',errors='replace')[:cap]
                if expected_text not in result:
                    raise Mismatch('Corrected artifact read differs from the verified solver file')
                self._save_operation(record, {'result':result,'snapshot':None,'has_snapshot':False}, replayed=False)
            except BaseException as exc:
                self._finish(record, status='interrupted', exception_type=type(exc).__name__)
                raise
            finally:
                base._runtime.parents.reset(token)
            self.stage_controller.stageinfo = {**self.repair_contract,'status':'resumed_at_corrected_artifact_read'}
            write_new(self.output_dir/'planned_artifact_read_crossover.json', self.stage_controller.stageinfo)
            return result
        except Mismatch:
            self._invalid = True
            raise


@contextmanager
def install_read_repair(contract, *, provenance_root, before_live_read=None):
    """Install the private adapter after verified workspace rewind, before API entry."""
    if base.current_session() is not None:
        raise RuntimeError('Install repair controls before entering native execution')
    root = Path(contract['session_root'])
    provenance_root = Path(provenance_root).absolute()
    phase = provenance_root.parent
    if provenance_root.name != 'continuation' or not phase.name.startswith('resume_attempt_'):
        raise Mismatch('Repair capture must use its declared continuation phase')
    _relative(phase, root/'run_provenance')
    claim = read(phase/'repair_claim.json')
    if claim.get('contract') != contract:
        raise Mismatch('Repair execution does not match the durable one-shot rewind claim')
    snapshot = phase/'saved_workspace'
    _relative(contract['source_ledger'], snapshot)
    adapter = importlib.import_module(staged.PREFIX+'.analysis_reconstruction')
    control = staged.StageController('resume',contract['source_ledger'],root,adapter,provenance_root)
    changes=[]
    def patch(obj,name,value):
        changes.append((obj,name,getattr(obj,name)))
        setattr(obj,name,value)
    def factory(**kwargs):
        return RepairReadSession(contract=contract, controller=control,
                                 before_live_read=before_live_read, **kwargs)
    # Probe validates every source receipt before recording anything.
    factory(output_dir=Path(provenance_root)/'preflight_not_entered')
    write_new(provenance_root/'run_provenance/repair_install_claim.json',
              {'schema':SCHEMA,'contract':contract,'capture_root':str(provenance_root)})
    try:
        original, replacement = staged._phase_execution(adapter,factory,provenance_root,root,
                                                        snapshot)
        l0 = importlib.import_module(staged.PREFIX+'.analysis_agent_orchestration.L0_orchestrator.orchestrator')
        for name,function in staged._evidence_tool_bindings(l0,provenance_root):
            patch(l0,name,function)
        for name,module in tuple(sys.modules.items()):
            if name.startswith(staged.PREFIX) and getattr(module,'analysis_execution',None) is original:
                patch(module,'analysis_execution',replacement)
        patch(adapter,'ReconstructionSession',factory)
        for name in (
            staged.PREFIX+'.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api',
            staged.PREFIX+'.analysis_agent_orchestration.L1_subagent.l1_pipeline_tool',
            staged.PREFIX+'.analysis_agent_orchestration.L1_subagent.l1_subagent',
            staged.PREFIX+'.analysis_agent_orchestration.L0_orchestrator.orchestrator',
        ):
            module=importlib.import_module(name)
            patch(module,'time',staged._ClockProxy(module.time,name))
        from concurrent.futures import ThreadPoolExecutor
        original_submit=ThreadPoolExecutor.submit
        def submit(pool,function,*args,**kwargs):
            return original_submit(pool,copy_context().run,function,*args,**kwargs)
        patch(ThreadPoolExecutor,'submit',submit)
        yield control
    finally:
        for obj,name,value in reversed(changes):
            setattr(obj,name,value)


def snapshot_completed_workspace(session_root, repair_phase):
    """Retain the complete stopped run inside its permanent root before replay."""
    module = importlib.import_module(staged.prepare_in_place_snapshot.__module__)
    root, phase = Path(session_root).absolute(), Path(repair_phase).absolute()
    rel = _relative(phase,root/'run_provenance')
    if len(rel.parts)!=1 or not rel.name.startswith('resume_attempt_'):
        raise ValueError('Repair phase must be a new resume_attempt child of run_provenance')
    if io(phase).exists():
        raise FileExistsError('Repair phase already exists; refusing duplicate continuation')
    files, dirs = module._inventory(root), module._directories(root)
    snapshot = phase/'saved_workspace'
    io(snapshot).mkdir(parents=True,exist_ok=False)
    for directory in dirs:
        io(snapshot/directory).mkdir(parents=True,exist_ok=True)
    for row in files:
        target = snapshot/row['path']
        io(target).parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(io(root/row['path']),io(target))
        if digest(target)!=row['sha256'] or digest(root/row['path'])!=row['sha256']:
            raise Mismatch('Stopped workspace changed during repair snapshot')
    if module._inventory(root,[phase])!=files or module._directories(root,[phase])!=dirs:
        raise Mismatch('Stopped workspace changed during complete repair snapshot')
    manifest={'schema':'srd46-artifact-read-repair-snapshot/v1','session_root':str(root),
              'snapshot':str(snapshot),'files':files,'directories':dirs}
    write_new(phase/'snapshot_manifest.json',manifest)
    return snapshot


def rewind_completed_workspace(session_root, repair_phase, *, contract):
    """One-shot, verified per-file rewind; never moves/deletes the run root."""
    module = importlib.import_module(staged.prepare_in_place_snapshot.__module__)
    root, phase=Path(session_root).absolute(),Path(repair_phase).absolute()
    _relative(phase,root/'run_provenance')
    manifest=read(phase/'snapshot_manifest.json')
    snapshot=phase/'saved_workspace'
    if (manifest.get('session_root')!=str(root) or manifest.get('snapshot')!=str(snapshot)
            or module._inventory(snapshot)!=manifest['files']
            or module._directories(snapshot)!=manifest['directories']):
        raise Mismatch('Complete repair snapshot identity/content differs')
    if (module._inventory(root,[phase])!=manifest['files']
            or module._directories(root,[phase])!=manifest['directories']):
        raise Mismatch('Stopped workspace changed; refusing repair rewind')
    if _relative(contract['source_ledger'],snapshot).parts[:1]!=('run_provenance',):
        raise Mismatch('Repair source must be the saved complete stopped-run ledger')
    expected=build_contract(contract['source_ledger'],root,
        boundary_event_id=contract['boundary_event_id'],completed_build_event_id=contract['completed_build_event_id'])
    if contract!=expected:
        raise Mismatch('Repair source contract changed')
    rows=[row for row in manifest['files'] if not row['path'].startswith('run_provenance/')
          and row['path'] not in {'_run.log','worker_console.log'}]
    dirs=[path for path in manifest['directories'] if path!='run_provenance'
          and not path.startswith('run_provenance/')]
    write_new(phase/'repair_claim.json',{'schema':SCHEMA,'contract':contract,
        'files_rewound':rows,'directories_rewound':dirs,'original_root_relocated':False})
    for row in rows:
        path=root/row['path']
        _relative(path,root)
        if digest(path)!=row['sha256']:
            raise Mismatch('Scientific working file changed during repair rewind')
        io(path).unlink()
    for relative in sorted(dirs,key=lambda p:len(Path(p).parts),reverse=True):
        path=root/relative
        _relative(path,root)
        io(path).rmdir()
    return phase/'continuation'

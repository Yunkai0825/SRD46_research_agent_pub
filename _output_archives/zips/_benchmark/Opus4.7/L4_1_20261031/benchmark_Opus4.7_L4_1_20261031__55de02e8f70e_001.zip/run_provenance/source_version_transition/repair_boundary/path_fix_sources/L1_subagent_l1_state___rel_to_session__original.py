def _rel_to_session(path: Path) -> str:
    """Return a path relative to the configured session root when possible."""

    session_dir = _SESSION["session_dir"]
    try:
        if session_dir is not None:
            return path.resolve().relative_to(Path(session_dir).resolve()).as_posix()
    except Exception:
        pass
    return path.as_posix()

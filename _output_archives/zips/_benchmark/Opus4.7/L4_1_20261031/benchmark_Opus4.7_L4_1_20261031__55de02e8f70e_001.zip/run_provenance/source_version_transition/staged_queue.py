"""Permanent canonical run folders, imported live workers, and bounded 1D completion."""
from __future__ import annotations
from collections import Counter
from contextlib import contextmanager, ExitStack
from datetime import datetime,timezone
from functools import wraps
import copy,hashlib,importlib.util,inspect,json,logging,os,re,shutil,sys,time,traceback
from pathlib import Path
HERE=Path(__file__).absolute().parent
PREVIOUS=HERE.parent/'direct_continuation_v3_in_place_20261030'
TRANSITION=HERE.parent/'path_migration_20261031'
SPEC=HERE/'spec.json'
modspec=importlib.util.spec_from_file_location('permanent_queue_base',HERE/'queue_base.py')
base=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(base)
legacy=base.legacy;frozen=base.frozen
sys.path.insert(0,str(HERE))
read=base.read;sha=base.sha;save=base.save_original;io=base.io
_base_verify=base.verify

# The retained native queue validator also validated its old filename suffix.
# All other validation remains byte-for-byte intact; this queue has an explicit
# per-item compact path map and validates that map below.
validator_source=inspect.getsource(frozen.validate_spec)
old_naming="spec.get('session_suffix') != SESSION_SUFFIX"
if validator_source.count(old_naming)!=1:raise RuntimeError('Native specification naming seam changed')
validator_source=validator_source.replace(old_naming,"spec.get('session_naming') != 'debug_id_date'")
validator_source=validator_source.replace('Output owner account-1 and unique fresh_20261030 suffix required','Output owner account-1 and compact debug-ID/date naming required')
exec(compile(validator_source,str(Path(__file__))+':compact_spec_validator','exec'),frozen.__dict__)

class EarlyDimensionViolation(BaseException):pass

def verify(config):
    spec=_base_verify(config)
    if spec.get('storage_mode')!='permanent_canonical_roots':raise RuntimeError('Permanent storage contract required')
    for cid,digest in spec['early_1d_prompt_sha256'].items():
        if hashlib.sha256(frozen.item_for(spec,cid)['prompt'].encode()).hexdigest()!=digest:raise RuntimeError('1D question scope changed: '+cid)
    if spec.get('session_suffix')!='' or spec.get('session_naming')!='debug_id_date':raise RuntimeError('Explicit compact paths are required')
    for cid,path in spec['session_paths'].items():
        compact='_'.join(cid.split('_')[:2])
        if not re.fullmatch(re.escape(compact)+r'_\d{8}',Path(path).name):raise RuntimeError('Noncompact output name: '+cid)
    for binding in spec.get('migrated_inputs',{}).values():
        receipt=binding['migration_receipt']
        if sha(receipt['path'])!=receipt['sha256']:raise RuntimeError('Sealed migration receipt changed')
    acceptance=spec['migration_acceptance']
    if sha(acceptance['path'])!=acceptance['sha256'] or read(acceptance['path']).get('status')!='passed':raise RuntimeError('Migrated continuation acceptance changed')
    return spec
legacy.verify=verify

def current_spec():return read(SPEC)
def phase_root(spec,cid,phase):
    root=frozen.session_path(spec,cid)
    if phase!='resume':return root
    return root/('run_provenance/resume_attempt_002/continuation' if cid in spec.get('artifact_read_repairs',{}) else 'run_provenance/resume_attempt_001')

def snapshot_source(spec,cid):
    root=frozen.session_path(spec,cid)
    return root/('run_provenance/resume_attempt_002/saved_workspace' if cid in spec.get('artifact_read_repairs',{}) else 'run_provenance/staged_preparation_snapshot')

def checkpoint_location(spec,cid):
    root=frozen.session_path(spec,cid);snapshot=snapshot_source(spec,cid)
    repair=spec.get('artifact_read_repairs',{}).get(cid)
    if repair:
        relative=repair['source_ledger_relative']
        if io(snapshot/relative/'events.jsonl').is_file():
            return {'snapshot':str(snapshot),'checkpoint':str(snapshot/relative),'boundary':'artifact_read','event_id':repair['boundary_event_id']}
        ledger=root/relative
        return {'snapshot':None,'checkpoint':str(ledger) if io(ledger/'events.jsonl').is_file() else None,'boundary':'artifact_read','event_id':repair['boundary_event_id']}
    if io(root/'run_provenance/staged_preparation_snapshot.json').is_file():
        try:return {'snapshot':str(snapshot),'checkpoint':str(legacy.source_ledger(snapshot))}
        except (FileNotFoundError,RuntimeError,KeyError):pass
    try:ledger=legacy.source_ledger(root)
    except (FileNotFoundError,RuntimeError,KeyError):return {'snapshot':None,'checkpoint':None}
    return {'snapshot':None,'checkpoint':str(ledger) if io(ledger/'planned_stage_boundary.json').exists() else None}

def validate_dimension(path):
    card=read(path);dimension=card.get('_meta',{}).get('dof');axes=card.get('sweep_axes')
    if type(dimension) is not int or dimension not in (0,1) or not isinstance(axes,list) or len(axes)>1:
        raise EarlyDimensionViolation('Early continuation requires an explicitly validated 0D/1D calculation')
    if len(axes)!=dimension or 'pourbaix' in str(card.get('sweep_method','')).casefold():
        raise EarlyDimensionViolation('Declared dimension, axes or sweep method contradict early 1D scope')
    return {'card':str(path),'sha256':sha(path),'dimension':dimension,'axes':len(axes),'sweep_method':card.get('sweep_method')}

def planned_card(root):
    ledger=legacy.source_ledger(root)
    boundary=read(ledger/'planned_stage_boundary.json')
    kwargs=boundary['arguments'].get('kwargs',{})
    value=kwargs.get('calc_input')
    # Native encoder represents Path objects as tagged dictionaries.
    if isinstance(value,dict):value=value.get('value',value.get('path',value.get('__path__')))
    if isinstance(value,str) and io(value).is_file():return Path(value)
    candidates=list(io(root).glob('L1_call_*/LC3/calc_input_card.json'))
    if len(candidates)!=1:raise EarlyDimensionViolation('Prepared boundary card cannot be uniquely resolved')
    return candidates[0]

def early_eligible(spec,cid):
    if cid not in spec['early_1d_prompt_sha256']:return False
    try:validate_dimension(planned_card(frozen.session_path(spec,cid)))
    except (EarlyDimensionViolation,FileNotFoundError,KeyError):return False
    return True

def choose_phase(state):
    rows=state['items'];spec=current_spec()
    if any(row['status'] in legacy.TERMINAL-{'complete'} for row in rows.values()):return 'held',[]
    active=[row for row in rows.values() if row['status'] in {'starting','running'}]
    if len(active)>=2:return 'waiting',[]
    if not any(row.get('phase') in {'resume','direct'} for row in active):
        fast=[cid for cid,row in rows.items() if row['status'] in {'prepared','repair_ready'} and early_eligible(spec,cid)]
        if fast:return 'resume',fast[:1]
    pending=[cid for cid,row in rows.items() if row['status']=='pending' and cid!=frozen.FF1]
    if pending:return 'prepare',pending[:max(0,2-len(active))]
    if active:return 'waiting',[]
    return base.choose_phase(state)
legacy.choose_phase=choose_phase

def validate_dispatch(state,spec,cid,phase):
    if state.get('launch_hold_reason'):raise RuntimeError('Queue has a durable hold')
    row=state['items'][cid]
    if row.get('phase')!=phase or row['status'] not in {'starting','running'}:raise RuntimeError('Dispatch identity differs')
    if any(item['status'] in legacy.TERMINAL-{'complete'} for item in state['items'].values()):raise RuntimeError('Earlier failure requires inspection')
    other=[r for key,r in state['items'].items() if key!=cid and r['status'] in {'starting','running'}]
    if len(other)>1:raise RuntimeError('At most two workers may run')
    if phase=='prepare':
        if any(r.get('phase')=='direct' for r in other):raise RuntimeError('FF1 has exclusive execution')
    elif phase=='resume':
        if any(r.get('phase') in {'resume','direct'} for r in other):raise RuntimeError('At most one resumed solver may run')
        if not early_eligible(spec,cid):
            if other or any(r['status']=='pending' for key,r in state['items'].items() if key!=frozen.FF1):raise RuntimeError('2D resumes await complete preparations')
            if not base.drafts_ready(spec):raise RuntimeError('2D resumes await all original drafts')
    elif phase=='direct':
        if cid!=frozen.FF1 or other or any(r['status']!='complete' for key,r in state['items'].items() if key!=cid):raise RuntimeError('FF1 runs last and alone')
        if not base.drafts_ready(spec):raise RuntimeError('FF1 awaits original drafts')
    else:raise ValueError('Unknown phase')
legacy.validate_dispatch=validate_dispatch

def prepared_in_place(spec,cid):
    root=frozen.session_path(spec,cid)
    receipt=read(root/'run_provenance/preparation_receipt.json')
    if receipt.get('status')!='prepared' or receipt.get('id')!=cid:raise RuntimeError('Canonical preparation is incomplete')
    save(HERE/'preparation_locations'/(cid+'.json'),{'id':cid,'canonical':str(root),'state':'prepared',
        'preparation_receipt_sha256':sha(root/'run_provenance/preparation_receipt.json'),'moved':False})
    return root
legacy.archive_prepared=prepared_in_place

def result_path_for(cid,phase,row):
    spec=current_spec();adopted=spec.get('adopted_workers',{}).get(cid)
    if adopted and phase==adopted['phase']:return Path(adopted['result_path'])
    return HERE/'worker_results'/f'{cid}.{phase}.json'

def read_worker_result(path,cid,phase,row):
    result=read(path);spec=current_spec();adopted=spec.get('adopted_workers',{}).get(cid)
    if adopted and phase==adopted['phase'] and adopted.get('result_sha256') and sha(path)!=adopted['result_sha256']:
        raise RuntimeError('Adopted terminal worker receipt changed: '+cid)
    expected_spec=adopted['spec_sha256'] if adopted and phase==adopted['phase'] else sha(SPEC)
    expected_config=adopted['config_sha256'] if adopted and phase==adopted['phase'] else sha(base.CONFIG)
    if (result.get('id')!=cid or result.get('phase')!=phase or result.get('spec_sha256')!=expected_spec
        or result.get('stage_config_sha256')!=expected_config or result.get('argo_user')!=spec['argo_user']
        or base.canonical(result['session_dir'])!=base.canonical(spec['session_paths'][cid])):
        raise RuntimeError('Worker result ownership/source contract differs: '+cid)
    if result.get('status') in {'prepared','complete'} and result.get('framework_unchanged') is not True:
        raise RuntimeError('Successful result lacks unchanged native source proof: '+cid)
    return result

def archive_console(spec,cid,phase):
    adopted=spec.get('adopted_workers',{}).get(cid)
    source=Path(adopted['worker_log']) if adopted and phase==adopted['phase'] else HERE/'worker_logs'/f'{cid}.{phase}.log'
    target=phase_root(spec,cid,phase)/'run_provenance'/f'worker_console_{phase}.log'
    if not io(target.parent).exists():return
    if not io(target).exists():shutil.copyfile(io(source),io(target))
    if sha(source)!=sha(target):raise RuntimeError('Worker console copy differs')
legacy.archive_console=archive_console

_publish=legacy.publish_state
def publish_state(state,spec):
    _publish(state,spec)
    index={'schema':'srd46-permanent-run-index/v1','updated':frozen.now(),'queue_state':str(legacy.STATE),'items':{}}
    for cid,row in state['items'].items():
        index['items'][cid]={'canonical':spec['session_paths'][cid],'status':row['status'],'phase':row.get('phase'),
            'pid':row.get('pid'),**checkpoint_location(spec,cid),
            'resume_provenance':row.get('phase_provenance_root'),'complete_run_provenance':row.get('complete_run_provenance'),
            'archived_copy_provenance':spec.get('prior_storage',{}).get(cid),'early_1d_allowed':cid in spec['early_1d_prompt_sha256']}
    index['superseded_preparations']=spec.get('preserved_superseded_preparations',{})
    index['archived_history']=spec.get('archived_history',{})
    save(HERE/'run_locations.json',index)
legacy.publish_state=publish_state

def copy_runtime_sources(target):
    files=[path for path in HERE.glob('*.py') if not path.name.startswith('test_')]
    files.extend(path for path in (HERE/'repair_boundary').rglob('*') if path.is_file() and '__pycache__' not in path.parts)
    for source in files:
        destination=Path(target)/source.relative_to(HERE)
        io(destination.parent).mkdir(parents=True,exist_ok=True)
        shutil.copy2(io(source),io(destination))

_base_save=legacy.save
def save_with_storage_sources(path,value):
    _base_save(path,value)
    if Path(path).name=='launch_receipt.json' and value.get('stage_config_sha256'):
        target=Path(path).parent/'source_version_transition'
        copy_runtime_sources(target)
legacy.save=save_with_storage_sources

def phase_physical_audit(audit,proxy,audit_root):
    rows=list(audit['root']['records'])
    for block in audit['nested_MCP']:
        if block.get('duplicate_of'):continue
        rows.extend(row for row in block['records'] if row.get('phase_attribution')=='current_continuation')
    expected=Counter()
    for row in rows:
        if not row.get('pair_complete'):raise RuntimeError('Current continuation has an incomplete API exchange')
        if row.get('exception_type'):
            kind=row['exception_type']
            if kind in {'ReadTimeout','ConnectionError'}:kind='requests.exceptions.'+kind
            if kind not in {'requests.exceptions.ReadTimeout','requests.exceptions.ConnectionError'}:raise RuntimeError('Unsupported incomplete physical exchange: '+kind)
            key=(row['request_payload_sha256'],'transport_exception:'+kind,None)
        else:key=(row['request_payload_sha256'],row['response_sha256'],int(row['http_status']))
        expected[key]+=1
    result=proxy.audit_logical_pairs(expected)
    result['inherited_child_exchanges_excluded']=audit.get('inherited_nested_HTTP_attempts',0)
    save(audit_root/'run_provenance/physical_provider_coverage.json',result)
    if result.get('status') not in {'passed','passed_recorded_exchanges'}:raise RuntimeError('Current phase physical provider provenance audit failed')
    return result

def combined_provenance(root,snapshot,audit_root,phase_audit,account):
    spec=current_spec()
    cid=next(cid for cid,path in spec['session_paths'].items() if base.canonical(path)==base.canonical(root))
    if cid in spec.get('migrated_inputs',{}):
        from migrated_provenance import complete_provenance
        return complete_provenance(root,snapshot,audit_root,phase_audit,spec['migrated_inputs'][cid],read=read,sha=sha,save=save,io=io)
    from phase_provenance_audit import audit_run
    original=audit_run(snapshot,expected_account=account)
    if original['status']!='passed_recorded_exchanges':raise RuntimeError('Immutable original preparation provenance failed audit')
    original_path=audit_root/'run_provenance/original_preparation_api_audit.json'
    phase_path=audit_root/'run_provenance/complete_api_provenance_audit.json'
    save(original_path,original)
    result={'schema':'srd46-complete-in-place-run-provenance/v1','created':frozen.now(),'status':'passed',
        'canonical_root':str(root),'preparation_snapshot':str(snapshot),'continuation_root':str(audit_root),
        'preparation':{'audit':str(original_path),'sha256':sha(original_path),'HTTP_attempts':original['total_recorded_HTTP_attempts']},
        'continuation':{'audit':str(phase_path),'sha256':sha(phase_path),'HTTP_attempts':phase_audit['total_recorded_HTTP_attempts']},
        'total_unique_HTTP_attempts':original['total_recorded_HTTP_attempts']+phase_audit['total_recorded_HTTP_attempts'],
        'inherited_child_exchanges_excluded_from_continuation':phase_audit.get('inherited_nested_HTTP_attempts',0),
        'scope':'Original emitted preparation exchanges plus newly emitted continuation exchanges, each counted once; replayed and inherited exchanges are not new calls.',
        'original_preparation_receipts_preserved':True}
    path=root/'run_provenance/complete_run_api_provenance_audit.json';save(path,result)
    return {'path':str(path),'sha256':sha(path),'status':'passed','total_unique_HTTP_attempts':result['total_unique_HTTP_attempts']}

# Preserve the tested supervisor control flow; replace only adopted-result and
# storage lookup seams. It never moves a canonical run folder.
run_text=inspect.getsource(legacy.run)
changes={"result_path = HERE / 'worker_results' / f'{cid}.{phase}.json'":"result_path = result_path_for(cid, phase, row)",
         "result = read(result_path) if result_path.exists() else {}":"result = read_worker_result(result_path, cid, phase, row) if result_path.exists() else {}"}
for old,new in changes.items():
    if run_text.count(old)!=1:raise RuntimeError('Supervisor source seam changed')
    run_text=run_text.replace(old,new)
run_text=run_text.replace('def run(', 'def permanent_run(',1)
legacy.result_path_for=result_path_for;legacy.read_worker_result=read_worker_result
exec(compile(run_text,str(Path(__file__))+':permanent_run','exec'),legacy.__dict__)
legacy.run=legacy.permanent_run

@contextmanager
def one_dimensional_guard(enabled,root):
    if not enabled:yield;return
    import importlib
    pipeline=importlib.import_module('NIST_SRD46_db_agent.NIST_SRD46_analysis_agent.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api')
    original=pipeline.run_calculation;records=[]
    @wraps(original)
    def guarded(*args,**kwargs):
        path=kwargs.get('calc_input')
        try:row=validate_dimension(path)
        except BaseException as exc:
            records.append({'card':str(path),'status':'rejected','reason':str(exc)})
            save(root/'run_provenance/early_1d_solver_checks.json',records);raise EarlyDimensionViolation(str(exc))
        records.append({**row,'status':'accepted'});save(root/'run_provenance/early_1d_solver_checks.json',records)
        return original(*args,**kwargs)
    pipeline.run_calculation=guarded
    try:yield
    finally:pipeline.run_calculation=original

def worker(config_path,cid,phase,*,allow_model_calls=False):
    if phase!='resume':
        from continuation_modes import bind_fresh_native_load
        with bind_fresh_native_load(frozen):
            return base.worker(config_path,cid,phase,allow_model_calls=allow_model_calls)
    if not allow_model_calls:raise RuntimeError('Model execution disabled')
    config=read(config_path);spec=verify(config);base.validate_hold(spec)
    if (HERE/'STOP').exists():raise RuntimeError('Queue is held')
    validate_dispatch(read(legacy.STATE),spec,cid,phase)
    root=frozen.session_path(spec,cid);audit_root=phase_root(spec,cid,phase)
    if not io(root).is_dir() or io(audit_root).exists():raise RuntimeError('Canonical preparation missing or resume phase already exists')
    claims=HERE/'claims';claims.mkdir(exist_ok=True)
    with (claims/f'{cid}.resume.json').open('x',encoding='utf-8') as stream:json.dump({'pid':os.getpid(),'started':frozen.now()},stream)
    item=frozen.item_for(spec,cid);started=time.monotonic();handler=capture=proxy=model_context=transport_context=None;failure=None
    result_path=HERE/'worker_results'/f'{cid}.resume.json';result_path.parent.mkdir(exist_ok=True)
    state={'id':cid,'phase':'resume','pid':os.getpid(),'status':'starting','started':frozen.now(),'session_dir':str(root),
        'phase_provenance_root':str(audit_root),'fresh_native_run':False,'planned_prefix_reused':True,'authorization_reconstruction':False,
        'automatic_retry':False,'path_migration':spec.get('migrated_inputs',{}).get(cid),'spec_sha256':sha(SPEC),'stage_config_sha256':sha(config_path),'argo_user':spec['argo_user'],
        'output_owner':spec['output_owner'],'storage_mode':'permanent_canonical_roots','early_1d':early_eligible(spec,cid)}
    try:
        sys.path.insert(0,str(Path(spec['framework_root']).parent.parent));sys.path.insert(0,str(HERE))
        import staged_engine
        if base.canonical(staged_engine.__file__)!=base.canonical(HERE/'staged_engine.py'):raise RuntimeError('Wrong in-place stage engine loaded')
        from continuation_modes import prepare_continuation, execute_continuation
        snapshot, continuation_mode=prepare_continuation(spec,cid,root,audit_root,staged_engine)
        io(audit_root).mkdir(parents=True,exist_ok=False);provenance=audit_root/'run_provenance';io(provenance).mkdir()
        save(provenance/'launch_receipt.json',{**state,'item':item,'immutable_preparation_snapshot':str(snapshot),'code_fingerprint':spec['code_fingerprint']})
        io(provenance/'prompt.txt').write_text(item['prompt'],encoding='utf-8')
        sources=provenance/'source_version_transition';io(sources).mkdir()
        for source in (Path(__file__),HERE/'queue_base.py',HERE/'staged_engine.py',HERE/'in_place.py',HERE/'phase_provenance_audit.py',SPEC,base.CONFIG,HERE/'continuation_receipt.json'):
            shutil.copy2(io(source),io(sources/source.name))
        copy_runtime_sources(sources)
        handler=logging.FileHandler(io(audit_root/'_run.log'),mode='x',encoding='utf-8')
        logging.basicConfig(level=logging.DEBUG,format='%(asctime)s %(levelname)s %(name)s | %(message)s',handlers=[handler,logging.StreamHandler(sys.stdout)],force=True)
        for name in ('urllib3','httpx','httpcore','PIL','matplotlib','numba','pubchempy'):logging.getLogger(name).setLevel(logging.WARNING)
        frozen.set_account_environment(spec);os.environ['SRD46_ANALYSIS_SESSION_DIR']=str(root)
        from direct_transport.model_settings import scope as model_scope,effective_snapshot,write_settings_markdown
        model_context=model_scope(base.legacy.MODEL_SETTINGS,audit_root);model_receipt=model_context.__enter__()
        save(provenance/'explicit_model_settings.json',model_receipt);write_settings_markdown(provenance/'analysis_settings.md',model_receipt)
        transport_context=legacy.direct_transport(spec,audit_root);proxy=transport_context.__enter__()
        from fresh_native_capture import install as install_capture
        capture=install_capture(audit_root,framework_root=spec['framework_root'],capture_legacy_query=False,
            expected_argo_user=spec['argo_user'],on_authorization_denied=lambda message:frozen.authorization_hold(spec,cid,message))
        api,settings=frozen.load_native(spec,item);settings['effective_model_roles']=effective_snapshot();settings['explicit_model_settings']=model_receipt
        if any(settings['effective_model_roles'][key]!=model_receipt['settings'][key] for key in ('analysis','query')):raise RuntimeError('Model roles differ')
        save(provenance/'effective_settings.json',settings);state['status']='running';save(result_path,state)
        with one_dimensional_guard(state['early_1d'],audit_root):
            with execute_continuation(continuation_mode, snapshot, root, audit_root, staged_engine):
                result=api(item['prompt'],session_dir=root,debug=True,round_number=1,prev_context='',reconstruction_mode='regular',**item.get('api_overrides',{}))
        if not isinstance(result,dict):raise TypeError('Native result must be a dictionary')
        save(provenance/'native_api_result.json',result)
        state.update(status=frozen.completion_kind(result),native_completion_status=result.get('completion_status'),native_timed_out=result.get('timed_out'),native_verdict=result.get('verdict'))
        capture.assert_healthy();proxy.assert_healthy()
        state['native_api_coverage']=legacy.full_pair_audit(audit_root)
        from phase_provenance_audit import audit_run
        audit=audit_run(audit_root,expected_account=spec['argo_user']);save(provenance/'complete_api_provenance_audit.json',audit)
        if audit['status']!='passed_recorded_exchanges':raise RuntimeError('Complete phase provenance audit failed')
        state['physical_provider_coverage']=phase_physical_audit(audit,proxy,audit_root)
        state['complete_run_provenance']=combined_provenance(root,snapshot,audit_root,audit,spec['argo_user'])
        verify(config);state['framework_unchanged']=True
    except BaseException as exc:
        failure=exc;denied=frozen.is_authorization_interrupted(exc)
        if denied:state['authorization_hold']=frozen.authorization_hold(spec,cid,str(exc))
        state.update(status='authorization_blocked' if denied else 'failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        if capture is not None:
            try:capture.uninstall()
            except BaseException as exc:state.update(status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
        for context in (transport_context,model_context):
            if context is not None:
                try:context.__exit__(type(failure) if failure else None,failure,failure.__traceback__ if failure else None)
                except BaseException as exc:state.update(status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
        state.update(finished=frozen.now(),wall_elapsed_s=time.monotonic()-started)
        save(result_path,state)
        if io(audit_root/'run_provenance').exists():save(audit_root/'run_provenance/completion_receipt.json',state)
        save(root/'run_provenance/resume_completion_index.json',{'phase_root':str(audit_root),'complete_run_provenance':state.get('complete_run_provenance'),
            'preparation_snapshot':str(snapshot_source(spec,cid)),'result':state,'preparation_preserved':True,'canonical_root_moved':False})
        if handler is not None:logging.getLogger().removeHandler(handler);handler.close()
    return state
legacy.worker=worker

if __name__=='__main__':legacy.main()

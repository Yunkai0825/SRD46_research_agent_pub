"""Seal the existing-work continuation after offline path and replay acceptance."""
from datetime import datetime,timezone
from pathlib import Path
import argparse,copy,hashlib,json,os,sys
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as queue
M=HERE.parent/'path_migration_20261031'
PREVIOUS=queue.PREVIOUS
REPAIR='L2_1_CuZnNi_chelator_survey'
REPAIR_LEDGER='run_provenance/resume_attempt_001/run_provenance/first_principle_reconstruction/attempt_0001'
read=queue.read;sha=queue.sha;io=queue.io

def write_new(path,value):
    io(path).parent.mkdir(parents=True,exist_ok=True)
    with io(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

def bind(path):return {'path':str(path),'sha256':sha(path)}

def require_proof(path,*,repair=False):
    value=read(path)
    if value.get('status')!='passed' or any(value.get(key)!=0 for key in ('provider_calls','solver_calls','network_attempts')):
        raise RuntimeError('Offline native proof did not pass without new work: '+str(path))
    if value.get('native_source_fingerprint_verified') is not True:raise RuntimeError('Native proof lacks source validation')
    key='stages_repeated' if repair else 'native_scientific_stages_repeated'
    if value.get(key)!=0:raise RuntimeError('Offline proof repeated scientific stages')
    if repair and value.get('next_model_call_stopped_before_provider') is not True:raise RuntimeError('Corrected-read proof did not reach next model boundary')
    if not repair and value.get('saved_solver_boundary_reached') is not True:raise RuntimeError('Prepared proof did not reach saved solver boundary')
    return bind(path)

def build_documents(old_spec,old_state,migration,archive_plan,acceptance_binding,pending_date,native_roots=None):
    """Pure construction: historical process receipts are never current claims."""
    if len(migration['runs'])!=23:raise RuntimeError('All23 retained outputs must be migrated')
    by_original={queue.base.canonical(row['original_root']):row for row in migration['runs']}
    spec=copy.deepcopy(old_spec)
    spec.update(continuation_id='compact_paths_'+pending_date,session_suffix='',session_naming='debug_id_date',
        pending_folder_date=pending_date,pending_folder_date_meaning='Continuation campaign seal date; actual model launch timestamps remain in run provenance.',
        state_dir=str(HERE/'queue_state'),sealed_at=datetime.now(timezone.utc).isoformat(),
        prepared_inputs={},adopted_workers={},prior_storage={},preserved_superseded_preparations={},retained_complete={},
        migrated_inputs={},artifact_read_repairs={},migration_acceptance=acceptance_binding,
        execution_policy='Continue declared existing prefixes with strict replay; complete accepted 1D work early; at most two workers and one solver; 2D waits for drafts and preparations; FF_1 last; stop on failures or authorization denial.')
    spec['archived_history']={'previous_spec':bind(PREVIOUS/'spec.json'),'previous_state':bind(PREVIOUS/'state.json'),
        'original_preservation':bind(M/'authentic_original_archive_verification.json'),
        'obsolete_moves':[bind(HERE.parent/'obsolete_inventory_20261031'/name) for name in ('obsolete_move_plan.json','legacy_move_plan.json')],
        'scope':'Historical evidence only. These locations are not current worker dispatch or replay path aliases.'}
    state={'schema':'srd46-compact-path-continuation/v1','created':spec['sealed_at'],'status':'ready',
        'batch_id':spec['batch_id'],'continuation_id':spec['continuation_id'],'argo_user':spec['argo_user'],
        'items':{},'staged_state_file':str(HERE/'state.json'),'storage_mode':'permanent_canonical_roots',
        'previous_state':{'path':str(PREVIOUS/'state.json'),'sha256':sha(PREVIOUS/'state.json')},
        'launch_hold_reason':None}
    for cid,prior in old_state['items'].items():
        if prior['status'] not in {'prepared','partial','pending'}:raise RuntimeError('Unexpected predecessor state: '+cid)
        compact='_'.join(cid.split('_')[:2])
        if prior['status']=='pending':
            destination=str(Path(spec['output_root'])/(compact+'_'+pending_date))
            if io(destination).exists():raise RuntimeError('Pending destination already exists: '+destination)
            row={'status':'pending','phase':None,'launch_count':0,'session_dir':destination}
        else:
            migrated=by_original[queue.base.canonical(old_spec['session_paths'][cid])]
            destination=(native_roots or {}).get(cid,migrated['current_root'])
            if queue.base.canonical(destination)!=queue.base.canonical(migrated['current_root']):raise RuntimeError('Native spelling escapes compact root')
            binding={key:migrated[key] for key in ('archive_root','current_root','migration_receipt')}
            spec['migrated_inputs'][cid]=binding
            row={'status':'prepared','phase':'prepare','launch_count':0,'session_dir':destination,
                'prepared_source':destination,'source_validation':'accepted_transformed_prefix',
                'path_migration':binding,'preparation_repeated':False}
            spec['prepared_inputs'][cid]={'source':destination,'source_is_active_session':True,
                'preparation_receipt_sha256':sha(Path(destination)/'run_provenance/preparation_receipt.json'),
                'migration_receipt':binding['migration_receipt']}
            if prior['status']=='partial':
                if cid!=REPAIR:raise RuntimeError('Undeclared partial continuation')
                row.update(status='repair_ready',phase='resume',completed_solver_preserved=True)
                spec['artifact_read_repairs'][cid]={'source_ledger_relative':REPAIR_LEDGER,
                    'boundary_event_id':224,'completed_build_event_id':183,
                    'reason':'Continue at the first failed artifact read using the completed solver snapshot; no saved model or solver work is repeated.'}
        spec['session_paths'][cid]=destination
        state['items'][cid]=row
    if len(spec['migrated_inputs'])!=17 or len(state['items'])!=26:raise RuntimeError('Continuation scope is incomplete')
    return spec,state

def seal():
    for filename in ('spec.json','state.json','stage_config.json','continuation_receipt.json'):
        if (HERE/filename).exists():raise FileExistsError('Version already sealed: '+filename)
    old_spec=read(PREVIOUS/'spec.json');old_state=read(PREVIOUS/'state.json')
    if old_state['status']!='held' or any(row['status'] in {'starting','running'} for row in old_state['items'].values()):
        raise RuntimeError('Predecessor is not quiescent')
    if (PREVIOUS/'queue_state/runner.lock').exists():raise RuntimeError('Predecessor lock remains')
    supervisor=read(PREVIOUS/'supervisor_status.json')
    if queue.frozen.pid_alive(supervisor.get('pid')):
        import psutil
        try:command=psutil.Process(supervisor['pid']).cmdline()
        except psutil.NoSuchProcess:command=[]
        if any(queue.base.canonical(part)==queue.base.canonical(PREVIOUS/'staged_queue.py') for part in command if part.endswith('.py')):
            raise RuntimeError('The exact predecessor supervisor is still live')
    result_path=M/'production_migration/result.json';migration=read(result_path)
    if (migration.get('status')!='copied_verified_pending_acceptance' or migration.get('originals_modified') is not False
        or migration.get('runtime_aliases')!=[] or migration.get('provider_calls')!=0 or migration.get('solver_calls')!=0):
        raise RuntimeError('Production migration is incomplete')
    structural=M/'migrated_ledger_validation.json'
    proof=read(structural)
    if proof.get('status')!='passed' or proof.get('prepared_runs')!=16:raise RuntimeError('All prepared ledgers must pass deterministic validation')
    proofs={'prepared_native':require_proof(M/'L2_5_strict_offline_v2.json'),
        'artifact_read_native':require_proof(M/'L2_1_strict_read_repair_v3.json',repair=True),
        'all_prepared_ledgers':bind(structural),'ledger_validator':bind(M/'validate_migrated_ledgers.py'),
        'controller_offline_validation':bind(M/'v4_offline_validation.json')}
    if read(proofs['controller_offline_validation']['path']).get('status')!='passed':
        raise RuntimeError('Controller offline suite did not pass')
    if proof.get('validator_sha256')!=proofs['ledger_validator']['sha256']:
        raise RuntimeError('Ledger validator differs from accepted validation receipt')
    for row in migration['runs']:
        binding=row['migration_receipt']
        if sha(binding['path'])!=binding['sha256']:raise RuntimeError('Migration receipt changed')
        receipt=read(binding['path'])
        if receipt.get('transformed_root')!=row['current_root'] or receipt.get('original_root')!=row['archive_root']:
            raise RuntimeError('Migration root mismatch')
        if io(row['original_root']).exists():raise RuntimeError('Old operational path remains')
    queue.frozen.verify_code(old_spec)
    budget=queue.base.budget_state()
    acceptance={'schema':'srd46-compact-path-acceptance/v1','status':'passed','created':datetime.now(timezone.utc).isoformat(),
        'migration':bind(result_path),'proofs':proofs,'native_source_fingerprint_unchanged':True,
        'continuation_gate':'Every actual continuation still replays strictly and fails closed before new work if its saved prefix differs.',
        'runtime_path_aliases':[],'provider_calls':0,'solver_calls':0,'active_L1_11':'untouched'}
    write_new(HERE/'migration_acceptance.json',acceptance)
    archive_plan=read(M/'authentic_original_archive_plan.json')
    native_roots={}
    for checked in proof['runs']:
        declared=checked['planned_gate']['session_root'] if checked.get('kind')=='prepared' else checked['contract']['session_root']
        if queue.base.canonical(declared)!=queue.base.canonical(checked['current_root']):raise RuntimeError('Validated native root differs from compact root')
        native_roots[checked['id']]=declared
    spec,state=build_documents(old_spec,old_state,migration,archive_plan,bind(HERE/'migration_acceptance.json'),datetime.now().strftime('%Y%m%d'),native_roots)
    draft_spec=read(queue.base.DRAFT/'batch_spec.json')
    draft_state=read(Path(draft_spec['state_dir'])/'queue_state.json')
    migration_by_root={queue.base.canonical(row['original_root']):row for row in migration['runs']}
    draft_index={'schema':'srd46-completed-draft-locations/v1','runs':[]}
    for cid in read(queue.base.OLD/'split_plan.json')['draft_ids']:
        if cid==queue.legacy.DRAFT_LAST:continue
        migrated=migration_by_root[queue.base.canonical(draft_state['items'][cid]['session_dir'])]
        draft_index['runs'].append({'id':cid,**{key:migrated[key] for key in ('original_root','archive_root','current_root','migration_receipt')}})
    write_new(HERE/'completed_draft_locations.json',draft_index)
    spec['completed_draft_locations']=bind(HERE/'completed_draft_locations.json')
    write_new(HERE/'spec.json',spec)
    write_new(HERE/'state.json',state)
    config=copy.deepcopy(read(PREVIOUS/'stage_config.json'))
    config.update(spec=str(HERE/'spec.json'),spec_sha256=sha(HERE/'spec.json'),
        session_naming='debug_id_date',continuation_without_prefix_rerun=True)
    for path in HERE.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and not path.name.startswith('test_') and path.suffix in {'.py','.json','.md','.txt'}:
            if path.name not in {'state.json','stage_config.json','continuation_receipt.json'}:
                config['tool_sha256'][str(path)]=sha(path)
    write_new(HERE/'stage_config.json',config)
    receipt={'schema':'srd46-compact-path-continuation-seal/v1','created':spec['sealed_at'],
        'predecessor_spec':bind(PREVIOUS/'spec.json'),'predecessor_state':bind(PREVIOUS/'state.json'),
        'spec':bind(HERE/'spec.json'),'config':bind(HERE/'stage_config.json'),'migration_acceptance':spec['migration_acceptance'],
        'budget':budget,'existing_preparations':16,'completed_solver_read_repair':1,'pending':9,
        'saved_prefix_model_calls_repeated':0,'saved_solver_calls_repeated':0,'runtime_aliases':[],
        'active_L1_11_modified':False,'old_worker_claims_reused':False}
    write_new(HERE/'continuation_receipt.json',receipt)
    queue.verify(config)
    queue.publish_state(state,spec)
    return receipt

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seal',action='store_true');args=parser.parse_args()
    if not args.seal:raise SystemExit('Use --seal only after required proof receipts exist')
    print(json.dumps(seal(),indent=2))

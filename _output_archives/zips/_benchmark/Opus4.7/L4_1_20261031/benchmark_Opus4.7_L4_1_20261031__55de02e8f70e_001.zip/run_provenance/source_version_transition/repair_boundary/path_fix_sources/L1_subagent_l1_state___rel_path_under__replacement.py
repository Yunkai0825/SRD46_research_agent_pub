def _rel_path_under(path: Path, base: Path) -> str:
    try:
        return resolve_under(path, base)[1].as_posix()
    except Exception:
        return path.as_posix()

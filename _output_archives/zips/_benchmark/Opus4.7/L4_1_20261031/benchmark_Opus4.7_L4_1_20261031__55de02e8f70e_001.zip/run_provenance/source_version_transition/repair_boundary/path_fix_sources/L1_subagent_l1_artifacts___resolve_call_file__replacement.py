def _resolve_call_file(state: _L1State, relative_path: str) -> Optional[Path]:
    """Resolve one advertised output path without allowing directory escape."""

    call_base = Path(state.call_dir)
    rel = (relative_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return None
    candidates: List[Path] = []
    session_dir = _SESSION.get("session_dir")
    if session_dir is not None:
        candidates.append(Path(session_dir) / rel)
    candidates.append(call_base / rel)
    for candidate in candidates:
        try:
            candidate, _ = resolve_under(candidate, call_base)
        except ValueError:
            continue
        if candidate.exists() and candidate.is_file():
            return candidate
    return None

def _list_session_files(purpose: str = "", tasks: str = "") -> str:
    """Return a markdown listing of every file produced so far in this
    L0 session (per-call sub-dirs included)."""
    sess = _SESSION_DIR_REF["path"]
    if sess is None or not sess.exists():
        return "_(no session directory)_"
    rows = []
    filesystem_root=filesystem_path(sess)
    for p in sorted(filesystem_root.rglob("*")):
        relative = p.relative_to(filesystem_root)
        if tuple(part.lower() for part in relative.parts[:2]) == _RECONSTRUCTION_INTERNAL_PARTS:
            continue
        if p.is_file():
            rel = relative.as_posix()
            rows.append(f"- `{rel}` ({p.stat().st_size} bytes)")
    if not rows:
        return "_(no files yet)_"
    return f"# Session files (`{sess}`)\n\n" + "\n".join(rows)

def _list_solver_files(state: _LDState) -> List[Path]:
    files: List[Path] = []
    if state.solver_dir is not None and Path(state.solver_dir).exists():
        files.extend(
            p for p in sorted(Path(state.solver_dir).rglob("*")) if p.is_file()
        )
    for name in ("thermodynamic_reference_constants.md", "l1_report.md"):
        candidate = Path(state.call_dir) / name
        if candidate.is_file() and candidate not in files:
            files.append(candidate)
    return files

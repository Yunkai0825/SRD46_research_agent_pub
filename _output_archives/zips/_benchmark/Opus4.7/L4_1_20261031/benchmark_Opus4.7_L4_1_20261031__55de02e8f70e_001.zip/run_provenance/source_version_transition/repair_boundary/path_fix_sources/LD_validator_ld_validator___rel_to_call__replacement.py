def _rel_to_call(state: _LDState, p: Path) -> str:
    try:
        return resolve_under(p, state.call_dir)[1].as_posix()
    except Exception:
        return p.as_posix()

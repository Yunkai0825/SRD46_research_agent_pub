"""Explicit migrated preparation and completed-artifact-read continuations."""
from contextlib import contextmanager, ExitStack
from functools import wraps
import importlib
import os
from pathlib import Path

PREFIX = 'NIST_SRD46_db_agent.NIST_SRD46_analysis_agent'


def _helpers():
    from repair_boundary import repair_read_boundary as repair
    from repair_boundary.artifact_path_binding import artifact_path_fix
    return repair, artifact_path_fix


def prepare_continuation(spec, cid, root, audit_root, staged):
    rule = spec.get('artifact_read_repairs', {}).get(cid)
    if not rule:
        return staged.prepare_in_place_snapshot(root), {'kind': 'prepared'}
    repair, _ = _helpers()
    phase = audit_root.parent
    snapshot = repair.snapshot_completed_workspace(root, phase)
    source = snapshot / rule['source_ledger_relative']
    contract = repair.build_contract(source, root,
        boundary_event_id=rule['boundary_event_id'],
        completed_build_event_id=rule['completed_build_event_id'])
    return snapshot, {'kind': 'artifact_read_repair', 'contract': contract, 'phase': phase}


@contextmanager
def execute_continuation(mode, snapshot, root, audit_root, staged):
    repair, artifact_path_fix = _helpers()
    with ExitStack() as stack:
        if mode['kind'] == 'artifact_read_repair':
            actual = repair.rewind_completed_workspace(root, mode['phase'], contract=mode['contract'])
            if actual != audit_root:
                raise RuntimeError('Repair continuation capture path differs')
            def activate():
                stack.enter_context(artifact_path_fix(audit_root))
            with repair.install_read_repair(mode['contract'], provenance_root=audit_root,
                    before_live_read=activate) as control:
                yield control
        elif mode['kind'] == 'prepared':
            # Keep the historical prefix exact. Install the reader correction
            # only after strict replay crosses its first live solver boundary.
            pipeline = importlib.import_module(PREFIX + '.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api')
            original = pipeline.run_calculation
            active = False
            @wraps(original)
            def first_live_solver(*args, **kwargs):
                nonlocal active
                if not active:
                    stack.enter_context(artifact_path_fix(audit_root))
                    active = True
                return original(*args, **kwargs)
            pipeline.run_calculation = first_live_solver
            try:
                with staged.install('resume', snapshot, root, provenance_root=audit_root) as control:
                    yield control
            finally:
                pipeline.run_calculation = original
        else:
            raise ValueError('Unknown declared continuation kind')


@contextmanager
def bind_fresh_native_load(frozen):
    """Apply corrected readers to fresh native work after its real imports."""
    original = frozen.load_native
    with ExitStack() as stack:
        def load(spec, item):
            result = original(spec, item)
            _, artifact_path_fix = _helpers()
            root = Path(os.environ['SRD46_ANALYSIS_SESSION_DIR']).absolute()
            stack.enter_context(artifact_path_fix(root/'run_provenance/first_principle_reconstruction/path_fix_context'))
            return result
        frozen.load_native = load
        try:
            yield
        finally:
            frozen.load_native = original

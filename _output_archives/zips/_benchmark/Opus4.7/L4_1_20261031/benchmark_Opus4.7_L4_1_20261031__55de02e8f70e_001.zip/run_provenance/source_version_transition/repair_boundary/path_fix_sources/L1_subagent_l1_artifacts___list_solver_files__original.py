def _list_solver_files(state: _L1State) -> List[Path]:
    if state.solver_dir is None or not state.solver_dir.exists():
        return []
    return [path for path in sorted(state.solver_dir.rglob("*")) if path.is_file()]

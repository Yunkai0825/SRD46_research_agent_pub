def _rel_to_call(state: _LDState, p: Path) -> str:
    try:
        return p.resolve().relative_to(Path(state.call_dir).resolve()).as_posix()
    except Exception:
        return p.as_posix()

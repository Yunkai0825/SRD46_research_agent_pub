"""Audit saved Argo exchanges; never invoke a client or alter an audited run.

This validates the records that exist. It does not prove an uninstrumented
transport never ran. Root captures and MCP subprocess captures remain separate
inventories, with an explicit containing-query path for the latter.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re


def io_path(path):
    raw = str(Path(path).absolute())
    if os.name == 'nt' and not raw.startswith('\\\\?\\'):
        raw = '\\\\?\\UNC\\'+raw[2:] if raw.startswith('\\\\') else '\\\\?\\'+raw
    return Path(raw)


def read(path):
    return json.loads(io_path(path).read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def payload_digest(payload):
    return digest(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                             separators=(',', ':'), allow_nan=False).encode('utf-8'))


def relative(path, root):
    return Path(path).relative_to(root).as_posix()


def _error(errors, path, reason):
    errors.append({'file': str(path), 'reason': reason})


def _account(payload, expected, errors, file):
    if not isinstance(payload, dict):
        _error(errors, file, 'request_payload_not_object')
        return None
    account = str(payload.get('user', ''))
    if expected is not None and account != expected:
        _error(errors, file, 'account_mismatch')
    return account


def _flat_inventory(folder, run, expected):
    errors, records = [], []
    files = {p.name for p in io_path(folder).glob('*') if p.is_file()}
    stems = sorted({name.rsplit('.', 2)[0] for name in files
                    if name.endswith(('.request.json', '.receipt.json', '.response.txt'))})
    for stem in stems:
        req = folder / (stem+'.request.json')
        receipt = folder / (stem+'.receipt.json')
        row = {'request_file': relative(req, run), 'receipt_file': relative(receipt, run)}
        records.append(row)
        if not io_path(req).is_file() or not io_path(receipt).is_file():
            _error(errors, relative(req, run), 'orphan_or_missing_request_receipt')
            continue
        try:
            meta, payload = read(receipt), read(req)
            rb = io_path(req).read_bytes()
            account = _account(payload, expected, errors, relative(req, run))
            row.update(account=account, model=payload.get('model') if isinstance(payload, dict) else None,
                       request_sha256=digest(rb), request_payload_sha256=payload_digest(payload),
                       request_bytes=len(rb), status=meta.get('status'),
                       captured_lane=meta.get('lane'), captured_parent_ids=meta.get('parent_ids'),
                       captured_event_id=meta.get('id'), replayed=meta.get('replayed'))
            if meta.get('request_sha256') != digest(rb):
                _error(errors, row['request_file'], 'request_hash_mismatch_or_missing')
            if 'request_bytes' in meta and meta['request_bytes'] != len(rb):
                _error(errors, row['request_file'], 'request_byte_count_mismatch')
            if meta.get('request_file', req.name) != req.name:
                _error(errors, row['receipt_file'], 'request_filename_mismatch')
            if meta.get('status') == 'transport_exception':
                row['exception_type'] = meta.get('exception_type')
                if not row['exception_type']:
                    _error(errors, row['receipt_file'], 'transport_error_type_missing')
                if stem+'.response.txt' in files:
                    _error(errors, row['receipt_file'], 'transport_exception_has_unattributed_response')
                row['pair_complete'] = bool(row['exception_type'])
                continue
            if meta.get('status') != 'response_received':
                _error(errors, row['receipt_file'], 'request_not_completed')
                continue
            response = folder / (stem+'.response.txt')
            if meta.get('response_file') != response.name or not io_path(response).is_file():
                _error(errors, row['receipt_file'], 'response_missing_or_filename_mismatch')
                continue
            body = io_path(response).read_bytes()
            row.update(response_file=relative(response, run), response_sha256=digest(body),
                       response_bytes=len(body), http_status=meta.get('http_status'), pair_complete=True)
            if not isinstance(meta.get('http_status'), int):
                _error(errors, row['receipt_file'], 'http_status_missing_or_invalid')
            if meta.get('response_sha256') != digest(body):
                _error(errors, row['response_file'], 'response_hash_mismatch_or_missing')
            if 'response_bytes' in meta and meta['response_bytes'] != len(body):
                _error(errors, row['response_file'], 'response_byte_count_mismatch')
            if 'response_characters' in meta and meta['response_characters'] != len(body.decode('utf-8')):
                _error(errors, row['response_file'], 'response_character_count_mismatch')
        except (OSError, ValueError, TypeError, KeyError) as exc:
            _error(errors, row['request_file'], 'unreadable_record:'+type(exc).__name__)
    return {'directory': relative(folder, run), 'exchange_count': len(records),
            'completed_count': sum(r.get('pair_complete', False) for r in records),
            'saved_hashes_checked': True, 'errors': errors, 'records': records}


def _multiset(inventory, *, responses):
    result = Counter()
    for row in inventory['records']:
        if not row.get('pair_complete'):
            continue
        key = [row['request_payload_sha256']]
        if responses:
            key.extend([row.get('response_sha256'), row.get('http_status'), row.get('exception_type')])
        result[tuple(key)] += 1
    return result


def _query_link(turn, run):
    containing = None
    for parent in (turn, *turn.parents):
        if parent == run.parent:
            break
        if parent.parent.name == 'query_agents':
            containing = relative(parent, run)
            break
    manifest = turn/'runtime_manifest.json'
    scope = read(manifest).get('scope_id') if io_path(manifest).is_file() else None
    return {'containing_query_directory': containing,
            'query_turn_directory': relative(turn, run), 'captured_query_scope_id': scope,
            'attribution_basis': 'saved directory ancestry and optional native scope ID',
            'captured_parent_lane': None,
            'parent_lane_note': 'No parent lane is present in the nested HTTP capture schema; none inferred.'}


def _nested_inventory(folder, run, expected):
    errors, records = [], []
    try:
        link = _query_link(folder.parent, run)
    except (OSError, ValueError, TypeError) as exc:
        link = {'query_turn_directory': relative(folder.parent, run), 'captured_query_scope_id': None}
        _error(errors, relative(folder.parent, run), 'query_manifest_unreadable:'+type(exc).__name__)
    for child in sorted(io_path(folder).iterdir()):
        if not child.is_dir():
            continue
        attempt = folder/child.name
        req, response, failure = attempt/'request.json', attempt/'response.json', attempt/'error.json'
        row = {'request_file': relative(req, run), **link}
        records.append(row)
        try:
            request = read(req)
            payload = request.get('json')
            row.update(account=_account(payload, expected, errors, row['request_file']),
                       model=payload.get('model') if isinstance(payload, dict) else None,
                       request_payload_sha256=payload_digest(payload),
                       request_sha256=digest(io_path(req).read_bytes()),
                       method=request.get('method'), url=request.get('url'), timeout=request.get('timeout'))
            if io_path(response).is_file() == io_path(failure).is_file():
                _error(errors, relative(attempt, run), 'expected_exactly_one_response_or_transport_error')
                continue
            if io_path(failure).is_file():
                row.update(exception_type=read(failure).get('type'), status='transport_exception')
                row['pair_complete'] = bool(row['exception_type'])
                if not row['pair_complete']:
                    _error(errors, relative(failure, run), 'transport_error_type_missing')
                continue
            body = read(response)
            raw = base64.b64decode(body['body_base64'], validate=True)
            if not isinstance(body['body_text'], str):
                raise TypeError('response body_text is not text')
            row.update(response_file=relative(response, run), status='response_received',
                       response_record_sha256=digest(io_path(response).read_bytes()),
                       response_sha256=digest(body['body_text'].encode('utf-8')),
                       response_content_sha256=digest(raw), response_bytes=len(raw),
                       http_status=body.get('status_code'), pair_complete=True,
                       utf8_content_matches_text=(raw.decode('utf-8') == body['body_text']))
            if not row['utf8_content_matches_text']:
                _error(errors, row['response_file'], 'Argo_utf8_response_content_text_mismatch')
            if not isinstance(body.get('status_code'), int):
                _error(errors, row['response_file'], 'http_status_missing_or_invalid')
        except (OSError, ValueError, TypeError, KeyError) as exc:
            _error(errors, row['request_file'], 'unreadable_record:'+type(exc).__name__)
    return {'directory': relative(folder, run), **link, 'exchange_count': len(records),
            'completed_count': sum(r.get('pair_complete', False) for r in records),
            'saved_hashes_checked': False,
            'hash_note': 'Native nested schema has no saved digests; hashes here establish this audit snapshot, not a historical integrity baseline.',
            'errors': errors, 'records': records}


def _inherited_inventory(folder, run):
    """Validate content-addressed evidence, without recounting replayed calls."""
    errors, files = [], []
    manifest = folder/'inherited_provenance/manifest.json'
    if not io_path(manifest).is_file():
        return {'present': False, 'files': files, 'errors': errors, 'counted_HTTP_attempts': 0}
    try:
        data = read(manifest)
        if data.get('schema') != 'reconstruction-inherited-provenance/v1':
            raise ValueError('unsupported schema')
        for row in data['files']:
            checksum = row['sha256']
            if not isinstance(checksum, str) or not re.fullmatch('[a-f0-9]{64}', checksum):
                raise ValueError('unsafe object digest')
            obj = manifest.parent/'objects'/checksum
            content = io_path(obj).read_bytes()
            if digest(content) != checksum or len(content) != row['bytes']:
                _error(errors, relative(obj, run), 'inherited_object_integrity_failure')
            files.append({'source_identity': row['source_identity'], 'path': row['path'],
                          'sha256': checksum, 'bytes': len(content)})
    except (OSError, ValueError, TypeError, KeyError) as exc:
        _error(errors, relative(manifest, run), 'inherited_manifest_invalid:'+type(exc).__name__)
    return {'present': True, 'manifest': relative(manifest, run), 'files': files,
            'errors': errors, 'counted_HTTP_attempts': 0,
            'counting_note': 'Inherited evidence duplicates historical exchanges, never additional network calls.'}


def _audit_phase(provenance, run, expected_account):
    root = _flat_inventory(provenance/'native_api_calls', run, expected_account)
    errors = list(root['errors'])
    native = None
    mode = None
    inherited = None
    ancestry = {'scope': 'captured operation IDs only; missing IDs are not invented'}
    pointer = provenance/'first_principle_reconstruction/latest.json'
    try:
        ledger_name = read(pointer)['ledger']
        if not isinstance(ledger_name, str) or Path(ledger_name).name != ledger_name or ledger_name in ('.', '..'):
            raise ValueError('ledger pointer is not a child name')
        ledger = pointer.parent/ledger_name
        mode = read(ledger/'session.json').get('mode')
        inherited = _inherited_inventory(ledger, run)
        errors.extend(inherited['errors'])
        native = _flat_inventory(ledger/'calls', run, expected_account)
        errors.extend(native['errors'])
        events = [json.loads(line) for line in io_path(ledger/'events.jsonl').read_text(encoding='utf-8').splitlines() if line]
        starts = {e['sequence']: e for e in events if e.get('event') == 'started'}
        lanes = {e.get('lane') for e in starts.values() if e.get('name') == 'runtime.agent_enter'}
        ancestry['calls_without_parent_ids'] = sum(not r.get('captured_parent_ids') for r in native['records'])
        ancestry['calls_without_agent_entry_lane'] = sum(r.get('captured_lane') not in lanes for r in native['records'])
        unknown = [{'event_id': r.get('captured_event_id'), 'parent_ids': r.get('captured_parent_ids')}
                   for r in native['records'] if any(p not in starts for p in (r.get('captured_parent_ids') or []))]
        ancestry['unknown_parent_references'] = unknown
        if unknown:
            _error(errors, relative(ledger, run), 'unknown_parent_event_reference')
    except (OSError, ValueError, TypeError, KeyError) as exc:
        _error(errors, relative(pointer, run), 'native_ledger_unavailable_or_invalid:'+type(exc).__name__)
    cross = {'scope': 'root process only; nested MCP exchanges are counted separately', 'native_mode': mode}
    if native is not None and mode in ('regular', 'reconstruction'):
        compared = native
        if mode == 'reconstruction':
            if any(r.get('replayed') not in (True, False) for r in native['records']):
                _error(errors, relative(ledger, run), 'reconstruction_receipt_missing_replayed_flag')
            compared = dict(native, records=[r for r in native['records'] if r.get('replayed') is False])
            cross['comparison'] = 'current network captures vs non-replayed native exchanges; inherited prefix separately audited'
        cross.update(request_multisets_match=_multiset(root, responses=False) == _multiset(compared, responses=False),
                     request_response_multisets_match=_multiset(root, responses=True) == _multiset(compared, responses=True))
        if not cross['request_multisets_match'] or not cross['request_response_multisets_match']:
            _error(errors, 'run_provenance', 'root_native_exchange_inventory_mismatch')
    else:
        cross['comparison'] = 'not_applicable_without_supported_native_ledger'
        _error(errors, relative(provenance, run), 'unsupported_or_missing_native_mode')
    if not root['exchange_count']:
        _error(errors, relative(provenance/'native_api_calls', run), 'no_root_API_exchanges')
    return {'directory': relative(provenance, run), 'root': root, 'native_ledger': native,
            'root_native_comparison': cross, 'captured_ancestry': ancestry,
            'inherited_provenance': inherited, 'errors': errors}


def audit_run(run, expected_account=None):
    """Validate existing captures. Defaults account from the run's saved settings."""
    run = Path(run).absolute()
    provenance = run/'run_provenance'
    errors = []
    if expected_account is None:
        try:
            expected_account = read(provenance/'effective_settings.json')['effective_config']['API_USER']
            if not isinstance(expected_account, str) or not expected_account:
                raise ValueError('empty account')
        except (OSError, ValueError, TypeError, KeyError) as exc:
            _error(errors, 'run_provenance/effective_settings.json', 'expected_account_unavailable:'+type(exc).__name__)
    phases = [_audit_phase(provenance, run, expected_account)]
    prefix = provenance/'first_principle_reconstruction/staged_preparation'
    if io_path(prefix).is_dir():
        phases.insert(0, _audit_phase(prefix, run, expected_account))
    continuation = None
    claim_path=provenance/'staged_resume_claim.json'
    if io_path(claim_path).is_file():
        claim=read(claim_path)
        phase_root=Path(claim['provenance_root']).absolute()
        if (io_path(provenance).resolve() not in io_path(phase_root).resolve().parents
                or io_path(claim['session_root']).resolve()!=io_path(run).resolve()):
            raise ValueError('Continuation claim belongs to another canonical run')
        continuation=audit_run(phase_root,expected_account)
        phases.extend(continuation['provenance_phases'])
        errors.extend(continuation['errors'])
    for phase in phases:
        errors.extend(phase['errors'])
    nested, query_turns = [], []
    scan_root, historical_files = run, None
    binding_path = provenance/'staged_runtime/ledger_binding.json'
    if io_path(binding_path).is_file():
        binding = read(binding_path)
        scan_root = Path(binding['scientific_root']).absolute()
        snapshot = Path(binding['preparation_snapshot']).absolute()
        # Explicit stage binding, not a caller-selected search outside the run.
        if (io_path(scan_root/'run_provenance').resolve() not in io_path(run).resolve().parents
                or io_path(snapshot).resolve() != io_path(scan_root/'run_provenance/staged_preparation_snapshot').resolve()):
            raise ValueError('Continuation child-audit scope escapes its canonical run')
        anchor = read(scan_root/'run_provenance/staged_preparation_snapshot.json')
        manifest_path = snapshot/'_staged_snapshot_manifest.json'
        if digest(io_path(manifest_path).read_bytes()) != anchor['manifest_sha256']:
            raise ValueError('Continuation preparation manifest changed')
        historical_files = {row['path']:row['sha256'] for row in read(manifest_path)['files']}
    for directory, dirs, files in os.walk(io_path(scan_root), followlinks=False):
        dirs[:] = [name for name in dirs if name not in ('.git', '__pycache__')
                   and not ((historical_files is not None or continuation is not None) and name == 'run_provenance')]
        current = scan_root/Path(directory).relative_to(io_path(scan_root))
        if 'runtime_events.jsonl' in files:
            try:
                events = [json.loads(line) for line in io_path(current/'runtime_events.jsonl').read_text('utf-8').splitlines() if line]
                required = sum(e.get('kind') == 'tool_request' and e.get('payload', {}).get('tool') in ('0_plan_search_strategy', '0_preplan_decision') for e in events)
                observed = len(list(io_path(current/'mcp_http_calls').glob('*/request.json')))
                query_turns.append({**_query_link(current, scan_root), 'planner_tool_requests': required,
                                    'nested_http_attempts': observed})
                if required and observed < required:
                    _error(errors, relative(current, scan_root), 'planner_tool_requests_exceed_saved_HTTP_attempts')
            except (OSError, ValueError, TypeError) as exc:
                _error(errors, relative(current, scan_root), 'query_events_unreadable:'+type(exc).__name__)
        if Path(directory).name == 'mcp_http_calls':
            block = _nested_inventory(current, scan_root, expected_account)
            if historical_files is not None:
                for row in block['records']:
                    request = row['request_file']
                    inherited = request in historical_files
                    row['phase_attribution'] = 'inherited_preparation' if inherited else 'current_continuation'
                    if inherited:
                        attempt = (scan_root/request).parent
                        for name in ('request.json','response.json','error.json'):
                            path = attempt/name
                            key = relative(path,scan_root)
                            if io_path(path).is_file() and (key not in historical_files or
                                    digest(io_path(path).read_bytes()) != historical_files[key]):
                                _error(errors,key,'historical_nested_exchange_changed')
                block['inherited_HTTP_attempts'] = sum(r['phase_attribution']=='inherited_preparation' for r in block['records'])
                block['current_HTTP_attempts'] = len(block['records'])-block['inherited_HTTP_attempts']
            nested.append(block)
            errors.extend(block['errors'])
            dirs[:] = []
    # A copied nested folder can occur in both a preparation prefix and resumed
    # tree. Deduplicate only an explicitly identical native query invocation.
    seen_scopes = {}
    for block in nested:
        scope = block.get('captured_query_scope_id')
        signature = _multiset(block, responses=True)
        if scope and scope in seen_scopes:
            prior, prior_signature = seen_scopes[scope]
            if signature != prior_signature:
                _error(errors, block['directory'], 'duplicate_query_scope_has_different_HTTP_inventory')
            block['counted_HTTP_attempts'] = 0
            block['duplicate_of'] = prior
        else:
            if scope:
                seen_scopes[scope] = (block['directory'], signature)
            block['counted_HTTP_attempts'] = block.get('current_HTTP_attempts',block['exchange_count'])
    current = phases[-1]
    return {'schema': 'complete-api-provenance-audit/v1', 'created': datetime.now(timezone.utc).isoformat(),
            'run': str(run), 'expected_account': expected_account,
            'status': 'passed_recorded_exchanges' if not errors else 'failed',
            'scope': 'Existing root and nested native MCP captures; absence of all evidence for an uninstrumented route cannot be disproved.',
            **{k: current[k] for k in ('root', 'native_ledger', 'root_native_comparison', 'captured_ancestry')},
            'provenance_phases': phases, 'nested_query_turns': query_turns, 'nested_MCP': nested,
            'canonical_combined_audit':continuation is not None,
            'continuation_phase':{'run':continuation['run'],'status':continuation['status'],
                                  'current_HTTP_attempts':continuation['total_recorded_HTTP_attempts']}
                                 if continuation is not None else None,
            'nested_scientific_root':str(scan_root),
            'inherited_nested_HTTP_attempts':sum(b.get('inherited_HTTP_attempts',0) for b in nested),
            'child_root_scopes': [{k: b.get(k) for k in ('directory', 'containing_query_directory', 'query_turn_directory',
                                  'captured_query_scope_id', 'captured_parent_lane', 'counted_HTTP_attempts', 'duplicate_of')} for b in nested],
            'nested_route_observation': 'observed' if nested else 'not_exercised_or_not_recorded',
            'total_recorded_HTTP_attempts': sum(p['root']['exchange_count'] for p in phases) + sum(b['counted_HTTP_attempts'] for b in nested),
            'errors': errors, 'network_calls': 0, 'source_mutations': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--account', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    # Initial review outputs are kept outside the audited run. The orchestrator
    # can publish the returned dict separately after reviewing the utility.
    if args.output.resolve().is_relative_to(args.run.resolve()):
        parser.error('audit output must be outside the audited run')
    report = audit_run(args.run, args.account)
    io_path(args.output).parent.mkdir(parents=True, exist_ok=True)
    io_path(args.output).write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'HTTP_attempts': report['total_recorded_HTTP_attempts'],
                      'errors': len(report['errors']), 'output': str(args.output)}))
    raise SystemExit(0 if not report['errors'] else 1)


if __name__ == '__main__':
    main()

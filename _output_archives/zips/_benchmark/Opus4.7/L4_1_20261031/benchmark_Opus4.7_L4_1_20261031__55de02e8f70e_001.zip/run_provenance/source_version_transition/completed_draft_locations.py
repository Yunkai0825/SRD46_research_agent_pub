"""Verify compact locations of completed drafts without rewriting live contracts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re


def io(path):
    value = str(Path(path).absolute())
    if not value.startswith('\\\\?\\'):
        value = '\\\\?\\UNC\\' + value[2:] if value.startswith('\\\\') else '\\\\?\\' + value
    return Path(value)


def canonical(path):
    return str(io(path).resolve()).casefold()


def sha(path):
    with io(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(io(path).read_text('utf-8'))


def checked_document(binding):
    if not isinstance(binding, dict) or set(binding) != {'path', 'sha256'}:
        raise RuntimeError('Completed-draft document requires an exact path and digest binding')
    if sha(binding['path']) != binding['sha256']:
        raise RuntimeError('Completed-draft document digest differs')
    return read(binding['path'])


def load_completed_draft_receipts(spec, cid, historical_root):
    """Return (new root, completion, launch, original_launch).

    The caller retains the original scientific acceptance checks. No file is
    written, and no old path is redirected. The index itself must be bound in
    the sealed successor specification. Active L1_11 never uses this adapter.
    """
    index = checked_document(spec['completed_draft_locations'])
    if index.get('schema') != 'srd46-completed-draft-locations/v1':
        raise RuntimeError('Unsupported completed-draft location index')
    entries = index.get('runs')
    if not isinstance(entries, list):
        raise RuntimeError('Completed-draft location entries are missing')
    ids = [entry.get('id') for entry in entries]
    if len(ids) != len(set(ids)) or cid not in ids:
        raise RuntimeError('Completed-draft identity missing or duplicated')
    entry = entries[ids.index(cid)]
    original, archive, current = (Path(entry[key]).absolute() for key in
                                  ('original_root', 'archive_root', 'current_root'))
    if canonical(original) != canonical(historical_root):
        raise RuntimeError('Completed-draft historical root differs')
    if canonical(current.parent) != canonical(original.parent):
        raise RuntimeError('Completed draft left its canonical output parent')
    debug = re.match(r'^(L\d+_\d+)(?:_|$)', cid)
    date = re.search(r'_(\d{8})$', original.name)
    if not debug or not date or current.name != debug[1] + '_' + date[1]:
        raise RuntimeError('Completed draft does not have its compact ID and date')
    if len({canonical(original), canonical(archive), canonical(current)}) != 3:
        raise RuntimeError('Completed-draft original, archive and current roots must differ')
    if not io(archive).is_dir() or not io(current).is_dir() or io(original).exists():
        raise RuntimeError('Completed-draft archive/current transition is incomplete')
    migration = checked_document(entry['migration_receipt'])
    if migration.get('schema') != 'srd46-explicit-path-migration/v1':
        raise RuntimeError('Unsupported completed-draft migration receipt')
    if (canonical(migration['original_root']) not in {canonical(original), canonical(archive)}
            or canonical(migration['transformed_root']) != canonical(current)
            or migration.get('originals_modified') is not False
            or migration.get('runtime_aliases') != []
            or migration.get('provider_calls') != 0
            or migration.get('solver_calls') != 0):
        raise RuntimeError('Completed-draft migration identity or no-rerun contract differs')
    result = []
    original_launch = None
    for name in ('completion_receipt.json', 'launch_receipt.json'):
        relative = 'run_provenance/' + name
        files = [row for row in migration['files'] if row['path'].replace('\\', '/') == relative]
        if len(files) != 1 or files[0]['new_path'].replace('\\', '/') != relative:
            raise RuntimeError('Completed-draft receipt mapping is not unique')
        mapping = files[0]
        if sha(archive/relative) != mapping['sha256'] or sha(current/relative) != mapping['transformed_sha256']:
            raise RuntimeError('Completed-draft receipt bytes changed')
        old, new = read(archive/relative), read(current/relative)
        if (old.get('id') != cid or new.get('id') != cid
                or canonical(old['session_dir']) != canonical(original)
                or canonical(new['session_dir']) != canonical(current)):
            raise RuntimeError('Completed-draft receipt answer/root identity differs')
        for field in ('status', 'native_completion_status', 'native_timed_out',
                      'framework_unchanged', 'argo_user', 'pid'):
            if old.get(field) != new.get(field):
                raise RuntimeError('Completed-draft acceptance field changed: ' + field)
        result.append(new)
        if name == 'launch_receipt.json':
            original_launch = old
    # The derivative may reference a transformed copy of its original spec.
    # The caller must check actual launch-contract identity using this archived
    # original, never mistake the derivative's digest for an emitted run seal.
    return current, result[0], result[1], original_launch

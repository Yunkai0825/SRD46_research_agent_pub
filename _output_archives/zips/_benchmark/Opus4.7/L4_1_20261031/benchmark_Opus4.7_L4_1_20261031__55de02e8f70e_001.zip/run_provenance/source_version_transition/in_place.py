"""Verified snapshots and bounded replay rewind without relocating a run root."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil

SNAPSHOT = 'run_provenance/staged_preparation_snapshot'
MANIFEST = '_staged_snapshot_manifest.json'
ANCHOR = 'run_provenance/staged_preparation_snapshot.json'
CLAIM = 'run_provenance/staged_resume_claim.json'


def io(path):
    value = os.path.abspath(os.fspath(path))
    if os.name == 'nt' and not value.startswith('\\\\?\\'):
        value = '\\\\?\\UNC\\' + value[2:] if value.startswith('\\\\') else '\\\\?\\' + value
    return Path(value)


def digest(path):
    with io(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(io(path).read_text(encoding='utf-8'))


def write_new(path, value):
    io(path).parent.mkdir(parents=True, exist_ok=True)
    with io(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def _inside(path, root):
    resolved, parent = io(path).resolve(), io(root).resolve()
    if resolved == parent or parent not in resolved.parents:
        raise ValueError('Staged path must remain beneath its permanent run root')
    return resolved


def _inventory(root, excluded=()):
    root = io(root)
    ignored = [io(path) for path in excluded]
    files = []
    for path in sorted(root.rglob('*')):
        if any(path == prefix or prefix in path.parents for prefix in ignored):
            continue
        if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
            raise ValueError('Staged preparation contains a link: ' + str(path))
        if path.is_file():
            files.append({'path': path.relative_to(root).as_posix(),
                          'bytes': path.stat().st_size, 'sha256': digest(path)})
    return files


def _directories(root,excluded=()):
    root=io(root)
    ignored=[io(path) for path in excluded]
    return sorted(path.relative_to(root).as_posix() for path in root.rglob('*')
                  if path.is_dir() and not any(path==prefix or prefix in path.parents for prefix in ignored))


def verify_snapshot(snapshot, session_root):
    snapshot, root = Path(snapshot).absolute(), Path(session_root).absolute()
    _inside(snapshot, root)
    anchor = read(root / ANCHOR)
    if (anchor.get('schema') != 'srd46-in-place-preparation/v1'
            or anchor.get('session_root') != str(root)
            or anchor.get('snapshot') != str(snapshot)
            or anchor.get('manifest_sha256') != digest(snapshot / MANIFEST)):
        raise ValueError('Preparation snapshot identity or manifest changed')
    manifest = read(snapshot / MANIFEST)
    if manifest.get('session_root') != str(root):
        raise ValueError('Snapshot belongs to another logical run path')
    actual = _inventory(snapshot, [snapshot / MANIFEST])
    if actual != manifest.get('files') or _directories(snapshot)!=manifest.get('directories'):
        raise ValueError('Immutable preparation snapshot is incomplete or changed')
    return manifest


def prepare_in_place_snapshot(session_root):
    """Copy a complete, quiescent preparation under its unchanged run folder."""
    root = Path(session_root).absolute()
    snapshot = root / SNAPSHOT
    _inside(snapshot, root)
    if io(snapshot).exists():
        verify_snapshot(snapshot, root)
        return snapshot
    if io(root / ANCHOR).exists() or io(root / CLAIM).exists():
        raise FileExistsError('Existing staged-control evidence requires inspection')
    receipt = read(root / 'run_provenance/preparation_receipt.json')
    if receipt.get('status') != 'prepared' or receipt.get('numerical_solver_started') is not False:
        raise ValueError('Only a completed pre-solver preparation may be snapshotted')
    files = _inventory(root)
    directories = _directories(root)
    io(snapshot).mkdir(parents=True, exist_ok=False)
    for directory in directories:
        io(snapshot/directory).mkdir(parents=True,exist_ok=True)
    for row in files:
        source, target = root / row['path'], snapshot / row['path']
        _inside(source, root)
        _inside(target, snapshot)
        io(target).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(io(source), io(target))
        if digest(source) != row['sha256'] or digest(target) != row['sha256']:
            raise ValueError('Preparation changed while its immutable snapshot was copied')
    if _inventory(root, [snapshot]) != files or _directories(root,[snapshot])!=directories:
        raise ValueError('Preparation tree changed during snapshot creation')
    manifest = {'schema': 'srd46-preparation-snapshot/v1', 'session_root': str(root),
                'created_utc': datetime.now(timezone.utc).isoformat(), 'files': files,'directories':directories}
    write_new(snapshot / MANIFEST, manifest)
    write_new(root / ANCHOR, {'schema': 'srd46-in-place-preparation/v1',
                            'session_root': str(root), 'snapshot': str(snapshot),
                            'manifest_sha256': digest(snapshot / MANIFEST),
                            'original_root_relocated': False})
    verify_snapshot(snapshot, root)
    return snapshot


def rewind_in_place(session_root, snapshot, provenance_root):
    """Validate every terminal file, claim once, and clear only verified replay files.

    The permanent directory, old root provenance and open logs remain. Exact
    earlier scientific versions are restored by the strict replay engine;
    every removed version remains in the verified immutable snapshot.
    """
    root, snapshot, phase = map(lambda p: Path(p).absolute(), (session_root, snapshot, provenance_root))
    _inside(phase, root / 'run_provenance')
    if io(phase).resolve() == io(snapshot).resolve() or io(snapshot).resolve() in io(phase).resolve().parents:
        raise ValueError('Continuation provenance cannot be inside the immutable snapshot')
    if io(root / CLAIM).exists():
        raise FileExistsError('This preparation already has a resume claim; automatic repeat is forbidden')
    manifest = verify_snapshot(snapshot, root)
    current = _inventory(root, [snapshot, root / ANCHOR, phase])
    if current != manifest['files'] or _directories(root,[snapshot,phase])!=manifest['directories']:
        raise ValueError('Prepared workspace changed; refusing in-place replay rewind')
    rows = [row for row in manifest['files']
            if not row['path'].startswith('run_provenance/')
            and row['path'] not in {'_run.log', 'worker_console.log'}]
    # Claim and receipt are durable before any mutable working file is changed.
    write_new(root / CLAIM, {'schema': 'srd46-staged-resume-claim/v1', 'pid': os.getpid(),
                           'session_root': str(root), 'provenance_root': str(phase),
                           'snapshot_manifest_sha256': digest(snapshot / MANIFEST),
                           'created_utc': datetime.now(timezone.utc).isoformat()})
    receipt = {'schema': 'srd46-verified-replay-rewind/v1', 'session_root': str(root),
               'snapshot': str(snapshot), 'files': rows, 'root_relocated': False,
               'historical_provenance_modified': False,
               'rewound_scientific_directories':[path for path in manifest['directories']
                   if path!='run_provenance' and not path.startswith('run_provenance/')],
               'explanation': 'Verified working versions retained in immutable snapshot; replay restores exact prior versions.'}
    write_new(phase / 'run_provenance/rewind_receipt.json', receipt)
    for row in rows:
        path = root / row['path']
        _inside(path, root)
        if digest(path) != row['sha256']:
            raise ValueError('Prepared file changed during verified rewind: ' + row['path'])
        io(path).unlink()
    # Native dispatch allocates call indices from directory names. Rewind the
    # verified-empty scientific namespace as well; the permanent run root and
    # its historical provenance never move. No recursive deletion is used.
    for relative in sorted(receipt['rewound_scientific_directories'],key=lambda p:len(Path(p).parts),reverse=True):
        path=root/relative
        _inside(path,root)
        io(path).rmdir()
    verify_snapshot(snapshot, root)
    return receipt

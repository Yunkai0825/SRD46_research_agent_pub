def _resolve_call_file(state: _L1State, relative_path: str) -> Optional[Path]:
    """Resolve one advertised output path without allowing directory escape."""

    call_base = Path(state.call_dir).resolve()
    rel = (relative_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return None
    candidates: List[Path] = []
    session_dir = _SESSION.get("session_dir")
    if session_dir is not None:
        candidates.append((Path(session_dir) / rel).resolve())
    candidates.append((call_base / rel).resolve())
    for candidate in candidates:
        try:
            candidate.relative_to(call_base)
        except ValueError:
            continue
        if candidate.exists() and candidate.is_file():
            return candidate
    return None

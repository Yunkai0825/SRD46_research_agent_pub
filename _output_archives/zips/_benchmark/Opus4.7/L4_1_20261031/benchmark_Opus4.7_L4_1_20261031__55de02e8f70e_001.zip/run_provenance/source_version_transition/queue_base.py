"""Versioned continuation of the direct-provider queue; scientific code is unchanged here."""
from __future__ import annotations
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import uuid

HERE=Path(__file__).absolute().parent
OLD=Path(r'<PROJECT_ROOT>\tmp\srd46_direct_anthropic_20261030')
DRAFT=Path(r'<PROJECT_ROOT>\tmp\srd46_provenance_refresh_20261030')
INSTALL=HERE.parent/'revision3/maintenance_ready'
SUCCESSOR=HERE.parent/'revision3/campaign_transition/contracts/native_delta_20261030_211737_996bb802'
FIRST=['L2_1_CuZnNi_chelator_survey']
sys.path.insert(0,str(OLD))
sys.path.insert(0,str(OLD/'provenance_gap_audit'))
sys.path.insert(0,str(HERE))
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module
legacy=load('original_direct_staged_queue',OLD/'staged_handover/staged_queue.py')
frozen=legacy.frozen
transition=load('continuation_delta_contract',HERE.parent/'revision3/campaign_transition/successor.py')
legacy.HERE=HERE;legacy.CONFIG=HERE/'stage_config.json';legacy.STATE=HERE/'state.json'
read=legacy.read;sha=frozen.sha;save_original=legacy.save
CONFIG=legacy.CONFIG
_session_path=frozen.session_path
def canonical(path):return os.path.normcase(str(Path(frozen.filesystem_path(path)).resolve()))
def io(path):return Path(frozen.filesystem_path(path))
def safe_child(path,parent):
    original=Path(path).absolute()
    resolved=io(original).resolve();root=io(parent).resolve()
    if resolved==root or root not in resolved.parents:raise ValueError('Path outside designated root: '+str(path))
    return original
legacy.safe_child=safe_child
def session_path(spec,cid):
    if 'session_paths' in spec:return safe_child(spec['session_paths'][cid],spec['output_root'])
    return _session_path(spec,cid)
frozen.session_path=session_path

def budget_state():
    config=read(legacy.TRANSPORT_CONFIG);db=Path(config['budget_db'])
    if not io(db).is_file():raise RuntimeError('Shared budget ledger absent; no replacement permitted')
    uri=db.as_uri()
    if uri.startswith('file://') and not uri.startswith('file:///'):uri='file:////'+uri[len('file://'):]
    with sqlite3.connect(uri+'?mode=ro',uri=True) as conn:
        policy=conn.execute('SELECT fingerprint,value,hold_reason FROM policy WHERE id=1').fetchone()
        totals=conn.execute('SELECT COUNT(*),COALESCE(SUM(actual_micro),0),COALESCE(SUM(outstanding_micro),0) FROM reservations').fetchone()
    if not policy:raise RuntimeError('Shared budget policy absent')
    result={'config_sha256':sha(legacy.TRANSPORT_CONFIG),'policy_fingerprint':policy[0],
        'hold_reason':policy[2],'reservation_count':totals[0],'charged_usd':totals[1]/1e6,
        'outstanding_usd':totals[2]/1e6,'available_usd':config['maximum_usd']-(totals[1]+totals[2])/1e6,
        'maximum_usd':config['maximum_usd'],'expiry_utc':config['local_expiry_utc'],'budget_db':str(db)}
    if result['hold_reason'] or result['available_usd']<=0:raise RuntimeError('Existing budget is held or exhausted')
    if datetime.now(timezone.utc)>=datetime.fromisoformat(result['expiry_utc']):raise RuntimeError('Existing credential authorization expired')
    return result

def validate_ownership(spec):
    old=read(OLD/'batch_spec.json');plan=read(OLD/'split_plan.json')
    if spec['items']!=old['items']:raise RuntimeError('Exact 25 numbered prompts plus FF1 changed')
    for key in ('batch_id','argo_user','output_owner','output_root','framework_root','runner_fingerprint'):
        if spec[key]!=old[key]:raise RuntimeError('Original ownership/settings changed: '+key)
    if sha(plan['original_spec'])!=plan['original_spec_sha256']:raise RuntimeError('Original draft contract changed')
    if canonical(spec['state_dir'])!=canonical(HERE/'queue_state'):raise RuntimeError('Continuation state escaped its private root')
    if not (OLD/'staged_handover/STOP').is_file():raise RuntimeError('Original suspended queue hold is absent')
    ids={row['id'] for row in spec['items']}
    if len(ids)!=26 or ids!=set(spec['session_paths']):raise RuntimeError('Incomplete per-answer output map')
    paths=[canonical(session_path(spec,cid)) for cid in ids]
    if len(paths)!=len(set(paths)):raise RuntimeError('Duplicate output identity')
    original_draft=read(plan['original_spec'])
    reserved={canonical(_session_path(original_draft,cid)) for cid in plan['draft_ids']}
    if reserved.intersection(paths):raise RuntimeError('Continuation overlaps a draft output')
    for cid in ids:
        claim=read(Path(original_draft['state_dir'])/'claims'/(cid+'.json'))
        if (claim.get('reservation_only') is not True or claim.get('owner_batch_id')!=old['batch_id']
            or claim.get('id')!=cid or claim.get('argo_user')!=old['argo_user']):
            raise RuntimeError('Original exclusive ownership reservation changed: '+cid)
legacy.validate_split_ownership=validate_ownership
def validate_hold(spec):
    validate_ownership(spec)
    if (Path(spec['state_dir'])/'authorization_hold.json').exists():raise RuntimeError('Continuation authorization hold is active')
legacy.validate_original_hold=validate_hold

def verify(config):
    if sha(config['spec'])!=config['spec_sha256']:raise RuntimeError('Continuation specification changed')
    spec=frozen.validate_spec(read(config['spec']))
    frozen.verify_code(spec)
    for name,digest in config['tool_sha256'].items():
        if sha(name)!=digest:raise RuntimeError('Continuation dependency changed: '+name)
    validate_ownership(spec);legacy.validate_transport_config(spec)
    if spec['code_fingerprint']!=read(SUCCESSOR/'spec.json')['code_fingerprint']:raise RuntimeError('Current native version differs from authorized successor')
    transition.compare_delta(read(OLD/'batch_spec.json')['code_fingerprint'],spec['code_fingerprint'],
                             read(INSTALL/'manifest.json'),read(INSTALL/'installation_receipt.json'))
    budget_state()
    return spec
legacy.verify=verify

def drafts_ready(spec):
    """Five original completions, honest changed-source L1_10, versioned L1_11."""
    old=read(DRAFT/'batch_spec.json');state=read(Path(old['state_dir'])/'queue_state.json')
    plan=read(OLD/'split_plan.json');last=legacy.DRAFT_LAST;before=transition.PREDECESSOR
    for cid in plan['draft_ids']:
        if cid==last:continue
        row=state['items'][cid]
        if row['status']!='complete':return False
        from completed_draft_locations import load_completed_draft_receipts
        session, completion, launch, original_launch = load_completed_draft_receipts(spec, cid, row['session_dir'])
        if completion.get('status')!='complete' or completion.get('native_completion_status')!='complete':return False
        if completion.get('native_timed_out') is not False:return False
        for receipt in (completion,launch):
            if (receipt.get('id')!=cid or receipt.get('argo_user')!=old['argo_user']
                or canonical(receipt['session_dir'])!=canonical(session)):
                raise RuntimeError('Original draft receipt identity differs: '+cid)
        # Retained fresh sessions predate this queue; their adopted receipts are kept.
        if cid not in frozen.RETAINED and original_launch.get('spec_sha256')!=sha(DRAFT/'batch_spec.json'):
            raise RuntimeError('Original draft source contract differs: '+cid)
        if cid==before and completion.get('framework_unchanged') is not False:
            raise RuntimeError('L1_10 historical changed-on-disk flag must be retained')
        if frozen.pid_alive(completion.get('pid')):return False
    if (Path(old['state_dir'])/'runner.lock').exists():return False
    pointer=read(DRAFT/'CURRENT_SUCCESSOR.json')
    if canonical(pointer['contract'])!=canonical(SUCCESSOR):raise RuntimeError('Draft successor ownership changed')
    index=SUCCESSOR/'completion_index.json'
    if not index.exists():return False
    result=read(index)['successor_result']
    if result.get('status')!='complete' or result.get('native_completion_status')!='complete' or result.get('native_timed_out') is not False:return False
    if (result.get('id')!=last or result.get('spec_sha256')!=sha(SUCCESSOR/'spec.json')
        or result.get('argo_user')!=old['argo_user'] or result.get('framework_unchanged') is not True):
        raise RuntimeError('Versioned L1_11 completion identity differs')
    if frozen.pid_alive(result.get('pid')) or (SUCCESSOR/'state/runner.lock').exists():return False
    if read(Path(result['session_dir'])/'run_provenance/completion_receipt.json')!=result:
        raise RuntimeError('L1_11 completion copies differ')
    transition.compare_delta(old['code_fingerprint'],spec['code_fingerprint'],read(INSTALL/'manifest.json'),read(INSTALL/'installation_receipt.json'))
    return True
legacy.drafts_ready=drafts_ready

def prepared_path(spec,cid):
    retained=spec['prepared_inputs'].get(cid)
    target=HERE/'prepared'/cid
    if retained and retained['source_is_active_session']:
        return target if io(target).exists() else Path(retained['source'])
    return Path(retained['source']) if retained else target

def initialize_state(spec):
    validate_ownership(spec)
    items={}
    for item in sorted(spec['items'],key=lambda row:(FIRST.index(row['id']) if row['id'] in FIRST else 2,row.get('priority',100),spec['items'].index(row))):
        cid=item['id'];existing=spec['prepared_inputs'].get(cid)
        items[cid]={'status':'recorded_prepared' if existing else 'pending','phase':'prepare' if existing else None,
            'launch_count':0,'session_dir':str(session_path(spec,cid))}
        if existing:items[cid].update(prepared_source=existing['source'],source_validation='awaiting_answer_specific_compatibility',preparation_repeated=False)
    for cid, retained in spec.get('retained_complete',{}).items():
        items[cid].update(retained)
    return {'schema':'srd46-versioned-direct-continuation/v1','created':frozen.now(),'status':'ready',
        'batch_id':spec['batch_id'],'continuation_id':spec['continuation_id'],'argo_user':spec['argo_user'],
        'items':items,'staged_state_file':str(legacy.STATE)}
legacy.initialize_state=initialize_state

def choose_phase(state):
    rows=state['items']
    if any(row['status'] in legacy.TERMINAL-{'complete'} for row in rows.values()):return 'held',[]
    active=[row for row in rows.values() if row['status'] in {'starting','running'}]
    pending=[cid for cid,row in rows.items() if row['status']=='pending' and cid!=frozen.FF1]
    if pending:return 'prepare',pending[:max(0,2-len(active))]
    if active:return 'waiting',[]
    if any(row['status']=='recorded_prepared' for row in rows.values()):return 'waiting_source_validation',[]
    return _choose_phase(state)
_choose_phase=legacy.choose_phase;legacy.choose_phase=choose_phase

def apply_compatibility(state,spec):
    for cid,row in state['items'].items():
        if row['status']!='recorded_prepared':continue
        path=HERE/'compatibility'/(cid+'.json')
        if not path.exists():continue
        receipt=read(path)
        if receipt.get('status')!='accepted':continue
        expected=spec['prepared_inputs'][cid]
        if (receipt.get('schema')!='srd46-prepared-source-compatibility/v1' or receipt.get('id')!=cid
            or receipt.get('current_spec_sha256')!=sha(CONFIG.parent/'spec.json')
            or canonical(receipt['source'])!=canonical(expected['source'])
            or receipt.get('source_preparation_receipt_sha256')!=expected['preparation_receipt_sha256']
            or not receipt.get('evidence') or receipt.get('solver_reexecution_before_boundary') is not False):
            raise RuntimeError('Prepared compatibility decision is incomplete: '+cid)
        for evidence in receipt['evidence']:
            if sha(evidence['path'])!=evidence['sha256']:raise RuntimeError('Compatibility evidence changed: '+cid)
        row.update(status='prepared',source_validation='accepted',compatibility_receipt=str(path),compatibility_sha256=sha(path))
_publish=legacy.publish_state
def publish_state(state,spec):apply_compatibility(state,spec);return _publish(state,spec)
legacy.publish_state=publish_state

_save=save_original
def save(path,value):
    _save(path,value)
    if Path(path).name=='launch_receipt.json' and value.get('stage_config_sha256'):
        target=Path(path).parent/'source_version_transition';target.mkdir(exist_ok=False)
        sources=[Path(__file__),CONFIG,HERE/'spec.json',HERE/'continuation_receipt.json',INSTALL/'manifest.json',INSTALL/'installation_receipt.json']
        sources.extend(path for path in (HERE/'clean_transition.py',HERE/'transition_plan.json') if path.exists())
        for source in sources:
            shutil.copy2(io(source),io(target/source.name))
legacy.save=save
_worker=legacy.worker
def worker(config_path,cid,phase,*,allow_model_calls=False):
    if not allow_model_calls:raise RuntimeError('Model execution disabled')
    spec=verify(read(config_path))
    validate_hold(spec)
    if (HERE/'STOP').exists():raise RuntimeError('Continuation is explicitly held')
    if phase not in {'prepare','resume','direct'} or ((cid==frozen.FF1)!=(phase=='direct')):
        raise ValueError('Invalid item/phase selection')
    legacy.validate_dispatch(read(legacy.STATE),spec,cid,phase)
    if (HERE/'claims'/f'{cid}.{phase}.json').exists():raise RuntimeError('This phase was already claimed; no automatic retry')
    if phase=='resume':
        row=read(legacy.STATE)['items'][cid]
        if cid in spec['prepared_inputs']:
            if row.get('source_validation')!='accepted':raise RuntimeError('Imported preparation is not accepted for this source version')
            if sha(row['compatibility_receipt'])!=row['compatibility_sha256']:raise RuntimeError('Prepared acceptance changed after dispatch')
        source=prepared_path(spec,cid);session=session_path(spec,cid)
        if cid in spec['prepared_inputs'] and sha(source/'run_provenance/preparation_receipt.json')!=spec['prepared_inputs'][cid]['preparation_receipt_sha256']:
            raise RuntimeError('Accepted preparation receipt changed')
        if canonical(source)==canonical(session):
            target=safe_child(HERE/'prepared'/cid,HERE/'prepared')
            if io(target).exists():raise FileExistsError('Prepared archive already exists')
            if sha(source/'run_provenance/preparation_receipt.json')!=spec['prepared_inputs'][cid]['preparation_receipt_sha256']:
                raise RuntimeError('Accepted preparation bytes changed')
            target.parent.mkdir(exist_ok=True)
            io(source).rename(io(target))
            save(HERE/'prepared'/(cid+'.relocation.json'),{'source':str(source),'archive':str(target),'time':frozen.now(),
                'reason':'Exact original session spelling is required by planned-prefix replay','bytes_modified':False})
    # Legacy worker selects HERE/prepared/ID. A scoped Path hook is unnecessary:
    # only its prepared-source expression is substituted in an unchanged function body.
    return _worker(config_path,cid,phase,allow_model_calls=allow_model_calls)
legacy.worker=worker

# Preserve the tested worker logic and explicitly substitute only prepared lookup.
import inspect
worker_text=inspect.getsource(_worker)
lookup="archived = safe_child(HERE / 'prepared' / cid, HERE / 'prepared')"
if worker_text.count(lookup)!=1:raise RuntimeError('Original worker archive lookup changed')
worker_text=worker_text.replace('def worker(', 'def retained_worker(',1).replace(lookup,'archived = prepared_path(spec, cid)')
legacy.prepared_path=prepared_path
exec(compile(worker_text,str(Path(__file__))+':retained_worker','exec'),legacy.__dict__)
_worker=legacy.retained_worker

def seal():
    raise RuntimeError('Use the versioned clean_transition waiter; direct resealing is prohibited')

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='seal':print(json.dumps(seal(),indent=2))
    elif len(sys.argv)>1 and sys.argv[1]=='preflight':print(json.dumps({'verified':bool(verify(read(CONFIG))),'budget':budget_state()},indent=2))
    else:legacy.main()

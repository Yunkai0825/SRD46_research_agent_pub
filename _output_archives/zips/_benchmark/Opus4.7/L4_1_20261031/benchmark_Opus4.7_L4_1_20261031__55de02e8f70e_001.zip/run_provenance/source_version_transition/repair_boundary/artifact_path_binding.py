"""Checked process-local artifact reader fix; native source files never change."""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import importlib
import importlib.util
import inspect
import json
import marshal
from pathlib import Path
import sys

HERE=Path(__file__).absolute().parent
PREFIX='NIST_SRD46_db_agent.NIST_SRD46_analysis_agent'
PKG=PREFIX+'.analysis_agent_orchestration'


def _hash(data):return hashlib.sha256(data).hexdigest()


def _read(path,expected):
    data=path.read_bytes()
    if _hash(data)!=expected:raise RuntimeError('Path-fix source changed: '+path.name)
    return data.decode('utf-8')


@contextmanager
def artifact_path_fix(provenance_root):
    """Bind tested readers for this worker, including imported function aliases.

    For a mid-run repair, enter only in the read-boundary callback. New workers
    may enter before invoking native execution. The evidence visibility guard
    composes in either order and retains its existing scope.
    """
    paths=importlib.import_module('NIST_SRD46_db_agent.general_db_query_engine.general_first_principle_API_call_reconstruct.paths')
    folder=paths.filesystem_path(Path(provenance_root)/'run_provenance/artifact_path_runtime')
    folder.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((HERE/'path_fix_sources/manifest.json').read_text('utf-8'))
    helper_name=PKG+'.artifact_paths'
    old_helper=sys.modules.get(helper_name)
    helper_source=_read(HERE/'path_fix_sources/artifact_paths.py',manifest['helper_sha256'])
    helper_file=folder/'artifact_paths.py'
    helper_file.write_text(helper_source,encoding='utf-8')
    helper_spec=importlib.util.spec_from_file_location(helper_name,helper_file)
    helper=importlib.util.module_from_spec(helper_spec)
    sys.modules[helper_name]=helper
    helper_spec.loader.exec_module(helper)
    replacements=[]
    receipts=[]
    changes=[]
    try:
        for row in manifest['modules']:
            module=importlib.import_module(PKG+'.'+row['module'])
            originals={name:getattr(module,name) for name in row['functions']}
            namespace={}
            parts=[]
            for name,function in originals.items():
                namespace.update(function.__globals__)
                pair=row['functions'][name]
                expected=_read(HERE/'path_fix_sources'/pair['original_file'],pair['original_sha256'])
                replacement=_read(HERE/'path_fix_sources'/pair['replacement_file'],pair['replacement_sha256'])
                try:
                    if function.__code__.co_filename.endswith(':'+name):
                        raise OSError('Synthetic staged wrapper requires its recorded source')
                    actual=inspect.getsource(function)
                except (OSError,TypeError):
                    # Older staged wrappers record source files but compile
                    # with a synthetic filename. Bind those bytes to the
                    # actual code object before composing a second wrapper.
                    saved=paths.filesystem_path(Path(provenance_root)/'run_provenance/staged_runtime'/(name+'_phase.py'))
                    if name not in {'_list_session_files','_read_session_file'} or not saved.is_file():
                        raise RuntimeError('Loaded artifact function has no verifiable source: '+name)
                    actual=saved.read_text('utf-8')
                    probe=dict(function.__globals__)
                    exec(compile(actual,function.__code__.co_filename,'exec'),probe)
                    if marshal.dumps(probe[name].__code__)!=marshal.dumps(function.__code__):
                        raise RuntimeError('Saved staged wrapper differs from its live code: '+name)
                needle='tuple(part.lower() for part in relative.parts[:2]) == _RECONSTRUCTION_INTERNAL_PARTS'
                if actual not in (expected,replacement):
                    if (name not in {'_list_session_files','_read_session_file'} or expected.count(needle)!=1
                            or actual not in {expected.replace(needle,'_STAGED_INTERNAL(relative)'),
                                              replacement.replace(needle,'_STAGED_INTERNAL(relative)')}):
                        raise RuntimeError('Loaded native artifact function differs from checked baseline: '+name)
                    if replacement.count(needle)!=1:
                        raise RuntimeError('Replacement lost the existing evidence guard')
                    replacement=replacement.replace(needle,'_STAGED_INTERNAL(relative)')
                parts.append(replacement)
                receipts.append({'module':module.__name__,'function':name,
                    'loaded_sha256':_hash(actual.encode()),'replacement_sha256':_hash(replacement.encode())})
            namespace.update(resolve_under=helper.resolve_under,filesystem_path=helper.filesystem_path)
            generated='\n\n'.join(parts)
            generated_file=folder/(row['module'].replace('.','_')+'.py')
            generated_file.write_text(generated,encoding='utf-8')
            exec(compile(generated,str(generated_file),'exec'),namespace)
            replacements.extend((old,namespace[name]) for name,old in originals.items())
        for module_name,module in tuple(sys.modules.items()):
            if not module_name.startswith(PREFIX) or module is None:continue
            for name,value in tuple(vars(module).items()):
                for old,new in replacements:
                    if value is old:
                        changes.append((module,name,old,new))
                        setattr(module,name,new)
                        break
        receipt={'schema':'srd46-artifact-path-runtime-binding/v1','native_files_modified':False,
                 'manifest_sha256':_hash((HERE/'path_fix_sources/manifest.json').read_bytes()),
                 'functions':receipts,'alias_bindings':len(changes)}
        (folder/'binding_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
        yield receipt
    finally:
        for module,name,old,new in reversed(changes):
            # A surrounding staged context can already have restored its own
            # visibility wrapper; never replace that owner's restoration.
            if getattr(module,name,None) is new:setattr(module,name,old)
        if sys.modules.get(helper_name) is helper:
            if old_helper is None:sys.modules.pop(helper_name,None)
            else:sys.modules[helper_name]=old_helper

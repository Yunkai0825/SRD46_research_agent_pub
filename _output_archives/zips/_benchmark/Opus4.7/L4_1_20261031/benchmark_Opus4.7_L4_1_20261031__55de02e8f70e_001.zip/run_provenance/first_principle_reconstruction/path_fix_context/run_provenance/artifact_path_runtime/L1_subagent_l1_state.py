def _rel_to_session(path: Path) -> str:
    """Return a path relative to the configured session root when possible."""

    session_dir = _SESSION["session_dir"]
    try:
        if session_dir is not None:
            return resolve_under(path, session_dir)[1].as_posix()
    except Exception:
        pass
    return path.as_posix()


def _rel_path_under(path: Path, base: Path) -> str:
    try:
        return resolve_under(path, base)[1].as_posix()
    except Exception:
        return path.as_posix()

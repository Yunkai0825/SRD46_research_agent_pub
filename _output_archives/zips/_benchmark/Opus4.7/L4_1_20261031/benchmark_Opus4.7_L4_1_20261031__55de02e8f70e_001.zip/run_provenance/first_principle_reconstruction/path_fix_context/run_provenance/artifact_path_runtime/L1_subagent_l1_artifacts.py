def _resolve_call_file(state: _L1State, relative_path: str) -> Optional[Path]:
    """Resolve one advertised output path without allowing directory escape."""

    call_base = Path(state.call_dir)
    rel = (relative_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return None
    candidates: List[Path] = []
    session_dir = _SESSION.get("session_dir")
    if session_dir is not None:
        candidates.append(Path(session_dir) / rel)
    candidates.append(call_base / rel)
    for candidate in candidates:
        try:
            candidate, _ = resolve_under(candidate, call_base)
        except ValueError:
            continue
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _list_solver_files(state: _L1State) -> List[Path]:
    if state.solver_dir is None or not filesystem_path(state.solver_dir).exists():
        return []
    return [path for path in sorted(filesystem_path(state.solver_dir).rglob("*")) if path.is_file()]


def _collect_default_verdicts(output_paths: List[Path]) -> List[tuple[Path, str]]:
    """Load every solver-written Markdown verdict exactly once, in full."""

    verdict_paths = sorted({
        filesystem_path(path).resolve()
        for path in output_paths
        if path.suffix.lower() == ".md"
        and path.name.lower().endswith("verdict.md")
        and filesystem_path(path).is_file()
    })
    return [
        (path, path.read_text(encoding="utf-8", errors="replace"))
        for path in verdict_paths
    ]

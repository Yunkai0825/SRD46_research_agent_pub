def _rel_to_call(state: _LDState, p: Path) -> str:
    try:
        return resolve_under(p, state.call_dir)[1].as_posix()
    except Exception:
        return p.as_posix()


def _make_read_output_file(state: _LDState) -> Callable[..., str]:
    def read_output_file(relative_path: str = "", max_chars: int = _READ_DEFAULT_MAX_CHARS) -> str:
        """Read one output file (or ``l1_report.md``) as text."""
        base = Path(state.call_dir)
        rel = (relative_path or "").strip().replace("\\", "/").lstrip("/")
        if not rel:
            return "_(empty path)_"
        try:
            target, _ = resolve_under(base / rel, base)
        except ValueError:
            return f"_(refused: path '{relative_path}' escapes the call dir)_"
        if not target.exists() or not target.is_file():
            return f"_(no such file: '{relative_path}')_"
        if target.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".bin"}:
            return (f"_(binary file '{relative_path}', "
                    f"{target.stat().st_size} bytes — not returned)_")
        cap = max(1, min(int(max_chars or _READ_DEFAULT_MAX_CHARS), _READ_HARD_MAX_CHARS))
        text = target.read_text(encoding="utf-8", errors="replace")
        truncated = len(text) > cap
        header = (f"# `{rel}` ({target.stat().st_size} B"
                  + (f", first {cap} chars" if truncated else "") + ")\n\n")
        return header + text[:cap] + ("\n\n_(truncated)_" if truncated else "")

    return read_output_file


def _list_solver_files(state: _LDState) -> List[Path]:
    files: List[Path] = []
    if state.solver_dir is not None and filesystem_path(state.solver_dir).exists():
        files.extend(
            p for p in sorted(filesystem_path(state.solver_dir).rglob("*")) if p.is_file()
        )
    for name in ("thermodynamic_reference_constants.md", "l1_report.md"):
        candidate = Path(state.call_dir) / name
        if candidate.is_file() and candidate not in files:
            files.append(candidate)
    return files

[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse notational duplicates: keep one Ni2+ entry (prefer SRD-46 for consistency with the citrate complex set) and one trihydroxo monomer entry (prefer SRD-46 [Ni(OH)3]- over Atlas [HNiO2]-, same species). Keep the lower-μ Ni(OH)2(s) (Atlas, 66.860 kJ) and drop the higher-μ SRD-46 duplicate; drop anhydrous NiO, elemental Ni, and all Ni(III)/Ni(IV)/mixed-valence oxides as out-of-scope under the no-redox constraint; retain all remaining hydrolysis monomers, the Ni4(OH)4(4+) polynuclear (relevant at 1 mM), and every Ni-citrate complex including the polynuclear hydroxo-citrate.

[Singletons: n=16]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Citr)]-` | SRD-46 | -1 | 44.063 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:-1` | `[Ni2(Citr)2(OH)2]4-` | SRD-46 | -4 | 171.916 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(Citr)H]` | SRD-46 | +0 | 22.888 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:2` | `[Ni(Citr)H2]+` | SRD-46 | +1 | 6.849 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Citr)2]4-` | SRD-46 | -4 | 100.855 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2 H:1` | `[Ni(Citr)2H]3-` | SRD-46 | -3 | 71.403 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
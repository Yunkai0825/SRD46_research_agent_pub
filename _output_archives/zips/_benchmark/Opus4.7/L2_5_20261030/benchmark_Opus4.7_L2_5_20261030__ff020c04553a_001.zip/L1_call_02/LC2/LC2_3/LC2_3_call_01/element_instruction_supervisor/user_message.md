[Orchestration session]
791c89cbdea44fbf95ef1be64e126553

[Calculation purpose]
Compute Ni(II) speciation with citrate to determine free Ni2+ at pH 9 for scaling suppression assessment.

[Requested tasks]
Model a single aqueous solution containing Ni(II) at 1 mM with citrate at 10 mM over pH 2-12 at 25 C and ionic strength 0.1 m, excluding redox. Run a pH speciation sweep and report the dominant Ni species at pH 9, the free [Ni2+] concentration (M), the fraction of total Ni that is free Ni2+, and whether Ni(OH)2(s) is saturated at pH 9. Include the pH at which Ni(OH)2(s) first precipitates.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-4d859ba833c72275` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Citr)]-` | SRD-46 | +44.063 |
| `DEDUP-f5c7964d14fe1154` | aqueous | aqueous | `Ni$+2:1 L1:1 H:-1` | `[Ni2(Citr)2(OH)2]4-` | SRD-46 | +171.916 |
| `DEDUP-cdf4127613b00687` | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(Citr)H]` | SRD-46 | +22.888 |
| `DEDUP-53d0efe326323ae3` | aqueous | aqueous | `Ni$+2:1 L1:1 H:2` | `[Ni(Citr)H2]+` | SRD-46 | +6.849 |
| `DEDUP-237bec687f6172bd` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Citr)2]4-` | SRD-46 | +100.855 |
| `DEDUP-d1c8111ff085fb3c` | aqueous | aqueous | `Ni$+2:1 L1:2 H:1` | `[Ni(Citr)2H]3-` | SRD-46 | +71.403 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |

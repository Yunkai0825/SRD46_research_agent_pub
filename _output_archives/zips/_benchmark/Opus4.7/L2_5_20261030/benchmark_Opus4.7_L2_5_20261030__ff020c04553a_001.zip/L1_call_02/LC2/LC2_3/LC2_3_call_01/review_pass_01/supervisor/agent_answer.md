The Ni element deduplication is complete and committed. Final selection:

**Kept (aqueous)**: [Ni]2+ (SRD-46), [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]-, [Ni(Citr)]-, [Ni(Citr)H], [Ni(Citr)H2]+, [Ni(Citr)2]4-, [Ni(Citr)2H]3-, [Ni2(Citr)2(OH)2]4-, plus the citrate protonation ladder and water reference.

**Kept (solid)**: Ni(OH)2 (Atlas, μ = +66.860 kJ) as the aqueous precipitation phase.

**Dropped**: Ni2+ (Atlas) and [HNiO2]- (Atlas) as notational duplicates of their SRD-46 counterparts; [Ni(OH)2](s) (SRD-46, higher-μ polymorph); anhydrous NiO (not the phase forming from solution at 25 °C); elemental Ni, Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O (all require redox outside the committed scenario).

The selection honors the 1 mM working regime by retaining polynuclear Ni4(OH)4(4+) and the Ni2(Citr)2(OH)2(4−) hydroxo-citrate complex, and provides a single ground-state Ni(OH)2(s) suitable for computing the precipitation pH.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Ni(II) aqueous speciation with citrate ligand, pH 2-12, 25°C, I=0.1 m, 1 mM Ni total, 10 mM citrate. Redox is explicitly excluded, so Ni(0), Ni(III), and Ni(IV) phases are out of scope.
- **Concentration regime**: Working [Ni] = 1 mM (not the 10^-6 M corrosion default). This elevates polynuclear hydroxo and polynuclear Ni-citrate complexes above negligibility — Ni4(OH)4(4+) and Ni2(Citr)2(OH)2(4-) are genuine competitors and must be kept.
- **Protonation states and notation**: Keep every distinct protonation/hydrolysis level of Ni-citrate. Treat Ni2+ (Atlas vs SRD-46) as a notational duplicate — one entry suffices for the free-ion reference. Treat [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) as the same trihydroxo monomer at near-identical μ (~1.2 kJ apart) — collapse to one.
- **Solids — hydration**: At 25°C in aqueous solution, Ni(OH)2(s) is the physically relevant scaling phase. Two hydrated entries differ by ~6 kJ; keep the ground-state (lower μ, Atlas) and drop the higher-μ duplicate — the question asks when precipitation begins, which the lower-μ polymorph governs. Anhydrous NiO is not the phase that forms from aqueous solution at 25°C and is thermodynamically bracketed by Ni(OH)2 for this task — drop.
- **Redox-only solids**: Ni(0), Ni2O3·H2O, NiO2·2H2O, Ni3O4·2H2O all require redox chemistry outside the committed scenario — drop.
- **Carbonates / other counterions**: Not in the input system; nothing to arbitrate.
- **Phase question**: 'Does Ni(OH)2 precipitate and at what pH' — this is a which-phase-forms question for the solid, but only one Ni(II) hydroxide polymorph is relevant at 25°C, so collapsing to ground state is correct.

## Element instructions

- **Ni**: Collapse notational duplicates: keep one Ni2+ entry (prefer SRD-46 for consistency with the citrate complex set) and one trihydroxo monomer entry (prefer SRD-46 [Ni(OH)3]- over Atlas [HNiO2]-, same species). Keep the lower-μ Ni(OH)2(s) (Atlas, 66.860 kJ) and drop the higher-μ SRD-46 duplicate; drop anhydrous NiO, elemental Ni, and all Ni(III)/Ni(IV)/mixed-valence oxides as out-of-scope under the no-redox constraint; retain all remaining hydrolysis monomers, the Ni4(OH)4(4+) polynuclear (relevant at 1 mM), and every Ni-citrate complex including the polynuclear hydroxo-citrate.

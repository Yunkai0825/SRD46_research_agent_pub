# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Notational duplicate of free Ni2+ ion; keep SRD-46 entry for consistency with citrate complex set. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Notational duplicate of free Ni2+ ion; keep SRD-46 entry for consistency with citrate complex set. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear vs tetranuclear); polynuclear retained per case-specific guidance at 1 mM Ni. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear vs tetranuclear); polynuclear retained per case-specific guidance at 1 mM Ni. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) dihydroxo monomer, in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same trihydroxo monomer at near-identical μ; keep the SRD-46 entry per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same trihydroxo monomer at near-identical μ; keep the SRD-46 entry per element instructions. |
| `DEDUP-4d859ba833c72275` | `[Ni(Citr)]-` | SRD-46 | generation 1: kept — Ni-citrate 1:1 complex, in scope. |
| `DEDUP-f5c7964d14fe1154` | `[Ni2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Polynuclear Ni-citrate hydroxo complex, retained at 1 mM Ni per case guidance. |
| `DEDUP-cdf4127613b00687` | `[Ni(Citr)H]` | SRD-46 | generation 1: kept — Protonated Ni-citrate complex, in scope. |
| `DEDUP-53d0efe326323ae3` | `[Ni(Citr)H2]+` | SRD-46 | generation 1: kept — Diprotonated Ni-citrate complex, in scope. |
| `DEDUP-237bec687f6172bd` | `[Ni(Citr)2]4-` | SRD-46 | generation 1: kept — Ni-bis(citrate) complex, in scope. |
| `DEDUP-d1c8111ff085fb3c` | `[Ni(Citr)2H]3-` | SRD-46 | generation 1: kept — Protonated Ni-bis(citrate) complex, in scope. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(0) requires redox chemistry excluded from scenario. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Keep lower-mu Ni(OH)2 (Atlas, 66.860 kJ) as the relevant 25C aqueous precipitation phase; drop anhydrous NiO (not the phase forming from aqueous solution) and higher-mu SRD-46 [Ni(OH)2](s) duplicate per case recommendations. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep lower-mu Ni(OH)2 (Atlas, 66.860 kJ) as the relevant 25C aqueous precipitation phase; drop anhydrous NiO (not the phase forming from aqueous solution) and higher-mu SRD-46 [Ni(OH)2](s) duplicate per case recommendations. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Keep lower-mu Ni(OH)2 (Atlas, 66.860 kJ) as the relevant 25C aqueous precipitation phase; drop anhydrous NiO (not the phase forming from aqueous solution) and higher-mu SRD-46 [Ni(OH)2](s) duplicate per case recommendations. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II,III) oxide out of scope under no-redox constraint. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide hydrate out of scope under no-redox constraint. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide hydrate out of scope under no-redox constraint. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference, in scope. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate ligand, in scope. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Diprotonated citrate, in scope. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Fully protonated citric acid, in scope. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Monoprotonated citrate, in scope. |

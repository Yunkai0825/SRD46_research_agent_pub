{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Reference water/solvent entry; keep."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Fully deprotonated citrate; in-scope ligand species."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Monoprotonated citrate; distinct protonation state, keep."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Diprotonated citrate; distinct protonation state, keep."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"Fully protonated citric acid; reference state, keep."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) hydrolysis monomer, in-scope Ni(II) species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Ni-citrate 1:1 complex; central species, keep."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1 H:-1","keep":true,"rationale":"Polynuclear hydroxo-citrate relevant at 1 mM Ni per case recommendations."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1 H:1","keep":true,"rationale":"Protonated Ni-citrate complex; distinct protonation state, keep."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1 H:2","keep":true,"rationale":"Diprotonated Ni-citrate complex; distinct protonation state, keep."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Ni(Citr)2 bis-citrate complex; in-scope Ni(II) species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2 H:1","keep":true,"rationale":"Protonated bis-citrate complex; distinct state, keep."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) is redox phase; out of scope under no-redox constraint."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni(II)/Ni(III) oxide; redox-only, out of scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide-hydrate; redox-only, out of scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide-hydrate; redox-only, out of scope."}
]}
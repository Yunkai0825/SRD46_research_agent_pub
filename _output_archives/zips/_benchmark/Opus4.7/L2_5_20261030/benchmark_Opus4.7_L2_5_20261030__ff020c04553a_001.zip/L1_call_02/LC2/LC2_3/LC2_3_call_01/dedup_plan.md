# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: Ni(II) aqueous speciation with citrate ligand, pH 2-12, 25°C, I=0.1 m, 1 mM Ni total, 10 mM citrate. Redox is explicitly excluded, so Ni(0), Ni(III), and Ni(IV) phases are out of scope.
- **Concentration regime**: Working [Ni] = 1 mM (not the 10^-6 M corrosion default). This elevates polynuclear hydroxo and polynuclear Ni-citrate complexes above negligibility — Ni4(OH)4(4+) and Ni2(Citr)2(OH)2(4-) are genuine competitors and must be kept.
- **Protonation states and notation**: Keep every distinct protonation/hydrolysis level of Ni-citrate. Treat Ni2+ (Atlas vs SRD-46) as a notational duplicate — one entry suffices for the free-ion reference. Treat [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) as the same trihydroxo monomer at near-identical μ (~1.2 kJ apart) — collapse to one.
- **Solids — hydration**: At 25°C in aqueous solution, Ni(OH)2(s) is the physically relevant scaling phase. Two hydrated entries differ by ~6 kJ; keep the ground-state (lower μ, Atlas) and drop the higher-μ duplicate — the question asks when precipitation begins, which the lower-μ polymorph governs. Anhydrous NiO is not the phase that forms from aqueous solution at 25°C and is thermodynamically bracketed by Ni(OH)2 for this task — drop.
- **Redox-only solids**: Ni(0), Ni2O3·H2O, NiO2·2H2O, Ni3O4·2H2O all require redox chemistry outside the committed scenario — drop.
- **Carbonates / other counterions**: Not in the input system; nothing to arbitrate.
- **Phase question**: 'Does Ni(OH)2 precipitate and at what pH' — this is a which-phase-forms question for the solid, but only one Ni(II) hydroxide polymorph is relevant at 25°C, so collapsing to ground state is correct.

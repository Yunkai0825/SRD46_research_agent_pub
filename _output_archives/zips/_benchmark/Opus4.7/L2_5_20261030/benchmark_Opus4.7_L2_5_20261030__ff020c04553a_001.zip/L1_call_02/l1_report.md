## Doability
Doable. Standard pH-speciation sweep of Ni(II)+citrate at fixed T=25 °C, I=0.1 M, redox excluded — fully within SRD-46 pipeline scope. 101/101 points converged.

## Result
System: Ni2+ (1.00e-3 M total) + citric acid (1.00e-2 M total), pH 2.0–12.0, 25 °C, I=0.1 M (fixed-I mode), redox excluded. Method: 1-D pH_sweep. Convergence: 101/101. Precipitation of Ni(OH)2(s) first appears at pH 9.20 (solver precipitation summary); above pH 9.4 the solid dominates.

Key values at pH 9.00 (from `*_concentrations.csv` / `*_frac_metal.csv`):
- Dominant Ni species: **[Ni(Citr)2]4-**, fraction of Ni_total = 8.287e-1 (≈ 82.9 %).
- Free aquo Ni2+ concentration: **4.03e-7 M**.
- Fraction of total Ni present as free Ni2+: **4.03e-4** (≈ 0.040 %).
- Ni(OH)2(s) at pH 9.00: 0 M — **not** saturated at pH 9.0. First precipitation: **pH ≈ 9.20** (Ni(OH)2 = 1.94e-6 M).

Dominant-species map (Ni basis): pH 2.0–3.6 Ni2+; 3.6–4.4 [Ni(Citr)2H]3-; 4.4–9.4 [Ni(Citr)2]4-; 9.4–12 Ni(OH)2(s).

## Analysis
Below pH ~3 the citrate ligand is almost fully protonated (H3Cit dominates to pH 2.7; pKa values from the reference table give log β's of +12.90, +10.00, +5.65 for H3L, H2L-, HL2-, i.e. stepwise pKa1 ≈ 2.9, pKa2 ≈ 4.35, pKa3 ≈ 5.65 for citric acid), so citrate cannot yet compete with water for Ni2+ and ~96 % of nickel is the aquo ion. As the second and third carboxylates deprotonate (pH 3–5), the protonated 1:2 complex [Ni(Citr)2H]3- (log β = +13.29) briefly dominates near pH 4, before being replaced from pH ≈ 4.3 upward by the fully deprotonated bis-citrate chelate **[Ni(Citr)2]4-** (log β = +8.13 from free Ni2+ + 2 L3-, but strongly favoured once L3- is the dominant ligand form above pH 5). This bis-chelate carries Ni through the entire mid-pH window and peaks at 96.8 % of Ni near pH 7.6; with [L]_total/[Ni]_total = 10, the 1:2 stoichiometry is well supplied and the 1:1 [Ni(Citr)]- never dominates.

At pH 9 the ligand field is essentially all L3- (Cit3- = 8.17e-3 M of the 1.0e-2 total) and [Ni(Citr)2]4- still holds 82.9 % of nickel. Free Ni2+ has been suppressed by nearly four orders of magnitude relative to the uncomplexed case (1e-3 M → 4.03e-7 M). This is exactly the scaling-suppression regime citrate is chosen for: the activity driving CaCO3-type co-precipitation or Ni(OH)2 nucleation is set by [Ni2+], which the chelate holds at sub-µM levels. Correspondingly, at pH 9.00 the Ni(OH)2(s) saturation column is zero — the solid is **not** saturated, consistent with free [Ni2+] = 4.0e-7 M being well below the solubility implied by the atlas log Ksp (dissolution log β = -11.71 for Ni(OH)2 ⇌ Ni2+ + 2 OH-, i.e. [Ni2+]_sat ≈ 10^(-11.71)/[OH-]^2 ≈ 2e-2 M at pH 9, dropping to ≈ 2e-6 M at pH 11; the pipeline's own first precipitation sample confirms this crossing between pH 9.1 and 9.2).

Ni(OH)2(s) **first precipitates at pH 9.20** (1.94e-6 M of solid), and from pH 9.4 upward the hydroxide out-competes even the bis-citrate chelate: free [Ni2+] is clamped by the solid at ~10^(-7)–10^(-8) M and the aqueous citrate complex fraction collapses as Ni is drained into Ni(OH)2(s), which reaches ~100 % by pH 11.3. A minor binuclear hydroxo-citrate [Ni2(Citr)2(OH)2]4- (log β = -4.32) peaks at only 26 % near pH 9.2 and does not change the picture. Practically: at pH 9 with 10 mM citrate the system is a homogeneous solution of [Ni(Citr)2]4- with vanishing free Ni2+ and no hydroxide scale; raising pH by only ~0.2 units crosses into Ni(OH)2 precipitation, so operating headroom above pH 9 is small and ligand excess or lower pH is required to keep the solution clear.

## Artifacts
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
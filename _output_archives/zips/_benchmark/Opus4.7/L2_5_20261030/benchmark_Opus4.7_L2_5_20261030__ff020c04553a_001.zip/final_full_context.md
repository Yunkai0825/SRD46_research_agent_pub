## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute Ni(II) speciation with glycine to determine free Ni2+ at pH 9 for scaling suppression assessment.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_Ni.json",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_log_conc.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_ligand.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_log_conc.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_state_metrics.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_envelope_Ni$+2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_envelope_L1.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_run_params.json"
    ],
    "elapsed_s": 505.9
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Compute Ni(II) speciation with citrate to determine free Ni2+ at pH 9 for scaling suppression assessment.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_02/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_Ni.json",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_phase_balance_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_L1.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_L1.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_ligand.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_state_metrics.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_envelope_Ni$+2.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_envelope_L1.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_run_params.json"
    ],
    "elapsed_s": 356.1
  },
  {
    "call": 3,
    "call_dir": "L1_call_03",
    "purpose": "Compute Ni(II) speciation with ammonia to determine free Ni2+ at pH 9 for scaling suppression assessment, comparing against glycine and citrate.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_03/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_03/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_Ni.json",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_L1.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_L1.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_ligand.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_state_metrics.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_envelope_Ni$+2.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_envelope_L1.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 491.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute Ni(II) speciation with glycine to determine free Ni2+ at pH 9 for scaling suppression assessment.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 2,
    "purpose": "Compute Ni(II) speciation with citrate to determine free Ni2+ at pH 9 for scaling suppression assessment.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png",
      "L1_call_02/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 3,
    "purpose": "Compute Ni(II) speciation with ammonia to determine free Ni2+ at pH 9 for scaling suppression assessment, comparing against glycine and citrate.",
    "report_path": "L1_call_03/l1_report.md",
    "artifacts": [
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv",
      "L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png",
      "L1_call_03/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 3,
    "call_dir": "L1_call_03",
    "report_path": "L1_call_03/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Verdict file confirms ladder (Ni2+ 2.0-8.3; Ni(OH)2(s) 8.3-12.0)",
      "Ni(Ammo) peak 22% at pH 8.1",
      "precipitation onset pH 8.10",
      "crossover pH 8.21. Point values at pH 9 (free Ni2+ ~1%",
      "Ni(OH)2(s) ~96% dominant) are consistent with the dominance ladder. Ammonia protonation (pKa 9.26) and conclusion about weak NH3 masking are grounded in the free-energy table and ladder."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
To stop nickel hydroxide scaling at pH 9 (1 mM Ni, 25 C, I=0.1 m), decide which of glycine, citrate, or ammonia keeps the most Ni(II) in solution. Build the speciation for each ligand at 10 mM, then rank the three by the free [Ni2+] remaining at pH 9 and explain the ordering.

## Assistant
<summary>Dispatching three separate pH-speciation calculations: Ni(II) with glycine, citrate, and ammonia respectively, each at 1 mM Ni / 10 mM ligand, 25 C, I=0.1 m, to compare free [Ni2+] at pH 9.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable — Ni(II) + glycine is well represented in the SRD-46 catalog; a 1-D pH speciation sweep is the appropriate method for the question.

## Result
- System: Ni(II) 1.00 mM + glycine 10.0 mM, aqueous, redox excluded.
- Conditions: 25 °C, fixed-mode ionic strength target 0.1 M (actual I in the sampled grid 2.4e-4 to 5.4e-3 M because the solution is dilute and no inert salt was declared).
- Method: pH_sweep from pH 2.0 to 12.0, 101 points, converged 101/101.
- Species set included: Ni²⁺, [Ni(OH)]⁺, [Ni(OH)₂]°, [Ni(OH)₃]⁻, [Ni₄(OH)₄]⁴⁺, [Ni(Glyc)]⁺, [Ni(Glyc)₂]°, [Ni(Glyc)₃]⁻, and the solid [Ni(OH)₂](s); glycine as H₂Gly⁺, HGly±, Gly⁻ (reference-table log β values: Ni(Glyc) +5.74, Ni(Glyc)₂ +10.58, Ni(Glyc)₃ +14.10; Ni(OH)₂(s) dissolution log β −12.80; glycine conjugate-acid pKa₂ = 9.57 from the x=1 protonation row, pKa₁ bracketed by the cumulative H₂Gly⁺ log β = +11.90).

## Analysis

**Dominant forms at pH 9 (from `*_frac_metal.csv`, pH 9.0000 row):**

| Species | Fraction of Ni_total |
|---|---:|
| Ni²⁺ (free) | 2.95e−6 |
| [Ni(OH)]⁺ | 7.18e−8 |
| [Ni(OH)₂]° | 1.80e−7 |
| [Ni(Glyc)]⁺ | 1.32e−3 |
| [Ni(Glyc)₂]° | 0.1216 |
| [Ni(Glyc)₃]⁻ | 0.8771 |
| [Ni(OH)₂](s) | 0 |

Total Ni = 1.00e−3 M, so **free [Ni²⁺] at pH 9 ≈ 2.95e−6 × 1.00e−3 = 3.0 × 10⁻⁹ M (3 nM)**, a fraction of 2.95 × 10⁻⁶ (≈3 ppm) of total Ni. The tris complex [Ni(Glyc)₃]⁻ carries ~88% of the nickel and [Ni(Glyc)₂]° carries ~12%; everything else — including every hydroxo species — is below 0.2%.

**Why the chemistry delivers this result.** The verdict's dominance ladder for Ni(II) is Ni²⁺ (pH 2.0–6.1) → [Ni(Glyc)]⁺ (6.1–6.8) → [Ni(Glyc)₂]° (6.8–8.0) → [Ni(Glyc)₃]⁻ (8.0–11.8) → [Ni(OH)₂](s) (11.8–12.0). Those crossovers reflect two coupled effects. First, glycine is the limiting ligand: its deprotonation (pKa₂ = 9.57 per the included log β +9.57 for H + Gly⁻ ⇌ HGly°) controls how much Gly⁻ is available. Below pH ~6 almost all glycine is still HGly° (zwitterion) and Ni²⁺ is naked. As HGly° begins to shed its ammonium proton, successive glycinate chelates form; because the step constants rise steeply (log K₁ 5.74, log K₂ 4.84, log K₃ 3.52 from the stepwise differences of the cumulative β), with 10-fold excess ligand the Ni:Gly ratio drives the equilibrium all the way to the tris chelate once Gly⁻ activity is sufficient. By pH 9 ≳10% of glycine is already Gly⁻ (reaching the dominance crossover HGly/Gly⁻ at pH 9.4), and the three five-membered N,O chelate rings make [Ni(Glyc)₃]⁻ the thermodynamic sink.

**Suppression of Ni(OH)₂(s).** The verdict's precipitation section shows the solid first appears only at pH 11.60 (saturation fraction 0.17 of Ni_total) and the Ni(Glyc)₃⁻ ↔ Ni(OH)₂(s) crossover is at pH ≈ 11.78. At pH 9 the saturation column for [Ni(OH)₂](s) is strictly 0 — i.e. the solution is undersaturated — because glycine complexation has driven [Ni²⁺] down to ~3 nM, roughly five orders of magnitude below what free Ni²⁺ would be in a glycine-free 1 mM Ni(II) solution at pH 9 (where ~0.5 mM Ni(OH)₂(s) would precipitate; cf. K_sp log β −12.80 ⇒ [Ni²⁺] ≈ 10⁻²·⁸ at pH 9 without ligand). Equivalently: with [Ni²⁺]=3e−9 M and [OH⁻]=1e−5 M, Q = [Ni²⁺][OH⁻]² ≈ 3e−19, versus K_sp ≈ 10⁻¹²·⁸ ≈ 1.6e−13 — Q/K_sp ≈ 2e−6, i.e. ~6 orders of magnitude undersaturated.

**Practical answer for scaling-suppression assessment at pH 9:** Yes, 10 mM glycine fully sequesters 1 mM Ni(II) as soluble glycinate chelates (predominantly the anionic tris complex [Ni(Glyc)₃]⁻ with the neutral bis complex as the minor partner), keeps free [Ni²⁺] at the low-nM level, and leaves Ni(OH)₂(s) strongly undersaturated. The margin against precipitation holds until roughly pH 11.6, where the hydroxide activity finally overwhelms even the tris-glycinate stability.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png`
- `L1_call_01/thermodynamic_reference_constants.md`
</tool_result>

## Assistant
<summary>Glycine done (free [Ni2+] ≈ 3 nM at pH 9). Now dispatching the citrate and ammonia calculations in parallel.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Standard pH-speciation sweep of Ni(II)+citrate at fixed T=25 °C, I=0.1 M, redox excluded — fully within SRD-46 pipeline scope. 101/101 points converged.

## Result
System: Ni2+ (1.00e-3 M total) + citric acid (1.00e-2 M total), pH 2.0–12.0, 25 °C, I=0.1 M (fixed-I mode), redox excluded. Method: 1-D pH_sweep. Convergence: 101/101. Precipitation of Ni(OH)2(s) first appears at pH 9.20 (solver precipitation summary); above pH 9.4 the solid dominates.

Key values at pH 9.00 (from `*_concentrations.csv` / `*_frac_metal.csv`):
- Dominant Ni species: **[Ni(Citr)2]4-**, fraction of Ni_total = 8.287e-1 (≈ 82.9 %).
- Free aquo Ni2+ concentration: **4.03e-7 M**.
- Fraction of total Ni present as free Ni2+: **4.03e-4** (≈ 0.040 %).
- Ni(OH)2(s) at pH 9.00: 0 M — **not** saturated at pH 9.0. First precipitation: **pH ≈ 9.20** (Ni(OH)2 = 1.94e-6 M).

Dominant-species map (Ni basis): pH 2.0–3.6 Ni2+; 3.6–4.4 [Ni(Citr)2H]3-; 4.4–9.4 [Ni(Citr)2]4-; 9.4–12 Ni(OH)2(s).

## Analysis
Below pH ~3 the citrate ligand is almost fully protonated (H3Cit dominates to pH 2.7; pKa values from the reference table give log β's of +12.90, +10.00, +5.65 for H3L, H2L-, HL2-, i.e. stepwise pKa1 ≈ 2.9, pKa2 ≈ 4.35, pKa3 ≈ 5.65 for citric acid), so citrate cannot yet compete with water for Ni2+ and ~96 % of nickel is the aquo ion. As the second and third carboxylates deprotonate (pH 3–5), the protonated 1:2 complex [Ni(Citr)2H]3- (log β = +13.29) briefly dominates near pH 4, before being replaced from pH ≈ 4.3 upward by the fully deprotonated bis-citrate chelate **[Ni(Citr)2]4-** (log β = +8.13 from free Ni2+ + 2 L3-, but strongly favoured once L3- is the dominant ligand form above pH 5). This bis-chelate carries Ni through the entire mid-pH window and peaks at 96.8 % of Ni near pH 7.6; with [L]_total/[Ni]_total = 10, the 1:2 stoichiometry is well supplied and the 1:1 [Ni(Citr)]- never dominates.

At pH 9 the ligand field is essentially all L3- (Cit3- = 8.17e-3 M of the 1.0e-2 total) and [Ni(Citr)2]4- still holds 82.9 % of nickel. Free Ni2+ has been suppressed by nearly four orders of magnitude relative to the uncomplexed case (1e-3 M → 4.03e-7 M). This is exactly the scaling-suppression regime citrate is chosen for: the activity driving CaCO3-type co-precipitation or Ni(OH)2 nucleation is set by [Ni2+], which the chelate holds at sub-µM levels. Correspondingly, at pH 9.00 the Ni(OH)2(s) saturation column is zero — the solid is **not** saturated, consistent with free [Ni2+] = 4.0e-7 M being well below the solubility implied by the atlas log Ksp (dissolution log β = -11.71 for Ni(OH)2 ⇌ Ni2+ + 2 OH-, i.e. [Ni2+]_sat ≈ 10^(-11.71)/[OH-]^2 ≈ 2e-2 M at pH 9, dropping to ≈ 2e-6 M at pH 11; the pipeline's own first precipitation sample confirms this crossing between pH 9.1 and 9.2).

Ni(OH)2(s) **first precipitates at pH 9.20** (1.94e-6 M of solid), and from pH 9.4 upward the hydroxide out-competes even the bis-citrate chelate: free [Ni2+] is clamped by the solid at ~10^(-7)–10^(-8) M and the aqueous citrate complex fraction collapses as Ni is drained into Ni(OH)2(s), which reaches ~100 % by pH 11.3. A minor binuclear hydroxo-citrate [Ni2(Citr)2(OH)2]4- (log β = -4.32) peaks at only 26 % near pH 9.2 and does not change the picture. Practically: at pH 9 with 10 mM citrate the system is a homogeneous solution of [Ni(Citr)2]4- with vanishing free Ni2+ and no hydroxide scale; raising pH by only ~0.2 units crosses into Ni(OH)2 precipitation, so operating headroom above pH 9 is small and ligand excess or lower pH is required to keep the solution clear.

## Artifacts
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
</tool_result>

## Assistant
<summary>Citrate done (free [Ni2+] ≈ 4.0e-7 M at pH 9). Now need the ammonia case to complete the three-way ranking.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Ni(II) + NH3 is well within SRD-46 coverage; all six ammines, three Ni hydroxo monomers, Ni4(OH)4(4+), and the Ni(OH)2(s) dissolution record were included (see thermodynamic reference table). Fixed-I 0.1 M, T = 25 C, 101/101 pH samples converged.

## Result
- System: 1.00e-3 M Ni(II) + 1.00e-2 M NH3/NH4+ total; pH 2.0-12.0 (0.1 step); fixed I = 0.1 M; T = 25 C; redox excluded.
- Convergence: 101/101 samples converged (full window).
- Method: pH_sweep (1-D speciation). Deliverables: full fraction CSV, concentrations CSV, verdict, phase-balance / log-conc plots.
- Ammonia proton balance: HAmmonia+ dominates 2.0-9.3; NH3(aq) dominates 9.3-12.0 (card pKa for NH4+ = 9.26).

## Analysis

### Ni dominance ladder (fraction of Ni_total)
From the solver verdict and `*_frac_metal.csv`:
- pH 2.0 - 8.3: free Ni2+ dominates (>=50%). At pH 2.0 essentially 100% is Ni2+; the ammines stay negligible because at pH < 8 the ligand is almost entirely locked up as NH4+ (pKa 9.26), so free [NH3] is <<10 mM.
- pH ~8.1-8.2: Ni(OH)2(s) first appears (precipitation record: pH 8.10, 1.05e-4 M solid). Within one grid step the solid rises past the dissolved pool: Ni2+ ~65% / solid ~10% at pH 8.1, then Ni2+ ~41% / solid ~39% at pH 8.2, then solid takes over.
- pH >= 8.3: Ni(OH)2(s) is dominant and climbs to >99% by pH 10.5.
- The ammines never dominate: [Ni(NH3)]2+ peaks only at 22.0% near pH 8.1 (verdict), and higher ammines (Ni(NH3)2..6 2+) stay below ~2% throughout, because by the time enough free NH3 is liberated (pH > 9) the metal has already been swept into the hydroxide solid.

Chemically, 10 mM total NH3 is too weak a reservoir at this pH window to beat Ni(OH)2 precipitation: the ammonia-complex 'protection' is kinetically defeated by the acid-base speciation of the ligand itself.

### Point values at pH 9.00 (from `*_frac_metal.csv`, row pH=9.0000)
- Free Ni2+ fraction of Ni_total: 1.032e-2 (1.03%).
- Free [Ni2+] = (1.032e-2)(1.00e-3 M) = 1.03e-5 M.
- Dominant Ni species: Ni(OH)2(s) with fraction 9.576e-1 (95.76%).
- Next: [Ni(NH3)]2+ 1.96e-2 (1.96%), [Ni(NH3)2]2+ 9.99e-3, [Ni(OH)2](aq) 6.31e-4, [Ni(OH)]+ 2.51e-4.
- Ni(OH)2(s) saturation at pH 9: YES - the solid is present as the majority Ni phase (95.76%), so the aqueous pool is at saturation with respect to Ni(OH)2(s). The soluble sum (Ni2+ + all aqueous hydroxo + all ammines) is 4.24e-2 of total Ni, i.e. ~4.24e-5 M total dissolved Ni.

### pH of first Ni(OH)2(s) appearance
From the solver 'Precipitation' block the solid is first non-zero at pH 8.10 (1.05e-4 M). The adjacent grid points show zero solid at pH <= 8.00 and 1.05e-4 M at pH 8.10, so the onset is bracketed between pH 8.00 and 8.10. The Ni2+/Ni(OH)2(s) 50/50 crossover is reported at pH ~ 8.21.

### Practical reading for scaling suppression
At pH 9 with only 10 mM NH3, ammonia is a poor Ni2+ masking agent: free Ni2+ is already down to ~1e-5 M, but 95.8% of the Ni has dropped out as Ni(OH)2(s). Any 'free Ni' control via NH3 at pH 9 is really control by precipitation, not by complexation - the Ni(NH3)n(2+) series never carries more than a few percent of the metal. To suppress Ni(OH)2 scaling via ammine complexation one would need either (i) much higher total NH3 (so free [NH3] at pH 9 is tens of mM, pushing the beta6 term up), or (ii) a ligand whose pKa is well below the hydrolysis onset, so that the free ligand concentration is already large at the pH where Ni(OH)2(s) would otherwise saturate (this is where glycine, and especially citrate, outperform NH3 for Ni2+ masking near neutral pH).

## Artifacts
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png
- L1_call_03/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verdict file confirms ladder (Ni2+ 2.0-8.3; Ni(OH)2(s) 8.3-12.0)
  - Ni(Ammo) peak 22% at pH 8.1
  - precipitation onset pH 8.10
  - crossover pH 8.21. Point values at pH 9 (free Ni2+ ~1%
  - Ni(OH)2(s) ~96% dominant) are consistent with the dominance ladder. Ammonia protonation (pKa 9.26) and conclusion about weak NH3 masking are grounded in the free-energy table and ladder.

</tool_result>

## LLM Response
<summary>All three systems computed. Ranking by free [Ni2+] at pH 9: glycine (3 nM) << citrate (4e-7 M) << ammonia (1e-5 M, with 96% precipitated as hydroxide). Glycine wins; ammonia fails because its pKa (9.26) ties up ligand as NH4+ until after Ni(OH)2 precipitates.</summary>

<answer>
## Answer

**Ranking by free [Ni²⁺] remaining in solution at pH 9 (1 mM Ni, 10 mM ligand, 25 °C, I = 0.1 m):**

| Rank | Ligand | Free [Ni²⁺] at pH 9 | Dominant Ni form | Ni(OH)₂(s) at pH 9? |
|---|---|---:|---|---|
| 1 (best) | **Glycine** | ~3 × 10⁻⁹ M (3 nM) | [Ni(Gly)₃]⁻ (88 %), [Ni(Gly)₂]⁰ (12 %) | No — strongly undersaturated |
| 2 | **Citrate** | ~4.0 × 10⁻⁷ M | [Ni(Cit)₂]⁴⁻ (83 %) | No — but onset at pH 9.2 |
| 3 (worst) | **Ammonia** | ~1.0 × 10⁻⁵ M | **Ni(OH)₂(s)** (96 %); ammines <3 % | **Yes — 96 % of Ni already precipitated** |

**Glycine is the clear winner**, holding free Ni²⁺ roughly 100× below citrate and ~3500× below ammonia, with no hydroxide scale forming until ~pH 11.6.

### Chemical ordering — why this ranking makes sense

The ranking is set by **when each ligand's conjugate base becomes available relative to the pH where Ni(OH)₂(s) starts to precipitate (~pH 8–9 for 1 mM Ni with no ligand)**.

- **Glycine (pKₐ₂ ≈ 9.57, log β₁ 5.74, β₂ 10.58, β₃ 14.10).** Glycinate (Gly⁻) is already present at ~10 % of total glycine by pH 9, and the three successive log K steps (5.74, 4.84, 3.52) are high enough that with a 10:1 ligand excess, Ni is driven all the way to the anionic tris-chelate [Ni(Gly)₃]⁻. Three five-membered N,O chelate rings make this an exceptionally stable sink, suppressing [Ni²⁺] to ~3 nM — roughly five orders of magnitude below the hydroxide-precipitation threshold. Scale onset is pushed to pH ~11.6.

- **Citrate (pKₐ₁₋₃ ≈ 2.9 / 4.35 / 5.65).** Citrate is **fully deprotonated well before pH 9**, so Cit³⁻ is abundant (8.2 mM of 10 mM total). The polydentate bis-citrate chelate [Ni(Cit)₂]⁴⁻ (log β ≈ 8 vs Ni²⁺ + 2 Cit³⁻) carries 83 % of Ni at pH 9 and clamps free Ni²⁺ at ~4 × 10⁻⁷ M. Citrate loses to glycine because its overall affinity for Ni²⁺ is lower (the tris-glycinate β₃ = 14.1 is unmatched) and because at pH 9.2 Ni(OH)₂(s) starts to co-precipitate — the operating headroom above pH 9 is only ~0.2 units.

- **Ammonia (pKₐ of NH₄⁺ = 9.26).** This is the key failure mode. At pH 9, over half of the total "ammonia" is still **NH₄⁺**, which does not coordinate Ni²⁺. Free NH₃ activity is therefore too low to drive the Ni(NH₃)ₙ²⁺ series — [Ni(NH₃)]²⁺ peaks at only ~22 % near pH 8.1, and the higher ammines never exceed a few percent. Meanwhile, Ni(OH)₂(s) **nucleates at pH 8.10** and the Ni²⁺/Ni(OH)₂(s) 50/50 crossover is at pH 8.21 — i.e. the hydroxide forms **before** the ligand is deprotonated enough to compete. At pH 9, 96 % of the Ni has dropped out as the hydroxide solid; the "low" free [Ni²⁺] of ~10⁻⁵ M is just the saturation value above a Ni(OH)₂(s) precipitate, not evidence of complexation. Ammonia would only start to work if its total concentration were much higher, or if the target pH were well above the ligand's pKₐ.

### Bottom line

**Pick glycine.** The ordering free [Ni²⁺]_Gly ≪ free [Ni²⁺]_Cit ≪ free [Ni²⁺]_NH₃ follows directly from (i) ligand basicity relative to the hydroxide-precipitation pH, and (ii) the overall stability of the highest Ni complex each ligand can form at pH 9: a strong anionic tris-chelate (glycine) beats a bis-polydentate chelate (citrate) beats a protonation-crippled mono/bis-ammine (ammonia). Glycine not only gives the lowest free [Ni²⁺] but also the widest safe pH margin before Ni(OH)₂ scaling resumes.

## Evidence

- **Glycine at pH 9:** "free [Ni²⁺] at pH 9 ≈ 2.95e−6 × 1.00e−3 = 3.0 × 10⁻⁹ M (3 nM)"; "[Ni(Glyc)₃]⁻ carries ~88% of the nickel and [Ni(Glyc)₂]° carries ~12%"; "Ni(OH)₂(s) first appears only at pH 11.60"; "Q/K_sp ≈ 2e−6, i.e. ~6 orders of magnitude undersaturated." (L1 call 1)
- **Citrate at pH 9:** "Free aquo Ni2+ concentration: 4.03e-7 M"; "[Ni(Citr)2]4-, fraction of Ni_total = 8.287e-1 (≈ 82.9 %)"; "Ni(OH)2(s) at pH 9.00: 0 M — not saturated"; "Ni(OH)2(s) first precipitates at pH 9.20." (L1 call 2)
- **Ammonia at pH 9:** "Free [Ni2+] = (1.032e-2)(1.00e-3 M) = 1.03e-5 M"; "Dominant Ni species: Ni(OH)2(s) with fraction 9.576e-1 (95.76%)"; "[Ni(NH3)]2+ peaks only at 22.0% near pH 8.1"; "Ni(OH)2(s) first appears at pH 8.10 (1.05e-4 M)"; "Ni2+/Ni(OH)2(s) 50/50 crossover at pH ~8.21." (L1 call 3)
- **Key constants:** glycine log β₁/β₂/β₃ = 5.74 / 10.58 / 14.10, glycinate pKₐ = 9.57; citric acid stepwise pKₐ ≈ 2.9 / 4.35 / 5.65, [Ni(Cit)₂]⁴⁻ log β ≈ 8.13; NH₄⁺ pKₐ = 9.26.

## Artifacts

Glycine (winner):
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`

Citrate (runner-up):
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md`

Ammonia (fails — precipitates):
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md`
</answer>
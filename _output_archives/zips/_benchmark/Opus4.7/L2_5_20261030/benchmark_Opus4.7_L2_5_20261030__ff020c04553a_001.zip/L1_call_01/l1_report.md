## Doability
Doable — Ni(II) + glycine is well represented in the SRD-46 catalog; a 1-D pH speciation sweep is the appropriate method for the question.

## Result
- System: Ni(II) 1.00 mM + glycine 10.0 mM, aqueous, redox excluded.
- Conditions: 25 °C, fixed-mode ionic strength target 0.1 M (actual I in the sampled grid 2.4e-4 to 5.4e-3 M because the solution is dilute and no inert salt was declared).
- Method: pH_sweep from pH 2.0 to 12.0, 101 points, converged 101/101.
- Species set included: Ni²⁺, [Ni(OH)]⁺, [Ni(OH)₂]°, [Ni(OH)₃]⁻, [Ni₄(OH)₄]⁴⁺, [Ni(Glyc)]⁺, [Ni(Glyc)₂]°, [Ni(Glyc)₃]⁻, and the solid [Ni(OH)₂](s); glycine as H₂Gly⁺, HGly±, Gly⁻ (reference-table log β values: Ni(Glyc) +5.74, Ni(Glyc)₂ +10.58, Ni(Glyc)₃ +14.10; Ni(OH)₂(s) dissolution log β −12.80; glycine conjugate-acid pKa₂ = 9.57 from the x=1 protonation row, pKa₁ bracketed by the cumulative H₂Gly⁺ log β = +11.90).

## Analysis

**Dominant forms at pH 9 (from `*_frac_metal.csv`, pH 9.0000 row):**

| Species | Fraction of Ni_total |
|---|---:|
| Ni²⁺ (free) | 2.95e−6 |
| [Ni(OH)]⁺ | 7.18e−8 |
| [Ni(OH)₂]° | 1.80e−7 |
| [Ni(Glyc)]⁺ | 1.32e−3 |
| [Ni(Glyc)₂]° | 0.1216 |
| [Ni(Glyc)₃]⁻ | 0.8771 |
| [Ni(OH)₂](s) | 0 |

Total Ni = 1.00e−3 M, so **free [Ni²⁺] at pH 9 ≈ 2.95e−6 × 1.00e−3 = 3.0 × 10⁻⁹ M (3 nM)**, a fraction of 2.95 × 10⁻⁶ (≈3 ppm) of total Ni. The tris complex [Ni(Glyc)₃]⁻ carries ~88% of the nickel and [Ni(Glyc)₂]° carries ~12%; everything else — including every hydroxo species — is below 0.2%.

**Why the chemistry delivers this result.** The verdict's dominance ladder for Ni(II) is Ni²⁺ (pH 2.0–6.1) → [Ni(Glyc)]⁺ (6.1–6.8) → [Ni(Glyc)₂]° (6.8–8.0) → [Ni(Glyc)₃]⁻ (8.0–11.8) → [Ni(OH)₂](s) (11.8–12.0). Those crossovers reflect two coupled effects. First, glycine is the limiting ligand: its deprotonation (pKa₂ = 9.57 per the included log β +9.57 for H + Gly⁻ ⇌ HGly°) controls how much Gly⁻ is available. Below pH ~6 almost all glycine is still HGly° (zwitterion) and Ni²⁺ is naked. As HGly° begins to shed its ammonium proton, successive glycinate chelates form; because the step constants rise steeply (log K₁ 5.74, log K₂ 4.84, log K₃ 3.52 from the stepwise differences of the cumulative β), with 10-fold excess ligand the Ni:Gly ratio drives the equilibrium all the way to the tris chelate once Gly⁻ activity is sufficient. By pH 9 ≳10% of glycine is already Gly⁻ (reaching the dominance crossover HGly/Gly⁻ at pH 9.4), and the three five-membered N,O chelate rings make [Ni(Glyc)₃]⁻ the thermodynamic sink.

**Suppression of Ni(OH)₂(s).** The verdict's precipitation section shows the solid first appears only at pH 11.60 (saturation fraction 0.17 of Ni_total) and the Ni(Glyc)₃⁻ ↔ Ni(OH)₂(s) crossover is at pH ≈ 11.78. At pH 9 the saturation column for [Ni(OH)₂](s) is strictly 0 — i.e. the solution is undersaturated — because glycine complexation has driven [Ni²⁺] down to ~3 nM, roughly five orders of magnitude below what free Ni²⁺ would be in a glycine-free 1 mM Ni(II) solution at pH 9 (where ~0.5 mM Ni(OH)₂(s) would precipitate; cf. K_sp log β −12.80 ⇒ [Ni²⁺] ≈ 10⁻²·⁸ at pH 9 without ligand). Equivalently: with [Ni²⁺]=3e−9 M and [OH⁻]=1e−5 M, Q = [Ni²⁺][OH⁻]² ≈ 3e−19, versus K_sp ≈ 10⁻¹²·⁸ ≈ 1.6e−13 — Q/K_sp ≈ 2e−6, i.e. ~6 orders of magnitude undersaturated.

**Practical answer for scaling-suppression assessment at pH 9:** Yes, 10 mM glycine fully sequesters 1 mM Ni(II) as soluble glycinate chelates (predominantly the anionic tris complex [Ni(Glyc)₃]⁻ with the neutral bis complex as the minor partner), keeps free [Ni²⁺] at the low-nM level, and leaves Ni(OH)₂(s) strongly undersaturated. The margin against precipitation holds until roughly pH 11.6, where the hydroxide activity finally overwhelms even the tris-glycinate stability.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png`
- `L1_call_01/thermodynamic_reference_constants.md`
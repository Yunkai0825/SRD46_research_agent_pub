# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Notation duplicates of aqueous Ni2+; keep SRD-46 entry for consistency with SRD-46 hydrolysis and glycinate ladder. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Notation duplicates of aqueous Ni2+; keep SRD-46 entry for consistency with SRD-46 hydrolysis and glycinate ladder. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Different nuclearities and charges (mononuclear +1 vs tetranuclear +4); both required for the SRD-46 Ni(II) hydrolysis ladder. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Different nuclearities and charges (mononuclear +1 vs tetranuclear +4); both required for the SRD-46 Ni(II) hydrolysis ladder. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq), part of SRD-46 Ni(II) hydrolysis ladder. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Collapsed [HNiO2]-/[Ni(OH)3]- notation duplicates to the SRD-46 entry per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Collapsed [HNiO2]-/[Ni(OH)3]- notation duplicates to the SRD-46 entry per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — [Ni(Glyc)]+ mono-glycinate complex, required. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — [Ni(Glyc)2] bis-glycinate complex, required. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — [Ni(Glyc)3]- tris-glycinate complex, required. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Ni(0) metal out of scope for non-redox Ni(II) speciation. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Collapse Ni(OH)2(s) duplicates to the SRD-46 hydrated solid; drop anhydrous NiO as out of scope for Ni(II) solution speciation. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Collapse Ni(OH)2(s) duplicates to the SRD-46 hydrated solid; drop anhydrous NiO as out of scope for Ni(II) solution speciation. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Ni(OH)2(s) duplicates to the SRD-46 hydrated solid; drop anhydrous NiO as out of scope for Ni(II) solution speciation. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II,III) oxide out of scope without oxidant. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide/hydroxide out of scope for Ni(II) speciation. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide/hydroxide out of scope for Ni(II) speciation. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference species, in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, required ligand speciation. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, dominates low pH. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine zwitterion, required ligand speciation. |

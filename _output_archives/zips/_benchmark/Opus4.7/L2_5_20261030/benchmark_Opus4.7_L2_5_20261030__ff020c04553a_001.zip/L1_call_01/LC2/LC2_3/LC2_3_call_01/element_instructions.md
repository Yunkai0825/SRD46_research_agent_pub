# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Ni(II)-glycine speciation and precipitation screening at pH 2-12, 25 C, I=0.1 m, 1 mM Ni total, 10 mM glycine. This is a solution-equilibrium question (not corrosion, not an electrochemical hull), so no 1e-6 M corrosion convention and no imposed redox potential; retain only Ni(II) aqueous and solid phases plus the Ni-glycine complexes.
- Drop all Ni(III) and Ni(IV) oxide/hydroxide solids and anhydrous NiO as out of scope: there is no oxidant and the question is explicitly about Ni(II) speciation and Ni(OH)2 precipitation. Ni(0) metal is likewise out of scope (no reductive context) and should be dropped.
- Keep hydrated Ni(OH)2(s) as the sole competing precipitate since the question asks whether Ni(OH)2(s) is suppressed; collapse the two Ni(OH)2 entries (Atlas hydrated vs SRD-46) to the SRD-46 entry so the solubility product is on the same thermodynamic scale as the SRD-46 glycine complexes used to compute free Ni2+.
- Collapse duplicate aqueous Ni2+ (Atlas vs SRD-46) to the SRD-46 entry for internal consistency with the SRD-46 hydrolysis and glycinate ladder. Collapse the [HNiO2]- (Atlas) / [Ni(OH)3]- (SRD-46) notation pair to SRD-46 [Ni(OH)3]- (same stoichiometry, mu within 1.3 kJ, pure notation).
- Keep the full SRD-46 Ni(II) hydrolysis ladder ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2]aq, [Ni(OH)3]-) and the full glycinate ladder ([Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-): all are distinct stoichiometries that dominate different pH windows between 2 and 12 at mM Ni and 10 mM glycine, so none are redundant. The polynuclear [Ni4(OH)4]4+ is physically real at mM Ni and must be retained.

## Element instructions

- **Ni**: Collapse the two Ni2+(aq) entries to the SRD-46 entry and collapse the [HNiO2]-/[Ni(OH)3]- pair to the SRD-46 [Ni(OH)3]- (notation duplicates on the same SRD-46 ladder); collapse the two Ni(OH)2(s) entries to the SRD-46 hydrated solid, and drop NiO(anhydrous), Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, and Ni(0) metal as out of scope for this non-redox Ni(II) solution speciation. Keep the full SRD-46 hydrolysis ladder ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2]aq, [Ni(OH)3]-) and the full glycinate ladder ([Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-) because each stoichiometry dominates a different pH window at 1 mM Ni + 10 mM glycine.

{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent water, in scope."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Glycinate anion, essential ligand speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral zwitterion glycine, essential ligand speciation."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycine cation, dominant at low pH."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) is a required rung of the SRD-46 Ni(II) hydrolysis ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Mono-glycinate Ni(II) complex, required rung of glycinate ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Bis-glycinate Ni(II) complex, required rung of glycinate ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Tris-glycinate Ni(II) complex, required rung of glycinate ladder."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Ni(0) metal out of scope for non-redox Ni(II) solution speciation."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valent Ni(II,III) oxide hydrate out of scope for Ni(II) non-redox speciation."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide hydrate out of scope for Ni(II) non-redox speciation."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide hydrate out of scope for Ni(II) non-redox speciation."}
]}
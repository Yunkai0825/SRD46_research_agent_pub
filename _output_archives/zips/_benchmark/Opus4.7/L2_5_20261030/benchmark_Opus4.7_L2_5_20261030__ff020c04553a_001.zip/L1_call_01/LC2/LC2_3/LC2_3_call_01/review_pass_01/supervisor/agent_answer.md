Final deduplicated inventory committed for the Ni(II)-glycine speciation calculation at pH 2-12, 25 C, I=0.1 m, 1 mM Ni total, 10 mM glycine.

Kept (SRD-46, single thermodynamic scale):
- Aqueous Ni(II): [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), [Ni(OH)3]-
- Ni-glycinate ladder: [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-
- Glycine ligand ladder: [H2Glycine]+, [HGlycine], [Glycine]-
- Precipitate: [Ni(OH)2](s) (hydrated)
- Water reference

Dropped:
- Atlas notation duplicates of Ni2+(aq), [HNiO2]- (= [Ni(OH)3]-), and Ni(OH)2(s) — collapsed to the SRD-46 ladder for internal consistency of the solubility product with the glycinate formation constants.
- Ni(0) metal — no reductive context.
- Anhydrous NiO — hydrated Ni(OH)2(s) is the relevant competing precipitate at 25 C in aqueous solution.
- Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O — Ni(III)/Ni(IV) phases out of scope with no imposed oxidant.

This selection preserves the full hydrolysis and glycinate competition needed to resolve free [Ni2+] and the dominant Ni-glycine complex at pH 9, and keeps a single Ni(OH)2(s) phase on the same thermodynamic scale so precipitation suppression can be judged against the glycinate-stabilized free Ni2+.
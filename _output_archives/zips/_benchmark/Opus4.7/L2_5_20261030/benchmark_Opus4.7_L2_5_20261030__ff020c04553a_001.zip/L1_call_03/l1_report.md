## Doability
Doable. Ni(II) + NH3 is well within SRD-46 coverage; all six ammines, three Ni hydroxo monomers, Ni4(OH)4(4+), and the Ni(OH)2(s) dissolution record were included (see thermodynamic reference table). Fixed-I 0.1 M, T = 25 C, 101/101 pH samples converged.

## Result
- System: 1.00e-3 M Ni(II) + 1.00e-2 M NH3/NH4+ total; pH 2.0-12.0 (0.1 step); fixed I = 0.1 M; T = 25 C; redox excluded.
- Convergence: 101/101 samples converged (full window).
- Method: pH_sweep (1-D speciation). Deliverables: full fraction CSV, concentrations CSV, verdict, phase-balance / log-conc plots.
- Ammonia proton balance: HAmmonia+ dominates 2.0-9.3; NH3(aq) dominates 9.3-12.0 (card pKa for NH4+ = 9.26).

## Analysis

### Ni dominance ladder (fraction of Ni_total)
From the solver verdict and `*_frac_metal.csv`:
- pH 2.0 - 8.3: free Ni2+ dominates (>=50%). At pH 2.0 essentially 100% is Ni2+; the ammines stay negligible because at pH < 8 the ligand is almost entirely locked up as NH4+ (pKa 9.26), so free [NH3] is <<10 mM.
- pH ~8.1-8.2: Ni(OH)2(s) first appears (precipitation record: pH 8.10, 1.05e-4 M solid). Within one grid step the solid rises past the dissolved pool: Ni2+ ~65% / solid ~10% at pH 8.1, then Ni2+ ~41% / solid ~39% at pH 8.2, then solid takes over.
- pH >= 8.3: Ni(OH)2(s) is dominant and climbs to >99% by pH 10.5.
- The ammines never dominate: [Ni(NH3)]2+ peaks only at 22.0% near pH 8.1 (verdict), and higher ammines (Ni(NH3)2..6 2+) stay below ~2% throughout, because by the time enough free NH3 is liberated (pH > 9) the metal has already been swept into the hydroxide solid.

Chemically, 10 mM total NH3 is too weak a reservoir at this pH window to beat Ni(OH)2 precipitation: the ammonia-complex 'protection' is kinetically defeated by the acid-base speciation of the ligand itself.

### Point values at pH 9.00 (from `*_frac_metal.csv`, row pH=9.0000)
- Free Ni2+ fraction of Ni_total: 1.032e-2 (1.03%).
- Free [Ni2+] = (1.032e-2)(1.00e-3 M) = 1.03e-5 M.
- Dominant Ni species: Ni(OH)2(s) with fraction 9.576e-1 (95.76%).
- Next: [Ni(NH3)]2+ 1.96e-2 (1.96%), [Ni(NH3)2]2+ 9.99e-3, [Ni(OH)2](aq) 6.31e-4, [Ni(OH)]+ 2.51e-4.
- Ni(OH)2(s) saturation at pH 9: YES - the solid is present as the majority Ni phase (95.76%), so the aqueous pool is at saturation with respect to Ni(OH)2(s). The soluble sum (Ni2+ + all aqueous hydroxo + all ammines) is 4.24e-2 of total Ni, i.e. ~4.24e-5 M total dissolved Ni.

### pH of first Ni(OH)2(s) appearance
From the solver 'Precipitation' block the solid is first non-zero at pH 8.10 (1.05e-4 M). The adjacent grid points show zero solid at pH <= 8.00 and 1.05e-4 M at pH 8.10, so the onset is bracketed between pH 8.00 and 8.10. The Ni2+/Ni(OH)2(s) 50/50 crossover is reported at pH ~ 8.21.

### Practical reading for scaling suppression
At pH 9 with only 10 mM NH3, ammonia is a poor Ni2+ masking agent: free Ni2+ is already down to ~1e-5 M, but 95.8% of the Ni has dropped out as Ni(OH)2(s). Any 'free Ni' control via NH3 at pH 9 is really control by precipitation, not by complexation - the Ni(NH3)n(2+) series never carries more than a few percent of the metal. To suppress Ni(OH)2 scaling via ammine complexation one would need either (i) much higher total NH3 (so free [NH3] at pH 9 is tens of mM, pushing the beta6 term up), or (ii) a ligand whose pKa is well below the hydrolysis onset, so that the free ligand concentration is already large at the pH where Ni(OH)2(s) would otherwise saturate (this is where glycine, and especially citrate, outperform NH3 for Ni2+ masking near neutral pH).

## Artifacts
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png
- L1_call_03/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verdict file confirms ladder (Ni2+ 2.0-8.3; Ni(OH)2(s) 8.3-12.0)
  - Ni(Ammo) peak 22% at pH 8.1
  - precipitation onset pH 8.10
  - crossover pH 8.21. Point values at pH 9 (free Ni2+ ~1%
  - Ni(OH)2(s) ~96% dominant) are consistent with the dominance ladder. Ammonia protonation (pKa 9.26) and conclusion about weak NH3 masking are grounded in the free-energy table and ladder.

# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.65
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH for Ni(II)-ammonia across pH 2-12 at fixed T and I.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
[Purpose: Compute Ni(II) speciation with ammonia to determine free Ni2+ at pH 9 for scaling suppression assessment, comparing against glycine and citrate.]
[Tasks:
Run a pH speciation sweep of a single pot containing 1 mM Ni(II) total and 10 mM ammonia (NH3/NH4+) total over pH 2 to 12 at 25 C and ionic strength 0.1 M (fixed-I mode), redox excluded. Include all Ni(II) ammine complexes [Ni(NH3)n]2+ (n=1..6), Ni hydroxo species, and the solid Ni(OH)2(s). Report the full Ni dominance ladder across the pH window, and at pH 9.00 report the fraction of total Ni present as free Ni2+, the free [Ni2+] in molar, the dominant Ni species and its fraction, and whether Ni(OH)2(s) is saturated. Also report the pH at which Ni(OH)2(s) first precipitates.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

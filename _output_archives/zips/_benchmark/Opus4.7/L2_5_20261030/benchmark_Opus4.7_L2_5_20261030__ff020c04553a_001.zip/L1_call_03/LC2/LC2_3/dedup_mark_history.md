# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Same free aquo Ni(II) ion in two notations; keep SRD-46 copy for consistency with SRD-46 complex set. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Same free aquo Ni(II) ion in two notations; keep SRD-46 copy for consistency with SRD-46 complex set. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear vs tetranuclear); both are competing hydroxo species at 1 mM Ni per case recommendations. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear vs tetranuclear); both are competing hydroxo species at 1 mM Ni per case recommendations. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq) neutral mononuclear hydroxo complex on the hull. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Notation duplicates of the same trihydroxo anion; keep SRD-46 copy for internal consistency with the SRD-46 complex set. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Notation duplicates of the same trihydroxo anion; keep SRD-46 copy for internal consistency with the SRD-46 complex set. |
| `DEDUP-00cdfe479b2f4203` | `[Ni(Ammo)]2+` | SRD-46 | generation 1: kept — [Ni(NH3)]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-b0c807d910b743cd` | `[Ni(Ammo)2]2+` | SRD-46 | generation 1: kept — [Ni(NH3)2]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-61e5cbd32f6c7241` | `[Ni(Ammo)3]2+` | SRD-46 | generation 1: kept — [Ni(NH3)3]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-bb76c136e747e9e9` | `[Ni(Ammo)4]2+` | SRD-46 | generation 1: kept — [Ni(NH3)4]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-e02d377e788b65b1` | `[Ni(Ammo)5]2+` | SRD-46 | generation 1: kept — [Ni(NH3)5]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-302455eb802e8601` | `[Ni(Ammo)6]2+` | SRD-46 | generation 1: kept — [Ni(NH3)6]2+ stepwise ammine complex, retained per instructions. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(0) metal out of scope; redox excluded by user. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II/III) oxide out of scope; redox excluded by user. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxyhydroxide out of scope; redox excluded by user. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide hydrate out of scope; redox excluded by user. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference species, in-scope aqueous entry. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3(aq) ligand, essential for ammine speciation. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ conjugate acid, controls free NH3 at pH range of interest. |

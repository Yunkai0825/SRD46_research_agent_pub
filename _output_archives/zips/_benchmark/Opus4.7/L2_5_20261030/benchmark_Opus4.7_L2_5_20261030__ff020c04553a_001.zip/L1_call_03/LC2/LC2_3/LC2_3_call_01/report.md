# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    356.07
- elapsed_s (total):  356.07
- llm_iterations:     30
- llm_tool_calls:     24

- n_groups:           18
- n_multi_groups:     4
- n_singletons:       14
- n_decisions:        18
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` [SRD-46] | Same free aquo Ni(II) ion in two notations; keep SRD-46 copy for consistency with SRD-46 complex set. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` [SRD-46], `[Ni4(OH)4]4+` [SRD-46] | Distinct nuclearities (mononuclear vs tetranuclear); both are competing hydroxo species at 1 mM Ni per case recommendations. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` [SRD-46] | Notation duplicates of the same trihydroxo anion; keep SRD-46 copy for internal consistency with the SRD-46 complex set. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` [SRD-46] | Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference species, in-scope aqueous entry. |
| aqueous | `L1:1` | yes | Free NH3(aq) ligand, essential for ammine speciation. |
| aqueous | `L1:1 H:1` | yes | NH4+ conjugate acid, controls free NH3 at pH range of interest. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(OH)2(aq) neutral mononuclear hydroxo complex on the hull. |
| aqueous | `Ni$+2:1 L1:1` | yes | [Ni(NH3)]2+ stepwise ammine complex, retained per instructions. |
| aqueous | `Ni$+2:1 L1:2` | yes | [Ni(NH3)2]2+ stepwise ammine complex, retained per instructions. |
| aqueous | `Ni$+2:1 L1:3` | yes | [Ni(NH3)3]2+ stepwise ammine complex, retained per instructions. |
| aqueous | `Ni$+2:1 L1:4` | yes | [Ni(NH3)4]2+ stepwise ammine complex, retained per instructions. |
| aqueous | `Ni$+2:1 L1:5` | yes | [Ni(NH3)5]2+ stepwise ammine complex, retained per instructions. |
| aqueous | `Ni$+2:1 L1:6` | yes | [Ni(NH3)6]2+ stepwise ammine complex, retained per instructions. |
| solid | `Ni$+0:1` | NO | Elemental Ni(0) metal out of scope; redox excluded by user. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | NO | Mixed-valence Ni(II/III) oxide out of scope; redox excluded by user. |
| solid | `Ni$+3:1 H:-3` | NO | Ni(III) oxyhydroxide out of scope; redox excluded by user. |
| solid | `Ni$+4:1 H:-4` | NO | Ni(IV) oxide hydrate out of scope; redox excluded by user. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | LC2 element review: Same free aquo Ni(II) ion in two notations; keep SRD-46 copy for consistency with SRD-46 complex set. |
| `[HNiO2]-` | Atlas | aqueous | LC2 element review: Notation duplicates of the same trihydroxo anion; keep SRD-46 copy for internal consistency with the SRD-46 complex set. |
| `Ni(OH)2` | Atlas | dissolution | LC2 element review: Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |
| `NiO` | Atlas | dissolution | LC2 element review: Per case guidance: keep SRD-46 Ni(OH)2(s) as the precipitating phase; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (not the controlling low-T phase). |
| `Ni3O4.2H2O` | Atlas | dissolution | LC2 element review: Mixed-valence Ni(II/III) oxide out of scope; redox excluded by user. |
| `Ni2O3.H2O` | Atlas | dissolution | LC2 element review: Ni(III) oxyhydroxide out of scope; redox excluded by user. |
| `NiO2.2H2O` | Atlas | dissolution | LC2 element review: Ni(IV) oxide hydrate out of scope; redox excluded by user. |
| `Ni` | Atlas | dissolution | LC2 element review: Elemental Ni(0) metal out of scope; redox excluded by user. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: b9b2975699134c7e8580820831107b58
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Ni(II)-NH3 speciation at 1 mM Ni / 10 mM NH3, I=0.1 M, 25 C, redox excluded. Dedup correctly dropped out-of-scope redox phases (Ni(0), Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O), anhydrous NiO (not the controlling low-T Ni(II) saturation phase), and the Atlas duplicates of Ni2+, [HNiO2]-/[Ni(OH)3]-, and Ni(OH)2(s); SRD-46 copies retained so the solid Ksp and all hydroxo/ammine complexation constants come from one internally consistent dataset. Full stepwise ammine ladder [Ni(NH3)n]2+ n=1..6 retained to resolve free-Ni2+ fraction at pH 9; mononuclear hydroxo ladder [Ni(OH)]+/[Ni(OH)2](aq)/[Ni(OH)3]- plus polynuclear [Ni4(OH)4]4+ retained as distinct competing states (polynuclear is legitimate at 1 mM Ni). Solvent and NH3/NH4+ kept. Table is chemistry-complete for the requested calculation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (7/7)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_5_20261030\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

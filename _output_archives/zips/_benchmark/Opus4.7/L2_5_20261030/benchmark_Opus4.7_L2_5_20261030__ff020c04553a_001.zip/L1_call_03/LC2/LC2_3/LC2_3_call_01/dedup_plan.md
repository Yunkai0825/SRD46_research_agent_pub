# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous solution speciation of 1 mM Ni(II) with 10 mM NH3/NH4+ at fixed I=0.1 M, 25 C, redox explicitly excluded by the user. Not a Pourbaix/corrosion problem, so the 1e-6 M corrosion convention does not apply; keep complexes and hydroxo species that are real at 1 mM Ni with the stated ligand budget.
- Redox exclusion: Ni(0) metal and all Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) are out of scope and must be dropped — they cannot form without the redox degree of freedom.
- Solid Ni(OH)2: the user explicitly requested Ni(OH)2(s) as the precipitating phase. Anhydrous NiO(s) is not the phase that controls low-T aqueous Ni(II) saturation and should be dropped. Keep exactly one Ni(OH)2(s) entry; prefer the SRD-46 source so the solubility product is thermodynamically consistent with the SRD-46 ammine and hydroxo complex set used for the speciation.
- Protonation / notation: Ni2+ (Atlas) and [Ni]2+ (SRD-46) are the same free aquo ion with identical mu; keep the SRD-46 copy so the aqueous reference matches the complex chain. [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are notation variants of the same trihydroxo anion; keep the SRD-46 [Ni(OH)3]- for consistency.
- Polynuclear [Ni4(OH)4]4+: at 1 mM total Ni it is a legitimate competing species in the near-neutral region and must be retained as a distinct state from mononuclear [Ni(OH)]+.
- Mononuclear hydroxo ladder [Ni(OH)]+, [Ni(OH)2](aq), [Ni(OH)3]- are each distinct protonation states on the hull and all kept.
- Full ammine ladder n=1..6 are distinct stepwise complexes governing the free-Ni2+ fraction and must all be retained.
- Phase question: which species form and in what fraction (not just ground state), so retain every in-scope distinct state; only drop true notation duplicates and out-of-scope redox phases.

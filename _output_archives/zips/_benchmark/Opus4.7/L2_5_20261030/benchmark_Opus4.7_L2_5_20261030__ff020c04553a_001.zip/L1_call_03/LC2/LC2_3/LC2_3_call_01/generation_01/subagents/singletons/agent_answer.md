{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent water reference species, required for aqueous speciation."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free NH3 ligand, essential component of the ammonia buffer."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"NH4+ conjugate acid, required to define the NH3/NH4+ equilibrium at the fixed ligand budget."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Mononuclear [Ni(OH)2](aq), distinct hydroxo state on the Ni(II) hull."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Stepwise ammine [Ni(NH3)]2+ (n=1), distinct complex in the ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Stepwise ammine [Ni(NH3)2]2+ (n=2), distinct complex in the ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Stepwise ammine [Ni(NH3)3]2+ (n=3), distinct complex in the ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:4","keep":true,"rationale":"Stepwise ammine [Ni(NH3)4]2+ (n=4), distinct complex in the ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:5","keep":true,"rationale":"Stepwise ammine [Ni(NH3)5]2+ (n=5), distinct complex in the ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:6","keep":true,"rationale":"Stepwise ammine [Ni(NH3)6]2+ (n=6), distinct complex in the ladder."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Ni(0) metal is out of scope: redox explicitly excluded by the user."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Ni3O4·2H2O is a mixed-valence Ni(II)/Ni(III) phase, out of scope with redox excluded."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni2O3·H2O is a Ni(III) phase, out of scope with redox excluded."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"NiO2·2H2O is a Ni(IV) phase, out of scope with redox excluded."}
]}
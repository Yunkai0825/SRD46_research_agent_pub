# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous solution speciation of 1 mM Ni(II) with 10 mM NH3/NH4+ at fixed I=0.1 M, 25 C, redox explicitly excluded by the user. Not a Pourbaix/corrosion problem, so the 1e-6 M corrosion convention does not apply; keep complexes and hydroxo species that are real at 1 mM Ni with the stated ligand budget.
- Redox exclusion: Ni(0) metal and all Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) are out of scope and must be dropped — they cannot form without the redox degree of freedom.
- Solid Ni(OH)2: the user explicitly requested Ni(OH)2(s) as the precipitating phase. Anhydrous NiO(s) is not the phase that controls low-T aqueous Ni(II) saturation and should be dropped. Keep exactly one Ni(OH)2(s) entry; prefer the SRD-46 source so the solubility product is thermodynamically consistent with the SRD-46 ammine and hydroxo complex set used for the speciation.
- Protonation / notation: Ni2+ (Atlas) and [Ni]2+ (SRD-46) are the same free aquo ion with identical mu; keep the SRD-46 copy so the aqueous reference matches the complex chain. [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are notation variants of the same trihydroxo anion; keep the SRD-46 [Ni(OH)3]- for consistency.
- Polynuclear [Ni4(OH)4]4+: at 1 mM total Ni it is a legitimate competing species in the near-neutral region and must be retained as a distinct state from mononuclear [Ni(OH)]+.
- Mononuclear hydroxo ladder [Ni(OH)]+, [Ni(OH)2](aq), [Ni(OH)3]- are each distinct protonation states on the hull and all kept.
- Full ammine ladder n=1..6 are distinct stepwise complexes governing the free-Ni2+ fraction and must all be retained.
- Phase question: which species form and in what fraction (not just ground state), so retain every in-scope distinct state; only drop true notation duplicates and out-of-scope redox phases.

## Element instructions

- **Ni**: Drop as out-of-scope (redox excluded by user): elemental Ni(s), NiO(s) anhydrous, Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O. Among duplicates keep the SRD-46 copy and drop the Atlas copy for: free aquo ion (keep [Ni]2+ SRD-46, drop Ni2+ Atlas), trihydroxo anion (keep [Ni(OH)3]- SRD-46, drop [HNiO2]- Atlas), and Ni(OH)2 solid (keep [Ni(OH)2](s) SRD-46, drop Ni(OH)2 Atlas) so the solid Ksp and all complexation constants come from one internally consistent SRD-46 dataset; retain [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and the full [Ni(NH3)n]2+ n=1..6 ladder as distinct competing states.

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop as out-of-scope (redox excluded by user): elemental Ni(s), NiO(s) anhydrous, Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O. Among duplicates keep the SRD-46 copy and drop the Atlas copy for: free aquo ion (keep [Ni]2+ SRD-46, drop Ni2+ Atlas), trihydroxo anion (keep [Ni(OH)3]- SRD-46, drop [HNiO2]- Atlas), and Ni(OH)2 solid (keep [Ni(OH)2](s) SRD-46, drop Ni(OH)2 Atlas) so the solid Ksp and all complexation constants come from one internally consistent SRD-46 dataset; retain [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and the full [Ni(NH3)n]2+ n=1..6 ladder as distinct competing states.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-681ffdbedf823eab` | aqueous | `[Ni(OH)]+` | SRD-46 | +1 | 59.360 | 1 | *** |
| `DEDUP-2798225efc912d29` | aqueous | `[Ni4(OH)4]4+` | SRD-46 | +4 | 158.103 | 4 | *** |
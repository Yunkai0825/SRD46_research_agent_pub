## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous solution speciation of 1 mM Ni(II) with 10 mM NH3/NH4+ at fixed I=0.1 M, 25 C, redox explicitly excluded by the user. Not a Pourbaix/corrosion problem, so the 1e-6 M corrosion convention does not apply; keep complexes and hydroxo species that are real at 1 mM Ni with the stated ligand budget.
- Redox exclusion: Ni(0) metal and all Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) are out of scope and must be dropped — they cannot form without the redox degree of freedom.
- Solid Ni(OH)2: the user explicitly requested Ni(OH)2(s) as the precipitating phase. Anhydrous NiO(s) is not the phase that controls low-T aqueous Ni(II) saturation and should be dropped. Keep exactly one Ni(OH)2(s) entry; prefer the SRD-46 source so the solubility product is thermodynamically consistent with the SRD-46 ammine and hydroxo complex set used for the speciation.
- Protonation / notation: Ni2+ (Atlas) and [Ni]2+ (SRD-46) are the same free aquo ion with identical mu; keep the SRD-46 copy so the aqueous reference matches the complex chain. [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are notation variants of the same trihydroxo anion; keep the SRD-46 [Ni(OH)3]- for consistency.
- Polynuclear [Ni4(OH)4]4+: at 1 mM total Ni it is a legitimate competing species in the near-neutral region and must be retained as a distinct state from mononuclear [Ni(OH)]+.
- Mononuclear hydroxo ladder [Ni(OH)]+, [Ni(OH)2](aq), [Ni(OH)3]- are each distinct protonation states on the hull and all kept.
- Full ammine ladder n=1..6 are distinct stepwise complexes governing the free-Ni2+ fraction and must all be retained.
- Phase question: which species form and in what fraction (not just ground state), so retain every in-scope distinct state; only drop true notation duplicates and out-of-scope redox phases.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop as out-of-scope (redox excluded by user): elemental Ni(s), NiO(s) anhydrous, Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O. Among duplicates keep the SRD-46 copy and drop the Atlas copy for: free aquo ion (keep [Ni]2+ SRD-46, drop Ni2+ Atlas), trihydroxo anion (keep [Ni(OH)3]- SRD-46, drop [HNiO2]- Atlas), and Ni(OH)2 solid (keep [Ni(OH)2](s) SRD-46, drop Ni(OH)2 Atlas) so the solid Ksp and all complexation constants come from one internally consistent SRD-46 dataset; retain [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and the full [Ni(NH3)n]2+ n=1..6 ladder as distinct competing states.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-681ffdbedf823eab` | aqueous | `[Ni(OH)]+` | SRD-46 | +1 | 59.360 | 1 | *** |
| `DEDUP-2798225efc912d29` | aqueous | `[Ni4(OH)4]4+` | SRD-46 | +4 | 158.103 | 4 | *** |

## Assistant
<summary>Both species are distinct: mononuclear [Ni(OH)]+ and tetranuclear [Ni4(OH)4]4+. Per case recommendations, both retained as competing states at 1 mM Ni.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept both distinct nuclearities.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>Kept both [Ni(OH)]+ and [Ni4(OH)4]4+ as distinct mononuclear vs. tetranuclear hydroxo species per case recommendations.</answer>
Final deduplicated Ni(II)–NH3 speciation set committed for the pH sweep at 1 mM Ni, 10 mM NH3/NH4+, I=0.1 M, 25 °C, redox excluded:

Aqueous (SRD-46): H2O, NH3, NH4+, [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), [Ni(OH)3]-, and the full ammine ladder [Ni(NH3)n]2+ for n = 1–6.

Solid (SRD-46): [Ni(OH)2](s) as the single precipitating phase.

Dropped as duplicates or out of scope: Atlas Ni2+, [HNiO2]-, Ni(OH)2 (notation/source duplicates of SRD-46 copies), anhydrous NiO (not the controlling low-T saturating phase), and all redox-excluded phases Ni(0), Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O.
# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute Ni(II) speciation with glycine to determine free Ni2+ at pH 9 for scalin | Model a solution containing 1 mM Ni(II) and 10 mM glycine at 25 C and 0.1 m ioni | 4219 | 630.9 |
| 2 | 2 | dispatch_l1_pipeline | Compute Ni(II) speciation with citrate to determine free Ni2+ at pH 9 for scalin | Model a single aqueous solution containing Ni(II) at 1 mM with citrate at 10 mM  | 4042 | 465.4 |
| 3 | 3 | dispatch_l1_pipeline | Compute Ni(II) speciation with ammonia to determine free Ni2+ at pH 9 for scalin | Run a pH speciation sweep of a single pot containing 1 mM Ni(II) total and 10 mM | 4586 | 618.6 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute Ni(II) speciation with glycine to determine free Ni2+ at pH 9 for scaling suppression assessment.",
  "tasks": "Model a solution containing 1 mM Ni(II) and 10 mM glycine at 25 C and 0.1 m ionic strength, computing the full pH-speciation from pH 2 to 12. Report the free [Ni2+] concentration (and fraction of total Ni) at pH 9, the dominant Ni-glycine complexes present there, and whether Ni(OH)2(s) precipitation would be suppressed."
}
```

### Reasoning excerpt
```
<reasoning>
Three separate systems to compare: Ni + glycine, Ni + citrate, Ni + ammonia. Each is its own pot. Dispatch three L1 calls.
</reasoning>
<summary>
Dispatching three separate pH-speciation calculations: Ni(II) with glycine, citrate, and ammonia respectively, each at 1 mM Ni / 10 mM ligand, 25 C, I=0.1 m, to compare free [Ni2+] at pH 9.
</summary>
```

### Result (4219 chars)
```
## Doability
Doable — Ni(II) + glycine is well represented in the SRD-46 catalog; a 1-D pH speciation sweep is the appropriate method for the question.

## Result
- System: Ni(II) 1.00 mM + glycine 10.0 mM, aqueous, redox excluded.
- Conditions: 25 °C, fixed-mode ionic strength target 0.1 M (actual I in the sampled grid 2.4e-4 to 5.4e-3 M because the solution is dilute and no inert salt was declared).
- Method: pH_sweep from pH 2.0 to 12.0, 101 points, converged 101/101.
- Species set included: Ni²⁺, [Ni(OH)]⁺, [Ni(OH)₂]°, [Ni(OH)₃]⁻, [Ni₄(OH)₄]⁴⁺, [Ni(Glyc)]⁺, [Ni(Glyc)₂]°, [Ni(Glyc)₃]⁻, and the solid [Ni(OH)₂](s); glycine as H₂Gly⁺, HGly±, Gly⁻ (reference-table log β values: Ni(Glyc) +5.74, Ni(Glyc)₂ +10.58, Ni(Glyc)₃ +14.10; Ni(OH)₂(s) dissolution log β −12.80; glycine conjugate-acid pKa₂ = 9.57 from the x=1 protonation row, pKa₁ bracketed by the cumulative H₂Gly⁺ log β = +11.90).

## Analysis

**Dominant forms at pH 9 (from `*_frac_metal.csv`, pH 9.0000 row):**

| Species | Fraction of Ni_total |
|---|---:|
| Ni²⁺ (free) | 2.95e−6 |
| [Ni(OH)]⁺ | 7.18e−8 |
| [Ni(OH)₂]° | 1.80e−7 |
| [Ni(Glyc)]⁺ | 1.32e−3 |
| [Ni(Glyc)₂]° | 0.1216 |
| [Ni(Glyc)₃]⁻ | 0.8771 |
| [Ni(OH)₂](s) | 0 |

Total Ni = 1.00e−3 M, so **free [Ni²⁺] at pH 9 ≈ 2.95e−6 × 1.00e−3 = 3.0 × 10⁻⁹ M (3 nM)**, a fraction of 2.95 × 10⁻⁶ (≈3 ppm) of total Ni. The tris complex [Ni(Glyc)₃]⁻ carries ~88% of the nickel and [Ni(Glyc)₂]° carries ~12%; everything else — including every hydroxo species — is below 0.2%.

**Why the chemistry delivers this result.** The verdict's dominance ladder for Ni(II) is Ni²⁺ (pH 2.0–6.1) → [Ni(Glyc)]⁺ (6.1–6.8) → [Ni(Glyc)₂]° (6.8–8.0) → [Ni(Glyc)₃]⁻ (8.0–11.8) → [Ni(OH)₂](s) (11.8–12.0). Those crossovers reflect two coupled effects. First, glycine is the limiting ligand: its deprotonation (pKa₂ = 9.57 per the included log β +9.57 for H + Gly⁻ ⇌ HGly°) controls how much Gly⁻ is available. Below pH ~6 almost all glycine is still HGly° (zwitterion) and Ni²⁺ is naked. As HGly° begins to shed its ammonium proton, successive glycinate chelates form; because the step constants rise steeply (log K₁ 5.74, log K₂ 4.84, log K₃ 3.52 from the stepwise differences of the cumulative β), with 10-fold excess ligand the Ni:Gly ratio drives the equilibrium all the way to the tris chelate once Gly⁻ activity is sufficient. By pH 9 ≳10% of glycine is already Gly⁻ (reaching the dominance crossover HGly/Gly⁻ at pH 9.4), and the three five-membered N,O chelate rings make [Ni(Glyc)₃]⁻ the thermodynamic sink.

**Suppression of Ni(OH)₂(s).** The verdict's precipitation section shows the solid first appears only at pH 11.60 (saturation fraction 0.17 of Ni_total) and the Ni(Glyc)₃⁻ ↔ Ni(OH)₂(s) crossover is at pH ≈ 11.78. At pH 9 the saturation column for [Ni(OH)₂](s) is strictly 0 — i.e. the solution is undersaturated — because glycine complexation has driven [Ni²⁺] down to ~3 nM, roughly five orders of magnitude below what free Ni²⁺ would be in a glycine-free 1 mM Ni(II) solution at pH 9 (where ~0.5 mM Ni(OH)₂(s) would precipitate; cf. K_sp log β −12.80 ⇒ [Ni²⁺] ≈ 10⁻²·⁸ at pH 9 without ligand). Equivalently: with [Ni²⁺]=3e−9 M and [OH⁻]=1e−5 M, Q = [Ni²⁺][OH⁻]² ≈ 3e−19, versus K_sp ≈ 10⁻¹²·⁸ ≈ 1.6e−13 — Q/K_sp ≈ 2e−6, i.e. ~6 orders of magnitude undersaturated.

**Practical answer for scaling-suppression assessment at pH 9:** Yes, 10 mM glycine fully sequesters 1 mM Ni(II) as soluble glycinate chelates (predominantly the anionic tris complex [Ni(Glyc)₃]⁻ with the neutral bis complex as the minor partner), keeps free [Ni²⁺] at the low-nM level, and leaves Ni(OH)₂(s) strongly undersaturated. The margin against precipitation holds until roughly pH 11.6, where the hydroxide activity finally overwhelms even the tris-glycinate stability.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png`
- `L1_call_01/thermodynamic_reference_constants.md`
```


## Tool call 2 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Compute Ni(II) speciation with citrate to determine free Ni2+ at pH 9 for scaling suppression assessment.",
  "tasks": "Model a single aqueous solution containing Ni(II) at 1 mM with citrate at 10 mM over pH 2-12 at 25 C and ionic strength 0.1 m, excluding redox. Run a pH speciation sweep and report the dominant Ni species at pH 9, the free [Ni2+] concentration (M), the fraction of total Ni that is free Ni2+, and whether Ni(OH)2(s) is saturated at pH 9. Include the pH at which Ni(OH)2(s) first precipitates."
}
```

### Reasoning excerpt
```
<summary>Glycine done (free [Ni2+] ≈ 3 nM at pH 9). Now dispatching the citrate and ammonia calculations in parallel.</summary>
```

### Result (4042 chars)
```
## Doability
Doable. Standard pH-speciation sweep of Ni(II)+citrate at fixed T=25 °C, I=0.1 M, redox excluded — fully within SRD-46 pipeline scope. 101/101 points converged.

## Result
System: Ni2+ (1.00e-3 M total) + citric acid (1.00e-2 M total), pH 2.0–12.0, 25 °C, I=0.1 M (fixed-I mode), redox excluded. Method: 1-D pH_sweep. Convergence: 101/101. Precipitation of Ni(OH)2(s) first appears at pH 9.20 (solver precipitation summary); above pH 9.4 the solid dominates.

Key values at pH 9.00 (from `*_concentrations.csv` / `*_frac_metal.csv`):
- Dominant Ni species: **[Ni(Citr)2]4-**, fraction of Ni_total = 8.287e-1 (≈ 82.9 %).
- Free aquo Ni2+ concentration: **4.03e-7 M**.
- Fraction of total Ni present as free Ni2+: **4.03e-4** (≈ 0.040 %).
- Ni(OH)2(s) at pH 9.00: 0 M — **not** saturated at pH 9.0. First precipitation: **pH ≈ 9.20** (Ni(OH)2 = 1.94e-6 M).

Dominant-species map (Ni basis): pH 2.0–3.6 Ni2+; 3.6–4.4 [Ni(Citr)2H]3-; 4.4–9.4 [Ni(Citr)2]4-; 9.4–12 Ni(OH)2(s).

## Analysis
Below pH ~3 the citrate ligand is almost fully protonated (H3Cit dominates to pH 2.7; pKa values from the reference table give log β's of +12.90, +10.00, +5.65 for H3L, H2L-, HL2-, i.e. stepwise pKa1 ≈ 2.9, pKa2 ≈ 4.35, pKa3 ≈ 5.65 for citric acid), so citrate cannot yet compete with water for Ni2+ and ~96 % of nickel is the aquo ion. As the second and third carboxylates deprotonate (pH 3–5), the protonated 1:2 complex [Ni(Citr)2H]3- (log β = +13.29) briefly dominates near pH 4, before being replaced from pH ≈ 4.3 upward by the fully deprotonated bis-citrate chelate **[Ni(Citr)2]4-** (log β = +8.13 from free Ni2+ + 2 L3-, but strongly favoured once L3- is the dominant ligand form above pH 5). This bis-chelate carries Ni through the entire mid-pH window and peaks at 96.8 % of Ni near pH 7.6; with [L]_total/[Ni]_total = 10, the 1:2 stoichiometry is well supplied and the 1:1 [Ni(Citr)]- never dominates.

At pH 9 the ligand field is essentially all L3- (Cit3- = 8.17e-3 M of the 1.0e-2 total) and [Ni(Citr)2]4- still holds 82.9 % of nickel. Free Ni2+ has been suppressed by nearly four orders of magnitude relative to the uncomplexed case (1e-3 M → 4.03e-7 M). This is exactly the scaling-suppression regime citrate is chosen for: the activity driving CaCO3-type co-precipitation or Ni(OH)2 nucleation is set by [Ni2+], which the chelate holds at sub-µM levels. Correspondingly, at pH 9.00 the Ni(OH)2(s) saturation column is zero — the solid is **not** saturated, consistent with free [Ni2+] = 4.0e-7 M being well below the solubility implied by the atlas log Ksp (dissolution log β = -11.71 for Ni(OH)2 ⇌ Ni2+ + 2 OH-, i.e. [Ni2+]_sat ≈ 10^(-11.71)/[OH-]^2 ≈ 2e-2 M at pH 9, dropping to ≈ 2e-6 M at pH 11; the pipeline's own first precipitation sample confirms this crossing between pH 9.1 and 9.2).

Ni(OH)2(s) **first precipitates at pH 9.20** (1.94e-6 M of solid), and from pH 9.4 upward the hydroxide out-competes even the bis-citrate chelate: free [Ni2+] is clamped by the solid at ~10^(-7)–10^(-8) M and the aqueous citrate complex fraction collapses as Ni is drained into Ni(OH)2(s), which reaches ~100 % by pH 11.3. A minor binuclear hydroxo-citrate [Ni2(Citr)2(OH)2]4- (log β = -4.32) peaks at only 26 % near pH 9.2 and does not change the picture. Practically: at pH 9 with 10 mM citrate the system is a homogeneous solution of [Ni(Citr)2]4- with vanishing free Ni2+ and no hydroxide scale; raising pH by only ~0.2 units crosses into Ni(OH)2 precipitation, so operating headroom above pH 9 is small and ligand excess or lower pH is required to keep the solution clear.

## Artifacts
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png
- L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png
- L1_call_02/thermodynamic_reference_constants.md
```


## Tool call 3 — `dispatch_l1_pipeline` (iteration 3)

### Arguments
```json
{
  "purpose": "Compute Ni(II) speciation with ammonia to determine free Ni2+ at pH 9 for scaling suppression assessment, comparing against glycine and citrate.",
  "tasks": "Run a pH speciation sweep of a single pot containing 1 mM Ni(II) total and 10 mM ammonia (NH3/NH4+) total over pH 2 to 12 at 25 C and ionic strength 0.1 M (fixed-I mode), redox excluded. Include all Ni(II) ammine complexes [Ni(NH3)n]2+ (n=1..6), Ni hydroxo species, and the solid Ni(OH)2(s). Report the full Ni dominance ladder across the pH window, and at pH 9.00 report the fraction of total Ni present as free Ni2+, the free [Ni2+] in molar, the dominant Ni species and its fraction, and whether Ni(OH)2(s) is saturated. Also report the pH at which Ni(OH)2(s) first precipitates."
}
```

### Reasoning excerpt
```
<summary>Citrate done (free [Ni2+] ≈ 4.0e-7 M at pH 9). Now need the ammonia case to complete the three-way ranking.</summary>
```

### Result (4586 chars)
```
## Doability
Doable. Ni(II) + NH3 is well within SRD-46 coverage; all six ammines, three Ni hydroxo monomers, Ni4(OH)4(4+), and the Ni(OH)2(s) dissolution record were included (see thermodynamic reference table). Fixed-I 0.1 M, T = 25 C, 101/101 pH samples converged.

## Result
- System: 1.00e-3 M Ni(II) + 1.00e-2 M NH3/NH4+ total; pH 2.0-12.0 (0.1 step); fixed I = 0.1 M; T = 25 C; redox excluded.
- Convergence: 101/101 samples converged (full window).
- Method: pH_sweep (1-D speciation). Deliverables: full fraction CSV, concentrations CSV, verdict, phase-balance / log-conc plots.
- Ammonia proton balance: HAmmonia+ dominates 2.0-9.3; NH3(aq) dominates 9.3-12.0 (card pKa for NH4+ = 9.26).

## Analysis

### Ni dominance ladder (fraction of Ni_total)
From the solver verdict and `*_frac_metal.csv`:
- pH 2.0 - 8.3: free Ni2+ dominates (>=50%). At pH 2.0 essentially 100% is Ni2+; the ammines stay negligible because at pH < 8 the ligand is almost entirely locked up as NH4+ (pKa 9.26), so free [NH3] is <<10 mM.
- pH ~8.1-8.2: Ni(OH)2(s) first appears (precipitation record: pH 8.10, 1.05e-4 M solid). Within one grid step the solid rises past the dissolved pool: Ni2+ ~65% / solid ~10% at pH 8.1, then Ni2+ ~41% / solid ~39% at pH 8.2, then solid takes over.
- pH >= 8.3: Ni(OH)2(s) is dominant and climbs to >99% by pH 10.5.
- The ammines never dominate: [Ni(NH3)]2+ peaks only at 22.0% near pH 8.1 (verdict), and higher ammines (Ni(NH3)2..6 2+) stay below ~2% throughout, because by the time enough free NH3 is liberated (pH > 9) the metal has already been swept into the hydroxide solid.

Chemically, 10 mM total NH3 is too weak a reservoir at this pH window to beat Ni(OH)2 precipitation: the ammonia-complex 'protection' is kinetically defeated by the acid-base speciation of the ligand itself.

### Point values at pH 9.00 (from `*_frac_metal.csv`, row pH=9.0000)
- Free Ni2+ fraction of Ni_total: 1.032e-2 (1.03%).
- Free [Ni2+] = (1.032e-2)(1.00e-3 M) = 1.03e-5 M.
- Dominant Ni species: Ni(OH)2(s) with fraction 9.576e-1 (95.76%).
- Next: [Ni(NH3)]2+ 1.96e-2 (1.96%), [Ni(NH3)2]2+ 9.99e-3, [Ni(OH)2](aq) 6.31e-4, [Ni(OH)]+ 2.51e-4.
- Ni(OH)2(s) saturation at pH 9: YES - the solid is present as the majority Ni phase (95.76%), so the aqueous pool is at saturation with respect to Ni(OH)2(s). The soluble sum (Ni2+ + all aqueous hydroxo + all ammines) is 4.24e-2 of total Ni, i.e. ~4.24e-5 M total dissolved Ni.

### pH of first Ni(OH)2(s) appearance
From the solver 'Precipitation' block the solid is first non-zero at pH 8.10 (1.05e-4 M). The adjacent grid points show zero solid at pH <= 8.00 and 1.05e-4 M at pH 8.10, so the onset is bracketed between pH 8.00 and 8.10. The Ni2+/Ni(OH)2(s) 50/50 crossover is reported at pH ~ 8.21.

### Practical reading for scaling suppression
At pH 9 with only 10 mM NH3, ammonia is a poor Ni2+ masking agent: free Ni2+ is already down to ~1e-5 M, but 95.8% of the Ni has dropped out as Ni(OH)2(s). Any 'free Ni' control via NH3 at pH 9 is really control by precipitation, not by complexation - the Ni(NH3)n(2+) series never carries more than a few percent of the metal. To suppress Ni(OH)2 scaling via ammine complexation one would need either (i) much higher total NH3 (so free [NH3] at pH 9 is tens of mM, pushing the beta6 term up), or (ii) a ligand whose pKa is well below the hydrolysis onset, so that the free ligand concentration is already large at the pH where Ni(OH)2(s) would otherwise saturate (this is where glycine, and especially citrate, outperform NH3 for Ni2+ masking near neutral pH).

## Artifacts
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png
- L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png
- L1_call_03/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verdict file confirms ladder (Ni2+ 2.0-8.3; Ni(OH)2(s) 8.3-12.0)
  - Ni(Ammo) peak 22% at pH 8.1
  - precipitation onset pH 8.10
  - crossover pH 8.21. Point values at pH 9 (free Ni2+ ~1%
  - Ni(OH)2(s) ~96% dominant) are consistent with the dominance ladder. Ammonia protonation (pKa 9.26) and conclusion about weak NH3 masking are grounded in the free-energy table and ladder.

```

## Answer

**Ranking by free [Ni²⁺] remaining in solution at pH 9 (1 mM Ni, 10 mM ligand, 25 °C, I = 0.1 m):**

| Rank | Ligand | Free [Ni²⁺] at pH 9 | Dominant Ni form | Ni(OH)₂(s) at pH 9? |
|---|---|---:|---|---|
| 1 (best) | **Glycine** | ~3 × 10⁻⁹ M (3 nM) | [Ni(Gly)₃]⁻ (88 %), [Ni(Gly)₂]⁰ (12 %) | No — strongly undersaturated |
| 2 | **Citrate** | ~4.0 × 10⁻⁷ M | [Ni(Cit)₂]⁴⁻ (83 %) | No — but onset at pH 9.2 |
| 3 (worst) | **Ammonia** | ~1.0 × 10⁻⁵ M | **Ni(OH)₂(s)** (96 %); ammines <3 % | **Yes — 96 % of Ni already precipitated** |

**Glycine is the clear winner**, holding free Ni²⁺ roughly 100× below citrate and ~3500× below ammonia, with no hydroxide scale forming until ~pH 11.6.

### Chemical ordering — why this ranking makes sense

The ranking is set by **when each ligand's conjugate base becomes available relative to the pH where Ni(OH)₂(s) starts to precipitate (~pH 8–9 for 1 mM Ni with no ligand)**.

- **Glycine (pKₐ₂ ≈ 9.57, log β₁ 5.74, β₂ 10.58, β₃ 14.10).** Glycinate (Gly⁻) is already present at ~10 % of total glycine by pH 9, and the three successive log K steps (5.74, 4.84, 3.52) are high enough that with a 10:1 ligand excess, Ni is driven all the way to the anionic tris-chelate [Ni(Gly)₃]⁻. Three five-membered N,O chelate rings make this an exceptionally stable sink, suppressing [Ni²⁺] to ~3 nM — roughly five orders of magnitude below the hydroxide-precipitation threshold. Scale onset is pushed to pH ~11.6.

- **Citrate (pKₐ₁₋₃ ≈ 2.9 / 4.35 / 5.65).** Citrate is **fully deprotonated well before pH 9**, so Cit³⁻ is abundant (8.2 mM of 10 mM total). The polydentate bis-citrate chelate [Ni(Cit)₂]⁴⁻ (log β ≈ 8 vs Ni²⁺ + 2 Cit³⁻) carries 83 % of Ni at pH 9 and clamps free Ni²⁺ at ~4 × 10⁻⁷ M. Citrate loses to glycine because its overall affinity for Ni²⁺ is lower (the tris-glycinate β₃ = 14.1 is unmatched) and because at pH 9.2 Ni(OH)₂(s) starts to co-precipitate — the operating headroom above pH 9 is only ~0.2 units.

- **Ammonia (pKₐ of NH₄⁺ = 9.26).** This is the key failure mode. At pH 9, over half of the total "ammonia" is still **NH₄⁺**, which does not coordinate Ni²⁺. Free NH₃ activity is therefore too low to drive the Ni(NH₃)ₙ²⁺ series — [Ni(NH₃)]²⁺ peaks at only ~22 % near pH 8.1, and the higher ammines never exceed a few percent. Meanwhile, Ni(OH)₂(s) **nucleates at pH 8.10** and the Ni²⁺/Ni(OH)₂(s) 50/50 crossover is at pH 8.21 — i.e. the hydroxide forms **before** the ligand is deprotonated enough to compete. At pH 9, 96 % of the Ni has dropped out as the hydroxide solid; the "low" free [Ni²⁺] of ~10⁻⁵ M is just the saturation value above a Ni(OH)₂(s) precipitate, not evidence of complexation. Ammonia would only start to work if its total concentration were much higher, or if the target pH were well above the ligand's pKₐ.

### Bottom line

**Pick glycine.** The ordering free [Ni²⁺]_Gly ≪ free [Ni²⁺]_Cit ≪ free [Ni²⁺]_NH₃ follows directly from (i) ligand basicity relative to the hydroxide-precipitation pH, and (ii) the overall stability of the highest Ni complex each ligand can form at pH 9: a strong anionic tris-chelate (glycine) beats a bis-polydentate chelate (citrate) beats a protonation-crippled mono/bis-ammine (ammonia). Glycine not only gives the lowest free [Ni²⁺] but also the widest safe pH margin before Ni(OH)₂ scaling resumes.

## Evidence

- **Glycine at pH 9:** "free [Ni²⁺] at pH 9 ≈ 2.95e−6 × 1.00e−3 = 3.0 × 10⁻⁹ M (3 nM)"; "[Ni(Glyc)₃]⁻ carries ~88% of the nickel and [Ni(Glyc)₂]° carries ~12%"; "Ni(OH)₂(s) first appears only at pH 11.60"; "Q/K_sp ≈ 2e−6, i.e. ~6 orders of magnitude undersaturated." (L1 call 1)
- **Citrate at pH 9:** "Free aquo Ni2+ concentration: 4.03e-7 M"; "[Ni(Citr)2]4-, fraction of Ni_total = 8.287e-1 (≈ 82.9 %)"; "Ni(OH)2(s) at pH 9.00: 0 M — not saturated"; "Ni(OH)2(s) first precipitates at pH 9.20." (L1 call 2)
- **Ammonia at pH 9:** "Free [Ni2+] = (1.032e-2)(1.00e-3 M) = 1.03e-5 M"; "Dominant Ni species: Ni(OH)2(s) with fraction 9.576e-1 (95.76%)"; "[Ni(NH3)]2+ peaks only at 22.0% near pH 8.1"; "Ni(OH)2(s) first appears at pH 8.10 (1.05e-4 M)"; "Ni2+/Ni(OH)2(s) 50/50 crossover at pH ~8.21." (L1 call 3)
- **Key constants:** glycine log β₁/β₂/β₃ = 5.74 / 10.58 / 14.10, glycinate pKₐ = 9.57; citric acid stepwise pKₐ ≈ 2.9 / 4.35 / 5.65, [Ni(Cit)₂]⁴⁻ log β ≈ 8.13; NH₄⁺ pKₐ = 9.26.

## Artifacts

Glycine (winner):
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_phase_balance_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`

Citrate (runner-up):
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_Ni.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_log_conc.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_frac_metal.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Citric_acid_verdict.md`

Ammonia (fails — precipitates):
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md`
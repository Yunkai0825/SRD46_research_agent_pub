## Answer

**Hypothesis (testable form).** If the chelate effect is real, then at pH 7 with 1 mM Ni(II), bidentate ethylenediamine (en) at 10 mM — which supplies the *same total number of N-donor atoms* (20 mmol N) as 20 mM monodentate ammonia — should leave substantially less free [Ni²⁺] in solution than the ammonia control. A null (or opposite) result would refute the chelate effect at these conditions.

**Verdict: strongly supported.** At pH 7, 25 °C, I = 0.1 M:

| System | Free [Ni²⁺] | Fraction of total Ni as free Ni²⁺ | Dominant Ni species |
|---|---|---|---|
| 1 mM Ni + 10 mM ethylenediamine | **2.87 × 10⁻⁶ M** | 0.29 % | [Ni(en)₂]²⁺ (~79 %) |
| 1 mM Ni + 20 mM ammonia | **9.44 × 10⁻⁴ M** | 94.4 % | free Ni²⁺(aq) |

Ethylenediamine depresses free [Ni²⁺] by a factor of **~329** (9.44 × 10⁻⁴ / 2.87 × 10⁻⁶) relative to ammonia at matched donor-atom inventory — about **2.5 orders of magnitude**. The chelate effect is confirmed.

**Chemical interpretation — why en wins so decisively.** Both ligands bind Ni(II) through neutral amine N-donors, so the per-bond enthalpy of coordination is comparable. The difference is entirely entropic / connectivity-driven:

- In the ammonia case, assembling a hexammine [Ni(NH₃)₆]²⁺ requires six independent NH₃ molecules to find the metal; each successive step pays an entropic cost and is driven only by log K ~ 2 per NH₃. More damagingly, **ammonia is 99.5 % protonated at pH 7** (pKₐ(NH₄⁺) = 9.26), so of the 20 mM nominal total, only [NH₃] = 1.09 × 10⁻⁴ M is actually available. The result is that even the mono-ammine never exceeds a few percent, and *free aquo Ni²⁺ is the overwhelming species* at pH 7.

- In the en case, binding each ligand is a single bimolecular event that installs *two* N-donors at once — the second donor is pre-positioned by the ethylene backbone, so its coordination costs essentially no translational entropy. This shows up as log β₂ = 13.44 for [Ni(en)₂]²⁺, versus log β₄ ≈ 7.9 for [Ni(NH₃)₄]²⁺ (four equivalent monodentate N-donors). Even though **en is also mostly protonated at pH 7** (H₂en²⁺ 55 %, Hen⁺ 26 %, free en only ~3 × 10⁻⁶ M), the enormous β₂ makes trace amounts of free en sufficient to sequester 99.7 % of the Ni(II).

**Secondary signatures of chelation.** The en system also suppresses Ni(OH)₂(s) precipitation entirely across pH 2–12, whereas the ammonia system precipitates Ni(OH)₂(s) above pH 8.2 (reaching 99.9 % of total Ni by pH 10.7). Chelation keeps Ni in soluble, cationic form; monodentate NH₃ cannot compete with hydroxide and loses the metal to the solid phase.

**Bottom line.** The computation quantitatively supports the chelate effect: at matched donor-atom inventory and matched pH, bidentate en lowers free [Ni²⁺] by a factor of ~329 (ΔlogK_apparent ≈ 2.5) relative to monodentate NH₃, and additionally protects Ni(II) against hydroxide precipitation. Both signatures are classic consequences of chelate ring closure.

## Evidence

- **Ethylenediamine system (pH 7):** "Free [Ni²⁺] = 2.87 × 10⁻⁶ M (≈ 0.29 % of the 1 mM Ni(II) total). [Ni(en)₂]²⁺ = 7.87 × 10⁻⁴ M (~79 %)… [Ni(en)]²⁺ = 1.81 × 10⁻⁴ M (~18 %)… [Ni(en)₃]²⁺ = 2.92 × 10⁻⁵ M (~2.9 %)." (L1 call 1)
- **Ammonia system (pH 7):** "Free [Ni²⁺] = 9.437 × 10⁻⁴ M (94.4 % of total Ni); [Ni(NH₃)]²⁺ = 5.52 × 10⁻⁵ M (5.5 %); [Ni(NH₃)₂]²⁺ = 8.70 × 10⁻⁷ M; … Free NH₃ = 1.09 × 10⁻⁴ M; NH₄⁺ = 1.98 × 10⁻² M (ammonia 99.5 % protonated)." (L1 call 2)
- **Ratio:** 9.437 × 10⁻⁴ / 2.87 × 10⁻⁶ ≈ 329× suppression of free Ni²⁺ by en vs NH₃.
- **Formation constants (from the thermodynamic reference):** en — log β₁ = 7.30, log β₂ = 13.44, log β₃ = 17.51; NH₃ — stepwise log K ~ 2.7, 2.1, 1.4, …, log β₆ = 8.30. The gap between log β₂(en) = 13.44 and log β₄(NH₃) ≈ 7.9 (same four N-donors) is the quantitative chelate-effect increment.
- **Hydrolysis / solid:** en suppresses Ni(OH)₂(s) across pH 2–12; NH₃ allows Ni(OH)₂(s) to precipitate at pH ≥ 8.20, reaching 99.9 % of Ni at pH 10.7. Both runs: 51–101 pH grid points, 100 % converged.

## Artifacts

- Ethylenediamine run:
  - `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png` — Ni fraction vs pH
  - `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_log_conc.png` — all species, log-conc vs pH
  - `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv` — full numeric table
  - `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md` — deterministic verdict
- Ammonia run:
  - `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png`
  - `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png`
  - `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv`
  - `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md`
- Shared reference: `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_02/thermodynamic_reference_constants.md`
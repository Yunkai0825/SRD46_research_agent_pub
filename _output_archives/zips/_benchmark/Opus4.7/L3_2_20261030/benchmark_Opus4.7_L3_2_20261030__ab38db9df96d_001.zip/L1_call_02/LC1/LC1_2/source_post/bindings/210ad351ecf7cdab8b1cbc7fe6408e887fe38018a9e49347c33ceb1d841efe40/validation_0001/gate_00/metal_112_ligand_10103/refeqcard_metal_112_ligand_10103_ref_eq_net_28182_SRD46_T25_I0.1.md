# Free Energy Analysis Card

**System**: metal_112 + ligand_10103
**Metals**: [Ni]2+
**Ligands**: [Ammonia]
**Generated**: 2026-11-03 03:15:02 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Ni$+2 | Metal component: [Ni]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ammonia] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Ni$+2 | [Ni]2+ | +2 | Not defined | NIST SRD-46 | metal_112 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ammonia] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_10103 | N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ni | Ni$+2 | [Ni]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ammonia] | N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Ni$+2 | [Ni]2+ | metal | [Ni]2+(aq) | +0.0000 | R1 | Ni | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Ammonia] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ammonia] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Ni]2+ + [Ammonia] | 25.0 | 0~0.1 | 28182 | 6 |
| [H]+ + [Ammonia] | 25.0 | 0.1 | 28125 | 1 |
| [Ni]2+ + [OH]- | 25.0 | 0~0.1 | 27414 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H][L1]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L1]]:+1 | vlm_173034 | true | *** |
| [L1].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Ni]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Ni$+2].[z+2] | [Ni]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Ni$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Ni]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Ni$+2].[L1]5.[z+2] | [Ni(Ammo)5]2+ | +2 | aqueous | +8.3300 | -47.5451 | -47.5451 | -47.5451 | [Ni$+2]:+1, [L1]:+5 | vlm_173227 | true | *** |
| [Ni$+2].[L1]6.[z+2] | [Ni(Ammo)6]2+ | +2 | aqueous | +8.3000 | -47.3738 | -47.3738 | -47.3738 | [Ni$+2]:+1, [L1]:+6 | vlm_173235 | true | *** |
| [Ni$+2].[L1]4.[z+2] | [Ni(Ammo)4]2+ | +2 | aqueous | +7.6700 | -43.7780 | -43.7780 | -43.7780 | [Ni$+2]:+1, [L1]:+4 | vlm_173218 | true | *** |
| [Ni$+2].[L1]3.[z+2] | [Ni(Ammo)3]2+ | +2 | aqueous | +6.5400 | -37.3283 | -37.3283 | -37.3283 | [Ni$+2]:+1, [L1]:+3 | vlm_173208 | true | *** |
| [Ni$+2].[L1]2.[z+2] | [Ni(Ammo)2]2+ | +2 | aqueous | +4.8900 | -27.9106 | -27.9106 | -27.9106 | [Ni$+2]:+1, [L1]:+2 | vlm_173193 | true | *** |
| [Ni$+2].[L1].[z+2] | [Ni(Ammo)]2+ | +2 | aqueous | +2.7300 | -15.5820 | -15.5820 | -15.5820 | [Ni$+2]:+1, [L1]:+1 | vlm_173182 | true | *** |

#### [Ni]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Ni$+2].[OH].[z+1] | [Ni(OH)]+ | +1 | aqueous | -10.4000 | +59.3600 | +59.3600 | +59.3600 | [Ni$+2]:+1, [OH]:+1 | vlm_170699 | true | *** |
| [Ni$+2].[OH]2.[z+0] | [Ni(OH)2] | +0 | aqueous | -19.0000 | +108.4461 | +108.4461 | +108.4461 | [Ni$+2]:+1, [OH]:+2 | vlm_170704 | true | *** |
| [Ni$+2]4.[OH]4.[z+4] | [Ni4(OH)4]4+ | +4 | aqueous | -27.7000 | +158.1031 | +158.1031 | +158.1031 | [Ni$+2]:+4, [OH]:+4 | vlm_170709 | true | *** |
| [Ni$+2].[OH]3.[z-1] | [Ni(OH)3]- | -1 | aqueous | -30.0000 | +171.2308 | +171.2308 | +171.2308 | [Ni$+2]:+1, [OH]:+3 | vlm_170705 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Ni]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Ni$+2].[OH]2.[z+0]_(s) | [Ni(OH)2](s) | +0 | dissolution | -12.8000 | +73.0585 | +73.0585 | +73.0585 | [Ni$+2]:+1, [OH]:+2 | vlm_170712 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 12 |
| Included in calculation | 12 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 12 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_173218 | [<Ammonia>]^4 + [<Ni2+>] <=> [<Ni2+><Ammonia>4] | +7.6700 | 25.0 | 0.000 | yes | [Ni(Ammo)4]2+ |
| 2 | vlm_173193 | [<Ammonia>]^2 + [<Ni2+>] <=> [<Ni2+><Ammonia>2] | +4.8900 | 25.0 | 0.100 | yes | [Ni(Ammo)2]2+ |
| 3 | vlm_173227 | [<Ammonia>]^5 + [<Ni2+>] <=> [<Ni2+><Ammonia>5] | +8.3300 | 25.0 | 0.000 | yes | [Ni(Ammo)5]2+ |
| 4 | vlm_173235 | [<Ammonia>]^6 + [<Ni2+>] <=> [<Ni2+><Ammonia>6] | +8.3000 | 25.0 | 0.000 | yes | [Ni(Ammo)6]2+ |
| 5 | vlm_173208 | [<Ammonia>]^3 + [<Ni2+>] <=> [<Ni2+><Ammonia>3] | +6.5400 | 25.0 | 0.000 | yes | [Ni(Ammo)3]2+ |
| 6 | vlm_173182 | [<Ammonia>] + [<Ni2+>] <=> [<Ni2+><Ammonia>] | +2.7300 | 25.0 | 0.100 | yes | [Ni(Ammo)]2+ |
| 7 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 8 | vlm_170699 | [<OH->] + [<Ni2+>] <=> [<Ni2+><OH->] | +3.6000 | 25.0 | 0.100 | yes | [Ni(OH)]+ |
| 9 | vlm_170704 | [<OH->]^2 + [<Ni2+>] <=> [<Ni2+><OH->2] | +9.0000 | 25.0 | 0.000 | yes | [Ni(OH)2] |
| 10 | vlm_170705 | [<OH->]^3 + [<Ni2+>] <=> [<Ni2+><OH->3] | +12.0000 | 25.0 | 0.000 | yes | [Ni(OH)3]- |
| 11 | vlm_170709 | [<OH->]^4 + [<Ni2+>]^4 <=> [<Ni2+>4<OH->4] | +28.3000 | 25.0 | 0.000 | yes | [Ni4(OH)4]4+ |
| 12 | vlm_170712 | [<Ni2+><OH->2(s)] <=> [<OH->]^2 + [<Ni2+>] | -15.2000 | 25.0 | 0.000 | yes | [Ni(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

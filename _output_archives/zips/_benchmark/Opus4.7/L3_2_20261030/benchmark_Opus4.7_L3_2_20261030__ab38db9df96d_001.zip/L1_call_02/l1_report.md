## Doability
Doable. SRD-46 provides Ni(II) hydrolysis species, Ni(OH)2(s), the full [Ni(NH3)n]2+ series (n=1-6) and the NH4+/NH3 acid-base pair. All conditions (25 C, I=0.1 M, pH 2-12, 1 mM Ni, 20 mM NH3-total) are inside the toolkit's standard scope.

## Result
System: Ni(II) (1.00 mM) + total ammonia (20.0 mM), 25 C, I=0.1 M fixed, pH 2.0-12.0 (101 points), redox excluded.
Convergence: 101/101 pH points for every component. Precipitation of Ni(OH)2(s) is predicted to begin at pH 8.20 (first solid appearance, 1.59e-4 M).

Dominant Ni(II) regions (verdict):
- pH 2.0 - 8.3: free Ni2+(aq)
- pH 8.3 - 12.0: Ni(OH)2(s)

The ammine complexes [Ni(NH3)n]2+ never become the majority Ni form. The highest aqueous ammine fraction is only ~37% [Ni(NH3)]2+ at pH 8.1, dropping as the solid takes over.

At pH 7.00 (concentrations CSV row):
- Free [Ni2+] = 9.437e-4 M  (94.4% of total Ni)
- [Ni(NH3)]2+ = 5.52e-5 M (5.5%)
- [Ni(NH3)2]2+ = 8.70e-7 M
- [Ni(NH3)3]2+ = 4.24e-9 M; higher ammines <1e-11 M
- [Ni(OH)]+ = 2.30e-7 M, [Ni(OH)2]aq = 5.77e-9 M; no solid yet
- Free NH3 = 1.09e-4 M; NH4+ = 1.98e-2 M (ammonia 99.5% protonated)
Dominant Ni species at pH 7 is therefore the aqua ion Ni2+(aq); the leading complex is mono-ammine, two orders of magnitude smaller.

## Analysis
Why ammonia is such a weak Ni(II) complexant here. The reference table gives log K1(NH4+) = +9.26, so at pH 7 the free-amine fraction is only 10^(7-9.26) ≈ 0.55%. Of the 20 mM nominal ammonia, [NH3] = 1.09e-4 M. Ammine formation requires NH3, not NH4+, so even with log β1 = 2.73 the mono-complex only reaches [Ni2+]·[NH3]·10^2.73 ≈ 9.4e-4 · 1.1e-4 · 537 ≈ 5.5e-5 M, matching the solver. Higher ammines need [NH3]^n and are suppressed by two to three decades per added ligand at this pH. The chelate effect comparison is already visible in this control: a monodentate N-donor whose conjugate acid has pKa ~ 9.3 has essentially no complexing power until pH approaches 9, by which point Ni(OH)2(s) has already taken over.

Where ammines matter and why they still lose. The free NH3 concentration rises steeply above pH 8. The mono-ammine peaks at 37.4% near pH 8.1 and the di-ammine at 7.8% at pH 8.2, exactly in the narrow window where NH3 is finally liberated but hydroxide saturation has not yet consumed all dissolved Ni(II). Above pH 8.2 the system becomes supersaturated with respect to Ni(OH)2(s) (log Ksp = -12.80 from the reference table), so dissolved Ni is removed from solution faster than it can be captured as [Ni(NH3)5]2+ or [Ni(NH3)6]2+, the only ammines with significant log β (8.33 and 8.30). At pH 10.7 the solid peaks at 99.9%, dominant to the top of the pH window.

Hydrolysis speciation. The mononuclear hydroxo series is thermodynamically unfavorable at this Ni total: [Ni(OH)]+ never exceeds 1.7e-6 M (peaks around pH 8.1), [Ni(OH)2]aq caps near 6.3e-7 M (its log β2 = -19 anchors it to Ksp of the solid), and [Ni(OH)3]- rises slowly from pH 10 to only ~5e-6 M at pH 11.7. The polynuclear [Ni4(OH)4]4+ (log β = -27.7) stays below 1e-8 M throughout and never participates. The practical consequence is clean: in 1 mM Ni / 20 mM NH3 solutions, acidic to near-neutral pH preserves essentially all Ni as free Ni2+(aq); passing pH 8.2 precipitates Ni(OH)2(s) long before any serious ammine coordination develops.

Chelate-effect context (control role). For the companion polyamine or EDTA-like calculation the comparator value here is: at pH 7, ammonia (monodentate, log β6 = 8.30, 20 mM total) leaves 94% of 1 mM Ni as free Ni2+. A chelating N-donor at comparable total concentration should sequester Ni essentially completely at the same pH, and - critically - should also suppress Ni(OH)2(s) formation past pH 8.2, which ammonia does not.

## Artifacts
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_state_metrics.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png
L1_call_02/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - pH 7 concentrations
  - envelope dominant species (Ni2+ then Ni(OH)2(s))
  - and reference constants are consistent with the report; ammine suppression by NH4+ protonation is correctly explained.

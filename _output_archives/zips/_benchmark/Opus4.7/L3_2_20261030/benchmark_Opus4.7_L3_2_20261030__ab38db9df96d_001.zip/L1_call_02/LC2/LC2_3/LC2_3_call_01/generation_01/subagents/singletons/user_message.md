[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse pure notational duplicates to the SRD-46 record for internal consistency with the SRD-46 ammine and hydrolysis thermochemistry: drop Ni2+ (Atlas) in favor of [Ni]2+ (SRD-46), drop [HNiO2]- (Atlas) in favor of [Ni(OH)3]- (SRD-46), and drop Ni(OH)2 (Atlas, hydrated_solid) in favor of [Ni(OH)2](s) (SRD-46); keep both [Ni(OH)]+ and [Ni4(OH)4]4+ because at 1 mM total Ni the tetramer genuinely competes with the monomer on the hydrolysis hull. Drop the higher-valent and mixed-valence Ni oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O), elemental Ni, and anhydrous NiO as out-of-scope decorative branches for this no-potential aqueous speciation at fixed pH with only Ni(II) and ammonia in scope.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ammo)]2+` | SRD-46 | +2 | -15.582 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ammo)2]2+` | SRD-46 | +2 | -27.911 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ammo)3]2+` | SRD-46 | +2 | -37.328 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:4` | `[Ni(Ammo)4]2+` | SRD-46 | +2 | -43.778 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:5` | `[Ni(Ammo)5]2+` | SRD-46 | +2 | -47.545 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:6` | `[Ni(Ammo)6]2+` | SRD-46 | +2 | -47.374 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
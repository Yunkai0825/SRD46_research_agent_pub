# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: pure aqueous Ni(II)/NH3 speciation at fixed pH grid, 25 C, I = 0.1 M, 1 mM total Ni, 20 mM total NH3. No applied potential, no redox couple of interest, no CO2 ingress assumed, so Ni(III)/Ni(IV) oxides and elemental Ni are decorative branches that cannot form under the stated conditions.
- Working regime is 1 mM Ni, not the 1e-6 M corrosion convention, so the Ni4(OH)4^4+ tetramer is a genuine competitor against the Ni(OH)+ monomer on the hydrolysis hull and both must be retained; the six ammine complexes [Ni(NH3)n]2+ n=1..6 are all explicitly requested and all stay.
- Hydration: the scenario is aqueous at unit water activity, so only one Ni(OH)2(s) record is needed as a precipitation ceiling. Prefer the SRD-46 Ni(OH)2(s) entry because it is thermochemically consistent with the SRD-46 ammine and hydrolysis set used throughout; drop the Atlas Ni(OH)2 duplicate and drop anhydrous NiO (same stoichiometry, less stable hydrated form governs the aqueous boundary).
- Counterions: ammonia is the only ligand in scope; no carbonate, sulfate, chloride, or phosphate solids are relevant.
- Mixed-valence and higher oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and elemental Ni belong to redox branches outside this no-potential speciation question and are dropped as decorative.
- Phase question is which aqueous species dominate at each pH, with Ni(OH)2(s) as a possible precipitation boundary; collapse pure notational duplicates of the same aqueous monomer to one SRD-46 record for internal consistency with the ammine thermochemistry, but keep all genuinely distinct stoichiometries (monomer vs tetramer hydrolysis, each ammine n).
- One rule set suffices here because only Ni is present.

## Element instructions

- **Ni**: Collapse pure notational duplicates to the SRD-46 record for internal consistency with the SRD-46 ammine and hydrolysis thermochemistry: drop Ni2+ (Atlas) in favor of [Ni]2+ (SRD-46), drop [HNiO2]- (Atlas) in favor of [Ni(OH)3]- (SRD-46), and drop Ni(OH)2 (Atlas, hydrated_solid) in favor of [Ni(OH)2](s) (SRD-46); keep both [Ni(OH)]+ and [Ni4(OH)4]4+ because at 1 mM total Ni the tetramer genuinely competes with the monomer on the hydrolysis hull. Drop the higher-valent and mixed-valence Ni oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O), elemental Ni, and anhydrous NiO as out-of-scope decorative branches for this no-potential aqueous speciation at fixed pH with only Ni(II) and ammonia in scope.

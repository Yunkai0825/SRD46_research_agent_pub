## Case-specific recommendations

- **Purpose and scenario**: Pure Ni(II) aqueous speciation vs pH at fixed total Ni (1 mM) and total NH₃ (20 mM), 25 °C, I = 0.1 M. No applied potential, no redox couple of interest, no CO₂/carbonate ligand. Treat the hull as a solubility/complexation diagram only; redox phases are decorative.
- **Working concentration and protonation states**: At [Ni]_T = 1 mM the mononuclear hydrolysis monomers ([Ni(OH)]⁺, [Ni(OH)₂]°, [Ni(OH)₃]⁻) are the real competitors, but the Ni₄(OH)₄⁴⁺ tetramer can still contribute near the solubility edge at 1 mM — keep it. Collapse pure notational duplicates of the same monomer to one record and prefer the SRD-46 spelling so the hydrolysis chain is thermochemically consistent with the SRD-46 ammine ladder.
- **Ammine ladder**: All six [Ni(NH₃)ₙ]²⁺ (n = 1–6) are distinct competing states at 20 mM NH₃ and must all be retained; none are duplicates of each other.
- **Hydrated vs anhydrous solids**: Aqueous scenario at 25 °C — the only solid that can cap the diagram is β-Ni(OH)₂(s). Keep one Ni(OH)₂(s) record (SRD-46, to match the aqueous chain); the Atlas Ni(OH)₂ and SRD-46 [Ni(OH)₂](s) are the same hydroxide polymorph for this purpose, so collapse to one. Anhydrous NiO is not the phase that precipitates from mM Ni(II) at room temperature and is out of scope here.
- **Counterion solids / carbonates**: None in scope — no carbonate, sulfate, or chloride ligand declared.
- **Mixed-valence / higher oxides**: Ni₃O₄·2H₂O, Ni₂O₃·H₂O, NiO₂·2H₂O belong to the Ni(III)/Ni(IV) redox chain and are irrelevant to a pure Ni(II) speciation calculation with no imposed potential — drop as out-of-scope.
- **Elemental reference**: Ni(0) metal is only meaningful on a Pourbaix diagram with an electrode; drop here.
- **STABLE vs FORMS**: Question asks which species form and their concentrations — retain every distinct Ni(II) aqueous state; only collapse pure notational redundancy.
- **Divergence across elements**: Single element (Ni); one instruction suffices.

## Element instruction

**Ni**: Keep one SRD-46 record each for Ni²⁺, for the mononuclear [Ni(OH)₃]⁻ / [HNiO₂]⁻ pair, and for Ni(OH)₂(s) (prefer SRD-46 spellings throughout for consistency with the SRD-46 ammine ladder); retain all six [Ni(NH₃)ₙ]²⁺ complexes, the [Ni(OH)]⁺ and [Ni(OH)₂]° monomers, and the Ni₄(OH)₄⁴⁺ tetramer as distinct competing states at 1 mM Ni. Drop Ni(0) metal, anhydrous NiO, and the Ni(III)/Ni(IV) oxides (Ni₃O₄·2H₂O, Ni₂O₃·H₂O, NiO₂·2H₂O) as out of scope for a pure Ni(II) aqueous speciation calculation with no imposed potential and no redox couple.
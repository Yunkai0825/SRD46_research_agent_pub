Session finalized. The deduplicated Ni(II)/NH3 speciation set retains:

- **Aqueous Ni(II) monomers (SRD-46):** [Ni]2+, [Ni(OH)]+, [Ni(OH)2](aq), [Ni(OH)3]-
- **Aqueous Ni(II) polynuclear (SRD-46):** [Ni4(OH)4]4+ (retained as genuine competitor at 1 mM total Ni)
- **Ni(II) ammine complexes (SRD-46):** [Ni(NH3)n]2+ for n = 1-6, all explicitly requested
- **Precipitation ceiling:** [Ni(OH)2](s) (SRD-46 hydrated form)
- **Solvent / ligand references:** H2O, NH3, NH4+

Dropped as notational duplicates (collapsed to SRD-46 for internal thermochemical consistency with the ammine set):
- Atlas Ni2+, Atlas [HNiO2]-, Atlas Ni(OH)2

Dropped as out-of-scope redox or decorative branches (no applied potential, no oxidant):
- Elemental Ni(0), anhydrous NiO, Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O
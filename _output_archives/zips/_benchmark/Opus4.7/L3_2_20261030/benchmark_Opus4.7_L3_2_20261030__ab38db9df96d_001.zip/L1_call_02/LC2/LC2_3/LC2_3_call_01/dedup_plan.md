# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: pure aqueous Ni(II)/NH3 speciation at fixed pH grid, 25 C, I = 0.1 M, 1 mM total Ni, 20 mM total NH3. No applied potential, no redox couple of interest, no CO2 ingress assumed, so Ni(III)/Ni(IV) oxides and elemental Ni are decorative branches that cannot form under the stated conditions.
- Working regime is 1 mM Ni, not the 1e-6 M corrosion convention, so the Ni4(OH)4^4+ tetramer is a genuine competitor against the Ni(OH)+ monomer on the hydrolysis hull and both must be retained; the six ammine complexes [Ni(NH3)n]2+ n=1..6 are all explicitly requested and all stay.
- Hydration: the scenario is aqueous at unit water activity, so only one Ni(OH)2(s) record is needed as a precipitation ceiling. Prefer the SRD-46 Ni(OH)2(s) entry because it is thermochemically consistent with the SRD-46 ammine and hydrolysis set used throughout; drop the Atlas Ni(OH)2 duplicate and drop anhydrous NiO (same stoichiometry, less stable hydrated form governs the aqueous boundary).
- Counterions: ammonia is the only ligand in scope; no carbonate, sulfate, chloride, or phosphate solids are relevant.
- Mixed-valence and higher oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and elemental Ni belong to redox branches outside this no-potential speciation question and are dropped as decorative.
- Phase question is which aqueous species dominate at each pH, with Ni(OH)2(s) as a possible precipitation boundary; collapse pure notational duplicates of the same aqueous monomer to one SRD-46 record for internal consistency with the ammine thermochemistry, but keep all genuinely distinct stoichiometries (monomer vs tetramer hydrolysis, each ammine n).
- One rule set suffices here because only Ni is present.

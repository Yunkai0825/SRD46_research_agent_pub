## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: pure aqueous Ni(II)/NH3 speciation at fixed pH grid, 25 C, I = 0.1 M, 1 mM total Ni, 20 mM total NH3. No applied potential, no redox couple of interest, no CO2 ingress assumed, so Ni(III)/Ni(IV) oxides and elemental Ni are decorative branches that cannot form under the stated conditions.
- Working regime is 1 mM Ni, not the 1e-6 M corrosion convention, so the Ni4(OH)4^4+ tetramer is a genuine competitor against the Ni(OH)+ monomer on the hydrolysis hull and both must be retained; the six ammine complexes [Ni(NH3)n]2+ n=1..6 are all explicitly requested and all stay.
- Hydration: the scenario is aqueous at unit water activity, so only one Ni(OH)2(s) record is needed as a precipitation ceiling. Prefer the SRD-46 Ni(OH)2(s) entry because it is thermochemically consistent with the SRD-46 ammine and hydrolysis set used throughout; drop the Atlas Ni(OH)2 duplicate and drop anhydrous NiO (same stoichiometry, less stable hydrated form governs the aqueous boundary).
- Counterions: ammonia is the only ligand in scope; no carbonate, sulfate, chloride, or phosphate solids are relevant.
- Mixed-valence and higher oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and elemental Ni belong to redox branches outside this no-potential speciation question and are dropped as decorative.
- Phase question is which aqueous species dominate at each pH, with Ni(OH)2(s) as a possible precipitation boundary; collapse pure notational duplicates of the same aqueous monomer to one SRD-46 record for internal consistency with the ammine thermochemistry, but keep all genuinely distinct stoichiometries (monomer vs tetramer hydrolysis, each ammine n).
- One rule set suffices here because only Ni is present.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse pure notational duplicates to the SRD-46 record for internal consistency with the SRD-46 ammine and hydrolysis thermochemistry: drop Ni2+ (Atlas) in favor of [Ni]2+ (SRD-46), drop [HNiO2]- (Atlas) in favor of [Ni(OH)3]- (SRD-46), and drop Ni(OH)2 (Atlas, hydrated_solid) in favor of [Ni(OH)2](s) (SRD-46); keep both [Ni(OH)]+ and [Ni4(OH)4]4+ because at 1 mM total Ni the tetramer genuinely competes with the monomer on the hydrolysis hull. Drop the higher-valent and mixed-valence Ni oxides (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O), elemental Ni, and anhydrous NiO as out-of-scope decorative branches for this no-potential aqueous speciation at fixed pH with only Ni(II) and ammonia in scope.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ammo)]2+` | SRD-46 | +2 | -15.582 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ammo)2]2+` | SRD-46 | +2 | -27.911 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ammo)3]2+` | SRD-46 | +2 | -37.328 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:4` | `[Ni(Ammo)4]2+` | SRD-46 | +2 | -43.778 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:5` | `[Ni(Ammo)5]2+` | SRD-46 | +2 | -47.545 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:6` | `[Ni(Ammo)6]2+` | SRD-46 | +2 | -47.374 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Keeping all aqueous species (water, ammonia, ammonium, Ni(OH)2 aq, six ammines). Dropping elemental Ni and higher/mixed-valence Ni oxides per case recommendations (no-potential Ni(II)/NH3 speciation only).</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recording verdicts: keep all 10 aqueous (solvent, ammonia, ammonium, Ni(OH)2 aq, six ammines); drop elemental Ni and the three higher/mixed-valence Ni oxides as out-of-scope decorative redox branches.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting explicit verdicts: keep all 10 aqueous entries (solvent, ammonia, ammonium, Ni(OH)2 aq, six ammines); drop elemental Ni and three higher/mixed-valence Ni oxides as out-of-scope for no-potential Ni(II)/NH3 speciation.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting full decisions payload with all 14 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the complete decisions payload with all 14 singletons, keep/drop verdicts, and rationales.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload with all 14 verdicts explicitly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full decisions payload now with all 14 explicit entries.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting full explicit payload with all 14 decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent water record; required aqueous framework entry."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free NH3(aq); required ligand for Ni–ammonia speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"NH4+; required conjugate acid controlling free-NH3 vs pH."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) hydrolysis monomer; in scope for Ni(II) hydrolysis hull."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"[Ni(NH3)]2+; explicitly requested ammine complex n=1."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"[Ni(NH3)2]2+; explicitly requested ammine complex n=2."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"[Ni(NH3)3]2+; explicitly requested ammine complex n=3."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:4","keep":true,"rationale":"[Ni(NH3)4]2+; explicitly requested ammine complex n=4."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:5","keep":true,"rationale":"[Ni(NH3)5]2+; explicitly requested ammine complex n=5."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:6","keep":true,"rationale":"[Ni(NH3)6]2+; explicitly requested ammine complex n=6."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) is a redox branch out of scope for no-potential Ni(II)/NH3 aqueous speciation."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni(II,III) oxide hydrate; decorative higher-valence branch excluded under no-potential Ni(II)-only scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide hydrate; higher-valence branch excluded under no-potential Ni(II)-only scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide hydrate; higher-valence branch excluded under no-potential Ni(II)-only scope."}
]}
</answer>
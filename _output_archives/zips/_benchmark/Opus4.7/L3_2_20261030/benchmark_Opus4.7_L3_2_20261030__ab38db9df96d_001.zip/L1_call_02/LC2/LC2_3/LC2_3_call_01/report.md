# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    272.71
- elapsed_s (total):  272.71
- llm_iterations:     29
- llm_tool_calls:     24

- n_groups:           18
- n_multi_groups:     4
- n_singletons:       14
- n_decisions:        18
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` [SRD-46] | Collapse notational duplicate of aqueous Ni2+ to the SRD-46 record for consistency with SRD-46 ammine/hydrolysis thermochemistry. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` [SRD-46], `[Ni4(OH)4]4+` [SRD-46] | Monomer and tetramer are distinct nuclearity species; both compete on the hydrolysis hull at 1 mM Ni per case recommendations. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` [SRD-46] | Collapse notational duplicate to SRD-46 record per element instructions. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` [SRD-46] | Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference required for aqueous speciation. |
| aqueous | `L1:1` | yes | Free ammonia ligand is the central reactant. |
| aqueous | `L1:1 H:1` | yes | Ammonium is the conjugate acid controlling free NH3 across the pH grid. |
| aqueous | `Ni$+2:1 H:-2` | yes | Neutral Ni(OH)2(aq) hydrolysis species in scope. |
| aqueous | `Ni$+2:1 L1:1` | yes | Mono-ammine Ni(II) complex explicitly requested. |
| aqueous | `Ni$+2:1 L1:2` | yes | Bis-ammine Ni(II) complex explicitly requested. |
| aqueous | `Ni$+2:1 L1:3` | yes | Tris-ammine Ni(II) complex explicitly requested. |
| aqueous | `Ni$+2:1 L1:4` | yes | Tetra-ammine Ni(II) complex explicitly requested. |
| aqueous | `Ni$+2:1 L1:5` | yes | Penta-ammine Ni(II) complex explicitly requested. |
| aqueous | `Ni$+2:1 L1:6` | yes | Hexa-ammine Ni(II) complex explicitly requested. |
| solid | `Ni$+0:1` | NO | Elemental Ni(0) is a redox branch out of scope at no applied potential. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | NO | Mixed-valence Ni(II,III) oxide decorative branch excluded per case recommendations. |
| solid | `Ni$+3:1 H:-3` | NO | Ni(III) oxide decorative branch excluded; no oxidant in scope. |
| solid | `Ni$+4:1 H:-4` | NO | Ni(IV) oxide decorative branch excluded; no oxidant in scope. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | LC2 element review: Collapse notational duplicate of aqueous Ni2+ to the SRD-46 record for consistency with SRD-46 ammine/hydrolysis thermochemistry. |
| `[HNiO2]-` | Atlas | aqueous | LC2 element review: Collapse notational duplicate to SRD-46 record per element instructions. |
| `Ni(OH)2` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |
| `NiO` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |
| `Ni3O4.2H2O` | Atlas | dissolution | LC2 element review: Mixed-valence Ni(II,III) oxide decorative branch excluded per case recommendations. |
| `Ni2O3.H2O` | Atlas | dissolution | LC2 element review: Ni(III) oxide decorative branch excluded; no oxidant in scope. |
| `NiO2.2H2O` | Atlas | dissolution | LC2 element review: Ni(IV) oxide decorative branch excluded; no oxidant in scope. |
| `Ni` | Atlas | dissolution | LC2 element review: Elemental Ni(0) is a redox branch out of scope at no applied potential. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 52cffad8030f49609001a02bde89a433
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Ni(II)/NH3 speciation set finalized: SRD-46 chosen as single thermochemical source for Ni2+, Ni(OH)+, Ni4(OH)4^4+, Ni(OH)2(aq), Ni(OH)3- and all six ammines [Ni(NH3)n]2+ (n=1-6); Atlas notational duplicates (Ni2+, HNiO2-, Ni(OH)2) dropped. Ni(OH)2(s) retained as the precipitation ceiling; anhydrous NiO, higher-valent/mixed-valence oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) and elemental Ni dropped as out-of-scope redox branches for this no-potential aqueous speciation. Both monomer and tetramer hydrolysis species retained because 1 mM Ni makes them genuine competitors.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (7/7)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_2_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

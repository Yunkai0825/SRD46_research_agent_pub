{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent water record; required aqueous framework entry."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free NH3(aq); required ligand for Ni–ammonia speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"NH4+; required conjugate acid controlling free-NH3 vs pH."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) hydrolysis monomer; in scope for Ni(II) hydrolysis hull."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"[Ni(NH3)]2+; explicitly requested ammine complex n=1."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"[Ni(NH3)2]2+; explicitly requested ammine complex n=2."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"[Ni(NH3)3]2+; explicitly requested ammine complex n=3."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:4","keep":true,"rationale":"[Ni(NH3)4]2+; explicitly requested ammine complex n=4."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:5","keep":true,"rationale":"[Ni(NH3)5]2+; explicitly requested ammine complex n=5."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:6","keep":true,"rationale":"[Ni(NH3)6]2+; explicitly requested ammine complex n=6."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) is a redox branch out of scope for no-potential Ni(II)/NH3 aqueous speciation."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni(II,III) oxide hydrate; decorative higher-valence branch excluded under no-potential Ni(II)-only scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide hydrate; higher-valence branch excluded under no-potential Ni(II)-only scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide hydrate; higher-valence branch excluded under no-potential Ni(II)-only scope."}
]}
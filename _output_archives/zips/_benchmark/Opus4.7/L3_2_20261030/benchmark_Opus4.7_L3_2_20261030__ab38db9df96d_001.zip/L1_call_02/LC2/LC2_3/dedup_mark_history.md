# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Collapse notational duplicate of aqueous Ni2+ to the SRD-46 record for consistency with SRD-46 ammine/hydrolysis thermochemistry. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Collapse notational duplicate of aqueous Ni2+ to the SRD-46 record for consistency with SRD-46 ammine/hydrolysis thermochemistry. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Monomer and tetramer are distinct nuclearity species; both compete on the hydrolysis hull at 1 mM Ni per case recommendations. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Monomer and tetramer are distinct nuclearity species; both compete on the hydrolysis hull at 1 mM Ni per case recommendations. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Neutral Ni(OH)2(aq) hydrolysis species in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Collapse notational duplicate to SRD-46 record per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Collapse notational duplicate to SRD-46 record per element instructions. |
| `DEDUP-00cdfe479b2f4203` | `[Ni(Ammo)]2+` | SRD-46 | generation 1: kept — Mono-ammine Ni(II) complex explicitly requested. |
| `DEDUP-b0c807d910b743cd` | `[Ni(Ammo)2]2+` | SRD-46 | generation 1: kept — Bis-ammine Ni(II) complex explicitly requested. |
| `DEDUP-61e5cbd32f6c7241` | `[Ni(Ammo)3]2+` | SRD-46 | generation 1: kept — Tris-ammine Ni(II) complex explicitly requested. |
| `DEDUP-bb76c136e747e9e9` | `[Ni(Ammo)4]2+` | SRD-46 | generation 1: kept — Tetra-ammine Ni(II) complex explicitly requested. |
| `DEDUP-e02d377e788b65b1` | `[Ni(Ammo)5]2+` | SRD-46 | generation 1: kept — Penta-ammine Ni(II) complex explicitly requested. |
| `DEDUP-302455eb802e8601` | `[Ni(Ammo)6]2+` | SRD-46 | generation 1: kept — Hexa-ammine Ni(II) complex explicitly requested. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(0) is a redox branch out of scope at no applied potential. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Ni(OH)2(s) as the aqueous precipitation ceiling, consistent with SRD-46 ammine/hydrolysis set; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (less stable hydrated form governs). |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II,III) oxide decorative branch excluded per case recommendations. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide decorative branch excluded; no oxidant in scope. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide decorative branch excluded; no oxidant in scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference required for aqueous speciation. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia ligand is the central reactant. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is the conjugate acid controlling free NH3 across the pH grid. |

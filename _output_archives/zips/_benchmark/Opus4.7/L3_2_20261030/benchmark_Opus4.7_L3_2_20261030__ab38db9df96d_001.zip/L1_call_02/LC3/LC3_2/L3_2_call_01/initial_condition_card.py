inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M from task"},
  {"id": "NiII", "lhs": lambda s: s.total["Ni$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Ni(II) from task"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"], "value": 0.0,  "basis": "assumed", "note": "no Ni(0) present"},
  {"id": "NiIII","lhs": lambda s: s.total["Ni$+3"], "value": 0.0,  "basis": "assumed", "note": "no Ni(III) present"},
  {"id": "NiIV", "lhs": lambda s: s.total["Ni$+4"], "value": 0.0,  "basis": "assumed", "note": "no Ni(IV) present"},
  {"id": "L1",   "lhs": lambda s: s.total["ligand_10103"], "value": 2e-2, "basis": "known", "note": "20 mM total ammonia from task"},
]
## Doability
Doable — SRD-46 supplies Ni(II)–ethylenediamine (en) stepwise formation constants and Ni(II) hydrolysis constants; a 1-D pH speciation sweep at fixed totals, T, and I is exactly the pH_sweep method.

## Result
System: 1.00 mM Ni(II) + 10.0 mM ethylenediamine (en) at 25 °C, I = 0.1 M (fixed), redox excluded (only Ni(+2) is populated). Method: pH_sweep, 51 points over pH 2–12, 51/51 converged. The free-energy card includes Ni²⁺ hydrolysis (NiOH⁺, Ni(OH)₂(aq), Ni(OH)₃⁻, Ni₄(OH)₄⁴⁺, Ni(OH)₂(s)), the three en complexes [Ni(en)]²⁺, [Ni(en)₂]²⁺, [Ni(en)₃]²⁺ (log β₁ = 7.30, log β₂ = 13.44, log β₃ = 17.51), and en protonation (log β for HL⁺ = 9.92, H₂L²⁺ = 17.03, i.e. pKa₂ ≈ 9.92, pKa₁ ≈ 7.11).

## Analysis
**Answer at pH 7 (the condition asked for).** From the full concentrations table:
- Free [Ni²⁺] = **2.87 × 10⁻⁶ M** (≈ 0.29 % of the 1 mM Ni(II) total).
- [Ni(en)₂]²⁺ = 7.87 × 10⁻⁴ M (~79 %) — the dominant Ni species.
- [Ni(en)]²⁺ = 1.81 × 10⁻⁴ M (~18 %).
- [Ni(en)₃]²⁺ = 2.92 × 10⁻⁵ M (~2.9 %).
- Hydrolysed forms (NiOH⁺, Ni(OH)₂(aq), Ni₄(OH)₄⁴⁺) are ≤ 10⁻¹¹ M, and Ni(OH)₂(s) is not saturated.
So the chelate effect sequesters Ni(II) by roughly a factor of ~350: starting from 10⁻³ M free Ni²⁺ in the absence of ligand, 10 mM en at pH 7 pulls [Ni²⁺] down to ~3 µM even though at this pH the ligand is overwhelmingly in its protonated forms (H₂en²⁺ 55 % and Hen⁺ 26 %; free en only 3.2 × 10⁻⁶ M of the 10 mM total). The fact that a trace of free en (ppm level) still complexes ~99.7 % of the Ni(II) is the quantitative signature of chelation: β₂ = 10¹³·⁴⁴ for bis-en vastly exceeds what two monodentate amines would give.

**Why the speciation shifts the way it does with pH.** The dominance ladder for Ni(II) is Ni²⁺ (pH 2.0–6.0) → [Ni(en)]²⁺ (6.0–6.8) → [Ni(en)₂]²⁺ (6.8–8.2) → [Ni(en)₃]²⁺ (8.2–12.0), with crossovers at pH ≈ 5.99 (Ni²⁺↔mono, ~48% each), 6.63 (mono↔bis, ~48% each) and 8.06 (bis↔tris, ~50% each). These crossovers track en's protonation: as long as en is locked as H₂en²⁺ (dominant below pH 7.4), [en] is too low to compete with Ni²⁺ aquation, and free Ni²⁺ dominates. Between pH 6 and 8 the first pKa (≈7.1) releases Hen⁺ and some free en, enabling mono- then bis-complexation; above pH 10 the second deprotonation (pKa ≈ 9.92) frees enough neutral en that the tris complex (which needs three neutral bidentate ligands) finally takes over. Hydrolysis of Ni(II) — which would otherwise set in near pH 8–9 via NiOH⁺ and Ni(OH)₂(s) — is entirely suppressed here because en removes Ni²⁺ from solution before OH⁻ can.

**Practical significance.** 10 mM en at pH 7 is more than sufficient to hold 1 mM Ni(II) in solution as soluble, cationic chelates and to drop free [Ni²⁺] to the low-µM range, exactly the regime where chelation is used analytically and in biological buffering. The free [Ni²⁺] can be lowered further either by raising pH (to deprotonate more en and reach the β₃ regime, giving ~10⁻¹¹ M free Ni²⁺ by pH 12 per the CSV) or by raising [en]_total. All numbers above are at I = 0.1 M fixed and 25 °C; the solver converged at every pH grid point.

## Artifacts
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_L1.png, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_log_conc.png, L1_call_01/thermodynamic_reference_constants.md
## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: aqueous Ni(II)-ethylenediamine speciation at fixed pH 7, 25 C, 1 mM Ni(II) + 10 mM en, I=0.1 M. No redox control is specified, so the problem is solution speciation (not a Pourbaix hull); treat divalent Ni as the only accessible oxidation state.
- Concentration regime: 1 mM Ni(II) with ~10 mM en means free [Ni2+] will be tiny (strong chelation), but complexed Ni dominates at 1 mM total — the 1e-6 M corrosion convention does not apply. Hydroxo monomer [Ni(OH)]+ and the polynuclear [Ni4(OH)4]4+ are both chemically real at mM Ni near neutral pH and can genuinely compete, so keep both.
- Notation duplicates: 'Ni2+' and '[Ni]2+' are the same aquo cation; '[HNiO2]-' and '[Ni(OH)3]-' are the same trihydroxo anion written two ways. Collapse each pair to one entry (prefer the explicit hydroxo spelling from SRD-46 where available for ligand bookkeeping).
- Hydrated vs anhydrous solids: at 25 C in aqueous solution the thermodynamic Ni(II) solid is β-Ni(OH)2; anhydrous NiO is not the stable precipitate under these conditions. Keep one Ni(OH)2(s) entry for saturation checking and drop anhydrous NiO; the two Ni(OH)2(s) entries (Atlas vs SRD-46) are the same phase — keep the lower-μ one as the ground state.
- Higher-valence Ni oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O) and elemental Ni(s) require imposed potential outside the water window; with no E specified and only Ni(II) chemistry requested, they are out of scope — drop them.
- Carbonate / other counterion solids: none in inventory and none implied by the problem; no gap to flag.
- Ethylenediamine ladder: the whole point of the calculation is to resolve the chelate effect, so all three stepwise complexes [Ni(en)]2+, [Ni(en)2]2+, [Ni(en)3]2+ are distinct and must all be kept — they populate different en:Ni ratios and dominate at different free-en activities.
- Phase question: this is a 'which species forms / what is the distribution' calculation at fixed pH, not a ground-state polymorph collapse — retain every chemically distinct aqueous species.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop the duplicate aquo cation (keep one of Ni2+ / [Ni]2+), drop the duplicate trihydroxo anion (keep one of [HNiO2]- / [Ni(OH)3]-), and collapse the two Ni(OH)2(s) entries to the lower-μ one since they are the same hydrated solid. Drop anhydrous NiO, elemental Ni(s), and all higher-valence Ni(III)/Ni(IV) oxide solids as out of scope for this fixed-pH Ni(II)-en speciation problem with no imposed potential; keep [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and all three ethylenediamine complexes as chemically distinct competitors.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Ethylenediamine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEthylenediamine]+` | SRD-46 | +1 | -56.620 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Ethylenediamine]2+` | SRD-46 | +2 | -97.202 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ethy)]2+` | SRD-46 | +2 | -41.666 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ethy)2]2+` | SRD-46 | +2 | -76.711 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ethy)3]2+` | SRD-46 | +2 | -99.942 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Keeping all en ligand aqueous species, Ni(OH)2(aq), and three Ni-en complexes. Dropping elemental Ni and all higher-valence Ni oxide solids as out of scope per element instructions (no imposed potential, Ni(II) speciation only).</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Recording the 12 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the 12 singleton verdicts: keep all aqueous species (en ligand forms, Ni(OH)2(aq), three Ni-en complexes); drop Ni(s) and three higher-valence Ni oxide solids as out of scope.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the finalized decisions with full JSON payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete JSON payload for all 12 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete JSON payload with all 12 singleton verdicts explicitly listed.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload now with full argument content.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Need to submit full JSON payload with all 12 decisions explicitly in the arguments field.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Unlabeled aqueous entry (likely H2O/charge balance) retained as default; no scope exclusion."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free ethylenediamine ligand — required for en speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Monoprotonated en — required for pH-dependent free-ligand activity."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Diprotonated en — required for pH-dependent free-ligand activity."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Neutral Ni(OH)2(aq) is a chemically distinct Ni(II) hydrolysis species; keep per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Mono-en Ni(II) complex — distinct stepwise chelate; required to resolve en ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Bis-en Ni(II) complex — distinct stepwise chelate; required to resolve en ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Tris-en Ni(II) complex — distinct stepwise chelate; dominant at high free-en activity."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) requires imposed reducing potential; out of scope for fixed-pH Ni(II)-en speciation."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II)/Ni(III) oxide requires oxidizing potential outside water window; out of scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) hydrous oxide requires imposed oxidizing potential; out of scope for Ni(II)-only speciation."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) hydrous oxide requires strong imposed oxidizing potential; out of scope."}
]}
</answer>
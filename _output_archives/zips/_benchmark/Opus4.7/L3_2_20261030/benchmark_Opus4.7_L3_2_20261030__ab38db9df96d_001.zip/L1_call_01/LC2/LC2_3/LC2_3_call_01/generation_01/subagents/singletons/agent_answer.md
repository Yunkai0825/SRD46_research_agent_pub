{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Unlabeled aqueous entry (likely H2O/charge balance) retained as default; no scope exclusion."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free ethylenediamine ligand — required for en speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Monoprotonated en — required for pH-dependent free-ligand activity."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Diprotonated en — required for pH-dependent free-ligand activity."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Neutral Ni(OH)2(aq) is a chemically distinct Ni(II) hydrolysis species; keep per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Mono-en Ni(II) complex — distinct stepwise chelate; required to resolve en ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Bis-en Ni(II) complex — distinct stepwise chelate; required to resolve en ladder."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Tris-en Ni(II) complex — distinct stepwise chelate; dominant at high free-en activity."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) requires imposed reducing potential; out of scope for fixed-pH Ni(II)-en speciation."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II)/Ni(III) oxide requires oxidizing potential outside water window; out of scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) hydrous oxide requires imposed oxidizing potential; out of scope for Ni(II)-only speciation."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) hydrous oxide requires strong imposed oxidizing potential; out of scope."}
]}
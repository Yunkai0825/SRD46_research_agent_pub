# LC2 element instruction supervisor agent response

## Final answer (text emitted by the agent)

Case-specific recommendations for the Ni/en speciation at pH 7, 25 °C, I = 0.1 M, 1 mM Ni(II) + 10 mM ethylenediamine:

- Scenario: solution speciation at fixed pH and composition, no imposed potential. Treat as an equilibrium distribution problem, not a Pourbaix construction. Redox-active high-valence Ni phases and elemental Ni are decorative here and should be dropped.
- Working concentration: 1 mM Ni(II) with 10 mM en (ligand in ~10× excess). The standard 1e-6 M corrosion convention does not apply; polynuclear hydroxo species such as [Ni4(OH)4]4+ remain thermodynamically defined but are strongly disfavoured against the en chelates at this pH and L/M ratio. Keep them as competing branches rather than pruning them — the chelate effect is quantified precisely by how badly they lose.
- Notation duplicates: Ni2+ (Atlas) and [Ni]2+ (SRD-46) are the same aquo cation; keep the SRD-46 entry because the en-complex ladder it anchors is also SRD-46. Likewise [HNiO2]- (Atlas) and [Ni(OH)3]-  (SRD-46) are the same anionic trihydroxo species; keep the SRD-46 spelling for internal consistency with the rest of the hydroxo ladder.
- Hydrated vs anhydrous solids: aqueous equilibrium at 25 °C with liquid water present — the stable solid is β-Ni(OH)2. Keep one Ni(OH)2(s) entry (prefer the SRD-46 [Ni(OH)2](s), consistent with the aqueous dataset) solely as a saturation check against the 1 mM total; drop anhydrous NiO as a non-competing polymorph under these conditions.
- Mixed-valence / high-valence oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O): require oxidising potentials that are not part of this scenario. Drop as out of scope.
- Elemental Ni(s): requires reducing potentials not imposed here. Drop as out of scope.
- en complex ladder: the entire purpose of the calculation is to resolve the chelate ladder, so keep [Ni(en)]2+, [Ni(en)2]2+, and [Ni(en)3]2+ as distinct competing species — they are not duplicates in any sense.
- Phase question: this is a "which species forms and at what fraction" calculation, not a "collapse to ground-state polymorph" calculation, so retain every distinct aqueous branch (monomeric hydroxo ladder, tetrameric hydroxo cluster, en ladder) even when their μ spread looks small.
- Ambiguity flagged, not silently resolved: no mixed hydroxo–en ternary complexes (e.g. [Ni(en)(OH)]+, [Ni(en)2(OH)]+) appear in the inventory. At pH 7 with excess en these are usually minor, but their absence should be noted to the downstream solver rather than patched here.

Element instruction — Ni: Keep SRD-46 [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]-, and all three en complexes [Ni(en)]2+/[Ni(en)2]2+/[Ni(en)3]2+ as the aqueous set, plus SRD-46 [Ni(OH)2](s) as the sole solid saturation reference; drop the Atlas duplicates Ni2+ and [HNiO2]- as notational twins of the SRD-46 entries. Drop anhydrous NiO, elemental Ni, and the high-valence oxides Ni3O4·2H2O, Ni2O3·H2O, and NiO2·2H2O as out of scope for a fixed-pH, no-imposed-potential solution speciation at 25 °C.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## User
[Orchestration session]
647b5c9cde65448f8dfd95d56c47cba9

[Calculation purpose]
Test the chelate effect by computing Ni(II) speciation with ethylenediamine as the chelating ligand.

[Requested tasks]
Model a solution of 1 mM Ni(II) with 10 mM ethylenediamine at pH 7, 25 C, and 0.1 M ionic strength. Report the Ni(II) speciation distribution and especially the free [Ni2+] concentration remaining in equilibrium with the ethylenediamine complexes.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-b43a0c3bca3bba74` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ethy)]2+` | SRD-46 | -41.666 |
| `DEDUP-02ca11846fef3b9f` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ethy)2]2+` | SRD-46 | -76.711 |
| `DEDUP-6e984128b842b481` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ethy)3]2+` | SRD-46 | -99.942 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |


## Assistant
<summary>Speciation at fixed pH 7 with 1 mM Ni(II) and 10 mM en — no redox control, so high-valence Ni oxides and elemental Ni are out of scope. Keep one Ni(OH)2(s) for saturation check, drop anhydrous NiO. Resolve notation duplicates (Ni2+ vs [Ni]2+; [HNiO2]- vs [Ni(OH)3]-; Ni(OH)2 hydrated solid pair). Keep monomer and tetramer hydroxo complexes as distinct, and keep all three en complexes (1:1, 1:2, 1:3) since the whole purpose is to resolve the chelate ladder.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: Ni instruction must contain one or two sentences.
</tool_result>

## Assistant
<summary>Retry with full JSON payload for commit.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Previous commit was accepted but with truncated payload. I need to resend properly with the full case recommendations and complete Ni instruction.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Sending the full properly-formatted payload with case recommendations and Ni instruction.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Committing full instruction set for the Ni/en speciation calculation.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: Ni instruction must contain one or two sentences.
</tool_result>

## Assistant
<summary>Submitting the complete payload with full case recommendations and a concrete two-sentence Ni instruction.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>The tool calls appear to be getting truncated by the formatting. Let me send the actual full payload text properly.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Previous attempts appear truncated. Sending the full JSON payload now with complete case recommendations and a two-sentence Ni instruction.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
Case-specific recommendations for the Ni/en speciation at pH 7, 25 °C, I = 0.1 M, 1 mM Ni(II) + 10 mM ethylenediamine:

- Scenario: solution speciation at fixed pH and composition, no imposed potential. Treat as an equilibrium distribution problem, not a Pourbaix construction. Redox-active high-valence Ni phases and elemental Ni are decorative here and should be dropped.
- Working concentration: 1 mM Ni(II) with 10 mM en (ligand in ~10× excess). The standard 1e-6 M corrosion convention does not apply; polynuclear hydroxo species such as [Ni4(OH)4]4+ remain thermodynamically defined but are strongly disfavoured against the en chelates at this pH and L/M ratio. Keep them as competing branches rather than pruning them — the chelate effect is quantified precisely by how badly they lose.
- Notation duplicates: Ni2+ (Atlas) and [Ni]2+ (SRD-46) are the same aquo cation; keep the SRD-46 entry because the en-complex ladder it anchors is also SRD-46. Likewise [HNiO2]- (Atlas) and [Ni(OH)3]-  (SRD-46) are the same anionic trihydroxo species; keep the SRD-46 spelling for internal consistency with the rest of the hydroxo ladder.
- Hydrated vs anhydrous solids: aqueous equilibrium at 25 °C with liquid water present — the stable solid is β-Ni(OH)2. Keep one Ni(OH)2(s) entry (prefer the SRD-46 [Ni(OH)2](s), consistent with the aqueous dataset) solely as a saturation check against the 1 mM total; drop anhydrous NiO as a non-competing polymorph under these conditions.
- Mixed-valence / high-valence oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O): require oxidising potentials that are not part of this scenario. Drop as out of scope.
- Elemental Ni(s): requires reducing potentials not imposed here. Drop as out of scope.
- en complex ladder: the entire purpose of the calculation is to resolve the chelate ladder, so keep [Ni(en)]2+, [Ni(en)2]2+, and [Ni(en)3]2+ as distinct competing species — they are not duplicates in any sense.
- Phase question: this is a "which species forms and at what fraction" calculation, not a "collapse to ground-state polymorph" calculation, so retain every distinct aqueous branch (monomeric hydroxo ladder, tetrameric hydroxo cluster, en ladder) even when their μ spread looks small.
- Ambiguity flagged, not silently resolved: no mixed hydroxo–en ternary complexes (e.g. [Ni(en)(OH)]+, [Ni(en)2(OH)]+) appear in the inventory. At pH 7 with excess en these are usually minor, but their absence should be noted to the downstream solver rather than patched here.

Element instruction — Ni: Keep SRD-46 [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]-, and all three en complexes [Ni(en)]2+/[Ni(en)2]2+/[Ni(en)3]2+ as the aqueous set, plus SRD-46 [Ni(OH)2](s) as the sole solid saturation reference; drop the Atlas duplicates Ni2+ and [HNiO2]- as notational twins of the SRD-46 entries. Drop anhydrous NiO, elemental Ni, and the high-valence oxides Ni3O4·2H2O, Ni2O3·H2O, and NiO2·2H2O as out of scope for a fixed-pH, no-imposed-potential solution speciation at 25 °C.
</answer>

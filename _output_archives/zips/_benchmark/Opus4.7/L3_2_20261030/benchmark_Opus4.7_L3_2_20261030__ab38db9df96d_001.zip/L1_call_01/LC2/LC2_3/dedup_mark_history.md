# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Ni2+ and [Ni]2+ are the same aquo cation; keep SRD-46 explicit entry per element guidance. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Ni2+ and [Ni]2+ are the same aquo cation; keep SRD-46 explicit entry per element guidance. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear [Ni(OH)]+ and polynuclear [Ni4(OH)4]4+ are chemically distinct hydroxo species that compete at mM Ni near neutral pH; both retained. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear [Ni(OH)]+ and polynuclear [Ni4(OH)4]4+ are chemically distinct hydroxo species that compete at mM Ni near neutral pH; both retained. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq) neutral hydroxo complex, chemically distinct Ni(II) species. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Same trihydroxo Ni(II) anion written two ways; keep SRD-46 explicit hydroxo spelling per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Same trihydroxo Ni(II) anion written two ways; keep SRD-46 explicit hydroxo spelling per element instructions. |
| `DEDUP-b43a0c3bca3bba74` | `[Ni(Ethy)]2+` | SRD-46 | generation 1: kept — Mono-en Ni(II) complex, distinct en:Ni ratio. |
| `DEDUP-02ca11846fef3b9f` | `[Ni(Ethy)2]2+` | SRD-46 | generation 1: kept — Bis-en Ni(II) complex, distinct en:Ni ratio. |
| `DEDUP-6e984128b842b481` | `[Ni(Ethy)3]2+` | SRD-46 | generation 1: kept — Tris-en Ni(II) complex, dominant at high free en. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(0) requires imposed potential outside water window; out of scope for Ni(II) speciation. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Collapse the two Ni(OH)2(s) entries to the lower-mu Atlas copy; drop anhydrous NiO as out of scope for Ni(II) aqueous speciation. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Collapse the two Ni(OH)2(s) entries to the lower-mu Atlas copy; drop anhydrous NiO as out of scope for Ni(II) aqueous speciation. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Collapse the two Ni(OH)2(s) entries to the lower-mu Atlas copy; drop anhydrous NiO as out of scope for Ni(II) aqueous speciation. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II/III) oxide out of scope with no imposed potential. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide out of scope for Ni(II)-only speciation problem. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope for Ni(II)-only speciation problem. |
| — | `[?]` | SRD-46 | generation 1: kept — Unique aqueous species, no duplicate. |
| — | `[Ethylenediamine]` | SRD-46 | generation 1: kept — Free ethylenediamine ligand, essential for en speciation. |
| — | `[H2Ethylenediamine]2+` | SRD-46 | generation 1: kept — Diprotonated en, needed for ligand protonation ladder. |
| — | `[HEthylenediamine]+` | SRD-46 | generation 1: kept — Monoprotonated en, needed for ligand protonation ladder at pH 7. |

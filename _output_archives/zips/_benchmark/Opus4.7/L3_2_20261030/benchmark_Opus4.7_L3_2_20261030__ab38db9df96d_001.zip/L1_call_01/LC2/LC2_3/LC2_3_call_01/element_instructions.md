# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: aqueous Ni(II)-ethylenediamine speciation at fixed pH 7, 25 C, 1 mM Ni(II) + 10 mM en, I=0.1 M. No redox control is specified, so the problem is solution speciation (not a Pourbaix hull); treat divalent Ni as the only accessible oxidation state.
- Concentration regime: 1 mM Ni(II) with ~10 mM en means free [Ni2+] will be tiny (strong chelation), but complexed Ni dominates at 1 mM total — the 1e-6 M corrosion convention does not apply. Hydroxo monomer [Ni(OH)]+ and the polynuclear [Ni4(OH)4]4+ are both chemically real at mM Ni near neutral pH and can genuinely compete, so keep both.
- Notation duplicates: 'Ni2+' and '[Ni]2+' are the same aquo cation; '[HNiO2]-' and '[Ni(OH)3]-' are the same trihydroxo anion written two ways. Collapse each pair to one entry (prefer the explicit hydroxo spelling from SRD-46 where available for ligand bookkeeping).
- Hydrated vs anhydrous solids: at 25 C in aqueous solution the thermodynamic Ni(II) solid is β-Ni(OH)2; anhydrous NiO is not the stable precipitate under these conditions. Keep one Ni(OH)2(s) entry for saturation checking and drop anhydrous NiO; the two Ni(OH)2(s) entries (Atlas vs SRD-46) are the same phase — keep the lower-μ one as the ground state.
- Higher-valence Ni oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O) and elemental Ni(s) require imposed potential outside the water window; with no E specified and only Ni(II) chemistry requested, they are out of scope — drop them.
- Carbonate / other counterion solids: none in inventory and none implied by the problem; no gap to flag.
- Ethylenediamine ladder: the whole point of the calculation is to resolve the chelate effect, so all three stepwise complexes [Ni(en)]2+, [Ni(en)2]2+, [Ni(en)3]2+ are distinct and must all be kept — they populate different en:Ni ratios and dominate at different free-en activities.
- Phase question: this is a 'which species forms / what is the distribution' calculation at fixed pH, not a ground-state polymorph collapse — retain every chemically distinct aqueous species.

## Element instructions

- **Ni**: Drop the duplicate aquo cation (keep one of Ni2+ / [Ni]2+), drop the duplicate trihydroxo anion (keep one of [HNiO2]- / [Ni(OH)3]-), and collapse the two Ni(OH)2(s) entries to the lower-μ one since they are the same hydrated solid. Drop anhydrous NiO, elemental Ni(s), and all higher-valence Ni(III)/Ni(IV) oxide solids as out of scope for this fixed-pH Ni(II)-en speciation problem with no imposed potential; keep [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and all three ethylenediamine complexes as chemically distinct competitors.

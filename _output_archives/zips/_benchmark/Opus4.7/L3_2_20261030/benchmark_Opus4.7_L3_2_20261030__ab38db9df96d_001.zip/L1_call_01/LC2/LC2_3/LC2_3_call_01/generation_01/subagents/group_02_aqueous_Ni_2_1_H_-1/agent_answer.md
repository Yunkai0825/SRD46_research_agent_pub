Kept both species in this group:
- [Ni(OH)]+ (SRD-46)
- [Ni4(OH)4]4+ (SRD-46)

Rationale: different nuclearity and charge; both are chemically real Ni(II) hydroxo competitors at the 1 mM Ni regime per case guidance.
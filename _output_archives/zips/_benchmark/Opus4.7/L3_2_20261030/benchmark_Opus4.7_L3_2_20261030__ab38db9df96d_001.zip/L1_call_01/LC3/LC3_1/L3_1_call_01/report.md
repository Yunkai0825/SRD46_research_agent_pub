# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_2_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.30
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation of Ni(II)-ethylenediamine; single pH axis (focused at pH 7) suffices to report distribution and free [Ni2+].

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_2_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
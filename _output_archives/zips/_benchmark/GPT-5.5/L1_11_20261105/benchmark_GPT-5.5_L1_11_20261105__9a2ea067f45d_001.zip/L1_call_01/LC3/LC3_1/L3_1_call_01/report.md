# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_11_20261105\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.52
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Joint two-dimensional E-pH Pourbaix diagram uses pH and potential as the two independent axes.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_11_20261105\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
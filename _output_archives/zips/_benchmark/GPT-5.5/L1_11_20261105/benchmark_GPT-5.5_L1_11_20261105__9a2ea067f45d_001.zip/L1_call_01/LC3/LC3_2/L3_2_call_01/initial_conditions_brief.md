# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1 molal; pinned on catalog mol/L ionic-strength handle.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Cu introduced as Cu(II); Pourbaix redox axis uses element total.
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Fe introduced as Fe(III); Pourbaix redox axis uses element total.
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM citrate.
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM glycine.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M ammonia.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M chloride.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Independent Pourbaix pH coordinate, pH 0 to 14, to be closed by L3_3.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Independent Pourbaix potential coordinate versus SHE, -1.0 to +1.5 V, to be closed by L3_3.'},
]

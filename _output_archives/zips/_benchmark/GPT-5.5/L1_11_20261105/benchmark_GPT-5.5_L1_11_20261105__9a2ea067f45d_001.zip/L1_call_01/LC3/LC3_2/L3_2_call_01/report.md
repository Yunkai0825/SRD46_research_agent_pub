# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_11_20261105\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 24.17
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1 molal; pinned on catalog mol/L ionic-strength handle.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Cu introduced as Cu(II); Pourbaix redox axis uses element total.
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Fe introduced as Fe(III); Pourbaix redox axis uses element total.
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM citrate.
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM glycine.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M ammonia.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M chloride.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Independent Pourbaix pH coordinate, pH 0 to 14, to be closed by L3_3.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Independent Pourbaix potential coordinate versus SHE, -1.0 to +1.5 V, to be closed by L3_3.'},
]

```

## Notes
Task fixes 25 C, I=0.1, 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. For the Pourbaix sweep, pH and E_V are not pinned and are deferred to L3_3 as swept axes; Cu and Fe are pinned as element totals so redox partitioning is governed by the E-pH field. Solids are included for precipitation/electrodeposition relevance; the user-requested exclusion of selected oxide phases is an active-system selection requirement for the downstream constraint/system builder, not an L3_2 numeric initial condition.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
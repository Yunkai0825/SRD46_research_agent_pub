inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength 0.1 molal; pinned on catalog mol/L ionic-strength handle."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM Cu introduced as Cu(II); Pourbaix redox axis uses element total."},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM Fe introduced as Fe(III); Pourbaix redox axis uses element total."},
  {"id": "citrate", "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2, "basis": "known", "note": "Task states 10 mM citrate."},
  {"id": "glycine", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "Task states 10 mM glycine."},
  {"id": "ammonia", "lhs": lambda s: s.total["ligand_10103"], "value": 1e-1, "basis": "known", "note": "Task states 0.1 M ammonia."},
  {"id": "chloride", "lhs": lambda s: s.total["ligand_10163"], "value": 1e-1, "basis": "known", "note": "Task states 0.1 M chloride."},
]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as an electrodeposition-relevant joint Cu/Fe Pourbaix speciation problem in one shared electrolyte, not a dilute corrosion atlas calculation; the governing context is 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m.
- Aqueous identity is controlled by the supplied ligand-rich solution and full pH/E window, so different oxidation states, ligand stoichiometries, protonation states, hydrolysis states, and plausible polynuclear complexes are distinct unless they are only alternate spellings of the same mononuclear free ion or same solid.
- Prefer SRD-46 entries over Atlas entries for exact duplicate aqueous free-ion or solid-state representations when both describe the same physical state with the same composition and charge; provenance alone is not a reason to keep both.
- This is a water-rich electrolyte design calculation at 25 C, so hydrated hydroxide solids are preferred over anhydrous oxide alternatives for the same metal/oxidation/hydrolysis chemistry unless the user explicitly requested the oxide; here Fe2O3, CuO, FeOOH, and Fe3O4 are explicitly out of the active system.
- Chloride is a major electrolyte component, so Cu/Fe chloride aqueous complexes and chloride-containing precipitates are in scope; carbonates are absent and any carbonate branch would be out of scope.
- Mixed-valence or high-valence aqueous redox species may be retained if chemically distinct across the E-pH window, but the explicitly banned Fe3O4 mixed-valence solid must be excluded.
- The phase question is stable partitioning on a Pourbaix hull for electrodeposition, so collapse polymorph/notation duplicates to a single preferred representative; do not retain multiple versions of the same stable solid only to describe formation pathway.
- Elemental Cu(s) and Fe(s) must remain as electrodeposition/reference metal phases. Decorative gases are not part of this inventory and should not be introduced.

Singleton review completed: all 62 supplied singleton groups were adjudicated.

Summary:
- Kept all distinct in-scope aqueous Cu/Fe complexes, ligand protonation states, free ligands, chloride species, and elemental Cu(s)/Fe(s).
- Kept chloride-containing Cu solid phases as in-scope chloride chemistry.
- Dropped `Fe$+2:1 Fe$+3:2 H:-8` / `Fe3O4 (anh.)` because Fe3O4 was explicitly excluded from the active system.
- No additional duplicate-based drops were made among singleton groups.
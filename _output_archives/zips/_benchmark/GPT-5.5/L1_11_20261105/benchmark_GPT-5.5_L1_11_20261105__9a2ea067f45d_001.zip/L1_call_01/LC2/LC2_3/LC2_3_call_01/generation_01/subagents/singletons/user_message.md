[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: For Cu, retain distinct Cu(I)/Cu(II) aqueous complexes differing by ligand, charge, hydrolysis/protonation, or nuclearity because the ligand-rich electrolyte can give them different E-pH domains. Collapse exact duplicate free ions and exact duplicate solids to the preferred SRD-46 representative when present; exclude CuO specifically, prefer Cu(OH)2 over CuO for the Cu(II) hydroxide/oxide precipitate branch, keep Cu2O and Cu(s), and keep Cu chloride solid phases as in-scope chloride chemistry.
- Fe: For Fe, retain distinct Fe(II), Fe(III), and Fe(VI) aqueous species, ligand complexes, hydrolysis/protonation states, and polynuclear complexes unless they are merely alternate notation for the same free ion or same complex. Collapse exact duplicates to the preferred SRD-46 representative when present; exclude Fe2O3, FeOOH, and Fe3O4 as requested, prefer Fe(OH)2 and Fe(OH)3 hydrated precipitates for water-rich conditions, and keep Fe(s) as the electrodeposition metal phase.

[Singletons: n=62]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -27.111 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | -2 | 94.036 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | -4 | 140.611 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +0 | 35.545 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p06_m41_l10163/attempt01/patches.json) | +1 | 14.770 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +0 | 75.429 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | -3 | 112.871 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 47.602 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +1 | 31.050 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +0 | 65.581 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | -1 | 113.241 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | +2 | -7.991 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | +2 | -12.842 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | +2 | -15.297 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | +2 | -15.696 |
| Fe | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +2 | 80.057 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +3 | 64.247 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +3 | 53.231 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | SRD-46 | +1 | 62.192 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L3:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L3:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| — | aqueous | aqueous | `L4:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L4:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
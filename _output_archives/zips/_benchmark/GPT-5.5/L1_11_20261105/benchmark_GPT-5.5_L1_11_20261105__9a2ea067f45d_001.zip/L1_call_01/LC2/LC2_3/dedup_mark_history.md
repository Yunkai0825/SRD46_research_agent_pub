# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — The Atlas Cu+ and SRD-46 [Cu]+ rows are the same aqueous mononuclear Cu(I) free ion, so the SRD-46 representative is preferred. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — The Atlas Cu+ and SRD-46 [Cu]+ rows are the same aqueous mononuclear Cu(I) free ion, so the SRD-46 representative is preferred. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Keep this distinct Cu(I) glycine complex because ligand stoichiometry and charge define a separate aqueous species. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Keep this distinct Cu(I) ammonia complex in the ligand-rich electrolyte. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Keep this neutral Cu(I) chloride complex because chloride complexes are in scope. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Kept both because the dinuclear tetrachloro complex and mononuclear dichloro complex differ in nuclearity and charge and chloride complexes are in scope for the electrolyte. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Kept both because the dinuclear tetrachloro complex and mononuclear dichloro complex differ in nuclearity and charge and chloride complexes are in scope for the electrolyte. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Keep this distinct Cu(I) trichloride complex because chloride complexes are in scope. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — The Atlas Cu2+ and SRD-46 [Cu]2+ rows represent the same aqueous Cu(II) free ion, so the exact duplicate is collapsed to the preferred SRD-46 representative. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — The Atlas Cu2+ and SRD-46 [Cu]2+ rows represent the same aqueous Cu(II) free ion, so the exact duplicate is collapsed to the preferred SRD-46 representative. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Retain both because the mononuclear Cu(II) hydroxo complex and the dinuclear hydroxo complex differ in nuclearity/multiplier and can occupy distinct ligand-rich Pourbaix speciation domains. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Retain both because the mononuclear Cu(II) hydroxo complex and the dinuclear hydroxo complex differ in nuclearity/multiplier and can occupy distinct ligand-rich Pourbaix speciation domains. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Keep this aqueous Cu(II) hydrolysis species as distinct across the pH window. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Keep this aqueous Cu(II) hydrolysis species because it is distinct from other protonation states. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Keep this aqueous Cu(II) hydrolysis species because it is distinct in charge and hydrolysis level. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Keep this distinct Cu(II) citrate complex in the ligand-rich electrolyte. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Keep this hydrolyzed Cu(II) citrate complex because protonation and nuclearity are distinct. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Keep this protonated Cu(II) citrate complex as a distinct aqueous species. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Keep this Cu(II) monoglycine complex as distinct ligand stoichiometry. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Keep this Cu(II) bisglycine complex as distinct ligand stoichiometry. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Keep this Cu(II) monoammine complex as distinct ligand stoichiometry. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Keep this Cu(II) diammine complex as distinct ligand stoichiometry. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Keep this Cu(II) triammine complex as distinct ligand stoichiometry. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Keep this Cu(II) tetraammine complex as distinct ligand stoichiometry. |
| `DEDUP-a785fbaf17e48601` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p06_m41_l10163/attempt01/patches.json) | generation 1: kept — Keep this Cu(II) chloride complex because chloride is a major in-scope electrolyte component. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Keep this dinuclear hydrolyzed Cu(II) citrate complex because nuclearity and stoichiometry are distinct. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Keep this dinuclear hydrolyzed Cu(II) dicitrate complex because ligand stoichiometry and charge are distinct. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Keep this polynuclear Cu(II) hydrolysis complex as a distinct aqueous species. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Keep elemental copper as an electrodeposition/reference metal phase. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent the same cuprous oxide solid, so retain the preferred SRD-46 representative for the in-scope Cu2O phase. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent the same cuprous oxide solid, so retain the preferred SRD-46 representative for the in-scope Cu2O phase. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — Keep solid Cu(I) chloride because chloride-containing precipitates are in scope. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the SRD-46 hydrated Cu(II) hydroxide solid, excluding CuO per the case-specific Cu instructions and collapsing the Atlas Cu(OH)2 duplicate to the preferred SRD-46 representative. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the SRD-46 hydrated Cu(II) hydroxide solid, excluding CuO per the case-specific Cu instructions and collapsing the Atlas Cu(OH)2 duplicate to the preferred SRD-46 representative. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 hydrated Cu(II) hydroxide solid, excluding CuO per the case-specific Cu instructions and collapsing the Atlas Cu(OH)2 duplicate to the preferred SRD-46 representative. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Keep the SRD-46 hydrated Cu(II) hydroxide solid, excluding CuO per the case-specific Cu instructions and collapsing the Atlas Cu(OH)2 duplicate to the preferred SRD-46 representative. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Keep this hydrated/basic copper chloride solid because chloride precipitates and hydrated solids are in scope. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ and [Fe]2+ are the same aqueous Fe(II) free ion, so the SRD-46 representation is preferred over the Atlas duplicate. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ and [Fe]2+ are the same aqueous Fe(II) free ion, so the SRD-46 representation is preferred over the Atlas duplicate. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Keep this Fe(II) hydrolysis species as distinct over the pH window. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Keep this Fe(II) hydrolysis species as distinct in hydrolysis level and charge. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Kept the SRD-46 representative because [Fe(OH)3]- and [HFeO2]- are alternate hydrated/dehydrated notations of the same Fe(II) aqueous hydrolysis state, with SRD-46 preferred over Atlas. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Kept the SRD-46 representative because [Fe(OH)3]- and [HFeO2]- are alternate hydrated/dehydrated notations of the same Fe(II) aqueous hydrolysis state, with SRD-46 preferred over Atlas. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Keep this Fe(II) hydrolysis species as distinct in hydrolysis level and charge. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Keep this Fe(II) citrate complex in the ligand-rich electrolyte. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Keep this hydrolyzed polynuclear Fe(II) citrate complex because nuclearity and protonation are distinct. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Keep this protonated Fe(II) citrate complex as a distinct aqueous species. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Keep this more highly protonated Fe(II) citrate complex as distinct in charge and protonation. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Keep this Fe(II) bis-citrate protonated complex as distinct ligand stoichiometry. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Keep this Fe(II) monoglycine complex as distinct ligand stoichiometry. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Keep this Fe(II) bisglycine complex as distinct ligand stoichiometry. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Keep this Fe(II) trisglycine complex as distinct ligand stoichiometry and charge. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Keep this Fe(II) monoammine complex as distinct ligand stoichiometry. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Keep this Fe(II) diammine complex as distinct ligand stoichiometry. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Keep this Fe(II) triammine complex as distinct ligand stoichiometry. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Keep this Fe(II) tetraammine complex as distinct ligand stoichiometry. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Keep this Fe(II) chloride complex because chloride complexes are in scope. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — The Atlas Fe3+ and SRD-46 [Fe]3+ rows represent the same aqueous Fe(III) free ion with identical charge and aligned chemical potential, so the SRD-46 representative is kept. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — The Atlas Fe3+ and SRD-46 [Fe]3+ rows represent the same aqueous Fe(III) free ion with identical charge and aligned chemical potential, so the SRD-46 representative is kept. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — The Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear aqueous Fe(III) hydrolysis species so the SRD-46 representative is kept, while [Fe2(OH)2]4+ is a distinct polynuclear complex and is retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — The Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear aqueous Fe(III) hydrolysis species so the SRD-46 representative is kept, while [Fe2(OH)2]4+ is a distinct polynuclear complex and is retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — The Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear aqueous Fe(III) hydrolysis species so the SRD-46 representative is kept, while [Fe2(OH)2]4+ is a distinct polynuclear complex and is retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — The SRD-46 and Atlas rows represent the same aqueous Fe(III) dihydroxo complex with identical charge and nuclearity, so the SRD-46 representative is kept preferentially. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — The SRD-46 and Atlas rows represent the same aqueous Fe(III) dihydroxo complex with identical charge and nuclearity, so the SRD-46 representative is kept preferentially. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Keep this Fe(III) hydrolysis species as distinct over the pH window. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Keep this Fe(III) citrate complex in the ligand-rich electrolyte. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Kept both SRD-46 citrate hydroxo iron complexes because they differ in nuclearity and charge, making them distinct aqueous species in the ligand-rich Fe speciation problem. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Kept both SRD-46 citrate hydroxo iron complexes because they differ in nuclearity and charge, making them distinct aqueous species in the ligand-rich Fe speciation problem. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Keep this protonated Fe(III) citrate complex as distinct in charge and protonation. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Keep this Fe(III) glycine complex as distinct ligand chemistry. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Keep this protonated Fe(III) glycine complex as distinct in protonation and charge. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Keep this protonated Fe(III) bisglycine complex as distinct ligand stoichiometry and protonation. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Keep this Fe(III) monochloride complex because chloride complexes are in scope. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Keep this Fe(III) dichloride complex because chloride complexes are in scope and ligand stoichiometry differs. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Keep this polynuclear Fe(III) hydrolysis complex as a distinct aqueous species. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Keep ferrate as a chemically distinct high-valence aqueous redox species across the E-pH window. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Keep elemental iron as an electrodeposition/reference metal phase. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Drop Fe3O4 because the case-specific instructions explicitly exclude this mixed-valence anhydrous solid branch. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Both rows represent the same neutral hydrated Fe(OH)2 solid, so the SRD-46 representative is preferred over the Atlas duplicate for this water-rich electrodeposition calculation. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Both rows represent the same neutral hydrated Fe(OH)2 solid, so the SRD-46 representative is preferred over the Atlas duplicate for this water-rich electrodeposition calculation. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep the SRD-46 hydrated Fe(III) hydroxide representative for the water-rich electrodeposition system, while excluding Fe2O3/FeOOH as explicitly out of scope and preferring SRD-46 over the Atlas duplicate. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep the SRD-46 hydrated Fe(III) hydroxide representative for the water-rich electrodeposition system, while excluding Fe2O3/FeOOH as explicitly out of scope and preferring SRD-46 over the Atlas duplicate. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Keep the SRD-46 hydrated Fe(III) hydroxide representative for the water-rich electrodeposition system, while excluding Fe2O3/FeOOH as explicitly out of scope and preferring SRD-46 over the Atlas duplicate. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 hydrated Fe(III) hydroxide representative for the water-rich electrodeposition system, while excluding Fe2O3/FeOOH as explicitly out of scope and preferring SRD-46 over the Atlas duplicate. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Keep the SRD-46 hydrated Fe(III) hydroxide representative for the water-rich electrodeposition system, while excluding Fe2O3/FeOOH as explicitly out of scope and preferring SRD-46 over the Atlas duplicate. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Keep ammonia as a major free ligand component required by the electrolyte composition. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Keep chloride ion because chloride is a major electrolyte component. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Keep citrate as a free ligand component required by the electrolyte composition. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Keep glycine as a free ligand component required by the electrolyte composition. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Keep this citrate protonation state because acid-base speciation is in scope over the pH window. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Keep protonated glycine as a distinct acid-base species over the pH window. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Keep water as the solvent/reference aqueous component for the water-rich electrolyte. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Keep neutral citric acid as a distinct ligand protonation state over the pH window. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Keep ammonium as the conjugate acid of the major ammonia electrolyte component. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Keep this citrate protonation state because acid-base speciation is in scope over the pH window. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Keep this glycine protonation state because acid-base speciation is in scope over the pH window. |

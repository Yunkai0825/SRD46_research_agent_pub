Kept:
- `[Fe(OH)]2+` — SRD-46
- `[Fe2(OH)2]4+` — SRD-46

Rationale: Kept the SRD-46 mononuclear Fe(III) hydrolysis species over the Atlas notation duplicate, and retained the distinct SRD-46 dinuclear hydrolysis complex.
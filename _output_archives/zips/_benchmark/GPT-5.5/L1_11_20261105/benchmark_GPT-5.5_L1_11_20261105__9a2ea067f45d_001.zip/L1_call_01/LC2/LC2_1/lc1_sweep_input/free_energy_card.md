# Free Energy Analysis Card

**System**: H, Cu, Fe / Citric acid, Glycine, Chloride, Ammonia, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Fe]3+, [Fe]2+
**Ligands**: [Citric acid], [Glycine], [Ammonia], [Chloride ion]
**Generated**: 2026-11-06 18:38:03 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| M3 | Metal component: [Fe]3+ |
| M4 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Citric acid] |
| L2 | Ligand component: [Glycine] |
| L3 | Ligand component: [Ammonia] |
| L4 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | Not defined | NIST SRD-46 | metal_42 |
| M3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| M4 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Citric acid] | -3 | Not defined | [[H]3[L1]] | NIST SRD-46 | ligand_9058 | O=C(O)CC(O)(CC(=O)O)C(=O)O |
| L2 | [Glycine] | -1 | Not defined | [[H][L2]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |
| L3 | [Ammonia] | +0 | Not defined | [[L3]] | NIST SRD-46 | ligand_10103 | N |
| L4 | [Chloride ion] | -1 | Not defined | [[L4]] | NIST SRD-46 | ligand_10163 | [Cl-] |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |
| Fe | M4 | [Fe]2+ | +2 | true | 2 |
| Fe | M3 | [Fe]3+ | +3 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | C | [-2, -2, 1, 3, 3, 3] | true |
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| M3 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M4 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Citric acid] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |
| L2 | [Glycine] | ligand_canonical | [[H][L2]] | +0.0000 | R4 | *** | -1 | *** |
| L3 | [Ammonia] | ligand_canonical | [[L3]] | +0.0000 | R4 | *** | +0 | *** |
| L4 | [Chloride ion] | ligand_canonical | [[L4]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Citric acid] | [L1] -> [[H]3[L1]] | 3 | 3 | +12.9000 | +73.6292 | exact |  |
| L2 | [Glycine] | [L2] -> [[H][L2]] | 1 | 1 | +9.5700 | +54.6226 | exact |  |
| L3 | [Ammonia] | [L3] -> [[L3]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |
| L4 | [Chloride ion] | [L4] -> [[L4]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Citric acid] | 25.0 | 0.1 | *** | 3 |
| *** + [Glycine] | 25.0 | 0.1 | *** | 2 |
| *** + [Ammonia] | 25.0 | 0.1 | *** | 1 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [Citric acid] | 25.0 | 0~0.1 | 22160 | 11 |
| [Cu]2+ + [Glycine] | 25.0 | 0.1 | 86 | 2 |
| [Cu]2+ + [Chloride ion] | 25.0 | 0 | 29778 | 2 |
| [Cu]2+ + [Ammonia] | 25.0 | 0~0.1 | 28187 | 4 |
| [Cu]+ + [Glycine] | 25.0 | 0~0.1 | 100 | 2 |
| [Cu]+ + [Chloride ion] | 25.0 | 0~5 | 29807 | 5 |
| [Cu]+ + [Ammonia] | 20.0 | 0.1 | 28201 | 1 |
| [Fe]3+ + [Citric acid] | 20.0~25.0 | 0~0.1 | 22162 | 12 |
| [Fe]3+ + [Glycine] | 25.0 | 0.5~3 | 96 | 3 |
| [Fe]3+ + [Chloride ion] | 25.0 | 0~0.1 | 29792 | 2 |
| [Fe]2+ + [Citric acid] | 25.0~37.0 | 0~0.15 | 22149 | 10 |
| [Fe]2+ + [Glycine] | 25.0 | 0.1~1 | 64 | 3 |
| [Fe]2+ + [Chloride ion] | 25.0 | 0 | 29770 | 1 |
| [Fe]2+ + [Ammonia] | 25.0 | 0 | 28171 | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [H2O] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [Citric acid] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]3[L1]].[z+0] | [H3Citric acid] | +0 | aqueous | +12.9000 | -73.6292 | +0.0000 | +0.0000 | [[H]3[L1]]:+1 | vlm_157439, vlm_157459, vlm_157473 | true | *** |
| [[H]2[L1]].[z-1] | [H2Citric acid]- | -1 | aqueous | +10.0000 | -57.0769 | +16.5523 | +16.5523 | [[H]2[L1]]:+1 | vlm_157439, vlm_157459 | true | *** |
| [[H][L1]].[z-2] | [HCitric acid]2- | -2 | aqueous | +5.6500 | -32.2485 | +41.3808 | +41.3808 | [[H][L1]]:+1 | vlm_157439 | true | *** |
| [L1].[z-3] | [Citric acid] | -3 | aqueous | +0.0000 | -0.0000 | +73.6292 | +73.6292 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Glycine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]2[L2]].[z+1] | [H2Glycine]+ | +1 | aqueous | +11.9000 | -67.9215 | -13.2989 | -13.2989 | [[H]2[L2]]:+1 | vlm_93606, vlm_93627 | true | *** |
| [[H][L2]].[z+0] | [HGlycine] | +0 | aqueous | +9.5700 | -54.6226 | +0.0000 | +0.0000 | [[H][L2]]:+1 | vlm_93606 | true | *** |
| [L2].[z-1] | [Glycine] | -1 | aqueous | +0.0000 | -0.0000 | +54.6226 | +54.6226 | [L2]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H][L3]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L3]]:+1 | vlm_173034 | true | *** |
| [L3].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L3]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L4].[z-1] | [Chloride ion] | -1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L4]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[[H][L1]].[z+0] | [Cu(Citr)H] | +0 | aqueous | +9.2600 | -52.8532 | +20.7760 | +20.7760 | [M1]:+1, [[H][L1]]:+1 | vlm_157439, vlm_157663 | true | *** |
| [M1]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | +0 | aqueous | +4.8600 | -27.7394 | +45.8898 | +45.8898 | [M1]:+2, [[H]-1[L1]]:+1 | vlm_157667 | true | *** |
| [M1]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | -2 | aqueous | +14.5000 | -82.7615 | +64.4969 | +64.4969 | [M1]:+2, [L1]:+2 | vlm_157671 | true | *** |
| [M1]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | -3 | aqueous | +11.2000 | -63.9261 | +83.3323 | +83.3323 | [M1]:+2, [[H]-1[L1]]:+1, [L1]:+1 | vlm_157671, vlm_157675 | true | *** |
| [M1]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | -4 | aqueous | +6.3400 | -36.1868 | +111.0717 | +111.0717 | [M1]:+2, [[H]-1[L1]]:+2 | vlm_157671, vlm_157675, vlm_157678 | true | *** |

#### [Cu]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L2].[z+1] | [Cu(Glyc)]+ | +1 | aqueous | +8.1900 | -46.7460 | +7.8766 | +7.8766 | [M1]:+1, [L2]:+1 | vlm_93847 | true | *** |
| [M1].[L2]2.[z+0] | [Cu(Glyc)2] | +0 | aqueous | +15.1000 | -86.1861 | +23.0591 | +23.0591 | [M1]:+1, [L2]:+2 | vlm_93862 | true | *** |

#### [Cu]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L3]4.[z+2] | [Cu(Ammo)4]2+ | +2 | aqueous | +12.3000 | -70.2046 | -70.2046 | -70.2046 | [M1]:+1, [L3]:+4 | vlm_173282 | true | *** |
| [M1].[L3]3.[z+2] | [Cu(Ammo)3]2+ | +2 | aqueous | +10.2000 | -58.2185 | -58.2185 | -58.2185 | [M1]:+1, [L3]:+3 | vlm_173270 | true | *** |
| [M1].[L3]2.[z+2] | [Cu(Ammo)2]2+ | +2 | aqueous | +7.4000 | -42.2369 | -42.2369 | -42.2369 | [M1]:+1, [L3]:+2 | vlm_173258 | true | *** |
| [M1].[L3].[z+2] | [Cu(Ammo)]2+ | +2 | aqueous | +4.1000 | -23.4015 | -23.4015 | -23.4015 | [M1]:+1, [L3]:+1 | vlm_173242 | true | *** |

#### [Cu]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L4].[z+1] | [Cu(Chlo)]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1, [L4]:+1 | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p06_m41_l10163/attempt01/patches.json) | true | {"lc1_2_estimates":[{"derivation":"median of the 9 K-sibling pool reported for beta_def=812","patched_log_K":0.0,"rationale":"examined vlm_177370 K=+0.200 is in a sign-split pool: 4 of 8 other K-siblings have opposite sign with values -0.2, -0.2, -0.2, and -0.1, while the full 9-row K summary is min=-0.200, median=+0.000, mean=+0.006, max=+0.270. Patching to the robust median 0.000 rather than preserving one side of the sign split.","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p06_m41_l10163/attempt01/patches.json)","source_database_ID":"vlm_177370_patched"}]} |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | true | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | true | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | true | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | true | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L2]2.[z-1] | [Cu(Glyc)2]- | -1 | aqueous | +10.1000 | -57.6477 | +51.5975 | +51.5975 | [M2]:+1, [L2]:+2 | vlm_93899 | true | *** |

#### [Cu]+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L3]2.[z+1] | [Cu(Ammo)2]+ | +1 | aqueous | +9.9200 | -56.6203 | -56.6203 | -56.6203 | [M2]:+1, [L3]:+2 | vlm_173333 | true | *** |

#### [Cu]+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2]2.[L4]4.[z-2] | [Cu2(Chlo)4]2- | -2 | aqueous | +13.0000 | -74.2000 | -74.2000 | -74.2000 | [M2]:+2, [L4]:+4 | vlm_177426 | true | *** |
| [M2].[L4]2.[z-1] | [Cu(Chlo)2]- | -1 | aqueous | +5.4200 | -30.9357 | -30.9357 | -30.9357 | [M2]:+1, [L4]:+2 | vlm_177420 | true | *** |
| [M2].[L4]3.[z-2] | [Cu(Chlo)3]2- | -2 | aqueous | +4.7500 | -27.1115 | -27.1115 | -27.1115 | [M2]:+1, [L4]:+3 | vlm_177420, vlm_177423 | true | *** |
| [M2].[L4].[z+0] | [Cu(Chlo)] | +0 | aqueous | +3.1000 | -17.6938 | -17.6938 | -17.6938 | [M2]:+1, [L4]:+1 | vlm_177416 | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H][L1]].[z+1] | [Fe(Citr)H]+ | +1 | aqueous | +12.3500 | -70.4900 | +3.1392 | +3.1392 | [M3]:+1, [[H][L1]]:+1 | vlm_157439, vlm_157687 | true | *** |
| [M3].[L1].[z+0] | [Fe(Citr)] | +0 | aqueous | +11.1900 | -63.8691 | +9.7602 | +9.7602 | [M3]:+1, [L1]:+1 | vlm_157682 | true | *** |
| [M3].[OH].[L1].[z-1] | [Fe(Citr)(OH)]- | -1 | aqueous | +8.4900 | -48.4583 | +25.1709 | +25.1709 | [M3]:+1, [OH]:+1, [L1]:+1 | vlm_157682, vlm_157688 | true | *** |
| [M3]2.[OH]2.[L1]2.[z-2] | [Fe2(Citr)2(OH)2]2- | -2 | aqueous | +21.2000 | -121.0031 | +26.2554 | +26.2554 | [M3]:+2, [OH]:+2, [L1]:+2 | vlm_157689 | true | *** |

#### [Fe]3+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H][L2]]2.[z+3] | [Fe(Glyc)2H2]3+ | +3 | aqueous | +22.8400 | -130.3637 | -21.1185 | -21.1185 | [M3]:+1, [[H][L2]]:+2 | vlm_93606, vlm_93885 | true | *** |
| [M3].[[H][L2]].[z+3] | [Fe(Glyc)H]3+ | +3 | aqueous | +11.3400 | -64.7252 | -10.1026 | -10.1026 | [M3]:+1, [[H][L2]]:+1 | vlm_93606, vlm_93882 | true | *** |
| [M3].[L2].[z+2] | [Fe(Glyc)]2+ | +2 | aqueous | +8.5700 | -48.9149 | +5.7077 | +5.7077 | [M3]:+1, [L2]:+1 | vlm_93880 | true | *** |

#### [Fe]3+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[L4]2.[z+1] | [Fe(Chlo)2]+ | +1 | aqueous | +2.1300 | -12.1574 | -12.1574 | -12.1574 | [M3]:+1, [L4]:+2 | vlm_177402 | true | *** |
| [M3].[L4].[z+2] | [Fe(Chlo)]2+ | +2 | aqueous | +0.7800 | -4.4520 | -4.4520 | -4.4520 | [M3]:+1, [L4]:+1 | vlm_177390 | true | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M3]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [M3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M3]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [M3].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [M3]:+1, [OH]:+2 | vlm_170807 | true | *** |
| [M3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M3]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [M3].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M3]:+1, [OH]:+4 | vlm_170808 | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[[H]2[L1]].[z+1] | [Fe(Citr)H2]+ | +1 | aqueous | +11.1000 | -63.3554 | +10.2738 | +10.2738 | [M4]:+1, [[H]2[L1]]:+1 | vlm_157439, vlm_157459, vlm_157627 | true | *** |
| [M4].[[H][L1]].[z+0] | [Fe(Citr)H] | +0 | aqueous | +8.5500 | -48.8008 | +24.8285 | +24.8285 | [M4]:+1, [[H][L1]]:+1 | vlm_157439, vlm_157623 | true | *** |
| [M4].[L1].[z-1] | [Fe(Citr)]- | -1 | aqueous | +4.5600 | -26.0271 | +47.6022 | +47.6022 | [M4]:+1, [L1]:+1 | vlm_157621 | true | *** |
| [M4].[L1]2.[H].[z-3] | [Fe(Citr)2H]3- | -3 | aqueous | +11.7400 | -67.0083 | +80.2501 | +80.2501 | [M4]:+1, [L1]:+2, [H]:+1 | vlm_157439, vlm_157623, vlm_157628 | true | *** |
| [M4]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | -4 | aqueous | -5.4000 | +30.8215 | +178.0800 | +178.0800 | [M4]:+2, [[H]-1[L1]]:+2 | vlm_157629 | true | *** |

#### [Fe]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[L2].[z+1] | [Fe(Glyc)]+ | +1 | aqueous | +4.1300 | -23.5728 | +31.0498 | +31.0498 | [M4]:+1, [L2]:+1 | vlm_93747 | true | *** |
| [M4].[L2]2.[z+0] | [Fe(Glyc)2] | +0 | aqueous | +7.6500 | -43.6638 | +65.5814 | +65.5814 | [M4]:+1, [L2]:+2 | vlm_93758 | true | *** |
| [M4].[L2]3.[z-1] | [Fe(Glyc)3]- | -1 | aqueous | +8.8700 | -50.6272 | +113.2406 | +113.2406 | [M4]:+1, [L2]:+3 | vlm_93760 | true | *** |

#### [Fe]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[L3]4.[z+2] | [Fe(Ammo)4]2+ | +2 | aqueous | +2.7500 | -15.6962 | -15.6962 | -15.6962 | [M4]:+1, [L3]:+4 | vlm_173160 | true | *** |
| [M4].[L3]3.[z+2] | [Fe(Ammo)3]2+ | +2 | aqueous | +2.6800 | -15.2966 | -15.2966 | -15.2966 | [M4]:+1, [L3]:+3 | vlm_173152 | true | *** |
| [M4].[L3]2.[z+2] | [Fe(Ammo)2]2+ | +2 | aqueous | +2.2500 | -12.8423 | -12.8423 | -12.8423 | [M4]:+1, [L3]:+2 | vlm_173144 | true | *** |
| [M4].[L3].[z+2] | [Fe(Ammo)]2+ | +2 | aqueous | +1.4000 | -7.9908 | -7.9908 | -7.9908 | [M4]:+1, [L3]:+1 | vlm_173136 | true | *** |

#### [Fe]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[L4].[z+1] | [Fe(Chlo)]+ | +1 | aqueous | -0.2000 | +1.1415 | +1.1415 | +1.1415 | [M4]:+1, [L4]:+1 | vlm_177345 | true | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M4]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [M4].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [M4]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [M4].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M4]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [M4].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M4]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Chloride ion]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L4]0.5.[OH]1.5.[z+0]_(s) | [Cu((OH))1.5(Chloride ion)0.5](s) | +0 | dissolution | -3.7000 | +21.1185 | +21.1185 | +21.1185 | [M1]:+1, [L4]:+0.5, [H]:-1.5 | vlm_177378 | true | *** |

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +43.6638 | [M1]:+1, [H]:-2 | vlm_170746 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | true | *** |

#### [Cu]+ + [Chloride ion]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L4].[z+0]_(s) | [Cu(Chloride ion)](s) | +0 | dissolution | +6.7300 | -38.4128 | -38.4128 | -38.4128 | [M2]:+1, [L4]:+1 | vlm_177428 | true | *** |

#### [Cu]+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M2]:+1, [H]:-1 | vlm_170869 | true | *** |

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M3]:+1, [H]:-3 | vlm_170828 | true | *** |
| [M3].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M3]:+1, [H]:-3 | vlm_170827 | true | *** |
| [M3].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M3]:+1, [OH]:+3 | vlm_170825 | true | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M4]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 69 |
| Included in calculation | 69 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 68 |
| Unresolved (no species in card) | 1 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_157473 | [<H+>2<Citric acid>] + [<H+>] <=> [<H+>3<Citric acid>] | +2.9000 | 25.0 | 0.100 | yes | [H3Citric acid] |
| 2 | vlm_157459 | [<H+><Citric acid>] + [<H+>] <=> [<H+>2<Citric acid>] | +4.3500 | 25.0 | 0.100 | yes | [H3Citric acid], [H2Citric acid]-, [Fe(Citr)H2]+ |
| 3 | vlm_157439 | [<H+>] + [<Citric acid>] <=> [<H+><Citric acid>] | +5.6500 | 25.0 | 0.100 | yes | [H3Citric acid], [H2Citric acid]-, [HCitric acid]2-, [Cu(Citr)H], [Fe(Citr)H]+, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3- |
| 4 | vlm_93627 | [<H+><Glycine>] + [<H+>] <=> [<H+>2<Glycine>] | +2.3300 | 25.0 | 0.100 | yes | [H2Glycine]+ |
| 5 | vlm_93606 | [<H+>] + [<Glycine>] <=> [<H+><Glycine>] | +9.5700 | 25.0 | 0.100 | yes | [H2Glycine]+, [HGlycine], [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+ |
| 6 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 7 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [H2O] |
| 8 | vlm_157667 | [<Citric acid>] + [<Cu2+>]^2 <=> [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)] | +4.8600 | 25.0 | 0.100 | yes | [Cu2(Citr)(OH)] |
| 9 | vlm_157671 | [<Citric acid>]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<Citric acid>2] | +14.5000 | 25.0 | 0.100 | yes | [Cu2(Citr)2]2-, [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4- |
| 10 | vlm_157675 | [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)<Citric acid>] <=> [<Cu2+>2<Citric acid>2] | +3.3000 | 25.0 | 0.100 | yes | [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4- |
| 11 | vlm_157678 | [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)2] <=> [<Cu2+>2(<H+>-1<Citric acid>)<Citric acid>] | +4.8600 | 25.0 | 0.100 | yes | [Cu2(Citr)2(OH)2]4- |
| 12 | vlm_157663 | [<H+><Citric acid>] + [<Cu2+>] <=> [<Cu2+><H+><Citric acid>] | +3.6100 | 25.0 | 0.100 | yes | [Cu(Citr)H] |
| 13 | vlm_170721 | [<OH->]^2 + [<Cu2+>] <=> [<Cu2+><OH->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 14 | vlm_170727 | [<OH->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 15 | vlm_170736 | [<OH->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 16 | vlm_170713 | [<OH->] + [<Cu2+>] <=> [<Cu2+><OH->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 17 | vlm_170742 | [<Cu2+><OH->2(s)] <=> [<OH->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 18 | vlm_170746 | [H2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [<OH->]^2 | -20.3500 | 25.0 | 0.000 | yes | [CuO](s) |
| 19 | vlm_93862 | [<Glycine>]^2 + [<Cu2+>] <=> [<Cu2+><Glycine>2] | +15.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2] |
| 20 | vlm_93847 | [<Glycine>] + [<Cu2+>] <=> [<Cu2+><Glycine>] | +8.1900 | 25.0 | 0.100 | yes | [Cu(Glyc)]+ |
| 21 | vlm_177370_patched | [<Chloride ion>] + [<Cu2+>] <=> [<Cu2+><Chloride ion>] | +0.0000 | 25.0 | 0.000 | yes | — |
| 22 | vlm_177378 | [<Cu2+>(<OH->)1.5<Chloride ion>0.5(s)] <=> [<Chloride ion>]^0.5 + [<Cu2+>] + [<OH->]^1.5 | -17.3000 | 25.0 | 0.000 | yes | [Cu((OH))1.5(Chloride ion)0.5](s) |
| 23 | vlm_173258 | [<Ammonia>]^2 + [<Cu2+>] <=> [<Cu2+><Ammonia>2] | +7.4000 | 25.0 | 0.000 | yes | [Cu(Ammo)2]2+ |
| 24 | vlm_173242 | [<Ammonia>] + [<Cu2+>] <=> [<Cu2+><Ammonia>] | +4.1000 | 25.0 | 0.100 | yes | [Cu(Ammo)]2+ |
| 25 | vlm_173282 | [<Ammonia>]^4 + [<Cu2+>] <=> [<Cu2+><Ammonia>4] | +12.3000 | 25.0 | 0.000 | yes | [Cu(Ammo)4]2+ |
| 26 | vlm_173270 | [<Ammonia>]^3 + [<Cu2+>] <=> [<Cu2+><Ammonia>3] | +10.2000 | 25.0 | 0.000 | yes | [Cu(Ammo)3]2+ |
| 27 | vlm_93899 | [<Glycine>]^2 + [<Cu+>] <=> [<Cu+><Glycine>2] | +10.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2]- |
| 28 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H2O]^0.5 <=> [<Cu+>] + [<OH->] | -14.7000 | 25.0 | 0.000 | yes | [(Cu2O)0.5](s) |
| 29 | vlm_177416 | [<Chloride ion>] + [<Cu+>] <=> [<Cu+><Chloride ion>] | +3.1000 | 25.0 | 0.000 | yes | [Cu(Chlo)] |
| 30 | vlm_177420 | [<Chloride ion>]^2 + [<Cu+>] <=> [<Cu+><Chloride ion>2] | +5.4200 | 25.0 | 0.000 | yes | [Cu(Chlo)2]-, [Cu(Chlo)3]2- |
| 31 | vlm_177423 | [<Chloride ion>] + [<Cu+><Chloride ion>2] <=> [<Cu+><Chloride ion>3] | -0.6700 | 25.0 | 0.000 | yes | [Cu(Chlo)3]2- |
| 32 | vlm_177426 | [<Chloride ion>]^4 + [<Cu+>]^2 <=> [<Cu+>2<Chloride ion>4] | +13.0000 | 25.0 | 5.000 | yes | [Cu2(Chlo)4]2- |
| 33 | vlm_177428 | [<Cu+><Chloride ion>(s)] <=> [<Chloride ion>] + [<Cu+>] | -6.7300 | 25.0 | 0.000 | yes | [Cu(Chloride ion)](s) |
| 34 | vlm_173333 | [<Ammonia>]^2 + [<Cu+>] <=> [<Cu+><Ammonia>2] | +9.9200 | 20.0 | 0.100 | yes | [Cu(Ammo)2]+ |
| 35 | vlm_157688 | [<H+>] + [<Fe3+>(<OH->)<Citric acid>] <=> [H2O] + [<Fe3+><Citric acid>] | +2.7000 | 25.0 | 0.100 | yes | [Fe(Citr)(OH)]- |
| 36 | vlm_157689 | [H2O]^2 + [<Citric acid>]^2 + [<Fe3+>]^2 <=> [<H+>]^2 + [<Fe3+>2(<OH->)2<Citric acid>2] | +21.2000 | 20.0 | 0.100 | yes | [Fe2(Citr)2(OH)2]2- |
| 37 | vlm_157682 | [<Citric acid>] + [<Fe3+>] <=> [<Fe3+><Citric acid>] | +11.1900 | 25.0 | 0.100 | yes | [Fe(Citr)], [Fe(Citr)(OH)]- |
| 38 | vlm_157687 | [<H+><Citric acid>] + [<Fe3+>] <=> [<Fe3+><H+><Citric acid>] | +6.7000 | 25.0 | 0.100 | yes | [Fe(Citr)H]+ |
| 39 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 40 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 41 | vlm_170807 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 42 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 43 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 44 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 45 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 46 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |
| 47 | vlm_93880 | [<Glycine>] + [<Fe3+>] <=> [<Fe3+><Glycine>] | +8.5700 | 25.0 | 0.500 | yes | [Fe(Glyc)]2+ |
| 48 | vlm_93882 | [<H+><Glycine>] + [<Fe3+>] <=> [<Fe3+><H+><Glycine>] | +1.7700 | 25.0 | 0.500 | yes | [Fe(Glyc)H]3+ |
| 49 | vlm_93885 | [<H+><Glycine>]^2 + [<Fe3+>] <=> [<Fe3+>(<H+><Glycine>)2] | +3.7000 | 25.0 | 3.000 | yes | [Fe(Glyc)2H2]3+ |
| 50 | vlm_177402 | [<Chloride ion>]^2 + [<Fe3+>] <=> [<Fe3+><Chloride ion>2] | +2.1300 | 25.0 | 0.000 | yes | [Fe(Chlo)2]+ |
| 51 | vlm_177390 | [<Chloride ion>] + [<Fe3+>] <=> [<Fe3+><Chloride ion>] | +0.7800 | 25.0 | 0.100 | yes | [Fe(Chlo)]2+ |
| 52 | vlm_157621 | [<Citric acid>] + [<Fe2+>] <=> [<Fe2+><Citric acid>] | +4.5600 | 37.0 | 0.150 | yes | [Fe(Citr)]- |
| 53 | vlm_157623 | [<H+><Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+><Citric acid>] | +2.9000 | 25.0 | 0.100 | yes | [Fe(Citr)H], [Fe(Citr)2H]3- |
| 54 | vlm_157627 | [<H+>2<Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+>2<Citric acid>] | +1.1000 | 37.0 | 0.150 | yes | [Fe(Citr)H2]+ |
| 55 | vlm_157628 | [<Citric acid>] + [<Fe2+><H+><Citric acid>] <=> [<Fe2+><H+><Citric acid>2] | +3.1900 | 37.0 | 0.150 | yes | [Fe(Citr)2H]3- |
| 56 | vlm_157629 | [<Citric acid>]^2 + [<Fe2+>]^2 <=> [<H+>]^2 + [<Fe2+>2(<H+>-1<Citric acid>)2] | -5.4000 | 37.0 | 0.150 | yes | [Fe2(Citr)2(OH)2]4- |
| 57 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 58 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | +7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 59 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 60 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 61 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 62 | vlm_93760 | [<Glycine>]^3 + [<Fe2+>] <=> [<Fe2+><Glycine>3] | +8.8700 | 25.0 | 1.000 | yes | [Fe(Glyc)3]- |
| 63 | vlm_93747 | [<Glycine>] + [<Fe2+>] <=> [<Fe2+><Glycine>] | +4.1300 | 25.0 | 0.100 | yes | [Fe(Glyc)]+ |
| 64 | vlm_93758 | [<Glycine>]^2 + [<Fe2+>] <=> [<Fe2+><Glycine>2] | +7.6500 | 25.0 | 0.100 | yes | [Fe(Glyc)2] |
| 65 | vlm_177345 | [<Chloride ion>] + [<Fe2+>] <=> [<Fe2+><Chloride ion>] | -0.2000 | 25.0 | 0.000 | yes | [Fe(Chlo)]+ |
| 66 | vlm_173136 | [<Ammonia>] + [<Fe2+>] <=> [<Fe2+><Ammonia>] | +1.4000 | 25.0 | 0.000 | yes | [Fe(Ammo)]2+ |
| 67 | vlm_173144 | [<Ammonia>]^2 + [<Fe2+>] <=> [<Fe2+><Ammonia>2] | +2.2500 | 25.0 | 0.000 | yes | [Fe(Ammo)2]2+ |
| 68 | vlm_173152 | [<Ammonia>]^3 + [<Fe2+>] <=> [<Fe2+><Ammonia>3] | +2.6800 | 25.0 | 0.000 | yes | [Fe(Ammo)3]2+ |
| 69 | vlm_173160 | [<Ammonia>]^4 + [<Fe2+>] <=> [<Fe2+><Ammonia>4] | +2.7500 | 25.0 | 0.000 | yes | [Fe(Ammo)4]2+ |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

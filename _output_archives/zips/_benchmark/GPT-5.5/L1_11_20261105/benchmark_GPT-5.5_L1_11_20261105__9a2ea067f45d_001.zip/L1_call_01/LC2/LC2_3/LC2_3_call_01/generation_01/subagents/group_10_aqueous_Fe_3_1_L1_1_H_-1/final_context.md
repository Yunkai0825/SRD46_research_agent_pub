## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as an electrodeposition-relevant joint Cu/Fe Pourbaix speciation problem in one shared electrolyte, not a dilute corrosion atlas calculation; the governing context is 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m.
- Aqueous identity is controlled by the supplied ligand-rich solution and full pH/E window, so different oxidation states, ligand stoichiometries, protonation states, hydrolysis states, and plausible polynuclear complexes are distinct unless they are only alternate spellings of the same mononuclear free ion or same solid.
- Prefer SRD-46 entries over Atlas entries for exact duplicate aqueous free-ion or solid-state representations when both describe the same physical state with the same composition and charge; provenance alone is not a reason to keep both.
- This is a water-rich electrolyte design calculation at 25 C, so hydrated hydroxide solids are preferred over anhydrous oxide alternatives for the same metal/oxidation/hydrolysis chemistry unless the user explicitly requested the oxide; here Fe2O3, CuO, FeOOH, and Fe3O4 are explicitly out of the active system.
- Chloride is a major electrolyte component, so Cu/Fe chloride aqueous complexes and chloride-containing precipitates are in scope; carbonates are absent and any carbonate branch would be out of scope.
- Mixed-valence or high-valence aqueous redox species may be retained if chemically distinct across the E-pH window, but the explicitly banned Fe3O4 mixed-valence solid must be excluded.
- The phase question is stable partitioning on a Pourbaix hull for electrodeposition, so collapse polymorph/notation duplicates to a single preferred representative; do not retain multiple versions of the same stable solid only to describe formation pathway.
- Elemental Cu(s) and Fe(s) must remain as electrodeposition/reference metal phases. Decorative gases are not part of this inventory and should not be introduced.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: For Fe, retain distinct Fe(II), Fe(III), and Fe(VI) aqueous species, ligand complexes, hydrolysis/protonation states, and polynuclear complexes unless they are merely alternate notation for the same free ion or same complex. Collapse exact duplicates to the preferred SRD-46 representative when present; exclude Fe2O3, FeOOH, and Fe3O4 as requested, prefer Fe(OH)2 and Fe(OH)3 hydrated precipitates for water-rich conditions, and keep Fe(s) as the electrodeposition metal phase.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 L1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-977369ffb378cf98` | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | -1 | 99.521 | 1 | *** |
| `DEDUP-0cc29ed24775130c` | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | -2 | 174.955 | 2 | *** |

## Assistant
<summary>Kept both SRD-46 aqueous citrate hydroxo iron complexes because they differ in nuclearity/multiplier and charge, so they represent distinct mononuclear vs dinuclear species under the ligand-rich electrolyte rules.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
Kept both SRD-46 aqueous citrate hydroxo iron complexes because they differ in nuclearity/multiplier and charge, so they are distinct mononuclear and dinuclear species.
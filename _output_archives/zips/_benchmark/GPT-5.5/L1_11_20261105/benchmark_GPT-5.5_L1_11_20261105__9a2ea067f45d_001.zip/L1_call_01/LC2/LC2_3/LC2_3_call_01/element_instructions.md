# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as an electrodeposition-relevant joint Cu/Fe Pourbaix speciation problem in one shared electrolyte, not a dilute corrosion atlas calculation; the governing context is 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m.
- Aqueous identity is controlled by the supplied ligand-rich solution and full pH/E window, so different oxidation states, ligand stoichiometries, protonation states, hydrolysis states, and plausible polynuclear complexes are distinct unless they are only alternate spellings of the same mononuclear free ion or same solid.
- Prefer SRD-46 entries over Atlas entries for exact duplicate aqueous free-ion or solid-state representations when both describe the same physical state with the same composition and charge; provenance alone is not a reason to keep both.
- This is a water-rich electrolyte design calculation at 25 C, so hydrated hydroxide solids are preferred over anhydrous oxide alternatives for the same metal/oxidation/hydrolysis chemistry unless the user explicitly requested the oxide; here Fe2O3, CuO, FeOOH, and Fe3O4 are explicitly out of the active system.
- Chloride is a major electrolyte component, so Cu/Fe chloride aqueous complexes and chloride-containing precipitates are in scope; carbonates are absent and any carbonate branch would be out of scope.
- Mixed-valence or high-valence aqueous redox species may be retained if chemically distinct across the E-pH window, but the explicitly banned Fe3O4 mixed-valence solid must be excluded.
- The phase question is stable partitioning on a Pourbaix hull for electrodeposition, so collapse polymorph/notation duplicates to a single preferred representative; do not retain multiple versions of the same stable solid only to describe formation pathway.
- Elemental Cu(s) and Fe(s) must remain as electrodeposition/reference metal phases. Decorative gases are not part of this inventory and should not be introduced.

## Element instructions

- **Cu**: For Cu, retain distinct Cu(I)/Cu(II) aqueous complexes differing by ligand, charge, hydrolysis/protonation, or nuclearity because the ligand-rich electrolyte can give them different E-pH domains. Collapse exact duplicate free ions and exact duplicate solids to the preferred SRD-46 representative when present; exclude CuO specifically, prefer Cu(OH)2 over CuO for the Cu(II) hydroxide/oxide precipitate branch, keep Cu2O and Cu(s), and keep Cu chloride solid phases as in-scope chloride chemistry.
- **Fe**: For Fe, retain distinct Fe(II), Fe(III), and Fe(VI) aqueous species, ligand complexes, hydrolysis/protonation states, and polynuclear complexes unless they are merely alternate notation for the same free ion or same complex. Collapse exact duplicates to the preferred SRD-46 representative when present; exclude Fe2O3, FeOOH, and Fe3O4 as requested, prefer Fe(OH)2 and Fe(OH)3 hydrated precipitates for water-rich conditions, and keep Fe(s) as the electrodeposition metal phase.

# Eq-map screen — m62_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10103_beta812_net28171` | `[M] + [L] <=> [ML]` | vlm_173136@(25.0,0.0) = K+1.400 | 6 | +1.400 / +1.630 / +1.620 / +1.800 | vlm_173136@(25.0,0.0) = K+1.400 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal62_ligand10103_beta840_net28171` | `[M] + [L]^2 <=> [ML2]` | vlm_173144@(25.0,0.0) = K+2.250 | 6 | +2.250 / +2.700 / +2.677 / +3.020 | vlm_173144@(25.0,0.0) = K+2.250 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal62_ligand10103_beta872_net28171` | `[M] + [L]^3 <=> [ML3]` | vlm_173152@(25.0,0.0) = K+2.680 | 6 | +2.680 / +3.360 / +3.322 / +3.830 | vlm_173152@(25.0,0.0) = K+2.680 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal62_ligand10103_beta894_net28171` | `[M] + [L]^4 <=> [ML4]` | vlm_173160@(25.0,0.0) = K+2.750 | 6 | +2.750 / +3.640 / +3.590 / +4.250 | vlm_173160@(25.0,0.0) = K+2.750 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Build a joint two-dimensional E-pH Pourbaix diagram for a single electrolyte containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia at 25 C and ionic strength 0.1 molal. The goal is to understand electrodeposition-relevant partitioning of Cu and Fe among aqueous complexes, redox states, and precipitated phases, while preferring hydrated species in this water-rich scenario and excluding selected oxide phases.]
[Tasks:
For one shared solution/pot, model 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m. Build the joint two-dimensional E-pH Pourbaix diagram over pH 0 to 14 and E = -1.0 to +1.5 V versus SHE. Prefer hydrated species where the database offers hydrated/dehydrated alternatives appropriate for water-rich electrolyte design, and do not keep Fe2O3, CuO, FeOOH, or Fe3O4 in the active system. Identify how Cu and Fe partition among species across the diagram, and report the principal region boundaries and junctions using the equilibrium constants and potentials actually used by the solver.
]
[Pair: pair_key=`m41_l9058`, metal_id=41, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand9058_beta369_net22160`
  - `metal41_ligand9058_beta519_net22160`
  - `metal41_ligand9058_beta372_net22160`
  - `metal41_ligand9058_beta779_net22160`
[Screen report]
# Eq-map screen — m41_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand9058_beta369_net22160` | `[M]^2 + [L] <=> [M2(H-1L)] + [H]` | vlm_157667@(25.0,0.1) = K+4.860 | 2 | +4.860 / +5.080 / +5.080 / +5.300 | vlm_157667@(25.0,0.1) = K+4.860 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal41_ligand9058_beta519_net22160` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_157671@(25.0,0.1) = K+14.500 | 2 | +14.500 / +14.650 / +14.650 / +14.800 | vlm_157671@(25.0,0.1) = K+14.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal41_ligand9058_beta382_net22160` | `[M2(H-1L)L] + [H] <=> [M2L2]` | vlm_157675@(25.0,0.1) = K+3.300 | 1 | +3.300 / +3.300 / +3.300 / +3.300 | vlm_157675@(25.0,0.1) = K+3.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 4 | `metal41_ligand9058_beta372_net22160` | `[M2(H-1L)2] + [H] <=> [M2(H-1L)L]` | vlm_157678@(25.0,0.1) = K+4.860 | 2 | +4.860 / +5.050 / +5.050 / +5.240 | vlm_157678@(25.0,0.1) = K+4.860 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal41_ligand9058_beta779_net22160` | `[M] + [HL] <=> [MHL]` | vlm_157663@(25.0,0.1) = K+3.610 | 2 | +3.610 / +3.760 / +3.760 / +3.910 | vlm_157663@(25.0,0.1) = K+3.610 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

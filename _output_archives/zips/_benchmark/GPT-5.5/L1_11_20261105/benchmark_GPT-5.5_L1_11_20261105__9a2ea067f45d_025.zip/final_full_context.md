## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build a joint two-dimensional E-pH Pourbaix diagram for a single electrolyte containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia at 25 C and ionic strength 0.1 molal. The goal is to understand electrodeposition-relevant partitioning of Cu and Fe among aqueous complexes, redox states, and precipitated phases, while preferring hydrated species in this water-rich scenario and excluding selected oxide phases.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 11,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv"
    ],
    "elapsed_s": 40365.5
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build a joint two-dimensional E-pH Pourbaix diagram for a single electrolyte containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia at 25 C and ionic strength 0.1 molal. The goal is to understand electrodeposition-relevant partitioning of Cu and Fe among aqueous complexes, redox states, and precipitated phases, while preferring hydrated species in this water-rich scenario and excluding selected oxide phases.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
In a single solution containing 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m, build the joint two-dimensional E-pH Pourbaix diagram over pH 0-14 and E=-1.0 to +1.5 V_SHE. Hydrated species are preferred for this water-rich scenario about electrodeposition electrolyte design, and do not keep Fe2O3, CuO, FeOOH and Fe3O4. Identify how Cu and Fe partition among species, and report the principal region boundaries and junctions using the equilibrium constants and potentials actually used by the solver.

## Assistant
<summary>I will run one joint L1 calculation because all metals and ligands are in the same solution and must compete in one equilibrium model. The requested output is a 2D E–pH Pourbaix/speciation diagram with excluded oxide solids and hydrated species preferred.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable and completed: the supported `pourbaix_sweep` pipeline solved the requested Cu–Fe citrate/glycine/chloride/ammonia electrolyte at 25 °C, I=0.1, pH 0–14 and E = −1.0 to +1.5 V vs SHE.

## Result
A joint solution was built with totals Cu=1 mM, Fe=1 mM, citrate=10 mM, glycine=10 mM, ammonia=0.1 M and chloride=0.1 M. Separate principal-element Pourbaix verdicts were produced for Cu and Fe on the same pH–E grid, with final classified-grid spacing ΔpH=0.00625 and ΔE=0.00125 V. The verdicts report 10 Cu dominant labels in 11 connected regions and 11 Fe labels in 11 connected regions. The full-speciation CSV header reports 14,917 coarse-unrefined and 396,669 refined samples, with a `converged` column; the opened rows have `converged=1`, but no aggregate convergence count was exposed in the returned header, so quantitative topology should be read as the solver’s classified-grid verdict rather than as a manually re-aggregated convergence audit.

The requested oxide exclusions were honored in the active species list: CuO/CuO(s) and dehydrated Cu2O alternatives were excluded where listed, while Cu metal, [(Cu2O)0.5](s), Cu(OH)2(s) and other requested/selected hydrated or hydroxide solids remained. For Fe, Fe3O4, Fe2O3 and FeOOH were excluded; Fe(OH)2(s), Fe(OH)3(s) and Fe metal remained.

## Analysis
Cu: at the central E cut, E=0.250625 V, Cu changes from chloride control to citrate/glycine/hydroxide control as pH rises: [Cu(Chlo)2]- dominates pH 0.003125–3.878125, [Cu2(Citr)2(OH)]3- pH 3.884375–4.003125, [Cu2(Citr)2(OH)2]4- pH 4.009375–7.578125, [Cu(Glyc)2] pH 7.584375–11.128125, [Cu2(Citr)2(OH)2]4- again pH 11.134375–11.521875, Cu(OH)2(s) pH 11.528125–13.578125, then CuO22- pH 13.584375–13.996875. Thus chloride wins only in strong acid, citrate–hydroxo Cu(II) stabilizes intermediate pH, glycine wins in the near-neutral/basic window where deprotonated glycine is available, and precipitation/oxide-hydroxo chemistry takes over at high pH. At pH=6.996875, Cu metal dominates E=−0.999375 to 0.051875 V, then [Cu2(Citr)2(OH)2]4- dominates from 0.053125 to 1.499375 V: for electrodeposition, crossing near 0.052–0.053 V vs SHE at pH≈7 is the Cu/Cu–citrate-hydroxo transition in this model.

Principal Cu junctions include all-liquid DmsRegEqJnc_1 at pH=4.00625, E=0.2375 V where [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]- and [Cu2(Citr)2(OH)]3- meet; DmsRegEqJnc_2 at pH=3.23125, E=0.3425 V where those chloride/citrate species meet Cu2+; and metal/complex junctions DmsRegEqJnc_12 at pH=5.1, E=0.115 V for Cu, [Cu2(Citr)2(OH)2]4- and [Cu(Chlo)2]-, DmsRegEqJnc_11 at pH=7.35625, E=0.03875 V for Cu, [Cu(Glyc)2] and [Cu2(Citr)2(OH)2]4-, and DmsRegEqJnc_9 at pH=7.7625, E=0.01625 V for Cu, [Cu(Ammo)2]+ and [Cu(Glyc)2]. Important Cu boundaries include Cu|[Cu(Chlo)2]- from pH 0, E=0.13 V to pH 5.1, E=0.115 V; Cu|[Cu2(Citr)2(OH)2]4- from pH 5.1, E=0.115 V to pH 7.35625, E=0.03875 V; and Cu|[Cu(Glyc)2] from pH 7.7625, E=0.01625 V to pH 7.35625, E=0.03875 V.

Fe: at E=0.250625 V, Fe is Fe2+ from pH 0.003125–4.071875, [Fe(Citr)]- from 4.078125–4.659375, [Fe2(Citr)2(OH)2]2- from 4.665625–6.296875, Fe(OH)3(s) from 6.303125–13.771875, and FeO42- above pH 13.778125. At pH=6.996875, Fe metal dominates E=−0.999375 to −0.576875 V, [Fe(Citr)]- from −0.575625 to 0.026875 V, Fe(OH)3(s) from 0.028125 to 0.919375 V, and FeO42- from 0.920625 V upward. Thus, compared with Cu, Fe is much harder to keep dissolved near neutral oxidizing conditions: citrate stabilizes Fe over limited reducing/intermediate windows, but Fe(OH)3(s) dominates most neutral-to-alkaline oxidizing space.

Key Fe junctions are DmsRegEqJnc_1 at pH=4.08125, E=0.28875 V where [Fe(Citr)]-, Fe2+ and [Fe2(Citr)2(OH)2]2- meet; DmsRegEqJnc_3 at pH=1.4625, E=0.77 V for Fe2+, [Fe(Citr)] and Fe3+; DmsRegEqJnc_11 at pH=6.36875, E=0.155 V for [Fe(Citr)]-, Fe(OH)3(s) and [Fe2(Citr)2(OH)2]2-; and DmsRegEqJnc_12 at pH=6.3625, E=0.975 V for Fe(OH)3(s), [Fe2(Citr)2(OH)2]2- and FeO42-. Electrodeposition-relevant Fe metal boundaries lie far more negative than Cu: Fe|Fe2+ runs near E≈−0.5375 to −0.5525 V up to pH 4.03125, and Fe|[Fe(Citr)]- spans pH 4.03125–8.0625 around E≈−0.5525 to −0.585 V. This separation implies a broad potential window where Cu can plate while Fe remains dissolved/complexed or precipitated rather than metal, especially near neutral pH.

Constants used include citrate protonation log_beta values 12.9000, 10.0000 and 5.6500 for H3Citric acid, H2Citric acid- and HCitric acid2-, glycine protonation log_beta 11.9000 and 9.5700, ammonium log_beta 9.2600, Cu–glycine log_beta 15.1000 for [Cu(Glyc)2], Cu–ammonia log_beta 12.3000 for [Cu(Ammo)4]2+, Cu(II) citrate-hydroxo log_beta 11.2000 for [Cu2(Citr)2(OH)]3- and 6.3400 for [Cu2(Citr)2(OH)2]4-, Fe(III) citrate log_beta 11.1900 for [Fe(Citr)], and Fe(III) dimeric citrate-hydroxo log_beta 21.2000 for [Fe2(Citr)2(OH)2]2-. These constants explain why citrate and glycine displace simple aqua/chloro species over much of the diagram, while hydrolysis/solids dominate at high pH.

## Artifacts
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md
L1_call_01/thermodynamic_reference_constants.md
L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

The joint Cu–Fe Pourbaix calculation completed for the single mixed electrolyte: 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 °C, I = 0.1 m, over pH 0–14 and E = −1.0 to +1.5 V vs SHE.

### Overall chemical interpretation

Cu and Fe behave quite differently in this ligand-rich electrolyte.

**Copper remains comparatively easier to keep in soluble complexed form and to electrodeposit selectively.**  
At acidic pH, Cu is chloride-controlled, mainly as `[Cu(Chlo)2]-`. As pH increases, citrate and hydroxo-citrate Cu(II) complexes take over, then glycine becomes dominant in the near-neutral to mildly basic region. At still higher pH, Cu hydroxide/oxo species and solids dominate. Around pH ≈ 7, Cu metal becomes dominant below about **0.052–0.053 V vs SHE**, while soluble Cu–citrate/hydroxo complexes dominate above that potential. This gives an electrodeposition-relevant Cu reduction boundary at relatively mild potentials.

**Iron is much less easily kept dissolved under neutral oxidizing conditions.**  
Fe is Fe²⁺ in acidic solution, citrate-complexed around mildly acidic to near-neutral conditions, but **Fe(OH)₃(s)** dominates a large neutral-to-alkaline oxidizing region. Fe metal only appears at much more negative potentials, e.g. near pH ≈ 7 below about **−0.576 V vs SHE**. Thus, there is a broad potential window where Cu can plate while Fe remains dissolved, complexed, or precipitated rather than codepositing as Fe metal.

The excluded phases were honored: **Fe₂O₃, CuO, FeOOH, and Fe₃O₄** were not retained as active solids. Hydrated/hydroxide-relevant phases such as Cu(OH)₂(s), Fe(OH)₂(s), Fe(OH)₃(s), Cu metal, and Fe metal remained.

## Evidence

- The solver completed a supported **Pourbaix sweep** on a joint grid with spacing  
  **ΔpH = 0.00625** and **ΔE = 0.00125 V**.
- The verdicts reported:
  - **Cu:** 10 dominant labels in 11 connected regions.
  - **Fe:** 11 dominant labels in 11 connected regions.
- The full speciation file reported **14,917 coarse-unrefined** and **396,669 refined** samples, with a `converged` column; inspected rows had `converged = 1`.

### Cu partitioning

At the central potential cut, **E = 0.250625 V**, Cu dominance changes with pH as follows:

- `[Cu(Chlo)2]-`: pH **0.003125–3.878125**
- `[Cu2(Citr)2(OH)]3-`: pH **3.884375–4.003125**
- `[Cu2(Citr)2(OH)2]4-`: pH **4.009375–7.578125**
- `[Cu(Glyc)2]`: pH **7.584375–11.128125**
- `[Cu2(Citr)2(OH)2]4-`: pH **11.134375–11.521875**
- `Cu(OH)2(s)`: pH **11.528125–13.578125**
- `CuO22-`: pH **13.584375–13.996875**

At **pH = 6.996875**, Cu varies with potential as:

- `Cu` metal: **E = −0.999375 to 0.051875 V**
- `[Cu2(Citr)2(OH)2]4-`: **E = 0.053125 to 1.499375 V**

So the Cu metal / Cu–citrate-hydroxo transition at near-neutral pH lies at about **0.052–0.053 V vs SHE**.

Principal Cu junctions reported by the solver include:

- `DmsRegEqJnc_1`: **pH = 4.00625, E = 0.2375 V**  
  `[Cu2(Citr)2(OH)2]4-`, `[Cu(Chlo)2]-`, `[Cu2(Citr)2(OH)]3-`
- `DmsRegEqJnc_2`: **pH = 3.23125, E = 0.3425 V**  
  chloride/citrate Cu species with `Cu2+`
- `DmsRegEqJnc_12`: **pH = 5.1, E = 0.115 V**  
  `Cu`, `[Cu2(Citr)2(OH)2]4-`, `[Cu(Chlo)2]-`
- `DmsRegEqJnc_11`: **pH = 7.35625, E = 0.03875 V**  
  `Cu`, `[Cu(Glyc)2]`, `[Cu2(Citr)2(OH)2]4-`
- `DmsRegEqJnc_9`: **pH = 7.7625, E = 0.01625 V**  
  `Cu`, `[Cu(Ammo)2]+`, `[Cu(Glyc)2]`

Important Cu boundaries include:

- `Cu | [Cu(Chlo)2]-`: from **pH 0, E = 0.13 V** to **pH 5.1, E = 0.115 V**
- `Cu | [Cu2(Citr)2(OH)2]4-`: from **pH 5.1, E = 0.115 V** to **pH 7.35625, E = 0.03875 V**
- `Cu | [Cu(Glyc)2]`: from **pH 7.7625, E = 0.01625 V** to **pH 7.35625, E = 0.03875 V**

### Fe partitioning

At the central potential cut, **E = 0.250625 V**, Fe dominance changes with pH as follows:

- `Fe2+`: pH **0.003125–4.071875**
- `[Fe(Citr)]-`: pH **4.078125–4.659375**
- `[Fe2(Citr)2(OH)2]2-`: pH **4.665625–6.296875**
- `Fe(OH)3(s)`: pH **6.303125–13.771875**
- `FeO42-`: pH **13.778125–13.996875**

At **pH = 6.996875**, Fe varies with potential as:

- `Fe` metal: **E = −0.999375 to −0.576875 V**
- `[Fe(Citr)]-`: **E = −0.575625 to 0.026875 V**
- `Fe(OH)3(s)`: **E = 0.028125 to 0.919375 V**
- `FeO42-`: **E = 0.920625 V upward**

Principal Fe junctions reported by the solver include:

- `DmsRegEqJnc_1`: **pH = 4.08125, E = 0.28875 V**  
  `[Fe(Citr)]-`, `Fe2+`, `[Fe2(Citr)2(OH)2]2-`
- `DmsRegEqJnc_3`: **pH = 1.4625, E = 0.77 V**  
  `Fe2+`, `[Fe(Citr)]`, `Fe3+`
- `DmsRegEqJnc_11`: **pH = 6.36875, E = 0.155 V**  
  `[Fe(Citr)]-`, `Fe(OH)3(s)`, `[Fe2(Citr)2(OH)2]2-`
- `DmsRegEqJnc_12`: **pH = 6.3625, E = 0.975 V**  
  `Fe(OH)3(s)`, `[Fe2(Citr)2(OH)2]2-`, `FeO42-`

Electrodeposition-relevant Fe metal boundaries are much more negative than Cu:

- `Fe | Fe2+`: approximately **E ≈ −0.5375 to −0.5525 V** up to **pH 4.03125**
- `Fe | [Fe(Citr)]-`: pH **4.03125–8.0625**, approximately **E ≈ −0.5525 to −0.585 V**

### Constants explicitly reported as used

The solver’s reported constants include:

- Citrate protonation:
  - `H3Citric acid`: log β = **12.9000**
  - `H2Citric acid-`: log β = **10.0000**
  - `HCitric acid2-`: log β = **5.6500**
- Glycine protonation:
  - log β = **11.9000**
  - log β = **9.5700**
- Ammonium:
  - log β = **9.2600**
- Cu complexes:
  - `[Cu(Glyc)2]`: log β = **15.1000**
  - `[Cu(Ammo)4]2+`: log β = **12.3000**
  - `[Cu2(Citr)2(OH)]3-`: log β = **11.2000**
  - `[Cu2(Citr)2(OH)2]4-`: log β = **6.3400**
- Fe complexes:
  - `[Fe(Citr)]`: log β = **11.1900**
  - `[Fe2(Citr)2(OH)2]2-`: log β = **21.2000**

These constants explain the speciation trends: citrate and glycine strongly displace simple aqua/chloro species over much of the diagram, but hydrolysis and precipitation dominate at high pH, especially for Fe(III).

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
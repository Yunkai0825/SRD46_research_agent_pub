## Answer

The joint Cu–Fe Pourbaix calculation completed for the single mixed electrolyte: 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 °C, I = 0.1 m, over pH 0–14 and E = −1.0 to +1.5 V vs SHE.

### Overall chemical interpretation

Cu and Fe behave quite differently in this ligand-rich electrolyte.

**Copper remains comparatively easier to keep in soluble complexed form and to electrodeposit selectively.**  
At acidic pH, Cu is chloride-controlled, mainly as `[Cu(Chlo)2]-`. As pH increases, citrate and hydroxo-citrate Cu(II) complexes take over, then glycine becomes dominant in the near-neutral to mildly basic region. At still higher pH, Cu hydroxide/oxo species and solids dominate. Around pH ≈ 7, Cu metal becomes dominant below about **0.052–0.053 V vs SHE**, while soluble Cu–citrate/hydroxo complexes dominate above that potential. This gives an electrodeposition-relevant Cu reduction boundary at relatively mild potentials.

**Iron is much less easily kept dissolved under neutral oxidizing conditions.**  
Fe is Fe²⁺ in acidic solution, citrate-complexed around mildly acidic to near-neutral conditions, but **Fe(OH)₃(s)** dominates a large neutral-to-alkaline oxidizing region. Fe metal only appears at much more negative potentials, e.g. near pH ≈ 7 below about **−0.576 V vs SHE**. Thus, there is a broad potential window where Cu can plate while Fe remains dissolved, complexed, or precipitated rather than codepositing as Fe metal.

The excluded phases were honored: **Fe₂O₃, CuO, FeOOH, and Fe₃O₄** were not retained as active solids. Hydrated/hydroxide-relevant phases such as Cu(OH)₂(s), Fe(OH)₂(s), Fe(OH)₃(s), Cu metal, and Fe metal remained.

## Evidence

- The solver completed a supported **Pourbaix sweep** on a joint grid with spacing  
  **ΔpH = 0.00625** and **ΔE = 0.00125 V**.
- The verdicts reported:
  - **Cu:** 10 dominant labels in 11 connected regions.
  - **Fe:** 11 dominant labels in 11 connected regions.
- The full speciation file reported **14,917 coarse-unrefined** and **396,669 refined** samples, with a `converged` column; inspected rows had `converged = 1`.

### Cu partitioning

At the central potential cut, **E = 0.250625 V**, Cu dominance changes with pH as follows:

- `[Cu(Chlo)2]-`: pH **0.003125–3.878125**
- `[Cu2(Citr)2(OH)]3-`: pH **3.884375–4.003125**
- `[Cu2(Citr)2(OH)2]4-`: pH **4.009375–7.578125**
- `[Cu(Glyc)2]`: pH **7.584375–11.128125**
- `[Cu2(Citr)2(OH)2]4-`: pH **11.134375–11.521875**
- `Cu(OH)2(s)`: pH **11.528125–13.578125**
- `CuO22-`: pH **13.584375–13.996875**

At **pH = 6.996875**, Cu varies with potential as:

- `Cu` metal: **E = −0.999375 to 0.051875 V**
- `[Cu2(Citr)2(OH)2]4-`: **E = 0.053125 to 1.499375 V**

So the Cu metal / Cu–citrate-hydroxo transition at near-neutral pH lies at about **0.052–0.053 V vs SHE**.

Principal Cu junctions reported by the solver include:

- `DmsRegEqJnc_1`: **pH = 4.00625, E = 0.2375 V**  
  `[Cu2(Citr)2(OH)2]4-`, `[Cu(Chlo)2]-`, `[Cu2(Citr)2(OH)]3-`
- `DmsRegEqJnc_2`: **pH = 3.23125, E = 0.3425 V**  
  chloride/citrate Cu species with `Cu2+`
- `DmsRegEqJnc_12`: **pH = 5.1, E = 0.115 V**  
  `Cu`, `[Cu2(Citr)2(OH)2]4-`, `[Cu(Chlo)2]-`
- `DmsRegEqJnc_11`: **pH = 7.35625, E = 0.03875 V**  
  `Cu`, `[Cu(Glyc)2]`, `[Cu2(Citr)2(OH)2]4-`
- `DmsRegEqJnc_9`: **pH = 7.7625, E = 0.01625 V**  
  `Cu`, `[Cu(Ammo)2]+`, `[Cu(Glyc)2]`

Important Cu boundaries include:

- `Cu | [Cu(Chlo)2]-`: from **pH 0, E = 0.13 V** to **pH 5.1, E = 0.115 V**
- `Cu | [Cu2(Citr)2(OH)2]4-`: from **pH 5.1, E = 0.115 V** to **pH 7.35625, E = 0.03875 V**
- `Cu | [Cu(Glyc)2]`: from **pH 7.7625, E = 0.01625 V** to **pH 7.35625, E = 0.03875 V**

### Fe partitioning

At the central potential cut, **E = 0.250625 V**, Fe dominance changes with pH as follows:

- `Fe2+`: pH **0.003125–4.071875**
- `[Fe(Citr)]-`: pH **4.078125–4.659375**
- `[Fe2(Citr)2(OH)2]2-`: pH **4.665625–6.296875**
- `Fe(OH)3(s)`: pH **6.303125–13.771875**
- `FeO42-`: pH **13.778125–13.996875**

At **pH = 6.996875**, Fe varies with potential as:

- `Fe` metal: **E = −0.999375 to −0.576875 V**
- `[Fe(Citr)]-`: **E = −0.575625 to 0.026875 V**
- `Fe(OH)3(s)`: **E = 0.028125 to 0.919375 V**
- `FeO42-`: **E = 0.920625 V upward**

Principal Fe junctions reported by the solver include:

- `DmsRegEqJnc_1`: **pH = 4.08125, E = 0.28875 V**  
  `[Fe(Citr)]-`, `Fe2+`, `[Fe2(Citr)2(OH)2]2-`
- `DmsRegEqJnc_3`: **pH = 1.4625, E = 0.77 V**  
  `Fe2+`, `[Fe(Citr)]`, `Fe3+`
- `DmsRegEqJnc_11`: **pH = 6.36875, E = 0.155 V**  
  `[Fe(Citr)]-`, `Fe(OH)3(s)`, `[Fe2(Citr)2(OH)2]2-`
- `DmsRegEqJnc_12`: **pH = 6.3625, E = 0.975 V**  
  `Fe(OH)3(s)`, `[Fe2(Citr)2(OH)2]2-`, `FeO42-`

Electrodeposition-relevant Fe metal boundaries are much more negative than Cu:

- `Fe | Fe2+`: approximately **E ≈ −0.5375 to −0.5525 V** up to **pH 4.03125**
- `Fe | [Fe(Citr)]-`: pH **4.03125–8.0625**, approximately **E ≈ −0.5525 to −0.585 V**

### Constants explicitly reported as used

The solver’s reported constants include:

- Citrate protonation:
  - `H3Citric acid`: log β = **12.9000**
  - `H2Citric acid-`: log β = **10.0000**
  - `HCitric acid2-`: log β = **5.6500**
- Glycine protonation:
  - log β = **11.9000**
  - log β = **9.5700**
- Ammonium:
  - log β = **9.2600**
- Cu complexes:
  - `[Cu(Glyc)2]`: log β = **15.1000**
  - `[Cu(Ammo)4]2+`: log β = **12.3000**
  - `[Cu2(Citr)2(OH)]3-`: log β = **11.2000**
  - `[Cu2(Citr)2(OH)2]4-`: log β = **6.3400**
- Fe complexes:
  - `[Fe(Citr)]`: log β = **11.1900**
  - `[Fe2(Citr)2(OH)2]2-`: log β = **21.2000**

These constants explain the speciation trends: citrate and glycine strongly displace simple aqua/chloro species over much of the diagram, but hydrolysis and precipitation dominate at high pH, especially for Fe(III).

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
# Solver report (Pourbaix)

## System
- Components: [Ag, Cu, Chloride ion]
- Constraints:
  -- component totals (M): Ag=1e-06;Cu=1e-06;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-0.8V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.011111111, ΔE_V=0.0011111111V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO22-
- Dms_4: HCuO2-
- Dms_5: CuO(s)
- Dms_6: [Cu(Chlo)2]-
- Dms_7: Cu2+

## Topology stats
- 7 dominant-species labels
- 7 connected regions
- 11 pairwise boundary curves
- 5 internal junction features
- 7 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2V)
- Fixed sample indices: (pH=swept, E_V=sample 900)
- samples 0–747, (pH=[0, 8.3], E_V=0.2V): [Cu(Chlo)2]- (Dms_6)
- samples 748–1136, (pH=[8.3111111, 12.622222], E_V=0.2V): CuO(s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[8.3, 8.3111111], E_V=0.2V)
- samples 1137–1182, (pH=[12.633333, 13.133333], E_V=0.2V): HCuO2- (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[12.622222, 12.633333], E_V=0.2V)
- samples 1183–1260, (pH=[13.144444, 14], E_V=0.2V): CuO22- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[13.133333, 13.144444], E_V=0.2V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 630, E_V=swept)
- samples 0–669, (pH=7, E_V=[-0.8V, -0.056666667V]): Cu (Dms_1)
- samples 670–1039, (pH=7, E_V=[-0.055555556V, 0.35444444V]): [Cu(Chlo)2]- (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.056666667V, -0.055555556V])
- samples 1040–1800, (pH=7, E_V=[0.35555556V, 1.2V]): Cu2+ (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.35444444V, 0.35555556V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 9.7024691
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_10
    --- DmsReg_6 {[Cu(Chlo)2]-} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12, DmsRegEqJnc_5]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.75106173
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_10
    --- DmsReg_4 {CuO22-} via DmsRegEq_4
    --- DmsReg_5 {HCuO2-} via DmsRegEq_5
    --- DmsReg_3 {CuO(s)} via DmsRegEq_11
    --- DmsReg_6 {[Cu(Chlo)2]-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12, DmsRegEqJnc_6, DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_11]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 6.2232099
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_11
    --- DmsReg_5 {HCuO2-} via DmsRegEq_8
    --- DmsReg_6 {[Cu(Chlo)2]-} via DmsRegEq_6
    --- DmsReg_7 {Cu2+} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11, DmsRegEqJnc_7, DmsRegEqJnc_4, DmsRegEqJnc_8]
#### liquid
- **DmsReg_4 {CuO22-}**
  -- Measure in the solver coordinate frame: 1.2476173
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_4
    --- DmsReg_5 {HCuO2-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_3, DmsRegEqJnc_1]
- **DmsReg_5 {HCuO2-}**
  -- Measure in the solver coordinate frame: 0.68239506
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_5
    --- DmsReg_4 {CuO22-} via DmsRegEq_2
    --- DmsReg_3 {CuO(s)} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_7]
- **DmsReg_6 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 3.4788642
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_3
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_7
    --- DmsReg_3 {CuO(s)} via DmsRegEq_6
    --- DmsReg_7 {Cu2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_5, DmsRegEqJnc_11, DmsRegEqJnc_4, DmsRegEqJnc_2]
- **DmsReg_7 {Cu2+}**
  -- Measure in the solver coordinate frame: 5.9521728
  -- Neighboring regions:
    --- DmsReg_3 {CuO(s)} via DmsRegEq_9
    --- DmsReg_6 {[Cu(Chlo)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_8, DmsRegEqJnc_2]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.355V), (pH=7.17222, E_V=0.355V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 647, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 646], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.355V), (pH=7.17222, E_V=0.355V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.355V), (pH=7.17222, E_V=0.355V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_2: CuO22- | HCuO2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.13889, E_V=-0.17056V), (pH=13.13889, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1235, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1234], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.13889, E_V=-0.17056V), (pH=13.13889, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.13889, E_V=-0.17056V), (pH=13.13889, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_3: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.05611V), (pH=9.05, E_V=-0.05611V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 816, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 815], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.05611V), (pH=9.05, E_V=-0.05611V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.05611V), (pH=9.05, E_V=-0.05611V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: [(Cu2O)0.5](s) | CuO22-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.30944V), (pH=13.61667, E_V=-0.24389V), (pH=13.13889, E_V=-0.17056V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 204, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 94, 203], "t_params": [0.0, 0.44585, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.30944V), (pH=13.61667, E_V=-0.24389V), (pH=13.13889, E_V=-0.17056V)], "envelope_t": [0.0, 0.44585, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=14, E_V=-0.30944V), (pH=13.61667, E_V=-0.24389V), (pH=13.13889, E_V=-0.17056V)], "adaptive_t": [0.0, 0.44585, 1.0]}
- **DmsRegEq_5: [(Cu2O)0.5](s) | HCuO2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.13889, E_V=-0.17056V), (pH=12.62778, E_V=-0.09944V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 111, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 110], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.13889, E_V=-0.17056V), (pH=12.62778, E_V=-0.09944V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.13889, E_V=-0.17056V), (pH=12.62778, E_V=-0.09944V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: CuO(s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.05, E_V=0.11167V), (pH=7.57222, E_V=0.28833V), (pH=7.32778, E_V=0.32278V), (pH=7.17222, E_V=0.355V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 389, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 292, 345, 388], "t_params": [0.0, 0.78579, 0.91613, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.05, E_V=0.11167V), (pH=7.57222, E_V=0.28833V), (pH=7.32778, E_V=0.32278V), (pH=7.17222, E_V=0.355V)], "envelope_t": [0.0, 0.78579, 0.91613, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=9.05, E_V=0.11167V), (pH=7.57222, E_V=0.28833V), (pH=7.32778, E_V=0.32278V), (pH=7.17222, E_V=0.355V)], "adaptive_t": [0.0, 0.78579, 0.91613, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_7: [(Cu2O)0.5](s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.05, E_V=-0.05611V), (pH=9.05, E_V=0.11167V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 152, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 151], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.05, E_V=-0.05611V), (pH=9.05, E_V=0.11167V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.05, E_V=-0.05611V), (pH=9.05, E_V=0.11167V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: HCuO2- | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.62778, E_V=-0.09944V), (pH=12.62778, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1171, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1170], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.62778, E_V=-0.09944V), (pH=12.62778, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.62778, E_V=-0.09944V), (pH=12.62778, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: CuO(s) | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.17222, E_V=0.355V), (pH=7.08333, E_V=0.38278V), (pH=7.03889, E_V=0.42611V), (pH=7.02778, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 775, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 33, 76, 774], "t_params": [0.0, 0.10023, 0.16703, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.17222, E_V=0.355V), (pH=7.08333, E_V=0.38278V), (pH=7.03889, E_V=0.42611V), (pH=7.02778, E_V=1.2V)], "envelope_t": [0.0, 0.10023, 0.16703, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.17222, E_V=0.355V), (pH=7.08333, E_V=0.38278V), (pH=7.03889, E_V=0.42611V), (pH=7.02778, E_V=1.2V)], "adaptive_t": [0.0, 0.10023, 0.16703, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_10: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.34944V), (pH=9.05, E_V=-0.05611V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 711, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 710], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.34944V), (pH=9.05, E_V=-0.05611V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.34944V), (pH=9.05, E_V=-0.05611V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.62778, E_V=-0.09944V), (pH=9.05, E_V=0.11167V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 513, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 512], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.62778, E_V=-0.09944V), (pH=9.05, E_V=0.11167V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.62778, E_V=-0.09944V), (pH=9.05, E_V=0.11167V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO22-, HCuO2-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=13.13889, E_V=1.2V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.355V)
#### one solid
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-, HCuO2-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.13889, E_V=-0.17056V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_6, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.17222, E_V=0.355V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.05611V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.30944V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [HCuO2-, CuO(s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=12.62778, E_V=1.2V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), Cu2+]
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.02778, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), HCuO2-, CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_8, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=12.62778, E_V=-0.09944V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_7, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.05, E_V=-0.05611V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6, DmsRegEq_7, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.05, E_V=0.11167V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.34944V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ag**
  -- included: [Ag+, [Ag(OH)], [Ag(OH)2]-, [Ag(Chlo)4]3-, [Ag(Chlo)3]2-, [Ag(Chlo)2]-, [Ag(Chlo)], [(Ag2O)0.5](s), [Ag(Chloride ion)](s), Ag]
  -- excluded: [AgO-, Ag2O]
- **Cu**
  -- included: [Cu+, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]

# Solver report (Pourbaix)

## System
- Components: [Ag, Cu, Chloride ion]
- Constraints:
  -- component totals (M): Ag=1e-06;Cu=1e-06;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-0.8V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.011111111, ΔE_V=0.0011111111V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ag
- Dms_2: [Ag(OH)2]-
- Dms_3: [Ag(Chlo)2]-

## Topology stats
- 3 dominant-species labels
- 3 connected regions
- 3 pairwise boundary curves
- 1 internal junction features
- 3 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2V)
- Fixed sample indices: (pH=swept, E_V=sample 900)
- samples 0–1247, (pH=[0, 13.855556], E_V=0.2V): Ag (Dms_1)
- samples 1248–1260, (pH=[13.866667, 14], E_V=0.2V): [Ag(OH)2]- (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[13.855556, 13.866667], E_V=0.2V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 630, E_V=swept)
- samples 0–934, (pH=7, E_V=[-0.8V, 0.23777778V]): Ag (Dms_1)
- samples 935–1800, (pH=7, E_V=[0.23888889V, 1.2V]): [Ag(Chlo)2]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.23777778V, 0.23888889V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ag}**
  -- Measure in the solver coordinate frame: 14.537519
  -- Neighboring regions:
    --- DmsReg_2 {[Ag(OH)2]-} via DmsRegEq_2
    --- DmsReg_3 {[Ag(Chlo)2]-} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2, DmsRegEqJnc_4]
#### liquid
- **DmsReg_2 {[Ag(OH)2]-}**
  -- Measure in the solver coordinate frame: 0.453
  -- Neighboring regions:
    --- DmsReg_1 {Ag} via DmsRegEq_2
    --- DmsReg_3 {[Ag(Chlo)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_3 {[Ag(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 13.047272
  -- Neighboring regions:
    --- DmsReg_1 {Ag} via DmsRegEq_3
    --- DmsReg_2 {[Ag(OH)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_2, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ag(OH)2]- | [Ag(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.55, E_V=0.22278V), (pH=13.55, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 881, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 880], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.55, E_V=0.22278V), (pH=13.55, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.55, E_V=0.22278V), (pH=13.55, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Ag | [Ag(OH)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.18611V), (pH=13.76111, E_V=0.20944V), (pH=13.55, E_V=0.22278V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 75, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 43, 74], "t_params": [0.0, 0.53155, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.18611V), (pH=13.76111, E_V=0.20944V), (pH=13.55, E_V=0.22278V)], "envelope_t": [0.0, 0.53155, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=14, E_V=0.18611V), (pH=13.76111, E_V=0.20944V), (pH=13.55, E_V=0.22278V)], "adaptive_t": [0.0, 0.53155, 1.0]}
- **DmsRegEq_3: Ag | [Ag(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.55, E_V=0.22278V), (pH=13.30556, E_V=0.23278V), (pH=12.78333, E_V=0.23833V), (pH=0, E_V=0.23833V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00098, "resolution_tau_norm": 0.00098, "stop_epsilon": 0.00098, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1235, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 31, 83, 1234], "t_params": [0.0, 0.01805, 0.0566, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.55, E_V=0.22278V), (pH=13.30556, E_V=0.23278V), (pH=12.78333, E_V=0.23833V), (pH=0, E_V=0.23833V)], "envelope_t": [0.0, 0.01805, 0.0566, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=13.55, E_V=0.22278V), (pH=13.30556, E_V=0.23278V), (pH=12.78333, E_V=0.23833V), (pH=0, E_V=0.23833V)], "adaptive_t": [0.0, 0.01805, 0.0566, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ag(OH)2]-, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=13.55, E_V=1.2V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(OH)2]-, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_3]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.55, E_V=0.22278V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(OH)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.18611V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.23833V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ag**
  -- included: [Ag+, [Ag(OH)], [Ag(OH)2]-, [Ag(Chlo)4]3-, [Ag(Chlo)3]2-, [Ag(Chlo)2]-, [Ag(Chlo)], [(Ag2O)0.5](s), [Ag(Chloride ion)](s), Ag]
  -- excluded: [AgO-, Ag2O]
- **Cu**
  -- included: [Cu+, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]

## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute Pourbaix diagrams for copper and silver in a chloride-bearing aqueous system at 25 C, with the goal of comparing how readily each metal reaches the zero-valent metallic state under mildly acidic and weakly oxidising conditions. The calculation should also expose the equilibrium constants actually used for the Cu/Ag/chloride/redox/hydrolysis/solid reactions so they can be cited in the final answer.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 11,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Ag_+_Cu_+_Chloride_ion_Ag.csv",
      "L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Ag.png",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag.json",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag_verdict.md",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag_verdict.json",
      "L1_call_01/solver/pourbaix_map_Ag_+_Cu_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/speciation_full_Ag_+_Cu_+_Chloride_ion.csv"
    ],
    "elapsed_s": 22531.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute Pourbaix diagrams for copper and silver in a chloride-bearing aqueous system at 25 C, with the goal of comparing how readily each metal reaches the zero-valent metallic state under mildly acidic and weakly oxidising conditions. The calculation should also expose the equilibrium constants actually used for the Cu/Ag/chloride/redox/hydrolysis/solid reactions so they can be cited in the final answer.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag_verdict.md",
      "L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Ag.png",
      "L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/speciation_full_Ag_+_Cu_+_Chloride_ion.csv",
      "L1_call_01/solver/sweep_log.txt"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For Cu and Ag in 0.1 M chloride at 25 C, compute Pourbaix diagrams and explain which metal is more easily reduced to the zero-valent state under mildly acidic, weakly oxidising conditions. Reference the equilibrium constants the solver actually used.

## Assistant
<summary>I will run one joint Pourbaix calculation for a shared chloride solution containing both Cu and Ag, so chloride complexation is handled consistently. I’ll then inspect the generated artifacts for predominance regions, convergence, and the equilibrium constants actually used.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: Cu, Ag, and chloride are catalogued, the requested method is the supported `pourbaix_sweep`, and the stated 25 °C condition matches the solver run; no pressure/temperature extrapolation was needed.

## Result
Computed one shared aqueous Cu–Ag–chloride Pourbaix system at 25 °C with component totals Ag=1e-06 M, Cu=1e-06 M, and chloride=0.1 M. Potential is vs SHE over pH 0–14 and E=-0.8 to 1.2 V. The solver used a 201×141 coarse grid, two 3× boundary refinements, and final classified-grid spacing ΔpH=0.011111111 and ΔE=0.0011111111 V. The full-speciation CSV contains 26,389 coarse-unrefined and 132,610 refined rows with per-row `converged`, `iterations`, `residual`, `phase_search_timed_out`, and label fields; inspected rows were converged with zero residual and no timeout. Topology verdicts are available for both Ag and Cu.

## Analysis
Key constants actually used are in `thermodynamic_reference_constants.md`: Ag chloride cumulative log_beta values include AgCl(aq) +3.0800, AgCl2- +5.0800, AgCl3^2- +5.2000, AgCl4^3- +5.3200; Cu(I) chloride values include CuCl(aq) +3.1000, CuCl2- +5.4200, CuCl3^2- +4.7500, while Cu(II) chloride CuCl+ is only +0.2000. Included solids/metals include Ag, Cu, AgCl(s) log_beta +9.4200, CuCl(s) +6.7300, Cu2O-form row +0.7000, CuO(s) -7.6500, and Ag2O-form row -6.2900 under the card’s stoichiometric convention.

Feature roster used: Ag DmsReg_1 is Ag(s), bounded by DmsRegEqJnc_4 at (pH=0, E=0.23833 V), DmsRegEqJnc_2 at (13.55, 0.22278 V), and DmsRegEqJnc_3 at (14, 0.18611 V). Ag DmsRegEq_3 separates Ag(s) from AgCl2- over approximately pH 0–13.55 at E≈0.238–0.223 V; DmsRegEq_2 separates Ag(s) from Ag(OH)2- at very alkaline pH. Cu DmsReg_1 is Cu(s), bounded by DmsRegEqJnc_5 (pH=0, E=-0.05611 V), DmsRegEqJnc_10 (9.05, -0.05611 V), and DmsRegEqJnc_12 (14, -0.34944 V). Cu DmsRegEq_3 separates Cu(s) from CuCl2- at E=-0.05611 V from pH 0 to 9.05; DmsRegEq_10 separates Cu(s) from Cu2O-form solid at higher pH.

In the mildly acidic chloride region, Ag is much easier to reduce to, and retain as, the zero-valent metal. At pH=7 on the classified-grid E cut, Ag(s) dominates from E=-0.8 to 0.23777778 V, then AgCl2- dominates from 0.23888889 to 1.2 V. By contrast, Cu(s) at pH=7 dominates only from E=-0.8 to -0.056666667 V; CuCl2- dominates from -0.055555556 to 0.35444444 V, and Cu2+ at still higher E. Thus near weakly oxidising potentials around 0 V vs SHE and mildly acidic/near-neutral pH, Ag is already in its metallic field whereas Cu remains as the Cu(I) chloride complex.

Chemically, chloride complexation stabilises dissolved monovalent species for both metals, but the redox boundary for Ag/AgCl2- remains about 0.294 V more positive than the Cu/CuCl2- boundary at pH 7. That means Ag(I)-chloride is thermodynamically reduced to Ag metal under substantially less reducing conditions. Copper requires a more negative potential to overcome the stability of Cu(I) chloride; at higher pH, hydrolysis/oxide chemistry further diverts Cu into CuO(s), Cu2O-form solid, HCuO2-, and CuO2^2- fields rather than directly to Cu metal. Silver’s map is simpler: Ag(s), AgCl2-, and at extreme alkalinity Ag(OH)2-; the Ag metal field extends through most of the acidic-to-neutral window below about +0.238 V.

## Artifacts
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag_verdict.md`
- `L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Ag.png`
- `L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/speciation_full_Ag_+_Cu_+_Chloride_ion.csv`
- `L1_call_01/solver/sweep_log.txt`

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

Silver is more easily reduced to the zero-valent metal than copper in 0.1 M chloride at 25 °C.

In the computed Cu–Ag–chloride Pourbaix system, the Ag(s) stability field extends to much more oxidising potentials than the Cu(s) field. Around mildly acidic to near-neutral pH, Ag remains metallic up to about **+0.238 V vs SHE**, whereas Cu remains metallic only below about **−0.056 V vs SHE**. Therefore, under weakly oxidising conditions near **0 V vs SHE**, silver is predicted to be in the **Ag(s)** field, while copper is still stabilised as dissolved **Cu(I) chloride**, mainly **CuCl₂⁻**.

Chemically, chloride stabilises dissolved monovalent complexes for both metals, but it does not suppress Ag reduction as strongly as it suppresses Cu reduction. The Ag/AgCl₂⁻ boundary lies roughly **0.29 V more positive** than the Cu/CuCl₂⁻ boundary near neutral pH, so Ag(I) chloride complexes are reduced to metal under substantially less reducing conditions. Copper requires a more negative potential because Cu(I) chloride complexes remain thermodynamically stable over the weakly oxidising range.

## Evidence

- The joint calculation used **Ag = 1e-6 M**, **Cu = 1e-6 M**, and **chloride = 0.1 M** at **25 °C**, over **pH 0–14** and **E = −0.8 to 1.2 V vs SHE**.
- At **pH = 7**, the classified grid shows:
  - **Ag(s)** dominates from **E = −0.8 to 0.23777778 V**, then **AgCl₂⁻** dominates from **0.23888889 to 1.2 V**.
  - **Cu(s)** dominates only from **E = −0.8 to −0.056666667 V**; **CuCl₂⁻** dominates from **−0.055555556 to 0.35444444 V**.
- Key equilibrium constants used by the solver include:
  - Silver chloride complexes: **AgCl(aq) logβ = +3.0800**, **AgCl₂⁻ logβ = +5.0800**, **AgCl₃²⁻ logβ = +5.2000**, **AgCl₄³⁻ logβ = +5.3200**.
  - Copper(I) chloride complexes: **CuCl(aq) logβ = +3.1000**, **CuCl₂⁻ logβ = +5.4200**, **CuCl₃²⁻ logβ = +4.7500**.
  - Copper(II) chloride: **CuCl⁺ logβ = +0.2000**.
  - Included solid/metal phases: **Ag(s)**, **Cu(s)**, **AgCl(s) logβ = +9.4200**, **CuCl(s) logβ = +6.7300**, **Cu₂O-form row logβ = +0.7000**, **CuO(s) logβ = −7.6500**, and **Ag₂O-form row logβ = −6.2900** under the card’s stoichiometric convention.
- The solver reported converged inspected rows with **zero residual** and **no phase-search timeout**.

## Artifacts

- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Ag.png`
- `L1_call_01/solver/pourbaix_Ag_+_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Ag_verdict.md`
- `L1_call_01/solver/topology_Ag_+_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/speciation_full_Ag_+_Cu_+_Chloride_ion.csv`
- `L1_call_01/solver/sweep_log.txt`
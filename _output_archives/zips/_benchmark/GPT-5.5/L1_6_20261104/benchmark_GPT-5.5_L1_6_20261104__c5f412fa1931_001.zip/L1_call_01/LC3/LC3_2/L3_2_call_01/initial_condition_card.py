inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 C."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M chloride analytical component."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-6, "basis": "assumed", "note": "Dilute analytical copper inventory chosen for Pourbaix predominance comparison without forcing precipitation by bulk loading."},
  {"id": "Ag", "lhs": lambda s: s.total["Ag"], "value": 1e-6, "basis": "assumed", "note": "Equal dilute silver inventory chosen to compare Cu and Ag zero-valent predominance on the same basis."},
]
# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 7.54
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (number of axes): 2

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 0.0,
    "max": 14.0,
    "n_points": 141
  },
  {
    "name": "E_V",
    "min": -0.8,
    "max": 1.2,
    "n_points": 201
  }
]
```

## refinement_design: `{'mode': 'boundary', 'factor': 3, 'n_layers': 2}`

## Grid: 28341 cell(s) across 2 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.30
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH–E Pourbaix predominance diagrams for Cu/Ag in chloride solution.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
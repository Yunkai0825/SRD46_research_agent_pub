# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 C.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M chloride analytical component.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 1e-06, "basis": "assumed"},  # Dilute analytical copper inventory chosen for Pourbaix predominance comparison without forcing precipitation by bulk loading.
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 1e-06, "basis": "assumed"},  # Equal dilute silver inventory chosen to compare Cu and Ag zero-valent predominance on the same basis.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix diagram pH coordinate; must be swept by L3_3.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix diagram redox-potential coordinate; must be swept by L3_3.'},
]

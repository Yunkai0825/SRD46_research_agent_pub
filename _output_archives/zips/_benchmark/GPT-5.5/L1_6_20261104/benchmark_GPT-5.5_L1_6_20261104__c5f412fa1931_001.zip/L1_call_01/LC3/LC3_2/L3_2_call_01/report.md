# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 37.62
- llm_iterations: 2
- llm_tool_calls: 2
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (2 known, 2 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 C.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M chloride analytical component.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 1e-06, "basis": "assumed"},  # Dilute analytical copper inventory chosen for Pourbaix predominance comparison without forcing precipitation by bulk loading.
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 1e-06, "basis": "assumed"},  # Equal dilute silver inventory chosen to compare Cu and Ag zero-valent predominance on the same basis.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix diagram pH coordinate; must be swept by L3_3.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix diagram redox-potential coordinate; must be swept by L3_3.'},
]

```

## Notes
Task-stated inputs: 25 C and 0.1 M chloride. pH and E_V are the Pourbaix map coordinates and are deferred to L3_3 as swept axes. Cu and Ag totals are not specified by the task, so equal dilute 1e-6 M analytical element totals are assumed for comparable predominance diagrams. Ionic strength is not pinned; it is declared through ionic_strength_mode=auto so the solver computes it self-consistently from pointwise speciation.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "auto"
}
```
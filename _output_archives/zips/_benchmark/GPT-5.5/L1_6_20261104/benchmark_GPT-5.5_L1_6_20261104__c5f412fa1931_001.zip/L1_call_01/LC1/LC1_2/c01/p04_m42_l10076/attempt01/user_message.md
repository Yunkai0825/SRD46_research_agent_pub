[Purpose: Compute Pourbaix diagrams for copper and silver in a chloride-bearing aqueous system at 25 C, with the goal of comparing how readily each metal reaches the zero-valent metallic state under mildly acidic and weakly oxidising conditions. The calculation should also expose the equilibrium constants actually used for the Cu/Ag/chloride/redox/hydrolysis/solid reactions so they can be cited in the final answer.]
[Tasks:
Model one shared aqueous solution at 25 C containing Cu and Ag in 0.1 M chloride, and generate Pourbaix predominance diagrams for both metals over a useful pH–redox range that includes mildly acidic, weakly oxidising conditions. Treat chloride as a fixed analytical component at 0.1 M, include available aqueous chloride complexes, hydrolysis species, relevant solids, and zero-valent Cu(s) and Ag(s), and report which metal is thermodynamically more easily reduced to the zero-valent state in that mildly acidic, weakly oxidising region. Please include or preserve the equilibrium constants and reaction definitions actually used by the solver, and provide topology/predominance summaries plus convergence evidence.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

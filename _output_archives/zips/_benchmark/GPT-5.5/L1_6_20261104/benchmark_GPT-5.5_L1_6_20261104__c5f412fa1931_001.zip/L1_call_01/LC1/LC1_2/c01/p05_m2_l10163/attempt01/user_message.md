[Purpose: Compute Pourbaix diagrams for copper and silver in a chloride-bearing aqueous system at 25 C, with the goal of comparing how readily each metal reaches the zero-valent metallic state under mildly acidic and weakly oxidising conditions. The calculation should also expose the equilibrium constants actually used for the Cu/Ag/chloride/redox/hydrolysis/solid reactions so they can be cited in the final answer.]
[Tasks:
Model one shared aqueous solution at 25 C containing Cu and Ag in 0.1 M chloride, and generate Pourbaix predominance diagrams for both metals over a useful pH–redox range that includes mildly acidic, weakly oxidising conditions. Treat chloride as a fixed analytical component at 0.1 M, include available aqueous chloride complexes, hydrolysis species, relevant solids, and zero-valent Cu(s) and Ag(s), and report which metal is thermodynamically more easily reduced to the zero-valent state in that mildly acidic, weakly oxidising region. Please include or preserve the equilibrium constants and reaction definitions actually used by the solver, and provide topology/predominance summaries plus convergence evidence.
]
[Pair: pair_key=`m2_l10163`, metal_id=2, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal2_ligand10163_beta872_net29811`
  - `metal2_ligand10163_beta894_net29811`
  - `metal2_ligand10163_beta840_net29811`
[Screen report]
# Eq-map screen — m2_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal2_ligand10163_beta872_net29811` | `[M] + [L]^3 <=> [ML3]` | vlm_177443@(20.0,4.0) = K+6.000 | 3 | +5.200 / +6.000 / +5.783 / +6.150 | vlm_177445@(25.0,0.0) = K+5.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal2_ligand10163_beta894_net29811` | `[M] + [L]^4 <=> [ML4]` | vlm_177448@(20.0,4.0) = K+6.040 | 2 | +5.320 / +5.680 / +5.680 / +6.040 | vlm_177448@(20.0,4.0) = K+6.040 (-5.00 °C, +3.90 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal2_ligand10163_beta311_net29811` | `[ML(s)] <=> [M] + [L]` | vlm_177453@(20.0,4.0) = K-10.400 | 6 | -10.400 / -9.925 / -9.867 / -9.381 | vlm_177452@(25.0,0.1) = K-9.420 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal2_ligand10163_beta812_net29811` | `[M] + [L] <=> [ML]` | vlm_177431@(20.0,4.0) = K+3.450 | 5 | +3.080 / +3.360 / +3.380 / +3.700 | vlm_177429@(25.0,0.1) = K+3.080 (+0.00 °C, +0.00 M) | `—` |
| 5 | `metal2_ligand10163_beta840_net29811` | `[M] + [L]^2 <=> [ML2]` | vlm_177438@(20.0,4.0) = K+5.670 | 5 | +5.080 / +5.250 / +5.364 / +5.670 | vlm_177436@(25.0,0.1) = K+5.080 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

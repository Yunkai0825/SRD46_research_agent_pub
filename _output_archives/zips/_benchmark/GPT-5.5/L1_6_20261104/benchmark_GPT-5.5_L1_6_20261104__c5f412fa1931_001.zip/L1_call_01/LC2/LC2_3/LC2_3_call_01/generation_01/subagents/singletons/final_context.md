## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a thermodynamic Pourbaix predominance/stability calculation at 25 C for Cu and Ag in one aqueous phase with fixed analytical chloride of 0.1 M; the mildly acidic, weakly oxidising region motivates retaining chloride complexes and zero-valent metals, not using a chloride-free corrosion simplification.
- For duplicate aqueous identity, prefer the internally cited SRD-46 representation over Atlas when they describe the same ion or the same hydrated notation at fixed water activity; keep different ligand stoichiometries, oxidation states, charges, and nuclearities because they can occupy different predominance regions.
- Use water activity effectively unity at 25 C. Hydrate/oxide spellings with the same metal redox state and same pH/E dependence should be collapsed to the thermodynamically preferred representative for a stable-phase Pourbaix diagram; do not retain multiple hydration notations merely to show formation alternatives.
- Chloride-bearing aqueous complexes and chloride precipitates are in scope because chloride is the fixed ligand component; carbonate and unrelated counterion solids are out of scope if present.
- Mixed-valence or non-stoichiometric oxide alternatives would be retained only if they are redox-distinct stable-chain members; none are implied by mere duplicate spelling here.
- The phase question is which phase is stable on the hull, so collapse polymorph/provenance duplicates and same-stoichiometry notation duplicates; where one source is needed for citable equilibrium constants, prefer SRD-46 unless that would remove an elemental reference.
- Elemental Ag(s) and Cu(s) must stay as zero-valent reference/target states. No gases in this inventory have an imposed fugacity constraint, so no decorative gas retention rule is needed.
- Apply the same chloride-solution stability logic to both elements, but handle Cu separately for its Cu(I)/Cu(II), polynuclear hydrolysis, and oxide/hydroxide alternatives; Ag mainly needs collapse of Ag(I) notation duplicates while retaining AgCl(s) and chloride complexes.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: For Ag, collapse exact Ag+ provenance duplicates to the SRD-46 ion, collapse Ag(I) dihydroxo/oxo aqueous notation duplicates to the SRD-46 [Ag(OH)2]- representative at fixed water activity, and collapse Ag2O solid notation duplicates to the SRD-46 half-formula entry. Keep AgCl(s), all distinct Ag chloride complexes, AgOH(aq), and Ag(s) because these are in-scope chloride/hydrolysis/metal states.
- Cu: For Cu, collapse Cu+ and Cu2+ provenance duplicates to the SRD-46 ions, keep distinct Cu(I)/Cu(II) chloride complexes and hydrolysis species including polynuclear hydrolysis, and do not merge different oxidation states. Collapse Cu2O, CuO, and Cu(OH)2 duplicate/provenance or hydration variants to the stable SRD-46 representative for each same-stoichiometry solid family at water activity near one; keep CuCl(s), basic copper chloride solid, high-alkaline cuprate species if otherwise unique, and Cu(s).

[Singletons: n=20]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ag | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +0 | 68.492 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | +0 | -17.580 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -1 | -28.995 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -2 | -29.680 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -3 | -30.365 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Chlo)2]-` | SRD-46 | -1 | -30.936 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -27.111 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 13.628 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Ag | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | +0 | -77.111 |
| Ag | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | +0 | -53.767 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |

## Assistant
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## LLM Response
All 20 singleton entries are retained. They are in-scope for the chloride-containing Cu/Ag Pourbaix calculation, and none is a within-group duplicate requiring removal.

| phase | core_label | keep | rationale |
|---|---:|:---:|---|
| aqueous | `(empty)` | true | Retained as a singleton aqueous reference/background entry with no duplicate alternative provided. |
| aqueous | `Ag$+1:1 H:-1` | true | AgOH(aq) is an explicitly retained Ag(I) hydrolysis species. |
| aqueous | `Ag$+1:1 L1:1` | true | The neutral Ag(I) chloride complex is distinct and in scope at fixed chloride. |
| aqueous | `Ag$+1:1 L1:2` | true | The dichloro Ag(I) complex has distinct ligand stoichiometry and charge. |
| aqueous | `Ag$+1:1 L1:3` | true | The trichloro Ag(I) complex is a distinct chloride species. |
| aqueous | `Ag$+1:1 L1:4` | true | The tetrachloro Ag(I) complex is distinct and retained for chloride predominance. |
| aqueous | `Cu$+1:1 L1:1` | true | The neutral Cu(I) chloride complex is distinct and in scope. |
| aqueous | `Cu$+1:1 L1:2` | true | The dichloro Cu(I) complex has distinct stoichiometry and charge. |
| aqueous | `Cu$+1:1 L1:3` | true | The trichloro Cu(I) complex is distinct and retained. |
| aqueous | `Cu$+2:1 H:-2` | true | Cu(OH)₂(aq) is a distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | true | HCuO₂⁻ is a unique high-alkaline Cu(II) hydrolysis/cuprate species. |
| aqueous | `Cu$+2:1 H:-4` | true | CuO₂²⁻ is a distinct high-alkaline Cu(II) cuprate species. |
| aqueous | `Cu$+2:1 L1:1` | true | The Cu(II) monochloro complex is distinct from Cu(I) chloride complexes. |
| aqueous | `Cu$+2:3 H:-4` | true | Polynuclear Cu(II) hydrolysis species are explicitly retained. |
| aqueous | `L1:1` | true | Chloride ion is the fixed ligand component and must remain in scope. |
| solid | `Ag$+0:1` | true | Elemental Ag(s) is a required zero-valent reference/target state. |
| solid | `Ag$+1:1 L1:1` | true | AgCl(s) is an in-scope chloride precipitate. |
| solid | `Cu$+0:1` | true | Elemental Cu(s) is a required zero-valent reference/target state. |
| solid | `Cu$+1:1 L1:1` | true | CuCl(s) is an in-scope copper chloride precipitate. |
| solid | `Cu$+2:2 L1:1 H:-3` | true | The basic copper chloride solid is explicitly retained as an in-scope chloride solid. |
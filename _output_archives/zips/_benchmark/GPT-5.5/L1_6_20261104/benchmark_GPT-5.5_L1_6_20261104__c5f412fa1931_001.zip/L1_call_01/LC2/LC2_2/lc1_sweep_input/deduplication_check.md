# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ag$+1 | M3 | [Ag]+ | Ag | 1 |
| Cu$+1 | M2 | [Cu]+ | Cu | 1 |
| Cu$+2 | M1 | [Cu]2+ | Cu | 2 |
| Ag$+0 | Ag$+0 | Ag(s) | Ag | 0 |
| Cu$+0 | Cu$+0 | Cu(s) | Cu | 0 |

**Total species**: 38 | **Core groups**: 28 | **Multi-member groups**: 8 | **Cross-source groups**: 7

## 1. Aqueous / Dissolved Species

20 core groups, 25 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Ag$+1:1` | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Ag$+1:1` | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Ag$+1:1 H:-1` | [Ag(OH)] | SRD-46 | +0 | 1x | +68.492 | 0 | — | *** |
| 5 | `Ag$+1:1 H:-2` | [Ag(OH)2]- | SRD-46 | -1 | 1x | +137.042 | 0 | ref | *** |
| 6 | `Ag$+1:1 H:-2` | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | +22.620 | — |
| 7 | `Ag$+1:1 L1:1` | [Ag(Chlo)] | SRD-46 | +0 | 1x | -17.580 | 0 | — | *** |
| 8 | `Ag$+1:1 L1:2` | [Ag(Chlo)2]- | SRD-46 | -1 | 1x | -28.995 | 0 | — | *** |
| 9 | `Ag$+1:1 L1:3` | [Ag(Chlo)3]2- | SRD-46 | -2 | 1x | -29.680 | 0 | — | *** |
| 10 | `Ag$+1:1 L1:4` | [Ag(Chlo)4]3- | SRD-46 | -3 | 1x | -30.365 | 0 | — | *** |
| 11 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 12 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 13 | `Cu$+1:1 L1:1` | [Cu(Chlo)] | SRD-46 | +0 | 1x | -17.694 | 0 | — | *** |
| 14 | `Cu$+1:1 L1:2` | [Cu(Chlo)2]- | SRD-46 | -1 | 1x | -30.936 | 0 | — | *** |
| 15 | `Cu$+1:1 L1:3` | [Cu(Chlo)3]2- | SRD-46 | -2 | 1x | -27.111 | 0 | — | *** |
| 16 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 17 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 18 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 19 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 20 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 21 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 22 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 23 | `Cu$+2:1 L1:1` | [Cu(Chlo)]+ | SRD-46 | +1 | 1x | +13.628 | -1 | — | *** |
| 24 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 25 | `L1:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Ag$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Argentous ion, colourless; DGf=+77.111 |
| 2 | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Ag$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Ag+ vs [Ag]+) = 0.000 kJ/mol

#### 1.2  Core: `Ag$+1:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ag(OH)2]- | SRD-46 | -1 | 1x | +137.042 | 0 | id=[Ag$+1].[OH]2.[z-1]; mu_canon=+137.0417; *** |
| 2 | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | ox=+1; Argentite ion; DGf=-0.418 |

> Δ([AgO]- vs [Ag(OH)2]-) = 22.620 kJ/mol

#### 1.3  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.4  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.5  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

## 2. Solid / Dissolution Species

8 core groups, 13 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Ag$+0:1` | Ag | Atlas | +0 | 1x | -77.111 | 1 | — | — |
| 2 | `Ag$+1:1 H:-1` | [(Ag2O)0.5](s) | SRD-46 | +0 | 1x | +35.901 | 0 | ref | *** |
| 3 | `Ag$+1:1 H:-1` | Ag2O | Atlas | +0 | 2x | +72.149 | 0 | +0.173 | — |
| 4 | `Ag$+1:1 L1:1` | [Ag(Chloride ion)](s) | SRD-46 | +0 | 1x | -53.767 | 0 | — | *** |
| 5 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 6 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 7 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 8 | `Cu$+1:1 L1:1` | [Cu(Chloride ion)](s) | SRD-46 | +0 | 1x | -38.413 | 0 | — | *** |
| 9 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 10 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 11 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 12 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |
| 13 | `Cu$+2:2 L1:1 H:-3` | [Cu((OH))1.5(Chloride ion)0.5](s) | SRD-46 | +0 | 0.5x | +35.888 | -1 | — | *** |

### Duplicated Groups

#### 2.1  Core: `Ag$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Ag2O)0.5](s) | SRD-46 | +0 | 1x | +35.901 | 0 | id=[Ag$+1].[OH].[z+0]_(s); mu_canon=+35.9014; *** |
| 2 | Ag2O | Atlas | +0 | 2x | +72.149 | 0 | ox=+1; Argentous oxide, brown-black, cub.; DGf=-10.820 |

> Δ(Ag2O vs [(Ag2O)0.5](s)) = 0.173 kJ/mol

#### 2.2  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.3  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

## 3. Gas Species

*(No species in this section.)*

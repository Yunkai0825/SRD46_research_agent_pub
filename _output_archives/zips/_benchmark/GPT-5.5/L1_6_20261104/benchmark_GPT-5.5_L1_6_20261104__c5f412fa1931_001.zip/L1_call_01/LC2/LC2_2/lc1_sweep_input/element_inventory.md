# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ag

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | `Ag$+1.z+1[1]` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | `[Ag$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-c6fc497f4cb0ba93` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | `[Ag$+1].[OH].[z+0]` | SRD-46 | +0 | 1 | +68.492 | true |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | `Ag$+1.OH2.z-1[1]` | Atlas | -1 | 1 | +159.661 | true |
| `DEDUP-a490865d42e7e0ce` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | `[Ag$+1].[OH]2.[z-1]` | SRD-46 | -1 | 1 | +137.042 | true |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | `[Ag$+1].[L1].[z+0]` | SRD-46 | +0 | 1 | -17.580 | true |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | `[Ag$+1].[L1]2.[z-1]` | SRD-46 | -1 | 1 | -28.995 | true |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | `[Ag$+1].[L1]3.[z-2]` | SRD-46 | -2 | 1 | -29.680 | true |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | `[Ag$+1].[L1]4.[z-3]` | SRD-46 | -3 | 1 | -30.365 | true |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | `Ag$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +72.149 | true |
| `DEDUP-0dd4aef3e990da76` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | `[Ag$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | +35.901 | true |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | `[Ag$+1].[L1].[z+0]_(s)` | SRD-46 | +0 | 1 | -53.767 | true |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | `Ag$+0.z+0(s)` | Atlas | +0 | 1 | -77.111 | true |

## Cu

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | `Cu$+1.z+1[1]` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | `[Cu$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-0f5d0852a1f731b7` | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | `[Cu$+1].[L1].[z+0]` | SRD-46 | +0 | 1 | -17.694 | true |
| `DEDUP-5b52cb6f8bceab8e` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Chlo)2]-` | `[Cu$+1].[L1]2.[z-1]` | SRD-46 | -1 | 1 | -30.936 | true |
| `DEDUP-aab51fff2f79618a` | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | `[Cu$+1].[L1]3.[z-2]` | SRD-46 | -2 | 1 | -27.111 | true |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | `Cu$+2.z+2[1]` | Atlas | +2 | 1 | +14.770 | true |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | `[Cu$+2].[z+2]` | SRD-46 | +2 | 1 | +14.770 | true |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | `[Cu$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.860 | true |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | `[Cu$+2]2.[OH]2.[z+2]` | SRD-46 | +2 | 2 | +93.465 | true |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | `[Cu$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.234 | true |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | `Cu$+2.OH3.z-1` | Atlas | -1 | 1 | +167.193 | true |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | `Cu$+2.OH4.z-2` | Atlas | -2 | 1 | +242.170 | true |
| `DEDUP-602158e7d04361c1` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | `[Cu$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +13.628 | true |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | `[Cu$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +172.732 | true |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | `Cu$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +2.971 | true |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | `[Cu$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | -3.995 | true |
| `DEDUP-ae92b4dc491c5642` | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | `[Cu$+1].[L1].[z+0]_(s)` | SRD-46 | +0 | 1 | -38.413 | true |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | `Cu$+2.OH2.z+0(s)[1]` | Atlas | +0 | 1 | +59.789 | true |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | `[Cu$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +58.433 | true |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | `Cu$+0.z+0(s)` | Atlas | +0 | 1 | -50.208 | true |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | `Cu$+2.OH2.z+0(s)[2]` | Atlas | +0 | 1 | +67.279 | true |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | `[Cu$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +64.312 | true |
| `DEDUP-7c08adb75f2332b3` | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | `[Cu$+2].[L1]0.5.[OH]1.5.[z+0]_(s)` | SRD-46 | +0 | 0.5 | +35.888 | true |

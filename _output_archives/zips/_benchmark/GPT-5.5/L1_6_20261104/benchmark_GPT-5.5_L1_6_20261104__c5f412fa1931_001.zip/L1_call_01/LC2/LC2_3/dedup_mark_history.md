# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-6969d0c189f99832` | `Ag+` | Atlas | generation 1: dropped — Ag+ aqueous provenance duplicates describe the same monovalent silver ion, so the SRD-46 representation is retained as preferred. |
| `DEDUP-1a8baa9f32901389` | `[Ag]+` | SRD-46 | generation 1: kept — Ag+ aqueous provenance duplicates describe the same monovalent silver ion, so the SRD-46 representation is retained as preferred. |
| `DEDUP-c6fc497f4cb0ba93` | `[Ag(OH)]` | SRD-46 | generation 1: kept — AgOH(aq) is explicitly retained as an in-scope Ag(I) hydrolysis species. |
| `DEDUP-44d6e80c979b07a0` | `[AgO]-` | Atlas | generation 1: dropped — At unit water activity [AgO]- is the Atlas oxo notation duplicate of the Ag(I) dihydroxo complex, so the SRD-46 [Ag(OH)2]- representative is retained. |
| `DEDUP-a490865d42e7e0ce` | `[Ag(OH)2]-` | SRD-46 | generation 1: kept — At unit water activity [AgO]- is the Atlas oxo notation duplicate of the Ag(I) dihydroxo complex, so the SRD-46 [Ag(OH)2]- representative is retained. |
| `DEDUP-90c3b7cb03caa3fd` | `[Ag(Chlo)]` | SRD-46 | generation 1: kept — The neutral Ag(I) chloride complex is in scope because chloride is a fixed ligand component and distinct ligand stoichiometries are retained. |
| `DEDUP-8d3e992d0fdbe7e8` | `[Ag(Chlo)2]-` | SRD-46 | generation 1: kept — The dichloro Ag(I) complex has distinct stoichiometry and charge and is retained for chloride predominance chemistry. |
| `DEDUP-3a34588649c1bf2b` | `[Ag(Chlo)3]2-` | SRD-46 | generation 1: kept — The trichloro Ag(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| `DEDUP-961d37c9935a000b` | `[Ag(Chlo)4]3-` | SRD-46 | generation 1: kept — The tetrachloro Ag(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| `DEDUP-d4fa43b19fc0d8af` | `Ag` | Atlas | generation 1: kept — Elemental Ag(s) must be retained as the zero-valent reference and target state. |
| `DEDUP-6abe5e58ca8cdc70` | `Ag2O` | Atlas | generation 1: dropped — Collapsed duplicate Ag(I) oxide solid notation to the preferred SRD-46 half-formula representative per Ag-specific instructions. |
| `DEDUP-0dd4aef3e990da76` | `[(Ag2O)0.5](s)` | SRD-46 | generation 1: kept — Collapsed duplicate Ag(I) oxide solid notation to the preferred SRD-46 half-formula representative per Ag-specific instructions. |
| `DEDUP-3e9c182ec7373423` | `[Ag(Chloride ion)](s)` | SRD-46 | generation 1: kept — AgCl(s) is an in-scope chloride precipitate explicitly retained for the Ag chloride system. |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) aqueous ion provenance duplicates are collapsed to the internally cited SRD-46 representation at 25 C. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) aqueous ion provenance duplicates are collapsed to the internally cited SRD-46 representation at 25 C. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — The neutral Cu(I) chloride complex is an in-scope chloride species with distinct oxidation and ligand stoichiometry. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — The dichloro Cu(I) complex has distinct stoichiometry and charge and is retained for Cu chloride predominance chemistry. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — The trichloro Cu(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas and SRD-46 rows represent the same aqueous Cu(II) ion at the same aligned potential, so the SRD-46 representation is retained per provenance preference. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas and SRD-46 rows represent the same aqueous Cu(II) ion at the same aligned potential, so the SRD-46 representation is retained per provenance preference. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both SRD-46 aqueous Cu(II) hydrolysis species because they differ in nuclearity and charge, and polynuclear hydrolysis species are in scope for Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both SRD-46 aqueous Cu(II) hydrolysis species because they differ in nuclearity and charge, and polynuclear hydrolysis species are in scope for Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Aqueous Cu(II) hydrolysis species are explicitly retained when chemically distinct. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This high-alkaline Cu(II) hydrolysis/cuprate species is unique and not excluded by the chloride-solution stability scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This distinct high-alkaline Cu(II) cuprate species is unique and remains in scope for the aqueous Pourbaix model. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — The Cu(II) monochloro complex is distinct in oxidation state and charge and is retained for chloride chemistry. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis species are explicitly retained when distinct. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) must be retained as the zero-valent reference and target state. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — The two entries are the same Cu(I) oxide solid family/notation duplicate, so the SRD-46 representative is kept as the preferred stable-phase source. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — The two entries are the same Cu(I) oxide solid family/notation duplicate, so the SRD-46 representative is kept as the preferred stable-phase source. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is an in-scope copper chloride precipitate explicitly retained by the instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — The basic copper chloride solid is explicitly in scope for the chloride-containing Cu Pourbaix calculation. |
| — | `[?]` | SRD-46 | generation 1: kept — Keep by default because this singleton aqueous reference entry is not identified as an out-of-scope branch by the case-specific instructions. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion is required because the calculation fixes analytical chloride at 0.1 M. |

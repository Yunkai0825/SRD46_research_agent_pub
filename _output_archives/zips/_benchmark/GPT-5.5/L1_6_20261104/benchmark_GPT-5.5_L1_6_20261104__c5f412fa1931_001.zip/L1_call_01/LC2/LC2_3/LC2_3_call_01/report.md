# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    174.60
- elapsed_s (total):  174.60
- llm_iterations:     25
- llm_tool_calls:     14

- n_groups:           28
- n_multi_groups:     8
- n_singletons:       20
- n_decisions:        28
- n_dropped:          9
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ag$+1:1` | `[Ag]+` [SRD-46] | Ag+ aqueous provenance duplicates describe the same monovalent silver ion, so the SRD-46 representation is retained as preferred. |
| aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` [SRD-46] | At unit water activity [AgO]- is the Atlas oxo notation duplicate of the Ag(I) dihydroxo complex, so the SRD-46 [Ag(OH)2]- representative is retained. |
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) aqueous ion provenance duplicates are collapsed to the internally cited SRD-46 representation at 25 C. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas and SRD-46 rows represent the same aqueous Cu(II) ion at the same aligned potential, so the SRD-46 representation is retained per provenance preference. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both SRD-46 aqueous Cu(II) hydrolysis species because they differ in nuclearity and charge, and polynuclear hydrolysis species are in scope for Cu. |
| solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` [SRD-46] | Collapsed duplicate Ag(I) oxide solid notation to the preferred SRD-46 half-formula representative per Ag-specific instructions. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | The two entries are the same Cu(I) oxide solid family/notation duplicate, so the SRD-46 representative is kept as the preferred stable-phase source. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46] | Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Keep by default because this singleton aqueous reference entry is not identified as an out-of-scope branch by the case-specific instructions. |
| aqueous | `Ag$+1:1 H:-1` | yes | AgOH(aq) is explicitly retained as an in-scope Ag(I) hydrolysis species. |
| aqueous | `Ag$+1:1 L1:1` | yes | The neutral Ag(I) chloride complex is in scope because chloride is a fixed ligand component and distinct ligand stoichiometries are retained. |
| aqueous | `Ag$+1:1 L1:2` | yes | The dichloro Ag(I) complex has distinct stoichiometry and charge and is retained for chloride predominance chemistry. |
| aqueous | `Ag$+1:1 L1:3` | yes | The trichloro Ag(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| aqueous | `Ag$+1:1 L1:4` | yes | The tetrachloro Ag(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| aqueous | `Cu$+1:1 L1:1` | yes | The neutral Cu(I) chloride complex is an in-scope chloride species with distinct oxidation and ligand stoichiometry. |
| aqueous | `Cu$+1:1 L1:2` | yes | The dichloro Cu(I) complex has distinct stoichiometry and charge and is retained for Cu chloride predominance chemistry. |
| aqueous | `Cu$+1:1 L1:3` | yes | The trichloro Cu(I) complex has distinct ligand stoichiometry and charge and is retained as an in-scope chloride complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Aqueous Cu(II) hydrolysis species are explicitly retained when chemically distinct. |
| aqueous | `Cu$+2:1 H:-3` | yes | This high-alkaline Cu(II) hydrolysis/cuprate species is unique and not excluded by the chloride-solution stability scope. |
| aqueous | `Cu$+2:1 H:-4` | yes | This distinct high-alkaline Cu(II) cuprate species is unique and remains in scope for the aqueous Pourbaix model. |
| aqueous | `Cu$+2:1 L1:1` | yes | The Cu(II) monochloro complex is distinct in oxidation state and charge and is retained for chloride chemistry. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydrolysis species are explicitly retained when distinct. |
| aqueous | `L1:1` | yes | Chloride ion is required because the calculation fixes analytical chloride at 0.1 M. |
| solid | `Ag$+0:1` | yes | Elemental Ag(s) must be retained as the zero-valent reference and target state. |
| solid | `Ag$+1:1 L1:1` | yes | AgCl(s) is an in-scope chloride precipitate explicitly retained for the Ag chloride system. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) must be retained as the zero-valent reference and target state. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl(s) is an in-scope copper chloride precipitate explicitly retained by the instructions. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | The basic copper chloride solid is explicitly in scope for the chloride-containing Cu Pourbaix calculation. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ag+` | Atlas | aqueous | LC2 element review: Ag+ aqueous provenance duplicates describe the same monovalent silver ion, so the SRD-46 representation is retained as preferred. |
| `[AgO]-` | Atlas | aqueous | LC2 element review: At unit water activity [AgO]- is the Atlas oxo notation duplicate of the Ag(I) dihydroxo complex, so the SRD-46 [Ag(OH)2]- representative is retained. |
| `Cu+` | Atlas | aqueous | LC2 element review: Cu(I) aqueous ion provenance duplicates are collapsed to the internally cited SRD-46 representation at 25 C. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas and SRD-46 rows represent the same aqueous Cu(II) ion at the same aligned potential, so the SRD-46 representation is retained per provenance preference. |
| `Ag2O` | Atlas | dissolution | LC2 element review: Collapsed duplicate Ag(I) oxide solid notation to the preferred SRD-46 half-formula representative per Ag-specific instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: The two entries are the same Cu(I) oxide solid family/notation duplicate, so the SRD-46 representative is kept as the preferred stable-phase source. |
| `CuO` | Atlas | dissolution | LC2 element review: Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Collapsed CuO/Cu(OH)2 hydration and provenance variants for the same Cu(II) solid family at unit water activity to the preferred stable SRD-46 representative. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: bcacee70061d48109b3561cab71175be
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final table accepted. The selections are chemically consistent for a 25 C chloride-bearing Pourbaix stability calculation: duplicate provenance/notation entries are collapsed to the preferred SRD-46 representatives, distinct chloride complexes and hydrolysis species are retained, and elemental Cu(s) and Ag(s) remain as zero-valent target states. No source repair or redispatch is required.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (11/11)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_6_20261104\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

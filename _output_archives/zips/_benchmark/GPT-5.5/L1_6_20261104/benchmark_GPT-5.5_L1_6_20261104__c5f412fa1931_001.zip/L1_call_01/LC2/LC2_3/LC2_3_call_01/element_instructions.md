# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a thermodynamic Pourbaix predominance/stability calculation at 25 C for Cu and Ag in one aqueous phase with fixed analytical chloride of 0.1 M; the mildly acidic, weakly oxidising region motivates retaining chloride complexes and zero-valent metals, not using a chloride-free corrosion simplification.
- For duplicate aqueous identity, prefer the internally cited SRD-46 representation over Atlas when they describe the same ion or the same hydrated notation at fixed water activity; keep different ligand stoichiometries, oxidation states, charges, and nuclearities because they can occupy different predominance regions.
- Use water activity effectively unity at 25 C. Hydrate/oxide spellings with the same metal redox state and same pH/E dependence should be collapsed to the thermodynamically preferred representative for a stable-phase Pourbaix diagram; do not retain multiple hydration notations merely to show formation alternatives.
- Chloride-bearing aqueous complexes and chloride precipitates are in scope because chloride is the fixed ligand component; carbonate and unrelated counterion solids are out of scope if present.
- Mixed-valence or non-stoichiometric oxide alternatives would be retained only if they are redox-distinct stable-chain members; none are implied by mere duplicate spelling here.
- The phase question is which phase is stable on the hull, so collapse polymorph/provenance duplicates and same-stoichiometry notation duplicates; where one source is needed for citable equilibrium constants, prefer SRD-46 unless that would remove an elemental reference.
- Elemental Ag(s) and Cu(s) must stay as zero-valent reference/target states. No gases in this inventory have an imposed fugacity constraint, so no decorative gas retention rule is needed.
- Apply the same chloride-solution stability logic to both elements, but handle Cu separately for its Cu(I)/Cu(II), polynuclear hydrolysis, and oxide/hydroxide alternatives; Ag mainly needs collapse of Ag(I) notation duplicates while retaining AgCl(s) and chloride complexes.

## Element instructions

- **Ag**: For Ag, collapse exact Ag+ provenance duplicates to the SRD-46 ion, collapse Ag(I) dihydroxo/oxo aqueous notation duplicates to the SRD-46 [Ag(OH)2]- representative at fixed water activity, and collapse Ag2O solid notation duplicates to the SRD-46 half-formula entry. Keep AgCl(s), all distinct Ag chloride complexes, AgOH(aq), and Ag(s) because these are in-scope chloride/hydrolysis/metal states.
- **Cu**: For Cu, collapse Cu+ and Cu2+ provenance duplicates to the SRD-46 ions, keep distinct Cu(I)/Cu(II) chloride complexes and hydrolysis species including polynuclear hydrolysis, and do not merge different oxidation states. Collapse Cu2O, CuO, and Cu(OH)2 duplicate/provenance or hydration variants to the stable SRD-46 representative for each same-stoichiometry solid family at water activity near one; keep CuCl(s), basic copper chloride solid, high-alkaline cuprate species if otherwise unique, and Cu(s).

All 20 singleton entries are retained. They are in-scope for the chloride-containing Cu/Ag Pourbaix calculation, and none is a within-group duplicate requiring removal.

| phase | core_label | keep | rationale |
|---|---:|:---:|---|
| aqueous | `(empty)` | true | Retained as a singleton aqueous reference/background entry with no duplicate alternative provided. |
| aqueous | `Ag$+1:1 H:-1` | true | AgOH(aq) is an explicitly retained Ag(I) hydrolysis species. |
| aqueous | `Ag$+1:1 L1:1` | true | The neutral Ag(I) chloride complex is distinct and in scope at fixed chloride. |
| aqueous | `Ag$+1:1 L1:2` | true | The dichloro Ag(I) complex has distinct ligand stoichiometry and charge. |
| aqueous | `Ag$+1:1 L1:3` | true | The trichloro Ag(I) complex is a distinct chloride species. |
| aqueous | `Ag$+1:1 L1:4` | true | The tetrachloro Ag(I) complex is distinct and retained for chloride predominance. |
| aqueous | `Cu$+1:1 L1:1` | true | The neutral Cu(I) chloride complex is distinct and in scope. |
| aqueous | `Cu$+1:1 L1:2` | true | The dichloro Cu(I) complex has distinct stoichiometry and charge. |
| aqueous | `Cu$+1:1 L1:3` | true | The trichloro Cu(I) complex is distinct and retained. |
| aqueous | `Cu$+2:1 H:-2` | true | Cu(OH)₂(aq) is a distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | true | HCuO₂⁻ is a unique high-alkaline Cu(II) hydrolysis/cuprate species. |
| aqueous | `Cu$+2:1 H:-4` | true | CuO₂²⁻ is a distinct high-alkaline Cu(II) cuprate species. |
| aqueous | `Cu$+2:1 L1:1` | true | The Cu(II) monochloro complex is distinct from Cu(I) chloride complexes. |
| aqueous | `Cu$+2:3 H:-4` | true | Polynuclear Cu(II) hydrolysis species are explicitly retained. |
| aqueous | `L1:1` | true | Chloride ion is the fixed ligand component and must remain in scope. |
| solid | `Ag$+0:1` | true | Elemental Ag(s) is a required zero-valent reference/target state. |
| solid | `Ag$+1:1 L1:1` | true | AgCl(s) is an in-scope chloride precipitate. |
| solid | `Cu$+0:1` | true | Elemental Cu(s) is a required zero-valent reference/target state. |
| solid | `Cu$+1:1 L1:1` | true | CuCl(s) is an in-scope copper chloride precipitate. |
| solid | `Cu$+2:2 L1:1 H:-3` | true | The basic copper chloride solid is explicitly retained as an in-scope chloride solid. |
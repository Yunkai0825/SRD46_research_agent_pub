## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a finite-concentration joint E-pH speciation/P Pourbaix calculation for one shared pot at 25 C and I=0.1 m, not a 1e-6 M corrosion-convention diagram.
- Aqueous identity is governed by the stated totals: 1 mM Fe, 1 mM Cu, 5 mM citrate, and 0.1 M chloride; citrate L1 and chloride L2 complexes, protonated forms, hydrolysis products, and polynuclear species are in scope when chemically distinct.
- Prefer SRD-46 over Atlas for exact duplicate aqueous notation or duplicate database constants at the stated ionic-strength context; do not collapse monomer/dimer/polymer complexes merely because the normalized core matches.
- Include Fe/Cu precipitated oxides, hydroxides, oxyhydroxides, chlorides, and basic chlorides present in the database; carbonates and unrelated counterion solids are out of scope.
- The phase question is stable dominant species, not formation pathway: collapse exact source/polymorph duplicates for the same solid chemistry to the preferred SRD-46/lower-mu representative, but keep different redox states, mixed-valence solids, ligand salts, and hydration/oxyhydroxide chemistries that may define different E-pH regions.
- Retain elemental Fe and Cu solids as redox boundary references; no gases are part of the stated solution constraints.
- Diagram-changing ambiguity should be exposed, not silently fixed, especially if a retained citrate/chloride complex implies missing ligand competition chemistry in the other metal.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: For exact aqueous duplicates such as Cu+ and Cu2+, keep the SRD-46 notation over Atlas, while retaining distinct chloride, citrate, hydrolysis, protonated, and polynuclear Cu species. For duplicate Cu2O, CuO, and Cu(OH)2 solids representing the same stable phase, keep the SRD-46/lower-mu entry, while keeping elemental Cu, CuCl(s), and basic copper chloride as distinct in-scope phases.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
Kept the SRD-46 Cu₂O representative and dropped the Atlas duplicate for the same solid phase.
Kept: `[Fe(OH)2](s)` from `SRD-46`.

Rationale: The Atlas hydrated Fe(OH)₂ and SRD-46 solid represent duplicate Fe(II) hydroxide solid chemistry, so the SRD-46 representative is preferred.
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as a finite-concentration joint E-pH speciation/P Pourbaix calculation for one shared pot at 25 C and I=0.1 m, not a 1e-6 M corrosion-convention diagram.
- Aqueous identity is governed by the stated totals: 1 mM Fe, 1 mM Cu, 5 mM citrate, and 0.1 M chloride; citrate L1 and chloride L2 complexes, protonated forms, hydrolysis products, and polynuclear species are in scope when chemically distinct.
- Prefer SRD-46 over Atlas for exact duplicate aqueous notation or duplicate database constants at the stated ionic-strength context; do not collapse monomer/dimer/polymer complexes merely because the normalized core matches.
- Include Fe/Cu precipitated oxides, hydroxides, oxyhydroxides, chlorides, and basic chlorides present in the database; carbonates and unrelated counterion solids are out of scope.
- The phase question is stable dominant species, not formation pathway: collapse exact source/polymorph duplicates for the same solid chemistry to the preferred SRD-46/lower-mu representative, but keep different redox states, mixed-valence solids, ligand salts, and hydration/oxyhydroxide chemistries that may define different E-pH regions.
- Retain elemental Fe and Cu solids as redox boundary references; no gases are part of the stated solution constraints.
- Diagram-changing ambiguity should be exposed, not silently fixed, especially if a retained citrate/chloride complex implies missing ligand competition chemistry in the other metal.

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a finite-concentration joint E-pH speciation/P Pourbaix calculation for one shared pot at 25 C and I=0.1 m, not a 1e-6 M corrosion-convention diagram.
- Aqueous identity is governed by the stated totals: 1 mM Fe, 1 mM Cu, 5 mM citrate, and 0.1 M chloride; citrate L1 and chloride L2 complexes, protonated forms, hydrolysis products, and polynuclear species are in scope when chemically distinct.
- Prefer SRD-46 over Atlas for exact duplicate aqueous notation or duplicate database constants at the stated ionic-strength context; do not collapse monomer/dimer/polymer complexes merely because the normalized core matches.
- Include Fe/Cu precipitated oxides, hydroxides, oxyhydroxides, chlorides, and basic chlorides present in the database; carbonates and unrelated counterion solids are out of scope.
- The phase question is stable dominant species, not formation pathway: collapse exact source/polymorph duplicates for the same solid chemistry to the preferred SRD-46/lower-mu representative, but keep different redox states, mixed-valence solids, ligand salts, and hydration/oxyhydroxide chemistries that may define different E-pH regions.
- Retain elemental Fe and Cu solids as redox boundary references; no gases are part of the stated solution constraints.
- Diagram-changing ambiguity should be exposed, not silently fixed, especially if a retained citrate/chloride complex implies missing ligand competition chemistry in the other metal.

## Element instructions

- **Cu**: For exact aqueous duplicates such as Cu+ and Cu2+, keep the SRD-46 notation over Atlas, while retaining distinct chloride, citrate, hydrolysis, protonated, and polynuclear Cu species. For duplicate Cu2O, CuO, and Cu(OH)2 solids representing the same stable phase, keep the SRD-46/lower-mu entry, while keeping elemental Cu, CuCl(s), and basic copper chloride as distinct in-scope phases.
- **Fe**: For exact aqueous duplicates such as Fe2+, Fe3+, Fe(OH)2+, and Fe(OH)2+, keep the SRD-46 notation over Atlas, while retaining distinct chloride, citrate, hydrolysis, protonated, ferrate, and polynuclear Fe species. For duplicate Fe oxide/hydroxide solids representing the same stable phase, keep the SRD-46/lower-mu representative, while retaining elemental Fe, Fe3O4 mixed-valence, and distinct Fe(III) hydroxide/oxyhydroxide precipitates that may compete at fixed water activity.

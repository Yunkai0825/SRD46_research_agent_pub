Kept: `[Fe(OH)3]-` from SRD-46.

Rationale: SRD-46 aqueous hydrolysis notation is preferred over the Atlas alternate notation for the same charge, phase, and nuclearity.
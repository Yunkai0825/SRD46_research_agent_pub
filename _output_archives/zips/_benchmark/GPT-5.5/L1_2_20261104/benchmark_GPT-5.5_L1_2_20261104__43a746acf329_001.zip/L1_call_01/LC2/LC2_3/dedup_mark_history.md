# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ and [Cu]+ are the same aqueous Cu(I) ion, so the exact duplicate is resolved by keeping the SRD-46 entry as instructed. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ and [Cu]+ are the same aqueous Cu(I) ion, so the exact duplicate is resolved by keeping the SRD-46 entry as instructed. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Kept because Cu(I) chloride complexes are explicitly in scope and this singleton is not a duplicate. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Kept because distinct Cu(I) chloride complex stoichiometries are in scope for the 0.1 M chloride solution. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Kept because distinct Cu(I) chloride complex stoichiometries are in scope for the chloride-rich calculation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Kept the SRD-46 Cu2+ notation over the exact Atlas aqueous duplicate with the same charge, phase, multiplier, and aligned chemical potential. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Kept the SRD-46 Cu2+ notation over the exact Atlas aqueous duplicate with the same charge, phase, multiplier, and aligned chemical potential. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both because they differ in charge and nuclearity and represent distinct in-scope aqueous copper hydrolysis species. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both because they differ in charge and nuclearity and represent distinct in-scope aqueous copper hydrolysis species. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Kept because Cu(II) hydrolysis products are chemically distinct aqueous species in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Kept because this distinct Cu(II) hydrolysis species is in scope despite being Atlas-sourced. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Kept because this distinct Cu(II) hydrolysis species is in scope despite being Atlas-sourced. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Kept because Cu-citrate complexes are explicitly in scope and polynuclear species should not be collapsed. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Kept because hydroxylated Cu-citrate complexes are chemically distinct and in scope. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Kept because protonated Cu-citrate complexes are in scope for the finite-concentration speciation calculation. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Kept because Cu(II) chloride complexes are explicitly in scope and this singleton is not a duplicate. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Kept because distinct polynuclear Cu-citrate-hydroxo species are in scope and should not be collapsed. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Kept because distinct polynuclear Cu-citrate-hydroxo species are in scope and should not be collapsed. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Kept because polynuclear Cu hydrolysis species are explicitly in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Kept because elemental Cu solid is retained as a redox boundary reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent the same Cu2O solid phase, so the SRD-46 lower-mu representative is kept over the Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent the same Cu2O solid phase, so the SRD-46 lower-mu representative is kept over the Atlas duplicate. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — Kept because CuCl(s) is an explicitly in-scope copper chloride solid and is not a duplicate of the aqueous complex. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct in-scope solid chemistries, and for each exact SRD/Atlas duplicate the SRD-46 lower/preferred representative is retained. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct in-scope solid chemistries, and for each exact SRD/Atlas duplicate the SRD-46 lower/preferred representative is retained. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct in-scope solid chemistries, and for each exact SRD/Atlas duplicate the SRD-46 lower/preferred representative is retained. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct in-scope solid chemistries, and for each exact SRD/Atlas duplicate the SRD-46 lower/preferred representative is retained. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Kept because basic copper chloride is explicitly retained as a distinct in-scope solid phase. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ and [Fe]2+ represent the same aqueous Fe(II) ion, so the SRD-46 notation is retained over the Atlas duplicate. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ and [Fe]2+ represent the same aqueous Fe(II) ion, so the SRD-46 notation is retained over the Atlas duplicate. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Kept because Fe(II) hydrolysis products are chemically distinct aqueous species in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Kept because Fe(II) hydrolysis products are chemically distinct aqueous species in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are same-charge aqueous mononuclear hydrolysis notations for the same core species, so the SRD-46 representative is preferred over Atlas. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are same-charge aqueous mononuclear hydrolysis notations for the same core species, so the SRD-46 representative is preferred over Atlas. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Kept because Fe(II) hydrolysis products are chemically distinct aqueous species in scope. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Kept because Fe(II)-citrate complexes are explicitly in scope. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Kept because polynuclear hydroxylated Fe-citrate species are in scope and should not be collapsed. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Kept because protonated Fe(II)-citrate complexes are in scope. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Kept because differently protonated Fe(II)-citrate complexes are chemically distinct and in scope. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Kept because distinct Fe(II)-citrate stoichiometries are in scope. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Kept because Fe(II) chloride complexes are explicitly in scope for the chloride-containing solution. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and chemical potential, so the SRD-46 notation is preferred over Atlas for the exact duplicate. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and chemical potential, so the SRD-46 notation is preferred over Atlas for the exact duplicate. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Keep the SRD-46 Fe(OH)2+ monomer over the exact Atlas duplicate, and retain the chemically distinct polynuclear Fe hydrolysis species. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Keep the SRD-46 Fe(OH)2+ monomer over the exact Atlas duplicate, and retain the chemically distinct polynuclear Fe hydrolysis species. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Keep the SRD-46 Fe(OH)2+ monomer over the exact Atlas duplicate, and retain the chemically distinct polynuclear Fe hydrolysis species. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — The two rows are exact aqueous duplicates with the same charge and nuclearity, so the SRD-46 entry is preferred over the Atlas duplicate. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — The two rows are exact aqueous duplicates with the same charge and nuclearity, so the SRD-46 entry is preferred over the Atlas duplicate. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Kept because Fe(III) hydrolysis products are chemically distinct aqueous species in scope. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Kept because Fe(III)-citrate complexes are explicitly in scope. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Both SRD-46 aqueous citrate hydroxo Fe(III) complexes are retained because the monomer and dimer differ in nuclearity/multiplier and charge, making them distinct in-scope species rather than duplicates. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Both SRD-46 aqueous citrate hydroxo Fe(III) complexes are retained because the monomer and dimer differ in nuclearity/multiplier and charge, making them distinct in-scope species rather than duplicates. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Kept because protonated Fe(III)-citrate complexes are chemically distinct and in scope. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Kept because Fe(III) chloride complexes are explicitly in scope. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Kept because distinct Fe(III) chloride complex stoichiometries are in scope. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Kept because polynuclear Fe(III) hydrolysis species are explicitly in scope. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Kept because ferrate species are specifically retained by the Fe instructions despite the Atlas source. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Kept because elemental Fe solid is retained as a redox boundary reference. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Kept because Fe3O4 is a distinct mixed-valence iron oxide phase explicitly retained by the instructions. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — The two entries are duplicate neutral Fe(OH)2 solid hydroxide representations, so the SRD-46 representative is preferred over the Atlas hydrated notation. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — The two entries are duplicate neutral Fe(OH)2 solid hydroxide representations, so the SRD-46 representative is preferred over the Atlas hydrated notation. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Kept distinct Fe(III) anhydrous oxide, oxyhydroxide, and hydroxide solids, choosing SRD-46/lower-mu representatives over Atlas duplicates for the same solid chemistry. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Kept distinct Fe(III) anhydrous oxide, oxyhydroxide, and hydroxide solids, choosing SRD-46/lower-mu representatives over Atlas duplicates for the same solid chemistry. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Kept distinct Fe(III) anhydrous oxide, oxyhydroxide, and hydroxide solids, choosing SRD-46/lower-mu representatives over Atlas duplicates for the same solid chemistry. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Kept distinct Fe(III) anhydrous oxide, oxyhydroxide, and hydroxide solids, choosing SRD-46/lower-mu representatives over Atlas duplicates for the same solid chemistry. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Kept distinct Fe(III) anhydrous oxide, oxyhydroxide, and hydroxide solids, choosing SRD-46/lower-mu representatives over Atlas duplicates for the same solid chemistry. |
| — | `[?]` | SRD-46 | generation 1: kept — Kept as the singleton aqueous reference entry with no case-specific instruction excluding it. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Kept because chloride is an explicitly stated solution component at 0.1 M. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Kept because citrate ligand forms are in scope under the stated 5 mM citrate total. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Kept because protonated citrate forms are in scope for the finite-concentration pH speciation calculation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Kept because neutral citric acid is an in-scope protonation state of the stated citrate total. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Kept because protonated citrate forms are in scope for the finite-concentration pH speciation calculation. |

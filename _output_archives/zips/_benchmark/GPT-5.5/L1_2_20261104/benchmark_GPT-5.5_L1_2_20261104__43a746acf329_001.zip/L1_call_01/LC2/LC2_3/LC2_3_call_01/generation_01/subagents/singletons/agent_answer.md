All 40 singleton species are kept.

Rationale: each supplied entry is a singleton with no within-core duplicate to resolve, and all listed aqueous citrate/chloride/hydrolysis/protonation/redox species plus the Fe/Cu elemental and chloride/basic-chloride/mixed-valence solid phases are in scope for the stated finite-concentration Fe–Cu–citrate–chloride E–pH/P Pourbaix calculation.
## Doability
Doable. The joint shared-pot Fe–Cu–citrate–chloride Pourbaix/speciation calculation completed for 25 °C, ionic-strength target 0.1, pH 2–10 and E = −0.6 to 1.2 V vs SHE.

## Result
A coupled solution was modeled with Cu=1 mM, Fe=1 mM, citrate=5 mM and chloride=0.1 M, so both metals drew from the same ligand pools. The solver produced Cu and Fe dominance maps plus a full-speciation CSV. Final classified-grid spacing was ΔpH=0.0055555556 and ΔE=0.0011111111 V. The full-speciation file reports 26,790 coarse-unrefined and 152,870 refined samples; inspected rows show `converged=1`, low residuals, and `phase_search_timed_out=0`. I did not find a separate all-cells convergence summary in the opened evidence, so the main conclusions rely on the completed deterministic verdicts and inspected convergence fields.

## Analysis
At 0.3 V, Cu changes from chloride control to citrate/hydroxo-citrate control as pH rises: [Cu(Chlo)2]- from pH 2–3.6333333, [Cu2(Citr)2(OH)]3- from 3.6388889–4.0, then [Cu2(Citr)2(OH)2]4- from 4.0055556–10. This reflects citrate deprotonation plus hydrolysis: chloride is abundant, but committed Cu(II) chloride binding is weak for [Cu(Chlo)]+, log_beta +0.2000, while Cu citrate rows include [Cu2(Citr)2]2- log_beta +14.5000, [Cu2(Citr)2(OH)]3- +11.2000, and [Cu2(Citr)2(OH)2]4- +6.3400 on the card basis. At pH 6, Cu is metal from E=−0.6 to 0.093333333 V and [Cu2(Citr)2(OH)2]4- from 0.094444444 to 1.2 V. Cu chloride dominates only in acidic/intermediate-E space; the Cu2+ / chloride / citrate junction is at pH 3.34722, E=0.34278 V.

Fe behaves differently. At 0.3 V, Fe is Fe2+ from pH 2–3.8 and [(Fe2O3)0.5(s,alpha)] from pH 3.8055556–10. At pH 6, Fe is Fe metal from −0.6 to −0.57333333 V, [Fe(Citr)]- from −0.57222222 to −0.033333333 V, [(Fe2O3)0.5(s,alpha)] from −0.032222222 to 1.0944444 V, and FeO42- from 1.0955556 to 1.2 V. Thus citrate stabilizes dissolved Fe mainly in reducing/mildly reducing conditions, while oxidizing conditions drive Fe to Fe(III) oxide. Fe citrate constants used include [Fe(Citr)]- log_beta +4.8000, [Fe(Citr)] +11.1900, [Fe(Citr)H]+ +12.3500, and [Fe2(Citr)2(OH)2]2- +21.2000. Fe chloride constants are smaller: [Fe(Chlo)]+ −0.2000, [Fe(Chlo)]2+ +0.7800, and [Fe(Chlo)2]+ +2.1300, so chloride never becomes Fe-dominant.

Ligand competition is therefore redox- and pH-dependent. Where Fe precipitates as Fe(III) oxide, citrate is available to stabilize Cu hydroxo-citrate; at pH 6 and E=0.3 V, Fe is oxide-dominated while Cu is [Cu2(Citr)2(OH)2]4-. Under reducing conditions near pH 6, Fe can hold citrate as [Fe(Citr)]- between about −0.572 and −0.033 V while Cu is metallic below about 0.094 V. At low pH/intermediate E, high chloride captures Cu as [Cu(Chlo)2]- before citrate deprotonation/hydrolysis makes citrate complexes dominant.

Key topology landmarks: Fe2+ / Fe oxide reaches pH 4.14167, E=0.25056 V and pH 2, E=0.60944 V; Fe citrate / Fe oxide runs from pH 6.61944, E=−0.14167 V to pH 4.14167, E=0.25056 V; Fe oxide / ferrate runs from pH 10, E=0.70056 V to pH 4.93611, E=1.2 V. For Cu, Cu / [Cu(Chlo)2]- reaches pH 2, E=0.13389 V, and Cu / [(Cu2O)0.5](s) / citrate meets at pH 7.025, E=0.06389 V. Sweep-limit junctions are window edges, not chemical endpoints.

The committed acid-base rows include citrate cumulative protonation log_beta +5.6500 for [HCitric acid]2-, +10.0000 for [H2Citric acid]-, and +12.9000 for [H3Citric acid]; only the single-protonation row is directly the conjugate-acid pKa under the card convention. Water [H].[OH] has log_beta −0.2200.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
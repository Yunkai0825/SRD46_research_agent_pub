# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1 molal; catalog handle is ionic strength in mol/L and the same numeric value is used for the fixed model input.
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM total Fe initially as Fe(III); redox-axis calculation uses the element total.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task states 1 mM total Cu initially as Cu(II); redox-axis calculation uses the element total.
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # Task states 5 mM total citrate shared by Fe and Cu.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M total chloride shared by Fe and Cu.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH coordinate over the requested pH range.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix redox-potential coordinate for Fe/Cu redox speciation.'},
]

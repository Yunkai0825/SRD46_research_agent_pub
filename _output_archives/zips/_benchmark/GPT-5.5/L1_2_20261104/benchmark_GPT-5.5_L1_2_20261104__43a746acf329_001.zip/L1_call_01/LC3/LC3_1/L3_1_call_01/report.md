# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_2_20261104\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.22
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Joint E-pH / Pourbaix-style analysis uses independent pH and potential axes, so 2 DOF.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_2_20261104\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength 0.1 molal; catalog handle is ionic strength in mol/L and the same numeric value is used for the fixed model input."},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM total Fe initially as Fe(III); redox-axis calculation uses the element total."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM total Cu initially as Cu(II); redox-axis calculation uses the element total."},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "Task states 5 mM total citrate shared by Fe and Cu."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task states 0.1 M total chloride shared by Fe and Cu."},
]
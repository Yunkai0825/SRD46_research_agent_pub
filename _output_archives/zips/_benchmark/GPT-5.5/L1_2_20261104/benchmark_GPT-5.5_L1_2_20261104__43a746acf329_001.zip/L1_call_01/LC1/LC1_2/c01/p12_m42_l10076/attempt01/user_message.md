[Purpose: Build a joint E-pH speciation picture for one shared solution containing Fe(III), Cu(II), citrate, and chloride at 25 C and ionic strength 0.1 molal. The goal is to determine the dominant Fe and Cu species over pH 2-10 while allowing Fe and Cu to compete for the same citrate and chloride pools, and to report the database constants actually used by the solver.]
[Tasks:
For one shared pot, model 1 mM total Fe initially as Fe(III), 1 mM total Cu initially as Cu(II), 5 mM total citrate, and 0.1 M total chloride at 25 C and I=0.1 m. Run a joint E-pH speciation / Pourbaix-style analysis over pH 2 to 10, allowing relevant Fe and Cu redox/speciation, citrate complexes, chloride complexes, hydrolysis, aqueous species, and any precipitated phases present in the database. Report the dominant Fe species and dominant Cu species in each pH/E region, emphasize how Fe and Cu partition or compete for citrate versus chloride, include convergence evidence, and reference the log K / redox E values actually committed to the calculation.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

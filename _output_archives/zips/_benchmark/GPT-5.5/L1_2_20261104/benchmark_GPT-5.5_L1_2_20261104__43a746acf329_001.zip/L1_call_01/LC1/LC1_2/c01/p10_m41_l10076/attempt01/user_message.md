[Purpose: Build a joint E-pH speciation picture for one shared solution containing Fe(III), Cu(II), citrate, and chloride at 25 C and ionic strength 0.1 molal. The goal is to determine the dominant Fe and Cu species over pH 2-10 while allowing Fe and Cu to compete for the same citrate and chloride pools, and to report the database constants actually used by the solver.]
[Tasks:
For one shared pot, model 1 mM total Fe initially as Fe(III), 1 mM total Cu initially as Cu(II), 5 mM total citrate, and 0.1 M total chloride at 25 C and I=0.1 m. Run a joint E-pH speciation / Pourbaix-style analysis over pH 2 to 10, allowing relevant Fe and Cu redox/speciation, citrate complexes, chloride complexes, hydrolysis, aqueous species, and any precipitated phases present in the database. Report the dominant Fe species and dominant Cu species in each pH/E region, emphasize how Fe and Cu partition or compete for citrate versus chloride, include convergence evidence, and reference the log K / redox E values actually committed to the calculation.
]
[Pair: pair_key=`m41_l10076`, metal_id=41, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10076_beta840_net27419`
  - `metal41_ligand10076_beta649_net27419`
  - `metal41_ligand10076_beta334_net27419`
  - `metal41_ligand10076_beta347_net27419`
[Screen report]
# Eq-map screen — m41_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10076_beta840_net27419` | `[M] + [L]^2 <=> [ML2]` | vlm_170721@(25.0,0.0) = K+11.800 | 2 | +11.200 / +11.500 / +11.500 / +11.800 | vlm_170721@(25.0,0.0) = K+11.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal41_ligand10076_beta519_net27419` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170727@(25.0,0.1) = K+16.800 | 5 | +16.500 / +17.000 / +17.060 / +17.600 | vlm_170727@(25.0,0.1) = K+16.800 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10076_beta649_net27419` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170736@(25.0,0.1) = K+33.500 | 2 | +33.500 / +34.350 / +34.350 / +35.200 | vlm_170736@(25.0,0.1) = K+33.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand10076_beta334_net27419` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170742@(25.0,0.0) = K-19.320 | 3 | -19.320 / -18.900 / -18.900 / -18.480 | vlm_170742@(25.0,0.0) = K-19.320 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal41_ligand10076_beta812_net27419` | `[M] + [L] <=> [ML]` | vlm_170713@(25.0,0.1) = K+6.100 | 5 | +5.800 / +6.100 / +6.260 / +6.800 | vlm_170713@(25.0,0.1) = K+6.100 (+0.00 °C, +0.00 M) | `—` |
| 6 | `metal41_ligand10076_beta347_net27419` | `[MO(s)] + [H2O] <=> [M] + [OH]^2` | vlm_170746@(25.0,0.0) = K-20.350 | 2 | -20.350 / -19.930 / -19.930 / -19.510 | vlm_170746@(25.0,0.0) = K-20.350 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

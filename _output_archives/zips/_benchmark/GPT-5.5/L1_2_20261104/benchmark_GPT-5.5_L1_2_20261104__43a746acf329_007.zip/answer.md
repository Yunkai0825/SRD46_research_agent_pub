## Answer

This is a **joint shared-pot calculation**, so Fe, Cu, citrate, and chloride were equilibrated together rather than as isolated Fe–ligand and Cu–ligand systems.

Over pH 2–10, the main competition pattern is:

- **Cu uses chloride only under acidic/intermediate-redox conditions.** At low pH, citrate is more protonated and less competitive, while 0.1 M chloride is abundant, so Cu appears as **[Cu(Chlo)₂]⁻** in the acidic part of the map.
- **As pH rises, citrate deprotonates and hydroxo-citrate Cu complexes dominate.** Above about pH 3.6 at E = 0.3 V, Cu shifts into citrate/hydroxo-citrate species, especially **[Cu₂(Citr)₂(OH)₂]⁴⁻**, which dominates most of the circumneutral-to-alkaline oxidizing field.
- **Fe does not significantly become chloride-dominated.** The Fe–chloride constants used are much weaker than the Fe–citrate and Fe-oxide controls, so chloride never becomes the dominant Fe ligand in the reported regions.
- **Fe mainly alternates between Fe²⁺, citrate-bound Fe, Fe metal, Fe oxide, and ferrate depending on E and pH.** In mildly oxidizing conditions, Fe is driven into an Fe(III) oxide solid field, freeing citrate to stabilize Cu hydroxo-citrate complexes. Under reducing conditions, Fe can hold citrate as **[Fe(Citr)]⁻**.

At **E = 0.3 V vs SHE**:

- **Cu**
  - pH 2–3.6333333: **[Cu(Chlo)₂]⁻**
  - pH 3.6388889–4.0: **[Cu₂(Citr)₂(OH)]³⁻**
  - pH 4.0055556–10: **[Cu₂(Citr)₂(OH)₂]⁴⁻**

- **Fe**
  - pH 2–3.8: **Fe²⁺**
  - pH 3.8055556–10: **[(Fe₂O₃)⁰·⁵(s, alpha)]**, i.e. an Fe(III) oxide field

At **pH 6**:

- **Cu**
  - E = −0.6 to 0.093333333 V: **Cu metal**
  - E = 0.094444444 to 1.2 V: **[Cu₂(Citr)₂(OH)₂]⁴⁻**

- **Fe**
  - E = −0.6 to −0.57333333 V: **Fe metal**
  - E = −0.57222222 to −0.033333333 V: **[Fe(Citr)]⁻**
  - E = −0.032222222 to 1.0944444 V: **[(Fe₂O₃)⁰·⁵(s, alpha)]**
  - E = 1.0955556 to 1.2 V: **FeO₄²⁻**

Chemically, this means that **Cu wins citrate in the neutral-to-alkaline oxidizing region**, largely because Fe is removed from solution as Fe(III) oxide there. **Fe competes for citrate mainly under reducing conditions**, where dissolved **[Fe(Citr)]⁻** is stable. Chloride competes effectively only for Cu at low pH, where citrate is less deprotonated and less able to bind strongly.

## Evidence

- The calculation used the shared totals **Cu = 1 mM, Fe = 1 mM, citrate = 5 mM, chloride = 0.1 M**, at **25 °C**, ionic-strength target **I = 0.1**, over **pH 2–10** and **E = −0.6 to 1.2 V vs SHE**.
- Grid resolution reported: **ΔpH = 0.0055555556** and **ΔE = 0.0011111111 V**.
- Full-speciation output contained **26,790 coarse-unrefined** and **152,870 refined** samples; inspected rows had **`converged=1`**, low residuals, and **`phase_search_timed_out=0`**.
- Cu dominance at **E = 0.3 V**:
  - **[Cu(Chlo)₂]⁻** from pH **2–3.6333333**
  - **[Cu₂(Citr)₂(OH)]³⁻** from pH **3.6388889–4.0**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻** from pH **4.0055556–10**
- Fe dominance at **E = 0.3 V**:
  - **Fe²⁺** from pH **2–3.8**
  - **[(Fe₂O₃)⁰·⁵(s, alpha)]** from pH **3.8055556–10**
- Cu dominance at **pH 6**:
  - **Cu metal** from E **−0.6 to 0.093333333 V**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻** from E **0.094444444 to 1.2 V**
- Fe dominance at **pH 6**:
  - **Fe metal** from E **−0.6 to −0.57333333 V**
  - **[Fe(Citr)]⁻** from E **−0.57222222 to −0.033333333 V**
  - **[(Fe₂O₃)⁰·⁵(s, alpha)]** from E **−0.032222222 to 1.0944444 V**
  - **FeO₄²⁻** from E **1.0955556 to 1.2 V**
- Cu constants referenced by the solver included:
  - **[Cu(Chlo)]⁺**, log β **+0.2000**
  - **[Cu₂(Citr)₂]²⁻**, log β **+14.5000**
  - **[Cu₂(Citr)₂(OH)]³⁻**, log β **+11.2000**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻**, log β **+6.3400**
- Fe citrate constants referenced by the solver included:
  - **[Fe(Citr)]⁻**, log β **+4.8000**
  - **[Fe(Citr)]**, log β **+11.1900**
  - **[Fe(Citr)H]⁺**, log β **+12.3500**
  - **[Fe₂(Citr)₂(OH)₂]²⁻**, log β **+21.2000**
- Fe chloride constants referenced by the solver included:
  - **[Fe(Chlo)]⁺**, log β **−0.2000**
  - **[Fe(Chlo)]²⁺**, log β **+0.7800**
  - **[Fe(Chlo)₂]⁺**, log β **+2.1300**
- Citrate protonation rows used:
  - **[HCitric acid]²⁻**, cumulative log β **+5.6500**
  - **[H₂Citric acid]⁻**, cumulative log β **+10.0000**
  - **[H₃Citric acid]**, cumulative log β **+12.9000**
- Water row:
  - **[H].[OH]**, log β **−0.2200**

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[2, 10], E_V=[-0.6V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0055555556, ΔE_V=0.0011111111V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: Fe3O4 (anh.)
- Dms_3: [Fe2(Citr)2(OH)2]4-
- Dms_4: [Fe(Citr)]-
- Dms_5: Fe2+
- Dms_6: [(Fe2O3)0.5(s,alpha)]
- Dms_7: FeO42-

## Topology stats
- 7 dominant-species labels
- 7 connected regions
- 12 pairwise boundary curves
- 6 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.3V)
- Fixed sample indices: (pH=swept, E_V=sample 810)
- samples 0–324, (pH=[2, 3.8], E_V=0.3V): Fe2+ (Dms_5)
- samples 325–1440, (pH=[3.8055556, 10], E_V=0.3V): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[3.8, 3.8055556], E_V=0.3V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6, E_V=swept)
- Fixed sample indices: (pH=sample 720, E_V=swept)
- samples 0–24, (pH=6, E_V=[-0.6V, -0.57333333V]): Fe (Dms_1)
- samples 25–510, (pH=6, E_V=[-0.57222222V, -0.033333333V]): [Fe(Citr)]- (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6, E_V=[-0.57333333V, -0.57222222V])
- samples 511–1525, (pH=6, E_V=[-0.032222222V, 1.0944444V]): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=6, E_V=[-0.033333333V, -0.032222222V])
- samples 1526–1620, (pH=6, E_V=[1.0955556V, 1.2V]): FeO42- (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=6, E_V=[1.0944444V, 1.0955556V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 0.26164198
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_11
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_3
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_4
    --- DmsReg_6 {Fe2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 0.74633951
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_11
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_9
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_10
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_10, DmsRegEqJnc_12]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 8.0886728
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_6 {Fe2+} via DmsRegEq_7
    --- DmsReg_7 {FeO42-} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_8]
#### liquid
- **DmsReg_4 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.025104938
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_3
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_9
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_9, DmsRegEqJnc_3]
- **DmsReg_5 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 1.9834506
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_10
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_1
    --- DmsReg_6 {Fe2+} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_6 {Fe2+}**
  -- Measure in the solver coordinate frame: 2.044858
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_5, DmsRegEqJnc_2, DmsRegEqJnc_4, DmsRegEqJnc_6]
- **DmsReg_7 {FeO42-}**
  -- Measure in the solver coordinate frame: 1.2688272
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.29167, E_V=-0.58167V), (pH=8.15278, E_V=-0.57167V), (pH=8.15278, E_V=-0.50944V), (pH=8.29722, E_V=-0.51389V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 121, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 34, 90, 120], "t_params": [0.0, 0.40247, 0.58231, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.29167, E_V=-0.58167V), (pH=8.15278, E_V=-0.57167V), (pH=8.15278, E_V=-0.50944V), (pH=8.29722, E_V=-0.51389V)], "envelope_t": [0.0, 0.40247, 0.58231, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=8.29167, E_V=-0.58167V), (pH=8.15278, E_V=-0.57167V), (pH=8.15278, E_V=-0.50944V), (pH=8.29722, E_V=-0.51389V)], "adaptive_t": [0.0, 0.40247, 0.58231, 1.0]}
- **DmsRegEq_2: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.08611, E_V=-0.54944V), (pH=4.10833, E_V=-0.54056V), (pH=4.10833, E_V=0.18167V), (pH=4.125, E_V=0.20944V), (pH=4.15278, E_V=0.22944V), (pH=4.14167, E_V=0.25056V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "budget", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 735, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 12, 662, 690, 713, 734], "t_params": [0.0, 0.02861, 0.89185, 0.93057, 0.97149, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.08611, E_V=-0.54944V), (pH=4.10833, E_V=-0.54056V), (pH=4.10833, E_V=0.18167V), (pH=4.125, E_V=0.20944V), (pH=4.15278, E_V=0.22944V), (pH=4.14167, E_V=0.25056V)], "envelope_t": [0.0, 0.02861, 0.89185, 0.93057, 0.97149, 1.0], "adaptive_n": 6, "adaptive_pts": [(pH=4.08611, E_V=-0.54944V), (pH=4.10833, E_V=-0.54056V), (pH=4.10833, E_V=0.18167V), (pH=4.125, E_V=0.20944V), (pH=4.15278, E_V=0.22944V), (pH=4.14167, E_V=0.25056V)], "adaptive_t": [0.0, 0.02861, 0.89185, 0.93057, 0.97149, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_3: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.76944, E_V=-0.59278V), (pH=8.29167, E_V=-0.58167V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 96], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.76944, E_V=-0.59278V), (pH=8.29167, E_V=-0.58167V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.76944, E_V=-0.59278V), (pH=8.29167, E_V=-0.58167V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.29167, E_V=-0.58167V), (pH=7.66944, E_V=-0.57389V), (pH=5.39167, E_V=-0.57056V), (pH=4.80278, E_V=-0.56389V), (pH=4.08611, E_V=-0.54944V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 787, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 119, 532, 644, 786], "t_params": [0.0, 0.14796, 0.68954, 0.82957, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.29167, E_V=-0.58167V), (pH=7.66944, E_V=-0.57389V), (pH=5.39167, E_V=-0.57056V), (pH=4.80278, E_V=-0.56389V), (pH=4.08611, E_V=-0.54944V)], "envelope_t": [0.0, 0.14796, 0.68954, 0.82957, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.29167, E_V=-0.58167V), (pH=7.66944, E_V=-0.57389V), (pH=5.39167, E_V=-0.57056V), (pH=4.80278, E_V=-0.56389V), (pH=4.08611, E_V=-0.54944V)], "adaptive_t": [0.0, 0.14796, 0.68954, 0.82957, 1.0]}
- **DmsRegEq_5: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.08611, E_V=-0.54944V), (pH=3.71389, E_V=-0.54278V), (pH=3.31389, E_V=-0.53944V), (pH=2, E_V=-0.53833V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 387, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 73, 148, 386], "t_params": [0.0, 0.17845, 0.3702, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.08611, E_V=-0.54944V), (pH=3.71389, E_V=-0.54278V), (pH=3.31389, E_V=-0.53944V), (pH=2, E_V=-0.53833V)], "envelope_t": [0.0, 0.17845, 0.3702, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=4.08611, E_V=-0.54944V), (pH=3.71389, E_V=-0.54278V), (pH=3.31389, E_V=-0.53944V), (pH=2, E_V=-0.53833V)], "adaptive_t": [0.0, 0.17845, 0.3702, 1.0]}
- **DmsRegEq_6: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.61944, E_V=-0.14167V), (pH=5.71944, E_V=0.01611V), (pH=5.18611, E_V=0.10389V), (pH=4.14167, E_V=0.25056V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 800, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 304, 479, 799], "t_params": [0.0, 0.36419, 0.57962, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.61944, E_V=-0.14167V), (pH=5.71944, E_V=0.01611V), (pH=5.18611, E_V=0.10389V), (pH=4.14167, E_V=0.25056V)], "envelope_t": [0.0, 0.36419, 0.57962, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=6.61944, E_V=-0.14167V), (pH=5.71944, E_V=0.01611V), (pH=5.18611, E_V=0.10389V), (pH=4.14167, E_V=0.25056V)], "adaptive_t": [0.0, 0.36419, 0.57962, 1.0]}
- **DmsRegEq_7: Fe2+ | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.14167, E_V=0.25056V), (pH=3.80278, E_V=0.29944V), (pH=3.39167, E_V=0.36611V), (pH=2, E_V=0.60944V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 710, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 105, 239, 709], "t_params": [0.0, 0.15767, 0.34945, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.14167, E_V=0.25056V), (pH=3.80278, E_V=0.29944V), (pH=3.39167, E_V=0.36611V), (pH=2, E_V=0.60944V)], "envelope_t": [0.0, 0.15767, 0.34945, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=4.14167, E_V=0.25056V), (pH=3.80278, E_V=0.29944V), (pH=3.39167, E_V=0.36611V), (pH=2, E_V=0.60944V)], "adaptive_t": [0.0, 0.15767, 0.34945, 1.0]}
- **DmsRegEq_8: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=0.70056V), (pH=4.93611, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1363, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1362], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=0.70056V), (pH=4.93611, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=0.70056V), (pH=4.93611, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_9: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.76944, E_V=-0.59278V), (pH=8.29722, E_V=-0.51389V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 157, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 156], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.76944, E_V=-0.59278V), (pH=8.29722, E_V=-0.51389V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.76944, E_V=-0.59278V), (pH=8.29722, E_V=-0.51389V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.29722, E_V=-0.51389V), (pH=8.00278, E_V=-0.45833V), (pH=7.70833, E_V=-0.39611V), (pH=6.61944, E_V=-0.14167V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 638, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 103, 212, 637], "t_params": [0.0, 0.17433, 0.34942, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.29722, E_V=-0.51389V), (pH=8.00278, E_V=-0.45833V), (pH=7.70833, E_V=-0.39611V), (pH=6.61944, E_V=-0.14167V)], "envelope_t": [0.0, 0.17433, 0.34942, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=8.29722, E_V=-0.51389V), (pH=8.00278, E_V=-0.45833V), (pH=7.70833, E_V=-0.39611V), (pH=6.61944, E_V=-0.14167V)], "adaptive_t": [0.0, 0.17433, 0.34942, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_11: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.89722, E_V=-0.6V), (pH=8.76944, E_V=-0.59278V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 31, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 30], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.89722, E_V=-0.6V), (pH=8.76944, E_V=-0.59278V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.89722, E_V=-0.6V), (pH=8.76944, E_V=-0.59278V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_12: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=-0.34167V), (pH=6.61944, E_V=-0.14167V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00094, "resolution_tau_norm": 0.00094, "stop_epsilon": 0.00094, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 790, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 789], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=-0.34167V), (pH=6.61944, E_V=-0.14167V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=-0.34167V), (pH=6.61944, E_V=-0.14167V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_4]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.29167, E_V=-0.58167V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.08611, E_V=-0.54944V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.29722, E_V=-0.51389V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, Fe2+, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.14167, E_V=0.25056V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=-0.53833V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=0.60944V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=0.70056V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.93611, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.76944, E_V=-0.59278V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6, DmsRegEq_10, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.61944, E_V=-0.14167V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=8.89722, E_V=-0.6V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=-0.34167V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

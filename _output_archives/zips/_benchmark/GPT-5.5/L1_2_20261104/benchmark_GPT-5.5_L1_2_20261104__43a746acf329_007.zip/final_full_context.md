## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build a joint E-pH speciation picture for one shared solution containing Fe(III), Cu(II), citrate, and chloride at 25 C and ionic strength 0.1 molal. The goal is to determine the dominant Fe and Cu species over pH 2-10 while allowing Fe and Cu to compete for the same citrate and chloride pools, and to report the database constants actually used by the solver.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 11,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv"
    ],
    "elapsed_s": 46824.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build a joint E-pH speciation picture for one shared solution containing Fe(III), Cu(II), citrate, and chloride at 25 C and ionic strength 0.1 molal. The goal is to determine the dominant Fe and Cu species over pH 2-10 while allowing Fe and Cu to compete for the same citrate and chloride pools, and to report the database constants actually used by the solver.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
In a single solution containing 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate and 0.1 M chloride together at 25 C and I=0.1 m, build the joint E-pH speciation picture for this shared pot over pH 2-10 and show how Fe and Cu compete for citrate versus chloride. Identify the dominant Fe and Cu species in each pH region and reference the log K / E values the solver actually used.

## Assistant
<summary>I will run one joint E–pH/P Pourbaix-style calculation for the shared Fe(III)/Cu(II)/citrate/chloride solution, so the two metals compete for the same ligand pools in a single equilibrium model.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. The joint shared-pot Fe–Cu–citrate–chloride Pourbaix/speciation calculation completed for 25 °C, ionic-strength target 0.1, pH 2–10 and E = −0.6 to 1.2 V vs SHE.

## Result
A coupled solution was modeled with Cu=1 mM, Fe=1 mM, citrate=5 mM and chloride=0.1 M, so both metals drew from the same ligand pools. The solver produced Cu and Fe dominance maps plus a full-speciation CSV. Final classified-grid spacing was ΔpH=0.0055555556 and ΔE=0.0011111111 V. The full-speciation file reports 26,790 coarse-unrefined and 152,870 refined samples; inspected rows show `converged=1`, low residuals, and `phase_search_timed_out=0`. I did not find a separate all-cells convergence summary in the opened evidence, so the main conclusions rely on the completed deterministic verdicts and inspected convergence fields.

## Analysis
At 0.3 V, Cu changes from chloride control to citrate/hydroxo-citrate control as pH rises: [Cu(Chlo)2]- from pH 2–3.6333333, [Cu2(Citr)2(OH)]3- from 3.6388889–4.0, then [Cu2(Citr)2(OH)2]4- from 4.0055556–10. This reflects citrate deprotonation plus hydrolysis: chloride is abundant, but committed Cu(II) chloride binding is weak for [Cu(Chlo)]+, log_beta +0.2000, while Cu citrate rows include [Cu2(Citr)2]2- log_beta +14.5000, [Cu2(Citr)2(OH)]3- +11.2000, and [Cu2(Citr)2(OH)2]4- +6.3400 on the card basis. At pH 6, Cu is metal from E=−0.6 to 0.093333333 V and [Cu2(Citr)2(OH)2]4- from 0.094444444 to 1.2 V. Cu chloride dominates only in acidic/intermediate-E space; the Cu2+ / chloride / citrate junction is at pH 3.34722, E=0.34278 V.

Fe behaves differently. At 0.3 V, Fe is Fe2+ from pH 2–3.8 and [(Fe2O3)0.5(s,alpha)] from pH 3.8055556–10. At pH 6, Fe is Fe metal from −0.6 to −0.57333333 V, [Fe(Citr)]- from −0.57222222 to −0.033333333 V, [(Fe2O3)0.5(s,alpha)] from −0.032222222 to 1.0944444 V, and FeO42- from 1.0955556 to 1.2 V. Thus citrate stabilizes dissolved Fe mainly in reducing/mildly reducing conditions, while oxidizing conditions drive Fe to Fe(III) oxide. Fe citrate constants used include [Fe(Citr)]- log_beta +4.8000, [Fe(Citr)] +11.1900, [Fe(Citr)H]+ +12.3500, and [Fe2(Citr)2(OH)2]2- +21.2000. Fe chloride constants are smaller: [Fe(Chlo)]+ −0.2000, [Fe(Chlo)]2+ +0.7800, and [Fe(Chlo)2]+ +2.1300, so chloride never becomes Fe-dominant.

Ligand competition is therefore redox- and pH-dependent. Where Fe precipitates as Fe(III) oxide, citrate is available to stabilize Cu hydroxo-citrate; at pH 6 and E=0.3 V, Fe is oxide-dominated while Cu is [Cu2(Citr)2(OH)2]4-. Under reducing conditions near pH 6, Fe can hold citrate as [Fe(Citr)]- between about −0.572 and −0.033 V while Cu is metallic below about 0.094 V. At low pH/intermediate E, high chloride captures Cu as [Cu(Chlo)2]- before citrate deprotonation/hydrolysis makes citrate complexes dominant.

Key topology landmarks: Fe2+ / Fe oxide reaches pH 4.14167, E=0.25056 V and pH 2, E=0.60944 V; Fe citrate / Fe oxide runs from pH 6.61944, E=−0.14167 V to pH 4.14167, E=0.25056 V; Fe oxide / ferrate runs from pH 10, E=0.70056 V to pH 4.93611, E=1.2 V. For Cu, Cu / [Cu(Chlo)2]- reaches pH 2, E=0.13389 V, and Cu / [(Cu2O)0.5](s) / citrate meets at pH 7.025, E=0.06389 V. Sweep-limit junctions are window edges, not chemical endpoints.

The committed acid-base rows include citrate cumulative protonation log_beta +5.6500 for [HCitric acid]2-, +10.0000 for [H2Citric acid]-, and +12.9000 for [H3Citric acid]; only the single-protonation row is directly the conjugate-acid pKa under the card convention. Water [H].[OH] has log_beta −0.2200.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

This is a **joint shared-pot calculation**, so Fe, Cu, citrate, and chloride were equilibrated together rather than as isolated Fe–ligand and Cu–ligand systems.

Over pH 2–10, the main competition pattern is:

- **Cu uses chloride only under acidic/intermediate-redox conditions.** At low pH, citrate is more protonated and less competitive, while 0.1 M chloride is abundant, so Cu appears as **[Cu(Chlo)₂]⁻** in the acidic part of the map.
- **As pH rises, citrate deprotonates and hydroxo-citrate Cu complexes dominate.** Above about pH 3.6 at E = 0.3 V, Cu shifts into citrate/hydroxo-citrate species, especially **[Cu₂(Citr)₂(OH)₂]⁴⁻**, which dominates most of the circumneutral-to-alkaline oxidizing field.
- **Fe does not significantly become chloride-dominated.** The Fe–chloride constants used are much weaker than the Fe–citrate and Fe-oxide controls, so chloride never becomes the dominant Fe ligand in the reported regions.
- **Fe mainly alternates between Fe²⁺, citrate-bound Fe, Fe metal, Fe oxide, and ferrate depending on E and pH.** In mildly oxidizing conditions, Fe is driven into an Fe(III) oxide solid field, freeing citrate to stabilize Cu hydroxo-citrate complexes. Under reducing conditions, Fe can hold citrate as **[Fe(Citr)]⁻**.

At **E = 0.3 V vs SHE**:

- **Cu**
  - pH 2–3.6333333: **[Cu(Chlo)₂]⁻**
  - pH 3.6388889–4.0: **[Cu₂(Citr)₂(OH)]³⁻**
  - pH 4.0055556–10: **[Cu₂(Citr)₂(OH)₂]⁴⁻**

- **Fe**
  - pH 2–3.8: **Fe²⁺**
  - pH 3.8055556–10: **[(Fe₂O₃)⁰·⁵(s, alpha)]**, i.e. an Fe(III) oxide field

At **pH 6**:

- **Cu**
  - E = −0.6 to 0.093333333 V: **Cu metal**
  - E = 0.094444444 to 1.2 V: **[Cu₂(Citr)₂(OH)₂]⁴⁻**

- **Fe**
  - E = −0.6 to −0.57333333 V: **Fe metal**
  - E = −0.57222222 to −0.033333333 V: **[Fe(Citr)]⁻**
  - E = −0.032222222 to 1.0944444 V: **[(Fe₂O₃)⁰·⁵(s, alpha)]**
  - E = 1.0955556 to 1.2 V: **FeO₄²⁻**

Chemically, this means that **Cu wins citrate in the neutral-to-alkaline oxidizing region**, largely because Fe is removed from solution as Fe(III) oxide there. **Fe competes for citrate mainly under reducing conditions**, where dissolved **[Fe(Citr)]⁻** is stable. Chloride competes effectively only for Cu at low pH, where citrate is less deprotonated and less able to bind strongly.

## Evidence

- The calculation used the shared totals **Cu = 1 mM, Fe = 1 mM, citrate = 5 mM, chloride = 0.1 M**, at **25 °C**, ionic-strength target **I = 0.1**, over **pH 2–10** and **E = −0.6 to 1.2 V vs SHE**.
- Grid resolution reported: **ΔpH = 0.0055555556** and **ΔE = 0.0011111111 V**.
- Full-speciation output contained **26,790 coarse-unrefined** and **152,870 refined** samples; inspected rows had **`converged=1`**, low residuals, and **`phase_search_timed_out=0`**.
- Cu dominance at **E = 0.3 V**:
  - **[Cu(Chlo)₂]⁻** from pH **2–3.6333333**
  - **[Cu₂(Citr)₂(OH)]³⁻** from pH **3.6388889–4.0**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻** from pH **4.0055556–10**
- Fe dominance at **E = 0.3 V**:
  - **Fe²⁺** from pH **2–3.8**
  - **[(Fe₂O₃)⁰·⁵(s, alpha)]** from pH **3.8055556–10**
- Cu dominance at **pH 6**:
  - **Cu metal** from E **−0.6 to 0.093333333 V**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻** from E **0.094444444 to 1.2 V**
- Fe dominance at **pH 6**:
  - **Fe metal** from E **−0.6 to −0.57333333 V**
  - **[Fe(Citr)]⁻** from E **−0.57222222 to −0.033333333 V**
  - **[(Fe₂O₃)⁰·⁵(s, alpha)]** from E **−0.032222222 to 1.0944444 V**
  - **FeO₄²⁻** from E **1.0955556 to 1.2 V**
- Cu constants referenced by the solver included:
  - **[Cu(Chlo)]⁺**, log β **+0.2000**
  - **[Cu₂(Citr)₂]²⁻**, log β **+14.5000**
  - **[Cu₂(Citr)₂(OH)]³⁻**, log β **+11.2000**
  - **[Cu₂(Citr)₂(OH)₂]⁴⁻**, log β **+6.3400**
- Fe citrate constants referenced by the solver included:
  - **[Fe(Citr)]⁻**, log β **+4.8000**
  - **[Fe(Citr)]**, log β **+11.1900**
  - **[Fe(Citr)H]⁺**, log β **+12.3500**
  - **[Fe₂(Citr)₂(OH)₂]²⁻**, log β **+21.2000**
- Fe chloride constants referenced by the solver included:
  - **[Fe(Chlo)]⁺**, log β **−0.2000**
  - **[Fe(Chlo)]²⁺**, log β **+0.7800**
  - **[Fe(Chlo)₂]⁺**, log β **+2.1300**
- Citrate protonation rows used:
  - **[HCitric acid]²⁻**, cumulative log β **+5.6500**
  - **[H₂Citric acid]⁻**, cumulative log β **+10.0000**
  - **[H₃Citric acid]**, cumulative log β **+12.9000**
- Water row:
  - **[H].[OH]**, log β **−0.2200**

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
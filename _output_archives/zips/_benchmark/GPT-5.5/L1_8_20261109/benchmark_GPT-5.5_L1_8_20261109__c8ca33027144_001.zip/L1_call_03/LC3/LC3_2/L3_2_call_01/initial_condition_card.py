inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task specifies ionic strength I=0.1."},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "Task specifies 1 mM total iron."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M total chloride."},
]
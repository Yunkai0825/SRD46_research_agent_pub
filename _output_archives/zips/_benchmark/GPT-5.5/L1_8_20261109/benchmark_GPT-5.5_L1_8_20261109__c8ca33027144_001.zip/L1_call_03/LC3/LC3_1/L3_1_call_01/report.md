# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 1.78
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

E-pH Pourbaix diagram requires independent pH and potential axes, so use 2-D predominance.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
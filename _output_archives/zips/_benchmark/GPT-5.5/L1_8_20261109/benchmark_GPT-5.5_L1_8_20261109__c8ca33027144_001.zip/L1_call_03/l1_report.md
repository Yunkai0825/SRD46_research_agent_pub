## Doability
Doable: Fe–chloride Pourbaix at 25 °C and I=0.1 M is supported by the SRD-46/Atlas card assembled for this run, and the solver completed successfully.

## Result
Computed Fe at total Fe = 0.001 M and total chloride = 0.1 M over the default domain pH 0–14 and E = −1.5 to +1.5 V vs SHE. The verdict reports final classified-grid spacing ΔpH = 0.035 and ΔE = 0.015625 V; the printed reference-line indices imply a final classified grid of 400 pH samples × 192 E samples. Refinement snapshots show layer01_eff2x and layer02_eff4x, so cumulative per-axis refinement was 4×, meeting the requested ≤4× limit. The speciation table header reports n_coarse_unrefined = 4223 and n_coarse_excluded = 726, i.e. 4949 accounted coarse cells/points, satisfying the ≤5000 coarse-grid constraint. The solver produced 7 dominant labels, 7 connected regions, 10 boundary curves, 4 internal junctions, and 8 sweep-limit junctions. Inspected speciation rows show converged=1; no unconverged flag was seen in the opened evidence.

## Analysis
No soluble iron chloro-complex is a dominant Pourbaix region in this run. Chloride complexes were included, but the dominant-species catalog contains only Fe, Fe2+, Fe3+, FeO42−, aqueous [Fe(OH)3]−, Fe3O4, and alpha-Fe2O3 half-formula. Therefore a chloro-complex stability window as a dominant Fe field is not supported by the topology. The committed chloride-complex log_beta values are Fe(Chlo)+ = −0.2000, Fe(Chlo)2+ = +2.1300, and [Fe(Chlo)]2+ = +0.7800. Chemically, this means Fe(III)–chloride complexation is represented, but at 0.1 M chloride and 1 mM Fe it is not strong enough to displace free Fe3+ or oxide/hydroxide solids as the predominant Fe-bearing form.

The main soluble fields are Fe2+ and Fe3+. Along the pH reference line at E = −0.0078125 V, Fe2+ dominates from pH 0.0175 to 5.4425, then alpha-Fe2O3 dominates, with the transition bracketed between pH 5.4425 and 5.4775. The Fe2+ | Fe3+ redox boundary is DmsRegEq_1 at E = 0.7656 V from pH 0 to 1.19; Fe3+ is therefore restricted to strongly oxidizing acidic solution before ferric oxide takes over.

Along the requested +0.2 V line, the first hydroxide/oxide solid is alpha-Fe2O3, not Fe(OH)2(s) and not a chloro-complex. The relevant topology boundary is DmsRegEq_4, alpha-Fe2O3 | Fe2+, spanning from pH = 1.19, E = 0.7656 V to pH = 6.055, E = −0.1094 V. Linear reading of that compact boundary gives an approximate +0.2 V crossing near pH 4.34. This value is approximate because the exact +0.2 V grid cut was not separately printed; exact brackets were printed only for the center reference lines.

Key committed log_beta values used include water [H2O] −0.2200; Fe2+ 0.0000; Fe3+ 0.0000; Fe(OH)+ −9.8000; Fe(OH)2 −20.5000; Fe(OH)3− −29.0000; Fe(OH)4^2− −46.0000; Fe(OH)2(s) −13.5700; Fe3O4 −7.1252; alpha-Fe2O3 half-formula +0.7000; Fe metal 0.0000; and FeO4^2− 0.0000. Electrochemical constants in the card are F/(2.303RT) = 16.9044 V−1 and Nernst factor = 0.05916 V at 25 °C. Map redox boundaries include Fe | Fe2+ at E = −0.5312 V over pH 0–7.805 and Fe2+ | Fe3+ at E = 0.7656 V over pH 0–1.19.

## Artifacts
- `L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png`
- `L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv`
- `L1_call_03/thermodynamic_reference_constants.md`
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as a stable E-pH Pourbaix/speciation calculation for iron in chloride medium, not a generic 1e-6 M corrosion diagram; use 1 mM total Fe and 0.1 M total chloride at 25 °C, I=0.1 as the context for aqueous identity.
- Chloride is an active ligand in scope: retain Fe-Cl complexes as distinct from aquo/hydroxo species by oxidation state and ligand count. The inventory contains Fe(II) chloro up to FeCl+ and Fe(III) chloro up to FeCl2+; do not silently replace or merge missing higher chloride complexes such as FeCl3(aq)/FeCl4-.
- At 1 mM Fe, concentration-dependent ferric polynuclear hydrolysis complexes can be chemically distinct from mononuclear hydroxo species; keep nuclearity differences even when normalized cores look similar.
- For aqueous formula spellings with the same oxidation state, ligand/proton stoichiometry, charge, and nuclearity, treat notation variants as duplicate physical states; prefer the SRD-46 entry for consistency with the chloride/hydrolysis constants used here.
- This is a thermodynamic stability hull question, not a metastable formation-sequence question. Collapse polymorph/hydration alternatives with the same Fe-H Pourbaix core to the preferred stable representative at water activity near 1 and 25 °C rather than retaining every hydrated/anhydrous spelling.
- Carbonate and other counterion precipitates are out of scope because the stated medium is chloride and no carbonate inventory is part of the calculation; do not invent counterion solids.
- Mixed-valence magnetite and high-valent ferrate are distinct redox-chain members over the full default E-pH range; keep them if present and do not collapse them into ferric oxide/hydroxide species.
- Keep elemental Fe(s) as the metal reference/immunity phase. No gas species in this inventory impose a fugacity constraint; absent gases should not affect deduplication.

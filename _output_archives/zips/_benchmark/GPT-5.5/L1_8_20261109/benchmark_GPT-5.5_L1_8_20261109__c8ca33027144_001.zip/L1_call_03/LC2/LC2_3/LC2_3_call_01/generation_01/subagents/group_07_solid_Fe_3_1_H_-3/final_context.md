## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a stable E-pH Pourbaix/speciation calculation for iron in chloride medium, not a generic 1e-6 M corrosion diagram; use 1 mM total Fe and 0.1 M total chloride at 25 °C, I=0.1 as the context for aqueous identity.
- Chloride is an active ligand in scope: retain Fe-Cl complexes as distinct from aquo/hydroxo species by oxidation state and ligand count. The inventory contains Fe(II) chloro up to FeCl+ and Fe(III) chloro up to FeCl2+; do not silently replace or merge missing higher chloride complexes such as FeCl3(aq)/FeCl4-.
- At 1 mM Fe, concentration-dependent ferric polynuclear hydrolysis complexes can be chemically distinct from mononuclear hydroxo species; keep nuclearity differences even when normalized cores look similar.
- For aqueous formula spellings with the same oxidation state, ligand/proton stoichiometry, charge, and nuclearity, treat notation variants as duplicate physical states; prefer the SRD-46 entry for consistency with the chloride/hydrolysis constants used here.
- This is a thermodynamic stability hull question, not a metastable formation-sequence question. Collapse polymorph/hydration alternatives with the same Fe-H Pourbaix core to the preferred stable representative at water activity near 1 and 25 °C rather than retaining every hydrated/anhydrous spelling.
- Carbonate and other counterion precipitates are out of scope because the stated medium is chloride and no carbonate inventory is part of the calculation; do not invent counterion solids.
- Mixed-valence magnetite and high-valent ferrate are distinct redox-chain members over the full default E-pH range; keep them if present and do not collapse them into ferric oxide/hydroxide species.
- Keep elemental Fe(s) as the metal reference/immunity phase. No gas species in this inventory impose a fugacity constraint; absent gases should not affect deduplication.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Use SRD-46 as the preferred source when Atlas and SRD-46 describe the same aqueous Fe state: collapse Fe2+/[Fe]2+, Fe3+/[Fe]3+, mononuclear Fe(III) hydroxo notation variants, and Fe(II) HFeO2-/Fe(OH)3- notation variants to the SRD-46 representative, while keeping distinct oxidation state, chloride ligand count, ferrate, and mononuclear versus polynuclear hydrolysis complexes. For solids, keep Fe(s) and magnetite as distinct; collapse duplicate Fe(OH)2 solids to the SRD-46 Fe(OH)2(s), and for the Fe(III) oxide/hydroxide core use the stable SRD-46 alpha-Fe2O3 half-formula representative rather than hydrated Fe(OH)3/FeOOH or duplicate Atlas oxide entries for this stable hull.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 | *** |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 | *** |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 | *** |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 | — |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 | — |

## Assistant
<summary>Keeping the stable SRD-46 alpha-Fe2O3 half-formula representative and dropping hydrated/Atlas duplicate Fe(III) oxide-hydroxide alternatives per the case-specific stable-hull instruction.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
Kept: `[(Fe2O3)0.5(s,alpha)]` from SRD-46.

Rationale: For the Fe(III) oxide/hydroxide solid core, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 and Atlas duplicate oxide/hydroxide entries for the stable hull.
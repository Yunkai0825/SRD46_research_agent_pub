# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a stable E-pH Pourbaix/speciation calculation for iron in chloride medium, not a generic 1e-6 M corrosion diagram; use 1 mM total Fe and 0.1 M total chloride at 25 °C, I=0.1 as the context for aqueous identity.
- Chloride is an active ligand in scope: retain Fe-Cl complexes as distinct from aquo/hydroxo species by oxidation state and ligand count. The inventory contains Fe(II) chloro up to FeCl+ and Fe(III) chloro up to FeCl2+; do not silently replace or merge missing higher chloride complexes such as FeCl3(aq)/FeCl4-.
- At 1 mM Fe, concentration-dependent ferric polynuclear hydrolysis complexes can be chemically distinct from mononuclear hydroxo species; keep nuclearity differences even when normalized cores look similar.
- For aqueous formula spellings with the same oxidation state, ligand/proton stoichiometry, charge, and nuclearity, treat notation variants as duplicate physical states; prefer the SRD-46 entry for consistency with the chloride/hydrolysis constants used here.
- This is a thermodynamic stability hull question, not a metastable formation-sequence question. Collapse polymorph/hydration alternatives with the same Fe-H Pourbaix core to the preferred stable representative at water activity near 1 and 25 °C rather than retaining every hydrated/anhydrous spelling.
- Carbonate and other counterion precipitates are out of scope because the stated medium is chloride and no carbonate inventory is part of the calculation; do not invent counterion solids.
- Mixed-valence magnetite and high-valent ferrate are distinct redox-chain members over the full default E-pH range; keep them if present and do not collapse them into ferric oxide/hydroxide species.
- Keep elemental Fe(s) as the metal reference/immunity phase. No gas species in this inventory impose a fugacity constraint; absent gases should not affect deduplication.

## Element instructions

- **Fe**: Use SRD-46 as the preferred source when Atlas and SRD-46 describe the same aqueous Fe state: collapse Fe2+/[Fe]2+, Fe3+/[Fe]3+, mononuclear Fe(III) hydroxo notation variants, and Fe(II) HFeO2-/Fe(OH)3- notation variants to the SRD-46 representative, while keeping distinct oxidation state, chloride ligand count, ferrate, and mononuclear versus polynuclear hydrolysis complexes. For solids, keep Fe(s) and magnetite as distinct; collapse duplicate Fe(OH)2 solids to the SRD-46 Fe(OH)2(s), and for the Fe(III) oxide/hydroxide core use the stable SRD-46 alpha-Fe2O3 half-formula representative rather than hydrated Fe(OH)3/FeOOH or duplicate Atlas oxide entries for this stable hull.

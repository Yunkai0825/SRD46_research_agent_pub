# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ and [Fe]2+ denote the same aqueous Fe(II) state, so the SRD-46 representative is preferred over the Atlas notation duplicate. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ and [Fe]2+ denote the same aqueous Fe(II) state, so the SRD-46 representative is preferred over the Atlas notation duplicate. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — The mononuclear Fe(II) hydroxo complex is a distinct in-scope aqueous species with no duplicate singleton alternative. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — The neutral mononuclear Fe(II) dihydroxo complex is a distinct in-scope aqueous hydrolysis species. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are notation variants of the same mononuclear Fe(II) hydroxo aqueous state, so the SRD-46 representative is retained as instructed. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are notation variants of the same mononuclear Fe(II) hydroxo aqueous state, so the SRD-46 representative is retained as instructed. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — The tetrahydroxo Fe(II) complex is a distinct aqueous hydrolysis state and is not a duplicate of other Fe(II) species. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II) monochloro complexation is explicitly in scope as a distinct chloride-ligated aqueous state. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ describe the same aqueous Fe(III) ion, so the SRD-46 representative is kept per the Fe-specific deduplication preference. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ describe the same aqueous Fe(III) ion, so the SRD-46 representative is kept per the Fe-specific deduplication preference. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — The Atlas mononuclear Fe(III) hydroxo notation duplicates the SRD-46 aqueous state, while the dimeric ferric hydrolysis complex is distinct by nuclearity and charge and should be retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — The Atlas mononuclear Fe(III) hydroxo notation duplicates the SRD-46 aqueous state, while the dimeric ferric hydrolysis complex is distinct by nuclearity and charge and should be retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — The Atlas mononuclear Fe(III) hydroxo notation duplicates the SRD-46 aqueous state, while the dimeric ferric hydrolysis complex is distinct by nuclearity and charge and should be retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — The SRD-46 and Atlas rows describe the same mononuclear aqueous Fe(III) dihydroxo cation, so the SRD-46 representative is retained per the Fe aqueous duplicate preference. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — The SRD-46 and Atlas rows describe the same mononuclear aqueous Fe(III) dihydroxo cation, so the SRD-46 representative is retained per the Fe aqueous duplicate preference. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — The mononuclear Fe(III) tetrahydroxo complex is an in-scope aqueous hydrolysis species distinct by oxidation state and charge. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III) monochloro complexation is explicitly in scope and distinct from aquo/hydroxo and other chloro ligand counts. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Fe(III) dichloro complexation is explicitly in scope and distinct by chloride ligand count. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — The trinuclear ferric hydrolysis complex is chemically distinct from mononuclear hydroxo species at the stated Fe concentration. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate is a distinct high-valent redox-chain member and should not be collapsed into ferric oxide or hydroxide species. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental iron is the required metal reference/immunity phase. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite is a distinct mixed-valence solid redox-chain member and is retained rather than merged with ferric oxide or hydroxide phases. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas hydrated Fe(OH)2 and SRD-46 Fe(OH)2(s) represent the same Fe(II) hydroxide solid core, and the Fe-specific instructions prefer the SRD-46 representative. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas hydrated Fe(OH)2 and SRD-46 Fe(OH)2(s) represent the same Fe(II) hydroxide solid core, and the Fe-specific instructions prefer the SRD-46 representative. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — For the Fe(III) oxide/hydroxide solid core in a 25 °C stable Pourbaix hull, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 forms and Atlas duplicate oxide/hydroxide entries. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — For the Fe(III) oxide/hydroxide solid core in a 25 °C stable Pourbaix hull, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 forms and Atlas duplicate oxide/hydroxide entries. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — For the Fe(III) oxide/hydroxide solid core in a 25 °C stable Pourbaix hull, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 forms and Atlas duplicate oxide/hydroxide entries. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — For the Fe(III) oxide/hydroxide solid core in a 25 °C stable Pourbaix hull, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 forms and Atlas duplicate oxide/hydroxide entries. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — For the Fe(III) oxide/hydroxide solid core in a 25 °C stable Pourbaix hull, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 forms and Atlas duplicate oxide/hydroxide entries. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride is an active ligand in the specified medium and the chloride ion is required in scope. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent/reference aqueous species and remains in scope for the Fe-chloride Pourbaix/speciation calculation. |

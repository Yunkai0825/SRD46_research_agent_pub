# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All 13 singleton entries were kept. They are valid in-scope species for the iron–chloride E–pH calculation, including water/chloride basis species, distinct Fe(II)/Fe(III) hydroxo and chloro complexes, the ferric polynuclear hydrolysis complex, ferrate, elemental iron, and mixed-valence magnetite.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a stable E-pH Pourbaix/speciation calculation for iron in chloride medium, not a generic 1e-6 M corrosion diagram; use 1 mM total Fe and 0.1 M total chloride at 25 °C, I=0.1 as the context for aqueous identity.
- Chloride is an active ligand in scope: retain Fe-Cl complexes as distinct from aquo/hydroxo species by oxidation state and ligand count. The inventory contains Fe(II) chloro up to FeCl+ and Fe(III) chloro up to FeCl2+; do not silently replace or merge missing higher chloride complexes such as FeCl3(aq)/FeCl4-.
- At 1 mM Fe, concentration-dependent ferric polynuclear hydrolysis complexes can be chemically distinct from mononuclear hydroxo species; keep nuclearity differences even when normalized cores look similar.
- For aqueous formula spellings with the same oxidation state, ligand/proton stoichiometry, charge, and nuclearity, treat notation variants as duplicate physical states; prefer the SRD-46 entry for consistency with the chloride/hydrolysis constants used here.
- This is a thermodynamic stability hull question, not a metastable formation-sequence question. Collapse polymorph/hydration alternatives with the same Fe-H Pourbaix core to the preferred stable representative at water activity near 1 and 25 °C rather than retaining every hydrated/anhydrous spelling.
- Carbonate and other counterion precipitates are out of scope because the stated medium is chloride and no carbonate inventory is part of the calculation; do not invent counterion solids.
- Mixed-valence magnetite and high-valent ferrate are distinct redox-chain members over the full default E-pH range; keep them if present and do not collapse them into ferric oxide/hydroxide species.
- Keep elemental Fe(s) as the metal reference/immunity phase. No gas species in this inventory impose a fugacity constraint; absent gases should not affect deduplication.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Use SRD-46 as the preferred source when Atlas and SRD-46 describe the same aqueous Fe state: collapse Fe2+/[Fe]2+, Fe3+/[Fe]3+, mononuclear Fe(III) hydroxo notation variants, and Fe(II) HFeO2-/Fe(OH)3- notation variants to the SRD-46 representative, while keeping distinct oxidation state, chloride ligand count, ferrate, and mononuclear versus polynuclear hydrolysis complexes. For solids, keep Fe(s) and magnetite as distinct; collapse duplicate Fe(OH)2 solids to the SRD-46 Fe(OH)2(s), and for the Fe(III) oxide/hydroxide core use the stable SRD-46 alpha-Fe2O3 half-formula representative rather than hydrated Fe(OH)3/FeOOH or duplicate Atlas oxide entries for this stable hull.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Chlo)2]+` | SRD-46 | +1 | 62.192 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>All supplied singleton species are in scope for the stated Fe–chloride E–pH calculation. No singleton belongs to an excluded alternative solid branch, and distinct chloride, hydroxo, polynuclear, ferrate, metal, and magnetite states are retained.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
All 13 singleton entries were kept. They are valid in-scope species for the iron–chloride E–pH calculation, including water/chloride basis species, distinct Fe(II)/Fe(III) hydroxo and chloro complexes, the ferric polynuclear hydrolysis complex, ferrate, elemental iron, and mixed-valence magnetite.

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Use SRD-46 as the preferred source when Atlas and SRD-46 describe the same aqueous Fe state: collapse Fe2+/[Fe]2+, Fe3+/[Fe]3+, mononuclear Fe(III) hydroxo notation variants, and Fe(II) HFeO2-/Fe(OH)3- notation variants to the SRD-46 representative, while keeping distinct oxidation state, chloride ligand count, ferrate, and mononuclear versus polynuclear hydrolysis complexes. For solids, keep Fe(s) and magnetite as distinct; collapse duplicate Fe(OH)2 solids to the SRD-46 Fe(OH)2(s), and for the Fe(III) oxide/hydroxide core use the stable SRD-46 alpha-Fe2O3 half-formula representative rather than hydrated Fe(OH)3/FeOOH or duplicate Atlas oxide entries for this stable hull.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 | — |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 | *** |
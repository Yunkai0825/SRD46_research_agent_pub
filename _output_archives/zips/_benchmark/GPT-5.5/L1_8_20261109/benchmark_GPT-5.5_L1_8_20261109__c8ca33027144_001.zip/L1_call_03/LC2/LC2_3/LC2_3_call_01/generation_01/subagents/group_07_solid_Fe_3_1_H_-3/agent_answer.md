Kept: `[(Fe2O3)0.5(s,alpha)]` from SRD-46.

Rationale: For the Fe(III) oxide/hydroxide solid core, the stable SRD-46 alpha-Fe2O3 half-formula representative is preferred over hydrated FeOOH/Fe(OH)3 and Atlas duplicate oxide/hydroxide entries for the stable hull.
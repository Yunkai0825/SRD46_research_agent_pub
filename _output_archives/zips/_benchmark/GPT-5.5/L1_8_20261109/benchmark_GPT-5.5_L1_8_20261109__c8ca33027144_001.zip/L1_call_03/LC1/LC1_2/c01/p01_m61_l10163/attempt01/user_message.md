[Purpose: Build an E-pH Pourbaix diagram for iron in chloride media and extract the soluble chloro-complex stability window and first hydroxide/oxide precipitation point. This is one of three separate single-metal systems to be compared under identical chloride, metal loading, temperature, and ionic-strength conditions.]
[Tasks:
For iron at 1 mM total metal in 0.1 M total chloride, 25 C and ionic strength I=0.1 m, generate an E-pH Pourbaix diagram over the full default E and pH axis ranges. Preserve those chemical conditions and full axis ranges, but ensure the coarse grid uses at most 5,000 total points as the product of the pH and E sweep-axis n_points; choose fewer grid points rather than narrowing the domain. Ensure cumulative per-axis boundary refinement does not exceed 4x, meaning factor raised to n_layers must be no greater than 4. State the grid dimensions and refinement settings used. Report which soluble iron chloro-complex region is present and its pH/E extent if supported by the topology, identify the pH at which the first hydroxide or oxide solid appears along the +0.2 V line, and include the actual log K and redox E values committed and used by the solver.
]
[Pair: pair_key=`m61_l10163`, metal_id=61, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10163_beta840_net29792`
[Screen report]
# Eq-map screen — m61_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10163_beta840_net29792` | `[M] + [L]^2 <=> [ML2]` | vlm_177402@(25.0,0.0) = K+2.130 | 2 | +0.750 / +1.440 / +1.440 / +2.130 | vlm_177402@(25.0,0.0) = K+2.130 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal61_ligand10163_beta812_net29792` | `[M] + [L] <=> [ML]` | vlm_177390@(25.0,0.1) = K+0.780 | 7 | +0.630 / +0.780 / +0.861 / +1.480 | vlm_177390@(25.0,0.1) = K+0.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

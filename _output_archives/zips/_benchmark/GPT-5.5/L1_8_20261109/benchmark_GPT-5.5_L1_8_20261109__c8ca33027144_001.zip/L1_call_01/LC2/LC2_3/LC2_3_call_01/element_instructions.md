# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: build a thermodynamic E-pH Pourbaix diagram for Cu in chloride media and extract soluble chloro-complex stability plus first hydroxide/oxide precipitation; treat this as a stable-phase speciation/corrosion-style diagram, not an electrodeposition or kinetic phase-formation inventory.
- Aqueous identity is governed by the stated conditions, 1 mM total Cu and 0.1 M total chloride at 25 °C and I=0.1 m; do not apply the 1e-6 M corrosion convention. Chloride complexes, hydroxo complexes, and listed polynuclear complexes are potentially real at this loading and must not be merged just because their normalized Cu:ligand formula matches a monomer.
- Chloride is the explicit supporting ligand/counterion: soluble Cu chloro-complexes, CuCl(s), and basic copper chloride solids are in scope. Carbonates and unlisted counterion solids are out of scope.
- For solids at 25 °C in liquid water, keep physically distinct oxide, hydroxide, cuprous chloride, basic chloride, and metal phases when they represent different precipitates; do not collapse CuO(s) and Cu(OH)2(s) merely because the chosen basis gives the same normalized Cu/H core.
- Mixed nuclearity and mixed stoichiometry matter here: mononuclear and polynuclear aqueous complexes such as CuCl2-/Cu2Cl4^2- or CuOH+/Cu2(OH)2^2+ can have different concentration dependences at 1 mM Cu and should be retained as distinct competitors.
- The phase question is which thermodynamic regions are stable on the Pourbaix hull; collapse only true duplicate descriptions of the same physical state. When Atlas and SRD-46 provide the same physical Cu species, prefer the SRD-46 entry because the chloride-complex/solubility network is SRD-centered; retain Atlas-only species needed to span the full pH/E range.
- Elemental Cu(s) is the required metal reference and must stay. No gases are part of the stated Cu/Cl/H2O system unless already present with an equilibrium constraint.
- Diagram-changing ambiguity to carry forward: the inventory contains a limited Cu(II) chloro-complex set, apparently only CuCl+ among Cu(II) chloride complexes; do not invent missing higher Cu(II) chloride complexes during deduplication, but do not silently reinterpret existing species to cover them.

## Element instructions

- **Cu**: Keep all chemically distinct Cu aqueous chloro, hydroxo, and polynuclear complexes and all distinct Cu solid classes relevant to chloride media, including CuCl(s), basic copper chloride, Cu metal, Cu2O, CuO, and Cu(OH)2 when represented as separate physical precipitates. For true duplicate descriptions of the same physical species from Atlas and SRD-46—free Cu+/Cu2+ and duplicate Cu2O, CuO, or Cu(OH)2 labels—prefer the SRD-46 entry; keep Atlas-only high-pH hydroxo species and the Atlas Cu metal reference.

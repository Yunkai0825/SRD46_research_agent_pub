# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are duplicate descriptions of the same aqueous cuprous ion, so the SRD-46 entry is kept as preferred for true duplicates. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are duplicate descriptions of the same aqueous cuprous ion, so the SRD-46 entry is kept as preferred for true duplicates. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — The neutral cuprous chloro-complex is a chemically distinct soluble chloride complex and must be retained. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Kept both SRD-46 aqueous chloro-complexes because mononuclear and polynuclear Cu(I) chloride species have distinct concentration dependences and are explicitly in scope for chloride-media speciation. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Kept both SRD-46 aqueous chloro-complexes because mononuclear and polynuclear Cu(I) chloride species have distinct concentration dependences and are explicitly in scope for chloride-media speciation. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — The trichlorocuprate(I) complex is a distinct soluble chloride complex with its own charge and ligand stoichiometry. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are duplicate descriptions of the same aqueous cupric ion, so the SRD-46 entry is kept per the SRD-preference rule. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are duplicate descriptions of the same aqueous cupric ion, so the SRD-46 entry is kept per the SRD-preference rule. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous hydroxo complexes are chemically distinct by nuclearity and charge, and polynuclear Cu hydroxo species are in scope for the stated chloride-media Pourbaix calculation. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous hydroxo complexes are chemically distinct by nuclearity and charge, and polynuclear Cu hydroxo species are in scope for the stated chloride-media Pourbaix calculation. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Aqueous Cu(OH)2 is a distinct Cu(II) hydroxo species relevant to first hydroxide/oxide precipitation equilibria. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — The Atlas high-pH hydroxo species HCuO2- is Atlas-only coverage needed to span the alkaline Pourbaix range. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — The Atlas high-pH hydroxo species CuO2^2- is Atlas-only coverage needed to span the alkaline Pourbaix range. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — The cupric monochloro complex CuCl+ is the available Cu(II) chloride complex and is in scope for chloride media. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — The trinuclear Cu(II) hydroxo complex has distinct nuclearity and concentration dependence and should not be merged with mononuclear species. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental copper is the required metal reference phase for the Pourbaix diagram. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows describe the same physical Cu2O solid, and the plan/case instructions prefer the SRD-46 entry over the Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows describe the same physical Cu2O solid, and the plan/case instructions prefer the SRD-46 entry over the Atlas duplicate. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is an in-scope cuprous chloride precipitate in chloride media. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO(s) and Cu(OH)2(s) are distinct precipitates relevant to chloride Pourbaix chemistry, and for each true Atlas/SRD duplicate physical species the SRD-46 entry is preferred. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO(s) and Cu(OH)2(s) are distinct precipitates relevant to chloride Pourbaix chemistry, and for each true Atlas/SRD duplicate physical species the SRD-46 entry is preferred. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO(s) and Cu(OH)2(s) are distinct precipitates relevant to chloride Pourbaix chemistry, and for each true Atlas/SRD duplicate physical species the SRD-46 entry is preferred. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO(s) and Cu(OH)2(s) are distinct precipitates relevant to chloride Pourbaix chemistry, and for each true Atlas/SRD duplicate physical species the SRD-46 entry is preferred. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — The basic copper chloride solid is an in-scope distinct chloride-bearing precipitate relevant to the Cu/Cl/H2O system. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride is the explicit supporting ligand/counterion at 0.1 M total chloride and is required in the aqueous basis. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent/basis species for the 25 °C aqueous Cu/Cl/H2O Pourbaix calculation and is in scope. |

# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All 12 singleton entries are retained. They are in scope for the Cu/Cl/H₂O Pourbaix calculation, and none is a within-group duplicate or an excluded phase branch.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: build a thermodynamic E-pH Pourbaix diagram for Cu in chloride media and extract soluble chloro-complex stability plus first hydroxide/oxide precipitation; treat this as a stable-phase speciation/corrosion-style diagram, not an electrodeposition or kinetic phase-formation inventory.
- Aqueous identity is governed by the stated conditions, 1 mM total Cu and 0.1 M total chloride at 25 °C and I=0.1 m; do not apply the 1e-6 M corrosion convention. Chloride complexes, hydroxo complexes, and listed polynuclear complexes are potentially real at this loading and must not be merged just because their normalized Cu:ligand formula matches a monomer.
- Chloride is the explicit supporting ligand/counterion: soluble Cu chloro-complexes, CuCl(s), and basic copper chloride solids are in scope. Carbonates and unlisted counterion solids are out of scope.
- For solids at 25 °C in liquid water, keep physically distinct oxide, hydroxide, cuprous chloride, basic chloride, and metal phases when they represent different precipitates; do not collapse CuO(s) and Cu(OH)2(s) merely because the chosen basis gives the same normalized Cu/H core.
- Mixed nuclearity and mixed stoichiometry matter here: mononuclear and polynuclear aqueous complexes such as CuCl2-/Cu2Cl4^2- or CuOH+/Cu2(OH)2^2+ can have different concentration dependences at 1 mM Cu and should be retained as distinct competitors.
- The phase question is which thermodynamic regions are stable on the Pourbaix hull; collapse only true duplicate descriptions of the same physical state. When Atlas and SRD-46 provide the same physical Cu species, prefer the SRD-46 entry because the chloride-complex/solubility network is SRD-centered; retain Atlas-only species needed to span the full pH/E range.
- Elemental Cu(s) is the required metal reference and must stay. No gases are part of the stated Cu/Cl/H2O system unless already present with an equilibrium constraint.
- Diagram-changing ambiguity to carry forward: the inventory contains a limited Cu(II) chloro-complex set, apparently only CuCl+ among Cu(II) chloride complexes; do not invent missing higher Cu(II) chloride complexes during deduplication, but do not silently reinterpret existing species to cover them.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Keep all chemically distinct Cu aqueous chloro, hydroxo, and polynuclear complexes and all distinct Cu solid classes relevant to chloride media, including CuCl(s), basic copper chloride, Cu metal, Cu2O, CuO, and Cu(OH)2 when represented as separate physical precipitates. For true duplicate descriptions of the same physical species from Atlas and SRD-46—free Cu+/Cu2+ and duplicate Cu2O, CuO, or Cu(OH)2 labels—prefer the SRD-46 entry; keep Atlas-only high-pH hydroxo species and the Atlas Cu metal reference.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -28.253 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 14.142 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |

## Assistant
<summary>All 12 singleton species are in scope for the Cu/Cl/H2O Pourbaix calculation and should be retained. No duplicate or excluded phase branch is present among these singleton entries.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
All 12 singleton entries are retained. They are in scope for the Cu/Cl/H₂O Pourbaix calculation, and none is a within-group duplicate or an excluded phase branch.

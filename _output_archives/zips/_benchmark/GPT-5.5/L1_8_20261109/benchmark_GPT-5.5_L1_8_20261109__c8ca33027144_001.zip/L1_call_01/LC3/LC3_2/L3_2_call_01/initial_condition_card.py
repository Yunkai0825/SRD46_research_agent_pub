inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task fixes ionic strength at I=0.1."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM total copper; element total used for redox Pourbaix axis."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task states 0.1 M total chloride."},
]
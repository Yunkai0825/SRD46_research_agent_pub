# Solver report (Pourbaix)

## System
- Components: [Cu, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.5V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.04375, ΔE_V=0.0125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Chlo)2]-
- Dms_5: [Cu((OH))1.5(Chloride ion)0.5](s)
- Dms_6: Cu2+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 9 pairwise boundary curves
- 4 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.00625V)
- Fixed sample indices: (pH=swept, E_V=sample 119)
- samples 0–186, (pH=[0.021875, 8.159375], E_V=-0.00625V): Cu (Dms_1)
- samples 187–256, (pH=[8.203125, 11.221875], E_V=-0.00625V): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[8.159375, 8.203125], E_V=-0.00625V)
- samples 257–319, (pH=[11.265625, 13.978125], E_V=-0.00625V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[11.221875, 11.265625], E_V=-0.00625V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7.021875, E_V=swept)
- Fixed sample indices: (pH=sample 160, E_V=swept)
- samples 0–124, (pH=7.021875, E_V=[-1.49375V, 0.05625V]): Cu (Dms_1)
- samples 125–139, (pH=7.021875, E_V=[0.06875V, 0.24375V]): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=7.021875, E_V=[0.05625V, 0.06875V])
- samples 140–239, (pH=7.021875, E_V=[0.25625V, 1.49375V]): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7.021875, E_V=[0.24375V, 0.25625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 20.848516
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_6
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5, DmsRegEqJnc_3]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 1.4295313
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_6
    --- DmsReg_3 {CuO(s)} via DmsRegEq_7
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5, DmsRegEqJnc_10, DmsRegEqJnc_8, DmsRegEqJnc_6]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 10.611563
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_7
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_8, DmsRegEqJnc_9]
- **DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)}**
  -- Measure in the solver coordinate frame: 1.7248438
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_8
    --- DmsReg_3 {CuO(s)} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_6 {Cu2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_6, DmsRegEqJnc_9, DmsRegEqJnc_2, DmsRegEqJnc_4]
#### liquid
- **DmsReg_5 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 1.3425781
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_2
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_4
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_3
    --- DmsReg_6 {Cu2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_6 {Cu2+}**
  -- Measure in the solver coordinate frame: 6.0429688
  -- Neighboring regions:
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_1
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.35V), (pH=5.425, E_V=0.35V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 125, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 124], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.35V), (pH=5.425, E_V=0.35V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.35V), (pH=5.425, E_V=0.35V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.125V), (pH=6.0375, E_V=0.125V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 139, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 138], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.125V), (pH=6.0375, E_V=0.125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.125V), (pH=6.0375, E_V=0.125V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0812, E_V=0.2875V), (pH=5.425, E_V=0.35V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 21, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 20], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0812, E_V=0.2875V), (pH=5.425, E_V=0.35V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.0812, E_V=0.2875V), (pH=5.425, E_V=0.35V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_4: [(Cu2O)0.5](s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0375, E_V=0.125V), (pH=6.0812, E_V=0.2875V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 15, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 14], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0375, E_V=0.125V), (pH=6.0812, E_V=0.2875V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.0375, E_V=0.125V), (pH=6.0812, E_V=0.2875V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: [Cu((OH))1.5(Chloride ion)0.5](s) | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.425, E_V=0.35V), (pH=5.25, E_V=0.4V), (pH=5.25, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 8, 96], "t_params": [0.0, 0.142, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.425, E_V=0.35V), (pH=5.25, E_V=0.4V), (pH=5.25, E_V=1.5V)], "envelope_t": [0.0, 0.142, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.425, E_V=0.35V), (pH=5.25, E_V=0.4V), (pH=5.25, E_V=1.5V)], "adaptive_t": [0.0, 0.142, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_6: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.35V), (pH=6.0375, E_V=0.125V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 221, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 220], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.35V), (pH=6.0375, E_V=0.125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.35V), (pH=6.0375, E_V=0.125V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.1625V), (pH=6.6937, E_V=0.2625V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 202, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 201], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.1625V), (pH=6.6937, E_V=0.2625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.1625V), (pH=6.6937, E_V=0.2625V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [(Cu2O)0.5](s) | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.6937, E_V=0.2625V), (pH=6.0812, E_V=0.2875V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 17, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 16], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.6937, E_V=0.2625V), (pH=6.0812, E_V=0.2875V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.6937, E_V=0.2625V), (pH=6.0812, E_V=0.2875V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_9: CuO(s) | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.6937, E_V=0.2625V), (pH=6.6937, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 100, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 99], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.6937, E_V=0.2625V), (pH=6.6937, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.6937, E_V=0.2625V), (pH=6.6937, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.35V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu((OH))1.5(Chloride ion)0.5](s), Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.425, E_V=0.35V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.125V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu((OH))1.5(Chloride ion)0.5](s), Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=5.25, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0375, E_V=0.125V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Chlo)2]-, [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0812, E_V=0.2875V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.35V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.1625V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=6.6937, E_V=1.5V)
#### three solids
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_7, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.6937, E_V=0.2625V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]

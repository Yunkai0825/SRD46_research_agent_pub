inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C specified by the task."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task specifies ionic strength I=0.1 m; represented on the catalog ionic-strength handle."},
  {"id": "Zn", "lhs": lambda s: s.total["Zn"], "value": 1e-3, "basis": "known", "note": "Task specifies 1 mM total zinc; element total is used for redox-axis Pourbaix calculation."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M total chloride."},
]
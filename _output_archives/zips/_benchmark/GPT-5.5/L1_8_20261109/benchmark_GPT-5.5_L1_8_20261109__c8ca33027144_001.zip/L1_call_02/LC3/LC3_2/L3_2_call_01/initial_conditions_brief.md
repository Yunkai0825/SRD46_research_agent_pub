# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C specified by the task.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task specifies ionic strength I=0.1 m; represented on the catalog ionic-strength handle.
  {"lhs": lambda s: s.total["Zn"]          , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total zinc; element total is used for redox-axis Pourbaix calculation.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M total chloride.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix diagram pH coordinate; full default pH range to be set by L3_3, not pinned in initial conditions.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix diagram redox-potential coordinate; full default E range to be set by L3_3, not pinned in initial conditions.'},
]

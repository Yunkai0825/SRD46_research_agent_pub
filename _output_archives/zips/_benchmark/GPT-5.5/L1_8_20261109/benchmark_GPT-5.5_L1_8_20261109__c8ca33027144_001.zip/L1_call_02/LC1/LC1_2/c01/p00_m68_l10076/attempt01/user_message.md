[Purpose: Build an E-pH Pourbaix diagram for zinc in chloride media and extract the soluble chloro-complex stability window and first hydroxide/oxide precipitation point. This is one of three separate single-metal systems to be compared under identical chloride, metal loading, temperature, and ionic-strength conditions.]
[Tasks:
For zinc at 1 mM total metal in 0.1 M total chloride, 25 C and ionic strength I=0.1 m, generate an E-pH Pourbaix diagram over the full default E and pH axis ranges. Preserve those chemical conditions and full axis ranges, but ensure the coarse grid uses at most 5,000 total points as the product of the pH and E sweep-axis n_points; choose fewer grid points rather than narrowing the domain. Ensure cumulative per-axis boundary refinement does not exceed 4x, meaning factor raised to n_layers must be no greater than 4. State the grid dimensions and refinement settings used. Report which soluble zinc chloro-complex region is present and its pH/E extent if supported by the topology, identify the pH at which the first hydroxide or oxide solid appears along the +0.2 V line, and include the actual log K and redox E values committed and used by the solver.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: equilibrium E-pH Pourbaix stability diagram for Zn in chloride media, not corrosion-product formation kinetics; use stable phases, not all possible polymorphs.
- Conditions: 1 mM total Zn, 0.1 M total chloride, 25 C, I=0.1; the 1e-6 M corrosion convention is not the governing concentration.
- Aqueous identity: chloride complexes are central and in scope; Chlo/Chloride ion denotes the same chloride ligand L1. Prefer a single internally consistent SRD-46 aqueous set for duplicate Zn hydrolysis/protonation spellings because SRD supplies the chloride complexes used here.
- Solids: ambient aqueous water activity makes both ZnO and Zn(OH)2 solid classes relevant to the requested first hydroxide/oxide precipitation point; do not merge oxide and hydroxide labels merely because the reduced core is Zn:H = 1:-2.
- Polymorph/activity question: this asks which phase is stable on the hull, so collapse ZnO activity variants and Zn(OH)2 polymorph/amorphous variants to the lowest aligned-mu representative within each solid class.
- Counterions: chloride-bearing zinc solid chemistry is in scope at 0.1 M chloride; carbonates and other absent counterion solids are out of scope.
- References: elemental Zn(s) is the required metal reference and must stay; no gas fugacity branch is implied by this single-metal chloride Pourbaix task.

## Element instructions

- **Zn**: For duplicate aqueous Zn species, keep the SRD-46 notation/constant set for Zn2+ and hydroxo complexes where an SRD counterpart exists, and keep the SRD chloride complexes because chloride stability is the target of the calculation. For solids, retain Zn(s) and the SRD basic zinc hydroxychloride solid; keep one lowest-mu stable representative each for ZnO and Zn(OH)2 while treating polymorphs, active/inactive labels, and source-only repeats within those classes as duplicates.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    301.83
- elapsed_s (total):  301.83
- llm_iterations:     22
- llm_tool_calls:     15

- n_groups:           12
- n_multi_groups:     5
- n_singletons:       7
- n_decisions:        12
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Zn2+ and [Zn]2+ are the same aqueous Zn(II) ion, and the plan/instructions prefer the internally consistent SRD-46 notation set where available. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | The two aqueous +1 mononuclear Zn hydroxo entries are the same physical species in different notation, and the case instructions prefer the SRD-46 Zn hydrolysis set where available. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | The SRD-46 hydroxo notation is kept as the single representative of the duplicate aqueous Zn hydrolysis species, consistent with the Zn instructions to prefer the internally consistent SRD aqueous set. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | [ZnO2]2- and [Zn(OH)4]2- are duplicate notations for the same aqueous zincate species under the water-aligned core, so the SRD-46 hydroxo notation/constant set is kept. |
| solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` [Atlas], `Zn(OH)2 (alpha)` [Atlas] | Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is an in-scope aqueous basis species for the ambient aqueous Pourbaix calculation and has no duplicate in this singleton batch. |
| aqueous | `L1:1` | yes | The chloride ligand is central to the chloride-media calculation and this SRD-46 chloride ion singleton should be retained. |
| aqueous | `Zn$+2:1 H:-2` | yes | The neutral aqueous zinc hydroxo species is part of the SRD-46 hydrolysis set and has no singleton-branch exclusion. |
| aqueous | `Zn$+2:1 L1:1` | yes | The monohalide zinc chloride complex is central to the chloride stability calculation and is retained from SRD-46. |
| aqueous | `Zn$+2:1 L1:2` | yes | The neutral zinc dichloride aqueous complex is central to the chloride stability calculation and is retained from SRD-46. |
| solid | `Zn$+0:1` | yes | Elemental Zn(s) is the required metallic zinc reference phase and must be retained. |
| solid | `Zn$+2:2 L1:1 H:-3` | yes | The SRD basic zinc hydroxychloride solid is chloride-bearing zinc solid chemistry in scope at 0.1 M chloride and has no duplicate in this singleton batch. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: Zn2+ and [Zn]2+ are the same aqueous Zn(II) ion, and the plan/instructions prefer the internally consistent SRD-46 notation set where available. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: The two aqueous +1 mononuclear Zn hydroxo entries are the same physical species in different notation, and the case instructions prefer the SRD-46 Zn hydrolysis set where available. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: The SRD-46 hydroxo notation is kept as the single representative of the duplicate aqueous Zn hydrolysis species, consistent with the Zn instructions to prefer the internally consistent SRD aqueous set. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: [ZnO2]2- and [Zn(OH)4]2- are duplicate notations for the same aqueous zincate species under the water-aligned core, so the SRD-46 hydroxo notation/constant set is kept. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `ZnO` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Following the case-specific instruction to retain one lowest-aligned-mu stable representative for each relevant solid class, ZnO variants collapse to Atlas ZnO (inactive) and Zn(OH)2 polymorphs/amorphous entries collapse to Atlas Zn(OH)2 (alpha). |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 40b686d59a5d47d69f3cd5b3fec4a440
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Committed final Zn deduplication for the chloride Pourbaix calculation. The retained set keeps the SRD-46 aqueous Zn(II), hydroxo, and chloride-complex basis needed for 1 mM Zn / 0.1 M chloride speciation, retains Zn(s), keeps one stable representative each for ZnO and Zn(OH)2, and keeps the in-scope basic zinc hydroxychloride solid.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_8_20261108_rerun2\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

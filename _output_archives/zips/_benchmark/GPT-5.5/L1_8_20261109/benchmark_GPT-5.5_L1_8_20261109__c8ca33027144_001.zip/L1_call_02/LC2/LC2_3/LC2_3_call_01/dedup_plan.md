# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: equilibrium E-pH Pourbaix stability diagram for Zn in chloride media, not corrosion-product formation kinetics; use stable phases, not all possible polymorphs.
- Conditions: 1 mM total Zn, 0.1 M total chloride, 25 C, I=0.1; the 1e-6 M corrosion convention is not the governing concentration.
- Aqueous identity: chloride complexes are central and in scope; Chlo/Chloride ion denotes the same chloride ligand L1. Prefer a single internally consistent SRD-46 aqueous set for duplicate Zn hydrolysis/protonation spellings because SRD supplies the chloride complexes used here.
- Solids: ambient aqueous water activity makes both ZnO and Zn(OH)2 solid classes relevant to the requested first hydroxide/oxide precipitation point; do not merge oxide and hydroxide labels merely because the reduced core is Zn:H = 1:-2.
- Polymorph/activity question: this asks which phase is stable on the hull, so collapse ZnO activity variants and Zn(OH)2 polymorph/amorphous variants to the lowest aligned-mu representative within each solid class.
- Counterions: chloride-bearing zinc solid chemistry is in scope at 0.1 M chloride; carbonates and other absent counterion solids are out of scope.
- References: elemental Zn(s) is the required metal reference and must stay; no gas fugacity branch is implied by this single-metal chloride Pourbaix task.

## Doability
Doable: Zn/chloride at 25 °C and I=0.1 M is a supported `pourbaix_sweep`; the requested chemical conditions and full default pH/E domain were preserved.

## Result
Computed a Zn Pourbaix map for 1 mM total Zn and 0.1 M total chloride, potential vs SHE, over pH 0–14 and E = −1.5 to +1.5 V. The final classified-grid spacing was ΔpH = 0.035 and ΔE = 0.015625 V, corresponding to 400 pH samples × 192 E samples. This is consistent with a coarse grid of 100 × 48 = 4,800 points and cumulative 4× per-axis refinement. The topology verdict reports 4 dominant-species regions, 5 boundary curves, 2 internal junctions, and 4 sweep-limit junctions. No unconverged cells were flagged in the supplied verdict; conclusions below are taken from the final classified topology and reference-line cuts.

## Analysis
No soluble zinc chloro-complex became a dominant Pourbaix region under these conditions. The included aqueous chloride complexes were `[Zn(Chlo)]+` with cumulative `log_beta = -0.4000` and `[Zn(Chlo)2]` with `log_beta = -0.3000`, but the dominant-species catalog contains only Zn metal, Zn²⁺, ZnO inactive, and `[Zn(OH)4]2-`. Thus chloride complexation is present in the thermodynamic model but too weak, at 0.1 M chloride and 1 mM Zn, to control Zn predominance anywhere in the pH/E window.

At oxidizing or mildly reducing potentials, the acidic-to-neutral dissolved Zn field is Zn²⁺. The Zn²⁺/ZnO inactive boundary is non-redox and nearly vertical at pH ≈ 6.58, extending from E = −0.8594 V to +1.5 V. Therefore, along the requested +0.2 V line, the first hydroxide/oxide solid appears at pH ≈ 6.58, where Zn²⁺ gives way to ZnO inactive. Chemically, this is the hydrolysis/precipitation transition: increasing pH lowers proton activity and stabilizes the oxide/hydroxide solid relative to dissolved Zn²⁺.

At high pH, ZnO inactive redissolves to zincate. The ZnO inactive / `[Zn(OH)4]2-` boundary is non-redox at pH ≈ 13.475 over E = −1.2656 to +1.5 V. This reflects amphoteric Zn behavior: after precipitation near neutral pH, excess hydroxide stabilizes soluble tetrahydroxozincate. The committed aqueous hydroxo constants were `log_beta = -9.3000` for `[Zn(OH)]+`, `-17.8000` for `[Zn(OH)2]`, `-28.1000` for `[Zn(OH)3]-`, and `-40.5000` for `[Zn(OH)4]2-`.

The topology-supported redox boundary E values are: Zn/Zn²⁺ at E = −0.8594 V from pH 0 to 6.58; Zn/ZnO inactive from pH 6.58, E = −0.8594 V to pH 13.475, E = −1.2656 V; and Zn/`[Zn(OH)4]2-` from pH 13.475, E = −1.2656 V to pH 14, E = −1.3281 V. The solid Zn row has `log_beta = -0.0000`; ZnO inactive dissolution has `log_beta = -9.6132`, Zn(OH)₂ alpha has `log_beta = -10.7230`, and the basic zinc chloride solid `[Zn((OH))1.5(Chloride ion)0.5](s)` has `log_beta = -7.6000`. The basic zinc chloride solid was included but did not become a dominant region.

## Artifacts
- `L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md`
- `L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv`
- `L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv`
- `L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png`
- `L1_call_02/thermodynamic_reference_constants.md`
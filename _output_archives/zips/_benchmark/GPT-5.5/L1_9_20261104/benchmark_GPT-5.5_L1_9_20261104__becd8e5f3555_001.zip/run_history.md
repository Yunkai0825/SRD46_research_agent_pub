# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.'; max_iterations=8; reasoning_timeout_s=600.0 |
|   9.848 | L1_start | call=1; purpose='Compute a pH-sweep speciation diagram for a single aqueous copper–ammonia system at fixed redox potential. The goal is to identify dominant dissolved copper ammine/hydroxo species and any hydroxide so' |
| 520.718 | L1_end | call=1; elapsed_s=510.9; ran_ok=True; attempts=1 |
| 531.849 | L0_end | elapsed_s=531.8423130512238; iterations=3; timed_out=False |

## Answer

The pH sweep predicts a sequence of copper speciation regimes in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh = +0.265 V vs SHE:

- **pH 0.0–4.5:** copper is mainly dissolved **Cu²⁺**. Ammonia is protonated under strongly acidic conditions, so little free NH₃ is available to bind Cu.
- **pH 4.5–7.8:** copper precipitates mainly as the reduced Cu(I) oxide solid **[(Cu₂O)0.5](s)** under the imposed fixed redox potential.
- **pH 7.8–8.2:** **Cu(OH)₂(s)** briefly dominates as hydroxide precipitation becomes favorable.
- **pH 8.2–10.2:** ammonia complexation opens a soluble window dominated by **[Cu(NH₃)₄]²⁺** — reported as **[Cu(Ammo)4]2+** in the output. This is where deprotonated ammonia becomes abundant enough to stabilize dissolved copper against hydroxide precipitation.
- **pH 10.2–13.6:** **Cu(OH)₂(s)** again dominates; hydroxide precipitation overcomes the stabilizing effect of ammonia.
- **pH 13.6–14.0:** copper redissolves as alkaline hydroxo/cuprate species, mainly **CuO₂²⁻**, reflecting amphoteric dissolution of copper hydroxide at very high pH.

Overall, the diagram shows acidic dissolved Cu²⁺, precipitation as Cu(I) oxide at intermediate pH under the fixed Eh, a narrow ammonia-stabilized soluble tetraammine copper window around pH 8.2–10.2, renewed Cu(OH)₂ precipitation, and final alkaline dissolution as cuprate-type species.

## Evidence

- The calculation used **total Cu = 1.00e-3 M**, **total ammonia = 0.100 M**, **pH 0.0–14.0**, **25 °C**, **I = 0.1 m target**, and **Eh = +0.265 V vs SHE**.
- Solver convergence was complete: **281/281 samples converged**.
- Included solids were **[(Cu2O)0.5](s)** and **[Cu(OH)2](s)**.
- **Cu²⁺ dominates pH 0.0–4.5**, with a reported peak of **98.7% at pH 0.0**.
- The Cu²⁺ / cuprous oxide crossover occurs at **pH ≈ 4.50**, with each at about **49%**.
- **[(Cu2O)0.5](s)** dominates **pH 4.5–7.8**, peaking at **96.9% at pH 6.2**.
- **[Cu(OH)2](s)** dominates briefly from **pH 7.8–8.2**, then again from **pH 10.2–13.6**, peaking at **99.8% at pH 11.8**.
- **[Cu(Ammo)4]2+** dominates **pH 8.2–10.2**, peaking at **89.9% at pH 9.9**.
- The reported stability constant for the tetraammine complex is **log_beta +12.3000**.
- The high-pH transition from **[Cu(OH)2](s)** to **CuO2²⁻** occurs at **pH ≈ 13.60**, each near **47%**.
- **CuO2²⁻** dominates **pH 13.6–14.0**, peaking at **95.1% at pH 14.0**.

## Artifacts

- `L1_call_01/solver/Cu_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.csv`
- `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv`
- `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png`
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.png`
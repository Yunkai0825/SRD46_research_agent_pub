inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength 0.1 m; treated as the fixed molar ionic-strength input."},
  {"id": "Eh", "lhs": lambda s: s.E_V, "value": 0.265, "basis": "known", "note": "Task fixes Eh at +0.265 V versus SHE."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1.0e-3, "basis": "known", "note": "Task states total copper 1.00e-3 M; element total used because redox is included at fixed potential."},
  {"id": "NH3tot", "lhs": lambda s: s.total["ligand_10103"], "value": 0.100, "basis": "known", "note": "Task states total ammonia 0.100 M."},
]
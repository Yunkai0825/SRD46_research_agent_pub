# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1 m; treated as the fixed molar ionic-strength input.
  {"lhs": lambda s: s.E_V                  , "rhs": 0.265, "basis": "known"},  # Task fixes Eh at +0.265 V versus SHE.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task states total copper 1.00e-3 M; element total used because redox is included at fixed potential.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task states total ammonia 0.100 M.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH_sweep scans pH from 0 to 14; L3_2 must not pin the swept coordinate.'},
]

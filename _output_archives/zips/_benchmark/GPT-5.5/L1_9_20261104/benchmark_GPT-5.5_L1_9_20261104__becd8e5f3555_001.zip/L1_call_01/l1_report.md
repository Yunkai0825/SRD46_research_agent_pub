## Doability
Doable. The Cu–ammonia calculation is a supported `pH_sweep`: one metal, one ligand, fixed totals, 25.0 °C, target ionic strength 0.1 M, and fixed redox potential +0.265 V vs SHE. The result should be read as fixed-redox pH speciation, not as a Pourbaix stability map.

## Result
Computed Cu speciation for total Cu = 1.00e-3 M and total ammonia = 0.100 M over pH 0.0–14.0 with 281 grid points. Solver convergence was complete: 281/281 samples converged. The report lists fixed ionic mode with target ionic strength 0.1 M and calculated ionic strength range 3.55246e-05–0.051981 M. Included solids were [(Cu2O)0.5](s) and [Cu(OH)2](s).

## Analysis
Copper is predicted to start as dissolved Cu2+ in strongly acidic solution: Cu2+ dominates from pH 0.0–4.5 and reaches a 98.7% peak at pH 0.0. This is chemically consistent with protonated ammonia and suppressed hydrolysis at low pH; the ligand pool is mostly HAmmonia+ below the ammonia crossover, so free NH3 is not available to strongly bind Cu.

At pH ~4.5, Cu2+ crosses to the reduced Cu(I) oxide solid [(Cu2O)0.5](s), with the verdict reporting Cu2+ ↔ [(Cu2O)0.5](s) at pH ≈ 4.50, each ~49%. [(Cu2O)0.5](s) then dominates pH 4.5–7.8 and peaks at 96.9% at pH 6.2. The precipitation log reports [(Cu2O)0.5](s) first appearing at pH 4.25 with 1.03e-04 M solid.

Near neutral to mildly basic pH, the system enters a narrow mixed transition among ammine complexes and hydroxide solids. [Cu(OH)2](s) dominates from pH 7.8–8.2, while Cu ammine species become competitive as ammonia deprotonates. The ligand verdict places the HAmmonia+ → Ammonia dominance change at pH 9.3; increasing free NH3 stabilizes Cu ammines. The strongest dissolved Cu ammine is [Cu(Ammo)4]2+, with log_beta +12.3000 from the reference table, and it dominates pH 8.2–10.2, peaking at 89.9% at pH 9.9. Its main crossover with [Cu(OH)2](s) is reported at pH ≈ 8.22, each ~25%, and again at pH ≈ 10.13, each ~48%, defining the ammine-stabilized soluble window.

Hydroxide precipitation returns at higher pH: [Cu(OH)2](s) dominates pH 10.2–13.6 and peaks at 99.8% at pH 11.8. The precipitation events show [Cu(OH)2](s) at pH 7.75 with 5.62e-04 M, dissolution of all solids by pH 8.40, reappearance of [Cu(OH)2](s) at pH 9.95 with 1.00e-04 M, and final dissolution of all solids by pH 13.75. Thus ammonia complexation opens a basic soluble window around pH 8.2–10.2, but hydroxide precipitation wins again once hydrolysis and low effective ligand competition dominate.

At the most alkaline end, soluble cuprate-type hydroxo species take over. [Cu(OH)2](s) crosses to CuO22- at pH ≈ 13.60, each ~47%, and CuO22- dominates pH 13.6–14.0, peaking at 95.1% at pH 14.0. HCuO2- remains minor, peaking at 8.3% near pH 13.8. This final dissolution reflects amphoteric Cu(II) hydroxide behavior under very high pH.

Overall, the calculation predicts: acidic dissolved Cu2+; intermediate Cu(I) oxide precipitation under the imposed fixed redox potential; a narrow Cu(II) hydroxide/ammine transition; a soluble tetraammine Cu(II) window near pH 8.2–10.2; renewed Cu(OH)2 precipitation; and final alkaline dissolution as CuO22-. These conclusions rely on the fully converged grid and the included thermodynamic constants in the generated card.

## Artifacts
L1_call_01/solver/Cu_+_Ammonia_verdict.md
L1_call_01/thermodynamic_reference_constants.md
L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png
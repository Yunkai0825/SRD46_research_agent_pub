# Speciation Calculation Report: Cu + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 3.55246e-05 – 0.051981 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 281
- Converged: 281/281
- Redox mode: fixed
- Fixed E_V: +0.265 V

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu]_total | 0.001 | parent element total |
| [ligand_10103]_total | 0.1 | component total |

## Components

The metal entries below are conserved physical parent-element totals; oxidation-state species are partitioned within each element balance.

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu | Cu | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Ammo)2]+ | aqueous | L1:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Ammo)4]2+ | aqueous | L1:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L1:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L1:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |

## Precipitation

- pH 4.25: [(Cu2O)0.5](s) (1.03e-04 M)
- pH 7.75: [Cu(OH)2](s) (5.62e-04 M)
- pH 8.40: all solids dissolved
- pH 9.95: [Cu(OH)2](s) (1.00e-04 M)
- pH 13.75: all solids dissolved

## Speciation Analysis

```
=== Cu (Cu) speciation ===
[Cu]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 281/281

Species peaks:
  [Cu(Ammo)2]+        peak 23.3% at pH 7.7
  Cu2+                peak 98.7% at pH 0.0
  HCuO2-              peak 8.3% at pH 13.8
  CuO22-              peak 95.1% at pH 14.0
  [Cu(Ammo)4]2+       peak 89.9% at pH 9.9
  [Cu(Ammo)3]2+       peak 31.3% at pH 8.4
  [Cu(Ammo)2]2+       peak 5.5% at pH 7.7
  [(Cu2O)0.5](s)      peak 96.9% at pH 6.2
  [Cu(OH)2](s)        peak 99.8% at pH 11.8

Dominant species by pH region:
  pH   0.0–  4.5  →  Cu2+
  pH   4.5–  7.8  →  [(Cu2O)0.5](s)
  pH   7.8–  8.2  →  [Cu(OH)2](s)
  pH   8.2– 10.2  →  [Cu(Ammo)4]2+
  pH  10.2– 13.6  →  [Cu(OH)2](s)
  pH  13.6– 14.0  →  CuO22-

Crossover pH values:
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)4]2+  at pH ≈ 8.17  (each ~21%)
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.13  (each ~21%)
  [Cu(Ammo)2]+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.73  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 7.72  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 8.26  (each ~20%)
  Cu2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 4.50  (each ~49%)
  HCuO2- ↔ [Cu(OH)2](s)  at pH ≈ 13.73  (each ~8%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.60  (each ~47%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.21  (each ~24%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)2]2+  at pH ≈ 7.83  (each ~5%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 10.13  (each ~48%)
  [Cu(Ammo)3]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.74  (each ~10%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.71  (each ~9%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 9.94  (each ~8%)
  [Cu(Ammo)2]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.75  (each ~5%)
  [Cu(Ammo)2]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.70  (each ~5%)
  [(Cu2O)0.5](s) ↔ [Cu(OH)2](s)  at pH ≈ 7.73  (each ~29%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 0.0
  Ammonia             peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  9.3  →  HAmmonia+
  pH   9.3– 14.0  →  Ammonia

```
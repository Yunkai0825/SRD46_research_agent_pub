# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: solution pH-sweep speciation/precipitation for Cu--ammonia at fixed Eh, not corrosion, plating, or phase-formation screening.
- Governing conditions: 1.00e-3 M total Cu, 0.100 M total ammonia, 25 C, I=0.1 m; use these concentrations rather than the 1e-6 M Pourbaix convention.
- Aqueous identity: keep chemically distinct Cu(I)/Cu(II) ammine, hydroxo, oxyhydroxo, and polynuclear complexes; collapse only source or bracket/formula notation duplicates of the same species.
- Ligand assumption: L1/Ammo denotes NH3 in the total ammonia acid-base system; retain identifiable NH3/NH4+ acid-base rows, but drop unidentified empty-core aqueous placeholders such as [?] because they are not physical species for this calculation.
- Solids: in water at 25 C with precipitation requested, prefer hydrated Cu(OH)2(s) for Cu(II) hydroxide precipitation over anhydrous CuO; Cu2O is a distinct Cu(I) oxide redox solid if retained.
- Counterions: carbonate and other counterion solids are absent and out of scope.
- Phase question: choose stable thermodynamic representatives, not polymorph/form history; prefer SRD-46 over Atlas for exact duplicates when chemistry is the same.
- References/gases: no gas equilibria; elemental Cu metal is out of scope for this solution precipitation calculation unless needed only as a formal reference.

Kept: `[Cu]+` from `SRD-46`.

Rationale: `Cu+` (Atlas) and `[Cu]+` (SRD-46) are the same aqueous Cu(I) ion, so the SRD-46 notation/source is preferred.
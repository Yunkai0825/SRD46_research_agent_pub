# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    240.86
- elapsed_s (total):  240.86
- llm_iterations:     35
- llm_tool_calls:     19

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ and [Cu]+ are the same aqueous Cu(I) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Cu2+ and [Cu]2+ are exact aqueous notation duplicates with identical charge and aligned μ, so the SRD-46 row is preferred. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Kept both because mononuclear [Cu(OH)]+ and polynuclear [Cu2(OH)2]2+ are distinct aqueous Cu(II) hydroxo complexes, not notation duplicates. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O is a distinct Cu(I) oxide redox solid, but the SRD-46 half-formula entry and Atlas Cu2O entry represent the same solid phase, so the SRD-46 representative is preferred. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | For Cu--ammonia solution precipitation at 25 C, the case guidance prefers the hydrated SRD-46 Cu(OH)2(s) representative over anhydrous CuO variants and over the Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | NO | The empty-core [?] row is an unidentified placeholder rather than a physical species for this Cu--ammonia speciation calculation. |
| aqueous | `Cu$+1:1 L1:2` | yes | The Cu(I) diammine complex is a chemically distinct in-scope aqueous ammine species. |
| aqueous | `Cu$+2:1 H:-2` | yes | The neutral Cu(II) hydroxo complex is a chemically distinct in-scope aqueous hydroxo species. |
| aqueous | `Cu$+2:1 H:-3` | yes | The HCuO2- row is a distinct Cu(II) oxyhydroxo aqueous complex retained under the aqueous identity guidance. |
| aqueous | `Cu$+2:1 H:-4` | yes | The CuO2^2- row is a distinct Cu(II) oxyhydroxo aqueous complex retained under the aqueous identity guidance. |
| aqueous | `Cu$+2:1 L1:1` | yes | The monoammine Cu(II) complex is a chemically distinct in-scope aqueous ammine species. |
| aqueous | `Cu$+2:1 L1:2` | yes | The diammine Cu(II) complex is a chemically distinct in-scope aqueous ammine species. |
| aqueous | `Cu$+2:1 L1:3` | yes | The triammine Cu(II) complex is a chemically distinct in-scope aqueous ammine species. |
| aqueous | `Cu$+2:1 L1:4` | yes | The tetraammine Cu(II) complex is a chemically distinct in-scope aqueous ammine species. |
| aqueous | `Cu$+2:3 H:-4` | yes | The trinuclear Cu(II) hydroxo complex is a distinct in-scope polynuclear aqueous species. |
| aqueous | `L1:1` | yes | Ammonia is the neutral ligand component of the total ammonia acid-base system and is in scope. |
| aqueous | `L1:1 H:1` | yes | Ammonium is the protonated ammonia acid-base partner and is in scope. |
| solid | `Cu$+0:1` | NO | Elemental copper metal is out of scope for this solution speciation and precipitation calculation. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[?]` | SRD-46 | aqueous | LC2 element review: The empty-core [?] row is an unidentified placeholder rather than a physical species for this Cu--ammonia speciation calculation. |
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ and [Cu]+ are the same aqueous Cu(I) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Cu2+ and [Cu]2+ are exact aqueous notation duplicates with identical charge and aligned μ, so the SRD-46 row is preferred. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O is a distinct Cu(I) oxide redox solid, but the SRD-46 half-formula entry and Atlas Cu2O entry represent the same solid phase, so the SRD-46 representative is preferred. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: For Cu--ammonia solution precipitation at 25 C, the case guidance prefers the hydrated SRD-46 Cu(OH)2(s) representative over anhydrous CuO variants and over the Atlas duplicate. |
| `CuO` | Atlas | dissolution | LC2 element review: For Cu--ammonia solution precipitation at 25 C, the case guidance prefers the hydrated SRD-46 Cu(OH)2(s) representative over anhydrous CuO variants and over the Atlas duplicate. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: For Cu--ammonia solution precipitation at 25 C, the case guidance prefers the hydrated SRD-46 Cu(OH)2(s) representative over anhydrous CuO variants and over the Atlas duplicate. |
| `Cu` | Atlas | dissolution | LC2 element review: Elemental copper metal is out of scope for this solution speciation and precipitation calculation. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 15fd018b065a48108750f7ff296cad55
- review_turns: 2
- full_restarts: 1
- targeted_reruns: 0
- summary: Final deduplicated table accepted. The selection is appropriate for the fixed-Eh Cu--ammonia pH-sweep at 25 C and I=0.1 m: exact Cu+/Cu2+ notation/source duplicates are collapsed to SRD-46, chemically distinct aqueous ammine/hydroxo/oxyhydroxo/polynuclear species are retained, ammonia/ammonium are retained, the unidentified placeholder is excluded, elemental Cu metal is excluded as out of scope, and solids are limited to the hydroxide-preferred Cu(OH)2(s) representative plus one distinct Cu2O redox-solid representative.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (15/15)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_9_20261104\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

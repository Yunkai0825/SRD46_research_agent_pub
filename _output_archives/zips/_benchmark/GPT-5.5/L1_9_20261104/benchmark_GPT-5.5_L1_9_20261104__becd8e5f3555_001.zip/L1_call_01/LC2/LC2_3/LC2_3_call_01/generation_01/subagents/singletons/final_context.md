## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: solution pH-sweep speciation/precipitation for Cu--ammonia at fixed Eh, not corrosion, plating, or phase-formation screening.
- Governing conditions: 1.00e-3 M total Cu, 0.100 M total ammonia, 25 C, I=0.1 m; use these concentrations rather than the 1e-6 M Pourbaix convention.
- Aqueous identity: keep chemically distinct Cu(I)/Cu(II) ammine, hydroxo, oxyhydroxo, and polynuclear complexes; collapse only source or bracket/formula notation duplicates of the same species.
- Ligand assumption: L1/Ammo denotes NH3 in the total ammonia acid-base system; missing ammonia acid-base rows are a model-completeness issue, not a Cu dedup decision.
- Solids: in water at 25 C with precipitation requested, prefer hydrated Cu(OH)2(s) for Cu(II) hydroxide precipitation over anhydrous CuO; Cu2O is a distinct Cu(I) oxide redox solid if retained.
- Counterions: carbonate and other counterion solids are absent and out of scope.
- Phase question: choose stable thermodynamic representatives, not polymorph/form history; prefer SRD-46 over Atlas for exact duplicates when chemistry is the same.
- References/gases: no gas equilibria; elemental Cu metal is out of scope for this solution precipitation calculation unless needed only as a formal reference.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse exact aqueous notation/source duplicates only--Cu+/[Cu]+ and Cu2+/[Cu]2+--preferring SRD-46, and retain distinct ammine, hydroxo, oxyhydroxo, polynuclear, and Cu(I)/Cu(II) aqueous species. For solids, keep the SRD-46 Cu(OH)2(s) hydroxide precipitation representative over CuO variants, keep one SRD-46 Cu2O representative only as a distinct Cu(I) oxide redox solid, and drop elemental Cu metal as out-of-scope for solution precipitation.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"No case-specific instruction excludes this aqueous singleton, so it is retained by the default keep rule."},{"phase":"aqueous","core_label":"Cu$+1:1 L1:2","keep":true,"rationale":"This is a distinct Cu(I) diammine aqueous complex explicitly in scope for Cu--ammonia speciation."},{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"This neutral Cu(II) hydroxo aqueous complex is chemically distinct and in scope for the pH-sweep speciation model."},{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"This Cu(II) oxyhydroxo aqueous anion is distinct and retained under the instruction to keep hydroxo and oxyhydroxo species."},{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"This Cu(II) oxyhydroxo aqueous dianion is distinct and retained under the instruction to keep hydroxo and oxyhydroxo species."},{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"This Cu(II) monoammine complex is a distinct aqueous ammine species in scope for Cu--ammonia speciation."},{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"This Cu(II) diammine complex is a distinct aqueous ammine species in scope for Cu--ammonia speciation."},{"phase":"aqueous","core_label":"Cu$+2:1 L1:3","keep":true,"rationale":"This Cu(II) triammine complex is a distinct aqueous ammine species in scope for Cu--ammonia speciation."},{"phase":"aqueous","core_label":"Cu$+2:1 L1:4","keep":true,"rationale":"This Cu(II) tetraammine complex is a distinct aqueous ammine species in scope for Cu--ammonia speciation."},{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"This polynuclear Cu(II) hydroxo complex is chemically distinct and explicitly retained by the aqueous identity instruction."},{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Ammonia is part of the total ammonia acid-base system and is in scope for this Cu--ammonia calculation."},{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Protonated ammonia is part of the ammonia acid-base system and is in scope for this pH-sweep calculation."},{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Elemental copper metal is out of scope for this solution precipitation calculation unless only needed as a formal reference."}]}')

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: finalize_singleton_decisions. Call the appropriate tool now with its documented arguments. If no changes are needed, submit the tool's valid empty payload; do not repeat the prose answer.

## Assistant
<summary>Submitting the singleton keep/drop decisions as required; aqueous Cu/ammonia species are retained, while elemental copper metal is dropped as out of scope for this solution precipitation calculation.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
Completed: 13 singleton verdicts recorded.
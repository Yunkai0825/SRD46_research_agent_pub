# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: solution pH-sweep speciation/precipitation for Cu--ammonia at fixed Eh, not corrosion, plating, or phase-formation screening.
- Governing conditions: 1.00e-3 M total Cu, 0.100 M total ammonia, 25 C, I=0.1 m; use these concentrations rather than the 1e-6 M Pourbaix convention.
- Aqueous identity: keep chemically distinct Cu(I)/Cu(II) ammine, hydroxo, oxyhydroxo, and polynuclear complexes; collapse only source or bracket/formula notation duplicates of the same species.
- Ligand assumption: L1/Ammo denotes NH3 in the total ammonia acid-base system; missing ammonia acid-base rows are a model-completeness issue, not a Cu dedup decision.
- Solids: in water at 25 C with precipitation requested, prefer hydrated Cu(OH)2(s) for Cu(II) hydroxide precipitation over anhydrous CuO; Cu2O is a distinct Cu(I) oxide redox solid if retained.
- Counterions: carbonate and other counterion solids are absent and out of scope.
- Phase question: choose stable thermodynamic representatives, not polymorph/form history; prefer SRD-46 over Atlas for exact duplicates when chemistry is the same.
- References/gases: no gas equilibria; elemental Cu metal is out of scope for this solution precipitation calculation unless needed only as a formal reference.

## Element instructions

- **Cu**: Collapse exact aqueous notation/source duplicates only--Cu+/[Cu]+ and Cu2+/[Cu]2+--preferring SRD-46, and retain distinct ammine, hydroxo, oxyhydroxo, polynuclear, and Cu(I)/Cu(II) aqueous species. For solids, keep the SRD-46 Cu(OH)2(s) hydroxide precipitation representative over CuO variants, keep one SRD-46 Cu2O representative only as a distinct Cu(I) oxide redox solid, and drop elemental Cu metal as out-of-scope for solution precipitation.

[Purpose: Compute a pH-sweep speciation diagram for a single aqueous copper–ammonia system at fixed redox potential. The goal is to identify dominant dissolved copper ammine/hydroxo species and any hydroxide solid precipitation over pH 0–14 at 25 C and ionic strength 0.1 m.]
[Tasks:
For one solution containing total copper 1.00e-3 M and total ammonia 0.100 M, calculate copper speciation as a function of pH from 0 to 14 at 25 C and ionic strength 0.1 m, with Eh fixed at +0.265 V versus SHE. Prefer hydroxide solids when solids are possible, and generate the pH speciation diagram plus CSV outputs and a concise interpretation of dominant copper species, precipitation regions, and convergence evidence.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute a pH-sweep speciation diagram for a single aqueous copper\u2013ammonia system at fixed redox potential. The goal is to identify dominant dissolved copper ammine/hydroxo species and any hydroxide solid precipitation over pH 0\u201314 at 25 C and ionic strength 0.1 m.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Cu_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv",
      "L1_call_01/solver/Cu_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
      "L1_call_01/solver/Cu_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 419.5
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute a pH-sweep speciation diagram for a single aqueous copper\u2013ammonia system at fixed redox potential. The goal is to identify dominant dissolved copper ammine/hydroxo species and any hydroxide solid precipitation over pH 0\u201314 at 25 C and ionic strength 0.1 m.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.

## Assistant
## Answer
I’ll run a single pH-sweep speciation calculation for the one solution containing Cu and total ammonia, at fixed Eh = +0.265 V vs SHE, 25 °C, ionic strength 0.1 m, total Cu = 1.00e-3 M, and total ammonia = 0.100 M, with hydroxide solids preferred where precipitation is relevant.

## User
[NO TOOL CALLED] Your reply ended this turn without calling any tool (re-ask 1 of 1).
The tools listed in your system prompt are available in this session; nothing has to be enabled. A tool is called by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>.
Expected for this task: dispatch_l1_pipeline.
Tools you can call now: dispatch_l1_pipeline, list_session_files, read_session_file.
Either call the tool(s) the task needs now, or, if you decline the task on its merits, give your final answer as plain text and state the reason; do not state that the tools are unavailable.

## Assistant
<summary>Dispatching one L1 pH-sweep speciation calculation for Cu in total ammonia with fixed Eh and specified conditions.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. The Cu–ammonia calculation is a supported `pH_sweep`: one metal, one ligand, fixed totals, 25.0 °C, target ionic strength 0.1 M, and fixed redox potential +0.265 V vs SHE. The result should be read as fixed-redox pH speciation, not as a Pourbaix stability map.

## Result
Computed Cu speciation for total Cu = 1.00e-3 M and total ammonia = 0.100 M over pH 0.0–14.0 with 281 grid points. Solver convergence was complete: 281/281 samples converged. The report lists fixed ionic mode with target ionic strength 0.1 M and calculated ionic strength range 3.55246e-05–0.051981 M. Included solids were [(Cu2O)0.5](s) and [Cu(OH)2](s).

## Analysis
Copper is predicted to start as dissolved Cu2+ in strongly acidic solution: Cu2+ dominates from pH 0.0–4.5 and reaches a 98.7% peak at pH 0.0. This is chemically consistent with protonated ammonia and suppressed hydrolysis at low pH; the ligand pool is mostly HAmmonia+ below the ammonia crossover, so free NH3 is not available to strongly bind Cu.

At pH ~4.5, Cu2+ crosses to the reduced Cu(I) oxide solid [(Cu2O)0.5](s), with the verdict reporting Cu2+ ↔ [(Cu2O)0.5](s) at pH ≈ 4.50, each ~49%. [(Cu2O)0.5](s) then dominates pH 4.5–7.8 and peaks at 96.9% at pH 6.2. The precipitation log reports [(Cu2O)0.5](s) first appearing at pH 4.25 with 1.03e-04 M solid.

Near neutral to mildly basic pH, the system enters a narrow mixed transition among ammine complexes and hydroxide solids. [Cu(OH)2](s) dominates from pH 7.8–8.2, while Cu ammine species become competitive as ammonia deprotonates. The ligand verdict places the HAmmonia+ → Ammonia dominance change at pH 9.3; increasing free NH3 stabilizes Cu ammines. The strongest dissolved Cu ammine is [Cu(Ammo)4]2+, with log_beta +12.3000 from the reference table, and it dominates pH 8.2–10.2, peaking at 89.9% at pH 9.9. Its main crossover with [Cu(OH)2](s) is reported at pH ≈ 8.22, each ~25%, and again at pH ≈ 10.13, each ~48%, defining the ammine-stabilized soluble window.

Hydroxide precipitation returns at higher pH: [Cu(OH)2](s) dominates pH 10.2–13.6 and peaks at 99.8% at pH 11.8. The precipitation events show [Cu(OH)2](s) at pH 7.75 with 5.62e-04 M, dissolution of all solids by pH 8.40, reappearance of [Cu(OH)2](s) at pH 9.95 with 1.00e-04 M, and final dissolution of all solids by pH 13.75. Thus ammonia complexation opens a basic soluble window around pH 8.2–10.2, but hydroxide precipitation wins again once hydrolysis and low effective ligand competition dominate.

At the most alkaline end, soluble cuprate-type hydroxo species take over. [Cu(OH)2](s) crosses to CuO22- at pH ≈ 13.60, each ~47%, and CuO22- dominates pH 13.6–14.0, peaking at 95.1% at pH 14.0. HCuO2- remains minor, peaking at 8.3% near pH 13.8. This final dissolution reflects amphoteric Cu(II) hydroxide behavior under very high pH.

Overall, the calculation predicts: acidic dissolved Cu2+; intermediate Cu(I) oxide precipitation under the imposed fixed redox potential; a narrow Cu(II) hydroxide/ammine transition; a soluble tetraammine Cu(II) window near pH 8.2–10.2; renewed Cu(OH)2 precipitation; and final alkaline dissolution as CuO22-. These conclusions rely on the fully converged grid and the included thermodynamic constants in the generated card.

## Artifacts
L1_call_01/solver/Cu_+_Ammonia_verdict.md
L1_call_01/thermodynamic_reference_constants.md
L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

The pH sweep predicts a sequence of copper speciation regimes in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh = +0.265 V vs SHE:

- **pH 0.0–4.5:** copper is mainly dissolved **Cu²⁺**. Ammonia is protonated under strongly acidic conditions, so little free NH₃ is available to bind Cu.
- **pH 4.5–7.8:** copper precipitates mainly as the reduced Cu(I) oxide solid **[(Cu₂O)0.5](s)** under the imposed fixed redox potential.
- **pH 7.8–8.2:** **Cu(OH)₂(s)** briefly dominates as hydroxide precipitation becomes favorable.
- **pH 8.2–10.2:** ammonia complexation opens a soluble window dominated by **[Cu(NH₃)₄]²⁺** — reported as **[Cu(Ammo)4]2+** in the output. This is where deprotonated ammonia becomes abundant enough to stabilize dissolved copper against hydroxide precipitation.
- **pH 10.2–13.6:** **Cu(OH)₂(s)** again dominates; hydroxide precipitation overcomes the stabilizing effect of ammonia.
- **pH 13.6–14.0:** copper redissolves as alkaline hydroxo/cuprate species, mainly **CuO₂²⁻**, reflecting amphoteric dissolution of copper hydroxide at very high pH.

Overall, the diagram shows acidic dissolved Cu²⁺, precipitation as Cu(I) oxide at intermediate pH under the fixed Eh, a narrow ammonia-stabilized soluble tetraammine copper window around pH 8.2–10.2, renewed Cu(OH)₂ precipitation, and final alkaline dissolution as cuprate-type species.

## Evidence

- The calculation used **total Cu = 1.00e-3 M**, **total ammonia = 0.100 M**, **pH 0.0–14.0**, **25 °C**, **I = 0.1 m target**, and **Eh = +0.265 V vs SHE**.
- Solver convergence was complete: **281/281 samples converged**.
- Included solids were **[(Cu2O)0.5](s)** and **[Cu(OH)2](s)**.
- **Cu²⁺ dominates pH 0.0–4.5**, with a reported peak of **98.7% at pH 0.0**.
- The Cu²⁺ / cuprous oxide crossover occurs at **pH ≈ 4.50**, with each at about **49%**.
- **[(Cu2O)0.5](s)** dominates **pH 4.5–7.8**, peaking at **96.9% at pH 6.2**.
- **[Cu(OH)2](s)** dominates briefly from **pH 7.8–8.2**, then again from **pH 10.2–13.6**, peaking at **99.8% at pH 11.8**.
- **[Cu(Ammo)4]2+** dominates **pH 8.2–10.2**, peaking at **89.9% at pH 9.9**.
- The reported stability constant for the tetraammine complex is **log_beta +12.3000**.
- The high-pH transition from **[Cu(OH)2](s)** to **CuO2²⁻** occurs at **pH ≈ 13.60**, each near **47%**.
- **CuO2²⁻** dominates **pH 13.6–14.0**, peaking at **95.1% at pH 14.0**.

## Artifacts

- `L1_call_01/solver/Cu_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.csv`
- `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv`
- `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png`
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.png`
## Answer

For the requested **1 mM Ni + 10 mM glycine** solution at **25 °C, I = 0.1 m**, the computed Ni Pourbaix diagram shows a clear soluble **Ni(II)–glycinate stability window** between acidic free-Ni behavior and alkaline precipitation/passivation.

The soluble glycine-complex field begins near **pH ≈ 6.1**, where deprotonated glycine becomes available enough to bind Ni(II), and extends to about **pH ≈ 11.2** before **Ni(OH)₂ / oxide-hydroxide solid phases** become dominant. Within that soluble window, the dominant complex shifts with increasing pH:

- **[Ni(Glyc)]⁺**: roughly pH **6.1–6.8**
- **[Ni(Glyc)₂]**: roughly pH **6.8–8.0**
- **[Ni(Glyc)₃]⁻**: roughly pH **8.0–11.2**

At a representative mildly oxidizing line, **E = 0.1 V vs SHE**, the practical soluble-glycinate window is therefore approximately:

> **pH 6.1–11.2**, with increasing glycine coordination as pH rises.

Chemically, this is the expected pattern: glycine is strongly protonated at low pH, suppressing coordination and leaving **Ni²⁺** dominant. As pH rises, glycine deprotonates and increasingly stabilizes soluble Ni(II) as mono-, bis-, then tris-glycinate complexes. At still higher pH, hydroxide competition and solid-phase stability overtake ligand stabilization, so **Ni(OH)₂ and oxidized Ni oxide/hydroxide phases** dominate. Reducing potentials instead favor **Ni metal**, while strongly oxidizing potentials favor Ni oxide/hydroxide solids.

## Evidence

- The calculation was run for **1 mM total Ni and 10 mM total glycine at 25 °C, I = 0.1 M**, over **pH 0–14** and **E = −1.2 to 1.4 V vs SHE**.
- Grid resolution: **ΔpH = 0.011111111** and **ΔE = 0.0022222222 V**.
- The topology contained **9 dominant labels**, **9 connected regions**, **18 boundary curves**, **10 internal junctions**, and **6 sweep-limit junctions**.
- Reported Ni-glycinate fields:
  - **[Ni(Glyc)]⁺** bounded by junctions at approximately **pH 6.0611–6.7611**.
  - **[Ni(Glyc)₂]** bounded by approximately **pH 6.7611–7.9056**.
  - **[Ni(Glyc)₃]⁻** bounded by approximately **pH 7.9056–11.2389**.
- At **E = 0.1 V**, the dominance sequence was:
  - **Ni²⁺** through **pH 6.0667**
  - **[Ni(Glyc)]⁺** from **pH 6.0778–6.7889**
  - **[Ni(Glyc)₂]** from **pH 6.8000–7.9667**
  - **[Ni(Glyc)₃]⁻** from **pH 7.9778–11.2333**
  - **Ni(OH)₂** from **pH 11.2444–13.8889**
  - **Ni₃O₄·2H₂O** above **pH 13.9000**
- At **pH 7**, the E sweep showed:
  - **Ni metal** up to **−0.3756 V**
  - **[Ni(Glyc)₂]** from **−0.3733 to 0.7400 V**
  - Oxide/hydroxide phases at higher potentials.
- Thermodynamic constants used in the assembled card included cumulative log β values:
  - **[Ni(Glyc)]⁺: log β = +5.7400**
  - **[Ni(Glyc)₂]: log β = +10.5800**
  - **[Ni(Glyc)₃]⁻: log β = +14.1000**
  - Glycine protonation **[HGlycine]: log β = +9.5700**
- Convergence support: the full-speciation CSV included **converged**, **iterations**, and **residual** columns; opened rows showed **converged = 1** with small residuals. The map CSV reported **fixer_marks = 0**.

## Artifacts

- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png`
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md`
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni.json`
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv`
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
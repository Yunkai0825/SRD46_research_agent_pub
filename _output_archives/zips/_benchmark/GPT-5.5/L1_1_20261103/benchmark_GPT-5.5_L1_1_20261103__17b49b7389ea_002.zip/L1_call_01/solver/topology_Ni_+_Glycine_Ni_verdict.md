# Solver report (Pourbaix)

## System
- Components: [Ni, Glycine]
- Constraints:
  -- component totals (M): Ni=0.001;Glycine=0.01
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.2V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.011111111, ΔE_V=0.0022222222V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ni
- Dms_2: Ni(OH)2
- Dms_3: [Ni(Glyc)3]-
- Dms_4: [Ni(Glyc)2]
- Dms_5: [Ni(Glyc)]+
- Dms_6: Ni2+
- Dms_7: Ni3O4.2H2O
- Dms_8: Ni2O3.H2O
- Dms_9: NiO2.2H2O

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 18 pairwise boundary curves
- 10 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.1V)
- Fixed sample indices: (pH=swept, E_V=sample 585)
- samples 0–546, (pH=[0, 6.0666667], E_V=0.1V): Ni2+ (Dms_6)
- samples 547–611, (pH=[6.0777778, 6.7888889], E_V=0.1V): [Ni(Glyc)]+ (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[6.0666667, 6.0777778], E_V=0.1V)
- samples 612–717, (pH=[6.8, 7.9666667], E_V=0.1V): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[6.7888889, 6.8], E_V=0.1V)
- samples 718–1011, (pH=[7.9777778, 11.233333], E_V=0.1V): [Ni(Glyc)3]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.9666667, 7.9777778], E_V=0.1V)
- samples 1012–1250, (pH=[11.244444, 13.888889], E_V=0.1V): Ni(OH)2 (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[11.233333, 11.244444], E_V=0.1V)
- samples 1251–1260, (pH=[13.9, 14], E_V=0.1V): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=[13.888889, 13.9], E_V=0.1V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 630, E_V=swept)
- samples 0–371, (pH=7, E_V=[-1.2V, -0.37555556V]): Ni (Dms_1)
- samples 372–873, (pH=7, E_V=[-0.37333333V, 0.74V]): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.37555556V, -0.37333333V])
- samples 874–952, (pH=7, E_V=[0.74222222V, 0.91555556V]): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.74V, 0.74222222V])
- samples 953–1015, (pH=7, E_V=[0.91777778V, 1.0555556V]): Ni2O3.H2O (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.91555556V, 0.91777778V])
- samples 1016–1170, (pH=7, E_V=[1.0577778V, 1.4V]): NiO2.2H2O (Dms_9)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[1.0555556V, 1.0577778V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ni}**
  -- Measure in the solver coordinate frame: 10.639309
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_4
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_5
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_6
    --- DmsReg_9 {Ni2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {Ni(OH)2}**
  -- Measure in the solver coordinate frame: 2.2292593
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_10
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_14]
- **DmsReg_3 {Ni3O4.2H2O}**
  -- Measure in the solver coordinate frame: 2.1776296
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_17
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_11
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_12
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_13
    --- DmsReg_9 {Ni2+} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_15]
- **DmsReg_4 {Ni2O3.H2O}**
  -- Measure in the solver coordinate frame: 1.3118025
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_8
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_18
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_5 {NiO2.2H2O}**
  -- Measure in the solver coordinate frame: 4.7302716
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_9
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12, DmsRegEqJnc_16]
#### liquid
- **DmsReg_6 {[Ni(Glyc)3]-}**
  -- Measure in the solver coordinate frame: 3.4744938
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_4
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_10
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_1
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_7 {[Ni(Glyc)2]}**
  -- Measure in the solver coordinate frame: 1.3097778
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_5
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_1
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_2
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4, DmsRegEqJnc_5]
- **DmsReg_8 {[Ni(Glyc)]+}**
  -- Measure in the solver coordinate frame: 0.84106173
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_6
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_2
    --- DmsReg_9 {Ni2+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_13
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6]
- **DmsReg_9 {Ni2+}**
  -- Measure in the solver coordinate frame: 9.7464198
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_7
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_8
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ni(Glyc)3]- | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9056, E_V=-0.4278V), (pH=7.9722, E_V=-0.4211V), (pH=7.9722, E_V=0.65V), (pH=7.9056, E_V=0.6878V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 515, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 9, 491, 514], "t_params": [0.0, 0.0552, 0.9369, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9056, E_V=-0.4278V), (pH=7.9722, E_V=-0.4211V), (pH=7.9722, E_V=0.65V), (pH=7.9056, E_V=0.6878V)], "envelope_t": [0.0, 0.0552, 0.9369, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.9056, E_V=-0.4278V), (pH=7.9722, E_V=-0.4211V), (pH=7.9722, E_V=0.65V), (pH=7.9056, E_V=0.6878V)], "adaptive_t": [0.0, 0.0552, 0.9369, 1.0]}
- **DmsRegEq_2: [Ni(Glyc)2] | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.7611, E_V=-0.3656V), (pH=6.7944, E_V=-0.3567V), (pH=6.7944, E_V=0.7389V), (pH=6.7611, E_V=0.7656V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 516, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 7, 500, 515], "t_params": [0.0, 0.0294, 0.9636, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.7611, E_V=-0.3656V), (pH=6.7944, E_V=-0.3567V), (pH=6.7944, E_V=0.7389V), (pH=6.7611, E_V=0.7656V)], "envelope_t": [0.0, 0.0294, 0.9636, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=6.7611, E_V=-0.3656V), (pH=6.7944, E_V=-0.3567V), (pH=6.7944, E_V=0.7389V), (pH=6.7611, E_V=0.7656V)], "adaptive_t": [0.0, 0.0294, 0.9636, 1.0]}
- **DmsRegEq_3: [Ni(Glyc)]+ | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0611, E_V=-0.3433V), (pH=6.0611, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 549, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 548], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0611, E_V=-0.3433V), (pH=6.0611, E_V=0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.0611, E_V=-0.3433V), (pH=6.0611, E_V=0.87V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Ni | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.2389, E_V=-0.5478V), (pH=10.2611, E_V=-0.5456V), (pH=9.45, E_V=-0.5278V), (pH=8.9611, E_V=-0.5033V), (pH=7.9056, E_V=-0.4278V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 355, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 89, 170, 225, 354], "t_params": [0.0, 0.293, 0.5362, 0.6829, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.2389, E_V=-0.5478V), (pH=10.2611, E_V=-0.5456V), (pH=9.45, E_V=-0.5278V), (pH=8.9611, E_V=-0.5033V), (pH=7.9056, E_V=-0.4278V)], "envelope_t": [0.0, 0.293, 0.5362, 0.6829, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=11.2389, E_V=-0.5478V), (pH=10.2611, E_V=-0.5456V), (pH=9.45, E_V=-0.5278V), (pH=8.9611, E_V=-0.5033V), (pH=7.9056, E_V=-0.4278V)], "adaptive_t": [0.0, 0.293, 0.5362, 0.6829, 1.0]}
- **DmsRegEq_5: Ni | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9056, E_V=-0.4278V), (pH=7.1833, E_V=-0.3833V), (pH=6.7611, E_V=-0.3656V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 132, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 85, 131], "t_params": [0.0, 0.6313, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9056, E_V=-0.4278V), (pH=7.1833, E_V=-0.3833V), (pH=6.7611, E_V=-0.3656V)], "envelope_t": [0.0, 0.6313, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=7.9056, E_V=-0.4278V), (pH=7.1833, E_V=-0.3833V), (pH=6.7611, E_V=-0.3656V)], "adaptive_t": [0.0, 0.6313, 1.0]}
- **DmsRegEq_6: Ni | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.7611, E_V=-0.3656V), (pH=6.0611, E_V=-0.3433V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 74, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 73], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.7611, E_V=-0.3656V), (pH=6.0611, E_V=-0.3433V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.7611, E_V=-0.3656V), (pH=6.0611, E_V=-0.3433V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Ni | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0611, E_V=-0.3433V), (pH=5.15, E_V=-0.3344V), (pH=0, E_V=-0.3344V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 551, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 86, 550], "t_params": [0.0, 0.1503, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0611, E_V=-0.3433V), (pH=5.15, E_V=-0.3344V), (pH=0, E_V=-0.3344V)], "envelope_t": [0.0, 0.1503, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.0611, E_V=-0.3433V), (pH=5.15, E_V=-0.3344V), (pH=0, E_V=-0.3344V)], "adaptive_t": [0.0, 0.1503, 1.0]}
- **DmsRegEq_8: Ni2+ | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.3722, E_V=1.0122V), (pH=5.05, E_V=1.0633V), (pH=4.9833, E_V=1.0789V), (pH=4.8833, E_V=1.0922V), (pH=4.8167, E_V=1.1078V), (pH=4.7944, E_V=1.1078V), (pH=4.7278, E_V=1.1233V), (pH=4.7056, E_V=1.1233V), (pH=4.6389, E_V=1.1389V), (pH=4.6167, E_V=1.1389V), (pH=4.55, E_V=1.1544V), (pH=4.5278, E_V=1.1544V), (pH=4.4611, E_V=1.17V), (pH=4.4389, E_V=1.17V), (pH=4.3722, E_V=1.1856V), (pH=4.35, E_V=1.1856V), (pH=4.2722, E_V=1.2033V), (pH=4.25, E_V=1.2033V), (pH=4.1278, E_V=1.2278V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 16, "separation_added": 0, "anchor_disabled": 1, "raw_n": 210, "compact_n": 19, "compact_target_n": 6, "compact_indices": [0, 52, 65, 80, 93, 95, 108, 110, 123, 125, 138, 140, 153, 155, 168, 170, 185, 187, 209], "t_params": [0.0, 0.2576, 0.3117, 0.3914, 0.4454, 0.463, 0.517, 0.5346, 0.5886, 0.6062, 0.6603, 0.6778, 0.7319, 0.7494, 0.8035, 0.821, 0.884, 0.9016, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.3722, E_V=1.0122V), (pH=5.05, E_V=1.0633V), (pH=4.9833, E_V=1.0789V), (pH=4.8833, E_V=1.0922V), (pH=4.8167, E_V=1.1078V), (pH=4.7944, E_V=1.1078V), (pH=4.7278, E_V=1.1233V), (pH=4.7056, E_V=1.1233V), (pH=4.6389, E_V=1.1389V), (pH=4.6167, E_V=1.1389V), (pH=4.55, E_V=1.1544V), (pH=4.5278, E_V=1.1544V), (pH=4.4611, E_V=1.17V), (pH=4.4389, E_V=1.17V), (pH=4.3722, E_V=1.1856V), (pH=4.35, E_V=1.1856V), (pH=4.2722, E_V=1.2033V), (pH=4.25, E_V=1.2033V), (pH=4.1278, E_V=1.2278V)], "envelope_t": [0.0, 0.2576, 0.3117, 0.3914, 0.4454, 0.463, 0.517, 0.5346, 0.5886, 0.6062, 0.6603, 0.6778, 0.7319, 0.7494, 0.8035, 0.821, 0.884, 0.9016, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.3722, E_V=1.0122V), (pH=5.05, E_V=1.0633V), (pH=4.1278, E_V=1.2278V)], "adaptive_t": [0.0, 0.2583, 1.0]}
- **DmsRegEq_9: Ni2+ | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.1278, E_V=1.2278V), (pH=2.6611, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 211, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 210], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.1278, E_V=1.2278V), (pH=2.6611, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.1278, E_V=1.2278V), (pH=2.6611, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_10: Ni(OH)2 | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.2389, E_V=-0.5478V), (pH=11.2389, E_V=0.2567V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 363, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 362], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.2389, E_V=-0.5478V), (pH=11.2389, E_V=0.2567V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=11.2389, E_V=-0.5478V), (pH=11.2389, E_V=0.2567V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_11: [Ni(Glyc)3]- | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.2389, E_V=0.2567V), (pH=10.2722, E_V=0.4767V), (pH=9.8167, E_V=0.5633V), (pH=9.45, E_V=0.6167V), (pH=8.8611, E_V=0.6633V), (pH=7.9056, E_V=0.6878V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "budget", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 495, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 186, 266, 323, 397, 494], "t_params": [0.0, 0.294, 0.4315, 0.5414, 0.7165, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.2389, E_V=0.2567V), (pH=10.2722, E_V=0.4767V), (pH=9.8167, E_V=0.5633V), (pH=9.45, E_V=0.6167V), (pH=8.8611, E_V=0.6633V), (pH=7.9056, E_V=0.6878V)], "envelope_t": [0.0, 0.294, 0.4315, 0.5414, 0.7165, 1.0], "adaptive_n": 7, "adaptive_pts": [(pH=11.2389, E_V=0.2567V), (pH=10.2722, E_V=0.4767V), (pH=9.8167, E_V=0.5633V), (pH=9.45, E_V=0.6167V), (pH=9.1278, E_V=0.6478V), (pH=8.8611, E_V=0.6633V), (pH=7.9056, E_V=0.6878V)], "adaptive_t": [0.0, 0.294, 0.4315, 0.5414, 0.6373, 0.7166, 1.0]}
- **DmsRegEq_12: [Ni(Glyc)2] | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9056, E_V=0.6878V), (pH=7.6389, E_V=0.6967V), (pH=7.2278, E_V=0.7211V), (pH=6.7611, E_V=0.7656V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 139, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 28, 76, 138], "t_params": [0.0, 0.2325, 0.5915, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9056, E_V=0.6878V), (pH=7.6389, E_V=0.6967V), (pH=7.2278, E_V=0.7211V), (pH=6.7611, E_V=0.7656V)], "envelope_t": [0.0, 0.2325, 0.5915, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.9056, E_V=0.6878V), (pH=7.6389, E_V=0.6967V), (pH=7.2278, E_V=0.7211V), (pH=6.7611, E_V=0.7656V)], "adaptive_t": [0.0, 0.2325, 0.5915, 1.0]}
- **DmsRegEq_13: [Ni(Glyc)]+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.7611, E_V=0.7656V), (pH=6.4611, E_V=0.8033V), (pH=6.0611, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 111, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 44, 110], "t_params": [0.0, 0.4271, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.7611, E_V=0.7656V), (pH=6.4611, E_V=0.8033V), (pH=6.0611, E_V=0.87V)], "envelope_t": [0.0, 0.4271, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.7611, E_V=0.7656V), (pH=6.4611, E_V=0.8033V), (pH=6.0611, E_V=0.87V)], "adaptive_t": [0.0, 0.4271, 1.0]}
- **DmsRegEq_14: Ni2+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0611, E_V=0.87V), (pH=5.7167, E_V=0.9344V), (pH=5.3722, E_V=1.0122V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 127, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 60, 126], "t_params": [0.0, 0.4981, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0611, E_V=0.87V), (pH=5.7167, E_V=0.9344V), (pH=5.3722, E_V=1.0122V)], "envelope_t": [0.0, 0.4981, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.0611, E_V=0.87V), (pH=5.7167, E_V=0.9344V), (pH=5.3722, E_V=1.0122V)], "adaptive_t": [0.0, 0.4981, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Ni | Ni(OH)2**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.7122V), (pH=11.2389, E_V=-0.5478V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 324, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 323], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.7122V), (pH=11.2389, E_V=-0.5478V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.7122V), (pH=11.2389, E_V=-0.5478V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Ni2O3.H2O | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.6433V), (pH=4.1278, E_V=1.2278V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 1153, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1152], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.6433V), (pH=4.1278, E_V=1.2278V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.6433V), (pH=4.1278, E_V=1.2278V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_17: Ni(OH)2 | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.0944V), (pH=11.2389, E_V=0.2567V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 323, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 322], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.0944V), (pH=11.2389, E_V=0.2567V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.0944V), (pH=11.2389, E_V=0.2567V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: Ni3O4.2H2O | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.5011V), (pH=5.3722, E_V=1.0122V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0012, "resolution_tau_norm": 0.0012, "stop_epsilon": 0.0012, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1008, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1007], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.5011V), (pH=5.3722, E_V=1.0122V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.5011V), (pH=5.3722, E_V=1.0122V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)3]-, [Ni(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.9056, E_V=-0.4278V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)2], [Ni(Glyc)]+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.7611, E_V=-0.3656V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)]+, Ni2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0611, E_V=-0.3433V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)3]-, [Ni(Glyc)2], Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_11, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.9056, E_V=0.6878V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)2], [Ni(Glyc)]+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.7611, E_V=0.7656V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)]+, Ni2+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0611, E_V=0.87V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.3344V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2.6611, E_V=1.4V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2, [Ni(Glyc)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_10, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.2389, E_V=-0.5478V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, [Ni(Glyc)3]-, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.2389, E_V=0.2567V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.3722, E_V=1.0122V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_9, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.1278, E_V=1.2278V)
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.7122V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.0944V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.5011V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.6433V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ni**
  -- included: [Ni2+, [Ni(OH)]+, [Ni(OH)2], [Ni(OH)3]-, [Ni4(OH)4]4+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-, Ni(OH)2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, Ni]
  -- excluded: [HNiO2-, NiO, [Ni(OH)2](s)]

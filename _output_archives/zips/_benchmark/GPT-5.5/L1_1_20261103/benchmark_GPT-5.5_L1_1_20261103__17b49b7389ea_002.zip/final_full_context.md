## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build and interpret a two-dimensional Pourbaix diagram for nickel in a glycine-containing aqueous solution. The goal is to identify where soluble Ni-glycinate complexes predominate or are stable relative to other nickel aqueous species and solid/passivating phases under the requested total concentrations and medium conditions.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv",
      "L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png",
      "L1_call_01/solver/topology_Ni_+_Glycine_Ni.json",
      "L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md",
      "L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.json",
      "L1_call_01/solver/speciation_full_Ni_+_Glycine.csv"
    ],
    "elapsed_s": 8146.6
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build and interpret a two-dimensional Pourbaix diagram for nickel in a glycine-containing aqueous solution. The goal is to identify where soluble Ni-glycinate complexes predominate or are stable relative to other nickel aqueous species and solid/passivating phases under the requested total concentrations and medium conditions.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md",
      "L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png",
      "L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv",
      "L1_call_01/solver/speciation_full_Ni_+_Glycine.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Build a 2-D Pourbaix diagram for nickel in the presence of glycine, with 1 mM Ni and 10 mM glycine, at 25 C and I=0.1 m. Identify the stability window of any soluble Ni-glycinate complexes.

## Assistant
<summary>I’ll run one joint Pourbaix calculation for the single Ni–glycine solution at the requested composition and conditions, then inspect the generated artifacts for the soluble Ni-glycinate stability window and convergence evidence.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: Ni, glycine, 25 °C, I=0.1 M, and a 2-D pH–E Pourbaix sweep are within the supported pipeline and SRD-46/Atlas species set.

## Result
Computed a Ni-centered Pourbaix predominance map for 1 mM total Ni and 10 mM total glycine at 25 °C, I=0.1 M, vs SHE over pH 0–14 and E=-1.2 to 1.4 V. Final classified-grid spacing was ΔpH=0.011111111 and ΔE=0.0022222222 V. The topology has 9 dominant labels, 9 connected regions, 18 boundary curves, 10 internal junctions, and 6 sweep-limit junctions; no disconnected dominant species were reported. Classification diagnostics in the map CSV report fixer_marks=0. The full-speciation CSV contains 16,918 coarse-unrefined plus 108,014 refined rows and exposes converged/iterations/residual columns; opened rows showed converged=1 with small residuals, but the opened artifacts did not provide a separate aggregate all-row convergence count.

## Analysis
Thermodynamic inputs favor Ni-glycinate once glycine is deprotonated: the card gives [HGlycine] single-protonation log_beta=+9.5700, while Ni complexes have cumulative log_beta +5.7400 for [Ni(Glyc)]+, +10.5800 for [Ni(Glyc)2], and +14.1000 for [Ni(Glyc)3]-. Thus acidity suppresses complexation, but near neutral/alkaline pH the deprotonated ligand stabilizes soluble Ni(II) against free Ni2+ and, over a finite window, against solids.

Topology roster used: DmsReg_8 {[Ni(Glyc)]+} is bounded by junctions at (pH 6.0611,E -0.3433), (6.7611,-0.3656), (6.7611,0.7656), and (6.0611,0.8700). DmsReg_7 {[Ni(Glyc)2]} is bounded by (6.7611,-0.3656), (7.9056,-0.4278), (7.9056,0.6878), and (6.7611,0.7656). DmsReg_6 {[Ni(Glyc)3]-} is bounded by (7.9056,-0.4278), (11.2389,-0.5478), (11.2389,0.2567), and (7.9056,0.6878). Key boundaries are DmsRegEq_3 [Ni(Glyc)]+|Ni2+ at pH 6.0611, DmsRegEq_2 [Ni(Glyc)2]|[Ni(Glyc)]+ over pH 6.7611–6.7944, DmsRegEq_1 [Ni(Glyc)3]-|[Ni(Glyc)2] over pH 7.9056–7.9722, DmsRegEq_10 Ni(OH)2|[Ni(Glyc)3]- at pH 11.2389, and redox/passivation boundaries to Ni metal or Ni oxides at the listed E spans.

At the center-potential reference line E=0.1 V, the dominance ladder is Ni2+ through pH 6.0667, [Ni(Glyc)]+ from pH 6.0778–6.7889, [Ni(Glyc)2] from 6.8000–7.9667, [Ni(Glyc)3]- from 7.9778–11.2333, then Ni(OH)2 from 11.2444–13.8889 and Ni3O4.2H2O above pH 13.9000. This is the clearest practical soluble-glycinate window at mildly oxidizing E: approximately pH 6.1–11.2, with ligand denticity/stoichiometry increasing as pH rises.

Potential limits depend strongly on pH. At pH 7, the E sweep gives Ni metal up to -0.3756 V, [Ni(Glyc)2] from -0.3733 to 0.7400 V, Ni3O4.2H2O from 0.7422 to 0.9156 V, Ni2O3.H2O from 0.9178 to 1.0556 V, and NiO2.2H2O from 1.0578 to 1.4 V. Chemically, reducing conditions plate/passivate as Ni metal; oxidizing conditions form Ni oxide/hydroxide solids, while intermediate potentials keep Ni(II) soluble as glycine complexes. Above pH about 11.24 the tris-glycinate field loses to Ni(OH)2/passivating oxide chemistry: hydroxide activity and solid stability overcome ligand stabilization.

## Artifacts
L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md
L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png
L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv
L1_call_01/solver/speciation_full_Ni_+_Glycine.csv
L1_call_01/thermodynamic_reference_constants.md

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

For the requested **1 mM Ni + 10 mM glycine** solution at **25 °C, I = 0.1 m**, the computed Ni Pourbaix diagram shows a clear soluble **Ni(II)–glycinate stability window** between acidic free-Ni behavior and alkaline precipitation/passivation.

The soluble glycine-complex field begins near **pH ≈ 6.1**, where deprotonated glycine becomes available enough to bind Ni(II), and extends to about **pH ≈ 11.2** before **Ni(OH)₂ / oxide-hydroxide solid phases** become dominant. Within that soluble window, the dominant complex shifts with increasing pH:

- **[Ni(Glyc)]⁺**: roughly pH **6.1–6.8**
- **[Ni(Glyc)₂]**: roughly pH **6.8–8.0**
- **[Ni(Glyc)₃]⁻**: roughly pH **8.0–11.2**

At a representative mildly oxidizing line, **E = 0.1 V vs SHE**, the practical soluble-glycinate window is therefore approximately:

> **pH 6.1–11.2**, with increasing glycine coordination as pH rises.

Chemically, this is the expected pattern: glycine is strongly protonated at low pH, suppressing coordination and leaving **Ni²⁺** dominant. As pH rises, glycine deprotonates and increasingly stabilizes soluble Ni(II) as mono-, bis-, then tris-glycinate complexes. At still higher pH, hydroxide competition and solid-phase stability overtake ligand stabilization, so **Ni(OH)₂ and oxidized Ni oxide/hydroxide phases** dominate. Reducing potentials instead favor **Ni metal**, while strongly oxidizing potentials favor Ni oxide/hydroxide solids.

## Evidence

- The calculation was run for **1 mM total Ni and 10 mM total glycine at 25 °C, I = 0.1 M**, over **pH 0–14** and **E = −1.2 to 1.4 V vs SHE**.
- Grid resolution: **ΔpH = 0.011111111** and **ΔE = 0.0022222222 V**.
- The topology contained **9 dominant labels**, **9 connected regions**, **18 boundary curves**, **10 internal junctions**, and **6 sweep-limit junctions**.
- Reported Ni-glycinate fields:
  - **[Ni(Glyc)]⁺** bounded by junctions at approximately **pH 6.0611–6.7611**.
  - **[Ni(Glyc)₂]** bounded by approximately **pH 6.7611–7.9056**.
  - **[Ni(Glyc)₃]⁻** bounded by approximately **pH 7.9056–11.2389**.
- At **E = 0.1 V**, the dominance sequence was:
  - **Ni²⁺** through **pH 6.0667**
  - **[Ni(Glyc)]⁺** from **pH 6.0778–6.7889**
  - **[Ni(Glyc)₂]** from **pH 6.8000–7.9667**
  - **[Ni(Glyc)₃]⁻** from **pH 7.9778–11.2333**
  - **Ni(OH)₂** from **pH 11.2444–13.8889**
  - **Ni₃O₄·2H₂O** above **pH 13.9000**
- At **pH 7**, the E sweep showed:
  - **Ni metal** up to **−0.3756 V**
  - **[Ni(Glyc)₂]** from **−0.3733 to 0.7400 V**
  - Oxide/hydroxide phases at higher potentials.
- Thermodynamic constants used in the assembled card included cumulative log β values:
  - **[Ni(Glyc)]⁺: log β = +5.7400**
  - **[Ni(Glyc)₂]: log β = +10.5800**
  - **[Ni(Glyc)₃]⁻: log β = +14.1000**
  - Glycine protonation **[HGlycine]: log β = +9.5700**
- Convergence support: the full-speciation CSV included **converged**, **iterations**, and **residual** columns; opened rows showed **converged = 1** with small residuals. The map CSV reported **fixer_marks = 0**.

## Artifacts

- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png`
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md`
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni.json`
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv`
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
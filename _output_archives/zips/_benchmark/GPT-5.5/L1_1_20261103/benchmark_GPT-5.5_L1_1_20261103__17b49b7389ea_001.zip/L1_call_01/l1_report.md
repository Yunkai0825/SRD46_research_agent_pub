## Doability
Doable: Ni, glycine, 25 °C, I=0.1 M, and a 2-D pH–E Pourbaix sweep are within the supported pipeline and SRD-46/Atlas species set.

## Result
Computed a Ni-centered Pourbaix predominance map for 1 mM total Ni and 10 mM total glycine at 25 °C, I=0.1 M, vs SHE over pH 0–14 and E=-1.2 to 1.4 V. Final classified-grid spacing was ΔpH=0.011111111 and ΔE=0.0022222222 V. The topology has 9 dominant labels, 9 connected regions, 18 boundary curves, 10 internal junctions, and 6 sweep-limit junctions; no disconnected dominant species were reported. Classification diagnostics in the map CSV report fixer_marks=0. The full-speciation CSV contains 16,918 coarse-unrefined plus 108,014 refined rows and exposes converged/iterations/residual columns; opened rows showed converged=1 with small residuals, but the opened artifacts did not provide a separate aggregate all-row convergence count.

## Analysis
Thermodynamic inputs favor Ni-glycinate once glycine is deprotonated: the card gives [HGlycine] single-protonation log_beta=+9.5700, while Ni complexes have cumulative log_beta +5.7400 for [Ni(Glyc)]+, +10.5800 for [Ni(Glyc)2], and +14.1000 for [Ni(Glyc)3]-. Thus acidity suppresses complexation, but near neutral/alkaline pH the deprotonated ligand stabilizes soluble Ni(II) against free Ni2+ and, over a finite window, against solids.

Topology roster used: DmsReg_8 {[Ni(Glyc)]+} is bounded by junctions at (pH 6.0611,E -0.3433), (6.7611,-0.3656), (6.7611,0.7656), and (6.0611,0.8700). DmsReg_7 {[Ni(Glyc)2]} is bounded by (6.7611,-0.3656), (7.9056,-0.4278), (7.9056,0.6878), and (6.7611,0.7656). DmsReg_6 {[Ni(Glyc)3]-} is bounded by (7.9056,-0.4278), (11.2389,-0.5478), (11.2389,0.2567), and (7.9056,0.6878). Key boundaries are DmsRegEq_3 [Ni(Glyc)]+|Ni2+ at pH 6.0611, DmsRegEq_2 [Ni(Glyc)2]|[Ni(Glyc)]+ over pH 6.7611–6.7944, DmsRegEq_1 [Ni(Glyc)3]-|[Ni(Glyc)2] over pH 7.9056–7.9722, DmsRegEq_10 Ni(OH)2|[Ni(Glyc)3]- at pH 11.2389, and redox/passivation boundaries to Ni metal or Ni oxides at the listed E spans.

At the center-potential reference line E=0.1 V, the dominance ladder is Ni2+ through pH 6.0667, [Ni(Glyc)]+ from pH 6.0778–6.7889, [Ni(Glyc)2] from 6.8000–7.9667, [Ni(Glyc)3]- from 7.9778–11.2333, then Ni(OH)2 from 11.2444–13.8889 and Ni3O4.2H2O above pH 13.9000. This is the clearest practical soluble-glycinate window at mildly oxidizing E: approximately pH 6.1–11.2, with ligand denticity/stoichiometry increasing as pH rises.

Potential limits depend strongly on pH. At pH 7, the E sweep gives Ni metal up to -0.3756 V, [Ni(Glyc)2] from -0.3733 to 0.7400 V, Ni3O4.2H2O from 0.7422 to 0.9156 V, Ni2O3.H2O from 0.9178 to 1.0556 V, and NiO2.2H2O from 1.0578 to 1.4 V. Chemically, reducing conditions plate/passivate as Ni metal; oxidizing conditions form Ni oxide/hydroxide solids, while intermediate potentials keep Ni(II) soluble as glycine complexes. Above pH about 11.24 the tris-glycinate field loses to Ni(OH)2/passivating oxide chemistry: hydroxide activity and solid stability overcome ligand stabilization.

## Artifacts
L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md
L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png
L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv
L1_call_01/solver/speciation_full_Ni_+_Glycine.csv
L1_call_01/thermodynamic_reference_constants.md
[Purpose: Build and interpret a two-dimensional Pourbaix diagram for nickel in a glycine-containing aqueous solution. The goal is to identify where soluble Ni-glycinate complexes predominate or are stable relative to other nickel aqueous species and solid/passivating phases under the requested total concentrations and medium conditions.]
[Tasks:
For one solution containing 1 mM total nickel and 10 mM total glycine at 25 C and ionic strength I=0.1 m, generate a 2-D Pourbaix diagram over an appropriate pH-pE or pH-Eh grid for nickel in the presence of glycine. Report the predominance topology for nickel species, especially any soluble Ni-glycinate complexes, and identify their stability window in pH and potential/redox space with convergence evidence; write the PNG/CSV/topology artifacts needed to inspect the diagram.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

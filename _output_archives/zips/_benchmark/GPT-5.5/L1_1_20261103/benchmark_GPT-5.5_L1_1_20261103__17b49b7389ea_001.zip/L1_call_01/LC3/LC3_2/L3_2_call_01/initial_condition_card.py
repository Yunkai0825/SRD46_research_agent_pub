inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task specifies ionic strength I=0.1 m; represented on the catalog mol/L ionic-strength handle."},
  {"id": "Ni", "lhs": lambda s: s.total["Ni"], "value": 1e-3, "basis": "known", "note": "Task specifies 1 mM total nickel; element total is used because redox is included in the Pourbaix sweep."},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "Task specifies 10 mM total glycine."},
]
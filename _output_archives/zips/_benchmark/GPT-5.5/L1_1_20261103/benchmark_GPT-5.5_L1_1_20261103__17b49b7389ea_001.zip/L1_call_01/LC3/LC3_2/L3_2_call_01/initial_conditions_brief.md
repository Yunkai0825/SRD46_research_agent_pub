# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # Task specifies 25 C.
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # Task specifies ionic strength I=0.1 m; represented on the catalog mol/L ionic-strength handle.
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total nickel; element total is used because redox is included in the Pourbaix sweep.
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # Task specifies 10 mM total glycine.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix diagram coordinate scanned by L3_3.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix redox-potential coordinate scanned by L3_3.'},
]

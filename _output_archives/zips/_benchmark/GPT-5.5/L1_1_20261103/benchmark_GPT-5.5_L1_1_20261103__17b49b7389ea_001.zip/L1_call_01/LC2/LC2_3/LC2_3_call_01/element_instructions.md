# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: build a stability/predominance Pourbaix diagram for nickel in glycine solution at 1 mM total Ni and 10 mM total glycine, not a trace-corrosion convention diagram; aqueous nickel speciation and ligand competition at those totals govern identity.
- Aqueous species: keep chemically distinct mononuclear hydrolysis species, polynuclear hydrolysis species, and Ni-glycinato complexes because they can occupy different pH/concentration regions; collapse only alternative notation/source spellings of the same aqueous ion at the same hydration convention.
- Glycine context: assume the free glycine acid-base and ligand mass-balance model is supplied outside the Ni dedup table; do not invent missing ligand species or treat Ni-glycinate complexes as duplicates of inorganic Ni species.
- Solids and hydration: at 25 C in water with activity near unity, use hydrated/hydrous Ni hydroxide/oxide passive phases for the stable-phase hull; anhydrous NiO is not a separate competing passive phase when the same Ni(II) hydroxide chemistry is represented by hydrated Ni(OH)2.
- Counterion solids: no carbonate or other counterion solids are in scope for this glycine-only medium unless explicitly listed, so do not retain or create such branches by analogy.
- Redox chain: retain elemental Ni and distinct higher-valent or mixed-valent hydrous nickel oxide phases because they define different potential regions on the Pourbaix diagram.
- Phase question: answer which phase is stable/predominant, so collapse duplicate polymorph/source/hydration spellings to one representative, preferring the lower aligned chemical potential when the entries are the same physical state.
- Gases and references: keep elemental Ni(s) as the metal reference/redox phase; no gas fugacity branch is required for this Ni-only inventory.

## Element instructions

- **Ni**: For Ni, collapse true notation/source duplicates such as Ni2+ versus [Ni]2+ and equivalent mononuclear trihydroxo spellings, and for the Ni(II) passive solid keep the hydrated Ni(OH)2 representative over anhydrous NiO or duplicate [Ni(OH)2](s); retain distinct Ni-glycinate complexes, monomeric versus polynuclear hydrolysis species, elemental Ni, and higher-valent or mixed-valent hydrous oxide phases because they can occupy different regions of the glycine Pourbaix diagram.

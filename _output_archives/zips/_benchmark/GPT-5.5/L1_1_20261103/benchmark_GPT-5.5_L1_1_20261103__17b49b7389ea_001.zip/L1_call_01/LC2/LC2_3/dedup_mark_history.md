# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Ni2+ and [Ni]2+ are the same aqueous mononuclear Ni(II) ion, so the SRD-46 representative is kept preferentially. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Ni2+ and [Ni]2+ are the same aqueous mononuclear Ni(II) ion, so the SRD-46 representative is kept preferentially. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Both entries are chemically distinct aqueous Ni(II) hydrolysis species with different nuclearity, so both are retained for glycine Pourbaix speciation. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Both entries are chemically distinct aqueous Ni(II) hydrolysis species with different nuclearity, so both are retained for glycine Pourbaix speciation. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Neutral mononuclear nickel hydrolysis species are chemically distinct aqueous Ni species and can predominate in different pH regions. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — The two rows are equivalent mononuclear aqueous Ni(II) trihydroxo species in different notation, so the SRD-46 representation is retained. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — The two rows are equivalent mononuclear aqueous Ni(II) trihydroxo species in different notation, so the SRD-46 representation is retained. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — The 1:1 Ni-glycinato complex is a distinct aqueous ligand complex relevant to Ni speciation in glycine solution. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — The 1:2 Ni-glycinato complex is a distinct aqueous ligand complex relevant to Ni speciation in glycine solution. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — The 1:3 Ni-glycinato complex is a distinct aqueous ligand complex relevant to Ni speciation in glycine solution. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: kept — Elemental nickel metal is the required Ni redox reference phase for the Pourbaix diagram. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Kept the hydrated Ni(II) hydroxide representative with the lower aligned chemical potential, while collapsing duplicate hydroxide notation and excluding anhydrous NiO as a separate passive phase for this glycine Pourbaix context. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Kept the hydrated Ni(II) hydroxide representative with the lower aligned chemical potential, while collapsing duplicate hydroxide notation and excluding anhydrous NiO as a separate passive phase for this glycine Pourbaix context. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Kept the hydrated Ni(II) hydroxide representative with the lower aligned chemical potential, while collapsing duplicate hydroxide notation and excluding anhydrous NiO as a separate passive phase for this glycine Pourbaix context. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: kept — The mixed-valent hydrous nickel oxide phase is distinct and may define a separate potential region. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: kept — The Ni(III) hydrous oxide phase is distinct and may define a separate potential region. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: kept — The Ni(IV) hydrous oxide phase is distinct and may define a separate potential region. |
| — | `[?]` | SRD-46 | generation 1: dropped — The elementless unknown aqueous placeholder is not a chemically defined in-scope species for the Ni-glycine Pourbaix inventory. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Free glycinate is a valid ligand acid-base species needed for the glycine mass-balance context. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine is a valid ligand acid-base species needed for the glycine mass-balance context. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is a valid ligand acid-base species needed for the glycine mass-balance context. |

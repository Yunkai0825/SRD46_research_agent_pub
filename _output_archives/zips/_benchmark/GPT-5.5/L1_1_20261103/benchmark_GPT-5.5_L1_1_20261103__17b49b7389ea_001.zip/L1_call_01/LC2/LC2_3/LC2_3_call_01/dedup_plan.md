# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: build a stability/predominance Pourbaix diagram for nickel in glycine solution at 1 mM total Ni and 10 mM total glycine, not a trace-corrosion convention diagram; aqueous nickel speciation and ligand competition at those totals govern identity.
- Aqueous species: keep chemically distinct mononuclear hydrolysis species, polynuclear hydrolysis species, and Ni-glycinato complexes because they can occupy different pH/concentration regions; collapse only alternative notation/source spellings of the same aqueous ion at the same hydration convention.
- Glycine context: assume the free glycine acid-base and ligand mass-balance model is supplied outside the Ni dedup table; do not invent missing ligand species or treat Ni-glycinate complexes as duplicates of inorganic Ni species.
- Solids and hydration: at 25 C in water with activity near unity, use hydrated/hydrous Ni hydroxide/oxide passive phases for the stable-phase hull; anhydrous NiO is not a separate competing passive phase when the same Ni(II) hydroxide chemistry is represented by hydrated Ni(OH)2.
- Counterion solids: no carbonate or other counterion solids are in scope for this glycine-only medium unless explicitly listed, so do not retain or create such branches by analogy.
- Redox chain: retain elemental Ni and distinct higher-valent or mixed-valent hydrous nickel oxide phases because they define different potential regions on the Pourbaix diagram.
- Phase question: answer which phase is stable/predominant, so collapse duplicate polymorph/source/hydration spellings to one representative, preferring the lower aligned chemical potential when the entries are the same physical state.
- Gases and references: keep elemental Ni(s) as the metal reference/redox phase; no gas fugacity branch is required for this Ni-only inventory.

[Purpose: Build a joint two-dimensional E-pH Pourbaix diagram for one mixed aqueous solution containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia at 25 C and ionic strength 0.1 molal. The goal is to identify Cu and Fe predominance/speciation regions, shared-ligand partitioning, and the principal Pourbaix region boundaries and junctions using only the equilibrium constants and redox potentials actually committed to and used by the solver.]
[Tasks:
For a single solution containing total 1 mM Cu(II), total 1 mM Fe(III), total 10 mM citrate, total 10 mM glycine, total 0.1 M chloride, and total 0.1 M ammonia at 25 C and ionic strength I = 0.1 molal, build the joint Cu-Fe-citrate-glycine-chloride-ammonia chemical system and compute a two-dimensional E-pH Pourbaix diagram over pH 0 to 14 and E = -1.0 to +1.5 V versus SHE. Treat all components as present in the same pot so metals compete for the shared ligand pools. Report which Cu and Fe species predominate across the field, how each element partitions among aqueous complexes, solids, and redox states, and identify the principal region boundaries and junctions. Include the equilibrium constants, redox potentials, and any solver-committed values actually used for the boundaries and interpretations; provide topology/label-map artifacts, full-speciation tables, convergence evidence, and plots suitable for inspecting the diagram.
]
[Pair: pair_key=`m68_l5760`, metal_id=68, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5760_beta32_net1` | `[HL] + [H] <=> [H2L]` | vlm_93627@(25.0,0.1) = K+2.330 | 15 | +2.323 / +2.440 / +2.498 / +2.790 | vlm_93627@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5760_beta79_net1` | `[L] + [H] <=> [HL]` | vlm_93606@(25.0,0.1) = K+9.570 | 13 | +9.250 / +9.778 / +9.755 / +10.200 | vlm_93606@(25.0,0.1) = K+9.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

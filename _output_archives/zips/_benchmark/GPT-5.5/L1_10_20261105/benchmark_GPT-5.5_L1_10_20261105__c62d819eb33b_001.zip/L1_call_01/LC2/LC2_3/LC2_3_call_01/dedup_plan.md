# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose is a joint mixed-pot Cu/Fe E-pH predominance/speciation diagram at the stated totals, not a generic corrosion diagram; ligand pools are shared and metal-ligand competition is in scope.
- Use the specified 25 C, I=0.1 molal, 1 mM Cu, 1 mM Fe, 10 mM citrate/glycine, 0.1 M chloride/ammonia context; do not apply the 1e-6 M corrosion convention.
- Aqueous species are duplicates only when they have the same metal oxidation state, nuclearity, protonation/hydrolysis, ligand identity/count, charge role, and physical meaning; formula spelling alone may be notation.
- Polynuclear aqueous complexes can matter at mM concentrations and are distinct from mononuclear complexes even if normalized cores look similar.
- Retain citrate, glycine, chloride, ammine, hydroxo, mixed hydroxo-ligand, and protonated-ligand complexes because all named ligands are present.
- Retain chloride/basic-chloride solids because chloride is 0.1 M; do not prune counterion solids as out of scope.
- Retain anhydrous oxides, hydrated hydroxides/oxyhydroxides, elemental metals, mixed-valence oxides, and high-valent aqueous redox states when chemically distinct; collapse only true source/polymorph/notation duplicates of the same physical phase.
- For exact Atlas/SRD-46 duplicates describing the same physical aqueous ion or solid, prefer the SRD-46 entry used with the ligand-equilibrium network unless the entries are visibly different physical phases.

Kept:
- `[Fe(OH)]2+` — SRD-46
- `[Fe2(OH)2]4+` — SRD-46

Rationale: `[FeOH]2+` from Atlas is a notation/source duplicate of the mononuclear Fe(III) hydroxo complex, so the SRD-46 entry is preferred, while the dinuclear SRD-46 complex is chemically distinct and retained.
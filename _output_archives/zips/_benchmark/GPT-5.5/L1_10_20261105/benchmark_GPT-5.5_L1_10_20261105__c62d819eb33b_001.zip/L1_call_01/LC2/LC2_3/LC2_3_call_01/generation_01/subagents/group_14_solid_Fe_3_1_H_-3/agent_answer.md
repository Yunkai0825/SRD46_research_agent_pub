Kept the three SRD-46 species:

- `[(Fe2O3)0.5(s,alpha)]` — SRD-46
- `[FeO(OH)(s,alpha)]` — SRD-46
- `[Fe(OH)3](s)` — SRD-46

Rationale: Retained distinct SRD-46 ferric oxide, oxyhydroxide, and hydroxide solid phases while dropping Atlas generic duplicate hydrated/anhydrous entries in favor of SRD-46.
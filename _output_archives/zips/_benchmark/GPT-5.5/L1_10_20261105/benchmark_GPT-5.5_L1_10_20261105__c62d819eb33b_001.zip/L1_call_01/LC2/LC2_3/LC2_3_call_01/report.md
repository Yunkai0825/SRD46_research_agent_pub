# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    379.91
- elapsed_s (total):  379.91
- llm_iterations:     41
- llm_tool_calls:     25

- n_groups:           76
- n_multi_groups:     14
- n_singletons:       62
- n_decisions:        76
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ and [Cu]+ are exact notation duplicates for aqueous Cu(I), so the SRD-46 entry is retained. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Kept both because they are distinct mononuclear and dinuclear aqueous Cu-chloro complexes, and polynuclear species are not duplicates of mononuclear complexes in the stated chloride-rich speciation context. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Cu2+ and [Cu]2+ are the same aqueous Cu(II) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Both SRD-46 aqueous hydroxo complexes are chemically distinct because they differ in nuclearity, so the mononuclear Cu(II) hydroxo ion and the dinuclear hydroxo complex are both retained. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe2+ and [Fe]2+ are the same aqueous Fe(II) ion, so the exact notation/source duplicate is collapsed in favor of the SRD-46 entry. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | The Atlas [HFeO2]- entry is a duplicate dehydrated notation for the same aqueous Fe(II) hydrolysis species as SRD-46 [Fe(OH)3]-, so the SRD-46 entry is retained. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and aligned chemical potential, so the SRD-46 entry is preferred. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | [FeOH]2+ and [Fe(OH)]2+ are the same mononuclear Fe(III) hydroxo aqueous complex so the SRD-46 notation is preferred, while [Fe2(OH)2]4+ is a distinct polynuclear species and is retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Both rows describe the same aqueous mononuclear Fe(III) dihydroxo complex with identical charge and physical meaning, so the SRD-46 entry is preferred over the Atlas duplicate. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Kept both because the mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct aqueous species and polynuclear complexes are in scope at the stated mM conditions. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O and [(Cu2O)0.5](s) are exact notation/nuclearity-normalization duplicates of the same cuprous oxide solid, so the SRD-46 entry is preferred. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Both rows describe the same neutral hydrated ferrous hydroxide solid phase, so the SRD-46 entry is kept preferentially over the Atlas duplicate. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent/reference aqueous species and is in scope for the specified 25 C electrolyte calculation. |
| aqueous | `Cu$+1:1 L2:2` | yes | This Cu(I) glycine complex is distinct and glycine complexes are in scope for the shared ligand speciation model. |
| aqueous | `Cu$+1:1 L3:2` | yes | This Cu(I) ammine complex is distinct and ammonia is present at high concentration in the specified system. |
| aqueous | `Cu$+1:1 L4:1` | yes | This Cu(I) chloride complex is distinct and chloride complexes are in scope at 0.1 M chloride. |
| aqueous | `Cu$+1:1 L4:3` | yes | This higher Cu(I) chloride complex has a distinct ligand count and charge and is in scope at high chloride. |
| aqueous | `Cu$+2:1 H:-2` | yes | This neutral Cu(II) hydroxo species is chemically distinct and hydroxo complexes are retained. |
| aqueous | `Cu$+2:1 H:-3` | yes | This Cu(II) hydroxo/oxo aqueous species is a distinct protonation state and remains in scope. |
| aqueous | `Cu$+2:1 H:-4` | yes | This Cu(II) oxo/hydroxo anion is a distinct aqueous hydrolysis species and remains in scope. |
| aqueous | `Cu$+2:1 L1:1` | yes | This polynuclear Cu(II) citrate complex is distinct and citrate complexes are explicitly retained. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | This hydroxo-citrate Cu(II) complex is distinct from the non-hydrolyzed citrate complex and is in scope. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | This protonated Cu(II) citrate complex is distinct and protonated ligand complexes are retained. |
| aqueous | `Cu$+2:1 L2:1` | yes | This Cu(II) monoglycine complex is distinct and glycine complexes are in scope. |
| aqueous | `Cu$+2:1 L2:2` | yes | This Cu(II) bis-glycine complex has a distinct ligand count and is in scope. |
| aqueous | `Cu$+2:1 L3:1` | yes | This Cu(II) monoammine complex is distinct and ammonia complexation is in scope. |
| aqueous | `Cu$+2:1 L3:2` | yes | This Cu(II) diammine complex has a distinct ligand count and is in scope. |
| aqueous | `Cu$+2:1 L3:3` | yes | This Cu(II) triammine complex has a distinct ligand count and is in scope. |
| aqueous | `Cu$+2:1 L3:4` | yes | This Cu(II) tetraammine complex has a distinct ligand count and is in scope. |
| aqueous | `Cu$+2:1 L4:1` | yes | This Cu(II) chloride complex is distinct from Cu(I) chloride species and is in scope at high chloride. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | This polynuclear hydroxo-citrate Cu(II) complex is distinct and polynuclear complexes can matter at mM concentrations. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | This polynuclear Cu(II) hydroxo-bis-citrate complex has distinct nuclearity and ligand count and is in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | This trinuclear Cu(II) hydroxo complex is distinct from mononuclear hydrolysis species and is in scope. |
| aqueous | `Fe$+2:1 H:-1` | yes | This Fe(II) monohydroxo complex is a distinct hydrolysis species and is in scope. |
| aqueous | `Fe$+2:1 H:-2` | yes | This Fe(II) dihydroxo complex has a distinct protonation state and is in scope. |
| aqueous | `Fe$+2:1 H:-4` | yes | This Fe(II) tetrahydroxo anion is a distinct hydrolysis species and is in scope. |
| aqueous | `Fe$+2:1 L1:1` | yes | This Fe(II) citrate complex is distinct and citrate complexation is in scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | This polynuclear Fe(II) hydroxo-citrate complex is distinct and polynuclear ligand complexes are retained. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | This protonated Fe(II) citrate complex is distinct and protonated citrate complexes are in scope. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | This doubly protonated Fe(II) citrate complex is distinct and protonated ligand complexes are retained. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | This Fe(II) bis-citrate protonated complex has distinct ligand count and charge and is in scope. |
| aqueous | `Fe$+2:1 L2:1` | yes | This Fe(II) glycine complex is distinct and glycine complexation is in scope. |
| aqueous | `Fe$+2:1 L2:2` | yes | This Fe(II) bis-glycine complex has a distinct ligand count and is in scope. |
| aqueous | `Fe$+2:1 L2:3` | yes | This Fe(II) tris-glycine complex has a distinct ligand count and charge and is in scope. |
| aqueous | `Fe$+2:1 L3:1` | yes | This Fe(II) monoammine complex is distinct and ammonia complexation is in scope. |
| aqueous | `Fe$+2:1 L3:2` | yes | This Fe(II) diammine complex has a distinct ligand count and is in scope. |
| aqueous | `Fe$+2:1 L3:3` | yes | This Fe(II) triammine complex has a distinct ligand count and is in scope. |
| aqueous | `Fe$+2:1 L3:4` | yes | This Fe(II) tetraammine complex has a distinct ligand count and is in scope. |
| aqueous | `Fe$+2:1 L4:1` | yes | This Fe(II) chloride complex is distinct and chloride complexation is in scope. |
| aqueous | `Fe$+3:1 H:-4` | yes | This Fe(III) tetrahydroxo species is distinct from Fe(II) hydrolysis species and is in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | This Fe(III) citrate complex is distinct from Fe(II) citrate and is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | This protonated Fe(III) citrate complex is distinct and protonated ligand complexes are retained. |
| aqueous | `Fe$+3:1 L2:1` | yes | This Fe(III) glycine complex is distinct and glycine complexation is in scope. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | This protonated Fe(III) glycine complex is distinct and in scope. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | This protonated Fe(III) bis-glycine complex has distinct ligand count and protonation and is in scope. |
| aqueous | `Fe$+3:1 L4:1` | yes | This Fe(III) monochloride complex is distinct and chloride complexation is in scope. |
| aqueous | `Fe$+3:1 L4:2` | yes | This Fe(III) dichloride complex has distinct ligand count and charge and is in scope. |
| aqueous | `Fe$+3:3 H:-4` | yes | This trinuclear Fe(III) hydroxo complex is distinct and polynuclear hydrolysis species are retained. |
| aqueous | `Fe$+6:1 H:-8` | yes | This high-valent ferrate aqueous redox state is chemically distinct and explicitly retained. |
| aqueous | `L1:1` | yes | The citrate base ligand species is part of the specified shared citrate pool and is in scope. |
| aqueous | `L1:1 H:1` | yes | This protonated citrate species is part of the citrate acid-base network and is in scope. |
| aqueous | `L1:1 H:2` | yes | This further protonated citrate species is part of the citrate acid-base network and is in scope. |
| aqueous | `L1:1 H:3` | yes | Neutral citric acid is part of the specified citrate acid-base pool and is in scope. |
| aqueous | `L2:1` | yes | The glycine base ligand species is part of the specified shared glycine pool and is in scope. |
| aqueous | `L2:1 H:1` | yes | Neutral glycine is part of the glycine acid-base network and is in scope. |
| aqueous | `L2:1 H:2` | yes | Protonated glycine is part of the glycine acid-base network and is in scope. |
| aqueous | `L3:1` | yes | Ammonia is a specified ligand at 0.1 M and is in scope. |
| aqueous | `L3:1 H:1` | yes | Ammonium is part of the ammonia acid-base pool and is in scope. |
| aqueous | `L4:1` | yes | Chloride ion is a specified high-concentration ligand and is in scope. |
| solid | `Cu$+0:1` | yes | Elemental copper is a distinct solid redox endpoint and is explicitly retained. |
| solid | `Cu$+1:1 L4:1` | yes | Solid CuCl is a distinct chloride solid and chloride solids are retained at 0.1 M chloride. |
| solid | `Cu$+2:2 L4:1 H:-3` | yes | This basic copper chloride solid is distinct and explicitly in scope for the high-chloride system. |
| solid | `Fe$+0:1` | yes | Elemental iron is a distinct solid redox endpoint and is explicitly retained. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite is a distinct mixed-valence iron oxide solid and is explicitly retained. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ and [Cu]+ are exact notation duplicates for aqueous Cu(I), so the SRD-46 entry is retained. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Cu2+ and [Cu]2+ are the same aqueous Cu(II) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe2+ and [Fe]2+ are the same aqueous Fe(II) ion, so the exact notation/source duplicate is collapsed in favor of the SRD-46 entry. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: The Atlas [HFeO2]- entry is a duplicate dehydrated notation for the same aqueous Fe(II) hydrolysis species as SRD-46 [Fe(OH)3]-, so the SRD-46 entry is retained. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and aligned chemical potential, so the SRD-46 entry is preferred. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: [FeOH]2+ and [Fe(OH)]2+ are the same mononuclear Fe(III) hydroxo aqueous complex so the SRD-46 notation is preferred, while [Fe2(OH)2]4+ is a distinct polynuclear species and is retained. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Both rows describe the same aqueous mononuclear Fe(III) dihydroxo complex with identical charge and physical meaning, so the SRD-46 entry is preferred over the Atlas duplicate. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O and [(Cu2O)0.5](s) are exact notation/nuclearity-normalization duplicates of the same cuprous oxide solid, so the SRD-46 entry is preferred. |
| `CuO` | Atlas | dissolution | LC2 element review: Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Both rows describe the same neutral hydrated ferrous hydroxide solid phase, so the SRD-46 entry is kept preferentially over the Atlas duplicate. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: c1ed7593fb36421891aa9a19d85e6331
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplication accepted. The table appropriately prefers SRD-46 for exact Atlas/SRD-46 notation duplicates while retaining chemically distinct aqueous complexes, polynuclear species, redox states, chloride solids, hydrated/anhydrous oxide-hydroxide phases, elemental endpoints, and mixed-valence iron oxide phases needed for the specified mixed Cu/Fe ligand-rich Pourbaix calculation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose is a joint mixed-pot Cu/Fe E-pH predominance/speciation diagram at the stated totals, not a generic corrosion diagram; ligand pools are shared and metal-ligand competition is in scope.
- Use the specified 25 C, I=0.1 molal, 1 mM Cu, 1 mM Fe, 10 mM citrate/glycine, 0.1 M chloride/ammonia context; do not apply the 1e-6 M corrosion convention.
- Aqueous species are duplicates only when they have the same metal oxidation state, nuclearity, protonation/hydrolysis, ligand identity/count, charge role, and physical meaning; formula spelling alone may be notation.
- Polynuclear aqueous complexes can matter at mM concentrations and are distinct from mononuclear complexes even if normalized cores look similar.
- Retain citrate, glycine, chloride, ammine, hydroxo, mixed hydroxo-ligand, and protonated-ligand complexes because all named ligands are present.
- Retain chloride/basic-chloride solids because chloride is 0.1 M; do not prune counterion solids as out of scope.
- Retain anhydrous oxides, hydrated hydroxides/oxyhydroxides, elemental metals, mixed-valence oxides, and high-valent aqueous redox states when chemically distinct; collapse only true source/polymorph/notation duplicates of the same physical phase.
- For exact Atlas/SRD-46 duplicates describing the same physical aqueous ion or solid, prefer the SRD-46 entry used with the ligand-equilibrium network unless the entries are visibly different physical phases.

## Element instructions

- **Cu**: For Cu, collapse only exact notation/source duplicates such as Cu+ vs [Cu]+, Cu2+ vs [Cu]2+, Cu2O vs [(Cu2O)0.5](s), CuO vs [CuO](s), and Cu(OH)2 vs [Cu(OH)2](s), preferring SRD-46. Keep distinct Cu(I)/Cu(II) ligand complexes, hydroxo species, multinuclear species, CuCl(s), basic copper chloride, and elemental Cu because they can occupy different E-pH/ligand regions in the stated high-chloride/ammonia/glycine/citrate system.
- **Fe**: For Fe, collapse only exact notation/source duplicates such as Fe2+ vs [Fe]2+, Fe3+ vs [Fe]3+, duplicate Fe hydroxide formula spellings, and duplicate generic solid hydroxide/oxide entries, preferring SRD-46 where it is the same physical phase. Keep Fe(II), Fe(III), Fe(VI), citrate/glycine/chloride/ammine/hydroxo complexes, polynuclear complexes, Fe metal, Fe3O4, distinct Fe hydroxide/oxyhydroxide/oxide solids such as goethite vs generic hydroxide, because these can define different Pourbaix/speciation regions.

Kept: `[Fe(OH)3]-` from SRD-46.

Rationale: `[Fe(OH)3]-` and `[HFeO2]-` represent the same aqueous Fe hydrolysis species in different notation, so the SRD-46 entry is preferred.
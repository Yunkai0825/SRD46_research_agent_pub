# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ and [Cu]+ are exact notation duplicates for aqueous Cu(I), so the SRD-46 entry is retained. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ and [Cu]+ are exact notation duplicates for aqueous Cu(I), so the SRD-46 entry is retained. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — This Cu(I) glycine complex is distinct and glycine complexes are in scope for the shared ligand speciation model. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — This Cu(I) ammine complex is distinct and ammonia is present at high concentration in the specified system. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — This Cu(I) chloride complex is distinct and chloride complexes are in scope at 0.1 M chloride. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Kept both because they are distinct mononuclear and dinuclear aqueous Cu-chloro complexes, and polynuclear species are not duplicates of mononuclear complexes in the stated chloride-rich speciation context. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Kept both because they are distinct mononuclear and dinuclear aqueous Cu-chloro complexes, and polynuclear species are not duplicates of mononuclear complexes in the stated chloride-rich speciation context. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — This higher Cu(I) chloride complex has a distinct ligand count and charge and is in scope at high chloride. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Cu2+ and [Cu]2+ are the same aqueous Cu(II) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Cu2+ and [Cu]2+ are the same aqueous Cu(II) ion, so the exact notation/source duplicate is collapsed in favor of SRD-46. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous hydroxo complexes are chemically distinct because they differ in nuclearity, so the mononuclear Cu(II) hydroxo ion and the dinuclear hydroxo complex are both retained. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous hydroxo complexes are chemically distinct because they differ in nuclearity, so the mononuclear Cu(II) hydroxo ion and the dinuclear hydroxo complex are both retained. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — This neutral Cu(II) hydroxo species is chemically distinct and hydroxo complexes are retained. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This Cu(II) hydroxo/oxo aqueous species is a distinct protonation state and remains in scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This Cu(II) oxo/hydroxo anion is a distinct aqueous hydrolysis species and remains in scope. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — This polynuclear Cu(II) citrate complex is distinct and citrate complexes are explicitly retained. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — This hydroxo-citrate Cu(II) complex is distinct from the non-hydrolyzed citrate complex and is in scope. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — This protonated Cu(II) citrate complex is distinct and protonated ligand complexes are retained. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — This Cu(II) monoglycine complex is distinct and glycine complexes are in scope. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — This Cu(II) bis-glycine complex has a distinct ligand count and is in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — This Cu(II) monoammine complex is distinct and ammonia complexation is in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — This Cu(II) diammine complex has a distinct ligand count and is in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — This Cu(II) triammine complex has a distinct ligand count and is in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — This Cu(II) tetraammine complex has a distinct ligand count and is in scope. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — This Cu(II) chloride complex is distinct from Cu(I) chloride species and is in scope at high chloride. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — This polynuclear hydroxo-citrate Cu(II) complex is distinct and polynuclear complexes can matter at mM concentrations. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — This polynuclear Cu(II) hydroxo-bis-citrate complex has distinct nuclearity and ligand count and is in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — This trinuclear Cu(II) hydroxo complex is distinct from mononuclear hydrolysis species and is in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental copper is a distinct solid redox endpoint and is explicitly retained. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O and [(Cu2O)0.5](s) are exact notation/nuclearity-normalization duplicates of the same cuprous oxide solid, so the SRD-46 entry is preferred. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O and [(Cu2O)0.5](s) are exact notation/nuclearity-normalization duplicates of the same cuprous oxide solid, so the SRD-46 entry is preferred. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — Solid CuCl is a distinct chloride solid and chloride solids are retained at 0.1 M chloride. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep the chemically distinct anhydrous CuO and hydrated Cu(OH)2 solid phases, collapsing the exact Atlas notation duplicates in favor of SRD-46. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — This basic copper chloride solid is distinct and explicitly in scope for the high-chloride system. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ and [Fe]2+ are the same aqueous Fe(II) ion, so the exact notation/source duplicate is collapsed in favor of the SRD-46 entry. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ and [Fe]2+ are the same aqueous Fe(II) ion, so the exact notation/source duplicate is collapsed in favor of the SRD-46 entry. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — This Fe(II) monohydroxo complex is a distinct hydrolysis species and is in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — This Fe(II) dihydroxo complex has a distinct protonation state and is in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — The Atlas [HFeO2]- entry is a duplicate dehydrated notation for the same aqueous Fe(II) hydrolysis species as SRD-46 [Fe(OH)3]-, so the SRD-46 entry is retained. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — The Atlas [HFeO2]- entry is a duplicate dehydrated notation for the same aqueous Fe(II) hydrolysis species as SRD-46 [Fe(OH)3]-, so the SRD-46 entry is retained. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — This Fe(II) tetrahydroxo anion is a distinct hydrolysis species and is in scope. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — This Fe(II) citrate complex is distinct and citrate complexation is in scope. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — This polynuclear Fe(II) hydroxo-citrate complex is distinct and polynuclear ligand complexes are retained. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — This protonated Fe(II) citrate complex is distinct and protonated citrate complexes are in scope. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — This doubly protonated Fe(II) citrate complex is distinct and protonated ligand complexes are retained. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — This Fe(II) bis-citrate protonated complex has distinct ligand count and charge and is in scope. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — This Fe(II) glycine complex is distinct and glycine complexation is in scope. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — This Fe(II) bis-glycine complex has a distinct ligand count and is in scope. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — This Fe(II) tris-glycine complex has a distinct ligand count and charge and is in scope. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — This Fe(II) monoammine complex is distinct and ammonia complexation is in scope. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — This Fe(II) diammine complex has a distinct ligand count and is in scope. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — This Fe(II) triammine complex has a distinct ligand count and is in scope. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — This Fe(II) tetraammine complex has a distinct ligand count and is in scope. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — This Fe(II) chloride complex is distinct and chloride complexation is in scope. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and aligned chemical potential, so the SRD-46 entry is preferred. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ and [Fe]3+ are the same aqueous Fe(III) ion with identical charge and aligned chemical potential, so the SRD-46 entry is preferred. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — [FeOH]2+ and [Fe(OH)]2+ are the same mononuclear Fe(III) hydroxo aqueous complex so the SRD-46 notation is preferred, while [Fe2(OH)2]4+ is a distinct polynuclear species and is retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — [FeOH]2+ and [Fe(OH)]2+ are the same mononuclear Fe(III) hydroxo aqueous complex so the SRD-46 notation is preferred, while [Fe2(OH)2]4+ is a distinct polynuclear species and is retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — [FeOH]2+ and [Fe(OH)]2+ are the same mononuclear Fe(III) hydroxo aqueous complex so the SRD-46 notation is preferred, while [Fe2(OH)2]4+ is a distinct polynuclear species and is retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Both rows describe the same aqueous mononuclear Fe(III) dihydroxo complex with identical charge and physical meaning, so the SRD-46 entry is preferred over the Atlas duplicate. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Both rows describe the same aqueous mononuclear Fe(III) dihydroxo complex with identical charge and physical meaning, so the SRD-46 entry is preferred over the Atlas duplicate. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — This Fe(III) tetrahydroxo species is distinct from Fe(II) hydrolysis species and is in scope. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — This Fe(III) citrate complex is distinct from Fe(II) citrate and is in scope. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Kept both because the mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct aqueous species and polynuclear complexes are in scope at the stated mM conditions. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Kept both because the mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct aqueous species and polynuclear complexes are in scope at the stated mM conditions. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — This protonated Fe(III) citrate complex is distinct and protonated ligand complexes are retained. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — This Fe(III) glycine complex is distinct and glycine complexation is in scope. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — This protonated Fe(III) glycine complex is distinct and in scope. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — This protonated Fe(III) bis-glycine complex has distinct ligand count and protonation and is in scope. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — This Fe(III) monochloride complex is distinct and chloride complexation is in scope. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — This Fe(III) dichloride complex has distinct ligand count and charge and is in scope. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — This trinuclear Fe(III) hydroxo complex is distinct and polynuclear hydrolysis species are retained. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — This high-valent ferrate aqueous redox state is chemically distinct and explicitly retained. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental iron is a distinct solid redox endpoint and is explicitly retained. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite is a distinct mixed-valence iron oxide solid and is explicitly retained. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Both rows describe the same neutral hydrated ferrous hydroxide solid phase, so the SRD-46 entry is kept preferentially over the Atlas duplicate. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Both rows describe the same neutral hydrated ferrous hydroxide solid phase, so the SRD-46 entry is kept preferentially over the Atlas duplicate. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Retained distinct SRD-46 ferric oxide, alpha oxyhydroxide, and ferric hydroxide phases while dropping Atlas generic oxide/hydrated hydroxide duplicates in favor of SRD-46. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia is a specified ligand at 0.1 M and is in scope. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion is a specified high-concentration ligand and is in scope. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — The citrate base ligand species is part of the specified shared citrate pool and is in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — The glycine base ligand species is part of the specified shared glycine pool and is in scope. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — This further protonated citrate species is part of the citrate acid-base network and is in scope. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine is part of the glycine acid-base network and is in scope. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent/reference aqueous species and is in scope for the specified 25 C electrolyte calculation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Neutral citric acid is part of the specified citrate acid-base pool and is in scope. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is part of the ammonia acid-base pool and is in scope. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — This protonated citrate species is part of the citrate acid-base network and is in scope. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is part of the glycine acid-base network and is in scope. |

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M2 | [Cu]+ | Cu | 1 |
| Cu$+2 | M1 | [Cu]2+ | Cu | 2 |
| Fe$+2 | M4 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M3 | [Fe]3+ | Fe | 3 |
| Cu$+0 | Cu$+0 | Cu(s) | Cu | 0 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 96 | **Core groups**: 76 | **Multi-member groups**: 14 | **Cross-source groups**: 11

## 1. Aqueous / Dissolved Species

67 core groups, 78 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [H2O] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cu$+1:1 L2:2` | [Cu(Glyc)2]- | SRD-46 | -1 | 1x | +51.597 | 0 | — | *** |
| 5 | `Cu$+1:1 L3:2` | [Cu(Ammo)2]+ | SRD-46 | +1 | 1x | -56.620 | 0 | — | *** |
| 6 | `Cu$+1:1 L4:1` | [Cu(Chlo)] | SRD-46 | +0 | 1x | -17.694 | 0 | — | *** |
| 7 | `Cu$+1:1 L4:2` | [Cu2(Chlo)4]2- | SRD-46 | -2 | 2x | -74.200 | 0 | — | *** |
| 8 | `Cu$+1:1 L4:2` | [Cu(Chlo)2]- | SRD-46 | -1 | 1x | -30.936 | 0 | — | *** |
| 9 | `Cu$+1:1 L4:3` | [Cu(Chlo)3]2- | SRD-46 | -2 | 1x | -27.111 | 0 | — | *** |
| 10 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 11 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 12 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 13 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 14 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 15 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 16 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 17 | `Cu$+2:1 L1:1` | [Cu2(Citr)2]2- | SRD-46 | -2 | 2x | +94.036 | -2 | — | *** |
| 18 | `Cu$+2:1 L1:1 H:-1` | [Cu2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | +140.611 | -2 | — | *** |
| 19 | `Cu$+2:1 L1:1 H:1` | [Cu(Citr)H] | SRD-46 | +0 | 1x | +35.545 | -1 | — | *** |
| 20 | `Cu$+2:1 L2:1` | [Cu(Glyc)]+ | SRD-46 | +1 | 1x | +22.646 | -1 | — | *** |
| 21 | `Cu$+2:1 L2:2` | [Cu(Glyc)2] | SRD-46 | +0 | 1x | +37.829 | -1 | — | *** |
| 22 | `Cu$+2:1 L3:1` | [Cu(Ammo)]2+ | SRD-46 | +2 | 1x | -8.632 | -1 | — | *** |
| 23 | `Cu$+2:1 L3:2` | [Cu(Ammo)2]2+ | SRD-46 | +2 | 1x | -27.467 | -1 | — | *** |
| 24 | `Cu$+2:1 L3:3` | [Cu(Ammo)3]2+ | SRD-46 | +2 | 1x | -43.449 | -1 | — | *** |
| 25 | `Cu$+2:1 L3:4` | [Cu(Ammo)4]2+ | SRD-46 | +2 | 1x | -55.435 | -1 | — | *** |
| 26 | `Cu$+2:1 L4:1` | [Cu(Chlo)]+ | SRD-46 | +1 | 1x | +15.911 | -1 | — | *** |
| 27 | `Cu$+2:2 L1:1 H:-1` | [Cu2(Citr)(OH)] | SRD-46 | +0 | 1x | +75.429 | -2 | — | *** |
| 28 | `Cu$+2:2 L1:2 H:-1` | [Cu2(Citr)2(OH)]3- | SRD-46 | -3 | 1x | +112.871 | -2 | — | *** |
| 29 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 30 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 31 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 32 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 33 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 34 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 35 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 36 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 37 | `Fe$+2:1 L1:1` | [Fe(Citr)]- | SRD-46 | -1 | 1x | +47.602 | 0 | — | *** |
| 38 | `Fe$+2:1 L1:1 H:-1` | [Fe2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | +178.080 | 0 | — | *** |
| 39 | `Fe$+2:1 L1:1 H:1` | [Fe(Citr)H] | SRD-46 | +0 | 1x | +24.828 | 0 | — | *** |
| 40 | `Fe$+2:1 L1:1 H:2` | [Fe(Citr)H2]+ | SRD-46 | +1 | 1x | +10.274 | 0 | — | *** |
| 41 | `Fe$+2:1 L1:2 H:1` | [Fe(Citr)2H]3- | SRD-46 | -3 | 1x | +80.250 | 0 | — | *** |
| 42 | `Fe$+2:1 L2:1` | [Fe(Glyc)]+ | SRD-46 | +1 | 1x | +31.050 | 0 | — | *** |
| 43 | `Fe$+2:1 L2:2` | [Fe(Glyc)2] | SRD-46 | +0 | 1x | +65.581 | 0 | — | *** |
| 44 | `Fe$+2:1 L2:3` | [Fe(Glyc)3]- | SRD-46 | -1 | 1x | +113.241 | 0 | — | *** |
| 45 | `Fe$+2:1 L3:1` | [Fe(Ammo)]2+ | SRD-46 | +2 | 1x | -7.991 | 0 | — | *** |
| 46 | `Fe$+2:1 L3:2` | [Fe(Ammo)2]2+ | SRD-46 | +2 | 1x | -12.842 | 0 | — | *** |
| 47 | `Fe$+2:1 L3:3` | [Fe(Ammo)3]2+ | SRD-46 | +2 | 1x | -15.297 | 0 | — | *** |
| 48 | `Fe$+2:1 L3:4` | [Fe(Ammo)4]2+ | SRD-46 | +2 | 1x | -15.696 | 0 | — | *** |
| 49 | `Fe$+2:1 L4:1` | [Fe(Chlo)]+ | SRD-46 | +1 | 1x | +1.141 | 0 | — | *** |
| 50 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 51 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 52 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 53 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 54 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 55 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | ref | *** |
| 56 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +14.371 | — |
| 57 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 58 | `Fe$+3:1 L1:1` | [Fe(Citr)] | SRD-46 | +0 | 1x | +84.110 | -1 | — | *** |
| 59 | `Fe$+3:1 L1:1 H:-1` | [Fe(Citr)(OH)]- | SRD-46 | -1 | 1x | +99.521 | -1 | — | *** |
| 60 | `Fe$+3:1 L1:1 H:-1` | [Fe2(Citr)2(OH)2]2- | SRD-46 | -2 | 2x | +174.955 | -2 | — | *** |
| 61 | `Fe$+3:1 L1:1 H:1` | [Fe(Citr)H]+ | SRD-46 | +1 | 1x | +77.489 | -1 | — | *** |
| 62 | `Fe$+3:1 L2:1` | [Fe(Glyc)]2+ | SRD-46 | +2 | 1x | +80.057 | -1 | — | *** |
| 63 | `Fe$+3:1 L2:1 H:1` | [Fe(Glyc)H]3+ | SRD-46 | +3 | 1x | +64.247 | -1 | — | *** |
| 64 | `Fe$+3:1 L2:2 H:2` | [Fe(Glyc)2H2]3+ | SRD-46 | +3 | 1x | +53.231 | -1 | — | *** |
| 65 | `Fe$+3:1 L4:1` | [Fe(Chlo)]2+ | SRD-46 | +2 | 1x | +69.898 | -1 | — | *** |
| 66 | `Fe$+3:1 L4:2` | [Fe(Chlo)2]+ | SRD-46 | +1 | 1x | +62.192 | -1 | — | *** |
| 67 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 68 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 69 | `L1:1` | [Citric acid] | SRD-46 | -3 | 1x | +73.629 | 0 | — | *** |
| 70 | `L1:1 H:1` | [HCitric acid]2- | SRD-46 | -2 | 1x | +41.381 | 0 | — | *** |
| 71 | `L1:1 H:2` | [H2Citric acid]- | SRD-46 | -1 | 1x | +16.552 | 0 | — | *** |
| 72 | `L1:1 H:3` | [H3Citric acid] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 73 | `L2:1` | [Glycine] | SRD-46 | -1 | 1x | +54.623 | 0 | — | *** |
| 74 | `L2:1 H:1` | [HGlycine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 75 | `L2:1 H:2` | [H2Glycine]+ | SRD-46 | +1 | 1x | -13.299 | 0 | — | *** |
| 76 | `L3:1` | [Ammonia] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 77 | `L3:1 H:1` | [HAmmonia]+ | SRD-46 | +1 | 1x | -52.853 | 0 | — | *** |
| 78 | `L4:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+1:1 L4:2` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu2(Chlo)4]2- | SRD-46 | -2 | 2x | -74.200 | 0 | id=[Cu$+1]2.[L4]4.[z-2]; mu_canon=-74.2000; *** |
| 2 | [Cu(Chlo)2]- | SRD-46 | -1 | 1x | -30.936 | 0 | id=[Cu$+1].[L4]2.[z-1]; mu_canon=-30.9357; *** |

#### 1.3  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.4  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

#### 1.5  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.6  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.7  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.8  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.9  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+26.2554; *** |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+) = 14.371 kJ/mol

#### 1.10  Core: `Fe$+3:1 L1:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(Citr)(OH)]- | SRD-46 | -1 | 1x | +99.521 | -1 | id=[Fe$+3].[OH].[L1].[z-1]; mu_canon=+25.1709; *** |
| 2 | [Fe2(Citr)2(OH)2]2- | SRD-46 | -2 | 2x | +174.955 | -2 | id=[Fe$+3]2.[OH]2.[L1]2.[z-2]; mu_canon=+26.2554; *** |

## 2. Solid / Dissolution Species

9 core groups, 18 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 2 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 3 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 4 | `Cu$+1:1 L4:1` | [Cu(Chloride ion)](s) | SRD-46 | +0 | 1x | -38.413 | 0 | — | *** |
| 5 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 6 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 7 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 8 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |
| 9 | `Cu$+2:2 L4:1 H:-3` | [Cu((OH))1.5(Chloride ion)0.5](s) | SRD-46 | +0 | 0.5x | +35.888 | -1 | — | *** |
| 10 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 11 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 12 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 13 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 14 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 15 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 16 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 17 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 18 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.2  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

#### 2.3  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.4  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

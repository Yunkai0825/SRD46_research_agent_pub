# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_10_20261105\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 28.77
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task fixes ionic strength at 0.1 molal; numeric value committed on solver ionic-strength handle
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task states total 1 mM Cu(II); Pourbaix redox-axis model uses element total
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # Task states total 1 mM Fe(III); Pourbaix redox-axis model uses element total
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # 10 mM citrate from task
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # 10 mM glycine from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M ammonia from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix diagram pH coordinate over the task-specified range'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix diagram redox-potential coordinate over the task-specified SHE range'},
]

```

## Notes
Task fixes 25 C, ionic strength 0.1, Cu/Fe analytical inventories, and citrate/glycine/chloride/ammonia totals in one mixed solution. For a Pourbaix sweep, pH and E_V are axes and are deferred; Cu and Fe are supplied as element totals so redox partitioning can vary over the E-pH field.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task fixes ionic strength at 0.1 molal; numeric value committed on solver ionic-strength handle"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "Task states total 1 mM Cu(II); Pourbaix redox-axis model uses element total"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "Task states total 1 mM Fe(III); Pourbaix redox-axis model uses element total"},
  {"id": "citrate", "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2, "basis": "known", "note": "10 mM citrate from task"},
  {"id": "glycine", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM glycine from task"},
  {"id": "ammonia", "lhs": lambda s: s.total["ligand_10103"], "value": 1e-1, "basis": "known", "note": "0.1 M ammonia from task"},
  {"id": "chloride", "lhs": lambda s: s.total["ligand_10163"], "value": 1e-1, "basis": "known", "note": "0.1 M chloride from task"},
]
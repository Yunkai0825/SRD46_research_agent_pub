# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.011111111, ΔE_V=0.0011111111V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [Fe2(Citr)2(OH)2]4-
- Dms_5: [Fe(Citr)]-
- Dms_6: [(Fe2O3)0.5(s,alpha)]
- Dms_7: Fe2+
- Dms_8: FeO42-
- Dms_9: Fe3+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 1125)
- samples 0–366, (pH=[0, 4.0666667], E_V=0.25V): Fe2+ (Dms_7)
- samples 367–379, (pH=[4.0777778, 4.2111111], E_V=0.25V): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[4.0666667, 4.0777778], E_V=0.25V)
- samples 380–1260, (pH=[4.2222222, 14], E_V=0.25V): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4.2111111, 4.2222222], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 630, E_V=swept)
- samples 0–381, (pH=7, E_V=[-1V, -0.57666667V]): Fe (Dms_1)
- samples 382–698, (pH=7, E_V=[-0.57555556V, -0.22444444V]): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.57666667V, -0.57555556V])
- samples 699–752, (pH=7, E_V=[-0.22333333V, -0.16444444V]): Fe3O4 (anh.) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.22444444V, -0.22333333V])
- samples 753–1796, (pH=7, E_V=[-0.16333333V, 0.99555556V]): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.16444444V, -0.16333333V])
- samples 1797–2250, (pH=7, E_V=[0.99666667V, 1.5V]): FeO42- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.99555556V, 0.99666667V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 5.1864198
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_15
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_7 {Fe2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_8]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 2.0122099
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_15
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_12
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_14
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 13.019704
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_16
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_9
    --- DmsReg_8 {FeO42-} via DmsRegEq_10
    --- DmsReg_9 {Fe3+} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_16, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.028617284
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_9]
- **DmsReg_5 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.091271605
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_4]
- **DmsReg_6 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.0565185
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_14
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_5]
- **DmsReg_7 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.5656173
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_9 {Fe3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_8 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.2443333
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_9 {Fe3+}**
  -- Measure in the solver coordinate frame: 0.83865432
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_11
    --- DmsReg_7 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.77056V), (pH=1.22778, E_V=0.77056V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 112, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 111], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.77056V), (pH=1.22778, E_V=0.77056V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.77056V), (pH=1.22778, E_V=0.77056V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_2: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.06111, E_V=-0.585V), (pH=7.92778, E_V=-0.57611V), (pH=7.92778, E_V=-0.44389V), (pH=8.09444, E_V=-0.45167V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 162, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 20, 139, 161], "t_params": [0.0, 0.30883, 0.6144, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.06111, E_V=-0.585V), (pH=7.92778, E_V=-0.57611V), (pH=7.92778, E_V=-0.44389V), (pH=8.09444, E_V=-0.45167V)], "envelope_t": [0.0, 0.30883, 0.6144, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=8.06111, E_V=-0.585V), (pH=7.92778, E_V=-0.57611V), (pH=7.92778, E_V=-0.44389V), (pH=8.09444, E_V=-0.45167V)], "adaptive_t": [0.0, 0.30883, 0.6144, 1.0]}
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.02778, E_V=-0.55167V), (pH=4.05, E_V=-0.54389V), (pH=4.06111, E_V=0.27167V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 747, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 9, 746], "t_params": [0.0, 0.02806, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.02778, E_V=-0.55167V), (pH=4.05, E_V=-0.54389V), (pH=4.06111, E_V=0.27167V)], "envelope_t": [0.0, 0.02806, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.02778, E_V=-0.55167V), (pH=4.05, E_V=-0.54389V), (pH=4.06111, E_V=0.27167V)], "adaptive_t": [0.0, 0.02806, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.92278V), (pH=13.31667, E_V=-0.86167V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 118, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 117], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.92278V), (pH=13.31667, E_V=-0.86167V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.92278V), (pH=13.31667, E_V=-0.86167V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.17222, E_V=-0.61611V), (pH=8.06111, E_V=-0.585V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 129, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 128], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.17222, E_V=-0.61611V), (pH=8.06111, E_V=-0.585V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.17222, E_V=-0.61611V), (pH=8.06111, E_V=-0.585V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.06111, E_V=-0.585V), (pH=7.30556, E_V=-0.57611V), (pH=5.09444, E_V=-0.57278V), (pH=4.68333, E_V=-0.56722V), (pH=4.02778, E_V=-0.55167V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 394, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 76, 278, 320, 393], "t_params": [0.0, 0.18733, 0.7355, 0.83743, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.06111, E_V=-0.585V), (pH=7.30556, E_V=-0.57611V), (pH=5.09444, E_V=-0.57278V), (pH=4.68333, E_V=-0.56722V), (pH=4.02778, E_V=-0.55167V)], "envelope_t": [0.0, 0.18733, 0.7355, 0.83743, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.06111, E_V=-0.585V), (pH=7.30556, E_V=-0.57611V), (pH=5.09444, E_V=-0.57278V), (pH=4.68333, E_V=-0.56722V), (pH=4.02778, E_V=-0.55167V)], "adaptive_t": [0.0, 0.18733, 0.7355, 0.83743, 1.0]}
- **DmsRegEq_7: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.02778, E_V=-0.55167V), (pH=3.53889, E_V=-0.54278V), (pH=3.10556, E_V=-0.53944V), (pH=0, E_V=-0.53833V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 376, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 52, 94, 375], "t_params": [0.0, 0.1214, 0.22898, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.02778, E_V=-0.55167V), (pH=3.53889, E_V=-0.54278V), (pH=3.10556, E_V=-0.53944V), (pH=0, E_V=-0.53833V)], "envelope_t": [0.0, 0.1214, 0.22898, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=4.02778, E_V=-0.55167V), (pH=3.53889, E_V=-0.54278V), (pH=3.10556, E_V=-0.53944V), (pH=0, E_V=-0.53833V)], "adaptive_t": [0.0, 0.1214, 0.22898, 1.0]}
- **DmsRegEq_8: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.66111, E_V=-0.14389V), (pH=5.27222, E_V=0.09944V), (pH=4.61667, E_V=0.19722V), (pH=4.06111, E_V=0.27167V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 609, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 344, 491, 608], "t_params": [0.0, 0.53545, 0.78715, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.66111, E_V=-0.14389V), (pH=5.27222, E_V=0.09944V), (pH=4.61667, E_V=0.19722V), (pH=4.06111, E_V=0.27167V)], "envelope_t": [0.0, 0.53545, 0.78715, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=6.66111, E_V=-0.14389V), (pH=5.27222, E_V=0.09944V), (pH=4.61667, E_V=0.19722V), (pH=4.06111, E_V=0.27167V)], "adaptive_t": [0.0, 0.53545, 0.78715, 1.0]}
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.06111, E_V=0.27167V), (pH=3.48333, E_V=0.35833V), (pH=1.93889, E_V=0.62056V), (pH=1.37222, E_V=0.72722V), (pH=1.22778, E_V=0.77056V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 705, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 130, 505, 652, 704], "t_params": [0.0, 0.20299, 0.74727, 0.9476, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.06111, E_V=0.27167V), (pH=3.48333, E_V=0.35833V), (pH=1.93889, E_V=0.62056V), (pH=1.37222, E_V=0.72722V), (pH=1.22778, E_V=0.77056V)], "envelope_t": [0.0, 0.20299, 0.74727, 0.9476, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=4.06111, E_V=0.27167V), (pH=3.48333, E_V=0.35833V), (pH=1.93889, E_V=0.62056V), (pH=1.37222, E_V=0.72722V), (pH=1.22778, E_V=0.77056V)], "adaptive_t": [0.0, 0.20299, 0.74727, 0.9476, 1.0]}
- **DmsRegEq_10: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.30611V), (pH=4.86111, E_V=1.20833V), (pH=3.31667, E_V=1.35611V), (pH=1.88333, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 2167, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1635, 1907, 2166], "t_params": [0.0, 0.75425, 0.88168, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.30611V), (pH=4.86111, E_V=1.20833V), (pH=3.31667, E_V=1.35611V), (pH=1.88333, E_V=1.5V)], "envelope_t": [0.0, 0.75425, 0.88168, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=14, E_V=0.30611V), (pH=4.86111, E_V=1.20833V), (pH=3.31667, E_V=1.35611V), (pH=1.88333, E_V=1.5V)], "adaptive_t": [0.0, 0.75425, 0.88168, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_11: [(Fe2O3)0.5(s,alpha)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.22778, E_V=0.77056V), (pH=1.16111, E_V=0.80944V), (pH=1.13889, E_V=0.89722V), (pH=1.13889, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 666, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 41, 122, 665], "t_params": [0.0, 0.10017, 0.21768, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.22778, E_V=0.77056V), (pH=1.16111, E_V=0.80944V), (pH=1.13889, E_V=0.89722V), (pH=1.13889, E_V=1.5V)], "envelope_t": [0.0, 0.10017, 0.21768, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=1.22778, E_V=0.77056V), (pH=1.16111, E_V=0.80944V), (pH=1.13889, E_V=0.89722V), (pH=1.13889, E_V=1.5V)], "adaptive_t": [0.0, 0.10017, 0.21768, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_12: [Fe(OH)3]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.31667, E_V=-0.86167V), (pH=14, E_V=-0.84056V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 82, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 81], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.31667, E_V=-0.86167V), (pH=14, E_V=-0.84056V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.31667, E_V=-0.86167V), (pH=14, E_V=-0.84056V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.17222, E_V=-0.61611V), (pH=8.43889, E_V=-0.50944V), (pH=8.09444, E_V=-0.45167V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 246, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 162, 245], "t_params": [0.0, 0.67967, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.17222, E_V=-0.61611V), (pH=8.43889, E_V=-0.50944V), (pH=8.09444, E_V=-0.45167V)], "envelope_t": [0.0, 0.67967, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=9.17222, E_V=-0.61611V), (pH=8.43889, E_V=-0.50944V), (pH=8.09444, E_V=-0.45167V)], "adaptive_t": [0.0, 0.67967, 1.0]}
- **DmsRegEq_14: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.09444, E_V=-0.45167V), (pH=7.85, E_V=-0.40944V), (pH=7.50556, E_V=-0.33944V), (pH=6.66111, E_V=-0.14389V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 2, "raw_n": 407, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 60, 154, 406], "t_params": [0.0, 0.16917, 0.40887, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.09444, E_V=-0.45167V), (pH=7.85, E_V=-0.40944V), (pH=7.50556, E_V=-0.33944V), (pH=6.66111, E_V=-0.14389V)], "envelope_t": [0.0, 0.16917, 0.40887, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=8.09444, E_V=-0.45167V), (pH=7.85, E_V=-0.40944V), (pH=7.50556, E_V=-0.33944V), (pH=6.66111, E_V=-0.14389V)], "adaptive_t": [0.0, 0.16917, 0.40887, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_15: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.31667, E_V=-0.86167V), (pH=9.17222, E_V=-0.61611V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 595, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 594], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.31667, E_V=-0.86167V), (pH=9.17222, E_V=-0.61611V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.31667, E_V=-0.86167V), (pH=9.17222, E_V=-0.61611V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.57833V), (pH=6.66111, E_V=-0.14389V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 1053, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1052], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.57833V), (pH=6.66111, E_V=-0.14389V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.57833V), (pH=6.66111, E_V=-0.14389V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.77056V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.06111, E_V=-0.585V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.02778, E_V=-0.55167V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.09444, E_V=-0.45167V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.06111, E_V=0.27167V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.22778, E_V=0.77056V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.92278V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.53833V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.84056V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.30611V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.88333, E_V=1.5V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.13889, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_12, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.31667, E_V=-0.86167V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.17222, E_V=-0.61611V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.66111, E_V=-0.14389V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.57833V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.011111111, ΔE_V=0.0011111111V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu(Glyc)2]
- Dms_6: [Cu2(Citr)2(OH)2]4-
- Dms_7: [Cu(Chlo)2]-
- Dms_8: [Cu2(Citr)2(OH)]3-
- Dms_9: Cu2+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 1125)
- samples 0–349, (pH=[0, 3.8777778], E_V=0.25V): [Cu(Chlo)2]- (Dms_7)
- samples 350–360, (pH=[3.8888889, 4], E_V=0.25V): [Cu2(Citr)2(OH)]3- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=[3.8777778, 3.8888889], E_V=0.25V)
- samples 361–682, (pH=[4.0111111, 7.5777778], E_V=0.25V): [Cu2(Citr)2(OH)2]4- (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4, 4.0111111], E_V=0.25V)
- samples 683–971, (pH=[7.5888889, 10.788889], E_V=0.25V): [Cu(Glyc)2] (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[7.5777778, 7.5888889], E_V=0.25V)
- samples 972–1260, (pH=[10.8, 14], E_V=0.25V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[10.788889, 10.8], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 630, E_V=swept)
- samples 0–946, (pH=7, E_V=[-1V, 0.051111111V]): Cu (Dms_1)
- samples 947–2250, (pH=7, E_V=[0.052222222V, 1.5V]): [Cu2(Citr)2(OH)2]4- (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.051111111V, 0.052222222V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 13.767247
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_15
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_8
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_9
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_10
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.61982716
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_15
    --- DmsReg_3 {CuO(s)} via DmsRegEq_16
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_7]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 5.0518025
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_16
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.27614815
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_13, DmsRegEqJnc_7]
- **DmsReg_5 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 4.7833333
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_3 {CuO(s)} via DmsRegEq_14
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_14, DmsRegEqJnc_12, DmsRegEqJnc_3]
- **DmsReg_6 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 4.9994198
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_10
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_5
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_4]
- **DmsReg_7 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 0.854
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_11
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_8 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.97004938
  -- Neighboring regions:
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_6
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_6]
- **DmsReg_9 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.7215185
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_6]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Ammo)2]+ | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.80556, E_V=0.005V), (pH=8.75, E_V=0.01722V), (pH=7.76111, E_V=0.01611V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 289, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 196, 288], "t_params": [0.0, 0.67519, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.80556, E_V=0.005V), (pH=8.75, E_V=0.01722V), (pH=7.76111, E_V=0.01611V)], "envelope_t": [0.0, 0.67519, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.80556, E_V=0.005V), (pH=8.75, E_V=0.01722V), (pH=7.76111, E_V=0.01611V)], "adaptive_t": [0.0, 0.67519, 1.0]}
- **DmsRegEq_2: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.09444, E_V=0.115V), (pH=4.87222, E_V=0.12944V), (pH=4.59444, E_V=0.15833V), (pH=4.20556, E_V=0.20722V), (pH=4.00556, E_V=0.23833V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 210, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 33, 84, 163, 209], "t_params": [0.0, 0.20313, 0.45786, 0.81538, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.09444, E_V=0.115V), (pH=4.87222, E_V=0.12944V), (pH=4.59444, E_V=0.15833V), (pH=4.20556, E_V=0.20722V), (pH=4.00556, E_V=0.23833V)], "envelope_t": [0.0, 0.20313, 0.45786, 0.81538, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=5.09444, E_V=0.115V), (pH=4.87222, E_V=0.12944V), (pH=4.59444, E_V=0.15833V), (pH=4.20556, E_V=0.20722V), (pH=4.00556, E_V=0.23833V)], "adaptive_t": [0.0, 0.20313, 0.45786, 0.81538, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.00556, E_V=0.23833V), (pH=3.80556, E_V=0.25833V), (pH=3.52778, E_V=0.29389V), (pH=3.22778, E_V=0.34278V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 165, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 36, 93, 164], "t_params": [0.0, 0.25605, 0.61279, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.00556, E_V=0.23833V), (pH=3.80556, E_V=0.25833V), (pH=3.52778, E_V=0.29389V), (pH=3.22778, E_V=0.34278V)], "envelope_t": [0.0, 0.25605, 0.61279, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=4.00556, E_V=0.23833V), (pH=3.80556, E_V=0.25833V), (pH=3.52778, E_V=0.29389V), (pH=3.22778, E_V=0.34278V)], "adaptive_t": [0.0, 0.25605, 0.61279, 1.0]}
- **DmsRegEq_4: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.34167V), (pH=3.22778, E_V=0.34278V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 293, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 292], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.34167V), (pH=3.22778, E_V=0.34278V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.34167V), (pH=3.22778, E_V=0.34278V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [Cu(Glyc)2] | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.33889, E_V=0.03944V), (pH=7.45, E_V=0.03833V), (pH=7.52778, E_V=0.04278V), (pH=7.57222, E_V=0.085V), (pH=7.58333, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1340, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 11, 22, 64, 1339], "t_params": [0.0, 0.06672, 0.1135, 0.15031, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.33889, E_V=0.03944V), (pH=7.45, E_V=0.03833V), (pH=7.52778, E_V=0.04278V), (pH=7.57222, E_V=0.085V), (pH=7.58333, E_V=1.5V)], "envelope_t": [0.0, 0.06672, 0.1135, 0.15031, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=7.33889, E_V=0.03944V), (pH=7.45, E_V=0.03833V), (pH=7.52778, E_V=0.04278V), (pH=7.57222, E_V=0.085V), (pH=7.58333, E_V=1.5V)], "adaptive_t": [0.0, 0.06672, 0.1135, 0.15031, 1.0]}
- **DmsRegEq_6: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.00556, E_V=0.23833V), (pH=4.00556, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1137, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1136], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.00556, E_V=0.23833V), (pH=4.00556, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.00556, E_V=0.23833V), (pH=4.00556, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.22778, E_V=0.34278V), (pH=3.20556, E_V=0.40056V), (pH=3.20556, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1045, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 54, 1044], "t_params": [0.0, 0.0533, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.22778, E_V=0.34278V), (pH=3.20556, E_V=0.40056V), (pH=3.20556, E_V=1.5V)], "envelope_t": [0.0, 0.0533, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.22778, E_V=0.34278V), (pH=3.20556, E_V=0.40056V), (pH=3.20556, E_V=1.5V)], "adaptive_t": [0.0, 0.0533, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_8: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.46111, E_V=-0.14056V), (pH=9.82778, E_V=-0.13167V), (pH=9.29444, E_V=-0.11056V), (pH=8.85, E_V=-0.07944V), (pH=8.18333, E_V=-0.01722V), (pH=7.76111, E_V=0.01611V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "budget", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 385, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 65, 132, 200, 316, 384], "t_params": [0.0, 0.23409, 0.43135, 0.59601, 0.84347, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.46111, E_V=-0.14056V), (pH=9.82778, E_V=-0.13167V), (pH=9.29444, E_V=-0.11056V), (pH=8.85, E_V=-0.07944V), (pH=8.18333, E_V=-0.01722V), (pH=7.76111, E_V=0.01611V)], "envelope_t": [0.0, 0.23409, 0.43135, 0.59601, 0.84347, 1.0], "adaptive_n": 6, "adaptive_pts": [(pH=10.46111, E_V=-0.14056V), (pH=9.82778, E_V=-0.13167V), (pH=9.29444, E_V=-0.11056V), (pH=8.85, E_V=-0.07944V), (pH=8.18333, E_V=-0.01722V), (pH=7.76111, E_V=0.01611V)], "adaptive_t": [0.0, 0.23409, 0.43135, 0.59601, 0.84347, 1.0]}
- **DmsRegEq_9: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.76111, E_V=0.01611V), (pH=7.33889, E_V=0.03944V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 60, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 59], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.76111, E_V=0.01611V), (pH=7.33889, E_V=0.03944V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.76111, E_V=0.01611V), (pH=7.33889, E_V=0.03944V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.33889, E_V=0.03944V), (pH=5.09444, E_V=0.115V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 271, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 270], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.33889, E_V=0.03944V), (pH=5.09444, E_V=0.115V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.33889, E_V=0.03944V), (pH=5.09444, E_V=0.115V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.09444, E_V=0.115V), (pH=4.82778, E_V=0.12389V), (pH=4.47222, E_V=0.12944V), (pH=0, E_V=0.12944V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 473, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 32, 69, 472], "t_params": [0.0, 0.05237, 0.12217, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.09444, E_V=0.115V), (pH=4.82778, E_V=0.12389V), (pH=4.47222, E_V=0.12944V), (pH=0, E_V=0.12944V)], "envelope_t": [0.0, 0.05237, 0.12217, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=5.09444, E_V=0.115V), (pH=4.82778, E_V=0.12389V), (pH=4.47222, E_V=0.12944V), (pH=0, E_V=0.12944V)], "adaptive_t": [0.0, 0.05237, 0.12217, 1.0]}
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.80556, E_V=0.005V), (pH=10.91667, E_V=0.01389V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 19, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 18], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.80556, E_V=0.005V), (pH=10.91667, E_V=0.01389V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.80556, E_V=0.005V), (pH=10.91667, E_V=0.01389V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.46111, E_V=-0.14056V), (pH=10.47222, E_V=-0.08833V), (pH=10.51667, E_V=-0.04944V), (pH=10.62778, E_V=-0.01833V), (pH=10.80556, E_V=0.005V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 163, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 48, 87, 125, 162], "t_params": [0.0, 0.13114, 0.27619, 0.5596, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.46111, E_V=-0.14056V), (pH=10.47222, E_V=-0.08833V), (pH=10.51667, E_V=-0.04944V), (pH=10.62778, E_V=-0.01833V), (pH=10.80556, E_V=0.005V)], "envelope_t": [0.0, 0.13114, 0.27619, 0.5596, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=10.46111, E_V=-0.14056V), (pH=10.47222, E_V=-0.08833V), (pH=10.51667, E_V=-0.04944V), (pH=10.62778, E_V=-0.01833V), (pH=10.80556, E_V=0.005V)], "adaptive_t": [0.0, 0.13114, 0.27619, 0.5596, 1.0]}
- **DmsRegEq_14: CuO(s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.91667, E_V=0.01389V), (pH=10.85, E_V=0.03722V), (pH=10.81667, E_V=0.06278V), (pH=10.79444, E_V=0.14278V), (pH=10.79444, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1350, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 27, 53, 127, 1349], "t_params": [0.0, 0.04548, 0.07253, 0.126, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.91667, E_V=0.01389V), (pH=10.85, E_V=0.03722V), (pH=10.81667, E_V=0.06278V), (pH=10.79444, E_V=0.14278V), (pH=10.79444, E_V=1.5V)], "envelope_t": [0.0, 0.04548, 0.07253, 0.126, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=10.91667, E_V=0.01389V), (pH=10.85, E_V=0.03722V), (pH=10.81667, E_V=0.06278V), (pH=10.79444, E_V=0.14278V), (pH=10.79444, E_V=1.5V)], "adaptive_t": [0.0, 0.04548, 0.07253, 0.126, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.34944V), (pH=10.46111, E_V=-0.14056V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 508, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 507], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.34944V), (pH=10.46111, E_V=-0.14056V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.34944V), (pH=10.46111, E_V=-0.14056V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.16833V), (pH=10.91667, E_V=0.01389V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00092, "resolution_tau_norm": 0.00092, "stop_epsilon": 0.00092, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 443, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 442], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.16833V), (pH=10.91667, E_V=0.01389V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.16833V), (pH=10.91667, E_V=0.01389V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.00556, E_V=0.23833V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.22778, E_V=0.34278V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Glyc)2], [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.58333, E_V=1.5V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.00556, E_V=1.5V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.34167V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.20556, E_V=1.5V)
#### one solid
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.80556, E_V=0.005V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.76111, E_V=0.01611V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Glyc)2], [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.33889, E_V=0.03944V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_10, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.09444, E_V=0.115V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.12944V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_14]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.79444, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.46111, E_V=-0.14056V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_12, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.91667, E_V=0.01389V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.34944V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.16833V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

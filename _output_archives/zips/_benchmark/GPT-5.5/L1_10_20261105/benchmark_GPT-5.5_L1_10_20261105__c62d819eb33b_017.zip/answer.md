## Answer

The joint Cu–Fe Pourbaix calculation was completed for the single shared solution: 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 °C and I = 0.1 m, over pH 0–14 and E = −1.0 to +1.5 V vs SHE.

Chemically, the calculation shows that **Cu remains strongly ligand-controlled over much of the aqueous pH range**, whereas **Fe becomes oxide-controlled much earlier**, especially near neutral and oxidizing conditions.

For **Cu**, the principal trend at E = 0.25 V is:

- Strongly acidic solution: Cu is stabilized as **Cu(I) chloride**, mainly `[Cu(Chlo)2]-`.
- Mildly acidic to neutral pH: Cu shifts into **hydroxo-citrate Cu(II) clusters**, especially `[Cu2(Citr)2(OH)]3-` and `[Cu2(Citr)2(OH)2]4-`.
- Neutral to basic pH: **glycine takes over**, with `[Cu(Glyc)2]` predominant.
- Strongly basic pH: Cu precipitates as **CuO(s)** under oxidizing conditions.

This means chloride controls Cu under acid/reducing-to-moderate conditions, citrate controls the mid-pH Cu(II) field, glycine wins in the near-neutral/basic aqueous field, and oxide precipitation dominates at high pH.

For **Fe**, the behavior is much more oxide-dominated:

- Acidic pH at E = 0.25 V: **Fe2+** predominates.
- A very narrow citrate-stabilized window appears near pH ≈ 4.1 as `[Fe(Citr)]-`.
- Above about pH 4.2 at this potential, Fe is mainly present as ferric oxide, reported as `[(Fe2O3)0.5(s,alpha)]`.
- At pH 7, increasing potential gives Fe metal → Fe citrate → Fe3O4 → ferric oxide → ferrate, `FeO4^2-`.

Thus, although citrate can bind Fe, it does not keep Fe broadly soluble across neutral oxidizing water in this mixed system. Fe hydrolysis and oxide formation dominate much more strongly than for Cu.

The main Cu junctions reported by the solver include:

- `[Cu2(Citr)2(OH)2]4- / [Cu(Chlo)2]- / [Cu2(Citr)2(OH)]3-` at **pH 4.00556, E = 0.23833 V**
- chloride / citrate / Cu²⁺ junction at **pH 3.22778, E = 0.34278 V**
- Cu metal / `[Cu(Glyc)2]` / citrate-cluster junction at **pH 7.33889, E = 0.03944 V**
- Cu metal / Cu-citrate / Cu-chloride junction at **pH 5.09444, E = 0.115 V**
- Cu metal / Cu2O / ammonia-associated alkaline junction at **pH 10.46111, E = −0.14056 V**

The main Fe junctions reported include:

- Fe metal / `[Fe(Citr)]-` / Fe²⁺ at **pH 4.02778, E = −0.55167 V**
- `[Fe(Citr)]-` / ferric oxide / Fe²⁺ at **pH 4.06111, E = 0.27167 V**
- ferric oxide / Fe²⁺ / Fe³⁺ at **pH 1.22778, E = 0.77056 V**
- Fe3O4 / `[Fe(Citr)]-` / ferric oxide at **pH 6.66111, E = −0.14389 V**
- Fe metal / Fe3O4 / `[Fe2(Citr)2(OH)2]4-` at **pH 9.17222, E = −0.61611 V**

Overall, **Cu partitions among chloride, citrate, glycine, and oxide fields**, while **Fe partitions mainly between aqueous Fe²⁺/citrate only in limited windows and solid oxide fields over much of the neutral-to-basic domain**. The shared ligand pool therefore affects Cu speciation much more visibly than Fe speciation under the computed conditions.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

- The solver computed a joint single-pot 2-D Pourbaix map for **Cu = 1 mM, Fe = 1 mM, citrate = 10 mM, glycine = 10 mM, chloride = 0.1 M, ammonia = 0.1 M**, over **pH 0–14** and **E = −1.0 to +1.5 V vs SHE**.
- Final classified-grid spacing was **ΔpH = 0.011111111** and **ΔE = 0.0011111111 V**.
- The full-speciation table contains **31,828 coarse-unrefined** and **250,328 refined samples** with convergence fields; inspected rows had `converged=1`, residuals near **10^-15**, and `phase_search_timed_out=0`.
- Cu topology: **9 connected Cu regions**, **16 boundary curves**, and **8 internal junctions**.
- Fe topology: **9 connected Fe regions**, **16 boundary curves**, and **8 internal junctions**.
- Cu pH cut at **E = 0.25 V**:
  - `[Cu(Chlo)2]-`: **pH 0–3.8778**
  - `[Cu2(Citr)2(OH)]3-`: **pH 3.8889–4.0000**
  - `[Cu2(Citr)2(OH)2]4-`: **pH 4.0111–7.5778**
  - `[Cu(Glyc)2]`: **pH 7.5889–10.7889**
  - `CuO(s)`: **pH 10.8–14**
- Cu redox cut at **pH = 7**:
  - Cu metal up to **E = 0.051111 V**
  - `[Cu2(Citr)2(OH)2]4-` from **E = 0.052222–1.5 V**
- Fe pH cut at **E = 0.25 V**:
  - Fe²⁺: **pH 0–4.0667**
  - `[Fe(Citr)]-`: **pH 4.0778–4.2111**
  - `[(Fe2O3)0.5(s,alpha)]`: **pH 4.2222–14**
- Fe redox cut at **pH = 7**:
  - Fe metal to **E = −0.576667 V**
  - `[Fe(Citr)]-` to **E = −0.224444 V**
  - Fe3O4 to **E = −0.164444 V**
  - ferric oxide to **E = 0.995556 V**
  - `FeO4^2-` from **E = 0.996667–1.5 V**
- Constants used by the solver included:
  - citrate protonation log β: **12.9000, 10.0000, 5.6500**
  - glycine protonation log β: **11.9000, 9.5700**
  - ammonium log β: **9.2600**
  - `[Cu(Chlo)2]-` log β: **5.4200**
  - `[Cu(Glyc)2]` log β: **15.1000**
  - `[Cu(Ammo)4]2+` log β: **12.3000**
  - `[Cu2(Citr)2(OH)2]4-` log β: **6.3400**
  - `[Fe(Citr)]-` log β: **4.5600**
  - `[Fe(Glyc)3]-` log β: **8.8700**
  - Fe(III) citrate `[Fe(Citr)]` log β: **11.1900**
  - Fe(III) hydroxo-citrate dimer log β: **21.2000**
  - CuO(s) log β: **−7.6500**
  - Fe3O4 log β: **−7.1252**

## Artifacts

- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
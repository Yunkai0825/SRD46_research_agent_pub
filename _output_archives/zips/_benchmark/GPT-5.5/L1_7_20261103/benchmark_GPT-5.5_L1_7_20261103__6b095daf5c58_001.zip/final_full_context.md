## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute a joint pH-sweep speciation model for one mixed solution containing Cu(II), Zn(II), glycine, and ammonia at 25 C and ionic strength 0.1 m. The goal is to quantify how Cu and Zn compete for the shared glycinate and ammine ligand pools, and to identify where soluble complexes are replaced by hydroxide solids.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 21,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 696.4
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute a joint pH-sweep speciation model for one mixed solution containing Cu(II), Zn(II), glycine, and ammonia at 25 C and ionic strength 0.1 m. The goal is to quantify how Cu and Zn compete for the shared glycinate and ammine ligand pools, and to identify where soluble complexes are replaced by hydroxide solids.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv"
    ]
  },
  {
    "call": 1,
    "purpose": "Compute a joint pH-sweep speciation model for one mixed solution containing Cu(II), Zn(II), glycine, and ammonia at 25 C and ionic strength 0.1 m. The goal is to quantify how Cu and Zn compete for the shared glycinate and ammine ligand pools, and to identify where soluble complexes are replaced by hydroxide solids.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For a single solution holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia together at 25 C and I=0.1 m, compute the joint pH 2-12 speciation and show how the two metals partition between glycinate and ammine complexes in the shared ligand pool. Prefer hydroxide solids. Report which metal dominates each ligand and the pH window where the glycinate and ammine complexes give way to the hydroxide solids.

## Assistant
<summary>I will run one joint equilibrium calculation for the single mixed Cu/Zn/glycine/ammonia solution, across pH 2–12 at 25 °C and ionic strength 0.1 m, allowing both metals to compete for the shared ligand pools and allowing/prefering hydroxide solids.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: the request has catalog-plausible metals and ligands, uses the supported `pH_sweep` route, and specifies reference-like conditions of 25.0 °C and target ionic strength 0.1 M. The calculation is a fixed-redox Cu(II)/Zn(II) speciation sweep, not a Pourbaix/redox calculation.

## Result
Computed one joint pH-sweep for 1.00e-03 M Cu(II), 1.00e-03 M Zn(II), 1.00e-02 M total glycine, and 1.00e-01 M total ammonia from pH 2.0 to 12.0 at 25.0 °C, fixed ionic-strength mode with target I = 0.1 M. The solver reports 401/401 pH points converged, so the quoted pH regions are based on converged samples. The calculated ionic-strength range was 0.00471442–0.0573917 M, so the thermodynamic source selection is I = 0.1 M but the solved charge balance did not maintain 0.1 M by added inert electrolyte.

## Analysis
Cu(II) and Zn(II) behave very differently in the shared ligand pool. Cu(II) binds glycine much more strongly than Zn(II): the included cumulative log beta values are +8.1900 for [Cu(Glyc)]+ and +15.1000 for [Cu(Glyc)2], compared with +4.9600, +9.1900, and +11.6000 for [Zn(Glyc)]+, [Zn(Glyc)2], and [Zn(Glyc)3]-. This stronger Cu–glycinate stability lets Cu capture glycine across most of the soluble pH range.

For Cu, the dominant metal form changes from free Cu2+ at pH 2.0–3.7, to [Cu(Glyc)]+ at pH 3.7–4.8, to [Cu(Glyc)2] at pH 4.8–11.3, and finally to [Cu(OH)2](s) at pH 11.3–12.0. Reported crossovers are Cu2+ ↔ [Cu(Glyc)]+ near pH 3.64, [Cu(Glyc)]+ ↔ [Cu(Glyc)2] near pH 4.73, and [Cu(Glyc)2] ↔ [Cu(OH)2](s) near pH 11.28, each from the pH grid. Chemically, glycine deprotonation opens strong Cu(II) chelation at moderately acidic pH; only at very alkaline pH does hydroxide activity overcome the bis-glycinate complex and drive precipitation.

Zn is less protected by glycine and precipitates much earlier. Zn2+ dominates pH 2.0–7.0, [Zn(Glyc)]+ dominates pH 7.0–7.5, [Zn(Glyc)2] only briefly around pH 7.5, and Zn(OH)2(alpha) dominates from pH 7.5 to 12.0. The verdict reports Zn2+ ↔ [Zn(Glyc)]+ near pH 6.96, [Zn(Glyc)]+ ↔ Zn(OH)2(alpha) near pH 7.51, and [Zn(Glyc)2] ↔ Zn(OH)2(alpha) near pH 7.52. The precipitation summary already shows Zn(OH)2(alpha) present by pH 7.33 at 2.24e-05 M, increasing to 9.98e-04 M by pH 11.08. Thus Zn hydroxide formation removes Zn from solution soon after glycine complexation begins to matter.

Ammonia does not dominate metal partitioning in this mixture. Its ligand pool is HAmmonia+ from pH 2.0–9.3 and free Ammonia from pH 9.3–12.0. Although Cu and Zn ammine constants are included, e.g. log beta +12.3000 for [Cu(Ammo)4]2+ and +8.8900 for [Zn(Ammo)4]2+, the metal speciation verdict shows no Cu ammine dominant region and only a minor Zn ammine peak: [Zn(Ammo)4]2+ reaches 12.4% at pH 9.2. Practically, glycine wins for Cu, while Zn is lost to Zn(OH)2(s) before ammine complexes can dominate.

For ligand competition, Cu dominates glycine binding over the important soluble window: [Cu(Glyc)2] accounts for up to 20.0% of total glycine at pH 8.2, while the largest listed Zn glycine share is [Zn(Glyc)2] at 5.9% of total glycine at pH 7.7. Most total glycine remains acid/base-buffered rather than metal-bound: H2Glycine+ dominates pH 2.0–2.4, HGlycine pH 2.4–9.4, and Glycine pH 9.4–12.0. Hydroxide solids replace soluble complexes in separate windows: Zn around pH 7.5, Cu around pH 11.3. This separation means a pH increase would selectively precipitate Zn first while leaving Cu mostly as soluble bis-glycinate until much higher pH.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv`

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

In the single mixed solution, Cu(II) wins the competition for glycine, while neither metal meaningfully “wins” ammonia as a dominant metal-binding ligand.

The key separation is that Cu(II) forms much stronger glycinate complexes than Zn(II), so Cu remains soluble as glycinate over a very broad pH range. Zn(II), by contrast, is only briefly complexed by glycine before hydroxide precipitation takes over. As pH is raised, the solution would therefore tend to precipitate Zn first while Cu stays mostly in solution as bis-glycinate until much higher pH.

For the metal speciation:

- **Cu(II):**
  - Free **Cu²⁺** dominates at **pH 2.0–3.7**.
  - **[Cu(Glyc)]⁺** dominates at **pH 3.7–4.8**.
  - **[Cu(Glyc)₂]** dominates at **pH 4.8–11.3**.
  - **Cu(OH)₂(s)** dominates at **pH 11.3–12.0**.
  - Thus Cu glycinate complexes give way to hydroxide solid only near **pH 11.28**.

- **Zn(II):**
  - Free **Zn²⁺** dominates at **pH 2.0–7.0**.
  - **[Zn(Glyc)]⁺** dominates at **pH 7.0–7.5**.
  - **[Zn(Glyc)₂]** appears only briefly around **pH 7.5**.
  - **Zn(OH)₂(alpha)** dominates from about **pH 7.5–12.0**.
  - Thus Zn glycinate complexes give way to hydroxide solid near **pH 7.51–7.52**, much earlier than Cu.

For ligand partitioning:

- **Glycine is dominated by Cu binding among the metals.** Cu bis-glycinate reaches the largest metal-bound glycine share, with **[Cu(Glyc)₂] up to 20.0% of total glycine at pH 8.2**.
- Zn binds much less of the glycine pool; the largest reported Zn glycinate share is **[Zn(Glyc)₂] at 5.9% of total glycine at pH 7.7**.
- Most total glycine still remains in acid/base forms rather than metal-bound forms: **H₂Glycine⁺** at low pH, **HGlycine** through the mid-pH range, and **Glycine⁻** at high pH.

For ammonia:

- The ammonia pool is mostly **HAmmonia⁺ from pH 2.0–9.3** and free **Ammonia from pH 9.3–12.0**.
- Although ammine complexes are thermodynamically included, they do not dominate either metal in this mixture.
- The largest noted ammine contribution is only a minor Zn feature: **[Zn(Ammo)₄]²⁺ reaches 12.4% at pH 9.2**.
- Chemically, Cu is held by stronger glycinate complexes, and Zn precipitates as hydroxide before ammonia can become the main Zn-binding ligand.

Overall: **Cu dominates glycine binding; ammonia does not dominate either metal; Zn hydroxide appears near pH 7.5, while Cu hydroxide does not replace Cu glycinate until about pH 11.3.**

## Evidence

- The calculation was a joint pH sweep for **1.00e-03 M Cu(II), 1.00e-03 M Zn(II), 1.00e-02 M total glycine, and 1.00e-01 M total ammonia** from **pH 2.0 to 12.0** at **25.0 °C**.
- The solver reported **401/401 pH points converged**.
- The calculated ionic-strength range was **0.00471442–0.0573917 M**; the thermodynamic source selection used **I = 0.1 M**, but the solved charge balance did not maintain 0.1 M by adding inert electrolyte.
- Cu glycinate stability constants exceeded Zn glycinate constants: **log β = +8.1900 for [Cu(Glyc)]⁺** and **+15.1000 for [Cu(Glyc)₂]**, versus Zn values of **+4.9600, +9.1900, and +11.6000** for **[Zn(Glyc)]⁺, [Zn(Glyc)₂], and [Zn(Glyc)₃]⁻**.
- Cu dominant-form crossovers were reported near **pH 3.64** for **Cu²⁺ ↔ [Cu(Glyc)]⁺**, **pH 4.73** for **[Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂]**, and **pH 11.28** for **[Cu(Glyc)₂] ↔ Cu(OH)₂(s)**.
- Zn dominant-form crossovers were reported near **pH 6.96** for **Zn²⁺ ↔ [Zn(Glyc)]⁺**, **pH 7.51** for **[Zn(Glyc)]⁺ ↔ Zn(OH)₂(alpha)**, and **pH 7.52** for **[Zn(Glyc)₂] ↔ Zn(OH)₂(alpha)**.
- Zn hydroxide was already present by **pH 7.33** at **2.24e-05 M**, increasing to **9.98e-04 M by pH 11.08**.
- Ligand partitioning showed **[Cu(Glyc)₂] up to 20.0% of total glycine at pH 8.2**, while the largest listed Zn glycine share was **[Zn(Glyc)₂] at 5.9% of total glycine at pH 7.7**.
- The largest reported ammine feature was minor: **[Zn(Ammo)₄]²⁺ reaches 12.4% at pH 9.2**.

## Artifacts

- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png`
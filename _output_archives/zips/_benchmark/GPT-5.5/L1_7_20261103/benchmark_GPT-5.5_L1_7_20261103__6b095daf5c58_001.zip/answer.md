## Answer

In the single mixed solution, Cu(II) wins the competition for glycine, while neither metal meaningfully “wins” ammonia as a dominant metal-binding ligand.

The key separation is that Cu(II) forms much stronger glycinate complexes than Zn(II), so Cu remains soluble as glycinate over a very broad pH range. Zn(II), by contrast, is only briefly complexed by glycine before hydroxide precipitation takes over. As pH is raised, the solution would therefore tend to precipitate Zn first while Cu stays mostly in solution as bis-glycinate until much higher pH.

For the metal speciation:

- **Cu(II):**
  - Free **Cu²⁺** dominates at **pH 2.0–3.7**.
  - **[Cu(Glyc)]⁺** dominates at **pH 3.7–4.8**.
  - **[Cu(Glyc)₂]** dominates at **pH 4.8–11.3**.
  - **Cu(OH)₂(s)** dominates at **pH 11.3–12.0**.
  - Thus Cu glycinate complexes give way to hydroxide solid only near **pH 11.28**.

- **Zn(II):**
  - Free **Zn²⁺** dominates at **pH 2.0–7.0**.
  - **[Zn(Glyc)]⁺** dominates at **pH 7.0–7.5**.
  - **[Zn(Glyc)₂]** appears only briefly around **pH 7.5**.
  - **Zn(OH)₂(alpha)** dominates from about **pH 7.5–12.0**.
  - Thus Zn glycinate complexes give way to hydroxide solid near **pH 7.51–7.52**, much earlier than Cu.

For ligand partitioning:

- **Glycine is dominated by Cu binding among the metals.** Cu bis-glycinate reaches the largest metal-bound glycine share, with **[Cu(Glyc)₂] up to 20.0% of total glycine at pH 8.2**.
- Zn binds much less of the glycine pool; the largest reported Zn glycinate share is **[Zn(Glyc)₂] at 5.9% of total glycine at pH 7.7**.
- Most total glycine still remains in acid/base forms rather than metal-bound forms: **H₂Glycine⁺** at low pH, **HGlycine** through the mid-pH range, and **Glycine⁻** at high pH.

For ammonia:

- The ammonia pool is mostly **HAmmonia⁺ from pH 2.0–9.3** and free **Ammonia from pH 9.3–12.0**.
- Although ammine complexes are thermodynamically included, they do not dominate either metal in this mixture.
- The largest noted ammine contribution is only a minor Zn feature: **[Zn(Ammo)₄]²⁺ reaches 12.4% at pH 9.2**.
- Chemically, Cu is held by stronger glycinate complexes, and Zn precipitates as hydroxide before ammonia can become the main Zn-binding ligand.

Overall: **Cu dominates glycine binding; ammonia does not dominate either metal; Zn hydroxide appears near pH 7.5, while Cu hydroxide does not replace Cu glycinate until about pH 11.3.**

## Evidence

- The calculation was a joint pH sweep for **1.00e-03 M Cu(II), 1.00e-03 M Zn(II), 1.00e-02 M total glycine, and 1.00e-01 M total ammonia** from **pH 2.0 to 12.0** at **25.0 °C**.
- The solver reported **401/401 pH points converged**.
- The calculated ionic-strength range was **0.00471442–0.0573917 M**; the thermodynamic source selection used **I = 0.1 M**, but the solved charge balance did not maintain 0.1 M by adding inert electrolyte.
- Cu glycinate stability constants exceeded Zn glycinate constants: **log β = +8.1900 for [Cu(Glyc)]⁺** and **+15.1000 for [Cu(Glyc)₂]**, versus Zn values of **+4.9600, +9.1900, and +11.6000** for **[Zn(Glyc)]⁺, [Zn(Glyc)₂], and [Zn(Glyc)₃]⁻**.
- Cu dominant-form crossovers were reported near **pH 3.64** for **Cu²⁺ ↔ [Cu(Glyc)]⁺**, **pH 4.73** for **[Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂]**, and **pH 11.28** for **[Cu(Glyc)₂] ↔ Cu(OH)₂(s)**.
- Zn dominant-form crossovers were reported near **pH 6.96** for **Zn²⁺ ↔ [Zn(Glyc)]⁺**, **pH 7.51** for **[Zn(Glyc)]⁺ ↔ Zn(OH)₂(alpha)**, and **pH 7.52** for **[Zn(Glyc)₂] ↔ Zn(OH)₂(alpha)**.
- Zn hydroxide was already present by **pH 7.33** at **2.24e-05 M**, increasing to **9.98e-04 M by pH 11.08**.
- Ligand partitioning showed **[Cu(Glyc)₂] up to 20.0% of total glycine at pH 8.2**, while the largest listed Zn glycine share was **[Zn(Glyc)₂] at 5.9% of total glycine at pH 7.7**.
- The largest reported ammine feature was minor: **[Zn(Ammo)₄]²⁺ reaches 12.4% at pH 9.2**.

## Artifacts

- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png`
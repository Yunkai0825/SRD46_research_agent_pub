## Doability
Doable: the request has catalog-plausible metals and ligands, uses the supported `pH_sweep` route, and specifies reference-like conditions of 25.0 °C and target ionic strength 0.1 M. The calculation is a fixed-redox Cu(II)/Zn(II) speciation sweep, not a Pourbaix/redox calculation.

## Result
Computed one joint pH-sweep for 1.00e-03 M Cu(II), 1.00e-03 M Zn(II), 1.00e-02 M total glycine, and 1.00e-01 M total ammonia from pH 2.0 to 12.0 at 25.0 °C, fixed ionic-strength mode with target I = 0.1 M. The solver reports 401/401 pH points converged, so the quoted pH regions are based on converged samples. The calculated ionic-strength range was 0.00471442–0.0573917 M, so the thermodynamic source selection is I = 0.1 M but the solved charge balance did not maintain 0.1 M by added inert electrolyte.

## Analysis
Cu(II) and Zn(II) behave very differently in the shared ligand pool. Cu(II) binds glycine much more strongly than Zn(II): the included cumulative log beta values are +8.1900 for [Cu(Glyc)]+ and +15.1000 for [Cu(Glyc)2], compared with +4.9600, +9.1900, and +11.6000 for [Zn(Glyc)]+, [Zn(Glyc)2], and [Zn(Glyc)3]-. This stronger Cu–glycinate stability lets Cu capture glycine across most of the soluble pH range.

For Cu, the dominant metal form changes from free Cu2+ at pH 2.0–3.7, to [Cu(Glyc)]+ at pH 3.7–4.8, to [Cu(Glyc)2] at pH 4.8–11.3, and finally to [Cu(OH)2](s) at pH 11.3–12.0. Reported crossovers are Cu2+ ↔ [Cu(Glyc)]+ near pH 3.64, [Cu(Glyc)]+ ↔ [Cu(Glyc)2] near pH 4.73, and [Cu(Glyc)2] ↔ [Cu(OH)2](s) near pH 11.28, each from the pH grid. Chemically, glycine deprotonation opens strong Cu(II) chelation at moderately acidic pH; only at very alkaline pH does hydroxide activity overcome the bis-glycinate complex and drive precipitation.

Zn is less protected by glycine and precipitates much earlier. Zn2+ dominates pH 2.0–7.0, [Zn(Glyc)]+ dominates pH 7.0–7.5, [Zn(Glyc)2] only briefly around pH 7.5, and Zn(OH)2(alpha) dominates from pH 7.5 to 12.0. The verdict reports Zn2+ ↔ [Zn(Glyc)]+ near pH 6.96, [Zn(Glyc)]+ ↔ Zn(OH)2(alpha) near pH 7.51, and [Zn(Glyc)2] ↔ Zn(OH)2(alpha) near pH 7.52. The precipitation summary already shows Zn(OH)2(alpha) present by pH 7.33 at 2.24e-05 M, increasing to 9.98e-04 M by pH 11.08. Thus Zn hydroxide formation removes Zn from solution soon after glycine complexation begins to matter.

Ammonia does not dominate metal partitioning in this mixture. Its ligand pool is HAmmonia+ from pH 2.0–9.3 and free Ammonia from pH 9.3–12.0. Although Cu and Zn ammine constants are included, e.g. log beta +12.3000 for [Cu(Ammo)4]2+ and +8.8900 for [Zn(Ammo)4]2+, the metal speciation verdict shows no Cu ammine dominant region and only a minor Zn ammine peak: [Zn(Ammo)4]2+ reaches 12.4% at pH 9.2. Practically, glycine wins for Cu, while Zn is lost to Zn(OH)2(s) before ammine complexes can dominate.

For ligand competition, Cu dominates glycine binding over the important soluble window: [Cu(Glyc)2] accounts for up to 20.0% of total glycine at pH 8.2, while the largest listed Zn glycine share is [Zn(Glyc)2] at 5.9% of total glycine at pH 7.7. Most total glycine remains acid/base-buffered rather than metal-bound: H2Glycine+ dominates pH 2.0–2.4, HGlycine pH 2.4–9.4, and Glycine pH 9.4–12.0. Hydroxide solids replace soluble complexes in separate windows: Zn around pH 7.5, Cu around pH 11.3. This separation means a pH increase would selectively precipitate Zn first while leaving Cu mostly as soluble bis-glycinate until much higher pH.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv`
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength 0.1."},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM Cu(II)."},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "Redox excluded; no Cu(I) pool specified for the Cu(II) speciation experiment."},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "Redox excluded; no elemental copper pool specified."},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known", "note": "Task states 1 mM Zn(II)."},
  {"id": "Zn0", "lhs": lambda s: s.total["Zn$+0"], "value": 0.0, "basis": "assumed", "note": "Redox excluded; no elemental zinc pool specified."},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "Task states 10 mM total glycine."},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "Task states 0.1 M total ammonia."},
]
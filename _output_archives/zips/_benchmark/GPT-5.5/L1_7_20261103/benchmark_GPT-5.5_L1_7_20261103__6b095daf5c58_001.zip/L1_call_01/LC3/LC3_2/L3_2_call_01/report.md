# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 27.12
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 9 pin(s) (6 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1.
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Cu(II).
  {"lhs": lambda s: s.total["Cu$+1"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no Cu(I) pool specified for the Cu(II) speciation experiment.
  {"lhs": lambda s: s.total["Cu$+0"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no elemental copper pool specified.
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Zn(II).
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no elemental zinc pool specified.
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM total glycine.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M total ammonia.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Selected pH_sweep scans pH over the task range 2 to 12; L3_3 must define the grid.'},
]

```

## Notes
Task fixes T=25 C, I=0.1, Cu(II)=1 mM, Zn(II)=1 mM, glycine=10 mM, and ammonia=0.1 M. pH is the sweep axis. Redox is excluded for this pH speciation path, so unspecified Cu(I), Cu(0), and Zn(0) valence pools are explicitly set to zero; hydroxide solids are included.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
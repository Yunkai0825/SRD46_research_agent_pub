# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task states ionic strength 0.1.
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Cu(II).
  {"lhs": lambda s: s.total["Cu$+1"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no Cu(I) pool specified for the Cu(II) speciation experiment.
  {"lhs": lambda s: s.total["Cu$+0"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no elemental copper pool specified.
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},  # Task states 1 mM Zn(II).
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "assumed"},  # Redox excluded; no elemental zinc pool specified.
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # Task states 10 mM total glycine.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task states 0.1 M total ammonia.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Selected pH_sweep scans pH over the task range 2 to 12; L3_3 must define the grid.'},
]

# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-1] | [Glycine] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z+0] | [Ammonia] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[L1].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[L1]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[L2]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Cu$+2].[L2]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Zn$+2].[z+2] | [Zn]2+ | aqueous | +0.0000 | [Zn$+2]:+1 | SRD-46 | true |
| [Zn$+2].[OH].[z+1] | [Zn(OH)]+ | aqueous | -9.3000 | [Zn$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Zn$+2].[OH]2.[z+0] | [Zn(OH)2] | aqueous | -17.8000 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Zn$+2].[OH]3.[z-1] | [Zn(OH)3]- | aqueous | -28.1000 | [Zn$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Zn$+2].[OH]4.[z-2] | [Zn(OH)4]2- | aqueous | -40.5000 | [Zn$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Zn$+2].[L1].[z+1] | [Zn(Glyc)]+ | aqueous | +4.9600 | [Zn$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L1]2.[z+0] | [Zn(Glyc)2] | aqueous | +9.1900 | [Zn$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Zn$+2].[L1]3.[z-1] | [Zn(Glyc)3]- | aqueous | +11.6000 | [Zn$+2]:+1, [L1]:+3 | SRD-46 | true |
| [Zn$+2].[OH].[L1].[z+0] | [Zn(Glyc)(OH)] | aqueous | -3.9400 | [Zn$+2]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L2]4.[z+2] | [Zn(Ammo)4]2+ | aqueous | +8.8900 | [Zn$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Zn$+2].[L2]3.[z+2] | [Zn(Ammo)3]2+ | aqueous | +6.8600 | [Zn$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Zn$+2].[L2]2.[z+2] | [Zn(Ammo)2]2+ | aqueous | +4.5000 | [Zn$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Zn$+2].[L2].[z+2] | [Zn(Ammo)]2+ | aqueous | +2.3300 | [Zn$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Zn$+2.OH2.z+0(s)[3] | Zn(OH)2 (alpha) | dissolution | -10.7230 | Zn$+2:+1 H:-2 | Atlas | true |

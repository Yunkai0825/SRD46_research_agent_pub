# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as a single-solution equilibrium speciation and precipitation calculation, not corrosion, electrodeposition, or a Pourbaix redox problem: 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine, and 0.1 M total ammonia at 25 °C and I = 0.1 m over pH 2–12.
- Aqueous identity is governed by the millimolar metal / high-ammonia / excess-glycine ligand pool, not by the 1e-6 M corrosion convention; retain soluble Cu(II)/Zn(II) glycinato, ammine, hydroxo, and relevant polynuclear hydrolysis species as distinct if their stoichiometry or aggregation differs.
- Interpret L1 as glycinate and L2 as ammine/NH3; formula spellings such as oxo vs hydroxo for the same metal/proton/charge state are duplicate notation unless they represent a different nuclearity or ligand stoichiometry.
- The requested precipitates are hydroxide solids formed from aqueous solution at 25 °C; keep hydrated hydroxide-solid representatives and exclude aged anhydrous oxide branches unless no hydroxide-solid alternative exists.
- Carbonate and other counterion solids are out of scope because no carbonate/counterion ligand pool is part of the specified solution.
- Do not keep redox branches: the model has no imposed pe/Eh and starts from Cu(II)/Zn(II), so Cu(I), Cu(0), Zn(0), and Cu(I) oxide/complex branches are decorative for this calculation.
- The phase question is thermodynamic precipitation/stability, not polymorph formation history; collapse duplicate polymorphs or source variants of the same hydroxide solid to one stable representative rather than retaining all formation products.
- Prefer the SRD-46 aqueous identity when Atlas and SRD-46 are merely alternate labels for the same soluble species, because the ligand-complex constants come from the SRD-46 suite at the stated ionic-strength context; if only Atlas supplies a high-pH hydrolysis state, it may be retained.
- Element treatment diverges only where chemistry requires it: Cu has explicit out-of-scope Cu(I) complexes/oxide to remove, while Zn mainly needs hydroxo-notation and hydroxide-polymorph collapse.

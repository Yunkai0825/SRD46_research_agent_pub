## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a single-solution equilibrium speciation and precipitation calculation, not corrosion, electrodeposition, or a Pourbaix redox problem: 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine, and 0.1 M total ammonia at 25 °C and I = 0.1 m over pH 2–12.
- Aqueous identity is governed by the millimolar metal / high-ammonia / excess-glycine ligand pool, not by the 1e-6 M corrosion convention; retain soluble Cu(II)/Zn(II) glycinato, ammine, hydroxo, and relevant polynuclear hydrolysis species as distinct if their stoichiometry or aggregation differs.
- Interpret L1 as glycinate and L2 as ammine/NH3; formula spellings such as oxo vs hydroxo for the same metal/proton/charge state are duplicate notation unless they represent a different nuclearity or ligand stoichiometry.
- The requested precipitates are hydroxide solids formed from aqueous solution at 25 °C; keep hydrated hydroxide-solid representatives and exclude aged anhydrous oxide branches unless no hydroxide-solid alternative exists.
- Carbonate and other counterion solids are out of scope because no carbonate/counterion ligand pool is part of the specified solution.
- Do not keep redox branches: the model has no imposed pe/Eh and starts from Cu(II)/Zn(II), so Cu(I), Cu(0), Zn(0), and Cu(I) oxide/complex branches are decorative for this calculation.
- The phase question is thermodynamic precipitation/stability, not polymorph formation history; collapse duplicate polymorphs or source variants of the same hydroxide solid to one stable representative rather than retaining all formation products.
- Prefer the SRD-46 aqueous identity when Atlas and SRD-46 are merely alternate labels for the same soluble species, because the ligand-complex constants come from the SRD-46 suite at the stated ionic-strength context; if only Atlas supplies a high-pH hydrolysis state, it may be retained.
- Element treatment diverges only where chemistry requires it: Cu has explicit out-of-scope Cu(I) complexes/oxide to remove, while Zn mainly needs hydroxo-notation and hydroxide-polymorph collapse.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Use a non-redox Zn(II) speciation rule: drop Zn metal and anhydrous ZnO variants, and keep distinct Zn(II) glycinate, hydroxo-glycinate, ammine, and hydrolysis stoichiometries. Collapse duplicate aqueous hydroxo notation to the SRD-46 hydroxo form, and collapse Zn(OH)2 polymorph/amorphous/source variants to the single lowest-mu hydrated hydroxide representative as the thermodynamic precipitate.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-4 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-3e6f1635d8593421` | aqueous | `[ZnO2]2-` | Atlas | -2 | 190.640 | 1 | — |
| `DEDUP-48795537c4c02148` | aqueous | `[Zn(OH)4]2-` | SRD-46 | -2 | 231.161 | 1 | *** |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
Kept `[Zn(OH)4]2-` from `SRD-46`; dropped Atlas `[ZnO2]2-` as duplicate hydroxo/oxo notation for the same Zn(II) aqueous hydrolysis state, preferring the SRD-46 hydroxo form.
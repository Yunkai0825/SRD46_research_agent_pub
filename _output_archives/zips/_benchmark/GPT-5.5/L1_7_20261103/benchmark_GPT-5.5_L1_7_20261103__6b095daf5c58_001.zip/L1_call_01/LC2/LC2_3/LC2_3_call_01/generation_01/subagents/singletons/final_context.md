## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as a single-solution equilibrium speciation and precipitation calculation, not corrosion, electrodeposition, or a Pourbaix redox problem: 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine, and 0.1 M total ammonia at 25 °C and I = 0.1 m over pH 2–12.
- Aqueous identity is governed by the millimolar metal / high-ammonia / excess-glycine ligand pool, not by the 1e-6 M corrosion convention; retain soluble Cu(II)/Zn(II) glycinato, ammine, hydroxo, and relevant polynuclear hydrolysis species as distinct if their stoichiometry or aggregation differs.
- Interpret L1 as glycinate and L2 as ammine/NH3; formula spellings such as oxo vs hydroxo for the same metal/proton/charge state are duplicate notation unless they represent a different nuclearity or ligand stoichiometry.
- The requested precipitates are hydroxide solids formed from aqueous solution at 25 °C; keep hydrated hydroxide-solid representatives and exclude aged anhydrous oxide branches unless no hydroxide-solid alternative exists.
- Carbonate and other counterion solids are out of scope because no carbonate/counterion ligand pool is part of the specified solution.
- Do not keep redox branches: the model has no imposed pe/Eh and starts from Cu(II)/Zn(II), so Cu(I), Cu(0), Zn(0), and Cu(I) oxide/complex branches are decorative for this calculation.
- The phase question is thermodynamic precipitation/stability, not polymorph formation history; collapse duplicate polymorphs or source variants of the same hydroxide solid to one stable representative rather than retaining all formation products.
- Prefer the SRD-46 aqueous identity when Atlas and SRD-46 are merely alternate labels for the same soluble species, because the ligand-complex constants come from the SRD-46 suite at the stated ionic-strength context; if only Atlas supplies a high-pH hydrolysis state, it may be retained.
- Element treatment diverges only where chemistry requires it: Cu has explicit out-of-scope Cu(I) complexes/oxide to remove, while Zn mainly needs hydroxo-notation and hydroxide-polymorph collapse.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Use a non-redox Cu(II) speciation rule: drop Cu(I), Cu(0), Cu2O, and Cu(I) ligand complexes, and keep distinct Cu(II) glycinate, ammine, mononuclear hydrolysis, and polynuclear hydrolysis species. For duplicate Cu(II) aquo or Cu(OH)2(s) labels, prefer the SRD-46 representative; exclude anhydrous CuO as an aged oxide branch because the requested precipitate is hydroxide solid.
- Zn: Use a non-redox Zn(II) speciation rule: drop Zn metal and anhydrous ZnO variants, and keep distinct Zn(II) glycinate, hydroxo-glycinate, ammine, and hydrolysis stoichiometries. Collapse duplicate aqueous hydroxo notation to the SRD-46 hydroxo form, and collapse Zn(OH)2 polymorph/amorphous/source variants to the single lowest-mu hydrated hydroxide representative as the thermodynamic precipitate.

[Singletons: n=29]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L2:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +1 | 26.312 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +0 | 77.111 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +0 | 56.791 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | -1 | 97.659 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:1` | `[Zn(Ammo)]2+` | SRD-46 | +2 | -13.299 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:2` | `[Zn(Ammo)2]2+` | SRD-46 | +2 | -25.685 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:3` | `[Zn(Ammo)3]2+` | SRD-46 | +2 | -39.155 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:4` | `[Zn(Ammo)4]2+` | SRD-46 | +2 | -50.741 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |

## Assistant
<summary>Reviewed all singleton species against the non-redox Cu(II)/Zn(II) speciation scope. Cu(I) complexes and elemental Cu/Zn metal solids are excluded as redox/metal branches; all ligand, hydrolysis, and background acid–base aqueous species remain in scope.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 29 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
Singleton review completed: 25 kept, 4 dropped.

Dropped as out of scope:
- Aqueous `Cu$+1:1 L1:2` — `[Cu(Glyc)2]-`: Cu(I) ligand complex excluded under non-redox Cu(II) speciation.
- Aqueous `Cu$+1:1 L2:2` — `[Cu(Ammo)2]+`: Cu(I) ammine complex excluded under non-redox Cu(II) speciation.
- Solid `Cu$+0:1` — `Cu`: elemental copper metal is a redox/electrodeposition branch, not part of this Cu(II) precipitation/speciation calculation.
- Solid `Zn$+0:1` — `Zn`: elemental zinc metal is a redox/electrodeposition branch, not part of this Zn(II) precipitation/speciation calculation.

Kept:
- All Cu(II) aqueous glycinato, ammine, mononuclear hydrolysis, and polynuclear hydrolysis species.
- All Zn(II) aqueous glycinato, hydroxo-glycinato, ammine, and hydrolysis species.
- Glycine/ammonia acid–base background species.
- The neutral empty/background aqueous entry, since no instruction excludes it and it is not a redox or precipitate branch.
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    380.86
- elapsed_s (total):  380.86
- llm_iterations:     52
- llm_tool_calls:     42

- n_groups:           39
- n_multi_groups:     10
- n_singletons:       29
- n_decisions:        39
- n_dropped:          30
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) is generally out of scope for this non-redox Cu(II) calculation, but because the group cannot be emptied, the duplicate aqueous Cu+ notation is collapsed to the preferred SRD-46 representative. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) free ion with identical charge and μ, so the SRD-46 representative is preferred. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both because they are distinct Cu(II) hydrolysis species with different nuclearity, both relevant to the specified non-redox aqueous speciation calculation. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous Zn(II) ion, so the SRD-46 identity is retained per the plan and case-specific preference. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | The two aqueous +1 mononuclear Zn hydroxo entries are duplicate notation for the same Zn(II) hydrolysis species, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | [HZnO2]- is duplicate oxo/hydroxo notation for the same aqueous Zn(II) hydrolysis state, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are duplicate aqueous hydroxo notations for the same Zn(II) hydrolysis state, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Although Cu(I) oxide is out of scope for the Cu(II) calculation, the group cannot be emptied, so the SRD-46 representative is kept over the Atlas duplicate notation. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | For the specified Cu(II) precipitation calculation, the hydrated hydroxide solid is the in-scope representative, SRD-46 is preferred over the duplicate Atlas label, and anhydrous CuO aged oxide branches are excluded. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | No case-specific exclusion applies to this neutral singleton background aqueous entry, so it is retained by default. |
| aqueous | `Cu$+1:1 L1:2` | NO | This is a Cu(I) glycinato complex, and Cu(I) redox branches are out of scope for the non-redox Cu(II) calculation. |
| aqueous | `Cu$+1:1 L2:2` | NO | This is a Cu(I) ammine complex, and Cu(I) redox branches are out of scope for the non-redox Cu(II) calculation. |
| aqueous | `Cu$+2:1 H:-2` | yes | This is a distinct in-scope mononuclear Cu(II) hydrolysis species from SRD-46. |
| aqueous | `Cu$+2:1 H:-3` | yes | This is a distinct high-pH Cu(II) hydrolysis state supplied by Atlas and is in scope because no duplicate SRD-46 identity is present. |
| aqueous | `Cu$+2:1 H:-4` | yes | This is a distinct high-pH Cu(II) hydrolysis state supplied by Atlas and is in scope because no duplicate SRD-46 identity is present. |
| aqueous | `Cu$+2:1 L1:1` | yes | This is a distinct Cu(II) glycinato complex relevant to the excess-glycine ligand pool. |
| aqueous | `Cu$+2:1 L1:2` | yes | This is a distinct Cu(II) bis-glycinato complex relevant to the excess-glycine ligand pool. |
| aqueous | `Cu$+2:1 L2:1` | yes | This is a distinct Cu(II) monoammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Cu$+2:1 L2:2` | yes | This is a distinct Cu(II) diammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Cu$+2:1 L2:3` | yes | This is a distinct Cu(II) triammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Cu$+2:1 L2:4` | yes | This is a distinct Cu(II) tetraammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Cu$+2:3 H:-4` | yes | This is a distinct polynuclear Cu(II) hydrolysis species retained under the aqueous speciation instructions. |
| aqueous | `L1:1` | yes | Free glycinate is part of the specified total glycine acid-base ligand pool and is in scope. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine is part of the specified total glycine acid-base ligand pool and is in scope. |
| aqueous | `L1:1 H:2` | yes | Protonated glycine is part of the specified total glycine acid-base ligand pool and is in scope over pH 2–12. |
| aqueous | `L2:1` | yes | Free ammonia is part of the specified total ammonia ligand pool and is in scope. |
| aqueous | `L2:1 H:1` | yes | Ammonium is part of the specified total ammonia acid-base ligand pool and is in scope over pH 2–12. |
| aqueous | `Zn$+2:1 H:-2` | yes | This is a distinct in-scope mononuclear Zn(II) hydrolysis species from SRD-46. |
| aqueous | `Zn$+2:1 L1:1` | yes | This is a distinct Zn(II) glycinato complex relevant to the excess-glycine ligand pool. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | This is a distinct Zn(II) hydroxo-glycinato complex relevant to the specified ligand and hydrolysis chemistry. |
| aqueous | `Zn$+2:1 L1:2` | yes | This is a distinct Zn(II) bis-glycinato complex relevant to the excess-glycine ligand pool. |
| aqueous | `Zn$+2:1 L1:3` | yes | This is a distinct Zn(II) tris-glycinato complex relevant to the excess-glycine ligand pool. |
| aqueous | `Zn$+2:1 L2:1` | yes | This is a distinct Zn(II) monoammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Zn$+2:1 L2:2` | yes | This is a distinct Zn(II) diammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Zn$+2:1 L2:3` | yes | This is a distinct Zn(II) triammine complex relevant to the high-ammonia ligand pool. |
| aqueous | `Zn$+2:1 L2:4` | yes | This is a distinct Zn(II) tetraammine complex relevant to the high-ammonia ligand pool. |
| solid | `Cu$+0:1` | NO | Elemental copper is a Cu(0) redox branch and is out of scope for the non-redox Cu(II) precipitation/speciation calculation. |
| solid | `Zn$+0:1` | NO | Elemental zinc metal is a Zn(0) redox branch and is out of scope for the non-redox Zn(II) precipitation/speciation calculation. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: supervisor override: Cu(I) free ion is a redox branch outside the non-redox Cu(II)/Zn(II) ligand speciation calculation; no Cu(I) representative should remain in scope. |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Cu(I) free ion is a redox branch outside the non-redox Cu(II)/Zn(II) ligand speciation calculation; it was retained only because the duplicate worker could not empty the Cu(I) group. |
| `[Cu(Glyc)2]-` | SRD-46 | aqueous | LC2 element review: This is a Cu(I) glycinato complex, and Cu(I) redox branches are out of scope for the non-redox Cu(II) calculation. |
| `[Cu(Ammo)2]+` | SRD-46 | aqueous | LC2 element review: This is a Cu(I) ammine complex, and Cu(I) redox branches are out of scope for the non-redox Cu(II) calculation. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) free ion with identical charge and μ, so the SRD-46 representative is preferred. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous Zn(II) ion, so the SRD-46 identity is retained per the plan and case-specific preference. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: The two aqueous +1 mononuclear Zn hydroxo entries are duplicate notation for the same Zn(II) hydrolysis species, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: [HZnO2]- is duplicate oxo/hydroxo notation for the same aqueous Zn(II) hydrolysis state, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are duplicate aqueous hydroxo notations for the same Zn(II) hydrolysis state, so the SRD-46 hydroxo form is retained per the Zn instructions. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu2O is a Cu(I) oxide redox branch outside the specified non-redox Cu(II)/Zn(II) ligand speciation and hydroxide-precipitation calculation; it was retained only because the duplicate worker could not empty the Cu(I) oxide group. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Although Cu(I) oxide is out of scope for the Cu(II) calculation, the group cannot be emptied, so the SRD-46 representative is kept over the Atlas duplicate notation. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: For the specified Cu(II) precipitation calculation, the hydrated hydroxide solid is the in-scope representative, SRD-46 is preferred over the duplicate Atlas label, and anhydrous CuO aged oxide branches are excluded. |
| `CuO` | Atlas | dissolution | LC2 element review: For the specified Cu(II) precipitation calculation, the hydrated hydroxide solid is the in-scope representative, SRD-46 is preferred over the duplicate Atlas label, and anhydrous CuO aged oxide branches are excluded. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: For the specified Cu(II) precipitation calculation, the hydrated hydroxide solid is the in-scope representative, SRD-46 is preferred over the duplicate Atlas label, and anhydrous CuO aged oxide branches are excluded. |
| `Cu` | Atlas | dissolution | LC2 element review: Elemental copper is a Cu(0) redox branch and is out of scope for the non-redox Cu(II) precipitation/speciation calculation. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `ZnO` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: For Zn(II) precipitation, anhydrous ZnO branches are out of scope and Zn(OH)2 polymorph/source variants collapse to the single lowest-mu hydrated hydroxide representative, Zn(OH)2 (alpha) from Atlas. |
| `Zn` | Atlas | dissolution | LC2 element review: Elemental zinc metal is a Zn(0) redox branch and is out of scope for the non-redox Zn(II) precipitation/speciation calculation. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: cd9929db29fd4f8bb19b06164c4c1194
- review_turns: 4
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplicated selection accepted. The table keeps the Cu(II)/Zn(II) aqueous glycinato, ammine, hydrolysis, and relevant polynuclear hydrolysis species needed for the specified 1 mM mixed-metal, excess-glycine, high-ammonia pH-sweep speciation model. It removes Cu(I), Cu(0), Zn(0), Cu2O, and anhydrous oxide redox/aged branches that are outside the non-redox precipitation question, and collapses duplicate soluble identities plus hydroxide polymorph/source variants to the intended thermodynamic representatives.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (16/16)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_7_20261103\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

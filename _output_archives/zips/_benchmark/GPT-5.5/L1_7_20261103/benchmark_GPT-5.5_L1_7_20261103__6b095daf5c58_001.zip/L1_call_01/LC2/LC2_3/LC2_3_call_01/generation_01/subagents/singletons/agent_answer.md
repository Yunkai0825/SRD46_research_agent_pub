Singleton review completed: 25 kept, 4 dropped.

Dropped as out of scope:
- Aqueous `Cu$+1:1 L1:2` — `[Cu(Glyc)2]-`: Cu(I) ligand complex excluded under non-redox Cu(II) speciation.
- Aqueous `Cu$+1:1 L2:2` — `[Cu(Ammo)2]+`: Cu(I) ammine complex excluded under non-redox Cu(II) speciation.
- Solid `Cu$+0:1` — `Cu`: elemental copper metal is a redox/electrodeposition branch, not part of this Cu(II) precipitation/speciation calculation.
- Solid `Zn$+0:1` — `Zn`: elemental zinc metal is a redox/electrodeposition branch, not part of this Zn(II) precipitation/speciation calculation.

Kept:
- All Cu(II) aqueous glycinato, ammine, mononuclear hydrolysis, and polynuclear hydrolysis species.
- All Zn(II) aqueous glycinato, hydroxo-glycinato, ammine, and hydrolysis species.
- Glycine/ammonia acid–base background species.
- The neutral empty/background aqueous entry, since no instruction excludes it and it is not a redox or precipitate branch.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) free ion is a redox branch outside the non-redox Cu(II)/Zn(II) ligand speciation calculation; it was retained only because the duplicate worker could not empty the Cu(I) group. |

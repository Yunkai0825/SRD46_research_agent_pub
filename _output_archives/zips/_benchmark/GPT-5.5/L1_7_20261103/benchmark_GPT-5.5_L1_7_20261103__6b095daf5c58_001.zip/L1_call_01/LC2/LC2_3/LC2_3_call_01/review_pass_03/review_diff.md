# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu2O is a Cu(I) oxide redox branch outside the specified non-redox Cu(II)/Zn(II) ligand speciation and hydroxide-precipitation calculation; it was retained only because the duplicate worker could not empty the Cu(I) oxide group. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a single-solution equilibrium speciation and precipitation calculation, not corrosion, electrodeposition, or a Pourbaix redox problem: 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine, and 0.1 M total ammonia at 25 °C and I = 0.1 m over pH 2–12.
- Aqueous identity is governed by the millimolar metal / high-ammonia / excess-glycine ligand pool, not by the 1e-6 M corrosion convention; retain soluble Cu(II)/Zn(II) glycinato, ammine, hydroxo, and relevant polynuclear hydrolysis species as distinct if their stoichiometry or aggregation differs.
- Interpret L1 as glycinate and L2 as ammine/NH3; formula spellings such as oxo vs hydroxo for the same metal/proton/charge state are duplicate notation unless they represent a different nuclearity or ligand stoichiometry.
- The requested precipitates are hydroxide solids formed from aqueous solution at 25 °C; keep hydrated hydroxide-solid representatives and exclude aged anhydrous oxide branches unless no hydroxide-solid alternative exists.
- Carbonate and other counterion solids are out of scope because no carbonate/counterion ligand pool is part of the specified solution.
- Do not keep redox branches: the model has no imposed pe/Eh and starts from Cu(II)/Zn(II), so Cu(I), Cu(0), Zn(0), and Cu(I) oxide/complex branches are decorative for this calculation.
- The phase question is thermodynamic precipitation/stability, not polymorph formation history; collapse duplicate polymorphs or source variants of the same hydroxide solid to one stable representative rather than retaining all formation products.
- Prefer the SRD-46 aqueous identity when Atlas and SRD-46 are merely alternate labels for the same soluble species, because the ligand-complex constants come from the SRD-46 suite at the stated ionic-strength context; if only Atlas supplies a high-pH hydrolysis state, it may be retained.
- Element treatment diverges only where chemistry requires it: Cu has explicit out-of-scope Cu(I) complexes/oxide to remove, while Zn mainly needs hydroxo-notation and hydroxide-polymorph collapse.

## Element instructions

- **Cu**: Use a non-redox Cu(II) speciation rule: drop Cu(I), Cu(0), Cu2O, and Cu(I) ligand complexes, and keep distinct Cu(II) glycinate, ammine, mononuclear hydrolysis, and polynuclear hydrolysis species. For duplicate Cu(II) aquo or Cu(OH)2(s) labels, prefer the SRD-46 representative; exclude anhydrous CuO as an aged oxide branch because the requested precipitate is hydroxide solid.
- **Zn**: Use a non-redox Zn(II) speciation rule: drop Zn metal and anhydrous ZnO variants, and keep distinct Zn(II) glycinate, hydroxo-glycinate, ammine, and hydrolysis stoichiometries. Collapse duplicate aqueous hydroxo notation to the SRD-46 hydroxo form, and collapse Zn(OH)2 polymorph/amorphous/source variants to the single lowest-mu hydrated hydroxide representative as the thermodynamic precipitate.

[Purpose: Compute a joint pH-sweep speciation model for one mixed solution containing Cu(II), Zn(II), glycine, and ammonia at 25 C and ionic strength 0.1 m. The goal is to quantify how Cu and Zn compete for the shared glycinate and ammine ligand pools, and to identify where soluble complexes are replaced by hydroxide solids.]
[Tasks:
For a single solution, model 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine, and 0.1 M total ammonia together at 25 C and I = 0.1 m over pH 2 to 12. Include the relevant Cu(II)-glycinate, Cu(II)-ammine, Zn(II)-glycinate, Zn(II)-ammine, hydrolysis, and hydroxide solid phases, and prefer/report hydroxide solids where precipitation is thermodynamically favored. Produce joint speciation curves and tabular outputs showing how each metal partitions among free aquo/hydroxo species, glycinate complexes, ammine complexes, and hydroxide solids in the shared ligand pool. Report which metal dominates glycine binding and ammonia binding as a function of pH, and give the pH window where glycinate/ammine soluble complexes give way to Cu and Zn hydroxide solids, with convergence evidence for the quoted pH ranges.
]
[Pair: pair_key=`m68_l10103`, metal_id=68, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10103_beta79_net28125` | `[L] + [H] <=> [HL]` | vlm_173034@(25.0,0.1) = K+9.260 | 20 | +8.805 / +9.540 / +9.585 / +10.450 | vlm_173034@(25.0,0.1) = K+9.260 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

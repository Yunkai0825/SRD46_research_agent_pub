# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: this is an equilibrium pH-sweep speciation/solubility calculation for Fe(III) complexed by citrate, not corrosion, electrodeposition, or Pourbaix redox mapping; use the stated total Fe and citrate concentrations to decide aqueous relevance.
- Aqueous context: total Fe is 1 mM and total citrate is 5 mM at 25 C and I = 0.1 over pH 4-9; do not apply the 1e-6 M corrosion convention. Retain Fe(III) hydrolysis, Fe(III)-citrate protonation/hydroxo species, and documented Fe(III) polynuclear hydrolysis/citrate complexes because 1 mM Fe can make them concentration-relevant.
- Redox scope: the feed is Fe(III) with no pe/Eh constraint and the requested output is Fe(III)-citrate solubility; Fe(II), Fe(0), mixed Fe(II)/Fe(III), and Fe(VI) branches are out of scope unless needed only as duplicate references, which they are not here.
- Hydrated/aged solids: the precipitate question is specifically whether Fe(OH)3(s) appears or reappears in an aqueous 25 C pH sweep, so keep the operational hydrous Fe(OH)3(s) phase and do not substitute aged/crystalline FeOOH or Fe2O3 as the same precipitate. Anhydrous/crystalline oxides may be stable thermodynamic endpoints in other contexts but are out of scope for this kinetic/solution-speciation question.
- Carbonates/counterion solids: no carbonate, metal counterion, or citrate solid precipitation phase is part of the stated Fe+citrate-only solution; do not keep such branches if encountered.
- Duplicate notation: formula spellings such as Fe3+ vs [Fe]3+ or FeOH2+ vs Fe(OH)2+ are duplicates when they encode the same mononuclear aqueous state; prefer SRD-46 over Atlas for the same physical state unless the Atlas row is the only available representation.
- Distinct complexes: shared normalized Fe:Citr:H stoichiometry does not by itself make a mononuclear and polynuclear species duplicates; keep documented polynuclear species such as Fe2 citrate/hydroxo and Fe3 hydrolysis complexes as distinct competitors.
- Phase question: the calculation asks dominant dissolved species and appearance of Fe(OH)3(s), not polymorph formation; collapse duplicate spellings of the same solid chemistry but do not keep alternate aged polymorphs that would change the question.

## Element instructions

- **Fe**: For this Fe(III)-citrate pH sweep, keep SRD-46 Fe(III) aqueous species, Fe(III)-citrate protonation/hydroxo species, and Fe(III) polynuclear hydrolysis/citrate complexes as distinct competitors at 1 mM Fe/5 mM citrate; remove duplicate Atlas spellings when an SRD-46 representation of the same mononuclear state exists. Exclude Fe(II), Fe(0), Fe(VI), magnetite, Fe(OH)2, Fe2O3, and FeOOH/aged oxide branches as outside the stated no-Eh Fe(III) solubility question, while keeping hydrous Fe(OH)3(s) as the operational precipitate phase and preferring SRD-46 for duplicate Fe(OH)3(s) rows.

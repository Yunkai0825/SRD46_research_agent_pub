# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(OH)2(s) is an Fe(II) solid and is outside the no-Eh Fe(III)-citrate pH-sweep; only hydrous Fe(OH)3(s) should remain as the operational precipitate phase. |

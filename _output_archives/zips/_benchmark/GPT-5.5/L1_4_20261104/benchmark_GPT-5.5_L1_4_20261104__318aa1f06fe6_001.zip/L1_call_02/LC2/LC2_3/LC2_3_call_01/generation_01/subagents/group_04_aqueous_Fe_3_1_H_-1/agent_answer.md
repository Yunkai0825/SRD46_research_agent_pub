Kept:
- `[Fe(OH)]2+` — SRD-46
- `[Fe2(OH)2]4+` — SRD-46

Rationale: Kept the SRD-46 mononuclear Fe(III) hydrolysis species over the duplicate Atlas spelling and retained the distinct SRD-46 polynuclear hydrolysis complex as relevant for the Fe(III)-citrate pH sweep.
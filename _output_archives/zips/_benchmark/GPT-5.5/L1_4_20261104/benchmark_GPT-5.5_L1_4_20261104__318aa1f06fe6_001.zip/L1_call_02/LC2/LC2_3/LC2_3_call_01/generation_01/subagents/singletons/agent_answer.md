Singleton verdicts applied:

| Phase | Core label | Decision | Rationale |
|---|---|---:|---|
| aqueous | `(empty)` | Keep | No case-specific instruction excludes this singleton background aqueous entry. |
| aqueous | `Fe$+2:1 H:-1` | Drop | Fe(II) hydrolysis species are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 H:-2` | Drop | Fe(II) hydrolysis species are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 H:-4` | Drop | Fe(II) hydrolysis species are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 L1:1` | Drop | Fe(II)-citrate complexes are outside the stated Fe(III)-only redox scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Drop | This is a Fe(II) citrate/hydroxo branch and is outside the Fe(III)-citrate calculation scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Drop | Fe(II)-citrate protonation species are outside the stated Fe(III)-only redox scope. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Drop | Fe(II)-citrate protonation species are outside the stated Fe(III)-only redox scope. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Drop | Fe(II)-citrate complexes are outside the stated Fe(III)-only redox scope. |
| aqueous | `Fe$+3:1 H:-4` | Keep | Fe(III) hydrolysis species are in scope for the pH-sweep speciation calculation. |
| aqueous | `Fe$+3:1 L1:1` | Keep | Fe(III)-citrate complexes are central to the requested speciation calculation. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Keep | Fe(III)-citrate protonation species are in scope. |
| aqueous | `Fe$+3:3 H:-4` | Keep | Documented Fe(III) polynuclear hydrolysis complexes are retained as distinct competitors. |
| aqueous | `Fe$+6:1 H:-8` | Drop | Fe(VI) is outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `L1:1` | Keep | Citrate acid-base species are required for the 5 mM citrate pH sweep. |
| aqueous | `L1:1 H:1` | Keep | Citrate acid-base species are required for the 5 mM citrate pH sweep. |
| aqueous | `L1:1 H:2` | Keep | Citrate acid-base species are required for the 5 mM citrate pH sweep. |
| aqueous | `L1:1 H:3` | Keep | Citrate acid-base species are required for the 5 mM citrate pH sweep. |
| solid | `Fe$+0:1` | Drop | Elemental Fe is outside the Fe(III)-citrate solubility question. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Drop | Magnetite is a mixed-valence oxide branch outside the stated Fe(III) precipitate question. |
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    525.55
- elapsed_s (total):  525.55
- llm_iterations:     56
- llm_tool_calls:     50

- n_groups:           28
- n_multi_groups:     8
- n_singletons:       20
- n_decisions:        28
- n_dropped:          24
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe(II) is out of scope for the Fe(III)-citrate calculation, but the group cannot be emptied, so the SRD-46 spelling is retained over the duplicate Atlas spelling. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Although this Fe(II) aqueous hydrolysis state is outside the Fe(III)-citrate scope, the group cannot be emptied, so the SRD-46 spelling [Fe(OH)3]- is retained over the Atlas duplicate notation [HFeO2]-. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ and [Fe]3+ represent the same mononuclear aqueous Fe(III) ion, so the SRD-46 row is preferred over the duplicate Atlas spelling. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | [FeOH]2+ is an Atlas duplicate spelling of the SRD-46 mononuclear Fe(III) hydrolysis species, while [Fe2(OH)2]4+ is a distinct polynuclear Fe(III) hydrolysis complex relevant at 1 mM Fe. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | The SRD-46 row is the preferred representation of the same mononuclear aqueous Fe(III) hydrolysis state duplicated by the Atlas spelling/source. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Keep both SRD-46 Fe(III)-citrate hydroxo complexes because mononuclear and documented polynuclear species are distinct competitors in the 1 mM Fe/5 mM citrate pH sweep. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Fe(OH)2 solids are out of scope for the Fe(III)-citrate calculation, but because the group cannot be emptied, the SRD-46 hydrated Fe(OH)2 solid is retained over the Atlas duplicate. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Keep the SRD-46 hydrous Fe(OH)3(s) operational precipitate for the Fe(III)-citrate pH sweep, excluding aged/crystalline FeOOH/Fe2O3 branches and the duplicate Atlas hydrate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | This neutral non-Fe singleton is not identified as an excluded redox or solid branch, so it is retained by the default keep rule. |
| aqueous | `Fe$+2:1 H:-1` | NO | This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 H:-2` | NO | This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 H:-4` | NO | This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `Fe$+2:1 L1:1` | NO | This is an Fe(II)-citrate complex, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | NO | This polynuclear citrate/hydroxo complex belongs to the Fe(II) branch by its core label and is outside the Fe(III)-only redox scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | This is an Fe(II)-citrate protonation species, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| aqueous | `Fe$+2:1 L1:1 H:2` | NO | This is an Fe(II)-citrate protonation species, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| aqueous | `Fe$+2:1 L1:2 H:1` | NO | This is an Fe(II)-citrate complex, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| aqueous | `Fe$+3:1 H:-4` | yes | This is an Fe(III) hydrolysis species relevant to the pH sweep and should be retained. |
| aqueous | `Fe$+3:1 L1:1` | yes | This is an Fe(III)-citrate complex relevant to the stated Fe(III)-citrate speciation calculation. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | This is a protonated Fe(III)-citrate species relevant to the stated pH-dependent citrate speciation calculation. |
| aqueous | `Fe$+3:3 H:-4` | yes | This documented polynuclear Fe(III) hydrolysis species is explicitly retained as a distinct competitor at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | NO | This ferrate Fe(VI) species is outside the no-Eh Fe(III)-citrate solubility scope. |
| aqueous | `L1:1` | yes | Free citrate is part of the stated Fe+citrate aqueous system and is needed for ligand acid-base/speciation balance. |
| aqueous | `L1:1 H:1` | yes | This citrate protonation state is relevant over the pH 4-9 sweep and should be retained. |
| aqueous | `L1:1 H:2` | yes | This citrate protonation state is relevant over the pH 4-9 sweep and should be retained. |
| aqueous | `L1:1 H:3` | yes | Citric acid is part of the citrate acid-base family and should be retained for the pH sweep. |
| solid | `Fe$+0:1` | NO | Elemental Fe(0) is outside the no-Eh Fe(III)-citrate solubility question. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Magnetite is a mixed Fe(II)/Fe(III) oxide branch and is explicitly out of scope for this Fe(III)-citrate pH-sweep question. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe(II) is out of scope for the Fe(III)-citrate calculation, but the group cannot be emptied, so the SRD-46 spelling is retained over the duplicate Atlas spelling. |
| `[Fe]2+` | SRD-46 | aqueous | LC2 element review: supervisor override: Fe(II) aqueous ion is outside the no-Eh Fe(III)-citrate pH-sweep; it was retained only because the worker could not empty its duplicate group. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| `[Fe(OH)3]-` | SRD-46 | aqueous | LC2 element review: supervisor override: Fe(II) hydrolysis species [Fe(OH)3]- is outside the no-Eh Fe(III)-citrate pH-sweep; it was retained only because the worker could not empty its duplicate group. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Although this Fe(II) aqueous hydrolysis state is outside the Fe(III)-citrate scope, the group cannot be emptied, so the SRD-46 spelling [Fe(OH)3]- is retained over the Atlas duplicate notation [HFeO2]-. |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: This is an Fe(II) hydrolysis species, and Fe(II) branches are outside the no-Eh Fe(III)-citrate solubility scope. |
| `[Fe(Citr)H2]+` | SRD-46 | aqueous | LC2 element review: This is an Fe(II)-citrate protonation species, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| `[Fe(Citr)H]` | SRD-46 | aqueous | LC2 element review: This is an Fe(II)-citrate protonation species, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| `[Fe(Citr)2H]3-` | SRD-46 | aqueous | LC2 element review: This is an Fe(II)-citrate complex, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| `[Fe(Citr)]-` | SRD-46 | aqueous | LC2 element review: This is an Fe(II)-citrate complex, and Fe(II) branches are outside the requested Fe(III)-citrate calculation. |
| `[Fe2(Citr)2(OH)2]4-` | SRD-46 | aqueous | LC2 element review: This polynuclear citrate/hydroxo complex belongs to the Fe(II) branch by its core label and is outside the Fe(III)-only redox scope. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ and [Fe]3+ represent the same mononuclear aqueous Fe(III) ion, so the SRD-46 row is preferred over the duplicate Atlas spelling. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: [FeOH]2+ is an Atlas duplicate spelling of the SRD-46 mononuclear Fe(III) hydrolysis species, while [Fe2(OH)2]4+ is a distinct polynuclear Fe(III) hydrolysis complex relevant at 1 mM Fe. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: The SRD-46 row is the preferred representation of the same mononuclear aqueous Fe(III) hydrolysis state duplicated by the Atlas spelling/source. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: This ferrate Fe(VI) species is outside the no-Eh Fe(III)-citrate solubility scope. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Fe(OH)2 solids are out of scope for the Fe(III)-citrate calculation, but because the group cannot be emptied, the SRD-46 hydrated Fe(OH)2 solid is retained over the Atlas duplicate. |
| `[Fe(OH)2](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Fe(OH)2(s) is an Fe(II) solid and is outside the no-Eh Fe(III)-citrate pH-sweep; only hydrous Fe(OH)3(s) should remain as the operational precipitate phase. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Magnetite is a mixed Fe(II)/Fe(III) oxide branch and is explicitly out of scope for this Fe(III)-citrate pH-sweep question. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Keep the SRD-46 hydrous Fe(OH)3(s) operational precipitate for the Fe(III)-citrate pH sweep, excluding aged/crystalline FeOOH/Fe2O3 branches and the duplicate Atlas hydrate. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Keep the SRD-46 hydrous Fe(OH)3(s) operational precipitate for the Fe(III)-citrate pH sweep, excluding aged/crystalline FeOOH/Fe2O3 branches and the duplicate Atlas hydrate. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep the SRD-46 hydrous Fe(OH)3(s) operational precipitate for the Fe(III)-citrate pH sweep, excluding aged/crystalline FeOOH/Fe2O3 branches and the duplicate Atlas hydrate. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep the SRD-46 hydrous Fe(OH)3(s) operational precipitate for the Fe(III)-citrate pH sweep, excluding aged/crystalline FeOOH/Fe2O3 branches and the duplicate Atlas hydrate. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe(0) is outside the no-Eh Fe(III)-citrate solubility question. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 0d55d01cf26f4a2ab58b98fd3642ae11
- review_turns: 4
- full_restarts: 0
- targeted_reruns: 0
- summary: Committed the deduplicated Fe(III)-citrate pH-sweep table. The retained set includes SRD-46 Fe(III) hydrolysis species, Fe(III)-citrate protonation/hydroxo complexes including documented polynuclear competitors, citrate acid-base species, and hydrous Fe(OH)3(s) as the operational precipitate. Fe(II), Fe(0), Fe(VI), mixed-valence magnetite, Fe(OH)2(s), Fe2O3, and FeOOH/aged oxide branches are excluded as outside the no-Eh Fe(III)-citrate solubility question.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (14/14)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

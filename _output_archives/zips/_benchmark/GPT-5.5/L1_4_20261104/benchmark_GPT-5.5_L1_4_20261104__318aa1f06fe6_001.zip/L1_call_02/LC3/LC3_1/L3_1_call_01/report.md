# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.29
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Purpose explicitly requests a 1-D speciation and solubility pH sweep.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_4_20261104\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
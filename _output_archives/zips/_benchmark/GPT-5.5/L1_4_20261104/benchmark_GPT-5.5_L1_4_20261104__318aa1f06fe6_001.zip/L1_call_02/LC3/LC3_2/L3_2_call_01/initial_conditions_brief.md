# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # Task states temperature 25 C.
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # Task states ionic strength I = 0.1 mol/L.
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "known"},  # Task specifies a separate solution containing Fe(III) only.
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "known"},  # Task specifies Fe(III) only; zero other Fe valence totals declared for excluded-redox balance closure.
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # Task states total Fe(III) = 1 mM.
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "known"},  # Task specifies Fe(III) only; zero other Fe valence totals declared for excluded-redox balance closure.
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.005, "basis": "known"},  # Task states total citrate = 5 mM.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the selected 1D sweep axis over the task-stated range 4 to 9.'},
]

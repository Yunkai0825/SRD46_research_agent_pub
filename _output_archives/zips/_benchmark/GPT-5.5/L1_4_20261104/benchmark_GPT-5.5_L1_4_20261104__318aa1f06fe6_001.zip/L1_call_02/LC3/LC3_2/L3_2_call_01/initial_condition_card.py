inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states temperature 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength I = 0.1 mol/L."},
  {"id": "FeII", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0, "basis": "known", "note": "Task specifies a separate solution containing Fe(III) only."},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"], "value": 0.0, "basis": "known", "note": "Task specifies Fe(III) only; zero other Fe valence totals declared for excluded-redox balance closure."},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 0.001, "basis": "known", "note": "Task states total Fe(III) = 1 mM."},
  {"id": "FeVI", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0, "basis": "known", "note": "Task specifies Fe(III) only; zero other Fe valence totals declared for excluded-redox balance closure."},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 0.005, "basis": "known", "note": "Task states total citrate = 5 mM."},
]
## Doability
Doable: Fe(III)–citrate pH speciation at 25.0 °C and target I = 0.1 M is within the supported `pH_sweep` route; redox was excluded, so this is fixed-oxidation-state Fe(III) chemistry only.

## Result
Computed a 1D pH sweep for total Fe(III) = 1.00e-3 M and total citrate = 5.00e-3 M over pH 4.0–9.0 at 25.0 °C. The solver reports 251/251 converged pH points. The state-metrics table confirms fixed target ionic strength 1.000000e-01 M, while the calculated ionic strength from explicitly modelled solutes spans 0.00672425–0.0224987 M; no inert ions were added. Redox mode was excluded.

## Analysis
Citrate strongly buffers Fe(III) against immediate hydrolysis/precipitation through the mildly acidic range. The included thermodynamic table shows large cumulative Fe(III)–citrate formation constants for aqueous complexes, including [Fe(Citr)H]+ with log_beta = +12.3500, [Fe(Citr)] with log_beta = +11.1900, [Fe(Citr)(OH)]- with log_beta = +8.4900, and the dimeric hydroxo-citrate [Fe2(Citr)2(OH)2]2- with log_beta = +21.2000. Against this, Fe(OH)3(s) is present as an included solid with log_beta = -3.2000 on the card convention.

Dominant Fe-containing species from the verdict:
- pH 4.0–6.1: [Fe2(Citr)2(OH)2]2- is the dominant Fe(III) carrier.
- pH 6.1–9.0: [Fe(OH)3](s) is dominant.

The calculated Fe profile is therefore not free Fe3+ hydrolysis in solution; citrate holds Fe as hydroxo-citrate complexes until increasing alkalinity makes ferric hydroxide precipitation thermodynamically favorable. The dimeric [Fe2(Citr)2(OH)2]2- reaches an Fe-fraction peak of 87.3% at pH 6.0, while [Fe(Citr)(OH)]- peaks at 12.7% at pH 6.0. These two aqueous hydroxo-citrate forms account for the soluble Fe just before precipitation begins.

Fe(OH)3(s) appears in the precipitation report at pH 6.06 with 1.06e-04 M solid. The verdict gives two Fe crossover points: [Fe(Citr)(OH)]- ↔ [Fe(OH)3](s) at pH ≈ 6.06, each about 12%, and [Fe2(Citr)2(OH)2]2- ↔ [Fe(OH)3](s) at pH ≈ 6.14, each about 45%. Following the pH-sweep reading rule, these are grid-based crossover/onset results rather than an independently interpolated solubility boundary.

For soluble versus precipitated Fe: below the reported precipitation onset, Fe is calculated as soluble Fe–citrate/hydroxo-citrate species, with the concentration table showing zero [Fe(OH)3](s) at the acidic grid points inspected, e.g. pH 4.0000–5.8400. At and above the onset, Fe progressively transfers to the solid phase; [Fe(OH)3](s) becomes the dominant Fe reservoir after the ~6.14 crossover and reaches a reported peak of 100.0% at pH 8.9. Thus citrate delays ferric hydroxide formation into the near-neutral range but does not keep 1 mM Fe(III) fully soluble through alkaline pH under these totals.

Practical interpretation: at 5 mM citrate, a fivefold ligand excess is enough to complex Fe(III) through pH 4–about 6, dominated by a hydroxo-bridged Fe(III)–citrate dimer. As pH rises, ligand deprotonation and hydrolysis both increase, but Fe(OH)3(s) becomes the lower-solubility sink; once precipitation starts near pH 6.06, citrate no longer prevents ferric hydroxide from taking over. There is no later alkaline redissolution in this pH 4–9 fixed-Fe(III) run; instead Fe(OH)3(s) remains dominant to pH 9.

## Artifacts
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv`
- `L1_call_02/thermodynamic_reference_constants.md`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
[Purpose: Compare how citrate buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.]
[Tasks:
Run a 1D pH sweep for a separate solution containing Fe(III) and citrate only: total Fe = 1 mM, total citrate = 5 mM, temperature 25 C, ionic strength I = 0.1, pH range 4 to 9. Report dominant Fe-containing species as a function of pH, soluble versus precipitated Fe, and specifically the pH interval, if any, where Fe(OH)3(s) appears or reappears.
]
[Pair: pair_key=`m61_l9058`, metal_id=61, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand9058_beta966_net22162`
  - `metal61_ligand9058_beta424_net22162`
  - `metal61_ligand9058_beta779_net22162`
[Screen report]
# Eq-map screen — m61_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand9058_beta966_net22162` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_157688@(25.0,0.1) = K+2.700 | 1 | +2.700 / +2.700 / +2.700 / +2.700 | vlm_157688@(25.0,0.1) = K+2.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal61_ligand9058_beta424_net22162` | `[M]^2 + [L]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_157689@(20.0,0.1) = K+21.200 | 1 | +21.200 / +21.200 / +21.200 / +21.200 | vlm_157689@(20.0,0.1) = K+21.200 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal61_ligand9058_beta812_net22162` | `[M] + [L] <=> [ML]` | vlm_157682@(25.0,0.1) = K+11.190 | 3 | +10.250 / +11.190 / +10.903 / +11.270 | vlm_157682@(25.0,0.1) = K+11.190 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal61_ligand9058_beta779_net22162` | `[M] + [HL] <=> [MHL]` | vlm_157687@(25.0,0.1) = K+6.700 | 1 | +6.700 / +6.700 / +6.700 / +6.700 | vlm_157687@(25.0,0.1) = K+6.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

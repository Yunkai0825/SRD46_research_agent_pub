[Purpose: Compare how citrate buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.]
[Tasks:
Run a 1D pH sweep for a separate solution containing Fe(III) and citrate only: total Fe = 1 mM, total citrate = 5 mM, temperature 25 C, ionic strength I = 0.1, pH range 4 to 9. Report dominant Fe-containing species as a function of pH, soluble versus precipitated Fe, and specifically the pH interval, if any, where Fe(OH)3(s) appears or reappears.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

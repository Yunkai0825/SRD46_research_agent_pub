## Answer

EDTA is the stronger Fe(III) buffer in this comparison. At 1 mM total Fe and 5 mM ligand, EDTA keeps Fe(III) soluble across the full pH 4–9 sweep, with no reappearance of Fe(OH)₃(s) in the sampled range. Chemically, this reflects the very high stability of Fe(III)–EDTA complexes: EDTA outcompetes hydroxide and suppresses ferric hydroxide precipitation even as pH rises.

Citrate also complexes Fe(III) and improves solubility in acidic to mildly neutral solution, but it is a weaker multidentate ligand than EDTA under these conditions. As pH increases, hydrolysis and ferric hydroxide formation eventually overcome citrate complexation, so Fe(OH)₃(s) reappears within the pH 4–9 range. Thus citrate buffers Fe(III) solubility over a narrower pH window than EDTA.

**Conclusion:** EDTA keeps Fe(III) soluble over the widest pH range; Fe(OH)₃(s) reappears for the citrate system but not for the EDTA system over pH 4–9.

## Evidence

- EDTA calculation completed successfully as a pH sweep for Fe(III) + EDTA at 25 °C and I = 0.1, with outputs in `L1_call_01/solver`.
- Citrate calculation completed successfully as a pH sweep for Fe(III) + citrate at 25 °C and I = 0.1, with outputs in `L1_call_02/solver`.
- The EDTA run includes the deterministic verdict file:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md`
- The citrate run includes the deterministic verdict file:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md`
- Both validation reviews were marked `supported`.

## Artifacts

- EDTA Fe fraction plot:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png`
- EDTA Fe phase-balance plot:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png`
- EDTA metal fraction CSV:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv`
- EDTA concentrations CSV:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv`
- EDTA convergence/state metrics:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv`

- Citrate Fe fraction plot:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png`
- Citrate Fe phase-balance plot:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
- Citrate metal fraction CSV:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv`
- Citrate concentrations CSV:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv`
- Citrate convergence/state metrics:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv`
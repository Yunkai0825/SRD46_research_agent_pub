inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states temperature 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states ionic strength I = 0.1."},
  {"id": "FeII", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0, "basis": "assumed", "note": "Fe is specified as Fe(III) only; redox excluded, so Fe(II) subtotal is explicitly zero."},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"], "value": 0.0, "basis": "assumed", "note": "Fe is specified as Fe(III) only; redox excluded, so Fe(0) subtotal is explicitly zero."},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 0.001, "basis": "known", "note": "Task states total Fe(III) = 1 mM."},
  {"id": "FeVI", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0, "basis": "assumed", "note": "Fe is specified as Fe(III) only; redox excluded, so Fe(VI) subtotal is explicitly zero."},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 0.005, "basis": "known", "note": "Task states total EDTA = 5 mM."},
]
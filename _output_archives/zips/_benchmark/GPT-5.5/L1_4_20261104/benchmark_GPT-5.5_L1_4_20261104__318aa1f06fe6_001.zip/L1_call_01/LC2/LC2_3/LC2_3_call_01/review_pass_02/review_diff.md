# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | Fe(II) is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) representative should be retained. |

Singleton decisions:

| phase | core_label | keep | rationale |
|---|---:|:---:|---|
| aqueous | `(empty)` | true | Kept as a neutral aqueous reference/placeholder species with no case-specific exclusion. |
| aqueous | `Fe$+2:1 H:-1` | false | Dropped because Fe(II) hydrolysis species are outside the non-redox Fe(III)-EDTA calculation scope. |
| aqueous | `Fe$+2:1 H:-2` | false | Dropped because Fe(II) hydrolysis species are outside the non-redox Fe(III)-EDTA calculation scope. |
| aqueous | `Fe$+2:1 H:-4` | false | Dropped because Fe(II) hydrolysis species are outside the non-redox Fe(III)-EDTA calculation scope. |
| aqueous | `Fe$+2:1 L1:1` | false | Dropped because Fe(II)-EDTA complexes are outside the specified Fe(III)-EDTA redox scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | false | Dropped because protonated Fe(II)-EDTA complexes are outside the specified Fe(III)-EDTA redox scope. |
| aqueous | `Fe$+3:1 H:-4` | true | Kept as a genuine Fe(III) hydrolysis species relevant to the pH sweep. |
| aqueous | `Fe$+3:1 L1:1` | true | Kept as a primary Fe(III)-EDTA complex relevant to the calculation. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | true | Kept as a distinct hydroxo Fe(III)-EDTA complex. |
| aqueous | `Fe$+3:1 L1:1 H:1` | true | Kept as a distinct protonated Fe(III)-EDTA complex. |
| aqueous | `Fe$+3:3 H:-4` | true | Kept as a genuine polynuclear Fe(III) hydrolysis species. |
| aqueous | `Fe$+6:1 H:-8` | false | Dropped because Fe(VI) ferrate is outside the non-redox Fe(III)-EDTA scope. |
| aqueous | `L1:1` | true | Kept as the fully deprotonated EDTA ligand form needed for ligand acid-base speciation. |
| aqueous | `L1:1 H:1` | true | Kept as a distinct protonated EDTA ligand form. |
| aqueous | `L1:1 H:2` | true | Kept as a distinct protonated EDTA ligand form. |
| aqueous | `L1:1 H:3` | true | Kept as a distinct protonated EDTA ligand form. |
| aqueous | `L1:1 H:4` | true | Kept as a distinct protonated EDTA ligand form. |
| aqueous | `L1:1 H:5` | true | Kept as a distinct protonated EDTA ligand form. |
| aqueous | `L1:1 H:6` | true | Kept as a distinct protonated EDTA ligand form. |
| solid | `Fe$+0:1` | false | Dropped because elemental Fe is outside scope and has no imposed redox equilibrium or reference constraint. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | false | Dropped because mixed-valence magnetite is outside the non-redox Fe(III)-EDTA precipitation question. |
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(OH)2(s) is an Fe(II) precipitate and is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) solid representative should be retained. |

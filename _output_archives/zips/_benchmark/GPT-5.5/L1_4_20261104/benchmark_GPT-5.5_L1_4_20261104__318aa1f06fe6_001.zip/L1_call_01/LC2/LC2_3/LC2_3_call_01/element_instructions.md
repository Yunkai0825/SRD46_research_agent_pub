# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: treat this as a non-redox Fe(III)-EDTA pH-sweep speciation and solubility calculation, not a corrosion/Potential-pH Pourbaix calculation; the question is whether Fe remains EDTA-buffered in solution or precipitates as Fe(OH)3(s).
- Concentration/context: use the stated analytical concentrations, total Fe = 1 mM and total EDTA = 5 mM at 25 °C and I = 0.1; the 1e-6 M corrosion convention is not applicable.
- Aqueous identity: EDTA complexation and Fe(III) hydrolysis govern speciation. Keep genuinely distinct protonated, hydroxo, EDTA-bound, and polynuclear Fe(III) species where stoichiometry/multiplier shows distinct complexes; collapse only alternative spellings of the same aqueous ion.
- Source preference: where two rows are the same physical aqueous state, prefer SRD-46 over Atlas because the EDTA equilibria are from SRD-46 and should remain internally consistent.
- Solids/hydration: the requested precipitate is freshly formed hydrous/amorphous Fe(OH)3(s); do not let aged crystalline Fe2O3 or FeO(OH) phases redefine the question as long-term oxide stability. Collapse duplicate Fe(OH)3(s) descriptions to the SRD-46 hydrous hydroxide when present.
- Carbonates/counterions: no carbonate, phosphate, background-metal, or other counterion precipitates are in scope for this Fe(III)-EDTA-only solution.
- Redox scope: no pe/Eh or reductant/oxidant is specified, so Fe(0), Fe(II), mixed-valence magnetite, and Fe(VI) ferrate branches are out of scope rather than competitors.
- Phase question: answer which Fe species dominate and whether Fe(OH)3(s) forms/reappears during the pH sweep, not which crystalline iron oxide is the global thermodynamic ground state after aging.
- Elemental/gas references: elemental Fe and gases have no imposed equilibrium or fugacity constraint in this calculation and should not be retained as decorative references.

## Element instructions

- **Fe**: Keep Fe(III) aqueous EDTA complexes, Fe(III) hydrolysis species, and genuine Fe(III) polynuclear hydrolysis species as distinct competitors for the 1 mM Fe / 5 mM EDTA pH sweep; collapse notation-only duplicates, preferring SRD-46 for the same physical state. Prune out-of-scope Fe(0), Fe(II), Fe(VI), magnetite, Fe(OH)2(s), anhydrous/crystalline Fe2O3, and FeO(OH), while retaining only the fresh hydrous Fe(OH)3(s) precipitate target, preferably the SRD-46 entry when duplicated.

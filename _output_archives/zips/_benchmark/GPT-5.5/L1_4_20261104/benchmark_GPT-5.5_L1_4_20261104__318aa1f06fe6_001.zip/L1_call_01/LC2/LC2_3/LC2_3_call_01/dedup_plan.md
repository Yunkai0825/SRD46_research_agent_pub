# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: treat this as a non-redox Fe(III)-EDTA pH-sweep speciation and solubility calculation, not a corrosion/Potential-pH Pourbaix calculation; the question is whether Fe remains EDTA-buffered in solution or precipitates as Fe(OH)3(s).
- Concentration/context: use the stated analytical concentrations, total Fe = 1 mM and total EDTA = 5 mM at 25 °C and I = 0.1; the 1e-6 M corrosion convention is not applicable.
- Aqueous identity: EDTA complexation and Fe(III) hydrolysis govern speciation. Keep genuinely distinct protonated, hydroxo, EDTA-bound, and polynuclear Fe(III) species where stoichiometry/multiplier shows distinct complexes; collapse only alternative spellings of the same aqueous ion.
- Source preference: where two rows are the same physical aqueous state, prefer SRD-46 over Atlas because the EDTA equilibria are from SRD-46 and should remain internally consistent.
- Solids/hydration: the requested precipitate is freshly formed hydrous/amorphous Fe(OH)3(s); do not let aged crystalline Fe2O3 or FeO(OH) phases redefine the question as long-term oxide stability. Collapse duplicate Fe(OH)3(s) descriptions to the SRD-46 hydrous hydroxide when present.
- Carbonates/counterions: no carbonate, phosphate, background-metal, or other counterion precipitates are in scope for this Fe(III)-EDTA-only solution.
- Redox scope: no pe/Eh or reductant/oxidant is specified, so Fe(0), Fe(II), mixed-valence magnetite, and Fe(VI) ferrate branches are out of scope rather than competitors.
- Phase question: answer which Fe species dominate and whether Fe(OH)3(s) forms/reappears during the pH sweep, not which crystalline iron oxide is the global thermodynamic ground state after aging.
- Elemental/gas references: elemental Fe and gases have no imposed equilibrium or fugacity constraint in this calculation and should not be retained as decorative references.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — The two rows represent the same out-of-scope aqueous Fe(II) ion, but the group cannot be emptied, so retain the SRD-46 notation-only duplicate by source preference. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — The two rows represent the same out-of-scope aqueous Fe(II) ion, but the group cannot be emptied, so retain the SRD-46 notation-only duplicate by source preference.<br>review 1: dropped — Fe(II) is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) representative should be retained. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — This is an Fe(II) hydrolysis species, and Fe(II) branches are out of scope for the non-redox Fe(III)-EDTA calculation. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — This is an Fe(II) hydrolysis species, and Fe(II) branches are out of scope for the non-redox Fe(III)-EDTA calculation. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both rows are Fe(II) aqueous hydrolysis notation variants outside the Fe(III)-EDTA scope, but the group must retain one representative, so the SRD-46 entry is preferred over the Atlas entry. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both rows are Fe(II) aqueous hydrolysis notation variants outside the Fe(III)-EDTA scope, but the group must retain one representative, so the SRD-46 entry is preferred over the Atlas entry.<br>review 2: dropped — Fe(II) hydrolysis species is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) representative should be retained. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — This is an Fe(II) hydrolysis species, and Fe(II) branches are out of scope for the non-redox Fe(III)-EDTA calculation. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — This is an Fe(II)-EDTA complex, and Fe(II) branches are out of scope for the non-redox Fe(III)-EDTA calculation. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — This is a protonated Fe(II)-EDTA complex, and Fe(II) branches are out of scope for the non-redox Fe(III)-EDTA calculation. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Fe(III) ion, so the notation-only duplicate is collapsed in favor of the SRD-46 entry for consistency with the Fe(III)-EDTA speciation data. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Fe(III) ion, so the notation-only duplicate is collapsed in favor of the SRD-46 entry for consistency with the Fe(III)-EDTA speciation data. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Keep the SRD-46 mononuclear Fe(III) hydrolysis ion over the Atlas notation duplicate, and retain the SRD-46 dinuclear hydrolysis species as a genuinely distinct polynuclear competitor. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) hydrolysis ion over the Atlas notation duplicate, and retain the SRD-46 dinuclear hydrolysis species as a genuinely distinct polynuclear competitor. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) hydrolysis ion over the Atlas notation duplicate, and retain the SRD-46 dinuclear hydrolysis species as a genuinely distinct polynuclear competitor. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — The two rows represent the same Fe(III) dihydroxo aqueous ion, so the SRD-46 entry is retained for internal consistency and the Atlas duplicate is dropped. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — The two rows represent the same Fe(III) dihydroxo aqueous ion, so the SRD-46 entry is retained for internal consistency and the Atlas duplicate is dropped. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — This is a distinct Fe(III) hydrolysis species relevant to the Fe(III)-EDTA pH sweep. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — This is the principal Fe(III)-EDTA complex and is in scope for the speciation calculation. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — This is a distinct hydroxo Fe(III)-EDTA complex relevant to Fe(III)-EDTA speciation. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — This is a distinct protonated Fe(III)-EDTA complex relevant to Fe(III)-EDTA speciation. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — This is a genuine polynuclear Fe(III) hydrolysis species and should be retained as a distinct competitor. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — This ferrate species is Fe(VI), which is outside the non-redox Fe(III)-EDTA calculation scope. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe is out of scope because no redox or elemental reference equilibrium is imposed. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite is a mixed-valence Fe(II)/Fe(III) solid branch and is out of scope for the non-redox Fe(III)-EDTA precipitation question. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Fe(OH)2(s) is out of scope for the Fe(III)-EDTA pH sweep, but the group cannot be emptied, so the duplicate hydrous solid is represented by the preferred SRD-46 entry. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Fe(OH)2(s) is out of scope for the Fe(III)-EDTA pH sweep, but the group cannot be emptied, so the duplicate hydrous solid is represented by the preferred SRD-46 entry.<br>review 3: dropped — Fe(OH)2(s) is an Fe(II) precipitate and is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) solid representative should be retained. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — For this Fe(III)-EDTA pH sweep, retain the fresh hydrous Fe(OH)3(s) precipitate target from SRD-46 and drop aged crystalline Fe2O3/FeO(OH) phases plus the lower-preference Atlas duplicate. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — For this Fe(III)-EDTA pH sweep, retain the fresh hydrous Fe(OH)3(s) precipitate target from SRD-46 and drop aged crystalline Fe2O3/FeO(OH) phases plus the lower-preference Atlas duplicate. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — For this Fe(III)-EDTA pH sweep, retain the fresh hydrous Fe(OH)3(s) precipitate target from SRD-46 and drop aged crystalline Fe2O3/FeO(OH) phases plus the lower-preference Atlas duplicate. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — For this Fe(III)-EDTA pH sweep, retain the fresh hydrous Fe(OH)3(s) precipitate target from SRD-46 and drop aged crystalline Fe2O3/FeO(OH) phases plus the lower-preference Atlas duplicate. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — For this Fe(III)-EDTA pH sweep, retain the fresh hydrous Fe(OH)3(s) precipitate target from SRD-46 and drop aged crystalline Fe2O3/FeO(OH) phases plus the lower-preference Atlas duplicate. |
| — | `[?]` | SRD-46 | generation 1: kept — No case-specific instruction excludes this singleton aqueous reference, so it is retained by default. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA is required for ligand mass balance and pH-dependent Fe(III)-EDTA speciation. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — This protonation state of EDTA is relevant to the pH sweep and ligand mass balance. |

Finalized the deduplicated Fe(III)-EDTA speciation set.

Retained:
- Fe(III) aqueous hydrolysis species, including distinct polynuclear Fe(III) hydrolysis complexes.
- Fe(III)-EDTA complexes, including protonated and hydroxo forms.
- Free EDTA protonation states needed for ligand mass balance.
- The SRD-46 hydrous Fe(OH)3(s) precipitate target.

Excluded:
- Fe(II), Fe(0), Fe(VI), magnetite, Fe(OH)2(s), and other redox/out-of-scope branches.
- Aged crystalline Fe2O3 and FeO(OH) phases, since the task asks about fresh Fe(OH)3(s) precipitation/reappearance.
- Atlas notation duplicates where SRD-46 equivalents exist and are preferred for consistency with the EDTA equilibrium set.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | true | false | Fe(II) hydrolysis species is out of scope for the non-redox Fe(III)-EDTA pH sweep; no Fe(II) representative should be retained. |

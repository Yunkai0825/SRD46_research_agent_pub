## Doability
Doable: Fe(III), EDTA, Fe hydrolysis/EDTA complexes, and Fe(OH)3(s) are present in the SRD-46-derived card, and the requested calculation is a supported pH_sweep at 25.0 °C and target I = 0.1 M.

## Result
Computed a 1-D pH sweep for total Fe(III) = 1.00e-3 M and total EDTA = 5.00e-3 M over pH 4.0–9.0. Redox was excluded, so the result is fixed-oxidation-state Fe(III) speciation only. The solver converged at all 251/251 pH points. The report lists target ionic strength 0.1 M, with calculated ionic strength range 0.00870471–0.0295601 M and no inert ions added.

## Analysis
EDTA keeps Fe(III) overwhelmingly soluble and chelated throughout the requested pH window. The Fe(III) dominance ladder contains only EDTA-bound aqueous species: from pH 4.0–7.0 the dominant Fe species is [Fe(EDTA)]-, and from pH 7.0–9.0 it is [Fe(EDTA)(OH)]2-. The reported crossover is [Fe(EDTA)]- ↔ [Fe(EDTA)(OH)]2- at pH ≈ 6.96, with each species about 50% at the crossing.

The fraction maxima show why no free Fe(III) hydrolysis ladder controls the system: [Fe(EDTA)]- reaches 99.8% of Fe at pH 4.0, while [Fe(EDTA)(OH)]2- reaches 99.1% at pH 9.0. Thus, even though Fe(OH)3(s) is included in the thermodynamic card, Fe is sequestered by EDTA instead of building up enough uncomplexed/hydrolysed Fe(III) to precipitate. Chemically, increasing pH deprotonates EDTA and also increases hydroxide activity; the Fe–EDTA complex therefore converts from the non-hydroxo chelate to a hydroxo-EDTA complex rather than releasing Fe(III) to form ferric hydroxide solid.

The ligand distribution also supports this interpretation. EDTA is in fivefold excess over Fe: 5.00e-3 M EDTA versus 1.00e-3 M Fe. The verdict reports EDTA-dominant ligand forms shifting from H2EDTA2- over pH 4.0–5.5, to HEDTA3- over pH 5.5–8.7, to EDTA over pH 8.7–9.0, while Fe-bound EDTA accounts for about the Fe-limited share of ligand: [Fe(EDTA)]- peaks at 20.0% of total ligand at pH 4.0 and [Fe(EDTA)(OH)]2- peaks at 19.8% at pH 9.0.

For precipitation, the full concentration table includes an explicit [Fe(OH)3](s) column. In the inspected concentration output, [Fe(OH)3](s) is 0.000000e+00 where shown, and the solver verdict reports no Fe(OH)3(s) dominance, peak, or precipitation interval over pH 4–9. Under these totals, there is therefore no pH interval in the computed sweep where Fe(OH)3(s) appears or reappears; Fe remains effectively soluble as Fe–EDTA complexes across the entire mildly acidic to alkaline range.

## Artifacts
L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md
L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv
L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv
L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv
L1_call_01/thermodynamic_reference_constants.md
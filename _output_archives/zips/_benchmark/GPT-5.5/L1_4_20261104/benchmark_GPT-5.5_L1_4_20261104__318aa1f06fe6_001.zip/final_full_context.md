## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compare how EDTA buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_Fe.json",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.png",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_ligand.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_Fe$+3.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_L1.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_run_params.json"
    ],
    "elapsed_s": 813.9
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Compare how citrate buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_02/solver/topology_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_Fe.json",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_L1.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_L1.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_log_conc.png",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_ligand.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_log_conc.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_envelope_Fe$+3.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_envelope_L1.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_run_params.json"
    ],
    "elapsed_s": 766.5
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compare how EDTA buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 2,
    "purpose": "Compare how citrate buffers Fe(III) speciation and solubility across mildly acidic to alkaline pH. The goal is a pH-sweep speciation analysis identifying dominant aqueous Fe species and any pH at which Fe(OH)3(s) becomes stable again under the stated total concentrations.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv",
      "L1_call_02/thermodynamic_reference_constants.md",
      "L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compare the buffering effect of EDTA versus citrate on the speciation of Fe(III) at pH 4-9, with 1 mM Fe total and 5 mM ligand, at 25 C and I=0.1. Which ligand keeps Fe(III) soluble over the widest pH range, and where does Fe(OH)3(s) reappear?

## Assistant
<summary>I will run two separate Fe(III) speciation sweeps because EDTA and citrate are being compared as separate ligand buffers, not mixed in the same solution. Each calculation will use 1 mM total Fe(III), 5 mM ligand, pH 4–9, 25 °C, and ionic strength 0.1, focusing on soluble Fe complexes versus Fe(OH)3(s) reappearance.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
**Parallel batch: 2 tools executed**

| # | Tool | Args | Chars | Note |
|---|------|------|------:|------|
| 1 | dispatch_l1_pipeline |  | 2859 | ### dispatch_l1_pipeline ## Doability Doable: Fe(III), EDTA, Fe hydrolysis/EDTA complexes, and Fe(OH)3(s) are present in the SRD-46-derived card, and the requested calculation is a supported pH_sweep… |
| 2 | dispatch_l1_pipeline |  | 3773 | ### dispatch_l1_pipeline ## Doability Doable: Fe(III)–citrate pH speciation at 25.0 °C and target I = 0.1 M is within the supported `pH_sweep` route; redox was excluded, so this is… |

*Use `inspect_batch_result(tool_number)` to read the full output of any tool above before proceeding.*

[WAIT BARRIER COMPLETE] 2 tool(s) finished (dispatch_l1_pipeline, dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

EDTA is the stronger Fe(III) buffer in this comparison. At 1 mM total Fe and 5 mM ligand, EDTA keeps Fe(III) soluble across the full pH 4–9 sweep, with no reappearance of Fe(OH)₃(s) in the sampled range. Chemically, this reflects the very high stability of Fe(III)–EDTA complexes: EDTA outcompetes hydroxide and suppresses ferric hydroxide precipitation even as pH rises.

Citrate also complexes Fe(III) and improves solubility in acidic to mildly neutral solution, but it is a weaker multidentate ligand than EDTA under these conditions. As pH increases, hydrolysis and ferric hydroxide formation eventually overcome citrate complexation, so Fe(OH)₃(s) reappears within the pH 4–9 range. Thus citrate buffers Fe(III) solubility over a narrower pH window than EDTA.

**Conclusion:** EDTA keeps Fe(III) soluble over the widest pH range; Fe(OH)₃(s) reappears for the citrate system but not for the EDTA system over pH 4–9.

## Evidence

- EDTA calculation completed successfully as a pH sweep for Fe(III) + EDTA at 25 °C and I = 0.1, with outputs in `L1_call_01/solver`.
- Citrate calculation completed successfully as a pH sweep for Fe(III) + citrate at 25 °C and I = 0.1, with outputs in `L1_call_02/solver`.
- The EDTA run includes the deterministic verdict file:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md`
- The citrate run includes the deterministic verdict file:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md`
- Both validation reviews were marked `supported`.

## Artifacts

- EDTA Fe fraction plot:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png`
- EDTA Fe phase-balance plot:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png`
- EDTA metal fraction CSV:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv`
- EDTA concentrations CSV:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv`
- EDTA convergence/state metrics:  
  `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv`

- Citrate Fe fraction plot:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png`
- Citrate Fe phase-balance plot:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
- Citrate metal fraction CSV:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv`
- Citrate concentrations CSV:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv`
- Citrate convergence/state metrics:  
  `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv`
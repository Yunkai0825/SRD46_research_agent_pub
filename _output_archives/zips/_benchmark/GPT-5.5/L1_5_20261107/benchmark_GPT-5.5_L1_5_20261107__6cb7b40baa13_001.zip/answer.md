## Answer

EDTA keeps free Cu²⁺ lower than NTA throughout the pH 3–10 range for the stated conditions: 1 mM total Cu, 5 mM ligand, 25 °C, and I = 0.1 m.

Chemically, this is expected because Cu(II)–EDTA is the stronger chelate system: EDTA is hexadentate and forms a very stable 1:1 Cu–EDTA complex, so even when EDTA becomes increasingly protonated at low pH, it still holds Cu more effectively than NTA. NTA is also a multidentate ligand, but its Cu(II) complex is less stabilizing than EDTA’s, so proton competition at acidic pH releases more Cu back into inorganic/free forms sooner.

At the low-pH end, both systems show acid-driven dissociation, but NTA begins to lose Cu complexation more strongly and at higher pH than EDTA. EDTA remains the better Cu²⁺ buffer across the whole sweep; NTA allows a larger free Cu²⁺ fraction under acidic conditions.

## Evidence

- The completed calculations are:
  - EDTA case: `L1_call_01`, pH-sweep output directory `L1_call_01/solver`
  - NTA case: `L1_call_02`, pH-sweep output directory `L1_call_02/solver`
- Both runs completed successfully and were validated as supported.
- EDTA run artifacts include the deterministic verdict, metal-fraction table, concentration table, state-metrics table, and plots.
- NTA run artifacts include the same corresponding files for direct comparison.
- The working-memory summary indicates both runs used pH 3–10, 25 °C, fixed ionic mode, and no redox sweep.

## Artifacts

- EDTA verdict: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- EDTA Cu fraction CSV: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- EDTA concentrations CSV: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv`
- EDTA convergence/state metrics: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- EDTA Cu speciation plot: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- EDTA log concentration plot: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png`

- NTA verdict: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md`
- NTA Cu fraction CSV: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv`
- NTA concentrations CSV: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_concentrations.csv`
- NTA convergence/state metrics: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv`
- NTA Cu speciation plot: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png`
- NTA log concentration plot: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png`
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # Task states 25 C.
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # Task states fixed ionic strength I=0.1 m.
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # Task states total Cu(II) = 1 mM.
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # Redox is excluded for this pH sweep; initial reduced Cu is set to zero.
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Single Cu(II) solution; metallic Cu subtotal set to zero under excluded redox.
  {"lhs": lambda s: s.total["ligand_6165"], "rhs": 0.005, "basis": "known"},  # Task states total NTA = 5 mM.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1D sweep coordinate from 3 to 10 specified by the task.'},
]

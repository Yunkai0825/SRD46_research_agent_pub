inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task states 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task states fixed ionic strength I=0.1 m."},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "Task states total Cu(II) = 1 mM."},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "Redox is excluded for this pH sweep; initial reduced Cu is set to zero."},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "Single Cu(II) solution; metallic Cu subtotal set to zero under excluded redox."},
  {"id": "NTA", "lhs": lambda s: s.total["ligand_6165"], "value": 5e-3, "basis": "known", "note": "Task states total NTA = 5 mM."},
]
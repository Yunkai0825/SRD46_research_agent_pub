# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as an aqueous ligand-control speciation calculation for Cu(II)-NTA, not a corrosion, electrodeposition, Pourbaix, battery, or redox-stability problem.
- Use the stated analytical regime as governing context: total Cu = 1 mM, total NTA = 5 mM, pH 3–10, 25 °C, I = 0.1 m. The 1e-6 M corrosion convention is not applicable.
- Keep distinct aqueous Cu(II) protonation, hydrolysis, polynuclear hydrolysis, and NTA-bound complexes because at millimolar Cu they can represent different mass-balance/speciation states across the pH sweep, even when their normalized Cu:H core looks similar.
- Collapse only exact duplicate descriptions of the same aqueous state, especially alternative spellings of simple free ions; prefer SRD-46 over Atlas when the state is otherwise identical because the NTA complex set is SRD-based.
- Exclude redox branches: the calculation fixes Cu as Cu(II) in a non-redox solution model, with no imposed pe/Eh or electron balance, so Cu(I), Cu(0), and cuprous oxide chemistry are out of scope.
- Exclude solid phases for this requested output: the task asks for dissolved Cu2+ suppression and dominant dissolved Cu-bearing species in a single analytical solution, not precipitation/solubility or hydrate/anhydrous solid competition.
- Carbonates, counterion solids, gases, and elemental reference phases have no role in this NTA-only fixed-composition aqueous sweep unless explicitly present in the source inventory; do not add or preserve them decoratively.
- The phase question is dissolved equilibrium speciation, not which crystalline polymorph forms; polymorph/hydration distinctions among solids should not be allowed to affect this calculation.

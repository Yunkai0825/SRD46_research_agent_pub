# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as an aqueous ligand-control speciation calculation for Cu(II)-NTA, not a corrosion, electrodeposition, Pourbaix, battery, or redox-stability problem.
- Use the stated analytical regime as governing context: total Cu = 1 mM, total NTA = 5 mM, pH 3–10, 25 °C, I = 0.1 m. The 1e-6 M corrosion convention is not applicable.
- Keep distinct aqueous Cu(II) protonation, hydrolysis, polynuclear hydrolysis, and NTA-bound complexes because at millimolar Cu they can represent different mass-balance/speciation states across the pH sweep, even when their normalized Cu:H core looks similar.
- Collapse only exact duplicate descriptions of the same aqueous state, especially alternative spellings of simple free ions; prefer SRD-46 over Atlas when the state is otherwise identical because the NTA complex set is SRD-based.
- Exclude redox branches: the calculation fixes Cu as Cu(II) in a non-redox solution model, with no imposed pe/Eh or electron balance, so Cu(I), Cu(0), and cuprous oxide chemistry are out of scope.
- Exclude solid phases for this requested output: the task asks for dissolved Cu2+ suppression and dominant dissolved Cu-bearing species in a single analytical solution, not precipitation/solubility or hydrate/anhydrous solid competition.
- Carbonates, counterion solids, gases, and elemental reference phases have no role in this NTA-only fixed-composition aqueous sweep unless explicitly present in the source inventory; do not add or preserve them decoratively.
- The phase question is dissolved equilibrium speciation, not which crystalline polymorph forms; polymorph/hydration distinctions among solids should not be allowed to affect this calculation.

## Element instructions

- **Cu**: Keep aqueous Cu(II) free ion, hydrolysis species including polynuclear hydroxo complexes, and all Cu-NTA complexes as distinct competitors, except collapse exact notation duplicates of the same aqueous ion and prefer the SRD-46 entry. Treat Cu(I), elemental Cu, cuprous/cupric oxides, and Cu hydroxide solids as out of scope for this non-redox aqueous Cu(II)-NTA mass-balance calculation.

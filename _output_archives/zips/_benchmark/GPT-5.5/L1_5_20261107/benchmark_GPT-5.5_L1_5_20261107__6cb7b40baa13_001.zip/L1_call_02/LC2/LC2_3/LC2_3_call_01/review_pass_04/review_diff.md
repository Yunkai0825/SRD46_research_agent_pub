# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu2O(s) is a solid Cu(I) redox/precipitation branch and is out of scope for the fixed-composition, non-redox dissolved Cu(II)-NTA pH speciation calculation. |

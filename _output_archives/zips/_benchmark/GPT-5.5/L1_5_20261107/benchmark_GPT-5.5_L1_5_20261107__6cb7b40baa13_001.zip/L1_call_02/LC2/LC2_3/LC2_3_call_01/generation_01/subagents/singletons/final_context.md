## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as an aqueous ligand-control speciation calculation for Cu(II)-NTA, not a corrosion, electrodeposition, Pourbaix, battery, or redox-stability problem.
- Use the stated analytical regime as governing context: total Cu = 1 mM, total NTA = 5 mM, pH 3–10, 25 °C, I = 0.1 m. The 1e-6 M corrosion convention is not applicable.
- Keep distinct aqueous Cu(II) protonation, hydrolysis, polynuclear hydrolysis, and NTA-bound complexes because at millimolar Cu they can represent different mass-balance/speciation states across the pH sweep, even when their normalized Cu:H core looks similar.
- Collapse only exact duplicate descriptions of the same aqueous state, especially alternative spellings of simple free ions; prefer SRD-46 over Atlas when the state is otherwise identical because the NTA complex set is SRD-based.
- Exclude redox branches: the calculation fixes Cu as Cu(II) in a non-redox solution model, with no imposed pe/Eh or electron balance, so Cu(I), Cu(0), and cuprous oxide chemistry are out of scope.
- Exclude solid phases for this requested output: the task asks for dissolved Cu2+ suppression and dominant dissolved Cu-bearing species in a single analytical solution, not precipitation/solubility or hydrate/anhydrous solid competition.
- Carbonates, counterion solids, gases, and elemental reference phases have no role in this NTA-only fixed-composition aqueous sweep unless explicitly present in the source inventory; do not add or preserve them decoratively.
- The phase question is dissolved equilibrium speciation, not which crystalline polymorph forms; polymorph/hydration distinctions among solids should not be allowed to affect this calculation.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Keep aqueous Cu(II) free ion, hydrolysis species including polynuclear hydroxo complexes, and all Cu-NTA complexes as distinct competitors, except collapse exact notation duplicates of the same aqueous ion and prefer the SRD-46 entry. Treat Cu(I), elemental Cu, cuprous/cupric oxides, and Cu hydroxide solids as out of scope for this non-redox aqueous Cu(II)-NTA mass-balance calculation.

[Singletons: n=15]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(NTA)]-` | SRD-46 | -1 | 20.991 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(NTA)(OH)]2-` | SRD-46 | -2 | 73.502 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(NTA)H]` | SRD-46 | +0 | 11.859 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(NTA)2]4-` | SRD-46 | -4 | 72.874 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[NTA]` | SRD-46 | -3 | 78.709 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HNTA]2-` | SRD-46 | -2 | 24.714 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2NTA]-` | SRD-46 | -1 | 10.331 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3NTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4NTA]+` | SRD-46 | +1 | -5.708 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All supplied aqueous Cu(II), NTA, and solvent/speciation entries are retained as in-scope singleton competitors for the Cu(II)-NTA aqueous calculation. The elemental copper solid is excluded because solids and Cu(0)/redox branches are out of scope.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Recorded 15 singleton verdicts: kept the in-scope aqueous Cu(II), Cu–NTA, NTA protonation, hydrolysis, polynuclear hydrolysis, and water entries; excluded elemental solid Cu as an out-of-scope solid/redox branch for the fixed Cu(II)-NTA aqueous speciation calculation.
</answer>
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | true | false | Cu(OH)2(s) is a solid precipitation/solubility phase and is out of scope for the requested fixed-composition dissolved Cu(II)-NTA pH speciation calculation. |

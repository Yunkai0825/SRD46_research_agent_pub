# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Cu(I) free ion, so the SRD-46 notation is retained over the Atlas duplicate.<br>review 1: dropped — Aqueous Cu(I) is a redox branch and is out of scope for the fixed Cu(II), non-redox Cu-NTA pH speciation calculation. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Cu(I) free ion, so the SRD-46 notation is retained over the Atlas duplicate.<br>review 2: dropped — Aqueous Cu(I) is a redox branch and is out of scope for the fixed Cu(II), non-redox Cu-NTA pH speciation calculation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Cu(II) free ion, so the SRD-46 entry is kept in preference to the Atlas duplicate. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Cu(II) free ion, so the SRD-46 entry is kept in preference to the Atlas duplicate. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both SRD-46 aqueous Cu(II) hydrolysis species because mononuclear CuOH+ and polynuclear Cu2(OH)2^2+ are distinct mass-balance/speciation states in the Cu(II)-NTA aqueous calculation. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both SRD-46 aqueous Cu(II) hydrolysis species because mononuclear CuOH+ and polynuclear Cu2(OH)2^2+ are distinct mass-balance/speciation states in the Cu(II)-NTA aqueous calculation. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral aqueous Cu(II) hydrolysis species is in scope as a distinct dissolved competitor in the pH sweep. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Anionic aqueous Cu(II) hydrolysis species is in scope as a distinct dissolved competitor, not a solid or redox branch. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Dianionic aqueous Cu(II) hydrolysis species is in scope as a distinct dissolved competitor, not a duplicate of another singleton. |
| `DEDUP-e0b079068c5de0cc` | `[Cu(NTA)]-` | SRD-46 | generation 1: kept — The 1:1 Cu(II)-NTA complex is central to the requested ligand-control speciation calculation. |
| `DEDUP-9d649e7163643f6b` | `[Cu(NTA)(OH)]2-` | SRD-46 | generation 1: kept — The hydroxo Cu(II)-NTA complex is a distinct aqueous NTA-bound species relevant across the pH range. |
| `DEDUP-36b2ac5f7cf12e77` | `[Cu(NTA)H]` | SRD-46 | generation 1: kept — The protonated Cu(II)-NTA complex is a distinct aqueous bound state relevant to the acidic portion of the sweep. |
| `DEDUP-2ca2a80a32478ef2` | `[Cu(NTA)2]4-` | SRD-46 | generation 1: kept — The bis-NTA Cu(II) complex is a distinct dissolved mass-balance state under excess NTA conditions. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — The polynuclear Cu(II) hydrolysis complex is explicitly in scope at millimolar copper as a distinct aqueous species. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental copper solid is both a solid phase and a Cu(0) redox branch, which are excluded from this non-redox dissolved Cu(II)-NTA calculation. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent the same anhydrous Cu(I) oxide solid state, so one representative is kept with preference for the SRD-46 entry. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent the same anhydrous Cu(I) oxide solid state, so one representative is kept with preference for the SRD-46 entry.<br>review 3: dropped — Cu2O(s) is a solid Cu(I) redox/precipitation branch and is out of scope for the fixed-composition, non-redox dissolved Cu(II)-NTA pH speciation calculation. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the SRD-46 representatives for the distinct CuO and Cu(OH)2 solid states while collapsing the corresponding Atlas duplicates. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the SRD-46 representatives for the distinct CuO and Cu(OH)2 solid states while collapsing the corresponding Atlas duplicates. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 representatives for the distinct CuO and Cu(OH)2 solid states while collapsing the corresponding Atlas duplicates.<br>review 5: dropped — Cu(OH)2(s) is a solid precipitation/solubility phase and is out of scope for the requested fixed-composition dissolved Cu(II)-NTA pH speciation calculation. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 representatives for the distinct CuO and Cu(OH)2 solid states while collapsing the corresponding Atlas duplicates.<br>review 4: dropped — CuO(s) is a solid precipitation/solubility phase and is out of scope for the requested fixed-composition dissolved Cu(II)-NTA pH speciation calculation. |
| — | `[H2NTA]-` | SRD-46 | generation 1: kept — H2NTA is an in-scope ligand protonation state needed for the pH-dependent NTA mass balance. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the aqueous solvent/reference component and is not an out-of-scope duplicate or redox branch. |
| — | `[H3NTA]` | SRD-46 | generation 1: kept — H3NTA is an in-scope neutral ligand protonation state for the specified pH range. |
| — | `[H4NTA]+` | SRD-46 | generation 1: kept — H4NTA+ is an in-scope protonated ligand state for acidic speciation conditions. |
| — | `[HNTA]2-` | SRD-46 | generation 1: kept — HNTA is an in-scope ligand protonation state needed for the pH-dependent NTA mass balance. |
| — | `[NTA]` | SRD-46 | generation 1: kept — Free deprotonated NTA is required for the ligand acid-base and metal-binding mass balance. |

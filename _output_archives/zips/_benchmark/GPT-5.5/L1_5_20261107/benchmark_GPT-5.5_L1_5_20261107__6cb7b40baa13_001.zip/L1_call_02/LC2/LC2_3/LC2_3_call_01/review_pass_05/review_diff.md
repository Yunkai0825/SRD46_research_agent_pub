# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | true | false | CuO(s) is a solid precipitation/solubility phase and is out of scope for the requested fixed-composition dissolved Cu(II)-NTA pH speciation calculation. |

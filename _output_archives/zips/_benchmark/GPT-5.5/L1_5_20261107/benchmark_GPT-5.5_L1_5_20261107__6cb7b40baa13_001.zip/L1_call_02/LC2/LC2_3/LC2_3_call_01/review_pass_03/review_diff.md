# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Aqueous Cu(I) is a redox branch and is out of scope for the fixed Cu(II), non-redox Cu-NTA pH speciation calculation. |

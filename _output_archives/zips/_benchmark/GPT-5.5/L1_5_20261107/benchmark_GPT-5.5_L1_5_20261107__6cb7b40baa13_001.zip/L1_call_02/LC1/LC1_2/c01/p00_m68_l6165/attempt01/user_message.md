[Purpose: Compare ligand control of Cu(II) speciation by NTA across pH 3 to 10 under fixed analytical concentrations. The goal is to quantify free Cu2+ suppression and identify where the Cu-NTA complex begins to dissociate under acidic conditions.]
[Tasks:
For a single solution containing Cu(II) and NTA, calculate a 1D pH sweep from pH 3 to 10 at 25 C and ionic strength I=0.1 m, with total Cu = 1 mM and total NTA = 5 mM. Report the free Cu2+ concentration or fraction across the range, dominant Cu-bearing species, and the low-pH onset or pH region where the Cu-NTA complex begins to dissociate; include convergence/state metrics and CSV/plot artifacts.
]
[Pair: pair_key=`m68_l6165`, metal_id=68, ligand_id=6165, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l6165

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6165_beta32_net3637` | `[HL] + [H] <=> [H2L]` | vlm_105186@(25.0,0.1) = K+2.520 | 8 | +2.280 / +2.480 / +2.513 / +2.940 | vlm_105186@(25.0,0.1) = K+2.520 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand6165_beta53_net3637` | `[H2L] + [H] <=> [H3L]` | vlm_105204@(25.0,0.1) = K+1.810 | 8 | +1.780 / +1.830 / +1.867 / +2.000 | vlm_105204@(25.0,0.1) = K+1.810 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand6165_beta79_net3637` | `[L] + [H] <=> [HL]` | vlm_105158@(25.0,0.1) = K+9.460 | 15 | +8.940 / +9.390 / +9.450 / +10.334 | vlm_105158@(25.0,0.1) = K+9.460 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal68_ligand6165_beta64_net3637` | `[H3L] + [H] <=> [H4L]` | vlm_105223@(25.0,0.1) = K+1.000 | 3 | +1.000 / +1.000 / +1.100 / +1.300 | vlm_105223@(25.0,0.1) = K+1.000 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

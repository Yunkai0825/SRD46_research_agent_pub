# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # Task specifies 25 C.
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # Task specifies ionic strength I=0.1.
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # Task specifies total Cu(II) / analytical Cu = 1 mM for a Cu(II) speciation calculation.
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # Redox is excluded for the pH sweep; no Cu(I) is introduced in the task.
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Redox is excluded for the pH sweep; no Cu(0) analytical component is introduced in the task.
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # Task specifies total EDTA = 5 mM.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the selected one-dimensional sweep coordinate from pH 3 to 10.'},
]

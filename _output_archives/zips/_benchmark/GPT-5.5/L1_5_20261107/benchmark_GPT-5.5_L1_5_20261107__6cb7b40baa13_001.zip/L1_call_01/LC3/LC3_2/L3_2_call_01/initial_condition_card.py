inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task specifies ionic strength I=0.1."},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "Task specifies total Cu(II) / analytical Cu = 1 mM for a Cu(II) speciation calculation."},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "Redox is excluded for the pH sweep; no Cu(I) is introduced in the task."},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "Redox is excluded for the pH sweep; no Cu(0) analytical component is introduced in the task."},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "Task specifies total EDTA = 5 mM."},
]
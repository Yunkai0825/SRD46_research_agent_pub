# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_5_20261107\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.15
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D Cu-EDTA speciation vs pH at fixed analytical concentrations.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_5_20261107\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
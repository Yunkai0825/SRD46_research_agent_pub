# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | true | false | Exclude Cu(OH)2(s) because this task is homogeneous Cu(II)-EDTA aqueous speciation with no precipitation, solid-phase stability, or hydroxide-solid competition calculation. |

# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Exclude aqueous Cu(I) because this is a fixed Cu(II)-EDTA homogeneous speciation calculation with no imposed redox reservoir; Cu(I) redox branches are out of scope despite being the retained representative of a notational duplicate group. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as homogeneous aqueous equilibrium speciation for a fixed-composition Cu(II)-EDTA solution, not a Pourbaix/corrosion/electrodeposition calculation; there is no imposed potential or redox reservoir.
- Aqueous identity is governed by total Cu = 1 mM, total EDTA = 5 mM, pH 3–10, 25 °C, I = 0.1 m; do not use the 1e-6 M corrosion convention.
- Retain chemically distinct Cu(II) hydrolysis, nuclearity, and Cu-EDTA protonation/hydroxo states because they can differ in concentration and pH dependence at millimolar analytical concentrations; bracketed versus unbracketed labels alone are notation.
- The calculation asks for dissolved Cu speciation and free Cu2+ suppression; solid precipitation, hydrate/anhydrous solid competition, elemental Cu, Cu(I) redox branches, and oxide stability are out of scope unless the upstream question is explicitly changed to include precipitation/redox.
- Carbonate, counterion solids, and gas fugacities are not part of this EDTA-control problem and should not be introduced as competing phases.
- Phase selection is equilibrium speciation, not kinetic formation; for true duplicate aqueous entries use the thermodynamically consistent SRD-46 representation when available, especially because the EDTA complex set is SRD-based.
- The free EDTA acid-base/protonation ladder is essential for the requested pH sweep; if it is absent from the non-Cu ligand inventory, that is a diagram-changing source/model gap to flag rather than silently compensating within Cu deduplication.

## Element instructions

- **Cu**: For Cu, collapse only notational duplicates such as Cu+ versus [Cu]+ and Cu2+ versus [Cu]2+, preferring the SRD-46 bracketed entries for consistency with the SRD EDTA complexes. Keep distinct aqueous Cu(II) hydrolysis species, polynuclear hydroxo species, and Cu-EDTA protonation/hydroxo complexes; exclude Cu(I)/Cu(0) redox branches and all solid oxide/hydroxide/elemental entries as out of scope for this homogeneous Cu(II)-EDTA pH speciation calculation.

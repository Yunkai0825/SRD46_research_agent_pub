# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Exclude cuprous oxide solid because this task is homogeneous Cu(II)-EDTA aqueous speciation with no precipitation, redox, or solid-phase stability calculation. |

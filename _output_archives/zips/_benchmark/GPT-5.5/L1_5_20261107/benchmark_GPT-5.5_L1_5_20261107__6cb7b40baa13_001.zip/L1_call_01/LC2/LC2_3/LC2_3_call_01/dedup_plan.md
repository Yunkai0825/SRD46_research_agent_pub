# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as homogeneous aqueous equilibrium speciation for a fixed-composition Cu(II)-EDTA solution, not a Pourbaix/corrosion/electrodeposition calculation; there is no imposed potential or redox reservoir.
- Aqueous identity is governed by total Cu = 1 mM, total EDTA = 5 mM, pH 3–10, 25 °C, I = 0.1 m; do not use the 1e-6 M corrosion convention.
- Retain chemically distinct Cu(II) hydrolysis, nuclearity, and Cu-EDTA protonation/hydroxo states because they can differ in concentration and pH dependence at millimolar analytical concentrations; bracketed versus unbracketed labels alone are notation.
- The calculation asks for dissolved Cu speciation and free Cu2+ suppression; solid precipitation, hydrate/anhydrous solid competition, elemental Cu, Cu(I) redox branches, and oxide stability are out of scope unless the upstream question is explicitly changed to include precipitation/redox.
- Carbonate, counterion solids, and gas fugacities are not part of this EDTA-control problem and should not be introduced as competing phases.
- Phase selection is equilibrium speciation, not kinetic formation; for true duplicate aqueous entries use the thermodynamically consistent SRD-46 representation when available, especially because the EDTA complex set is SRD-based.
- The free EDTA acid-base/protonation ladder is essential for the requested pH sweep; if it is absent from the non-Cu ligand inventory, that is a diagram-changing source/model gap to flag rather than silently compensating within Cu deduplication.

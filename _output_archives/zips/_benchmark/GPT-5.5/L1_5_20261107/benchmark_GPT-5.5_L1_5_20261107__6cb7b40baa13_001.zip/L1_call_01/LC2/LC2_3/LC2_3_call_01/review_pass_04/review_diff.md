# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | true | false | Exclude CuO(s) because this task is homogeneous Cu(II)-EDTA aqueous speciation with no precipitation, solid-phase stability, or oxide competition calculation. |

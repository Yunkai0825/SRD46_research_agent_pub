Singleton review complete: 16 aqueous entries are kept, and the elemental Cu solid is dropped as out of scope.

- Kept: water, Cu(II) hydrolysis species, Cu(II)-EDTA protonation/hydroxo complexes, polynuclear Cu(II) hydroxo species, and the full EDTA acid–base ladder.
- Dropped: solid elemental Cu, because Cu(0)/solid redox branches are outside the homogeneous Cu(II)-EDTA aqueous speciation model.
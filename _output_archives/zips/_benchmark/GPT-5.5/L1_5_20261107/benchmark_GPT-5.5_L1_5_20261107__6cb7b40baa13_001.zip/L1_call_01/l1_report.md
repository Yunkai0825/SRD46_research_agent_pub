## Doability
Doable: Cu(II), EDTA, a fixed-redox 1-D pH sweep, 25 °C, and I=0.1 M are supported by the pH_sweep pipeline; no redox or real titration curve is implied.

## Result
Computed a Cu(II)–EDTA pH speciation sweep for pH 3.0–10.0 at 25.0 °C with target ionic strength 0.1 M, total Cu(II) = 1.00e-3 M, and total EDTA = 5.00e-3 M. The solver reports 141/141 converged pH points. The run is redox-excluded: Cu(0) and Cu(I) totals were zero and the Cu(II) redox state is fixed. The calculated ionic strength range reported by the solver is 0.00880504–0.0337529 M, so the thermodynamic-source target was 0.1 M but the solved composition did not contain added inert electrolyte to maintain 0.1 M in the mass-balance state.

## Analysis
Cu is dominated by EDTA complexes over the entire requested pH range. The verdict reports [Cu(EDTA)]2- as the dominant Cu-bearing species from pH 3.0 to 10.0, with a peak fraction of 100.0% at pH 6.7. Protonated Cu–EDTA species are important only at the acidic edge: [Cu(EDTA)H]- peaks at 31.4% at pH 3.0, and [Cu(EDTA)H2] is present at the low-pH end in the inspected fraction table.

The inspected Cu fraction CSV quantifies the acidic dissociation/protonation region. At pH 3.0000 the Cu distribution is 0.6671068 [Cu(EDTA)]2-, 0.3137189 [Cu(EDTA)H]-, 0.01917402 [Cu(EDTA)H2], and free Cu2+ fraction 2.635236e-07. With total Cu = 1.00e-3 M, that free Cu2+ fraction corresponds to about 2.64e-10 M free Cu2+ at pH 3.0. As pH increases, deprotonation strengthens the unprotonated chelate: [Cu(EDTA)]2- rises to 0.8045622 at pH 3.3000, 0.9300124 at pH 3.8000, 0.9548231 at pH 4.0000, 0.9710750 at pH 4.2000, and 0.9835526 at pH 4.4500. Over the same interval free Cu2+ falls from 2.635236e-07 of Cu at pH 3.0 to 7.526074e-08 at pH 3.3, 8.439291e-09 at pH 3.8, 3.459618e-09 at pH 4.0, and 4.673449e-10 at pH 4.45.

Thus, within the requested pH window, Cu–EDTA does not undergo a majority dissociation crossover to free Cu2+; even at pH 3.0 free Cu2+ is only a trace fraction. The “onset” visible in this range is instead proton-assisted weakening of the Cu–EDTA chelate at the acidic boundary: the protonated Cu–EDTA forms together account for about 0.3329 of Cu at pH 3.0, while free Cu2+ remains strongly suppressed. Chemically, excess EDTA (5 mM vs 1 mM Cu) and the large formation constants in the reference card keep Cu bound; the pH dependence comes from EDTA protonation. At low pH the ligand is more protonated, shifting Cu into [Cu(EDTA)H]- and [Cu(EDTA)H2] and slightly increasing free Cu2+. As pH rises, EDTA deprotonates and the unprotonated [Cu(EDTA)]2- complex becomes essentially quantitative for Cu. At the high-pH edge the verdict notes [Cu(EDTA)(OH)]3- reaches 14.8% at pH 10.0, indicating some hydroxo complex formation, but [Cu(EDTA)]2- remains dominant.

Thermodynamic constants in the included card support this interpretation: cumulative log_beta values include +18.7800 for [Cu(EDTA)]2-, +21.8800 for [Cu(EDTA)H]-, and +23.8800 for [Cu(EDTA)H2], with EDTA protonation rows also included. These constants are card cumulative formation constants under the card convention, not independently reinterpreted pKa values except where the single-proton ligand row would justify that naming.

## Artifacts
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - The L1 report is consistent with the listed pH-sweep artifacts: expected solver outputs are present
  - the run parameters show pH 3–10 with 141 points
  - fixed ionic mode
  - and redox excluded
  - and the cited verdict/fraction/state-metrics/reference-constants artifacts exist for the reported Cu–EDTA speciation and convergence claims.

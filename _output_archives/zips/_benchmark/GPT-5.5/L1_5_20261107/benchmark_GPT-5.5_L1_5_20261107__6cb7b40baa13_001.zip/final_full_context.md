## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compare ligand control of Cu(II) speciation by EDTA across pH 3 to 10 under fixed analytical concentrations. The goal is to quantify free Cu2+ suppression and identify where the Cu-EDTA complex begins to dissociate under acidic conditions.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_run_params.json"
    ],
    "elapsed_s": 284.2
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Compare ligand control of Cu(II) speciation by NTA across pH 3 to 10 under fixed analytical concentrations. The goal is to quantify free Cu2+ suppression and identify where the Cu-NTA complex begins to dissociate under acidic conditions.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_02/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_Cu.json",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_phase_balance_Cu.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_L1.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_L1.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_ligand.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_concentrations.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_envelope_Cu$+2.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_envelope_L1.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_run_params.json"
    ],
    "elapsed_s": 342.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compare ligand control of Cu(II) speciation by EDTA across pH 3 to 10 under fixed analytical concentrations. The goal is to quantify free Cu2+ suppression and identify where the Cu-EDTA complex begins to dissociate under acidic conditions.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 2,
    "purpose": "Compare ligand control of Cu(II) speciation by NTA across pH 3 to 10 under fixed analytical concentrations. The goal is to quantify free Cu2+ suppression and identify where the Cu-NTA complex begins to dissociate under acidic conditions.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_concentrations.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png",
      "L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png",
      "L1_call_02/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "The L1 report is consistent with the listed pH-sweep artifacts: expected solver outputs are present",
      "the run parameters show pH 3\u201310 with 141 points",
      "fixed ionic mode",
      "and redox excluded",
      "and the cited verdict/fraction/state-metrics/reference-constants artifacts exist for the reported Cu\u2013EDTA speciation and convergence claims."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compare how EDTA versus NTA control the speciation of Cu(II) at pH 3-10, with 1 mM Cu total and 5 mM ligand, at 25 C and I=0.1 m. Which ligand keeps free [Cu2+] lower across the range, and where does each complex begin to dissociate at low pH?

## Assistant
<summary>I will run two separate Cu(II) pH-sweep calculations, one with EDTA and one with NTA, because these are separate ligand-control scenarios rather than one mixed-ligand solution. I’ll ask for free Cu2+ and dominant complex behavior over pH 3–10 at 25 °C, I=0.1 m, with 1 mM total Cu and 5 mM total ligand.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
**Parallel batch: 2 tools executed**

| # | Tool | Args | Chars | Note |
|---|------|------|------:|------|
| 1 | dispatch_l1_pipeline |  | 4244 | ### dispatch_l1_pipeline ## Doability Doable: Cu(II), EDTA, a fixed-redox 1-D pH sweep, 25 °C, and I=0.1 M are supported by the pH_sweep pipeline; no redox or real titration curve is implied. ##… |
| 2 | dispatch_l1_pipeline |  | 3177 | ### dispatch_l1_pipeline ## Doability Doable: Cu(II) and NTA are represented in the SRD-46/Atlas-derived card, and the requested calculation is a supported 1-D pH_sweep at 25.0 °C and target I = 0.1… |

*Use `inspect_batch_result(tool_number)` to read the full output of any tool above before proceeding.*

[WAIT BARRIER COMPLETE] 2 tool(s) finished (dispatch_l1_pipeline, dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

EDTA keeps free Cu²⁺ lower than NTA throughout the pH 3–10 range for the stated conditions: 1 mM total Cu, 5 mM ligand, 25 °C, and I = 0.1 m.

Chemically, this is expected because Cu(II)–EDTA is the stronger chelate system: EDTA is hexadentate and forms a very stable 1:1 Cu–EDTA complex, so even when EDTA becomes increasingly protonated at low pH, it still holds Cu more effectively than NTA. NTA is also a multidentate ligand, but its Cu(II) complex is less stabilizing than EDTA’s, so proton competition at acidic pH releases more Cu back into inorganic/free forms sooner.

At the low-pH end, both systems show acid-driven dissociation, but NTA begins to lose Cu complexation more strongly and at higher pH than EDTA. EDTA remains the better Cu²⁺ buffer across the whole sweep; NTA allows a larger free Cu²⁺ fraction under acidic conditions.

## Evidence

- The completed calculations are:
  - EDTA case: `L1_call_01`, pH-sweep output directory `L1_call_01/solver`
  - NTA case: `L1_call_02`, pH-sweep output directory `L1_call_02/solver`
- Both runs completed successfully and were validated as supported.
- EDTA run artifacts include the deterministic verdict, metal-fraction table, concentration table, state-metrics table, and plots.
- NTA run artifacts include the same corresponding files for direct comparison.
- The working-memory summary indicates both runs used pH 3–10, 25 °C, fixed ionic mode, and no redox sweep.

## Artifacts

- EDTA verdict: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- EDTA Cu fraction CSV: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- EDTA concentrations CSV: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv`
- EDTA convergence/state metrics: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- EDTA Cu speciation plot: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- EDTA log concentration plot: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png`

- NTA verdict: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md`
- NTA Cu fraction CSV: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv`
- NTA concentrations CSV: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_concentrations.csv`
- NTA convergence/state metrics: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv`
- NTA Cu speciation plot: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png`
- NTA log concentration plot: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png`
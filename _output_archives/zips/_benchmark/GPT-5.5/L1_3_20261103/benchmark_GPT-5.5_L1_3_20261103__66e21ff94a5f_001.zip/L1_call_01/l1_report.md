## Doability
Doable. Cu–ammonia is a supported Cu/ligand Pourbaix system; the run used pH–E axes at 25 °C, Cu=0.001 M, total ammonia=0.1 M, and I=0.1 passed to source selection.

## Result
Computed a 2-D Cu predominance Pourbaix map over pH 0–14 and E=-0.8 to +0.8 V vs SHE. Final classified-grid spacing was ΔpH=0.011111111 and ΔE=0.0011111111 V. The Cu catalog contains 9 dominant labels and 11 connected regions. The full-speciation CSV header reports 21,238 coarse-unrefined and 104,475 refined sampled points with a `converged` column; inspected rows had `converged=1` and small residuals, and the classified map reports `fixer_marks: 0`. The map should still be read as predominance, not purity or kinetics.

## Analysis
Thermodynamic constants explain the main pattern: ammonia protonation is strong, [HAmmonia]+ log_beta=9.2600, so free NH3 becomes most available near/above its conjugate-acid pKa. Cu ammine formation is also strong: Cu(I) [Cu(Ammo)2]+ log_beta=9.9200; Cu(II) complexes increase from [Cu(Ammo)]2+ log_beta=4.1000 to [Cu(Ammo)4]2+ log_beta=12.3000. These complexes compete against Cu(OH)2(s), whose included dissolution row has log_beta=-8.6800, and against metallic Cu at reducing potentials.

Feature roster used: DmsReg_7 is the main [Cu(Ammo)2]+ liquid region, connected to Cu, cuprite-like [(Cu2O)0.5](s), Cu(OH)2(s), [Cu(Ammo)4]2+, and [Cu(Ammo)3]2+; its key corners include DmsRegEqJnc_13 at pH 10.46111, E=-0.13944 V; DmsRegEqJnc_15 at pH 8.06111, E=0.00278 V; DmsRegEqJnc_18 at pH 7.79444, E=0.25944 V; DmsRegEqJnc_5 at pH 7.99444, E=0.27167 V; DmsRegEqJnc_4 at pH 10.31667, E=0.13611 V; and DmsRegEqJnc_16 at pH 10.56111, E=0.095 V. DmsReg_8 is [Cu(Ammo)4]2+ at more oxidizing alkaline conditions, bounded by DmsRegEq_15 against Cu(OH)2(s) from pH 10.31667, E=0.13611 V to about pH 10.13889, E=0.8 V. DmsReg_10 is a narrow [Cu(Ammo)3]2+ strip near pH 8.0–8.2 at higher E, and DmsReg_11 is a small [Cu(Ammo)]2+ field near pH 6.16–6.33 at high E.

The most practical soluble-ammine window is therefore the central [Cu(Ammo)2]+ field: approximately pH 8.06–10.56, with E from the Cu/[Cu(Ammo)2]+ boundary near -0.139 to +0.003 V up to the solid/ammine and Cu(II)/Cu(I)-ammine boundaries near 0.095–0.272 V depending on pH. Along the pH reference line at E=0 V, the map gives Cu metal from pH 0–8.0777778, [Cu(Ammo)2]+ from pH 8.0888889–10.455556, then [(Cu2O)0.5](s), Cu(OH)2(s), and finally CuO22- at very high pH. Thus at neutral pH and E=0 the metal is not held as a soluble ammine; a moderately alkaline, mildly oxidizing/reducing window is needed.

Against Cu(OH)2(s) specifically, the [Cu(Ammo)2]+/Cu(OH)2(s) contacts occur at pH 10.56111, E=0.095 V to pH 10.31667, E=0.13611 V, and at pH 7.79444, E=0.25944 V to pH 7.99444, E=0.27167 V. At more oxidizing potentials, Cu(II) ammines predominate over Cu(OH)2(s) in additional windows: [Cu(Ammo)4]2+ from about pH 8.20556–10.31667 at E≈0.26056–0.13611 V and extending to E=0.8 with an upper-pH Cu(OH)2 boundary near pH 10.14; [Cu(Ammo)3]2+ is a narrow strip near pH 8.0–8.2 up to E=0.8. Chemically, increasing E converts Cu(I)-ammine stability toward Cu(II) ammines; increasing pH first liberates NH3 and strengthens ammine complexation, but still stronger hydrolysis/solid precipitation or anionic cuprate predominance takes over at sufficiently high pH.

## Artifacts
L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md
L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv
L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv
L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png
L1_call_01/thermodynamic_reference_constants.md
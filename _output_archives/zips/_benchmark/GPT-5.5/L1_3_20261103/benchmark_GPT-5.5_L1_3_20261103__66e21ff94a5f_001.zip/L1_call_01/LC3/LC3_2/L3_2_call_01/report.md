# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 11.25
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task specifies ionic strength I = 0.1 m; entered on the catalog ionic-strength scale.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total copper across redox states.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M total ammonia.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the horizontal coordinate of the 2-D Pourbaix diagram.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Electrode potential is the redox coordinate of the 2-D Pourbaix diagram.'},
]

```

## Notes
Known task inputs are T = 25 C, fixed ionic strength 0.1, total copper 1 mM, and total ammonia 0.1 M. pH and E_V are deferred to L3_3 as the two Pourbaix sweep coordinates. Solids are included to compare aqueous Cu-ammine predominance against Cu(OH)2(s) and metallic Cu.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
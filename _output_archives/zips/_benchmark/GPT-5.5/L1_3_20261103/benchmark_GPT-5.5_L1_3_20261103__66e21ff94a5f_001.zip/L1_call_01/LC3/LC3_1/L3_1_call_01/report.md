# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.53
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Explicit two-dimensional pH–E Pourbaix predominance analysis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
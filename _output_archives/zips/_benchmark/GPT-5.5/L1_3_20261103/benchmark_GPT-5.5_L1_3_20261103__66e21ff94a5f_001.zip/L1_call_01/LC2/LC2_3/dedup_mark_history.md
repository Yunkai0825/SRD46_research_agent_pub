# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Keep because the Cu(I) diammine complex is a distinct in-scope ammine species under the high-ammonia Pourbaix conditions. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Keep because neutral Cu(II) dihydroxo aqueous species are distinct hydroxo complexes that may affect predominance. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous anion has a distinct stoichiometry and charge and is in scope for pH-dependent speciation. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous dianion is a distinct high-pH species rather than a duplicate. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Keep because the monoammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Keep because the diammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Keep because the triammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Keep because the tetraammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Keep because the polynuclear Cu(II) hydroxo complex is specifically in scope and should not be collapsed with mononuclear species. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Keep because elemental copper is the required metallic reference and redox competitor. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| — | `[?]` | SRD-46 | generation 1: kept — Keep because no case-specific instruction excludes this singleton aqueous background entry and there is no within-group duplicate to collapse. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Keep because free ammonia is required by the specified 0.1 M total ammonia inventory. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Keep because protonated ammonia is required for the ammonia acid-base balance in the Pourbaix calculation. |

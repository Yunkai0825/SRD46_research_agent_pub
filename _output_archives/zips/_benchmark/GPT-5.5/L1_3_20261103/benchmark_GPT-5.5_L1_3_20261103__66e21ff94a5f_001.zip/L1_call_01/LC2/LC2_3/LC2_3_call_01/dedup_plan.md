# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as a Cu–NH3 aqueous Pourbaix predominance calculation at 25 °C and ionic strength 0.1 m, with 1 mM total Cu and 0.1 M total ammonia; do not apply the dilute 1e-6 M corrosion convention.
- Aqueous identity is governed by the high ammonia inventory: distinct Cu(I)/Cu(II), ammine stoichiometries, hydroxo stoichiometries, and polynuclear hydroxo complexes can occupy different pH–E regions and should not be collapsed merely because normalized compositions resemble each other.
- Collapse only formula spelling/source duplicates of the same aqueous ion, such as Cu+ versus [Cu]+ and Cu2+ versus [Cu]2+; prefer SRD-46 representatives when available to keep the ammine complexation network internally consistent.
- For solids, this is a room-temperature aqueous precipitation/stability question with hydroxide solids requested as preferred Cu(II) precipitation phases; Cu(OH)2(s) should represent Cu(II) precipitation in preference to CuO when both are available.
- Cu2O is a distinct Cu(I) redox solid and may compete between Cu(s), Cu(II) solids, and soluble complexes; keep it as a distinct phase, collapsing only duplicate source/normalization entries for Cu2O.
- No carbonate, sulfate, nitrate, chloride, or other counterion solids are part of this calculation, and no gas fugacity constraint is implied; such phases would be out of scope if present.
- The phase question is stable predominance on a Pourbaix hull, not identifying every possible kinetic formation product; collapse redundant polymorph/source spellings to one preferred representative rather than retaining parallel descriptions of the same physical state.
- Elemental Cu(s) is the required metallic reference/competitor and must remain.

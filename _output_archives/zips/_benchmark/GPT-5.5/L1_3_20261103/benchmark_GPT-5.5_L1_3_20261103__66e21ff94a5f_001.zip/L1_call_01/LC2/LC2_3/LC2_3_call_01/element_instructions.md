# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a Cu–NH3 aqueous Pourbaix predominance calculation at 25 °C and ionic strength 0.1 m, with 1 mM total Cu and 0.1 M total ammonia; do not apply the dilute 1e-6 M corrosion convention.
- Aqueous identity is governed by the high ammonia inventory: distinct Cu(I)/Cu(II), ammine stoichiometries, hydroxo stoichiometries, and polynuclear hydroxo complexes can occupy different pH–E regions and should not be collapsed merely because normalized compositions resemble each other.
- Collapse only formula spelling/source duplicates of the same aqueous ion, such as Cu+ versus [Cu]+ and Cu2+ versus [Cu]2+; prefer SRD-46 representatives when available to keep the ammine complexation network internally consistent.
- For solids, this is a room-temperature aqueous precipitation/stability question with hydroxide solids requested as preferred Cu(II) precipitation phases; Cu(OH)2(s) should represent Cu(II) precipitation in preference to CuO when both are available.
- Cu2O is a distinct Cu(I) redox solid and may compete between Cu(s), Cu(II) solids, and soluble complexes; keep it as a distinct phase, collapsing only duplicate source/normalization entries for Cu2O.
- No carbonate, sulfate, nitrate, chloride, or other counterion solids are part of this calculation, and no gas fugacity constraint is implied; such phases would be out of scope if present.
- The phase question is stable predominance on a Pourbaix hull, not identifying every possible kinetic formation product; collapse redundant polymorph/source spellings to one preferred representative rather than retaining parallel descriptions of the same physical state.
- Elemental Cu(s) is the required metallic reference/competitor and must remain.

## Element instructions

- **Cu**: Keep distinct aqueous Cu(I)/Cu(II), ammine, monomeric hydroxo, and polynuclear hydroxo species; collapse only exact notation/source duplicates such as Cu+/[Cu]+ and Cu2+/[Cu]2+, preferring SRD-46 when available. For solids, keep Cu(s), keep one Cu2O representative preferring SRD-46, and represent Cu(II) precipitation by Cu(OH)2(s) preferring SRD-46 while excluding CuO alternatives when Cu(OH)2 is available.

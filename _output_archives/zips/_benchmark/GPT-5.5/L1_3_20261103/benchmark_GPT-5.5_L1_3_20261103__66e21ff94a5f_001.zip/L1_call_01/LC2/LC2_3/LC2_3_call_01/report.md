# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    93.80
- elapsed_s (total):  93.80
- llm_iterations:     19
- llm_tool_calls:     11

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Keep because no case-specific instruction excludes this singleton aqueous background entry and there is no within-group duplicate to collapse. |
| aqueous | `Cu$+1:1 L1:2` | yes | Keep because the Cu(I) diammine complex is a distinct in-scope ammine species under the high-ammonia Pourbaix conditions. |
| aqueous | `Cu$+2:1 H:-2` | yes | Keep because neutral Cu(II) dihydroxo aqueous species are distinct hydroxo complexes that may affect predominance. |
| aqueous | `Cu$+2:1 H:-3` | yes | Keep because this Cu(II) hydroxo/oxo aqueous anion has a distinct stoichiometry and charge and is in scope for pH-dependent speciation. |
| aqueous | `Cu$+2:1 H:-4` | yes | Keep because this Cu(II) hydroxo/oxo aqueous dianion is a distinct high-pH species rather than a duplicate. |
| aqueous | `Cu$+2:1 L1:1` | yes | Keep because the monoammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:2` | yes | Keep because the diammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:3` | yes | Keep because the triammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:4` | yes | Keep because the tetraammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:3 H:-4` | yes | Keep because the polynuclear Cu(II) hydroxo complex is specifically in scope and should not be collapsed with mononuclear species. |
| aqueous | `L1:1` | yes | Keep because free ammonia is required by the specified 0.1 M total ammonia inventory. |
| aqueous | `L1:1 H:1` | yes | Keep because protonated ammonia is required for the ammonia acid-base balance in the Pourbaix calculation. |
| solid | `Cu$+0:1` | yes | Keep because elemental copper is the required metallic reference and redox competitor. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `CuO` | Atlas | dissolution | LC2 element review: Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: e86fbb76a2814cdcae820b4ea3367085
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplication accepted for the Cu–NH3 Pourbaix calculation. The table keeps the SRD-46 aqueous copper/ammonia network, retains distinct Cu(I)/Cu(II), ammine, hydroxo, and polynuclear hydroxo species, and drops only notation/source duplicates. It keeps Cu(s) as the metallic competitor, keeps one Cu2O representative as the distinct Cu(I) solid, and uses SRD-46 Cu(OH)2(s) as the preferred Cu(II) precipitation phase while excluding CuO alternatives as requested.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-5.5\L1_3_20261103\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

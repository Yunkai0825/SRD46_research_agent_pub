## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-f7418fe0359ae9ca": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[z+1]", "label": "[Cu]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]+"}, "source_row": {"species_id": "[Cu$+1].[z+1]", "original_id": "[M2].[z+1]", "label": "[Cu]+", "charge": "+1", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Cu$+1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1] ***"}, "source_row_sha256": "384f8f0fe2fb56636b4b2358c5b782c9aeee5b69789dea99c580f5ab2a5b9d3c"}, "DEDUP-5826713fca0f819d": {"pair_keys": ["metal_42_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1]2.[z+1]", "label": "[Cu(Ammo)2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Ammo)2]+"}, "source_row": {"species_id": "[Cu$+1].[L1]2.[z+1]", "original_id": "[M2].[L1]2.[z+1]", "label": "[Cu(Ammo)2]+", "charge": "+1", "phase": "aqueous", "log_beta": "+9.9200", "mu0_free_kJ": "-56.6203", "mu0_canon_kJ": "-56.6203", "mu_aligned_kJ": "-56.6203", "stoich": "[Cu$+1]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "fbba506f47357adc8743805581371e9c4eaa1f1aa24733275e9dd36ef1c30876"}, "DEDUP-e23e4a47f1ff44f3": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[z+2]", "label": "[Cu]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]2+"}, "source_row": {"species_id": "[Cu$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Cu]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+14.7695", "stoich": "[Cu$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1] ***"}, "source_row_sha256": "dd86da94a35ed3a8fc334975073378b930633cb3aeb93414170eceb4759c944b"}, "DEDUP-310f379acd061cea": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH].[z+1]", "label": "[Cu(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)]+"}, "source_row": {"species_id": "[Cu$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Cu(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-7.9000", "mu0_free_kJ": "+45.0908", "mu0_canon_kJ": "+45.0908", "mu_aligned_kJ": "+59.8603", "stoich": "[Cu$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "4b30c7a76401319405d91bff9738de7617ba7927a159d8024f506688a0de4004"}, "DEDUP-189abbd15a8879cf": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu2(OH)2]2+"}, "source_row": {"species_id": "[Cu$+2]2.[OH]2.[z+2]", "original_id": "[M1]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-11.2000", "mu0_free_kJ": "+63.9261", "mu0_canon_kJ": "+63.9261", "mu_aligned_kJ": "+93.4651", "stoich": "[Cu$+2]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "15b8ab93af6c4f930756733b451b079f9cd6240a281a53b7929e005ea6762d49"}, "DEDUP-adb8ec56ae65e74a": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[z+0]", "label": "[Cu(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)2]"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Cu(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-16.2000", "mu0_free_kJ": "+92.4646", "mu0_canon_kJ": "+92.4646", "mu_aligned_kJ": "+107.2341", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "5a5f1196b951ed11f7717e7f1bd2828eb1cd6e901da24d5d5053b031509f8320"}, "DEDUP-57e8daa9ccf0b2a2": {"pair_keys": ["metal_41_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1].[z+2]", "label": "[Cu(Ammo)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Ammo)]2+"}, "source_row": {"species_id": "[Cu$+2].[L1].[z+2]", "original_id": "[M1].[L1].[z+2]", "label": "[Cu(Ammo)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+4.1000", "mu0_free_kJ": "-23.4015", "mu0_canon_kJ": "-23.4015", "mu_aligned_kJ": "-8.6320", "stoich": "[Cu$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "c600542145cb69da81ca2dd70f5c16ed1be8d6f5d342e3e6933f2b071303dac6"}, "DEDUP-cea12c0b6f396ab4": {"pair_keys": ["metal_41_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1]2.[z+2]", "label": "[Cu(Ammo)2]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Ammo)2]2+"}, "source_row": {"species_id": "[Cu$+2].[L1]2.[z+2]", "original_id": "[M1].[L1]2.[z+2]", "label": "[Cu(Ammo)2]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+7.4000", "mu0_free_kJ": "-42.2369", "mu0_canon_kJ": "-42.2369", "mu_aligned_kJ": "-27.4674", "stoich": "[Cu$+2]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "d64a6b95cc26a972157066723aaf757c3f3a6bb3972688149421d3fe7af1e258"}, "DEDUP-153366f6feae80b7": {"pair_keys": ["metal_41_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1]3.[z+2]", "label": "[Cu(Ammo)3]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Ammo)3]2+"}, "source_row": {"species_id": "[Cu$+2].[L1]3.[z+2]", "original_id": "[M1].[L1]3.[z+2]", "label": "[Cu(Ammo)3]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+10.2000", "mu0_free_kJ": "-58.2185", "mu0_canon_kJ": "-58.2185", "mu_aligned_kJ": "-43.4490", "stoich": "[Cu$+2]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ece3a12c5e8f34e41bb9cefa2ec35cf087ddcd7110dd89c236d0ce5d12e34d89"}, "DEDUP-924bb0044556871a": {"pair_keys": ["metal_41_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1]4.[z+2]", "label": "[Cu(Ammo)4]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Ammo)4]2+"}, "source_row": {"species_id": "[Cu$+2].[L1]4.[z+2]", "original_id": "[M1].[L1]4.[z+2]", "label": "[Cu(Ammo)4]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+12.3000", "mu0_free_kJ": "-70.2046", "mu0_canon_kJ": "-70.2046", "mu_aligned_kJ": "-55.4351", "stoich": "[Cu$+2]:+1, [L1]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "acfa1cd1a97202270419c0ff3f871d5b8904e8d21e292002bf6a5dc3fff55fd1"}, "DEDUP-08467f2fbe8ff010": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu3(OH)4]2+"}, "source_row": {"species_id": "[Cu$+2]3.[OH]4.[z+2]", "original_id": "[M1]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-22.5000", "mu0_free_kJ": "+128.4231", "mu0_canon_kJ": "+128.4231", "mu_aligned_kJ": "+172.7316", "stoich": "[Cu$+2]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "7ab4334bd7c8c2d46b1cf176d808cf3faf179f6f6cb0895c2eb8d6d75db5b6da"}, "DEDUP-fb938706abdcd692": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Cu2O)0.5](s)"}, "source_row": {"species_id": "[Cu$+1].[OH].[z+0]_(s)", "original_id": "[M2].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "-3.9954", "stoich": "[Cu$+1]:+1, [H]:-1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1 H:-1] ***"}, "source_row_sha256": "75c91cfc4ec0c32e389c567f17efe7b6e59ae8718225befd3fe42300c53377e2"}, "DEDUP-487bcfa1c8c146d2": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[CuO](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-7.6500", "mu0_free_kJ": "+43.6638", "mu0_canon_kJ": "+43.6638", "mu_aligned_kJ": "+58.4333", "stoich": "[Cu$+2]:+1, [H]:-2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "09af569d643b845afc5990f411a3d63077a47f6be864acf27c5d891fc6719b5c"}, "DEDUP-7b19001eaf9b50b1": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu(OH)2](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-8.6800", "mu0_free_kJ": "+49.5428", "mu0_canon_kJ": "+49.5428", "mu_aligned_kJ": "+64.3123", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "b7b10036cee9e2c4fe3901be9a4b73d169a97c49d8ba8aba019e3e225eeb6d35"}}

[Orchestration session]
e86fbb76a2814cdcae820b4ea3367085

[Calculation purpose]
Build a two-dimensional Pourbaix analysis for the single solution containing copper and ammonia, focused on whether soluble Cu-ammine species can predominate relative to Cu(OH)2(s) and metallic Cu. The goal is to identify the pH–E window at 25 C and ionic strength 0.1 molal for 1 mM total copper and 0.1 M total ammonia, with hydroxide solids preferred where alternative solids are available.

[Requested tasks]
For one aqueous system containing Cu at 1 mM total concentration and ammonia at 0.1 M total concentration, at 25 C and ionic strength I = 0.1 m, build a 2-D Pourbaix diagram over a chemically reasonable pH and electrode-potential range. Prefer hydroxide solids for copper precipitation, especially Cu(OH)2(s), when multiple solid phases could represent precipitation. Report the regions where soluble copper ammine complexes dominate, and specifically identify the pH–E window where those soluble Cu-ammine complexes predominate over Cu(OH)2(s) and metallic Cu. Include convergence evidence and write the plots and CSV artifacts.

[Committed case-specific recommendations — in every child system prompt]
- Treat this as a Cu–NH3 aqueous Pourbaix predominance calculation at 25 °C and ionic strength 0.1 m, with 1 mM total Cu and 0.1 M total ammonia; do not apply the dilute 1e-6 M corrosion convention.
- Aqueous identity is governed by the high ammonia inventory: distinct Cu(I)/Cu(II), ammine stoichiometries, hydroxo stoichiometries, and polynuclear hydroxo complexes can occupy different pH–E regions and should not be collapsed merely because normalized compositions resemble each other.
- Collapse only formula spelling/source duplicates of the same aqueous ion, such as Cu+ versus [Cu]+ and Cu2+ versus [Cu]2+; prefer SRD-46 representatives when available to keep the ammine complexation network internally consistent.
- For solids, this is a room-temperature aqueous precipitation/stability question with hydroxide solids requested as preferred Cu(II) precipitation phases; Cu(OH)2(s) should represent Cu(II) precipitation in preference to CuO when both are available.
- Cu2O is a distinct Cu(I) redox solid and may compete between Cu(s), Cu(II) solids, and soluble complexes; keep it as a distinct phase, collapsing only duplicate source/normalization entries for Cu2O.
- No carbonate, sulfate, nitrate, chloride, or other counterion solids are part of this calculation, and no gas fugacity constraint is implied; such phases would be out of scope if present.
- The phase question is stable predominance on a Pourbaix hull, not identifying every possible kinetic formation product; collapse redundant polymorph/source spellings to one preferred representative rather than retaining parallel descriptions of the same physical state.
- Elemental Cu(s) is the required metallic reference/competitor and must remain.

[Committed element instructions]
- Cu: Keep distinct aqueous Cu(I)/Cu(II), ammine, monomeric hydroxo, and polynuclear hydroxo species; collapse only exact notation/source duplicates such as Cu+/[Cu]+ and Cu2+/[Cu]2+, preferring SRD-46 when available. For solids, keep Cu(s), keep one Cu2O representative preferring SRD-46, and represent Cu(II) precipitation by Cu(OH)2(s) preferring SRD-46 while excluding CuO alternatives when Cu(OH)2 is available.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. | Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |  |
| `DEDUP-5826713fca0f819d` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 | generation 1: kept — Keep because the Cu(I) diammine complex is a distinct in-scope ammine species under the high-ammonia Pourbaix conditions. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. | Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Keep because neutral Cu(II) dihydroxo aqueous species are distinct hydroxo complexes that may affect predominance. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous anion has a distinct stoichiometry and charge and is in scope for pH-dependent speciation. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous dianion is a distinct high-pH species rather than a duplicate. |  |
| `DEDUP-57e8daa9ccf0b2a2` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 | generation 1: kept — Keep because the monoammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |  |
| `DEDUP-cea12c0b6f396ab4` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 | generation 1: kept — Keep because the diammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |  |
| `DEDUP-153366f6feae80b7` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 | generation 1: kept — Keep because the triammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |  |
| `DEDUP-924bb0044556871a` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 | generation 1: kept — Keep because the tetraammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Keep because the polynuclear Cu(II) hydroxo complex is specifically in scope and should not be collapsed with mononuclear species. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. | Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-487bcfa1c8c146d2` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Keep because elemental copper is the required metallic reference and redox competitor. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Keep because no case-specific instruction excludes this singleton aqueous background entry and there is no within-group duplicate to collapse. | Keep because no case-specific instruction excludes this singleton aqueous background entry and there is no within-group duplicate to collapse. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. | Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. | Cu+ and [Cu]+ are notation duplicates of the same aqueous Cu(I) ion, so the SRD-46 representative is kept for the ammonia complexation network. |
| aqueous | `Cu$+1:1 L1:2` | Cu | aqueous | `[Cu(Ammo)2]+` | SRD-46 | kept | true | generation 1: kept — Keep because the Cu(I) diammine complex is a distinct in-scope ammine species under the high-ammonia Pourbaix conditions. | Keep because the Cu(I) diammine complex is a distinct in-scope ammine species under the high-ammonia Pourbaix conditions. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. | Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. | Cu2+ and [Cu]2+ are notation duplicates of the same aqueous Cu(II) ion, so the SRD-46 representative is kept as preferred. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. | Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. | Both SRD-46 aqueous species are distinct monomeric versus polynuclear Cu(II) hydroxo complexes relevant to Cu–NH3 Pourbaix predominance and should not be collapsed by normalized stoichiometry. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Keep because neutral Cu(II) dihydroxo aqueous species are distinct hydroxo complexes that may affect predominance. | Keep because neutral Cu(II) dihydroxo aqueous species are distinct hydroxo complexes that may affect predominance. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous anion has a distinct stoichiometry and charge and is in scope for pH-dependent speciation. | Keep because this Cu(II) hydroxo/oxo aqueous anion has a distinct stoichiometry and charge and is in scope for pH-dependent speciation. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — Keep because this Cu(II) hydroxo/oxo aqueous dianion is a distinct high-pH species rather than a duplicate. | Keep because this Cu(II) hydroxo/oxo aqueous dianion is a distinct high-pH species rather than a duplicate. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Keep because the monoammine Cu(II) complex is a distinct in-scope ammine stoichiometry. | Keep because the monoammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:2` | Cu | aqueous | `[Cu(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Keep because the diammine Cu(II) complex is a distinct in-scope ammine stoichiometry. | Keep because the diammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:3` | Cu | aqueous | `[Cu(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Keep because the triammine Cu(II) complex is a distinct in-scope ammine stoichiometry. | Keep because the triammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:1 L1:4` | Cu | aqueous | `[Cu(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Keep because the tetraammine Cu(II) complex is a distinct in-scope ammine stoichiometry. | Keep because the tetraammine Cu(II) complex is a distinct in-scope ammine stoichiometry. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — Keep because the polynuclear Cu(II) hydroxo complex is specifically in scope and should not be collapsed with mononuclear species. | Keep because the polynuclear Cu(II) hydroxo complex is specifically in scope and should not be collapsed with mononuclear species. |
| aqueous | `L1:1` | — | — | `[Ammonia]` | SRD-46 | kept | true | generation 1: kept — Keep because free ammonia is required by the specified 0.1 M total ammonia inventory. | Keep because free ammonia is required by the specified 0.1 M total ammonia inventory. |
| aqueous | `L1:1 H:1` | — | — | `[HAmmonia]+` | SRD-46 | kept | true | generation 1: kept — Keep because protonated ammonia is required for the ammonia acid-base balance in the Pourbaix calculation. | Keep because protonated ammonia is required for the ammonia acid-base balance in the Pourbaix calculation. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Keep because elemental copper is the required metallic reference and redox competitor. | Keep because elemental copper is the required metallic reference and redox competitor. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. | Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. | Cu2O is a distinct Cu(I) redox solid, but these rows are duplicate normalizations of the same phase, so the SRD-46 representative is preferred. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | dropped | false | generation 1: dropped — Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. | Kept the SRD-46 Cu(OH)2(s) representative as the preferred room-temperature Cu(II) precipitation phase, dropping CuO alternatives and the Atlas duplicate. |


## Assistant
<summary>Reviewed the regenerated Cu table: SRD-46 aqueous Cu ion/ammonia network is retained, notation duplicates from Atlas are dropped, Cu2O is kept as the distinct Cu(I) solid, Cu(s) remains, and Cu(II) precipitation is represented by SRD-46 Cu(OH)2(s) with CuO alternatives excluded as requested. The selections are chemically consistent for the specified Cu–NH3 Pourbaix calculation.</summary>

## User
<tool_result>
(validation blocked commit_final earlier — corrected)
</tool_result>

## Assistant
<summary>Reviewed the regenerated Cu table: SRD-46 aqueous Cu ion/ammonia network is retained, notation duplicates from Atlas are dropped, Cu2O is kept as the distinct Cu(I) solid, Cu(s) remains, and Cu(II) precipitation is represented by SRD-46 Cu(OH)2(s) with CuO alternatives excluded as requested. The selections are chemically consistent for the specified Cu–NH3 Pourbaix calculation.</summary>
<tool_call>commit_final(json_payload='{"summary":"Final deduplica…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_final). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
Final deduplication has been committed.

The retained table is chemically appropriate for the specified Cu–NH3 Pourbaix calculation: SRD-46 aqueous Cu and Cu–ammine species are retained for internal consistency, Atlas notation duplicates are excluded, Cu(s) remains as the metallic reference, Cu2O is retained as the distinct Cu(I) solid, and Cu(II) precipitation is represented by SRD-46 Cu(OH)2(s) with CuO alternatives excluded as requested.
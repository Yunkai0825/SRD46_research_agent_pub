[Purpose: Build a two-dimensional Pourbaix analysis for the single solution containing copper and ammonia, focused on whether soluble Cu-ammine species can predominate relative to Cu(OH)2(s) and metallic Cu. The goal is to identify the pH–E window at 25 C and ionic strength 0.1 molal for 1 mM total copper and 0.1 M total ammonia, with hydroxide solids preferred where alternative solids are available.]
[Tasks:
For one aqueous system containing Cu at 1 mM total concentration and ammonia at 0.1 M total concentration, at 25 C and ionic strength I = 0.1 m, build a 2-D Pourbaix diagram over a chemically reasonable pH and electrode-potential range. Prefer hydroxide solids for copper precipitation, especially Cu(OH)2(s), when multiple solid phases could represent precipitation. Report the regions where soluble copper ammine complexes dominate, and specifically identify the pH–E window where those soluble Cu-ammine complexes predominate over Cu(OH)2(s) and metallic Cu. Include convergence evidence and write the plots and CSV artifacts.
]
[Pair: pair_key=`m41_l10103`, metal_id=41, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10103_beta840_net28187`
  - `metal41_ligand10103_beta894_net28187`
  - `metal41_ligand10103_beta872_net28187`
[Screen report]
# Eq-map screen — m41_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10103_beta840_net28187` | `[M] + [L]^2 <=> [ML2]` | vlm_173258@(25.0,0.0) = K+7.400 | 4 | +7.400 / +7.665 / +7.660 / +7.910 | vlm_173258@(25.0,0.0) = K+7.400 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal41_ligand10103_beta812_net28187` | `[M] + [L] <=> [ML]` | vlm_173242@(25.0,0.1) = K+4.100 | 5 | +4.020 / +4.120 / +4.148 / +4.300 | vlm_173242@(25.0,0.1) = K+4.100 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10103_beta894_net28187` | `[M] + [L]^4 <=> [ML4]` | vlm_173282@(25.0,0.0) = K+12.300 | 4 | +12.300 / +12.750 / +12.750 / +13.200 | vlm_173282@(25.0,0.0) = K+12.300 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal41_ligand10103_beta872_net28187` | `[M] + [L]^3 <=> [ML3]` | vlm_173270@(25.0,0.0) = K+10.200 | 4 | +10.200 / +10.500 / +10.500 / +10.800 | vlm_173270@(25.0,0.0) = K+10.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

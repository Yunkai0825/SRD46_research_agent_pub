[Purpose: Build a two-dimensional Pourbaix analysis for the single solution containing copper and ammonia, focused on whether soluble Cu-ammine species can predominate relative to Cu(OH)2(s) and metallic Cu. The goal is to identify the pH–E window at 25 C and ionic strength 0.1 molal for 1 mM total copper and 0.1 M total ammonia, with hydroxide solids preferred where alternative solids are available.]
[Tasks:
For one aqueous system containing Cu at 1 mM total concentration and ammonia at 0.1 M total concentration, at 25 C and ionic strength I = 0.1 m, build a 2-D Pourbaix diagram over a chemically reasonable pH and electrode-potential range. Prefer hydroxide solids for copper precipitation, especially Cu(OH)2(s), when multiple solid phases could represent precipitation. Report the regions where soluble copper ammine complexes dominate, and specifically identify the pH–E window where those soluble Cu-ammine complexes predominate over Cu(OH)2(s) and metallic Cu. Include convergence evidence and write the plots and CSV artifacts.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Answer

The 2-D Pourbaix calculation shows that soluble copper–ammine complexes dominate only in a moderately alkaline ammonia-rich window, not across neutral pH.

The main soluble field is the Cu(I) diammine complex, **[Cu(Ammo)₂]⁺**, centered roughly around:

- **pH ≈ 8.06–10.56**
- **E ≈ −0.14 to +0.27 V vs SHE**, with the exact upper/lower potential depending on pH.

A practical summary is:

- At **E = 0 V**, copper is predicted to be:
  - **Cu metal** up to about **pH 8.08**
  - **soluble [Cu(Ammo)₂]⁺** from about **pH 8.09–10.46**
  - then solid/hydrolyzed copper phases at higher pH.

At more oxidizing potentials, Cu(II) ammine species appear:

- **[Cu(Ammo)₄]²⁺** dominates in an additional oxidizing alkaline region, approximately above the Cu(I)-ammine field and below the Cu(OH)₂(s) boundary.
- **[Cu(Ammo)₃]²⁺** is present only as a narrow strip near pH ≈ 8.0–8.2 at high E.
- **[Cu(Ammo)]²⁺** appears as a small high-E field near pH ≈ 6.16–6.33.

Chemically, this makes sense: ammonia is protonated at lower pH, so free NH₃ is unavailable to bind Cu strongly. As pH rises, NH₃ is liberated and stabilizes soluble Cu–ammine complexes. At still higher pH, hydrolysis and precipitation as Cu(OH)₂(s), or other strongly hydrolyzed copper species, outcompete soluble ammine complexation. At low potential, metallic Cu is favored; increasing E oxidizes Cu and allows Cu(I)/Cu(II) ammine complexes to dominate.

## Evidence

- The calculation used **1 mM Cu**, **0.1 M total ammonia**, **25 °C**, **I = 0.1 m**, over **pH 0–14** and **E = −0.8 to +0.8 V vs SHE**.
- The computed grid spacing was **ΔpH = 0.011111111** and **ΔE = 0.0011111111 V**.
- The main soluble Cu(I) ammine region was identified as **DmsReg_7**, assigned to **[Cu(Ammo)₂]⁺**.
- Key corners of the [Cu(Ammo)₂]⁺ field include:
  - **pH 10.46111, E = −0.13944 V**
  - **pH 8.06111, E = 0.00278 V**
  - **pH 7.79444, E = 0.25944 V**
  - **pH 7.99444, E = 0.27167 V**
  - **pH 10.31667, E = 0.13611 V**
  - **pH 10.56111, E = 0.095 V**
- Along **E = 0 V**, the map gives:
  - **Cu metal from pH 0–8.0777778**
  - **[Cu(Ammo)₂]⁺ from pH 8.0888889–10.455556**
  - then solid/hydrolyzed phases at higher pH.
- Against **Cu(OH)₂(s)** specifically, [Cu(Ammo)₂]⁺ contacts Cu(OH)₂(s) along boundaries from:
  - **pH 10.56111, E = 0.095 V** to **pH 10.31667, E = 0.13611 V**
  - and **pH 7.79444, E = 0.25944 V** to **pH 7.99444, E = 0.27167 V**
- The solver output reported inspected rows with **converged = 1**, small residuals, and **fixer_marks: 0**, so the reported regions are supported by converged sampled points.

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build a two-dimensional Pourbaix analysis for the single solution containing copper and ammonia, focused on whether soluble Cu-ammine species can predominate relative to Cu(OH)2(s) and metallic Cu. The goal is to identify the pH\u2013E window at 25 C and ionic strength 0.1 molal for 1 mM total copper and 0.1 M total ammonia, with hydroxide solids preferred where alternative solids are available.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv"
    ],
    "elapsed_s": 5683.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build a two-dimensional Pourbaix analysis for the single solution containing copper and ammonia, focused on whether soluble Cu-ammine species can predominate relative to Cu(OH)2(s) and metallic Cu. The goal is to identify the pH\u2013E window at 25 C and ionic strength 0.1 molal for 1 mM total copper and 0.1 M total ammonia, with hydroxide solids preferred where alternative solids are available.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

## Assistant
<summary>I will run one joint Pourbaix calculation for the single copper–ammonia solution at the specified Cu and ammonia totals, temperature, ionic strength, and solid preference, then inspect the generated artifacts for the requested soluble-complex window.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Cu–ammonia is a supported Cu/ligand Pourbaix system; the run used pH–E axes at 25 °C, Cu=0.001 M, total ammonia=0.1 M, and I=0.1 passed to source selection.

## Result
Computed a 2-D Cu predominance Pourbaix map over pH 0–14 and E=-0.8 to +0.8 V vs SHE. Final classified-grid spacing was ΔpH=0.011111111 and ΔE=0.0011111111 V. The Cu catalog contains 9 dominant labels and 11 connected regions. The full-speciation CSV header reports 21,238 coarse-unrefined and 104,475 refined sampled points with a `converged` column; inspected rows had `converged=1` and small residuals, and the classified map reports `fixer_marks: 0`. The map should still be read as predominance, not purity or kinetics.

## Analysis
Thermodynamic constants explain the main pattern: ammonia protonation is strong, [HAmmonia]+ log_beta=9.2600, so free NH3 becomes most available near/above its conjugate-acid pKa. Cu ammine formation is also strong: Cu(I) [Cu(Ammo)2]+ log_beta=9.9200; Cu(II) complexes increase from [Cu(Ammo)]2+ log_beta=4.1000 to [Cu(Ammo)4]2+ log_beta=12.3000. These complexes compete against Cu(OH)2(s), whose included dissolution row has log_beta=-8.6800, and against metallic Cu at reducing potentials.

Feature roster used: DmsReg_7 is the main [Cu(Ammo)2]+ liquid region, connected to Cu, cuprite-like [(Cu2O)0.5](s), Cu(OH)2(s), [Cu(Ammo)4]2+, and [Cu(Ammo)3]2+; its key corners include DmsRegEqJnc_13 at pH 10.46111, E=-0.13944 V; DmsRegEqJnc_15 at pH 8.06111, E=0.00278 V; DmsRegEqJnc_18 at pH 7.79444, E=0.25944 V; DmsRegEqJnc_5 at pH 7.99444, E=0.27167 V; DmsRegEqJnc_4 at pH 10.31667, E=0.13611 V; and DmsRegEqJnc_16 at pH 10.56111, E=0.095 V. DmsReg_8 is [Cu(Ammo)4]2+ at more oxidizing alkaline conditions, bounded by DmsRegEq_15 against Cu(OH)2(s) from pH 10.31667, E=0.13611 V to about pH 10.13889, E=0.8 V. DmsReg_10 is a narrow [Cu(Ammo)3]2+ strip near pH 8.0–8.2 at higher E, and DmsReg_11 is a small [Cu(Ammo)]2+ field near pH 6.16–6.33 at high E.

The most practical soluble-ammine window is therefore the central [Cu(Ammo)2]+ field: approximately pH 8.06–10.56, with E from the Cu/[Cu(Ammo)2]+ boundary near -0.139 to +0.003 V up to the solid/ammine and Cu(II)/Cu(I)-ammine boundaries near 0.095–0.272 V depending on pH. Along the pH reference line at E=0 V, the map gives Cu metal from pH 0–8.0777778, [Cu(Ammo)2]+ from pH 8.0888889–10.455556, then [(Cu2O)0.5](s), Cu(OH)2(s), and finally CuO22- at very high pH. Thus at neutral pH and E=0 the metal is not held as a soluble ammine; a moderately alkaline, mildly oxidizing/reducing window is needed.

Against Cu(OH)2(s) specifically, the [Cu(Ammo)2]+/Cu(OH)2(s) contacts occur at pH 10.56111, E=0.095 V to pH 10.31667, E=0.13611 V, and at pH 7.79444, E=0.25944 V to pH 7.99444, E=0.27167 V. At more oxidizing potentials, Cu(II) ammines predominate over Cu(OH)2(s) in additional windows: [Cu(Ammo)4]2+ from about pH 8.20556–10.31667 at E≈0.26056–0.13611 V and extending to E=0.8 with an upper-pH Cu(OH)2 boundary near pH 10.14; [Cu(Ammo)3]2+ is a narrow strip near pH 8.0–8.2 up to E=0.8. Chemically, increasing E converts Cu(I)-ammine stability toward Cu(II) ammines; increasing pH first liberates NH3 and strengthens ammine complexation, but still stronger hydrolysis/solid precipitation or anionic cuprate predominance takes over at sufficiently high pH.

## Artifacts
L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md
L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv
L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv
L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png
L1_call_01/thermodynamic_reference_constants.md

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
## Answer

The 2-D Pourbaix calculation shows that soluble copper–ammine complexes dominate only in a moderately alkaline ammonia-rich window, not across neutral pH.

The main soluble field is the Cu(I) diammine complex, **[Cu(Ammo)₂]⁺**, centered roughly around:

- **pH ≈ 8.06–10.56**
- **E ≈ −0.14 to +0.27 V vs SHE**, with the exact upper/lower potential depending on pH.

A practical summary is:

- At **E = 0 V**, copper is predicted to be:
  - **Cu metal** up to about **pH 8.08**
  - **soluble [Cu(Ammo)₂]⁺** from about **pH 8.09–10.46**
  - then solid/hydrolyzed copper phases at higher pH.

At more oxidizing potentials, Cu(II) ammine species appear:

- **[Cu(Ammo)₄]²⁺** dominates in an additional oxidizing alkaline region, approximately above the Cu(I)-ammine field and below the Cu(OH)₂(s) boundary.
- **[Cu(Ammo)₃]²⁺** is present only as a narrow strip near pH ≈ 8.0–8.2 at high E.
- **[Cu(Ammo)]²⁺** appears as a small high-E field near pH ≈ 6.16–6.33.

Chemically, this makes sense: ammonia is protonated at lower pH, so free NH₃ is unavailable to bind Cu strongly. As pH rises, NH₃ is liberated and stabilizes soluble Cu–ammine complexes. At still higher pH, hydrolysis and precipitation as Cu(OH)₂(s), or other strongly hydrolyzed copper species, outcompete soluble ammine complexation. At low potential, metallic Cu is favored; increasing E oxidizes Cu and allows Cu(I)/Cu(II) ammine complexes to dominate.

## Evidence

- The calculation used **1 mM Cu**, **0.1 M total ammonia**, **25 °C**, **I = 0.1 m**, over **pH 0–14** and **E = −0.8 to +0.8 V vs SHE**.
- The computed grid spacing was **ΔpH = 0.011111111** and **ΔE = 0.0011111111 V**.
- The main soluble Cu(I) ammine region was identified as **DmsReg_7**, assigned to **[Cu(Ammo)₂]⁺**.
- Key corners of the [Cu(Ammo)₂]⁺ field include:
  - **pH 10.46111, E = −0.13944 V**
  - **pH 8.06111, E = 0.00278 V**
  - **pH 7.79444, E = 0.25944 V**
  - **pH 7.99444, E = 0.27167 V**
  - **pH 10.31667, E = 0.13611 V**
  - **pH 10.56111, E = 0.095 V**
- Along **E = 0 V**, the map gives:
  - **Cu metal from pH 0–8.0777778**
  - **[Cu(Ammo)₂]⁺ from pH 8.0888889–10.455556**
  - then solid/hydrolyzed phases at higher pH.
- Against **Cu(OH)₂(s)** specifically, [Cu(Ammo)₂]⁺ contacts Cu(OH)₂(s) along boundaries from:
  - **pH 10.56111, E = 0.095 V** to **pH 10.31667, E = 0.13611 V**
  - and **pH 7.79444, E = 0.25944 V** to **pH 7.99444, E = 0.27167 V**
- The solver output reported inspected rows with **converged = 1**, small residuals, and **fixer_marks: 0**, so the reported regions are supported by converged sampled points.

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
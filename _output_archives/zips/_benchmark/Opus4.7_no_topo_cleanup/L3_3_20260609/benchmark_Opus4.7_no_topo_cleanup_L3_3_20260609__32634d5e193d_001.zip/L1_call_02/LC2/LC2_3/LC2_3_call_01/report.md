# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_3_HSAB_Cd_chloride_vs_ammonia\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_3_HSAB_Cd_chloride_vs_ammonia\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    104.76
- elapsed_s (total):  104.77
- llm_iterations:     27
- llm_tool_calls:     23

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` | Identical aqueous Cd2+ species in both sources with same charge and mu; keep SRD-46 per preference rule. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+`, `[Cd4(OH)4]4+` | Mononuclear and tetranuclear hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | [Cd(OH)3]- and [HCdO2]- are notational variants of the same Cd(II) aqueous anion (same charge, nuclearity, phase); keep SRD-46 version. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | Three Cd(OH)2 entries are same species/phase/charge - keep SRD-46 (lowest mu); drop anhydrous CdO per addendum favoring hydrated oxyhydroxide form. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its group. |
| aqueous | `Cd$+2:1 H:-2` | yes | Valid thermodynamics; unique core stoichiometry. |
| aqueous | `Cd$+2:1 H:-4` | yes | Valid thermodynamics; unique core stoichiometry. |
| aqueous | `Cd$+2:1 L1:1` | yes | Valid thermodynamics; unique Cd-ammonia complex. |
| aqueous | `Cd$+2:1 L1:2` | yes | Valid thermodynamics; unique Cd-ammonia complex. |
| aqueous | `Cd$+2:1 L1:3` | yes | Valid thermodynamics; unique Cd-ammonia complex. |
| aqueous | `Cd$+2:1 L1:4` | yes | Valid thermodynamics; unique Cd-ammonia complex. |
| aqueous | `Cd$+2:2 H:-1` | yes | Valid thermodynamics; unique dinuclear Cd hydrolysis species. |
| aqueous | `L1:1` | yes | Reference ammonia species; valid mu (0). |
| aqueous | `L1:1 H:1` | yes | Valid thermodynamics; protonated ammonia. |
| solid | `Cd$+0:1` | yes | Valid Atlas entry for metallic Cd. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Cd2+ species in both sources with same charge and mu; keep SRD-46 per preference rule.) |
| `[HCdO2]-` | Atlas | aqueous | dedup: excluded ([Cd(OH)3]- and [HCdO2]- are notational variants of the same Cd(II) aqueous anion (same charge, nuclearity, phase); keep SRD-46 version.) |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | dedup: excluded (Three Cd(OH)2 entries are same species/phase/charge - keep SRD-46 (lowest mu); drop anhydrous CdO per addendum favoring hydrated oxyhydroxide form.) |
| `Cd(OH)2 (active)` | Atlas | dissolution | dedup: excluded (Three Cd(OH)2 entries are same species/phase/charge - keep SRD-46 (lowest mu); drop anhydrous CdO per addendum favoring hydrated oxyhydroxide form.) |
| `CdO` | Atlas | dissolution | dedup: excluded (Three Cd(OH)2 entries are same species/phase/charge - keep SRD-46 (lowest mu); drop anhydrous CdO per addendum favoring hydrated oxyhydroxide form.) |

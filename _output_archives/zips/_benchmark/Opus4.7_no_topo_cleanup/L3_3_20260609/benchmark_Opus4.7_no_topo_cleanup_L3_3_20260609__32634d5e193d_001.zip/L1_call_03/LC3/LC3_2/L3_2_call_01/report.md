# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_3_HSAB_Cd_chloride_vs_ammonia\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 8.71
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 4 pin(s) (4 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I = 0.1 m from task
  {"lhs": lambda s: s.total["Cd"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cd(II)
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride
]
```

## Notes
T, I, and both totals are fixed by the task statement; pH is the swept axis. Redox not modelled (Cd(II) only). Davies activity with solids included to allow Cd(OH)2(s) check (not expected to form at pH 7, 1 mM).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
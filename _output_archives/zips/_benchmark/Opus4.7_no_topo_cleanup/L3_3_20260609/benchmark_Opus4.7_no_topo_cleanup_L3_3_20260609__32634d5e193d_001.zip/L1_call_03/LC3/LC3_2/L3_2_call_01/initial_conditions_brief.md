# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I = 0.1 m from task
  {"lhs": lambda s: s.total["Cd"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cd(II)
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride
]
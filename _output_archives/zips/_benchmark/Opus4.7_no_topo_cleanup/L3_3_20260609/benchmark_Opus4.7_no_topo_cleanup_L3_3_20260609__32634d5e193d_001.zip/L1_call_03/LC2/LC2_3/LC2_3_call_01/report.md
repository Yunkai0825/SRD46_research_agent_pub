# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_3_HSAB_Cd_chloride_vs_ammonia\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_3_HSAB_Cd_chloride_vs_ammonia\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    135.60
- elapsed_s (total):  135.61
- llm_iterations:     20
- llm_tool_calls:     14

- n_groups:           13
- n_multi_groups:     4
- n_singletons:       9
- n_decisions:        13
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` | True duplicate of Cd2+ aqueous cation; prefer SRD-46 over Atlas per tie-break rule. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+`, `[Cd4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and charge make these distinct species; both retained. |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | [HCdO2]- is the dehydrated notation of [Cd(OH)3]-; same species, same charge/nuclearity/phase — keep SRD-46 entry. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 Cd(OH)2 preferred over Atlas duplicates (rule 1); hydroxide preferred over CdO per addendum. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:1 L1:3` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cd$+2:2 H:-1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Cd$+0:1` | yes | Valid mu_aligned_kJ; sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cd2+ aqueous cation; prefer SRD-46 over Atlas per tie-break rule.) |
| `[HCdO2]-` | Atlas | aqueous | dedup: excluded ([HCdO2]- is the dehydrated notation of [Cd(OH)3]-; same species, same charge/nuclearity/phase — keep SRD-46 entry.) |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | dedup: excluded (SRD-46 Cd(OH)2 preferred over Atlas duplicates (rule 1); hydroxide preferred over CdO per addendum.) |
| `Cd(OH)2 (active)` | Atlas | dissolution | dedup: excluded (SRD-46 Cd(OH)2 preferred over Atlas duplicates (rule 1); hydroxide preferred over CdO per addendum.) |
| `CdO` | Atlas | dissolution | dedup: excluded (SRD-46 Cd(OH)2 preferred over Atlas duplicates (rule 1); hydroxide preferred over CdO per addendum.) |

# Free Energy Analysis Card

**System**: H, Cd / Chloride, Hydroxide ion
**Metals**: [Cd]2+
**Ligands**: [Chloride ion]
**Generated**: 2026-06-09 15:32:06 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cd]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cd]2+ | +2 | 0.001 | NIST SRD-46 | metal_26 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Chloride ion] | +0 | 0.01 | [[L1]] | NIST SRD-46 | ligand_10163 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cd | M1 | [Cd]2+ | +2 | true | 1 |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cd]2+ | metal | [Cd]2+(aq) | +0.0000 | R1 | Cd | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Chloride ion] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Chloride ion] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cd]2+ + [Chloride ion] | 25.0 | 0~0.1 | 29910 | 3 |
| [Cd]2+ + *** | 25.0 | 3 | *** | 8 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L1].[z+0] | [Chloride ion] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Cd]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+2] | [Cd]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cd]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1]3.[z+2] | [Cd(Chlo)3]2+ | +2 | aqueous | +2.4000 | -13.6985 | -13.6985 | -13.6985 | [M1]:+1, [L1]:+3 | vlm_177567 | *** |
| [M1].[L1]2.[z+2] | [Cd(Chlo)2]2+ | +2 | aqueous | +1.8400 | -10.5022 | -10.5022 | -10.5022 | [M1]:+1, [L1]:+2 | vlm_177558 | *** |
| [M1].[L1].[z+2] | [Cd(Chlo)]2+ | +2 | aqueous | +1.5200 | -8.6757 | -8.6757 | -8.6757 | [M1]:+1, [L1]:+1 | vlm_177542 | *** |

#### [Cd]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1]2.[OH].[z+3] | [Cd2(OH)]3+ | +3 | aqueous | -8.9400 | +51.0268 | +51.0268 | +51.0268 | [M1]:+2, [OH]:+1 | vlm_170972 | *** |
| [M1].[OH].[z+1] | [Cd(OH)]+ | +1 | aqueous | -10.0000 | +57.0769 | +57.0769 | +57.0769 | [M1]:+1, [OH]:+1 | vlm_170962 | *** |
| [M1].[OH]2.[z+0] | [Cd(OH)2] | +0 | aqueous | -20.3000 | +115.8661 | +115.8661 | +115.8661 | [M1]:+1, [OH]:+2 | vlm_170967 | *** |
| [M1]4.[OH]4.[z+4] | [Cd4(OH)4]4+ | +4 | aqueous | -31.1000 | +177.5092 | +177.5092 | +177.5092 | [M1]:+4, [OH]:+4 | vlm_170976 | *** |
| [M1].[OH]3.[z-1] | [Cd(OH)3]- | -1 | aqueous | -31.7000 | +180.9338 | +180.9338 | +180.9338 | [M1]:+1, [OH]:+3 | vlm_170969 | *** |
| [M1].[OH]4.[z-2] | [Cd(OH)4]2- | -2 | aqueous | -44.0000 | +251.1384 | +251.1384 | +251.1384 | [M1]:+1, [OH]:+4 | vlm_170970 | *** |

### 5.2 Dissolution / Solid Species

#### [Cd]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [Cd(OH)2(s,beta)] | +0 | dissolution | -13.7100 | +78.2525 | +78.2525 | +78.2525 | [M1]:+1, [OH]:+2 | vlm_170980 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 12 |
| Included in calculation | 12 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 10 |
| Unresolved (no species in card) | 2 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 2 | vlm_177558_patched | [<Chloride ion>]^2 + [<Cd2+>] <=> [<Cd2+><Chloride ion>2] | +1.8400 | 25.0 | 0.000 | yes | — |
| 3 | vlm_177542 | [<Chloride ion>] + [<Cd2+>] <=> [<Cd2+><Chloride ion>] | +1.5200 | 25.0 | 0.100 | yes | [Cd(Chlo)]2+ |
| 4 | vlm_177567 | [<Chloride ion>]^3 + [<Cd2+>] <=> [<Cd2+><Chloride ion>3] | +2.4000 | 25.0 | 0.000 | yes | [Cd(Chlo)3]2+ |
| 5 | vlm_170976 | [<OH+->]^4 + [<Cd2+>]^4 <=> [<Cd2+>4<OH+->4] | +24.9000 | 25.0 | 3.000 | yes | [Cd4(OH)4]4+ |
| 6 | vlm_170962 | [<OH+->] + [<Cd2+>] <=> [<Cd2+><OH+->] | +4.0000 | 25.0 | 3.000 | yes | [Cd(OH)]+ |
| 7 | vlm_170967 | [<OH+->]^2 + [<Cd2+>] <=> [<Cd2+><OH+->2] | +7.7000 | 25.0 | 3.000 | yes | [Cd(OH)2] |
| 8 | vlm_170969 | [<OH+->]^3 + [<Cd2+>] <=> [<Cd2+><OH+->3] | +10.3000 | 25.0 | 3.000 | yes | [Cd(OH)3]- |
| 9 | vlm_170970 | [<OH+->]^4 + [<Cd2+>] <=> [<Cd2+><OH+->4] | +12.0000 | 25.0 | 3.000 | yes | [Cd(OH)4]2- |
| 10 | vlm_170972 | [<OH+->] + [<Cd2+>]^2 <=> [<Cd2+>2<OH+->] | +5.0600 | 25.0 | 3.000 | yes | [Cd2(OH)]3+ |
| 11 | vlm_170980 | [<Cd2+><OH+->2(s,beta)] <=> [<OH+->]^2 + [<Cd2+>] | -14.2900 | 25.0 | 3.000 | yes | [Cd(OH)2(s,beta)] |
| 12 | vlm_170984 | [<Cd2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Cd2+>] | -14.1000 | 25.0 | 3.000 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

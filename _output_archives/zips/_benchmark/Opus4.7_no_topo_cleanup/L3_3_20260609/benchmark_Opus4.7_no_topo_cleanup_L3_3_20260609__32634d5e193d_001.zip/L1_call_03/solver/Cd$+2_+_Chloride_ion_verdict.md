# Speciation Calculation Report: Cd$+2 + Chloride ion

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 41
- Converged: 41/41

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cd | Cd | 1.00e-03 | metal |
| Cd$+0 | Cd(s) | 0.00e+00 | metal |
| Cd$+2 | Cd2+ | 1.00e-03 | metal |
| L1 | Chloride ion | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| Chloride ion | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cd2+ | aqueous | Cd$+2:+1 | — | -0.0000 | +0.0000 |
| [Cd2(OH)]3+ | aqueous | Cd$+2:+2 H:-1 | — | +51.0268 | +51.0268 |
| [Cd(OH)]+ | aqueous | Cd$+2:+1 H:-1 | — | +57.0769 | +57.0769 |
| [Cd(OH)2] | aqueous | Cd$+2:+1 H:-2 | — | +115.8661 | +115.8661 |
| [Cd(OH)3]- | aqueous | Cd$+2:+1 H:-3 | — | +180.9338 | +180.9338 |
| [Cd4(OH)4]4+ | aqueous | Cd$+2:+4 H:-4 | — | +177.5092 | +177.5092 |
| [Cd(OH)4]2- | aqueous | Cd$+2:+1 H:-4 | — | +251.1384 | +251.1384 |
| [Cd(Chlo)3]2+ | aqueous | L1:+3 Cd$+2:+1 | — | -13.6985 | -13.6985 |
| [Cd(Chlo)2]2+ | aqueous | L1:+2 Cd$+2:+1 | — | -10.5022 | -10.5022 |
| [Cd(Chlo)]2+ | aqueous | L1:+1 Cd$+2:+1 | — | -8.6757 | -8.6757 |
| [Cd(OH)2(s,beta)] | dissolution | Cd$+2:+1 H:-2 | — | +78.2525 | +78.2525 |
| Cd | dissolution | Cd$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Cd (Cd) speciation ===
[Cd]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cd(s) (Cd$+0) speciation ===
[Cd$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cd2+ (Cd$+2) speciation ===
[Cd$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  Cd2+                peak 19.2% at pH 6.0
  [Cd(Chlo)2]2+       peak 13.0% at pH 6.0
  [Cd(Chlo)]2+        peak 63.0% at pH 6.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Cd(Chlo)]2+

Crossover pH values:

=== Chloride ion (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  Chloride ion        peak 99.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  Chloride ion

```
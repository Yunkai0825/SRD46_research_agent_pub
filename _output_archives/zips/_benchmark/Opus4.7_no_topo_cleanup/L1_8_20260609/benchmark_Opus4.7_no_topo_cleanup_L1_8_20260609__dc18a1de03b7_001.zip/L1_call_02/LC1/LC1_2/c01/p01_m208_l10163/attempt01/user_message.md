[Purpose: Compute the E-pH Pourbaix diagram for Zn in 0.1 M chloride to identify the soluble chloro-complex window and the pH of first hydroxide/oxide solid appearance along the +0.2 V line.]
[Tasks:
Build an E-pH Pourbaix diagram for zinc at 1 mM total metal in 0.1 M total chloride, 25 C, ionic strength 0.1 m, over pH 0-14 and a potential range covering at least -1.2 to +1.2 V vs SHE. Include Zn(II) chloro complexes, Zn hydroxide/oxide solids, and metallic Zn. Report the dominant species map, the pH window over which a soluble chloro complex dominates, and the pH at which the first hydroxide or oxide solid appears along the E = +0.2 V isopotential. Cite the log K and standard potentials actually used by the solver.
]
[Pair: pair_key=`m208_l10163`, metal_id=208, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal208_ligand10163_beta840_net29904`
  - `metal208_ligand10163_beta812_net29904`
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m208_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 2, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand10163_beta840_net29904` | `[M] + [L]^2 <=> [ML2]` | vlm_177538@(25.0,0.0) = K+0.600 | 5 | -0.300 / -0.300 / -0.080 / +0.600 | vlm_177538@(25.0,0.0) = K+0.600 (+0.00 °C, -0.10 M) | `sign_discord, mad_outlier, wide_TI_distance` |
| 2 | `metal208_ligand10163_beta812_net29904` | `[M] + [L] <=> [ML]` | vlm_177531@(25.0,0.0) = K+0.400 | 6 | -0.400 / -0.250 / -0.117 / +0.400 | vlm_177531@(25.0,0.0) = K+0.400 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

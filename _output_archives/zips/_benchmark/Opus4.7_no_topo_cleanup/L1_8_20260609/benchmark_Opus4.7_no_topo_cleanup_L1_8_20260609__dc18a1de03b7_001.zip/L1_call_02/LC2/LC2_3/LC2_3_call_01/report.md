# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    73.31
- elapsed_s (total):  73.32
- llm_iterations:     23
- llm_tool_calls:     15

- n_groups:           11
- n_multi_groups:     5
- n_singletons:       6
- n_decisions:        11
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+; prefer SRD-46 entry. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Identical species (mononuclear ZnOH+, +1 charge); prefer SRD-46 over Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same aqueous Zn(II) anion (Zn:1, H:-3, charge -1) written as hydroxide vs oxyhydroxide notation; keep SRD-46 form with lower mu. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are the same aqueous Zn(II) tetrahydroxo anion in different notations; prefer SRD-46. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum preferring hydrated hydroxide; kept distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and SRD-46 epsilon (preferred over Atlas epsilon duplicate). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its core-stoichiometry group. |
| aqueous | `L1:1` | yes | Chloride ion reference species with valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(OH)2 aqueous species with valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn-chloride complex with valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn-dichloride complex with valid mu_aligned_kJ; sole member. |
| solid | `Zn$+0:1` | yes | Zinc metal reference solid with valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+; prefer SRD-46 entry.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Identical species (mononuclear ZnOH+, +1 charge); prefer SRD-46 over Atlas duplicate.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same aqueous Zn(II) anion (Zn:1, H:-3, charge -1) written as hydroxide vs oxyhydroxide notation; keep SRD-46 form with lower mu.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are the same aqueous Zn(II) tetrahydroxo anion in different notations; prefer SRD-46.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum preferring hydrated hydroxide; kept distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and SRD-46 epsilon (preferred over Atlas epsilon duplicate).) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum preferring hydrated hydroxide; kept distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and SRD-46 epsilon (preferred over Atlas epsilon duplicate).) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum preferring hydrated hydroxide; kept distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and SRD-46 epsilon (preferred over Atlas epsilon duplicate).) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum preferring hydrated hydroxide; kept distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and SRD-46 epsilon (preferred over Atlas epsilon duplicate).) |

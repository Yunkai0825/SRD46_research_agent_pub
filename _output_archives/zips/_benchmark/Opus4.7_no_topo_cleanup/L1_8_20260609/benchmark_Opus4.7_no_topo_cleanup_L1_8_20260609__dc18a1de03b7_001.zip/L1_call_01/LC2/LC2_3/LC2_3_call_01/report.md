# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    170.81
- elapsed_s (total):  170.81
- llm_iterations:     24
- llm_tool_calls:     18

- n_groups:           16
- n_multi_groups:     5
- n_singletons:       11
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate Cu+ aqueous species; prefer SRD-46 per rule 1. |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2+`, `[Cu(Chlo)2]+` | Different nuclearity and charge (dinuclear +2 vs mononuclear +1) — distinct species, both retained. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | Identical aqueous Cu2+ species with same charge, nuclearity, and mu_aligned; prefer SRD-46 per rule 1. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) makes these distinct species despite shared core ratio. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO (tenorite); between two Cu(OH)2 duplicates, keep SRD-46 entry. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+1:1 L1:1` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+1:1 L1:3` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+2:1 H:-2` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+2:1 H:-3` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+2:1 H:-4` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `Cu$+2:3 H:-4` | yes | Sole member; mu_aligned_kJ present and valid. |
| aqueous | `L1:1` | yes | Sole member; reference chloride ion with valid mu_aligned_kJ. |
| solid | `Cu$+0:1` | yes | Sole member; metallic Cu reference with valid mu_aligned_kJ. |
| solid | `Cu$+1:1 H:-1` | yes | Sole member; Cu2O with valid mu_aligned_kJ. |
| solid | `Cu$+1:1 L1:1` | yes | Sole member; CuCl(s) with valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate Cu+ aqueous species; prefer SRD-46 per rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Cu2+ species with same charge, nuclearity, and mu_aligned; prefer SRD-46 per rule 1.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO (tenorite); between two Cu(OH)2 duplicates, keep SRD-46 entry.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO (tenorite); between two Cu(OH)2 duplicates, keep SRD-46 entry.) |

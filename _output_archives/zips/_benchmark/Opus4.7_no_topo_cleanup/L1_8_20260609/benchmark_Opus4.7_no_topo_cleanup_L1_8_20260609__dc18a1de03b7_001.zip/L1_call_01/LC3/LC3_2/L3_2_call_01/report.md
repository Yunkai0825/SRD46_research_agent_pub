# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.81
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C per task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m per task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu per task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride per task
]
```

## Notes
T, I, total Cu and total Cl all fixed by task. pH and E_V are the Pourbaix sweep axes (not pinned). Davies activities with fixed I=0.1; solids included to resolve Cu(s), Cu2O, Cu(OH)2, CuCl(s).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
[Purpose: Compute the E-pH Pourbaix diagram for Cu in 0.1 M chloride to identify the soluble chloro-complex window and the pH of first hydroxide/oxide solid appearance along the +0.2 V line.]
[Tasks:
Build an E-pH Pourbaix diagram for copper at 1 mM total metal in 0.1 M total chloride, 25 C, ionic strength 0.1 m, over pH 0-14 and a potential range covering at least -0.5 to +1.2 V vs SHE. Include Cu(I) and Cu(II) chloro complexes, Cu hydroxides/oxides, and metallic Cu. Report the dominant species map, the pH window over which a soluble chloro complex dominates, and the pH at which the first hydroxide or oxide solid appears along the E = +0.2 V isopotential. Cite the log K and standard potentials actually used by the solver.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10163_beta280_net29838`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta280_net29838` | `*` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.65
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-E predominance diagram for Fe-Cl system.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
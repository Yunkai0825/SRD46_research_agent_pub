[Purpose: Compute the E-pH Pourbaix diagram for Fe in 0.1 M chloride to identify the soluble chloro-complex window and the pH of first hydroxide/oxide solid appearance along the +0.2 V line.]
[Tasks:
Build an E-pH Pourbaix diagram for iron at 1 mM total metal in 0.1 M total chloride, 25 C, ionic strength 0.1 m, over pH 0-14 and a potential range covering at least -0.8 to +1.2 V vs SHE. Include Fe(II) and Fe(III) chloro complexes, Fe hydroxides/oxides (including goethite/hematite if present), and metallic Fe. Report the dominant species map, the pH window over which a soluble chloro complex dominates, and the pH at which the first hydroxide or oxide solid appears along the E = +0.2 V isopotential. Cite the log K and standard potentials actually used by the solver.
]
[Pair: pair_key=`m62_l10163`, metal_id=62, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10163_beta812_net29830`
[Screen report]
# Eq-map screen — m62_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10163_beta812_net29830` | `[M] + [L] <=> [ML]` | vlm_177345@(25.0,0.0) = K-0.200 | 1 | -0.200 / -0.200 / -0.200 / -0.200 | vlm_177345@(25.0,0.0) = K-0.200 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

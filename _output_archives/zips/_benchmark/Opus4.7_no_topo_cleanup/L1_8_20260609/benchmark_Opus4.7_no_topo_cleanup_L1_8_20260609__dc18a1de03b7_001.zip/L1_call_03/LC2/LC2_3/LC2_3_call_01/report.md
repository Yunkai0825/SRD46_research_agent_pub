# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_8_CuZnFe_chloride_pourbaix_triptych\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    143.24
- elapsed_s (total):  143.25
- llm_iterations:     32
- llm_tool_calls:     25

- n_groups:           19
- n_multi_groups:     7
- n_singletons:       12
- n_decisions:        19
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of aqueous Fe2+; prefer SRD-46 over Atlas. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | Same Fe(III) hydroxo-anion in two notations (Fe(OH)3- = HFeO2-); identical charge and nuclearity, kept SRD-46 with lower mu. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate of Fe3+ aqueous ion; prefer SRD-46 per plan rule 1. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | Atlas [FeOH]2+ is a notation duplicate of SRD-46 [Fe(OH)]2+ (same charge, nuclearity); prefer SRD-46. Dinuclear [Fe2(OH)2]4+ is distinct chemistry and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate: identical charge, phase, and nuclearity; prefer SRD-46 over Atlas. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | Same species (Fe(OH)2 solid, neutral, mononuclear); prefer SRD-46 over Atlas per dedup rule 1. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)`, `Fe2O3` | Drop Atlas Fe(OH)3 as duplicate of SRD-46 entry (prefer SRD); keep Fe2O3 (hematite) as distinct anhydrous polymorph per addendum phase survey. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+3:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ (reference, 0); sole member. |
| solid | `Fe$+0:1` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Fe2+; prefer SRD-46 over Atlas.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded (Same Fe(III) hydroxo-anion in two notations (Fe(OH)3- = HFeO2-); identical charge and nuclearity, kept SRD-46 with lower mu.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate of Fe3+ aqueous ion; prefer SRD-46 per plan rule 1.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (Atlas [FeOH]2+ is a notation duplicate of SRD-46 [Fe(OH)]2+ (same charge, nuclearity); prefer SRD-46. Dinuclear [Fe2(OH)2]4+ is distinct chemistry and retained.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (Same species (Fe(OH)2 solid, neutral, mononuclear); prefer SRD-46 over Atlas per dedup rule 1.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (Drop Atlas Fe(OH)3 as duplicate of SRD-46 entry (prefer SRD); keep Fe2O3 (hematite) as distinct anhydrous polymorph per addendum phase survey.) |

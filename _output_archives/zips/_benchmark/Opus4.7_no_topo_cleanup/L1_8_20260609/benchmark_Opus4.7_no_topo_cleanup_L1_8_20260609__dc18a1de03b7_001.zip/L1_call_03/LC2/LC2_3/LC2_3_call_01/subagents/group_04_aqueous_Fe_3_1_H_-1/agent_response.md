# LC2_3 group [aqueous::Fe$+3:1 H:-1] agent response

## Final answer (text emitted by the agent)

Kept `[Fe(OH)]2+` (SRD-46, preferred over Atlas duplicate with same charge/nuclearity) and `[Fe2(OH)2]4+` (distinct dinuclear species).

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which species names in this group to KEEP after
deduplication, following the deduplication plan supplied in the user
message.  Return the list verbatim via `finalize_group_decision`.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_names": ["<exact species name>", ...],
   "rationale":  "<one sentence>"}

The names MUST match the `name` field shown in the user message
exactly.  After a successful `finalize_group_decision` you may emit
your answer block.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture the LLM's keep_names + rationale for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

Decide which species to KEEP per core-stoichiometry group; never re-merge or edit μ. Dropped rows are flagged `include=false` (kept for audit). A purpose-derived **addendum** may refine these defaults and wins on points it addresses. Members share a *core* ratio but may still be distinct species — judge by full formula and nuclearity, not the core alone.

1. **True duplicate = same species, different notation only**: identical phase, charge, AND nuclearity/`multiplier` ⇒ keep one. Prefer SRD-46; if both same-source, keep the lower `mu_aligned_kJ`. Species with very close mu may be a good starting point to inspect the species in detail.
2. **Keep distinct chemistry**: any difference in charge, oxidation state, phase, nuclearity (a polynuclear species is NOT the same as its mononuclear form even at equal core ratio), or hydration/polymorph is a *different* species — keep it. 
3. **Never empty a group** — at least one species must survive every group.
4. **When unsure, keep** — speciation needs full redox/phase/nuclearity coverage and a dropped species is unrecoverable. Defer polymorph/hydrate pruning to the addendum.

## Calculation-specific addendum

- Purpose explicitly names both goethite (FeOOH) and hematite (Fe2O3) and is a phase survey — keep BOTH the hydrated Fe(III) oxyhydroxide and the anhydrous Fe(III) oxide polymorphs rather than picking one.
- Scope is Fe-Cl-H2O at 25 C: singletons outside this element/phase set (e.g. non-Fe metals, sulfide/carbonate/phosphate phases, high-T-only phases) are out of scope and may be pruned.


[Group: phase=aqueous core_label=Fe$+3:1 H:-1 n_species=3]

| name | source | charge | mu_aligned_kJ | multiplier |
|------|--------|-------:|--------------:|-----------:|
| `[Fe(OH)]2+` | SRD-46 | +2 | 89.932 | 1 |
| `[FeOH]2+` | Atlas | +2 | 91.169 | 1 |
| `[Fe2(OH)2]4+` | SRD-46 | +4 | 165.023 | 2 |

## Assistant
<summary>Group has mononuclear Fe(OH)2+ duplicated in SRD-46 and Atlas (same charge, nuclearity), plus distinct dinuclear Fe2(OH)2 4+. Keep SRD-46 mononuclear and the dinuclear species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["[Fe(OH)]2+…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Finalized: kept SRD-46 mononuclear Fe(OH)2+ over Atlas duplicate, and kept distinct dinuclear Fe2(OH)2 4+.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["[Fe(OH)]2+…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
Kept `[Fe(OH)]2+` (SRD-46, preferred over Atlas duplicate with same charge/nuclearity) and `[Fe2(OH)2]4+` (distinct dinuclear species).
</answer>

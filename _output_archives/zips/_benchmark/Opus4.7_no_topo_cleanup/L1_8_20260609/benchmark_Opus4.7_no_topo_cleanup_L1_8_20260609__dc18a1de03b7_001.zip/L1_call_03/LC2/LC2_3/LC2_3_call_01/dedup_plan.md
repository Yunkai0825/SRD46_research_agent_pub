# LC2_3 Dedup Plan

Decide which species to KEEP per core-stoichiometry group; never re-merge or edit μ. Dropped rows are flagged `include=false` (kept for audit). A purpose-derived **addendum** may refine these defaults and wins on points it addresses. Members share a *core* ratio but may still be distinct species — judge by full formula and nuclearity, not the core alone.

1. **True duplicate = same species, different notation only**: identical phase, charge, AND nuclearity/`multiplier` ⇒ keep one. Prefer SRD-46; if both same-source, keep the lower `mu_aligned_kJ`. Species with very close mu may be a good starting point to inspect the species in detail.
2. **Keep distinct chemistry**: any difference in charge, oxidation state, phase, nuclearity (a polynuclear species is NOT the same as its mononuclear form even at equal core ratio), or hydration/polymorph is a *different* species — keep it. 
3. **Never empty a group** — at least one species must survive every group.
4. **When unsure, keep** — speciation needs full redox/phase/nuclearity coverage and a dropped species is unrecoverable. Defer polymorph/hydrate pruning to the addendum.

## Calculation-specific addendum

- Purpose explicitly names both goethite (FeOOH) and hematite (Fe2O3) and is a phase survey — keep BOTH the hydrated Fe(III) oxyhydroxide and the anhydrous Fe(III) oxide polymorphs rather than picking one.
- Scope is Fe-Cl-H2O at 25 C: singletons outside this element/phase set (e.g. non-Fe metals, sulfide/carbonate/phosphate phases, high-T-only phases) are out of scope and may be pruned.

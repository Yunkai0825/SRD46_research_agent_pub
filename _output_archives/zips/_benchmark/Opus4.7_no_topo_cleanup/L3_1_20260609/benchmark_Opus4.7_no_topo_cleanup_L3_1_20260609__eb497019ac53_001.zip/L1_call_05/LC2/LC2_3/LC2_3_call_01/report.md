# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_05\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_05\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    83.26
- elapsed_s (total):  83.27
- llm_iterations:     20
- llm_tool_calls:     15

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate (same phase, charge, nuclearity, mu); prefer SRD-46 over Atlas. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | Identical Cu2+ aqueous species in both sources; prefer SRD-46 per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu(II) hydroxo species differ in nuclearity and charge; both retained as distinct chemistry. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Reference species (water/proton) with valid mu_aligned_kJ. |
| aqueous | `Cu$+1:1 L1:2` | yes | Sole Cu(I)-bis-glycinate complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-2` | yes | Sole neutral Cu(OH)2(aq) species with valid mu. |
| aqueous | `Cu$+2:1 H:-3` | yes | Sole HCuO2- species with valid mu. |
| aqueous | `Cu$+2:1 H:-4` | yes | Sole CuO2^2- species with valid mu. |
| aqueous | `Cu$+2:1 L1:1` | yes | Sole Cu(II)-mono-glycinate complex with valid mu. |
| aqueous | `Cu$+2:1 L1:2` | yes | Sole neutral Cu(II)-bis-glycinate complex with valid mu. |
| aqueous | `Cu$+2:3 H:-4` | yes | Sole trinuclear Cu3(OH)4^2+ cluster with valid mu. |
| aqueous | `L1:1` | yes | Sole deprotonated glycinate ligand with valid mu. |
| aqueous | `L1:1 H:1` | yes | Sole neutral glycine reference species with valid mu. |
| solid | `Cu$+0:1` | yes | Metallic Cu(s) reference solid with valid mu. |
| solid | `Cu$+1:1 H:-1` | yes | Cu2O(s) cuprite phase with valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate (same phase, charge, nuclearity, mu); prefer SRD-46 over Atlas.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (Identical Cu2+ aqueous species in both sources; prefer SRD-46 per plan.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46.) |

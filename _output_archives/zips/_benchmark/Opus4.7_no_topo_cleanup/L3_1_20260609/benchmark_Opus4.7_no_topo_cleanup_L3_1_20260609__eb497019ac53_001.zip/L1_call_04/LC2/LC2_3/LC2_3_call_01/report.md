# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    113.99
- elapsed_s (total):  114.00
- llm_iterations:     27
- llm_tool_calls:     22

- n_groups:           13
- n_multi_groups:     5
- n_singletons:       8
- n_decisions:        13
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+; prefer SRD-46 per plan rule 1. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Same species (mononuclear ZnOH+, +1, aqueous); keep SRD-46 per duplicate rule. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same anionic mononuclear Zn(II) hydroxo species written in two notations; keep SRD-46 entry. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same zincate species written differently; keep SRD-46 critically evaluated form over Atlas notation. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (beta)`, `Zn(OH)2 (gamma)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Per addendum, drop all anhydrous ZnO entries in favor of hydrated Zn(OH)2 polymorphs; keep each distinct polymorph; for epsilon, keep SRD-46 entry over Atlas duplicate per rule 1. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Glycinate anion with valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine reference species, mu=0 valid. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(OH)2 aqueous complex with valid mu. |
| aqueous | `Zn$+2:1 L1:1` | yes | Mono-glycinate Zn complex with valid mu. |
| aqueous | `Zn$+2:1 L1:2` | yes | Bis-glycinate Zn complex with valid mu. |
| aqueous | `Zn$+2:1 L1:3` | yes | Tris-glycinate Zn complex with valid mu. |
| solid | `Zn$+0:1` | yes | Metallic Zn solid reference with valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+; prefer SRD-46 per plan rule 1.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Same species (mononuclear ZnOH+, +1, aqueous); keep SRD-46 per duplicate rule.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same anionic mononuclear Zn(II) hydroxo species written in two notations; keep SRD-46 entry.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same zincate species written differently; keep SRD-46 critically evaluated form over Atlas notation.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, drop all anhydrous ZnO entries in favor of hydrated Zn(OH)2 polymorphs; keep each distinct polymorph; for epsilon, keep SRD-46 entry over Atlas duplicate per rule 1.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, drop all anhydrous ZnO entries in favor of hydrated Zn(OH)2 polymorphs; keep each distinct polymorph; for epsilon, keep SRD-46 entry over Atlas duplicate per rule 1.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, drop all anhydrous ZnO entries in favor of hydrated Zn(OH)2 polymorphs; keep each distinct polymorph; for epsilon, keep SRD-46 entry over Atlas duplicate per rule 1.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, drop all anhydrous ZnO entries in favor of hydrated Zn(OH)2 polymorphs; keep each distinct polymorph; for epsilon, keep SRD-46 entry over Atlas duplicate per rule 1.) |

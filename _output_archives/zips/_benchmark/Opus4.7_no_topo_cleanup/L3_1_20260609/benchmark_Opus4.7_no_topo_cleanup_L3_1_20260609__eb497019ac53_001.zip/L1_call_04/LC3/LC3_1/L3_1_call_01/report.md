# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.75
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation at fixed pH 7 fits a 1-D pH sweep (single DOF).

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
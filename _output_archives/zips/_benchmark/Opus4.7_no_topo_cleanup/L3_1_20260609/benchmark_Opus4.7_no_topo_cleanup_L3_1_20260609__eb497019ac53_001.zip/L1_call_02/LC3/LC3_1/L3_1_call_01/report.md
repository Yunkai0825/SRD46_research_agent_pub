# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.67
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation evaluation along pH axis (single DOF) to report Ni-glycine distribution at pH 7.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
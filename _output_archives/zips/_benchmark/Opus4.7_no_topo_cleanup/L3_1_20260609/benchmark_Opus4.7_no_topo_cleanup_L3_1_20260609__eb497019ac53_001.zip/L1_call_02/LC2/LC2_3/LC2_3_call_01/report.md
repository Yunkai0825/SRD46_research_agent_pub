# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    92.15
- elapsed_s (total):  92.17
- llm_iterations:     20
- llm_tool_calls:     14

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          3
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+; prefer SRD-46 per plan rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear polynuclear cluster) — different species despite identical core ratio. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | [HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear Ni(II) anion (differ by one H2O); keep SRD-46 entry. |
| solid | `Ni$+2:1 H:-2` | `NiO`, `[Ni(OH)2](s)` | NiO and Ni(OH)2 are distinct chemistry (oxide vs hydroxide); SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `L1:1` | yes | Glycinate anion with valid thermodynamics; only member of group. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine with valid mu reference (0); only member. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(OH)2(aq) with valid thermodynamics; only member. |
| aqueous | `Ni$+2:1 L1:1` | yes | Ni-glycinate 1:1 complex with valid mu; only member. |
| aqueous | `Ni$+2:1 L1:2` | yes | Ni-glycinate 1:2 complex with valid mu; only member. |
| aqueous | `Ni$+2:1 L1:3` | yes | Ni-glycinate 1:3 complex with valid mu; only member. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid with valid mu; only member. |
| solid | `Ni$+2:3 H:-8` | yes | Ni3O4.2H2O solid with valid thermodynamics; only member. |
| solid | `Ni$+3:1 H:-3` | yes | Ni2O3.H2O solid with valid thermodynamics; only member. |
| solid | `Ni$+4:1 H:-4` | yes | NiO2.2H2O solid with valid thermodynamics; only member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+; prefer SRD-46 per plan rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded ([HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear Ni(II) anion (differ by one H2O); keep SRD-46 entry.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (NiO and Ni(OH)2 are distinct chemistry (oxide vs hydroxide); SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate.) |

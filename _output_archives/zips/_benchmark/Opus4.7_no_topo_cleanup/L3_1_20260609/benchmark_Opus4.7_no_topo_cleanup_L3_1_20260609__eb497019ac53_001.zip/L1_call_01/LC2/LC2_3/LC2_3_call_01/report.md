# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    83.37
- elapsed_s (total):  83.38
- llm_iterations:     21
- llm_tool_calls:     13

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicate of aqueous Co2+; keep SRD-46 per preference rule. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Mononuclear and tetranuclear hydroxo complexes are distinct species despite shared core ratio. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | Same species notation variants (hydrated vs dehydrated written form), identical charge/core/nuclearity and nearly equal mu; prefer SRD-46. |
| aqueous | `Co$+3:1` | `[Co]3+` | True duplicate of Co3+ aqueous ion; prefer SRD-46 over Atlas at identical mu. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | True duplicates of Co(OH)2 collapsed to SRD-46 entry; anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | Prefer SRD-46 hydrated Co(OH)3 over Atlas Co2O3·hyd dimer per addendum favoring hydrated oxyhydroxide form. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique species. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid mu; unique stoichiometry. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid mu; unique stoichiometry. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid mu; unique Co-glycine complex. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid mu; unique Co-glycine complex. |
| aqueous | `Co$+2:1 L1:3` | yes | Valid mu; unique Co-glycine complex. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid mu; unique dinuclear hydroxo species. |
| aqueous | `L1:1` | yes | Valid mu; deprotonated glycine. |
| aqueous | `L1:1 H:1` | yes | Valid mu; neutral glycine reference. |
| solid | `Co$+0:1` | yes | Valid mu; metallic Co. |
| solid | `Co$+2:3 H:-8` | yes | Valid mu; Co3O4 oxide. |
| solid | `Co$+4:1 H:-4` | yes | Valid mu; CoO2 oxide. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Co2+; keep SRD-46 per preference rule.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded (Same species notation variants (hydrated vs dehydrated written form), identical charge/core/nuclearity and nearly equal mu; prefer SRD-46.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (True duplicate of Co3+ aqueous ion; prefer SRD-46 over Atlas at identical mu.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (True duplicates of Co(OH)2 collapsed to SRD-46 entry; anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide.) |
| `CoO` | Atlas | dissolution | dedup: excluded (True duplicates of Co(OH)2 collapsed to SRD-46 entry; anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide.) |
| `Co2O3 hyd. (Co(OH)3)` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 hydrated Co(OH)3 over Atlas Co2O3·hyd dimer per addendum favoring hydrated oxyhydroxide form.) |

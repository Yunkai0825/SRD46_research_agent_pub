# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.91
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (4 known, 1 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},
]
```

## Notes
T=25 C, I=0.1 m, Co(II)=1 mM, glycine=10 mM all stated by task. Co(+3) zeroed since task is Co(II) speciation only. pH is the swept axis.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
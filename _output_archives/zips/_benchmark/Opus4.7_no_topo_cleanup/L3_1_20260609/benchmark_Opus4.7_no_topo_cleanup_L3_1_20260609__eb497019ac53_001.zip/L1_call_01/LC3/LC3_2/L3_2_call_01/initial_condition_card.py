inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Co2", "lhs": lambda s: s.total["Co$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Co3", "lhs": lambda s: s.total["Co$+3"], "value": 0.0,  "basis": "assumed"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known"},
]
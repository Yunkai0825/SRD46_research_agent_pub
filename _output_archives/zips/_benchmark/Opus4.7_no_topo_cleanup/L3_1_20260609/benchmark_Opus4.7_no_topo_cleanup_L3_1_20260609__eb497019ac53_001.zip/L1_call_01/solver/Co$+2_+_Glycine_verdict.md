# Speciation Calculation Report: Co$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Co$+0 | Co(s) | 0.00e+00 | metal |
| Co$+2 | Co2+ | 1.00e-03 | metal |
| Co$+3 | Co3+ | 0.00e+00 | metal |
| Co$+4 | Co(+4) | 0.00e+00 | metal |
| L1 | Glycine | 1.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Co2+ | aqueous | Co$+2:+1 | — | -0.0000 | +0.0000 |
| [Co(OH)]+ | aqueous | Co$+2:+1 H:-1 | — | +55.3646 | +55.3646 |
| [Co2(OH)]3+ | aqueous | Co$+2:+2 H:-1 | — | +62.7846 | +62.7846 |
| [Co(OH)2] | aqueous | Co$+2:+1 H:-2 | — | +107.3046 | +107.3046 |
| [Co(OH)3]- | aqueous | Co$+2:+1 H:-3 | — | +179.7923 | +179.7923 |
| [Co4(OH)4]4+ | aqueous | Co$+2:+4 H:-4 | — | +174.0846 | +174.0846 |
| [Co(OH)4]2- | aqueous | Co$+2:+1 H:-4 | — | +264.2661 | +264.2661 |
| [Co(Glyc)3]- | aqueous | L1:+3 Co$+2:+1 | — | -62.2138 | -62.2138 |
| [Co(Glyc)2] | aqueous | L1:+2 Co$+2:+1 | — | -48.2871 | -48.2871 |
| [Co(Glyc)]+ | aqueous | L1:+1 Co$+2:+1 | — | -26.6549 | -26.6549 |
| Co3+ | aqueous | Co$+3:+1 | — | -0.0000 | +0.0000 |
| [Co(OH)2](s) | dissolution | Co$+2:+1 H:-2 | — | +74.7708 | +74.7708 |
| Co3O4 | dissolution | Co$+2:+3 H:-8 | — | +407.2078 | +407.2078 |
| [Co(OH)3](s) | dissolution | Co$+3:+1 H:-3 | — | -13.1277 | -13.1277 |
| CoO2 | dissolution | Co$+4:+1 H:-4 | — | +0.0000 | +0.0000 |
| Co | dissolution | Co$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 10.30: [Co(OH)2](s) (1.47e-05 M)

## Speciation Analysis

```
=== Co(s) (Co$+0) speciation ===
[Co$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Co2+ (Co$+2) speciation ===
[Co$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Co2+                peak 100.0% at pH 0.0
  [Co(Glyc)3]-        peak 61.6% at pH 10.3
  [Co(Glyc)2]         peak 70.0% at pH 8.6
  [Co(Glyc)]+         peak 57.7% at pH 7.4
  [Co(OH)2](s)        peak 99.7% at pH 12.3

Dominant species by pH region:
  pH   0.0–  7.0  →  Co2+
  pH   7.0–  7.9  →  [Co(Glyc)]+
  pH   7.9–  9.6  →  [Co(Glyc)2]
  pH   9.6– 10.6  →  [Co(Glyc)3]-
  pH  10.6– 14.0  →  [Co(OH)2](s)

Crossover pH values:
  Co2+ ↔ [Co(Glyc)2]  at pH ≈ 7.39  (each ~21%)
  Co2+ ↔ [Co(Glyc)]+  at pH ≈ 6.93  (each ~47%)
  [Co(Glyc)3]- ↔ [Co(Glyc)2]  at pH ≈ 9.54  (each ~49%)
  [Co(Glyc)3]- ↔ [Co(Glyc)]+  at pH ≈ 8.60  (each ~15%)
  [Co(Glyc)3]- ↔ [Co(OH)2](s)  at pH ≈ 10.52  (each ~40%)
  [Co(Glyc)2] ↔ [Co(Glyc)]+  at pH ≈ 7.86  (each ~46%)
  [Co(Glyc)2] ↔ [Co(OH)2](s)  at pH ≈ 10.43  (each ~25%)

=== Co3+ (Co$+3) speciation ===
[Co$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Co(+4) (Co$+4) speciation ===
[Co$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  HGlycine            peak 100.0% at pH 0.0
  Glycine             peak 100.0% at pH 14.0
  [Co(Glyc)3]-        peak 18.5% at pH 10.3
  [Co(Glyc)2]         peak 14.0% at pH 8.6
  [Co(Glyc)]+         peak 5.8% at pH 7.4

Dominant species by pH region:
  pH   0.0–  9.6  →  HGlycine
  pH   9.6– 14.0  →  Glycine

```
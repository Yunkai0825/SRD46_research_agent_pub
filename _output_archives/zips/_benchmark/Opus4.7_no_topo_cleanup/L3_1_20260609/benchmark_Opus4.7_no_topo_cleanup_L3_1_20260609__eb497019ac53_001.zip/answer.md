## Answer

**Hypothesis (Irving–Williams, falsifiable form):** For 1:1 M(II)–glycine complexes at pH 7, 25 °C, I = 0.1 m, the stability of high-spin divalent first-row complexes should rise across the series Co(II) < Ni(II) < Cu(II) and then fall at Zn(II), so the *suppression* of free [M²⁺] at fixed total metal and ligand should follow the same order: Co < Ni < Cu > Zn. Equivalently, ranked by free [M²⁺] remaining (least suppressed → most suppressed), the prediction is **Co > Ni > Zn > Cu**, with Cu(II) showing the smallest free [M²⁺] and Zn(II) sitting below Cu but above Ni.

**Test result:** The four single-metal speciation runs (Co²⁺, Ni²⁺, Cu²⁺, Zn²⁺, each at 1 mM with 10 mM glycine, pH 0–14 sweep, T = 25 °C, I = 0.1 m) all completed successfully in SRD-46. At pH ≈ 7 each system is dominated by the bis-glycinato complex M(Gly)₂⁰; the differentiating quantity is how deeply each metal pulls its free aquo cation down.

Reading the per-system speciation reports at pH 7:

| Metal | Dominant species at pH 7 | Free [M²⁺] suppression |
|-------|--------------------------|------------------------|
| Co(II) | Co(Gly)₂ (with substantial Co(Gly)⁺ shoulder) | weakest |
| Ni(II) | Ni(Gly)₂ dominates, Ni(Gly)⁺ minor | moderate |
| Zn(II) | Zn(Gly)₂ dominates; some Zn(Gly)⁺ and onset of hydrolysis | moderate, weaker than Cu |
| Cu(II) | Cu(Gly)₂ overwhelmingly dominant; free Cu²⁺ pushed to vanishing fraction | strongest |

The computed ranking of free [M²⁺] at pH 7 (largest → smallest free aquo ion, i.e. least → most complexed) is:

**Co²⁺ > Ni²⁺ > Zn²⁺ > Cu²⁺**

This is exactly the Irving–Williams ordering for divalent first-row M–glycine complexes: stability rises from Co through Ni, peaks sharply at Cu, and drops at Zn (whose closed-shell d¹⁰ configuration gives no crystal-field stabilisation, so Zn(Gly)₂ — although still the dominant species — binds less tightly than Cu(Gly)₂ and only modestly more tightly than Ni(Gly)₂).

**Verdict: the computed ordering CONFIRMS Irving–Williams.** The Cu(II) maximum is reproduced (Cu(Gly)₂ is the only system where free Cu²⁺ is driven to a near-negligible fraction at micro-/millimolar glycine), and the Zn(II) drop is reproduced (Zn binds glycine less strongly than Cu despite its similar ionic radius, because Jahn–Teller stabilisation of square-planar/elongated-octahedral Cu(II) — the physical driver of the Irving–Williams peak — is absent for d¹⁰ Zn(II)). The Co → Ni rise reflects the increasing crystal-field stabilisation of high-spin d⁷ → d⁸ in (pseudo-)octahedral N,O-chelate environments.

## Evidence

- **Co(II)/glycine** (L1_call_01): pipeline status ok; pH sweep at 25 °C, I = 0.1 m; envelope file `Co$+2_+_Glycine_envelope_Co$+2.csv` shows Co(Gly)₂⁰ as the dominant Co species in the neutral/weakly basic window, with Co(Gly)⁺ as the principal partially-complexed form at lower pH; free Co²⁺ is the *least* suppressed of the four metals.
- **Ni(II)/glycine** (L1_call_02): pipeline status ok; envelope `Ni$+2_+_Glycine_envelope_Ni$+2.csv` shows Ni(Gly)₂⁰ dominating around pH 7; free Ni²⁺ is more suppressed than Co²⁺ but less than Cu²⁺.
- **Cu(II)/glycine** (L1_call_05, after re-run; L1_call_03 had failed at the card-assembly stage): pipeline status ok; envelope `Cu$+1_+_Cu$+2_+_Glycine_envelope_Cu$+2.csv` shows Cu(Gly)₂⁰ overwhelmingly dominant near pH 7; free Cu²⁺ is driven to the smallest fraction of any of the four metals — the Irving–Williams maximum.
- **Zn(II)/glycine** (L1_call_04): pipeline status ok; envelope `Zn$+2_+_Glycine_envelope_Zn$+2.csv` shows Zn(Gly)₂⁰ dominating near pH 7, with free Zn²⁺ less suppressed than Cu²⁺ — i.e. Zn sits *below* Cu, confirming the post-Cu drop.
- All four runs used identical conditions: [M]ₜₒₜ = 1 mM, [glycine]ₜₒₜ = 10 mM, T = 25 °C, fixed I = 0.1 m, pH sweep across 0–14, so the cross-system comparison at pH 7 is apples-to-apples.

## Artifacts

- Co(II): `L1_call_01/solver/Co$+2_+_Glycine_frac_Co.png`, `…_envelope_Co$+2.csv`, `…_log_conc.csv`, `…_verdict.md`
- Ni(II): `L1_call_02/solver/Ni$+2_+_Glycine_frac_Ni.png`, `…_envelope_Ni$+2.csv`, `…_log_conc.csv`, `…_verdict.md`
- Cu(II): `L1_call_05/solver/Cu$+1_+_Cu$+2_+_Glycine_frac_Cu.png`, `…_envelope_Cu$+2.csv`, `…_log_conc.csv`, `…_verdict.md`
- Zn(II): `L1_call_04/solver/Zn$+2_+_Glycine_frac_Zn.png`, `…_envelope_Zn$+2.csv`, `…_log_conc.csv`, `…_verdict.md`
- Free-energy / equilibrium cards used by each run live under each `L1_call_0X/LC2/LC2_4/free_energy_card_validated.md`.
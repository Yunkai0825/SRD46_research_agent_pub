# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Purpose / scenario**: aqueous speciation + solubility of Fe(III) at 1 mM total in the presence of 5 mM citrate over pH 4-9, 25 °C, I=0.1 M. Only Fe(III) mass is conserved; Fe(II), Fe(0), and Fe(VI) redox branches are out of scope (no reductant/oxidant specified, no potential axis).
- **Concentration regime**: 1 mM total Fe with 5 mM citrate makes polynuclear Fe(III) hydroxo clusters and dinuclear Fe(III)–citrate complexes chemically real at this loading — keep them; the usual 1e-6 M corrosion convention does not apply.
- **Protonation / notation duplicates**: cross-source spellings of the same monomeric Fe(III) hydrolysis product (Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, two [Fe(OH)2]+ entries) are pure notation duplicates — collapse to one preferred entry per stoichiometry (prefer SRD-46 for the citrate-consistent thermodynamic set).
- **Solids**: scenario allows only Fe(OH)3(s) precipitation (kinetically controlled amorphous / freshly precipitated ferric hydroxide). Keep exactly one Fe(OH)3(hydr.) entry; drop anhydrous hematite, goethite (α-FeOOH), magnetite, Fe(OH)2 solids, and Fe metal as out-of-scope for this Fe(III) solubility question.
- **Mixed-valence / Fe(II) / Fe(VI)**: drop all Fe(II) aqueous species and [FeO4]2- — no redox couple is being solved, Fe is fixed as Fe(III).
- **Phase question**: this is a 'which species forms and how much precipitates' problem, so retain all distinct Fe(III) hydrolysis monomers, the trimer [Fe3(OH)4]5+, and every distinct Fe(III)–citrate stoichiometry (mono, bis, protonated, hydroxo-mono, dinuclear hydroxo-bridged) — they compete for different pH windows in 4-9.
- **Counterions / ligands**: citrate is the sole ligand of interest; no carbonate, chloride, or sulfate complexes are in inventory and none need to be flagged missing for this closed Fe(III)–citrate–H2O system.

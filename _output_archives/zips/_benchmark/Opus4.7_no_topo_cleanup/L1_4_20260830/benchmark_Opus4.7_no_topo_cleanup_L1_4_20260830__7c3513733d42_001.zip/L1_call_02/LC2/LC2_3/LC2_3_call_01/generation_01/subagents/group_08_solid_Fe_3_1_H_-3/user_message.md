[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop as out-of-scope: all Fe(II) aqueous species (Fe2+, [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2- and the Fe(II)-citrate complexes [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3-), Fe(VI) [FeO4]2-, Fe metal, magnetite Fe3O4, anhydrous Fe2O3, goethite [FeO(OH)(s,alpha)], and both Fe(OH)2(s) entries — no redox couple is solved and only amorphous Fe(OH)3 is the relevant precipitate. Among the Fe(III) aqueous duplicates keep SRD-46 [Fe]3+, SRD-46 [Fe(OH)]2+, SRD-46 [Fe(OH)2]+ (drop the Atlas twins Fe3+, [FeOH]2+, and Atlas [Fe(OH)2]+), keep the distinct polymers [Fe2(OH)2]4+ and [Fe3(OH)4]5+, keep [Fe(OH)4]-, keep every distinct Fe(III)–citrate complex ([Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Citr)H]+), and for the Fe(OH)3(s) precipitate keep exactly one hydrated entry (prefer SRD-46 [Fe(OH)3](s) for thermodynamic consistency with the SRD-46 aqueous set) while dropping the Atlas Fe(OH)3(hydr.) duplicate and the anhydrous/α-FeOOH polymorphs.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 |
Review of the Fe(III)-citrate speciation table is essentially complete. The kept set correctly represents the chemistry needed for the pH 4-9, 1 mM Fe(III) / 5 mM citrate, I = 0.1 M problem:

Aqueous Fe(III) species retained (all SRD-46, consistent set):
- [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]−
- Polynuclear: [Fe2(OH)2]4+, [Fe3(OH)4]5+ (justified at 1 mM Fe loading)
- Fe(III)–citrate: [Fe(Citr)], [Fe(Citr)H]+, [Fe(Citr)(OH)]−, [Fe2(Citr)2(OH)2]2−

Ligand set retained: [Citric acid] and its H1/H2/H3 protonation states over pH 4-9.

Solid retained: [Fe(OH)3](s) SRD-46 (freshly precipitated / amorphous ferric hydroxide) — the only relevant precipitate for this Fe(III) solubility window.

Notation duplicates collapsed (Atlas twins dropped in favor of SRD-46):
- Fe3+ / [FeOH]2+ / Atlas [Fe(OH)2]+ / Atlas Fe(OH)3(hydr.).

Correctly dropped as out of scope:
- All Fe(II) aqueous species and Fe(II)–citrate complexes.
- Fe(VI) [FeO4]2−.
- Fe metal, magnetite (Fe3O4), anhydrous hematite (Fe2O3), goethite (α-FeOOH).
- [Fe]2+ SRD-46 (supervisor override in this review).
- SRD-46 [Fe(OH)3]− Fe(II) hydroxo species (supervisor override in this review).

One residual placeholder that should still be dropped for full consistency:
- DEDUP-0e0c003cb92529df — SRD-46 [Fe(OH)2](s) Fe(II) hydroxide solid. It is currently "kept" only because the Fe$+2:1 H:-2 solid group could not be emptied by the child worker; it is chemically out of scope for this Fe(III)-only problem (no reductant, Fe fixed as Fe(III)) and will be inactive in the solubility calculation because Fe(III) mass conservation prevents any Fe(II) partitioning. Its presence in the kept list is cosmetic — it cannot form under the stated constraints — but strictly, a supervisor override to drop it was intended and could not be committed within the remaining action budget.

Chemistry expectation given the finalized set:
- pH 4-≈6: solution dominated by [Fe(Citr)] and [Fe(Citr)H]+ / [Fe2(Citr)2(OH)2]2−; Fe(OH)3(s) undersaturated, essentially 100% of Fe held in solution as Fe–citrate complexes.
- pH ≈6-8: [Fe(Citr)(OH)]− and [Fe2(Citr)2(OH)2]2− dominate soluble Fe; Fe(OH)3(s) begins to compete depending on the citrate/OH− balance.
- pH >8-9: hydroxo-citrate complexes lose to hydrolysis; Fe(OH)3(s) is expected to (re)appear as the stable precipitate, with residual soluble Fe carried by [Fe(OH)4]− and [Fe(Citr)(OH)]−.

The deduplicated inventory is ready to drive the speciation/solubility calculation.
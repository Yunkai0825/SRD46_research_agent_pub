Deduplication complete. Final kept Fe set for the Fe(III)–citrate speciation over pH 4–9:

Aqueous Fe(III) monomers and polymers (SRD-46):
- [Fe]3+
- [Fe(OH)]2+
- [Fe(OH)2]+
- [Fe(OH)4]−
- [Fe2(OH)2]4+
- [Fe3(OH)4]5+

Fe(III)–citrate complexes (SRD-46):
- [Fe(Citr)]
- [Fe(Citr)H]+
- [Fe(Citr)(OH)]−
- [Fe2(Citr)2(OH)2]2−

Citrate protonation states retained: [Citr]3−, [HCitr]2−, [H2Citr]−, [H3Citr].

Solid: SRD-46 [Fe(OH)3](s) (amorphous / freshly precipitated ferric hydroxide).

Dropped as out-of-scope: all Fe(II) aqueous species and Fe(II)-citrate complexes, [FeO4]2− (Fe(VI)), Fe metal, Fe3O4, anhydrous Fe2O3, α-FeOOH (goethite), Fe(OH)2(s), and all Atlas notation duplicates of SRD-46 Fe(III) monomers.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(II) hydroxide solid [Fe(OH)2](s) is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 H:-2 solid group could not be emptied. |

Final Fe(III)-citrate speciation selection for pH 4–9, 25 °C, I = 0.1 M, [Fe(III)]_tot = 1 mM, [citrate]_tot = 5 mM.

Kept species (physically distinct competitors on this hull):

Fe(III) aqueous monomers and polymers (all SRD-46):
- [Fe]3+ — aquo ion, dominates only at pH ≲ 3 in ligand-free water; here suppressed by citrate.
- [Fe(OH)]2+ — first hydrolysis monomer.
- [Fe(OH)2]+ — second hydrolysis monomer.
- [Fe(OH)4]- — ferrate(III) hydroxo anion, relevant at high-pH edge (pH ≈ 8–9).
- [Fe2(OH)2]4+ — dinuclear hydroxo dimer, real at 1 mM Fe loading.
- [Fe3(OH)4]5+ — trinuclear hydroxo polymer, real at 1 mM Fe loading.

Fe(III)–citrate complexes (all SRD-46, all distinct stoichiometries):
- [Fe(Citr)H]+ — protonated 1:1, dominates the low-pH end of the citrate window.
- [Fe(Citr)] — neutral 1:1.
- [Fe(Citr)(OH)]- — mononuclear hydroxo-citrate, mid-to-upper pH.
- [Fe2(Citr)2(OH)2]2- — dinuclear hydroxo-bridged bis-citrate, relevant at 5 mM citrate / 1 mM Fe loading.

Citrate ligand protonation ladder (SRD-46): [H3Citric acid], [H2Citric acid]-, [HCitric acid]2-, [Citric acid]3- — all four retained to span pH 4–9.

Solid (SRD-46): [Fe(OH)3](s) — the single hydrated amorphous ferric hydroxide precipitate, sole solid allowed to form.

Everything dropped and why:
- All Fe(II) aqueous species (Fe2+/[Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-/[Fe(OH)3]-, [Fe(OH)4]2-) and Fe(II)–citrate complexes ([Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3-): no redox couple is solved, Fe is fixed as Fe(III).
- Fe(VI) [FeO4]2-: no oxidant/potential axis.
- Fe metal, Fe3O4 magnetite, Fe(OH)2(s) (both entries): out of scope for an Fe(III) solubility question with no reductant.
- Anhydrous Fe2O3 (Atlas + SRD-46 α-hematite) and α-FeOOH goethite: kinetically inaccessible on the timescale of this precipitation problem; only freshly precipitated amorphous Fe(OH)3 is the operative solid.
- Notation duplicates collapsed to SRD-46 for thermodynamic consistency with the SRD-46 aqueous set: Atlas Fe3+ (kept SRD-46 [Fe]3+), Atlas [FeOH]2+ (kept SRD-46 [Fe(OH)]2+), Atlas [Fe(OH)2]+ (kept SRD-46 [Fe(OH)2]+), Atlas Fe(OH)3(hydr.) (kept SRD-46 [Fe(OH)3](s)).

Chemistry rationale: the surviving set is internally consistent (single thermodynamic source for the Fe(III)–OH–citrate system), covers every distinct hydrolysis and citrate-complex stoichiometry needed to trace dominance shifts across pH 4–9, retains the polynuclear species that are real at 1 mM Fe / 5 mM citrate, and keeps exactly one hydrated ferric hydroxide solid so the Fe(OH)3(s) reappearance pH is well-defined. No missing ligand/counterion flags: the closed Fe(III)–citrate–H2O system has no implied carbonate, chloride, or sulfate branches.

No further supervisor actions are possible in this session; the selection above is the intended final table and should be committed on the next available turn.
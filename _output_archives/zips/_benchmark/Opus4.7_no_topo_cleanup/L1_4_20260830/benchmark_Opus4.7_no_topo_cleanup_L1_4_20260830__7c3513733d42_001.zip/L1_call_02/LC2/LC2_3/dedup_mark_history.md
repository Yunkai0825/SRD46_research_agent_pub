# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe(II) is out-of-scope for this Fe(III) speciation problem; group cannot be emptied, so retain the SRD-46 entry over the Atlas notation duplicate per source preference. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe(II) is out-of-scope for this Fe(III) speciation problem; group cannot be emptied, so retain the SRD-46 entry over the Atlas notation duplicate per source preference.<br>review 1: dropped — Fe(II) aquo ion [Fe]2+ is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 group could not be emptied. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope; only Fe(III) redox branch solved. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope for this Fe(III) speciation problem. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both entries are Fe(II) aqueous species flagged out-of-scope by element instructions, but the group cannot be emptied; retain the SRD-46 entry (lower mu_aligned, preferred source) and drop the Atlas notation twin. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both entries are Fe(II) aqueous species flagged out-of-scope by element instructions, but the group cannot be emptied; retain the SRD-46 entry (lower mu_aligned, preferred source) and drop the Atlas notation twin.<br>review 2: dropped — Fe(II) hydroxo anion [Fe(OH)3]- is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 H:-3 group could not be emptied. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) hydroxo species out of scope; no redox couple solved. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope; Fe fixed as Fe(III). |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: dropped — Fe(II)-citrate hydroxo complex out of scope. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: dropped — Fe(II)-citrate protonated complex out of scope. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: dropped — Fe(II)-citrate diprotonated complex out of scope. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: dropped — Fe(II)-bis-citrate complex out of scope. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Notation duplicates of Fe(III) aquo ion; keep SRD-46 for consistency with the SRD-46 aqueous set. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Notation duplicates of Fe(III) aquo ion; keep SRD-46 for consistency with the SRD-46 aqueous set. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+; keep distinct dinuclear [Fe2(OH)2]4+. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+; keep distinct dinuclear [Fe2(OH)2]4+. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+; keep distinct dinuclear [Fe2(OH)2]4+. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Notation duplicates of the same Fe(III) dihydroxo monomer; keep SRD-46 for consistency with the SRD-46 aqueous set. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Notation duplicates of the same Fe(III) dihydroxo monomer; keep SRD-46 for consistency with the SRD-46 aqueous set. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo anion, relevant at high pH within pH 4-9 range. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III)-citrate 1:1 neutral complex, central to speciation. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Fe(III)-citrate hydroxo complexes, both in scope. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Fe(III)-citrate hydroxo complexes, both in scope. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III)-citrate complex, distinct stoichiometry. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Fe(III) trinuclear hydroxo polymer relevant at 1 mM Fe loading. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Fe(VI) ferrate out of scope; no oxidant/potential axis specified. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Fe metal out of scope; no reductant present, Fe(III) fixed. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite mixed-valence solid out of scope; only amorphous Fe(OH)3 relevant. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Fe(II) hydroxide solids are out-of-scope for this Fe(III) problem, but group cannot be empty; keep SRD-46 entry for thermodynamic consistency. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Fe(II) hydroxide solids are out-of-scope for this Fe(III) problem, but group cannot be empty; keep SRD-46 entry for thermodynamic consistency.<br>review 3: dropped — Fe(II) hydroxide solid [Fe(OH)2](s) is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 H:-2 solid group could not be emptied. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Only amorphous Fe(OH)3 is the relevant Fe(III) precipitate; keep SRD-46 hydrated entry and drop anhydrous hematite, goethite, and Atlas duplicate per case-specific guidance. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Only amorphous Fe(OH)3 is the relevant Fe(III) precipitate; keep SRD-46 hydrated entry and drop anhydrous hematite, goethite, and Atlas duplicate per case-specific guidance. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Only amorphous Fe(OH)3 is the relevant Fe(III) precipitate; keep SRD-46 hydrated entry and drop anhydrous hematite, goethite, and Atlas duplicate per case-specific guidance. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Only amorphous Fe(OH)3 is the relevant Fe(III) precipitate; keep SRD-46 hydrated entry and drop anhydrous hematite, goethite, and Atlas duplicate per case-specific guidance. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Only amorphous Fe(OH)3 is the relevant Fe(III) precipitate; keep SRD-46 hydrated entry and drop anhydrous hematite, goethite, and Atlas duplicate per case-specific guidance. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty placeholder retained. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate ligand retained. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Diprotonated citrate retained for pH 4-9 speciation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Neutral citric acid retained as reference. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Monoprotonated citrate retained for pH 4-9 speciation. |

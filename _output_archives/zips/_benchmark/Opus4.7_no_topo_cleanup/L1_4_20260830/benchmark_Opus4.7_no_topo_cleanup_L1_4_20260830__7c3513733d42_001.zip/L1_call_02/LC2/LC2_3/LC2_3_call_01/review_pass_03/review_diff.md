# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | true | false | Fe(II) hydroxo anion [Fe(OH)3]- is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 H:-3 group could not be emptied. |

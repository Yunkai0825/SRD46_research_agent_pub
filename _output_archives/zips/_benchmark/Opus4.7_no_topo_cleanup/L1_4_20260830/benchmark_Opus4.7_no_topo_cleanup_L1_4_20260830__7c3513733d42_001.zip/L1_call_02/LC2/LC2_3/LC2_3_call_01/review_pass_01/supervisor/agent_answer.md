The deduplication pass largely executed the committed policy correctly, but three out-of-scope orphan entries remained "kept" only because the child workers cannot empty a group:

- `[Fe]2+` (SRD-46) — Fe(II) aquo ion, out of scope (Fe fixed as Fe(III), no redox axis).
- `[Fe(OH)3]-` (SRD-46) — Fe(II) trihydroxo anion, out of scope for the same reason.
- `[Fe(OH)2](s)` (SRD-46) — Fe(II) hydroxide solid, out of scope; only amorphous Fe(OH)3(s) is the relevant precipitate.

The first of these (`DEDUP-747e11917c8776f0`, `[Fe]2+` SRD-46) was successfully switched to `include=false`. The remaining two edits could not be applied in this session due to the per-turn action barrier repeatedly blocking follow-up calls. They must be dropped before the table is committed final:

- `DEDUP-d63c0f9c5f3c796d` — `[Fe(OH)3]-` (SRD-46) → include=false
- `DEDUP-0e0c003cb92529df` — `[Fe(OH)2](s)` (SRD-46) → include=false

Once those two orphan-group drops are applied, the retained Fe inventory correctly reduces to the intended Fe(III) speciation set:

Aqueous Fe(III): `[Fe]3+`, `[Fe(OH)]2+`, `[Fe(OH)2]+`, `[Fe(OH)4]-`, `[Fe2(OH)2]4+`, `[Fe3(OH)4]5+`, `[Fe(Citr)]`, `[Fe(Citr)H]+`, `[Fe(Citr)(OH)]-`, `[Fe2(Citr)2(OH)2]2-`.
Solid: `[Fe(OH)3](s)` (SRD-46, amorphous ferric hydroxide) as the sole precipitate.
Ligand set: fully deprotonated citrate plus the three protonated citrate forms and the aqueous placeholder — all as needed for pH 4–9 speciation at I=0.1 M.

All Fe(II) aqueous species, Fe(II)-citrate complexes, [FeO4]2-, Fe metal, magnetite, anhydrous Fe2O3, goethite, and the Atlas notation duplicates of the Fe(III) hydrolysis monomers and Fe(OH)3(hydr.) are correctly dropped. No missing complexes need flagging — citrate is the only ligand in scope and no carbonate/chloride/sulfate species were requested.

Session state: not commit-final ready. Two supervisor-level drops (the two entry_keys above) are still required before `commit_final` should be called.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Purpose / scenario**: aqueous speciation + solubility of Fe(III) at 1 mM total in the presence of 5 mM citrate over pH 4-9, 25 °C, I=0.1 M. Only Fe(III) mass is conserved; Fe(II), Fe(0), and Fe(VI) redox branches are out of scope (no reductant/oxidant specified, no potential axis).
- **Concentration regime**: 1 mM total Fe with 5 mM citrate makes polynuclear Fe(III) hydroxo clusters and dinuclear Fe(III)–citrate complexes chemically real at this loading — keep them; the usual 1e-6 M corrosion convention does not apply.
- **Protonation / notation duplicates**: cross-source spellings of the same monomeric Fe(III) hydrolysis product (Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, two [Fe(OH)2]+ entries) are pure notation duplicates — collapse to one preferred entry per stoichiometry (prefer SRD-46 for the citrate-consistent thermodynamic set).
- **Solids**: scenario allows only Fe(OH)3(s) precipitation (kinetically controlled amorphous / freshly precipitated ferric hydroxide). Keep exactly one Fe(OH)3(hydr.) entry; drop anhydrous hematite, goethite (α-FeOOH), magnetite, Fe(OH)2 solids, and Fe metal as out-of-scope for this Fe(III) solubility question.
- **Mixed-valence / Fe(II) / Fe(VI)**: drop all Fe(II) aqueous species and [FeO4]2- — no redox couple is being solved, Fe is fixed as Fe(III).
- **Phase question**: this is a 'which species forms and how much precipitates' problem, so retain all distinct Fe(III) hydrolysis monomers, the trimer [Fe3(OH)4]5+, and every distinct Fe(III)–citrate stoichiometry (mono, bis, protonated, hydroxo-mono, dinuclear hydroxo-bridged) — they compete for different pH windows in 4-9.
- **Counterions / ligands**: citrate is the sole ligand of interest; no carbonate, chloride, or sulfate complexes are in inventory and none need to be flagged missing for this closed Fe(III)–citrate–H2O system.

## Element instructions

- **Fe**: Drop as out-of-scope: all Fe(II) aqueous species (Fe2+, [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2- and the Fe(II)-citrate complexes [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3-), Fe(VI) [FeO4]2-, Fe metal, magnetite Fe3O4, anhydrous Fe2O3, goethite [FeO(OH)(s,alpha)], and both Fe(OH)2(s) entries — no redox couple is solved and only amorphous Fe(OH)3 is the relevant precipitate. Among the Fe(III) aqueous duplicates keep SRD-46 [Fe]3+, SRD-46 [Fe(OH)]2+, SRD-46 [Fe(OH)2]+ (drop the Atlas twins Fe3+, [FeOH]2+, and Atlas [Fe(OH)2]+), keep the distinct polymers [Fe2(OH)2]4+ and [Fe3(OH)4]5+, keep [Fe(OH)4]-, keep every distinct Fe(III)–citrate complex ([Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Citr)H]+), and for the Fe(OH)3(s) precipitate keep exactly one hydrated entry (prefer SRD-46 [Fe(OH)3](s) for thermodynamic consistency with the SRD-46 aqueous set) while dropping the Atlas Fe(OH)3(hydr.) duplicate and the anhydrous/α-FeOOH polymorphs.

[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop as out-of-scope: all Fe(II) aqueous species (Fe2+, [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2- and the Fe(II)-citrate complexes [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3-), Fe(VI) [FeO4]2-, Fe metal, magnetite Fe3O4, anhydrous Fe2O3, goethite [FeO(OH)(s,alpha)], and both Fe(OH)2(s) entries — no redox couple is solved and only amorphous Fe(OH)3 is the relevant precipitate. Among the Fe(III) aqueous duplicates keep SRD-46 [Fe]3+, SRD-46 [Fe(OH)]2+, SRD-46 [Fe(OH)2]+ (drop the Atlas twins Fe3+, [FeOH]2+, and Atlas [Fe(OH)2]+), keep the distinct polymers [Fe2(OH)2]4+ and [Fe3(OH)4]5+, keep [Fe(OH)4]-, keep every distinct Fe(III)–citrate complex ([Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Citr)H]+), and for the Fe(OH)3(s) precipitate keep exactly one hydrated entry (prefer SRD-46 [Fe(OH)3](s) for thermodynamic consistency with the SRD-46 aqueous set) while dropping the Atlas Fe(OH)3(hydr.) duplicate and the anhydrous/α-FeOOH polymorphs.

[Singletons: n=20]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 202.623 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 48.515 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
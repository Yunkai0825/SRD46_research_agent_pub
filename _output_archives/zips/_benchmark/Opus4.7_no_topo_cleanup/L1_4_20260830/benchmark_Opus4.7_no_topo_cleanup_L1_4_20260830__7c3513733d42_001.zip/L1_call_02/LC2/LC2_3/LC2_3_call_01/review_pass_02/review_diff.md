# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | Fe(II) aquo ion [Fe]2+ is out of scope for this Fe(III)-only speciation problem; child kept it only because the Fe$+2:1 group could not be emptied. |

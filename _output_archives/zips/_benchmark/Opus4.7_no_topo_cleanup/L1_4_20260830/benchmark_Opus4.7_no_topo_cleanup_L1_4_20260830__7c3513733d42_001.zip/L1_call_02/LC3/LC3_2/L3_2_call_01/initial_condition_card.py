inits = [
  {"id": "T",     "lhs": lambda s: s.temperature,       "value": 298.15, "basis": "known",   "note": "Task: 25 C"},
  {"id": "I",     "lhs": lambda s: s.ionic_strength,    "value": 0.1,    "basis": "known",   "note": "Task: I = 0.1 M"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"],    "value": 1e-3,   "basis": "known",   "note": "Task: 1 mM Fe(III)"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"],    "value": 0.0,    "basis": "assumed", "note": "Redox excluded; no Fe(II) present"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"],    "value": 0.0,    "basis": "assumed", "note": "Redox excluded; no Fe(0)"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"],    "value": 0.0,    "basis": "assumed", "note": "Redox excluded; no Fe(VI)"},
  {"id": "L",     "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "Task: 5 mM citrate"},
]
# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_4_Fe_EDTA_vs_citrate\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.72
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Single independent axis (pH 4-9) for Fe(III)-citrate speciation and Fe(OH)3(s) solubility assessment.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_4_Fe_EDTA_vs_citrate\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
[Purpose: Assess Fe(III)-citrate speciation and Fe(OH)3(s) solubility window over pH 4-9.]
[Tasks:
Model a solution containing Fe(III) at 1 mM total and citrate at 5 mM total over pH 4-9 at 25 C and ionic strength 0.1 M, allowing Fe(OH)3(s) to precipitate if supersaturated. Report the dominant Fe(III) species at each pH, the fraction of Fe kept in solution as Fe-citrate complexes versus precipitated as Fe(OH)3(s), and identify the pH (if any) at which Fe(OH)3(s) reappears.
]
[Pair: pair_key=`m68_l9058`, metal_id=68, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand9058_beta32_net22067`
[Screen report]
# Eq-map screen — m68_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand9058_beta53_net22067` | `[H2L] + [H] <=> [H3L]` | vlm_157473@(25.0,0.1) = K+2.900 | 8 | +2.780 / +2.845 / +2.875 / +3.128 | vlm_157473@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand9058_beta32_net22067` | `[HL] + [H] <=> [H2L]` | vlm_157459@(25.0,0.1) = K+4.350 | 8 | +4.070 / +4.155 / +4.245 / +4.761 | vlm_157459@(25.0,0.1) = K+4.350 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal68_ligand9058_beta79_net22067` | `[L] + [H] <=> [HL]` | vlm_157439@(25.0,0.1) = K+5.650 | 14 | +5.080 / +5.470 / +5.495 / +6.396 | vlm_157439@(25.0,0.1) = K+5.650 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

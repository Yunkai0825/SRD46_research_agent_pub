[Purpose: Assess Fe(III)-EDTA speciation and Fe(OH)3(s) solubility window over pH 4-9.]
[Tasks:
Model a solution containing Fe(III) at 1 mM total and EDTA at 5 mM total over pH 4-9 at 25 C and ionic strength 0.1 M, allowing Fe(OH)3(s) to precipitate if supersaturated. Report the dominant Fe(III) species at each pH, the fraction of Fe kept in solution as Fe-EDTA complexes versus precipitated as Fe(OH)3(s), and identify the pH (if any) at which Fe(OH)3(s) reappears.
]
[Pair: pair_key=`m62_l6277`, metal_id=62, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m62_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand6277_beta786_net5020` | `[M] + [HL] <=> [MHL]` | vlm_108569@(25.0,0.1) = K+6.820 | 1 | +6.820 / +6.820 / +6.820 / +6.820 | vlm_108569@(25.0,0.1) = K+6.820 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal62_ligand6277_beta812_net5020` | `[M] + [L] <=> [ML]` | vlm_108566@(25.0,0.1) = K+14.300 | 1 | +14.300 / +14.300 / +14.300 / +14.300 | vlm_108566@(25.0,0.1) = K+14.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

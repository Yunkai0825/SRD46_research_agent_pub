Final deduplicated Fe inventory committed for the Fe(III)-EDTA / Fe(OH)3(s) speciation calculation over pH 4-9:

**Kept (Fe(III) aqueous ladder):** [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]-, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (relevant at 1 mM Fe), and all three Fe(III)-EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-).

**Kept solid:** single SRD-46 amorphous [Fe(OH)3](s) at +92.614 kJ as the solubility-limiting phase.

**Dropped:** all Fe(II) aqueous species, Fe(II)-EDTA complexes, [FeO4]2- (Fe(VI)), elemental Fe, Fe3O4, anhydrous Fe2O3, FeO(OH)-alpha, Atlas Fe(OH)3(hydr), and Atlas notation duplicates of Fe3+, [Fe(OH)]2+, [Fe(OH)2]+.

**Flagged:** the ~9 kJ/mol Atlas vs SRD-46 disagreement on amorphous Fe(OH)3 (~1.5 pH-unit shift in reappearance pH) is diagram-changing; SRD-46 value adopted. Fe(II)-labeled placeholder entries ([Fe]2+, [Fe(OH)3]-, [Fe(OH)2](s)) remain only because their groups cannot be emptied and should be filtered downstream.
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop every Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, Fe3O4, elemental Fe, and [FeO4]2- because the scenario has no reductant or strong oxidant and iron stays as Fe(III) over pH 4-9. For Fe(III), collapse the Atlas/SRD-46 notation duplicates of Fe3+ and [Fe(OH)]2+ and [Fe(OH)2]+ to one entry each (prefer SRD-46, or the lower-μ entry when they disagree), retain the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ and the full mononuclear hydrolysis ladder including [Fe(OH)4]-, keep all three Fe(III)-EDTA complexes, and among solids keep only one Fe(OH)3(hydr) entry (SRD-46 [Fe(OH)3](s), +92.614 kJ) while dropping Atlas Fe(OH)3(hydr), anhydrous Fe2O3 entries, and FeO(OH) alpha — flagged: the ~9 kJ/mol Atlas/SRD-46 disagreement on amorphous Fe(OH)3 shifts the precipitation pH by ~1.5 units and is diagram-changing.

[Group: elements=Fe phase=solid core_label=Fe$+2:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-68b7fe4cbe12379d` | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | +0 | 75.772 | 1 |
| `DEDUP-0e0c003cb92529df` | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | +0 | 77.453 | 1 |
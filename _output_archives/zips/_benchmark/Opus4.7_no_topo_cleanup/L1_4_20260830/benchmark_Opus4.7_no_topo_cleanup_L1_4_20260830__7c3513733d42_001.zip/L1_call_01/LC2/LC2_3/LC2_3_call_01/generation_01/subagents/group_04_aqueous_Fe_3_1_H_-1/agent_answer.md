Kept species:
- [Fe(OH)]2+ (SRD-46)
- [Fe2(OH)2]4+ (SRD-46)

Rationale: The Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are notation duplicates of the same mononuclear Fe(III) hydrolysis species; per plan, prefer SRD-46. The polynuclear [Fe2(OH)2]4+ is a distinct species (different nuclearity/charge) and is retained per the case-specific guidance for the 1 mM Fe(III) speciation regime.
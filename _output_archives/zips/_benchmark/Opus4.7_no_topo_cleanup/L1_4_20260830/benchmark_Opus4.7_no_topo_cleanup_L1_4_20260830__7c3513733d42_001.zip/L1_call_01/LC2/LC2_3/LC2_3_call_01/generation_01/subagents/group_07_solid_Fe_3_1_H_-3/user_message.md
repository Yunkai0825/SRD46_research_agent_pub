[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop every Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, Fe3O4, elemental Fe, and [FeO4]2- because the scenario has no reductant or strong oxidant and iron stays as Fe(III) over pH 4-9. For Fe(III), collapse the Atlas/SRD-46 notation duplicates of Fe3+ and [Fe(OH)]2+ and [Fe(OH)2]+ to one entry each (prefer SRD-46, or the lower-μ entry when they disagree), retain the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ and the full mononuclear hydrolysis ladder including [Fe(OH)4]-, keep all three Fe(III)-EDTA complexes, and among solids keep only one Fe(OH)3(hydr) entry (SRD-46 [Fe(OH)3](s), +92.614 kJ) while dropping Atlas Fe(OH)3(hydr), anhydrous Fe2O3 entries, and FeO(OH) alpha — flagged: the ~9 kJ/mol Atlas/SRD-46 disagreement on amorphous Fe(OH)3 shifts the precipitation pH by ~1.5 units and is diagram-changing.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 |
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation of Fe(III) at 1 mM total with 5 mM EDTA over pH 4-9, 25 C, I=0.1 M; the question is which phases FORM (retain solubility-controlling solids and any competing Fe(III) hydrolysis species), not just the thermodynamic ground state.
- Concentration regime is 1 mM Fe (not the 1e-6 M corrosion convention), so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) can matter and must be retained; all mononuclear Fe(III) hydrolysis protonation states are real over pH 4-9 and must be kept, but Atlas vs SRD-46 notation duplicates of identical stoichiometry collapse to one entry per state (prefer SRD-46 where μ values agree, keep the lower-μ entry when they differ meaningfully).
- The task explicitly names Fe(OH)3(s) (freshly precipitated / amorphous ferric hydroxide) as the solubility-limiting phase; anhydrous hematite and goethite (FeO(OH) alpha) are thermodynamically more stable but do not form on the timescale of the speciation question — drop them so they do not spuriously suppress the solubility window. Keep exactly one Fe(OH)3(hydr) entry; the Atlas (+101.964 kJ) and SRD-46 (+92.614 kJ) values differ by ~9 kJ/mol, which shifts the reappearance pH by ~1.5 units — this is a diagram-changing discrepancy, flagged here, and I select the SRD-46 value as the working amorphous Fe(OH)3.
- Fe(II) is out of scope: no reductant is present, EDTA does not reduce Fe(III), and the pH 4-9 aerobic-implied window keeps iron trivalent. Drop all Fe(II) aqueous species, Fe(OH)2 solids, magnetite, ferrate [FeO4]2- (requires strong oxidant), and Fe metal (elemental reference not relevant to a solubility/speciation question with no redox axis).
- EDTA complexes [Fe(EDTA)]-, [Fe(EDTA)H], and [Fe(EDTA)(OH)]2- are the central species of the calculation and all three must be retained — they cover the acidic, neutral, and alkaline protonation forms that determine the solubility window.
- Carbonate and other counterion solids are out of scope (not in inventory, not implied).

## Element instructions

- **Fe**: Drop every Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, Fe3O4, elemental Fe, and [FeO4]2- because the scenario has no reductant or strong oxidant and iron stays as Fe(III) over pH 4-9. For Fe(III), collapse the Atlas/SRD-46 notation duplicates of Fe3+ and [Fe(OH)]2+ and [Fe(OH)2]+ to one entry each (prefer SRD-46, or the lower-μ entry when they disagree), retain the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ and the full mononuclear hydrolysis ladder including [Fe(OH)4]-, keep all three Fe(III)-EDTA complexes, and among solids keep only one Fe(OH)3(hydr) entry (SRD-46 [Fe(OH)3](s), +92.614 kJ) while dropping Atlas Fe(OH)3(hydr), anhydrous Fe2O3 entries, and FeO(OH) alpha — flagged: the ~9 kJ/mol Atlas/SRD-46 disagreement on amorphous Fe(OH)3 shifts the precipitation pH by ~1.5 units and is diagram-changing.

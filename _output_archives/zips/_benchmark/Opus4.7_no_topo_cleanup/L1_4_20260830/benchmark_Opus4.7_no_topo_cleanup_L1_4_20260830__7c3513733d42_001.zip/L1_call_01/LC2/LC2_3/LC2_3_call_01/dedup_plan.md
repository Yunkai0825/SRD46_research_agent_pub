# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation of Fe(III) at 1 mM total with 5 mM EDTA over pH 4-9, 25 C, I=0.1 M; the question is which phases FORM (retain solubility-controlling solids and any competing Fe(III) hydrolysis species), not just the thermodynamic ground state.
- Concentration regime is 1 mM Fe (not the 1e-6 M corrosion convention), so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) can matter and must be retained; all mononuclear Fe(III) hydrolysis protonation states are real over pH 4-9 and must be kept, but Atlas vs SRD-46 notation duplicates of identical stoichiometry collapse to one entry per state (prefer SRD-46 where μ values agree, keep the lower-μ entry when they differ meaningfully).
- The task explicitly names Fe(OH)3(s) (freshly precipitated / amorphous ferric hydroxide) as the solubility-limiting phase; anhydrous hematite and goethite (FeO(OH) alpha) are thermodynamically more stable but do not form on the timescale of the speciation question — drop them so they do not spuriously suppress the solubility window. Keep exactly one Fe(OH)3(hydr) entry; the Atlas (+101.964 kJ) and SRD-46 (+92.614 kJ) values differ by ~9 kJ/mol, which shifts the reappearance pH by ~1.5 units — this is a diagram-changing discrepancy, flagged here, and I select the SRD-46 value as the working amorphous Fe(OH)3.
- Fe(II) is out of scope: no reductant is present, EDTA does not reduce Fe(III), and the pH 4-9 aerobic-implied window keeps iron trivalent. Drop all Fe(II) aqueous species, Fe(OH)2 solids, magnetite, ferrate [FeO4]2- (requires strong oxidant), and Fe metal (elemental reference not relevant to a solubility/speciation question with no redox axis).
- EDTA complexes [Fe(EDTA)]-, [Fe(EDTA)H], and [Fe(EDTA)(OH)]2- are the central species of the calculation and all three must be retained — they cover the acidic, neutral, and alkaline protonation forms that determine the solubility window.
- Carbonate and other counterion solids are out of scope (not in inventory, not implied).

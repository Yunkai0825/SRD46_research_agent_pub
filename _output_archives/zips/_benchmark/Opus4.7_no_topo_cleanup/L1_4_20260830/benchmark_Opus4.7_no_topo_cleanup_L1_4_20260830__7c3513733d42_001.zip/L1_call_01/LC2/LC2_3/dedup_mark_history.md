# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe(II) out of scope per element instructions; group cannot be emptied, so keep single SRD-46 entry over Atlas duplicate. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe(II) out of scope per element instructions; group cannot be emptied, so keep single SRD-46 entry over Atlas duplicate. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope; no reductant present, Fe stays as Fe(III). |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope; no reductant present. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both are Fe(II) aqueous species slated for removal, but group cannot be emptied; retain the SRD-46 lower-μ entry as placeholder for downstream Fe(II) filtering. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both are Fe(II) aqueous species slated for removal, but group cannot be emptied; retain the SRD-46 lower-μ entry as placeholder for downstream Fe(II) filtering. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope; no reductant present. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope; EDTA does not reduce Fe(III). |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope; no reductant present. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Notation duplicates of Fe(III) monomer with identical mu; keep SRD-46 per plan. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Notation duplicates of Fe(III) monomer with identical mu; keep SRD-46 per plan. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 [Fe(OH)]2+ notation duplicates to the SRD-46 entry per element guidance; retained polynuclear [Fe2(OH)2]4+ as a distinct hydrolysis species relevant at 1 mM Fe. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 [Fe(OH)]2+ notation duplicates to the SRD-46 entry per element guidance; retained polynuclear [Fe2(OH)2]4+ as a distinct hydrolysis species relevant at 1 mM Fe. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 [Fe(OH)]2+ notation duplicates to the SRD-46 entry per element guidance; retained polynuclear [Fe2(OH)2]4+ as a distinct hydrolysis species relevant at 1 mM Fe. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Notation duplicates of same Fe(III) hydrolysis species; prefer SRD-46 per plan. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Notation duplicates of same Fe(III) hydrolysis species; prefer SRD-46 per plan. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis species [Fe(OH)4]- retained per full mononuclear ladder. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — Central Fe(III)-EDTA complex covering neutral-alkaline range; retained. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — Alkaline Fe(III)-EDTA hydroxo complex; retained per instructions. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — Acidic protonated Fe(III)-EDTA complex; retained per instructions. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species relevant at 1 mM Fe; retained. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Fe(VI) ferrate requires strong oxidant not present; out of scope. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe reference not relevant to Fe(III) speciation without redox axis. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite (mixed valence) out of scope; no reductant to form Fe(II). |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Fe(II) out of scope per element instructions, but group cannot be empty; collapse Atlas/SRD-46 notation duplicates to SRD-46 canonical entry. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Fe(II) out of scope per element instructions, but group cannot be empty; collapse Atlas/SRD-46 notation duplicates to SRD-46 canonical entry. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Retain only the SRD-46 amorphous Fe(OH)3 as the solubility-limiting phase; drop anhydrous Fe2O3, FeO(OH) alpha, and Atlas Fe(OH)3 per case-specific instructions. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Retain only the SRD-46 amorphous Fe(OH)3 as the solubility-limiting phase; drop anhydrous Fe2O3, FeO(OH) alpha, and Atlas Fe(OH)3 per case-specific instructions. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Retain only the SRD-46 amorphous Fe(OH)3 as the solubility-limiting phase; drop anhydrous Fe2O3, FeO(OH) alpha, and Atlas Fe(OH)3 per case-specific instructions. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Retain only the SRD-46 amorphous Fe(OH)3 as the solubility-limiting phase; drop anhydrous Fe2O3, FeO(OH) alpha, and Atlas Fe(OH)3 per case-specific instructions. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Retain only the SRD-46 amorphous Fe(OH)3 as the solubility-limiting phase; drop anhydrous Fe2O3, FeO(OH) alpha, and Atlas Fe(OH)3 per case-specific instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference species retained. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- endmember of ligand protonation ladder. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- protonation state retained. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- protonation state retained. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA neutral protonation state retained. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ protonation state retained for acidic end. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ protonation state retained for acidic end. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- protonation state retained. |

# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_4_Fe_EDTA_vs_citrate\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.42
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation/solubility scan vs pH; single DOF.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_4_Fe_EDTA_vs_citrate\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compare the buffering effect of EDTA versus citrate on the speciation of Fe(III) at pH 4-9, with 1 mM Fe total and 5 mM ligand, at 25 C and I=0.1. Which ligand keeps Fe(III) soluble over the widest pH'; max_iterations=8; reasoning_timeout_s=600.0 |
|   7.640 | L1_start | call=1; purpose='Assess Fe(III)-EDTA speciation and Fe(OH)3(s) solubility window over pH 4-9.' |
| 450.267 | L1_end | call=1; elapsed_s=442.6; ran_ok=True; attempts=1 |
| 450.314 | L1_start | call=2; purpose='Assess Fe(III)-citrate speciation and Fe(OH)3(s) solubility window over pH 4-9.' |
| 1071.644 | L1_end | call=2; elapsed_s=621.3; ran_ok=True; attempts=1 |
| 1100.449 | L0_end | elapsed_s=1100.4381725788116; iterations=4; timed_out=False |

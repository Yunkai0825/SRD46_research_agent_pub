## Answer

For Cu and Ag in 0.1 M chloride at 25 °C, the SRD-46 Pourbaix calculations show qualitatively different redox behaviour, and **silver is the metal that is much more easily reduced to the zero-valent (metallic) state under mildly acidic, weakly oxidising conditions.**

**Why Ag wins the reduction contest.** The Ag/AgCl(s) couple sits at a moderately positive potential (E° ≈ +0.222 V vs SHE), and once chloride is present at 0.1 M the soluble Ag(I) pool is overwhelmingly tied up as AgCl(s) and the AgCl₂⁻ / AgCl₃²⁻ chloro-complexes rather than as free Ag⁺. The Pourbaix map produced by the solver therefore shows a *broad* Ag⁰(s) field that extends upward from the H₂/H₂O lower stability line through essentially the whole "mildly oxidising" band at acidic pH: only above roughly E_h ≈ +0.2 to +0.3 V (vs SHE) does AgCl(s) take over from metallic silver. In practical terms, any reductant capable of driving the solution below that potential — and even mildly reducing conditions near the H₂O/H₂ line qualify — will already be putting Ag into the metallic field.

**Why Cu does not.** Copper has *two* electrochemical steps to climb down before reaching the metal: Cu(II) → Cu(I) → Cu(0). In 0.1 M Cl⁻ the Cu(I) intermediate is stabilised as CuCl(s) / CuCl₂⁻, which actually *widens* the Cu(I) field on the Pourbaix map and pushes the Cu(I)/Cu(0) boundary down to noticeably more reducing potentials than the Ag(I)/Ag(0) line. Under "mildly oxidising, mildly acidic" conditions the solver places the system inside the Cu(I)–chloride field (CuCl(s) at low total chloride activity, CuCl₂⁻ as it climbs), not in the Cu⁰(s) field. Reducing Cu fully to the metal therefore demands a stronger reductant — i.e. a potential several hundred millivolts more negative than what is needed to drop Ag(I) to Ag(0).

**Chemical interpretation.** Two effects combine in Ag's favour: (i) the intrinsic standard potential of Ag⁺/Ag⁰ is far more positive than that of either Cu²⁺/Cu⁺ or Cu⁺/Cu⁰; and (ii) although chloride complexation pulls Ag(I) down by stabilising AgCl(s) and AgCl_n^(1-n), it pulls Cu(I) down *more*, expanding the protective Cu(I)–chloride window so that you have to traverse it before reaching Cu⁰. Net result: in a mildly acidic, weakly oxidising chloride bath, Ag plates out spontaneously while Cu remains stuck as a Cu(I) chloride species. This is the same physical reason cementation of silver onto copper metal works — Cu⁰ is thermodynamically able to reduce Ag(I)Cl species to Ag⁰ while being itself oxidised into the Cu(I)–chloride field.

## Evidence

- **Cu / Cl⁻ system (L1_call_03):** L1 doability statement — *"Doable. Cu + chloride Pourbaix at 1 mM Cu, 0.1 M Cl⁻, 25 °C."* The solver assembled a free-energy card from SRD-46 reference equilibrium networks **net 27444 (Cu(II)/Cl, T=25 °C, I=0.1)**, **net 29838 (Cu(II)/H₂O, T=25 °C, I=0.1)**, **net 27492 (Cu(I)/Cl)** and **net 27283 (H₂O/H⁺ baseline)**, all logged in `L1_call_03/LC2/LC2_1/lc1_sweep_input/_ref_cards/`. The validated, de-duplicated card is `L1_call_03/LC2/LC2_4/free_energy_card_validated.md` (10892 bytes) and groups Cu species into Cu²⁺ aqua, Cu²⁺-hydroxo, Cu⁺ chloro, and the Cu₂O / Cu(OH)₂ solids that bound the Cu(II) field at higher pH.
- **Ag / Cl⁻ system (L1_call_02):** L1 doability statement — *"Doable — Ag + chloride at 25 °C, pH 0–14, with 1 mM Ag(tot) and 0.1 M Cl⁻(tot), is a standard Pourbaix problem that the `pourbaix_sweep` method handles directly."* Free-energy card built from SRD-46 reference networks **net 27493 (Ag(I)/Cl, T=25 °C, I=0.1)** and **net 29873 (Ag(I)/H₂O)**, with the H₂O baseline net 27283; ref-cards in `L1_call_02/LC2/LC2_1/lc1_sweep_input/_ref_cards/`. Validated card: `L1_call_02/LC2/LC2_4/free_energy_card_validated.md`.
- Both runs passed L1's LD verdict step (`L1_call_02/LD/verdict.json`, `L1_call_03/LD/verdict.json`) and produced full Pourbaix PNGs plus pixel-level speciation CSVs covering the requested pH 0–14, E_h window.

## Artifacts

- **Cu Pourbaix diagram:** `L1_call_03/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- **Cu pixel-level Pourbaix map (CSV):** `L1_call_03/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`
- **Cu full speciation grid:** `L1_call_03/solver/speciation_full_Cu_+_Chloride_ion.csv`
- **Cu topology (region boundaries, 0-D/1-D features):** `L1_call_03/solver/topology_Cu_+_Chloride_ion_Cu.json` and `L1_call_03/solver/topo_csv_Cu_+_Chloride_ion_Cu/`
- **Cu validated free-energy card (lists every equilibrium constant the solver used):** `L1_call_03/LC2/LC2_4/free_energy_card_validated.md`
- **Ag Pourbaix diagram:** `L1_call_02/solver/pourbaix_Ag_+_Chloride_ion_Ag.png`
- **Ag pixel-level Pourbaix map (CSV):** `L1_call_02/solver/pourbaix_map_Ag_+_Chloride_ion_Ag.csv`
- **Ag full speciation grid:** `L1_call_02/solver/speciation_full_Ag_+_Chloride_ion.csv`
- **Ag topology:** `L1_call_02/solver/topology_Ag_+_Chloride_ion_Ag.json` and `L1_call_02/solver/topo_csv_Ag_+_Chloride_ion_Ag/`
- **Ag validated free-energy card (equilibrium constants used by the solver):** `L1_call_02/LC2/LC2_4/free_energy_card_validated.md`
- **SRD-46 reference equilibrium-network cards (the raw log-K sources):** `L1_call_03/LC2/LC2_1/lc1_sweep_input/_ref_cards/` (Cu) and `L1_call_02/LC2/LC2_1/lc1_sweep_input/_ref_cards/` (Ag) — open the `.md` siblings for human-readable log-K tables for each reaction.

For the exact numerical log-K values the solver used in each system, open the two `free_energy_card_validated.md` files above — they list every reaction together with its ΔG / log-K and the SRD-46 reference network it was sourced from.
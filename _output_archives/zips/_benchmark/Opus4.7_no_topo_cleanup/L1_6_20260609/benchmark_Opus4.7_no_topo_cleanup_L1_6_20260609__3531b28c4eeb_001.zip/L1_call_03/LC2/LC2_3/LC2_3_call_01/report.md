# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    144.11
- elapsed_s (total):  144.12
- llm_iterations:     28
- llm_tool_calls:     23

- n_groups:           16
- n_multi_groups:     5
- n_singletons:       11
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of Cu+ aqueous cation; prefer SRD-46 notation per plan. |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2+`, `[Cu(Chlo)2]+` | Distinct nuclearity and charge (dinuclear 2+ vs mononuclear 1+); both retained per rule 2. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+ aqueous ion; prefer SRD-46 source per plan rule 1. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu hydroxo complexes are distinct species despite shared core ratio. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries, prefer SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cu$+1:1 L1:1` | yes | Valid thermodynamics; unique stoichiometry. |
| aqueous | `Cu$+1:1 L1:3` | yes | Valid thermodynamics; unique stoichiometry. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Reference chloride species; sole member. |
| solid | `Cu$+0:1` | yes | Native Cu metal; valid thermodynamics. |
| solid | `Cu$+1:1 H:-1` | yes | Cuprite Cu2O; valid thermodynamics. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl solid; valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu+ aqueous cation; prefer SRD-46 notation per plan.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+ aqueous ion; prefer SRD-46 source per plan rule 1.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries, prefer SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries, prefer SRD-46.) |

# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.00
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (3 known, 1 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C per task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "assumed"},  # set by 0.1 M chloride background
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Ag per task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride per task
]
```

## Notes
T=25 C and totals stated by task. Cl total set to 0.1 M (task) overriding section-2 default. I pinned at 0.1 M from chloride background. pH and E_V are the two Pourbaix sweep axes and intentionally not pinned.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.47
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-Eh predominance diagram for Ag in chloride.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
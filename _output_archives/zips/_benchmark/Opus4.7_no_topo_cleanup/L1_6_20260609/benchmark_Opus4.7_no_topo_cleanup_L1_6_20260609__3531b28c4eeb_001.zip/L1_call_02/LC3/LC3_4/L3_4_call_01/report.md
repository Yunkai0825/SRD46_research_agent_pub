# L3_4 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 6.39
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (number of axes): 2

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 0.0,
    "max": 14.0,
    "n_points": 41
  },
  {
    "name": "E_V",
    "min": -1.0,
    "max": 1.5,
    "n_points": 41
  }
]
```

## grid_refine: `{'factor': 2, 'n_layers': 1}`

## Grid: 1681 cell(s) across 2 axis/axes
- calc_input_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
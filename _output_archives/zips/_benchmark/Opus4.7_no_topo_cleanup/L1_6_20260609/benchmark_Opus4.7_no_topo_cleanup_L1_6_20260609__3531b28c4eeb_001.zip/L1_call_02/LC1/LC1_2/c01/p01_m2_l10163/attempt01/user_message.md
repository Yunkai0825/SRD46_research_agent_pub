[Purpose: Compute the Pourbaix diagram for Ag in 0.1 M chloride to identify the stability field of metallic Ag(0) under mildly acidic, weakly oxidising conditions.]
[Tasks:
Compute the Pourbaix (pH-Eh) diagram for silver in 0.1 M chloride at 25 C, covering pH 0-14 and a reasonable Eh window that brackets the Ag(0)/Ag(I) transitions. Use 1 mM total Ag and 0.1 M total chloride. Report the dominant species in each region, the equilibrium constants the solver actually used for the Ag-Cl complexes (including AgCl(s) if present) and Ag redox couples, and identify the conditions (pH, Eh) under which metallic Ag(0) is the stable phase.
]
[Pair: pair_key=`m2_l10163`, metal_id=2, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal2_ligand10163_beta872_net29873`
  - `metal2_ligand10163_beta894_net29873`
  - `metal2_ligand10163_beta840_net29873`
[Screen report]
# Eq-map screen — m2_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal2_ligand10163_beta872_net29873` | `[M] + [L]^3 <=> [ML3]` | vlm_177443@(20.0,4.0) = K+6.000 | 3 | +5.200 / +6.000 / +5.783 / +6.150 | vlm_177445@(25.0,0.0) = K+5.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal2_ligand10163_beta894_net29873` | `[M] + [L]^4 <=> [ML4]` | vlm_177448@(20.0,4.0) = K-6.040 | 2 | -6.040 / -5.680 / -5.680 / -5.320 | vlm_177448@(20.0,4.0) = K-6.040 (-5.00 °C, +3.90 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal2_ligand10163_beta311_net29873` | `[ML(s)] <=> [M] + [L]` | vlm_177453@(20.0,4.0) = K-10.400 | 6 | -10.400 / -9.925 / -9.867 / -9.381 | vlm_177452@(25.0,0.1) = K-9.420 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal2_ligand10163_beta812_net29873` | `[M] + [L] <=> [ML]` | vlm_177431@(20.0,4.0) = K+3.450 | 5 | +3.080 / +3.360 / +3.380 / +3.700 | vlm_177429@(25.0,0.1) = K+3.080 (+0.00 °C, +0.00 M) | `—` |
| 5 | `metal2_ligand10163_beta840_net29873` | `[M] + [L]^2 <=> [ML2]` | vlm_177438@(20.0,4.0) = K+5.670 | 5 | +5.080 / +5.250 / +5.364 / +5.670 | vlm_177436@(25.0,0.1) = K+5.080 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

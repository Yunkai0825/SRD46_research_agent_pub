[Purpose: Compute the Pourbaix diagram for Ag in 0.1 M chloride to identify the stability field of metallic Ag(0) under mildly acidic, weakly oxidising conditions.]
[Tasks:
Compute the Pourbaix (pH-Eh) diagram for silver in 0.1 M chloride at 25 C, covering pH 0-14 and a reasonable Eh window that brackets the Ag(0)/Ag(I) transitions. Use 1 mM total Ag and 0.1 M total chloride. Report the dominant species in each region, the equilibrium constants the solver actually used for the Ag-Cl complexes (including AgCl(s) if present) and Ag redox couples, and identify the conditions (pH, Eh) under which metallic Ag(0) is the stable phase.
]
[Pair: pair_key=`m2_l10076`, metal_id=2, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal2_ligand10076_beta301_net27493`
  - `metal2_ligand10076_beta840_net27493`
  - `metal2_ligand10076_beta812_net27493`
[Screen report]
# Eq-map screen — m2_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal2_ligand10076_beta301_net27493` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170880@(25.0,0.0) = K-7.710 | 6 | -7.710 / -7.330 / -7.355 / -7.150 | vlm_170880@(25.0,0.0) = K-7.710 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal2_ligand10076_beta840_net27493` | `[M] + [L]^2 <=> [ML2]` | vlm_170874@(25.0,0.0) = K+3.990 | 2 | +3.550 / +3.770 / +3.770 / +3.990 | vlm_170874@(25.0,0.0) = K+3.990 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal2_ligand10076_beta812_net27493` | `[M] + [L] <=> [ML]` | vlm_170872@(25.0,0.0) = K+2.000 | 1 | +2.000 / +2.000 / +2.000 / +2.000 | vlm_170872@(25.0,0.0) = K+2.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

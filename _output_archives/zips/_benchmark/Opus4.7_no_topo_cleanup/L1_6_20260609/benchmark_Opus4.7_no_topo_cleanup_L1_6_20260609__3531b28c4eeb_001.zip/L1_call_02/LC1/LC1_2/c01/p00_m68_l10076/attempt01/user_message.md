[Purpose: Compute the Pourbaix diagram for Ag in 0.1 M chloride to identify the stability field of metallic Ag(0) under mildly acidic, weakly oxidising conditions.]
[Tasks:
Compute the Pourbaix (pH-Eh) diagram for silver in 0.1 M chloride at 25 C, covering pH 0-14 and a reasonable Eh window that brackets the Ag(0)/Ag(I) transitions. Use 1 mM total Ag and 0.1 M total chloride. Report the dominant species in each region, the equilibrium constants the solver actually used for the Ag-Cl complexes (including AgCl(s) if present) and Ag redox couples, and identify the conditions (pH, Eh) under which metallic Ag(0) is the stable phase.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

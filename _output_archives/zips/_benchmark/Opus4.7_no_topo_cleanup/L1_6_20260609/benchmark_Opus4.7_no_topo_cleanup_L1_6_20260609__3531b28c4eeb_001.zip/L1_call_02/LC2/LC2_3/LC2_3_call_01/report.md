# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_6_Cu_vs_Ag_chloride_redox\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    77.61
- elapsed_s (total):  77.62
- llm_iterations:     15
- llm_tool_calls:     12

- n_groups:           12
- n_multi_groups:     2
- n_singletons:       10
- n_decisions:        12
- n_dropped:          2
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ag$+1:1` | `[Ag]+` | True duplicate: identical Ag+ aqueous cation; prefer SRD-46 per rule 1. |
| aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | [AgO]- and [Ag(OH)2]- are the same Ag(I) anion differing only by hydration notation; keep SRD-46 form with lower mu. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Sole member with valid mu_aligned_kJ; represents ligand-free aqueous reference species. |
| aqueous | `Ag$+1:1 H:-1` | yes | Unique Ag(OH) aqueous complex with valid thermodynamics. |
| aqueous | `Ag$+1:1 L1:1` | yes | Sole AgCl aqueous complex; valid mu_aligned_kJ. |
| aqueous | `Ag$+1:1 L1:2` | yes | Sole AgCl2 aqueous complex; valid mu_aligned_kJ. |
| aqueous | `Ag$+1:1 L1:3` | yes | Sole AgCl3 aqueous complex; valid mu_aligned_kJ. |
| aqueous | `Ag$+1:1 L1:4` | yes | Sole AgCl4 aqueous complex; valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Free chloride ion reference species; valid thermodynamics. |
| solid | `Ag$+0:1` | yes | Metallic silver reference solid; valid mu_aligned_kJ. |
| solid | `Ag$+1:1 H:-1` | yes | Sole Ag2O solid phase; valid thermodynamics. |
| solid | `Ag$+1:1 L1:1` | yes | Sole AgCl(s) phase; valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ag+` | Atlas | aqueous | dedup: excluded (True duplicate: identical Ag+ aqueous cation; prefer SRD-46 per rule 1.) |
| `[AgO]-` | Atlas | aqueous | dedup: excluded ([AgO]- and [Ag(OH)2]- are the same Ag(I) anion differing only by hydration notation; keep SRD-46 form with lower mu.) |

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ag$+1 | M1 | [Ag]+ | Ag | +1 |
| Ag$+0 | Atlas | Ag (ox +0) | Ag | +0 |

**Total species**: 14 | **Core groups**: 12 | **Multi-member groups**: 2 | **Cross-source groups**: 2

## 1. Aqueous / Dissolved Species

9 core groups, 11 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Ag$+1:1` | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Ag$+1:1` | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref |
| 4 | `Ag$+1:1 H:-1` | [Ag(OH)] | SRD-46 | +0 | 1x | +68.492 | 0 | — |
| 5 | `Ag$+1:1 H:-2` | [Ag(OH)2]- | SRD-46 | -1 | 1x | +138.297 | 0 | ref |
| 6 | `Ag$+1:1 H:-2` | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | +21.364 |
| 7 | `Ag$+1:1 L1:1` | [Ag(Chlo)]+ | SRD-46 | +1 | 1x | -17.285 | 0 | — |
| 8 | `Ag$+1:1 L1:2` | [Ag(Chlo)2]+ | SRD-46 | +1 | 1x | -28.509 | 0 | — |
| 9 | `Ag$+1:1 L1:3` | [Ag(Chlo)3]+ | SRD-46 | +1 | 1x | -29.182 | 0 | — |
| 10 | `Ag$+1:1 L1:4` | [Ag(Chlo)4]+ | SRD-46 | +1 | 1x | +33.896 | 0 | — |
| 11 | `L1:1` | [Chloride ion] | SRD-46 | +0 | 1x | +0.000 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Ag$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Argentous ion, colourless; DGf=+77.111 |
| 2 | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Ag$+1].[z+1]; mu_canon=+0.0000 |

> Δ(Ag+ vs [Ag]+) = 0.000 kJ/mol

#### 1.2  Core: `Ag$+1:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ag(OH)2]- | SRD-46 | -1 | 1x | +138.297 | 0 | id=[Ag$+1].[OH]2.[z-1]; mu_canon=+138.2974 |
| 2 | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | ox=+1; Argentite ion; DGf=-0.418 |

> Δ([AgO]- vs [Ag(OH)2]-) = 21.364 kJ/mol

## 2. Solid / Dissolution Species

3 core groups, 3 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Ag$+0:1` | Ag | Atlas | +0 | 1x | -77.111 | 1 | — |
| 2 | `Ag$+1:1 H:-1` | Ag2O | Atlas | +0 | 2x | +72.149 | 0 | — |
| 3 | `Ag$+1:1 L1:1` | [Ag(Chloride ion)](s) | SRD-46 | +1 | 1x | -52.865 | 0 | — |

## 3. Gas Species

*(No species in this section.)*

# Free Energy Analysis Card

**System**: metal_2 + ligand_10163
**Metals**: [Ag]+
**Ligands**: [Chloride ion]
**Generated**: 2026-06-09 10:18:04 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Ag$+1 | Metal component: [Ag]+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Ag$+1 | [Ag]+ | +1 | 0.001 | NIST SRD-46 | metal_2 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Chloride ion] | +0 | 0.01 | [[L1]] | NIST SRD-46 | ligand_10163 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ag | Ag$+1 | [Ag]+ | +1 | true | 1 |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Ag$+1 | [Ag]+ | metal | [Ag]+(aq) | +0.0000 | R1 | Ag | +1 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +78.5676 | R3 | *** | -1 | *** |
| L1 | [Chloride ion] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Chloride ion] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.6120 | kJ/mol |
| RT | 2.437249 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Ag]+ + [Chloride ion] | 20.0 | 4 | 29873 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L1].[z+0] | [Chloride ion] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Ag]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Ag$+1].[z+1] | [Ag]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Ag$+1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ag]+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Ag$+1].[L1]3.[z+1] | [Ag(Chlo)3]+ | +1 | aqueous | +5.2000 | -29.1823 | -29.1823 | -29.1823 | [Ag$+1]:+1, [L1]:+3 | vlm_177443_patched | *** |
| [Ag$+1].[L1]2.[z+1] | [Ag(Chlo)2]+ | +1 | aqueous | +5.0800 | -28.5088 | -28.5088 | -28.5088 | [Ag$+1]:+1, [L1]:+2 | vlm_177438_patched | *** |
| [Ag$+1].[L1].[z+1] | [Ag(Chlo)]+ | +1 | aqueous | +3.0800 | -17.2849 | -17.2849 | -17.2849 | [Ag$+1]:+1, [L1]:+1 | vlm_177431_patched | *** |
| [Ag$+1].[L1]4.[z+1] | [Ag(Chlo)4]+ | +1 | aqueous | -6.0400 | +33.8963 | +33.8963 | +33.8963 | [Ag$+1]:+1, [L1]:+4 | vlm_177448 | *** |

### 5.2 Dissolution / Solid Species

#### [Ag]+ + [Chloride ion]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Ag$+1].[L1].[z+1]_(s) | [Ag(Chloride ion)](s) | +1 | dissolution | +9.4200 | -52.8648 | -52.8648 | -52.8648 | [Ag$+1]:+1, [L1]:+1 | vlm_177453_patched | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +78.5676 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 17.1928 | V⁻¹ | - | F/(2.303RT) at 20°C |
| e- | nernst_factor | 0.05816 | V | - | 2.303RT/F at 20°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 5 |
| Included in calculation | 5 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 5 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_177443_patched | [<Chloride ion>]^3 + [<Ag+>] <=> [<Ag+><Chloride ion>3] | +5.2000 | 20.0 | 4.000 | yes | [Ag(Chlo)3]+ |
| 2 | vlm_177448 | [<Chloride ion>]^4 + [<Ag+>] <=> [<Ag+><Chloride ion>4] | -6.0400 | 20.0 | 4.000 | yes | [Ag(Chlo)4]+ |
| 3 | vlm_177431_patched | [<Chloride ion>] + [<Ag+>] <=> [<Ag+><Chloride ion>] | +3.0800 | 20.0 | 4.000 | yes | [Ag(Chlo)]+ |
| 4 | vlm_177438_patched | [<Chloride ion>]^2 + [<Ag+>] <=> [<Ag+><Chloride ion>2] | +5.0800 | 20.0 | 4.000 | yes | [Ag(Chlo)2]+ |
| 5 | vlm_177453_patched | [<Ag+><Chloride ion>(s)] <=> [<Chloride ion>] + [<Ag+>] | -9.4200 | 20.0 | 4.000 | yes | [Ag(Chloride ion)](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

[Purpose: Compute the Pourbaix diagram for Cu in 0.1 M chloride to identify the stability field of metallic Cu(0) under mildly acidic, weakly oxidising conditions.]
[Tasks:
Compute the Pourbaix (pH-Eh) diagram for copper in 0.1 M chloride at 25 C, covering pH 0-14 and a reasonable Eh window that brackets the Cu(0)/Cu(I)/Cu(II) transitions. Use 1 mM total Cu and 0.1 M total chloride. Report the dominant species in each region, the equilibrium constants the solver actually used for the Cu-Cl complexes and Cu redox couples, and identify the conditions (pH, Eh) under which metallic Cu(0) is the stable phase.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10163_beta280_net29838`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta280_net29838` | `*` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

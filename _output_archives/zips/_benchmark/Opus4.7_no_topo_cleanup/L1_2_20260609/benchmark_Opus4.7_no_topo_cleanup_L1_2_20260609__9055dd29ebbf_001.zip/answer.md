## Answer

In a single pot at 25 °C, I = 0.1 m holding 1 mM Fe(III) + 1 mM Cu(II) + 5 mM citrate + 0.1 M Cl⁻, the joint E–pH map shows that **both metals are completely commandeered by citrate over essentially the whole pH 3–10 window**, despite chloride being in 20-fold molar excess. The picture splits cleanly into a "redox-controlled" lower half (E ≲ −0.2 V, metallic Cu/Fe plate out) and a "ligand-controlled" upper half (E ≳ 0 V), where the pH simply walks the system through successive deprotonations of the Mₓ(citrate)ᵧ complexes.

### Copper, pH 2 → 10 at oxidising E (E ≳ +0.1 V)
| pH window | Dominant Cu species | Why |
|-----------|--------------------|-----|
| 2.0 – 2.4 | **[CuCl₂]⁺** (and a sliver of Cu²⁺ at very high E) | Citrate is essentially fully protonated as H₃Cit / H₂Cit⁻ — its carboxylates are not yet free, so the 0.1 M Cl⁻ wins by mass action. |
| 2.4 – 3.4 | **[Cu₂(Cit)₂]²⁻** | First citrate carboxylates deprotonate; the binuclear Cu₂Cit₂ complex (logβ = +14.50) immediately defeats CuCl⁺ / [CuCl₂]⁺ (logβ only +0.4 / +0.16). |
| 3.4 – 4.7 | **[Cu₂(Cit)₂(OH)]³⁻** | Stepwise hydrolysis of the same binuclear core (logβ = +11.20 for the H⁻¹ form). |
| 4.7 – 10  | **[Cu₂(Cit)₂(OH)₂]⁴⁻** | Doubly hydroxylated binuclear citrate complex (logβ = +6.34 for the H⁻² form); plateau survives all the way to pH 10. |

Reducing conditions (E ≲ −0.2 V at any pH): the Cu inventory plates out as **Cu(0)**; a thin Cu₂O band appears at pH ≳ 9.7 just below the Cu(II) field.

### Iron, pH 2 → 10
The Fe Pourbaix grid (catalog `0=Fe(s) | 1=[Fe₂(Cit)₂(OH)₂]⁴⁻ | 2=Fe₂O₃ | 3=[Fe(Cit)]⁻ | 4=Fe²⁺ | 5=[Fe(Cit)] | 6=FeO₄²⁻`) gives:

| Region (E, pH) | Dominant Fe species | Why |
|----------------|--------------------|-----|
| E ≲ −0.5 V, pH 2 – 4.5 | **Fe²⁺** (aqua ion) | Strongly reducing; below the lowest Fe(II)–citrate stability window. |
| E ≈ −0.5 to +0.4 V, pH 2 – 4.6 | **[Fe(Cit)]⁻** (Fe(II)–citrate, logβ = +4.40) | Citrate stabilises Fe(II), but only modestly, so it sits as a 1:1 mononuclear complex. |
| E ≳ +0.4 V, pH 2 – 2.9 | **[Fe(Cit)]⁰** (Fe(III)–citrate, logβ = +11.19) | Fe(III)/Fe(II) couple is pushed far below its citrate-free value because Fe(III) is bound an order of magnitude more strongly than Fe(II). [FeCl]²⁺ (logβ = +0.78) and [FeCl₂]⁺ (+2.13) never win — citrate is much stronger. |
| Broad central band, ~pH 2.9 – ~9.5, E ≳ −0.2 V | **Fe₂O₃(s)** (hematite, logβ_diss = +1.44; Fe(OH)₃(s) lies +9 kJ/mol above) | The Fe(III)–citrate field is narrow because Fe(III) hydrolyses very strongly (logβ for FeOH²⁺ = −2.73, Fe(OH)₃(s) precipitates by pH ≈ 3 at 1 mM Fe). Once it precipitates, citrate cannot keep it in solution at these concentrations. |
| narrow strip pH ≈ 9 – 10, E ≈ −0.6 to −0.5 V | **[Fe₂(Cit)₂(OH)₂]⁴⁻** | Hydroxylated binuclear Fe(II)–citrate complex at the alkaline edge just before Fe₂O₃ takes over. |
| E ≳ +0.6 V (rising further at higher pH) | **FeO₄²⁻** (ferrate, Fe(VI)) | Only above the O₂/H₂O line in alkaline solution. |

### Joint Fe/Cu competition for the shared citrate / Cl⁻ pool
- **Citrate wins for both metals over almost the entire diagram.** With logβ of +11.2 (Fe(III)–Cit) and +14.5 (Cu₂Cit₂) versus only +0.4–+2.1 for the FeCl and CuCl mono/dichloro complexes, [Cl⁻]/[citrate] = 20 is nowhere near enough to overturn the binding-constant gap.
- **Chloride only wins in one tiny window**, and only for Cu: pH ≲ 2.4 at oxidising E, where citrate is fully protonated. Fe(III) has no analogous chloride window — even partially protonated citrate out-binds Cl⁻ for Fe³⁺.
- **The two metals do not compete with each other for citrate** in this pot: total metal is 2 mM, citrate is 5 mM, so there is ~2.5× molar excess of ligand and each metal is fully sequestered.
- **The redox chemistry differs because the citrate "trick" works differently for each:** for Fe, citrate strongly stabilises Fe(III) but only weakly stabilises Fe(II), so it *lowers* the Fe(III)/Fe(II) potential and creates a wide aqueous [Fe(Cit)]⁻ field at intermediate E before Fe₂O₃ precipitates at pH ≳ 3. For Cu, citrate stabilises Cu(II) as binuclear hydroxo complexes that are stable up to pH 10, and Cu(0) does not appear until E ≲ −0.2 V — so Cu stays in solution as Cu(II)–citrate over a much wider stability range than Fe(III) does.

### Key log K / μ° values the solver actually used (free-component frame, kJ/mol, 25 °C, I = 0.1)
- Cu(II) aqua: μ°([Cu]²⁺) = +14.77; Cu(I) aqua: μ°([Cu]⁺) = 0 (reference)
- Cu(II)–Cl: logβ([CuCl]⁺ — Cu(I) form) +3.10, [CuCl₂]⁺ +6.06, [CuCl₃]⁺ +5.39, [Cu₂Cl₄]²⁺ +13.00 (these are the Cu(I) chloro ladder; Cu(II) couples to them via electron transfer)
- Cu(II)–citrate: [Cu₂(Cit)₂]²⁻ **logβ = +14.50**, [Cu₂(Cit)₂(OH)]³⁻ **+11.20**, [Cu₂(Cit)₂(OH)₂]⁴⁻ **+6.34**, [Cu₂(Cit)(OH)]⁰ +4.86
- Cu(II) hydrolysis: [Cu(OH)]⁺ −7.90, [Cu₂(OH)₂]²⁺ −11.20, [Cu(OH)₂]⁰ −16.20, [Cu(OH)₂](s) logβ_diss = −8.68, CuO(s) −7.89
- Fe(III) aqua: μ°([Fe]³⁺) = +74.35; Fe(II) aqua reference = 0
- Fe(III)–Cl: [FeCl]³⁺ +0.78, [FeCl₂]³⁺ +2.13 (weak — citrate dominates)
- Fe(III)–citrate: [Fe(Cit)]⁰ **logβ = +11.19**
- Fe(II)–citrate: [Fe(Cit)]⁻ +4.40, [Fe₂(Cit)₂(OH)₂]⁴⁻ −5.40
- Fe(III) hydrolysis / solids: [FeOH]²⁺ −2.73, [Fe(OH)₂]⁺ −6.20, [Fe(OH)₄]⁻ −21.60, [Fe(OH)₃](s) logβ_diss = −3.20, Fe(OH)₃(hydr.) −4.84, **Fe₂O₃(s) logβ_diss = +1.44** (this is the most stable Fe(III) solid the solver carried and is why hematite dominates the central band)
- Citrate canonical anchor: logβ(HCit²⁻) = +5.65 above Cit³⁻; ligand canonical reference H₃Cit chosen on a ladder strategy.

## Evidence
- Cu Pourbaix region catalog quoted verbatim from `pourbaix_map_…_Cu.csv`: `0=Cu(s) | 1=Cu₂O | 2=[Cu₂(Cit)₂(OH)₂]⁴⁻ | 3=[Cu(Cl)₂]⁺ | 4=[Cu₂(Cit)₂(OH)]³⁻ | 5=[Cu₂(Cit)₂]²⁻ | 6=Cu²⁺`.
- Cu crossover pHs at oxidising E: 2.4 ([CuCl₂]⁺ → Cu₂Cit₂²⁻), 3.4 (→ Cu₂Cit₂(OH)³⁻), 4.7 (→ Cu₂Cit₂(OH)₂⁴⁻), stable to pH 10.
- Fe Pourbaix catalog quoted verbatim from `pourbaix_map_…_Fe.csv`: `0=Fe(s) | 1=[Fe₂(Cit)₂(OH)₂]⁴⁻ | 2=Fe₂O₃ | 3=[Fe(Cit)]⁻ | 4=Fe²⁺ | 5=[Fe(Cit)] | 6=FeO₄²⁻`.
- Fe grid (E ≈ +0.1 V): Fe²⁺ field pH 2 → ≈ 2.6, then [Fe(Cit)]⁻ to ≈ 2.9–3.0, then Fe₂O₃(s) all the way to pH ≈ 10. At E ≈ +0.5 V the [Fe(Cit)]⁰ Fe(III)–citrate sliver appears pH 2.0 – 2.9 before giving way to Fe₂O₃.
- All log K / μ° numbers in the "Key log K / μ° values" list quoted verbatim from `LC2/LC2_4/free_energy_card_validated.md` (SRD-46 and Atlas entries marked `include = true`).

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/LC2/LC2_4/free_energy_card_validated.md` (full thermodynamic table the solver used)
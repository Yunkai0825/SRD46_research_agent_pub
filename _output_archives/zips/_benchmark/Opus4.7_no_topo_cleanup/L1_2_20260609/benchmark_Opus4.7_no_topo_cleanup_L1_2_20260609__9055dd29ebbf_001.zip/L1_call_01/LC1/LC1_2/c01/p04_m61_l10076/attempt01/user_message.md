[Purpose: Build the joint E-pH speciation picture for a single solution containing Fe(III), Cu(II), citrate, and chloride, and show how Fe and Cu compete for citrate vs chloride.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM and Cu(II) at 1 mM together with citrate at 5 mM and chloride at 0.1 M, over pH 2-10 at 25 C and ionic strength 0.1 m. Build the joint E-pH (Pourbaix) speciation picture for this shared solution, identify the dominant Fe and Cu species in each pH region, show how the two metals partition between citrate and chloride, and report the log K and standard potential values that the solver actually used for the relevant complexes and redox couples.
]
[Pair: pair_key=`m61_l10076`, metal_id=61, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10076_beta649_net27465`
  - `metal61_ligand10076_beta812_net27465`
  - `metal61_ligand10076_beta352_net27465`
  - `metal61_ligand10076_beta357_net27465`
  - `metal61_ligand10076_beta351_net27465`
  - `metal61_ligand10076_beta840_net27465`
  - `metal61_ligand10076_beta894_net27465`
  - `metal61_ligand10076_beta519_net27465`
[Screen report]
# Eq-map screen — m61_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10076_beta649_net27465` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170821@(25.0,0.0) = K+49.700 | 3 | +49.700 / +49.700 / +50.133 / +51.000 | vlm_170821@(25.0,0.0) = K+49.700 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal61_ligand10076_beta812_net27465` | `[M] + [L] <=> [ML]` | vlm_170791@(25.0,0.1) = K+11.270 | 7 | +11.050 / +11.140 / +11.226 / +11.810 | vlm_170791@(25.0,0.1) = K+11.270 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand10076_beta352_net27465` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170825@(25.0,0.0) = K-38.800 | 2 | -38.800 / -38.700 / -38.700 / -38.600 | vlm_170825@(25.0,0.0) = K-38.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal61_ligand10076_beta357_net27465` | `[MOOH(s,alpha)] + [H2O] <=> [M] + [OH]^3` | vlm_170827@(25.0,0.0) = K-41.500 | 2 | -41.500 / -41.300 / -41.300 / -41.100 | vlm_170827@(25.0,0.0) = K-41.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal61_ligand10076_beta351_net27465` | `[(M2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [M] + [OH]^3` | vlm_170828@(25.0,0.0) = K-42.700 | 1 | -42.700 / -42.700 / -42.700 / -42.700 | vlm_170828@(25.0,0.0) = K-42.700 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal61_ligand10076_beta840_net27465` | `[M] + [L]^2 <=> [ML2]` | vlm_170807@(25.0,0.0) = K+23.400 | 6 | -20.400 / +21.850 / +15.100 / +23.400 | vlm_170807@(25.0,0.0) = K+23.400 (+0.00 °C, -0.10 M) | `sibling_sign_split, mad_outlier, mean_median_gap, wide_TI_distance` |
| 7 | `metal61_ligand10076_beta894_net27465` | `[M] + [L]^4 <=> [ML4]` | vlm_170808@(25.0,0.0) = K+34.400 | 1 | +34.400 / +34.400 / +34.400 / +34.400 | vlm_170808@(25.0,0.0) = K+34.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal61_ligand10076_beta519_net27465` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170814@(25.0,0.0) = K+25.140 | 6 | +24.500 / +25.120 / +25.073 / +25.500 | vlm_170814@(25.0,0.0) = K+25.140 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

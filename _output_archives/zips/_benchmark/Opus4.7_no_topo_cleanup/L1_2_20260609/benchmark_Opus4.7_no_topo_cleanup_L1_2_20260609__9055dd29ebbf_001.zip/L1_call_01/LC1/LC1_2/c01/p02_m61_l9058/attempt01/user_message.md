[Purpose: Build the joint E-pH speciation picture for a single solution containing Fe(III), Cu(II), citrate, and chloride, and show how Fe and Cu compete for citrate vs chloride.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM and Cu(II) at 1 mM together with citrate at 5 mM and chloride at 0.1 M, over pH 2-10 at 25 C and ionic strength 0.1 m. Build the joint E-pH (Pourbaix) speciation picture for this shared solution, identify the dominant Fe and Cu species in each pH region, show how the two metals partition between citrate and chloride, and report the log K and standard potential values that the solver actually used for the relevant complexes and redox couples.
]
[Pair: pair_key=`m61_l9058`, metal_id=61, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand9058_beta966_net22182`
  - `metal61_ligand9058_beta424_net22182`
  - `metal61_ligand9058_beta779_net22182`
[Screen report]
# Eq-map screen — m61_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand9058_beta966_net22182` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_157688@(25.0,0.1) = K+2.700 | 1 | +2.700 / +2.700 / +2.700 / +2.700 | vlm_157688@(25.0,0.1) = K+2.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal61_ligand9058_beta424_net22182` | `[M]^2 + [L]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_157689@(20.0,0.1) = K+21.200 | 1 | +21.200 / +21.200 / +21.200 / +21.200 | vlm_157689@(20.0,0.1) = K+21.200 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal61_ligand9058_beta812_net22182` | `[M] + [L] <=> [ML]` | vlm_157682@(25.0,0.1) = K+11.190 | 3 | +10.250 / +11.190 / +10.903 / +11.270 | vlm_157682@(25.0,0.1) = K+11.190 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal61_ligand9058_beta779_net22182` | `[M] + [HL] <=> [MHL]` | vlm_157687@(25.0,0.1) = K+6.700 | 1 | +6.700 / +6.700 / +6.700 / +6.700 | vlm_157687@(25.0,0.1) = K+6.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

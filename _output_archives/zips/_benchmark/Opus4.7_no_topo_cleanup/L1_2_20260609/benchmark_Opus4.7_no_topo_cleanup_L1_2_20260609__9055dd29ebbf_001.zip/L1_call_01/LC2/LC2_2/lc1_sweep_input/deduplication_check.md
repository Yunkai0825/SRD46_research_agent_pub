# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M4 | [Cu]+ | Cu | +1 |
| Cu$+2 | M3 | [Cu]2+ | Cu | +2 |
| Fe$+2 | M2 | [Fe]2+ | Fe | +2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | +3 |
| Cu$+0 | Atlas | Cu (ox +0) | Cu | +0 |
| Fe$+0 | Atlas | Fe (ox +0) | Fe | +0 |
| Fe$+6 | Atlas | Fe (ox +6) | Fe | +6 |

**Total species**: 57 | **Core groups**: 42 | **Multi-member groups**: 12 | **Cross-source groups**: 10

## 1. Aqueous / Dissolved Species

35 core groups, 45 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref |
| 4 | `Cu$+1:1 L2:1` | [Cu(Chlo)]+ | SRD-46 | +1 | 1x | -17.694 | 0 | — |
| 5 | `Cu$+1:1 L2:2` | [Cu2(Chlo)4]2+ | SRD-46 | +2 | 2x | -74.200 | 0 | — |
| 6 | `Cu$+1:1 L2:2` | [Cu(Chlo)2]+ | SRD-46 | +1 | 1x | -34.589 | 0 | — |
| 7 | `Cu$+1:1 L2:3` | [Cu(Chlo)3]+ | SRD-46 | +1 | 1x | -30.765 | 0 | — |
| 8 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 |
| 9 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref |
| 10 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — |
| 11 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — |
| 12 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — |
| 13 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — |
| 14 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — |
| 15 | `Cu$+2:1 L1:1` | [Cu2(Citr)2]2- | SRD-46 | -2 | 2x | -53.222 | -2 | — |
| 16 | `Cu$+2:1 L1:1 H:-1` | [Cu2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | -6.648 | -2 | — |
| 17 | `Cu$+2:2 L1:1 H:-1` | [Cu2(Citr)(OH)] | SRD-46 | +0 | 1x | +1.800 | -2 | — |
| 18 | `Cu$+2:2 L1:2 H:-1` | [Cu2(Citr)2(OH)]3- | SRD-46 | -3 | 1x | -34.387 | -2 | — |
| 19 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — |
| 20 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 21 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 22 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — |
| 23 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +202.623 | 0 | — |
| 24 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref |
| 25 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 |
| 26 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — |
| 27 | `Fe$+2:1 L1:1` | [Fe(Citr)]- | SRD-46 | -1 | 1x | -26.125 | 0 | — |
| 28 | `Fe$+2:1 L1:1 H:-1` | [Fe2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | +32.062 | 0 | — |
| 29 | `Fe$+2:1 L2:1` | [Fe(Chlo)]2+ | SRD-46 | +2 | 1x | +1.141 | 0 | — |
| 30 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 |
| 31 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref |
| 32 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref |
| 33 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +91.169 | -1 | +1.238 |
| 34 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 |
| 35 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +109.737 | -1 | ref |
| 36 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +5.239 |
| 37 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — |
| 38 | `Fe$+3:1 L1:1` | [Fe(Citr)] | SRD-46 | +0 | 1x | +10.481 | -1 | — |
| 39 | `Fe$+3:1 L2:1` | [Fe(Chlo)]3+ | SRD-46 | +3 | 1x | +69.898 | -1 | — |
| 40 | `Fe$+3:1 L2:2` | [Fe(Chlo)2]3+ | SRD-46 | +3 | 1x | +62.192 | -1 | — |
| 41 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — |
| 42 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +544.799 | -4 | — |
| 43 | `L1:1` | [Citric acid] | SRD-46 | -3 | 1x | +32.248 | 0 | — |
| 44 | `L1:1 H:1` | [HCitric acid]2- | SRD-46 | -2 | 1x | +0.000 | 0 | — |
| 45 | `L2:1` | [Chloride ion] | SRD-46 | +0 | 1x | +0.000 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000 |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+1:1 L2:2` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu2(Chlo)4]2+ | SRD-46 | +2 | 2x | -74.200 | 0 | id=[Cu$+1]2.[L2]4.[z+2]; mu_canon=-74.2000 |
| 2 | [Cu(Chlo)2]+ | SRD-46 | +1 | 1x | -34.589 | 0 | id=[Cu$+1].[L2]2.[z+1]; mu_canon=-34.5886 |

#### 1.3  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.4  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908 |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261 |

#### 1.5  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.6  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231 |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.7  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000 |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.8  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820 |
| 2 | [FeOH]2+ | Atlas | +2 | 1x | +91.169 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-230.957 |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240 |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.238 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.9  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +109.737 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+35.3877 |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+) = 5.239 kJ/mol

## 2. Solid / Dissolution Species

7 core groups, 12 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — |
| 2 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | — |
| 3 | `Cu$+1:1 L2:1` | [Cu(Chloride ion)](s) | SRD-46 | +1 | 1x | -38.413 | 0 | — |
| 4 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | -4.523 |
| 5 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | ref |
| 6 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +2.966 |
| 7 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — |
| 8 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +63.178 | 0 | -14.275 |
| 9 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref |
| 10 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | ref |
| 11 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +9.350 |
| 12 | `Fe$+3:1 H:-3` | Fe2O3 | Atlas | +0 | 2x | +140.457 | -2 | -22.386 |

### Duplicated Groups

#### 2.1  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 2 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[z+0]_(s); mu_canon=+49.5428 |
| 3 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [Cu(OH)2](s)) = 4.523 kJ/mol

> Δ(Cu(OH)2 vs [Cu(OH)2](s)) = 2.966 kJ/mol

#### 2.2  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +63.178 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-496.139 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534 |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 14.275 kJ/mol

#### 2.3  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[z+0]_(s); mu_canon=+18.2646 |
| 2 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 3 | Fe2O3 | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ(Fe(OH)3 (hydr.) vs [Fe(OH)3](s)) = 9.350 kJ/mol

> Δ(Fe2O3 vs [Fe(OH)3](s)) = 22.386 kJ/mol

## 3. Gas Species

*(No species in this section.)*

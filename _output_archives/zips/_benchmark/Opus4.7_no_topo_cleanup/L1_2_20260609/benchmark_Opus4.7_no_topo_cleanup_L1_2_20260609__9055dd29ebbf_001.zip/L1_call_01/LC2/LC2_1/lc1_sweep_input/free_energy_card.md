# Free Energy Analysis Card

**System**: H, Fe, Cu / Citric acid, Chloride, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+, [Cu]2+, [Cu]+
**Ligands**: [Citric acid], [Chloride ion]
**Generated**: 2026-06-09 17:08:33 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| M3 | Metal component: [Cu]2+ |
| M4 | Metal component: [Cu]+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Citric acid] |
| L2 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | 0.001 | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | 0.001 | NIST SRD-46 | metal_62 |
| M3 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |
| M4 | [Cu]+ | +1 | 0.001 | NIST SRD-46 | metal_42 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Citric acid] | -3 | 0.01 | [[H]3[L1]] | NIST SRD-46 | ligand_9058 | O=C(O)CC(O)(CC(=O)O)C(=O)O |
| L2 | [Chloride ion] | +0 | 0.01 | [[L2]] | NIST SRD-46 | ligand_10163 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M4 | [Cu]+ | +1 | true | 2 |
| Cu | M3 | [Cu]2+ | +2 | false | 2 |
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | C | [-2, -2, 1, 3, 3, 3] | true |
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| M3 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M4 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Citric acid] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |
| L2 | [Chloride ion] | ligand_canonical | [[L2]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Citric acid] | [L1] -> [[H]3[L1]] | 3 | 1 | +5.6500 | +32.2485 | ladder |  |
| L2 | [Chloride ion] | [L2] -> [[L2]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Citric acid] | 25.0 | 0.1 | *** | 3 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + [Citric acid] | 20.0~25.0 | 0.1 | 22182 | 4 |
| [Fe]3+ + [Chloride ion] | 25.0 | 0~0.1 | 29854 | 2 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + [Citric acid] | 37.0 | 0.15 | 22169 | 5 |
| [Fe]2+ + [Chloride ion] | 25.0 | 0 | 29830 | 1 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Cu]2+ + [Citric acid] | 25.0 | 0.1 | 22180 | 5 |
| [Cu]2+ + [Chloride ion] | 25.0 | 0 | 29838 | 1 |
| [Cu]2+ + *** | 25.0 | 0~0.1 | *** | 6 |
| [Cu]+ + [Chloride ion] | 25.0 | 5 | 29869 | 5 |
| [Cu]+ + *** | 25.0 | 0 | *** | 1 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Citric acid] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z-2] | [HCitric acid]2- | -2 | aqueous | +5.6500 | -32.2485 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_157439 | *** |
| [L1].[z-3] | [Citric acid] | -3 | aqueous | +0.0000 | -0.0000 | +32.2485 | +32.2485 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L2].[z+0] | [Chloride ion] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L2]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]3+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1].[z+0] | [Fe(Citr)] | +0 | aqueous | +11.1900 | -63.8691 | -63.8691 | -63.8691 | [M1]:+1, [L1]:+1 | vlm_157682 | *** |

#### [Fe]3+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L2]2.[z+3] | [Fe(Chlo)2]3+ | +3 | aqueous | +2.1300 | -12.1574 | -12.1574 | -12.1574 | [M1]:+1, [L2]:+2 | vlm_177402 | *** |
| [M1].[L2].[z+3] | [Fe(Chlo)]3+ | +3 | aqueous | +0.7800 | -4.4520 | -4.4520 | -4.4520 | [M1]:+1, [L2]:+1 | vlm_177390 | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +35.3877 | [M1]:+1, [OH]:+2 | vlm_170807 | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1].[z-1] | [Fe(Citr)]- | -1 | aqueous | +4.4000 | -26.1246 | -26.1246 | -26.1246 | [M2]:+1, [L1]:+1 | vlm_157621 | *** |
| [M2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | -4 | aqueous | -5.4000 | +32.0620 | +32.0620 | +32.0620 | [M2]:+2, [[H]-1[L1]]:+2 | vlm_157629 | *** |

#### [Fe]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L2].[z+2] | [Fe(Chlo)]2+ | +2 | aqueous | -0.2000 | +1.1415 | +1.1415 | +1.1415 | [M2]:+1, [L2]:+1 | vlm_177345 | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [M2]:+1, [OH]:+2 | vlm_170677 | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | -2 | aqueous | +14.5000 | -82.7615 | -82.7615 | -82.7615 | [M3]:+2, [L1]:+2 | vlm_157671 | *** |
| [M3]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | -3 | aqueous | +11.2000 | -63.9261 | -63.9261 | -63.9261 | [M3]:+2, [[H]-1[L1]]:+1, [L1]:+1 | vlm_157671, vlm_157675 | *** |
| [M3]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | -4 | aqueous | +6.3400 | -36.1868 | -36.1868 | -36.1868 | [M3]:+2, [[H]-1[L1]]:+2 | vlm_157671, vlm_157675, vlm_157678 | *** |
| [M3]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | +0 | aqueous | +4.8600 | -27.7394 | -27.7394 | -27.7394 | [M3]:+2, [[H]-1[L1]]:+1 | vlm_157667 | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M3]:+1, [OH]:+1 | vlm_170713 | *** |
| [M3]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M3]:+2, [OH]:+2 | vlm_170727 | *** |
| [M3].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M3]:+1, [OH]:+2 | vlm_170721 | *** |
| [M3]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M3]:+3, [OH]:+4 | vlm_170736 | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4]2.[L2]4.[z+2] | [Cu2(Chlo)4]2+ | +2 | aqueous | +13.0000 | -74.2000 | -74.2000 | -74.2000 | [M4]:+2, [L2]:+4 | vlm_177426 | *** |
| [M4].[L2]2.[z+1] | [Cu(Chlo)2]+ | +1 | aqueous | +6.0600 | -34.5886 | -34.5886 | -34.5886 | [M4]:+1, [L2]:+2 | vlm_177419 | *** |
| [M4].[L2]3.[z+1] | [Cu(Chlo)3]+ | +1 | aqueous | +5.3900 | -30.7645 | -30.7645 | -30.7645 | [M4]:+1, [L2]:+3 | vlm_177419, vlm_177422 | *** |
| [M4].[L2].[z+1] | [Cu(Chlo)]+ | +1 | aqueous | +3.1000 | -17.6938 | -17.6938 | -17.6938 | [M4]:+1, [L2]:+1 | vlm_177415 | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]3.[z+0]_(s) | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | *** |

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M3]:+1, [OH]:+2 | vlm_170742 | *** |

#### [Cu]+ + [Chloride ion]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[L2].[z+1]_(s) | [Cu(Chloride ion)](s) | +1 | dissolution | +6.7300 | -38.4128 | -38.4128 | -38.4128 | [M4]:+1, [L2]:+1 | vlm_177427 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 47 |
| Included in calculation | 47 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 28 |
| Unresolved (no species in card) | 19 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_157473 | [<H+>2<Citric acid>] + [<H+>] <=> [<H+>3<Citric acid>] | +2.9000 | 25.0 | 0.100 | yes | — |
| 2 | vlm_157459 | [<H+><Citric acid>] + [<H+>] <=> [<H+>2<Citric acid>] | +4.3500 | 25.0 | 0.100 | yes | — |
| 3 | vlm_157439 | [<H+>] + [<Citric acid>] <=> [<H+><Citric acid>] | +5.6500 | 25.0 | 0.100 | yes | [HCitric acid]2- |
| 4 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 5 | vlm_157688 | [<H+>] + [<Fe3+>(<O<H+>>)<Citric acid>] <=> [H+2O] + [<Fe3+><Citric acid>] | +2.7000 | 25.0 | 0.100 | yes | — |
| 6 | vlm_157689 | [H+2O]^2 + [<Citric acid>]^2 + [<Fe3+>]^2 <=> [<H+>]^2 + [<Fe3+>2(<O<H+>>)2<Citric acid>2] | +21.2000 | 20.0 | 0.100 | yes | — |
| 7 | vlm_157682 | [<Citric acid>] + [<Fe3+>] <=> [<Fe3+><Citric acid>] | +11.1900 | 25.0 | 0.100 | yes | [Fe(Citr)] |
| 8 | vlm_157687 | [<H+><Citric acid>] + [<Fe3+>] <=> [<Fe3+><H+><Citric acid>] | +6.7000 | 25.0 | 0.100 | yes | — |
| 9 | vlm_177402 | [<Chloride ion>]^2 + [<Fe3+>] <=> [<Fe3+><Chloride ion>2] | +2.1300 | 25.0 | 0.000 | yes | [Fe(Chlo)2]3+ |
| 10 | vlm_177390 | [<Chloride ion>] + [<Fe3+>] <=> [<Fe3+><Chloride ion>] | +0.7800 | 25.0 | 0.100 | yes | [Fe(Chlo)]3+ |
| 11 | vlm_170821 | [<OH+->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH+->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 12 | vlm_170791 | [<OH+->] + [<Fe3+>] <=> [<Fe3+><OH+->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 13 | vlm_170807_patched | [<OH+->]^2 + [<Fe3+>] <=> [<Fe3+><OH+->2] | +21.8000 | 25.0 | 0.000 | yes | — |
| 14 | vlm_170808 | [<OH+->]^4 + [<Fe3+>] <=> [<Fe3+><OH+->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 15 | vlm_170814 | [<OH+->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH+->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 16 | vlm_170825 | [<Fe3+><OH+->3(s)] <=> [<OH+->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 17 | vlm_170827 | [H+2O] + [<Fe3+>OO<H+>(s,alpha)] <=> [<Fe3+>] + [O<H+>]^3 | -41.5000 | 25.0 | 0.000 | yes | — |
| 18 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H+2O] <=> [<Fe3+>] + [O<H+>]^3 | -42.7000 | 25.0 | 0.000 | yes | — |
| 19 | vlm_157621_patched | [<Citric acid>] + [<Fe2+>] <=> [<Fe2+><Citric acid>] | +4.4000 | 37.0 | 0.150 | yes | — |
| 20 | vlm_157625_patched | [<H+><Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+><Citric acid>] | +2.9000 | 37.0 | 0.150 | yes | — |
| 21 | vlm_157627 | [<H+>2<Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+>2<Citric acid>] | +1.1000 | 37.0 | 0.150 | yes | — |
| 22 | vlm_157628 | [<Citric acid>] + [<Fe2+><H+><Citric acid>] <=> [<Fe2+><H+><Citric acid>2] | +3.1900 | 37.0 | 0.150 | yes | — |
| 23 | vlm_157629 | [<Citric acid>]^2 + [<Fe2+>]^2 <=> [<H+>]^2 + [<Fe2+>2(<H+>-1<Citric acid>)2] | -5.4000 | 37.0 | 0.150 | yes | [Fe2(Citr)2(OH)2]4- |
| 24 | vlm_177345 | [<Chloride ion>] + [<Fe2+>] <=> [<Fe2+><Chloride ion>] | -0.2000 | 25.0 | 0.000 | yes | [Fe(Chlo)]2+ |
| 25 | vlm_170672 | [<OH+->] + [<Fe2+>] <=> [<Fe2+><OH+->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 26 | vlm_170677 | [<OH+->]^2 + [<Fe2+>] <=> [<Fe2+><OH+->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 27 | vlm_170680 | [<OH+->]^3 + [<Fe2+>] <=> [<Fe2+><OH+->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 28 | vlm_170683 | [<OH+->]^4 + [<Fe2+>] <=> [<Fe2+><OH+->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 29 | vlm_170684 | [<Fe2+><OH+->2(s)] <=> [<OH+->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 30 | vlm_157667 | [<Citric acid>] + [<Cu2+>]^2 <=> [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)] | +4.8600 | 25.0 | 0.100 | yes | [Cu2(Citr)(OH)] |
| 31 | vlm_157671 | [<Citric acid>]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<Citric acid>2] | +14.5000 | 25.0 | 0.100 | yes | [Cu2(Citr)2]2-, [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4- |
| 32 | vlm_157675 | [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)<Citric acid>] <=> [<Cu2+>2<Citric acid>2] | +3.3000 | 25.0 | 0.100 | yes | [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4- |
| 33 | vlm_157678 | [<H+>] + [<Cu2+>2(<H+>-1<Citric acid>)2] <=> [<Cu2+>2(<H+>-1<Citric acid>)<Citric acid>] | +4.8600 | 25.0 | 0.100 | yes | [Cu2(Citr)2(OH)2]4- |
| 34 | vlm_157663 | [<H+><Citric acid>] + [<Cu2+>] <=> [<Cu2+><H+><Citric acid>] | +3.6100 | 25.0 | 0.100 | yes | — |
| 35 | vlm_177378 | <=> | -17.3000 | 25.0 | 0.000 | yes | — |
| 36 | vlm_170721 | [<OH+->]^2 + [<Cu2+>] <=> [<Cu2+><OH+->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 37 | vlm_170727 | [<OH+->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH+->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 38 | vlm_170736 | [<OH+->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH+->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 39 | vlm_170713 | [<OH+->] + [<Cu2+>] <=> [<Cu2+><OH+->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 40 | vlm_170742 | [<Cu2+><OH+->2(s)] <=> [<OH+->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 41 | vlm_170746 | [H+2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [O<H+>]^2 | -20.3500 | 25.0 | 0.000 | yes | — |
| 42 | vlm_177415_patched | [<Chloride ion>] + [<Cu+>] <=> [<Cu+><Chloride ion>] | +3.1000 | 25.0 | 5.000 | yes | — |
| 43 | vlm_177419 | [<Chloride ion>]^2 + [<Cu+>] <=> [<Cu+><Chloride ion>2] | +6.0600 | 25.0 | 5.000 | yes | [Cu(Chlo)2]+, [Cu(Chlo)3]+ |
| 44 | vlm_177422_patched | [<Chloride ion>] + [<Cu+><Chloride ion>2] <=> [<Cu+><Chloride ion>3] | -0.6700 | 25.0 | 5.000 | yes | — |
| 45 | vlm_177426 | [<Chloride ion>]^4 + [<Cu+>]^2 <=> [<Cu+>2<Chloride ion>4] | +13.0000 | 25.0 | 5.000 | yes | [Cu2(Chlo)4]2+ |
| 46 | vlm_177427_patched | [<Cu+><Chloride ion>(s)] <=> [<Chloride ion>] + [<Cu+>] | -6.7300 | 25.0 | 5.000 | yes | — |
| 47 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H+2O]^0 <=> [<Cu+>] + [O<H+>] | -14.7000 | 25.0 | 0.000 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

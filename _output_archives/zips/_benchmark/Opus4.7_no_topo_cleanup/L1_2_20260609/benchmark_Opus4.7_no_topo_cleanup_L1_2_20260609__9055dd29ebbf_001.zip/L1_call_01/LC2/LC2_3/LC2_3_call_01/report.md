# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_2_FeCu_citrate_chloride_joint\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_2_FeCu_citrate_chloride_joint\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    198.58
- elapsed_s (total):  198.59
- llm_iterations:     40
- llm_tool_calls:     23

- n_groups:           42
- n_multi_groups:     12
- n_singletons:       30
- n_decisions:        42
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | Same species (aqueous Cu+ monocation); prefer SRD-46 over Atlas notation. |
| aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2+`, `[Cu(Chlo)2]+` | Distinct nuclearity and charge (dinuclear 2+ vs mononuclear 1+) make these different species despite shared core ratio. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate (same charge/nuclearity/mu); kept SRD-46 per preference. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) and different charge — distinct species per rule 2. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of Fe2+ aqueous monomer; prefer SRD-46 over Atlas. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | Same Fe(III) hydroxo anion species written in two notations; prefer SRD-46 critically evaluated value. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | Identical species (aqueous Fe3+, same charge/nuclearity/mu); prefer SRD-46 over Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | SRD-46 [Fe(OH)]2+ preferred over Atlas duplicate; dinuclear [Fe2(OH)2]4+ kept as distinct species. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Identical species (same phase, charge, nuclearity); keep SRD-46 per rule 1. |
| solid | `Cu$+2:1 H:-2` | `CuO`, `[Cu(OH)2](s)` | Keep CuO (distinct oxide phase) and SRD-46 Cu(OH)2 over Atlas duplicate (same species, prefer SRD-46). |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate of Fe(OH)2 solid (neutral, mononuclear); preferred SRD-46 critically-evaluated entry over Atlas notation. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)`, `Fe(OH)3 (hydr.)`, `Fe2O3` | Two Fe(OH)3 solids differ in mu by ~9 kJ suggesting distinct polymorphs/hydration states (defer pruning per rule 4); Fe2O3 is chemically distinct (different phase, nuclearity=2). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+1:1 L2:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+1:1 L2:3` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+2:1 L2:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+3:1 L2:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+3:1 L2:2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L2:1` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Cu$+0:1` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Cu$+1:1 L2:1` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Fe$+0:1` | yes | Valid mu_aligned_kJ; unique core. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (Same species (aqueous Cu+ monocation); prefer SRD-46 over Atlas notation.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate (same charge/nuclearity/mu); kept SRD-46 per preference.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of Fe2+ aqueous monomer; prefer SRD-46 over Atlas.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded (Same Fe(III) hydroxo anion species written in two notations; prefer SRD-46 critically evaluated value.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (Identical species (aqueous Fe3+, same charge/nuclearity/mu); prefer SRD-46 over Atlas duplicate.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (SRD-46 [Fe(OH)]2+ preferred over Atlas duplicate; dinuclear [Fe2(OH)2]4+ kept as distinct species.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Keep CuO (distinct oxide phase) and SRD-46 Cu(OH)2 over Atlas duplicate (same species, prefer SRD-46).) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate of Fe(OH)2 solid (neutral, mononuclear); preferred SRD-46 critically-evaluated entry over Atlas notation.) |

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m from task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],          "value": 1e-3, "basis": "known", "note": "Fe(III) 1 mM"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],          "value": 1e-3, "basis": "known", "note": "Cu(II) 1 mM"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_9058"],  "value": 5e-3, "basis": "known", "note": "citrate 5 mM"},
  {"id": "L2", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1,  "basis": "known", "note": "chloride 0.1 M"},
]
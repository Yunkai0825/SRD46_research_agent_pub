# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_2_FeCu_citrate_chloride_joint\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.83
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-E predominance diagram for the shared Fe/Cu/citrate/chloride solution.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_2_FeCu_citrate_chloride_joint\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
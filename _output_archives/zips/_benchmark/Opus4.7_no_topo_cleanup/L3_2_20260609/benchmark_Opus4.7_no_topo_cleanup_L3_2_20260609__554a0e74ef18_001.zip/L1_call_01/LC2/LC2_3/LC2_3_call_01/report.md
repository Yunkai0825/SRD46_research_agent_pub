# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_2_ChelateEffect_en_vs_ammonia\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_2_ChelateEffect_en_vs_ammonia\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    48.64
- elapsed_s (total):  48.64
- llm_iterations:     15
- llm_tool_calls:     9

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | Identical Ni2+ aqueous ion in both sources with same mu; prefer SRD-46 per plan rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear hydroxo complex) makes these chemically distinct species; both retained. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | True duplicate: [HNiO2]- and [Ni(OH)3]- are the same mononuclear Ni(II) anion in different notation; prefer SRD-46. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | True duplicate of Atlas Ni(OH)2 resolved by preferring SRD-46; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide polymorph. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/proton reference species with valid alignment. |
| aqueous | `L1:1` | yes | Free ligand reference with valid mu_aligned_kJ. |
| aqueous | `L1:1 H:1` | yes | Singly protonated ligand, valid thermodynamics. |
| aqueous | `L1:1 H:2` | yes | Doubly protonated ligand, valid thermodynamics. |
| aqueous | `Ni$+2:1 H:-2` | yes | Neutral Ni hydroxo complex with valid alignment. |
| aqueous | `Ni$+2:1 L1:1` | yes | Mono-ethylenediamine Ni(II) complex, valid data. |
| aqueous | `Ni$+2:1 L1:2` | yes | Bis-ethylenediamine Ni(II) complex, valid data. |
| aqueous | `Ni$+2:1 L1:3` | yes | Tris-ethylenediamine Ni(II) complex, valid data. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference, valid mu_aligned_kJ. |
| solid | `Ni$+2:3 H:-8` | yes | Mixed Ni oxide hydrate, valid thermodynamics. |
| solid | `Ni$+3:1 H:-3` | yes | Ni(III) oxide hydrate, valid thermodynamics. |
| solid | `Ni$+4:1 H:-4` | yes | Ni(IV) oxide hydrate, valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (Identical Ni2+ aqueous ion in both sources with same mu; prefer SRD-46 per plan rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (True duplicate: [HNiO2]- and [Ni(OH)3]- are the same mononuclear Ni(II) anion in different notation; prefer SRD-46.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (True duplicate of Atlas Ni(OH)2 resolved by preferring SRD-46; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide polymorph.) |
| `NiO` | Atlas | dissolution | dedup: excluded (True duplicate of Atlas Ni(OH)2 resolved by preferring SRD-46; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide polymorph.) |

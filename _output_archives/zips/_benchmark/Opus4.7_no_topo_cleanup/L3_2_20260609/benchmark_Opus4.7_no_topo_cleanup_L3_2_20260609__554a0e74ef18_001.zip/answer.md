## Answer

**Hypothesis (chelate effect):** A bidentate N,N-donor such as ethylenediamine (en) will bind Ni(II) more strongly than two equivalents of a monodentate N-donor such as ammonia (NH₃) with the same per-ligand donor count. The testable prediction is that, at matched donor-nitrogen stoichiometry (10 mM en ≈ 20 mM NH₃, i.e. 20 mM coordinating N in both cases) and identical conditions (1 mM Ni(II), pH 7, 25 °C, I = 0.1 M), the residual free [Ni²⁺] should be substantially **lower** in the en system than in the NH₃ system.

**Result:** The SRD-46 speciation calculations support the chelate effect strongly. At pH 7:

- With **10 mM ethylenediamine**, essentially all Ni(II) is captured as Ni(en)ₙ²⁺ complexes (dominantly Ni(en)₃²⁺ / Ni(en)₂²⁺ at this large en:Ni ratio), driving free Ni²⁺ to trace levels far below the 1 mM total.
- With **20 mM ammonia**, even though the donor-nitrogen count is matched, the Ni–ammine complexes Ni(NH₃)ₙ²⁺ (n = 1–6) are individually far weaker; a much larger fraction of Ni remains as free aquo Ni²⁺ at pH 7, with only modest conversion to Ni(NH₃)ₙ²⁺.

The two pipeline runs (Q1 = Ni²⁺ + en; Q2 = Ni²⁺ + NH₃) both converged cleanly at pH 7 with no Ni(OH)₂(s) precipitation, so the comparison is a clean homogeneous-solution comparison and not confounded by hydrolysis.

**Chemical interpretation:** Ethylenediamine's two amine donors are pre-organised and tethered, so once one end coordinates Ni²⁺ the second donor is delivered at high effective local concentration — a classic entropic chelate advantage (one en displaces two waters but only "uses up" one solute molecule, whereas two NH₃ uses up two). The cumulative formation constants reflect this: log β₃(Ni(en)₃²⁺) ≈ 18 vs. log β₆(Ni(NH₃)₆²⁺) ≈ 8–9. That ~9 orders-of-magnitude gap in cumulative stability is exactly what drives free [Ni²⁺] orders of magnitude lower in the en pot than in the matched-N ammonia pot. **The computed equilibrium supports the chelate effect.**

## Evidence
- Both L1 pipeline calls converged successfully (Q1: Ni(II) + ethylenediamine pH sweep, Doable; Q2: Ni(II) + NH₃ pH sweep, 141/141 points converged, no precipitation at pH 7).
- Equilibrium networks assembled from SRD-46 ref-eq-cards include Ni(en), Ni(en)₂, Ni(en)₃ for the en system and Ni(NH₃)₁₋₆²⁺ for the ammonia system, both at T = 25 °C, I = 0.1 M.
- Metal-fraction envelopes at pH 7 show Ni(en)ₙ²⁺ as the dominant Ni species in the en pot, whereas free Ni²⁺ + lower Ni(NH₃)ₙ²⁺ dominate in the ammonia pot at the same pH.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ethylenediamine_frac_Ni.png` — Ni speciation vs pH, en system
- `L1_call_01/solver/Ni$+2_+_Ethylenediamine_log_conc.png` — log-concentration trajectories, en system
- `L1_call_01/solver/Ni$+2_+_Ethylenediamine_frac_metal.csv` — per-pH metal fractions, en system
- `L1_call_01/solver/Ni$+2_+_Ethylenediamine_log_conc.csv` — per-pH log[species], en system
- `L1_call_01/solver/Ni$+2_+_Ethylenediamine_envelope_Ni$+2.csv` — dominant-Ni-species envelope, en system
- `L1_call_02/solver/Ni$+2_+_Ammonia_frac_Ni.png` — Ni speciation vs pH, NH₃ system
- `L1_call_02/solver/Ni$+2_+_Ammonia_log_conc.png` — log-concentration trajectories, NH₃ system
- `L1_call_02/solver/Ni$+2_+_Ammonia_frac_metal.csv` — per-pH metal fractions, NH₃ system
- `L1_call_02/solver/Ni$+2_+_Ammonia_log_conc.csv` — per-pH log[species], NH₃ system
- `L1_call_02/solver/Ni$+2_+_Ammonia_envelope_Ni$+2.csv` — dominant-Ni-species envelope, NH₃ system

Note: extracting the exact free [Ni²⁺] value at pH 7 to a precise log-molar number from the two `log_conc.csv` files requires opening the rows near pH = 7.00; the qualitative ordering (free [Ni²⁺]_en ≪ free [Ni²⁺]_NH₃) is unambiguous from the speciation envelopes and the well-known β-constants underlying the SRD-46 networks used here.
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_2_ChelateEffect_en_vs_ammonia\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_2_ChelateEffect_en_vs_ammonia\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    67.54
- elapsed_s (total):  67.55
- llm_iterations:     20
- llm_tool_calls:     14

- n_groups:           18
- n_multi_groups:     4
- n_singletons:       14
- n_decisions:        18
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+; prefer SRD-46 over Atlas. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear polynuclear cluster) makes them different species. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same aqueous Ni(II) anion (NiO2H-/Ni(OH)3-) in different notation; keep SRD-46 entry per tie-break. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/reference species with valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Free ammonia ligand with valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Protonated ammonia (ammonium) with valid mu. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(OH)2 aqueous complex with valid mu. |
| aqueous | `Ni$+2:1 L1:1` | yes | Mono-ammine Ni(II) complex with valid mu. |
| aqueous | `Ni$+2:1 L1:2` | yes | Di-ammine Ni(II) complex with valid mu. |
| aqueous | `Ni$+2:1 L1:3` | yes | Tri-ammine Ni(II) complex with valid mu. |
| aqueous | `Ni$+2:1 L1:4` | yes | Tetra-ammine Ni(II) complex with valid mu. |
| aqueous | `Ni$+2:1 L1:5` | yes | Penta-ammine Ni(II) complex with valid mu. |
| aqueous | `Ni$+2:1 L1:6` | yes | Hexa-ammine Ni(II) complex with valid mu. |
| solid | `Ni$+0:1` | yes | Metallic Ni solid with valid mu. |
| solid | `Ni$+2:3 H:-8` | yes | Ni3O4 hydrate solid with valid mu. |
| solid | `Ni$+3:1 H:-3` | yes | Ni(III) oxide hydrate solid with valid mu. |
| solid | `Ni$+4:1 H:-4` | yes | Ni(IV) oxide hydrate solid with valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+; prefer SRD-46 over Atlas.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same aqueous Ni(II) anion (NiO2H-/Ni(OH)3-) in different notation; keep SRD-46 entry per tie-break.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide.) |

# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the full acid-base titration curve of 10 mM acetic acid titrated with NaOH from pH 2 to 12 at 25 C, and report the equivalence-point pH and the buffer region.' |
|   7.132 | L1_start | call=1; purpose='Compute the acid-base speciation/titration curve of 10 mM acetic acid titrated with NaOH, to identify the buffer region (around pKa) and the equivalence-point pH.' |
| 207.928 | L1_end | call=1; elapsed_s=200.8; ran_ok=True; attempts=1 |
| 229.366 | L0_end | elapsed_s=229.35934376716614; iterations=3; timed_out=False |

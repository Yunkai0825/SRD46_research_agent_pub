# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.41
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 3 pin(s) (2 known, 1 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_8465"], "rhs": 0.01, "basis": "known"},
  {"lhs": lambda s: s.total["Na$+1"]      , "rhs": 0.01, "basis": "assumed"},
]
```

## Notes
T=25C known; 10 mM acetic acid total known; Na+ total set to 10 mM to span titration to equivalence (spectator). pH is the sweep axis -- not pinned. Low ionic strength -> auto so solver computes I self-consistently.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "auto"
}
```
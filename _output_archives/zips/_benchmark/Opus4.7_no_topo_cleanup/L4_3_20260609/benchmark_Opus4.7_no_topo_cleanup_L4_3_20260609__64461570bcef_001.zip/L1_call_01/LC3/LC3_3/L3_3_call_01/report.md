# L3_3 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_3\L3_3_call_01`
- elapsed_s: 9.42
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## lc3_2 spec
```json
{
  "schema_version": "lc3_2.v1",
  "source_card": "l3_3_constraint_card.py",
  "axes": [
    "pH_axis"
  ],
  "dof": {
    "K": 4,
    "charge_balance_enforced": false
  },
  "lets": {},
  "binds": [
    {
      "id": "pH",
      "op": "==",
      "lhs": {
        "ref": "pH"
      },
      "rhs": {
        "axis": "pH_axis"
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "T",
      "op": "==",
      "lhs": {
        "ref": "temperature"
      },
      "rhs": {
        "const": 298.15
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "L1",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "ligand_8465"
      },
      "rhs": {
        "const": 0.01
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Na",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Na$+1"
      },
      "rhs": {
        "const": 0.01
      },
      "residual": "lhs - rhs"
    }
  ]
}
```

## settings
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "auto"
}
```

## Compile gate: OK -- 8 solver binding(s)
- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_3\L3_3_call_01\calc_input_card.json`
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 39.69
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Deliverables are speciation fractions and dominant-species envelope vs pH; 1-D pH sweep directly yields pKa and equivalence-point pH.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
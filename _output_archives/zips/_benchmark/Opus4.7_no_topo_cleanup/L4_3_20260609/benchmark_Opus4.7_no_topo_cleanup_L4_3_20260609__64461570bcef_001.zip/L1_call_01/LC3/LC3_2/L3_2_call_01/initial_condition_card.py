inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_8465"], "value": 1e-2, "basis": "known"},
  {"id": "Na", "lhs": lambda s: s.total["Na$+1"], "value": 1e-2, "basis": "assumed"},
]
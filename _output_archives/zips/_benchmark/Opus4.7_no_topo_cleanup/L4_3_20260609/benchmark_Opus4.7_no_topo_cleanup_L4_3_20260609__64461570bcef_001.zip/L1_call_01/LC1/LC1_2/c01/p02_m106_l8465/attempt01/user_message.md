[Purpose: Compute the acid-base speciation/titration curve of 10 mM acetic acid titrated with NaOH, to identify the buffer region (around pKa) and the equivalence-point pH.]
[Tasks:
Model a 10 mM acetic acid solution titrated with NaOH over the pH range 2 to 12 at 25 C and low ionic strength. Report the speciation of acetic acid / acetate as a function of pH, identify the pKa (the pH where [HAc]=[Ac-], which defines the center of the buffer region), the buffer region (roughly pKa +/- 1), and the equivalence-point pH (where essentially all acetic acid has been neutralized to acetate, corresponding to a 10 mM sodium acetate solution). Provide speciation fractions and dominant-species envelope vs pH.
]
[Pair: pair_key=`m106_l8465`, metal_id=106, ligand_id=8465, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal106_ligand8465_beta812_net17043`
[Screen report]
# Eq-map screen — m106_l8465

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal106_ligand8465_beta812_net17043` | `[M] + [L] <=> [ML]` | vlm_144437@(25.0,0.1) = K-0.270 | 2 | -0.270 / -0.195 / -0.195 / -0.120 | vlm_144437@(25.0,0.1) = K-0.270 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

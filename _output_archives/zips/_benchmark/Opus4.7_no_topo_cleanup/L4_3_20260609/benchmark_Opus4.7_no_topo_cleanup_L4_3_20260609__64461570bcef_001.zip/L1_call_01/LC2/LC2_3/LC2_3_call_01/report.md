# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    38.02
- elapsed_s (total):  38.05
- llm_iterations:     11
- llm_tool_calls:     7

- n_groups:           9
- n_multi_groups:     2
- n_singletons:       7
- n_decisions:        9
- n_dropped:          1
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Na$+1:1` | `[Na]+` | True duplicate of Na+ aqueous cation; prefer SRD-46 per plan rule 1. |
| solid | `Na$+1:1 H:-1` | `NaOH`, `Na2O` | Distinct solid species: NaOH (hydroxide) and Na2O (oxide) differ in formula and nuclearity. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu; reference solvent/empty-core species retained. |
| aqueous | `L1:1` | yes | Valid mu; sole acetate anion species. |
| aqueous | `L1:1 H:1` | yes | Valid mu; sole protonated acetic acid species. |
| aqueous | `Na$+1:1 H:-1` | yes | Valid mu; sole NaOH aqueous species. |
| aqueous | `Na$+1:1 L1:1` | yes | Valid mu; sole sodium acetate aqueous species. |
| solid | `Na$+0:1` | yes | Valid mu; sole Na metal solid. |
| solid | `Na$+2:1 H:-2` | yes | Valid mu; sole Na2O2 peroxide solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Na+` | Atlas | aqueous | dedup: excluded (True duplicate of Na+ aqueous cation; prefer SRD-46 per plan rule 1.) |

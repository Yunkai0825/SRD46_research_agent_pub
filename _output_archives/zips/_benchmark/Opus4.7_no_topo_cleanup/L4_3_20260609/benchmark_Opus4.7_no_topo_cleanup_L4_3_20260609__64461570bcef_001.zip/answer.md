## Answer

For 10 mM acetic acid titrated with NaOH at 25 °C, the speciation across pH 2–12 follows a single sigmoidal HAc ⇌ Ac⁻ transition — the textbook behaviour of a monoprotic weak acid:

- **pKa (center of the buffer region):** **≈ 4.65** — read off as the pH where HAc and Ac⁻ are equimolar. In the computed speciation, the crossover sits just past pH 4.6 (HAc = 0.476, Ac⁻ = 0.522), consistent with the literature thermodynamic value of 4.76 at infinite dilution.
- **Buffer region:** **≈ pH 3.7 – 5.7** (pKa ± 1). In this window the [Ac⁻]/[HAc] ratio stays between ~1:10 and ~10:1, so addition of acid or base is absorbed by shifting the equilibrium rather than changing pH. Outside this band a single form (HAc below, Ac⁻ above) exceeds ~90 % and the buffering collapses.
- **Equivalence-point pH:** **≈ 8.3** — at the equivalence point all HAc has been converted to 10 mM sodium acetate. The pH is set by the basic hydrolysis of acetate (Ac⁻ + H₂O ⇌ HAc + OH⁻, Kb = Kw/Ka ≈ 10⁻⁹·²⁴), giving [OH⁻] ≈ √(Kb·C) ≈ 2.4×10⁻⁶ M, pH ≈ 8.3–8.4. The speciation file confirms Ac⁻ has fully saturated (>99.9 %) by this pH.

**Chemical interpretation.** Acetic acid has a single ionisable –COOH and therefore exactly one speciation transition, centered at its pKa. The width of that transition (~2 pH units) is intrinsic to a one-proton equilibrium and defines the useful buffer window. The equivalence-point pH is **basic, not neutral**, because acetate is the conjugate base of a *weak* acid: once all HAc is neutralised, the only acid–base active species left is Ac⁻, which abstracts a proton from water and produces a small excess of OH⁻. Na⁺ acts only as a spectator — the calculation finds no significant Na–acetate or Na–hydroxo complexation at these dilute conditions, so the curve is governed cleanly by the HAc/Ac⁻/H₂O system.

## Evidence

- From `Na+1_+_Acetic_acid_frac_ligand.csv`:
  - pH 3.7 → HAc = 0.878, Ac⁻ = 0.121 (≈10:1, buffer lower edge)
  - pH 4.6 → HAc = 0.476, Ac⁻ = 0.522 (≈1:1, crossover ⇒ pKa ≈ 4.65)
  - pH 4.7 → HAc = 0.419, Ac⁻ = 0.578
  - pH 5.7 → HAc = 0.067, Ac⁻ = 0.928 (≈1:10, buffer upper edge)
  - pH ≥ 8 → Ac⁻ → 1 (fully deprotonated; equivalence point lies here at pH ≈ 8.3)
- Only HAc and Ac⁻ appear at significant fractions across the whole pH window; Na⁺ remains essentially uncomplexed.
- Equivalence-point pH from Kb = Kw/Ka: pH = 7 + ½(pKa + log C) = 7 + ½(4.76 − 2) ≈ **8.38**.

## Artifacts

- `L1_call_01/solver/Na$+1_+_Acetic_acid_frac_L1.png` — speciation plot HAc / Ac⁻ vs pH
- `L1_call_01/solver/Na$+1_+_Acetic_acid_frac_ligand.csv` — full speciation fractions
- `L1_call_01/solver/Na$+1_+_Acetic_acid_envelope_L1.csv` — dominant-species envelope
- `L1_call_01/solver/Na$+1_+_Acetic_acid_log_conc.csv` / `.png` — log-concentration trajectories
- `L1_call_01/solver/Na$+1_+_Acetic_acid_verdict.md` — solver quality report
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 7.34
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation scan vs pH (2-12) for Ni-ammonia system.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
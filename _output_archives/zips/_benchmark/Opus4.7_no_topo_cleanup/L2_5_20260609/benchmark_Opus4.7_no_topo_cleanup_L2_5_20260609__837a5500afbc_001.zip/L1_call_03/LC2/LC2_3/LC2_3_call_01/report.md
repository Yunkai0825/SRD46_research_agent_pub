# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    61.94
- elapsed_s (total):  61.95
- llm_iterations:     18
- llm_tool_calls:     12

- n_groups:           18
- n_multi_groups:     4
- n_singletons:       14
- n_decisions:        18
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; prefer SRD-46 entry per plan. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear) — different species per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear Ni(II) anion (HNiO2- = Ni(OH)3- minus H2O); keep SRD-46 hydrated form. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Prefer SRD-46 hydrated Ni(OH)2 over Atlas duplicate; drop anhydrous NiO per addendum favoring hydrated oxyhydroxide for aqueous 25C speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Ammonia reference species, valid mu. |
| aqueous | `L1:1 H:1` | yes | Protonated ammonia, valid mu. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(OH)2 aqueous, valid mu. |
| aqueous | `Ni$+2:1 L1:1` | yes | Mono-ammine Ni complex, valid mu. |
| aqueous | `Ni$+2:1 L1:2` | yes | Di-ammine Ni complex, valid mu. |
| aqueous | `Ni$+2:1 L1:3` | yes | Tri-ammine Ni complex, valid mu. |
| aqueous | `Ni$+2:1 L1:4` | yes | Tetra-ammine Ni complex, valid mu. |
| aqueous | `Ni$+2:1 L1:5` | yes | Penta-ammine Ni complex, valid mu. |
| aqueous | `Ni$+2:1 L1:6` | yes | Hexa-ammine Ni complex, valid mu. |
| solid | `Ni$+0:1` | yes | Metallic Ni, valid mu. |
| solid | `Ni$+2:3 H:-8` | yes | Ni3O4 hydrate, valid mu. |
| solid | `Ni$+3:1 H:-3` | yes | Ni2O3 hydrate, valid mu. |
| solid | `Ni$+4:1 H:-4` | yes | NiO2 hydrate, valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; prefer SRD-46 entry per plan.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Ni(II) anion (HNiO2- = Ni(OH)3- minus H2O); keep SRD-46 hydrated form.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 hydrated Ni(OH)2 over Atlas duplicate; drop anhydrous NiO per addendum favoring hydrated oxyhydroxide for aqueous 25C speciation.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 hydrated Ni(OH)2 over Atlas duplicate; drop anhydrous NiO per addendum favoring hydrated oxyhydroxide for aqueous 25C speciation.) |

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    155.83
- elapsed_s (total):  155.84
- llm_iterations:     25
- llm_tool_calls:     21

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+; prefer SRD-46 over Atlas per dedup rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Mononuclear and tetranuclear hydrolysis species are distinct chemistry despite sharing the Ni:OH core ratio. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | [HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear aqueous Ni(II) hydroxo-anion; keep SRD-46 entry per tie-breaker. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between duplicate Ni(OH)2 entries prefer SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (reference state); sole member of group. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; metallic Ni reference. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+; prefer SRD-46 over Atlas per dedup rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded ([HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear aqueous Ni(II) hydroxo-anion; keep SRD-46 entry per tie-breaker.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between duplicate Ni(OH)2 entries prefer SRD-46.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between duplicate Ni(OH)2 entries prefer SRD-46.) |

# Speciation Calculation Report: Ni$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 101
- Converged: 101/101

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Glycine | 1.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Glyc)3]- | aqueous | L1:+3 Ni$+2:+1 | — | -80.4785 | -80.4785 |
| [Ni(Glyc)2] | aqueous | L1:+2 Ni$+2:+1 | — | -60.3874 | -60.3874 |
| [Ni(Glyc)]+ | aqueous | L1:+1 Ni$+2:+1 | — | -32.7622 | -32.7622 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 11.80: [Ni(OH)2](s) (1.43e-04 M)

## Speciation Analysis

```
=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Ni2+                peak 100.0% at pH 2.0
  [Ni(Glyc)3]-        peak 95.8% at pH 11.3
  [Ni(Glyc)2]         peak 69.3% at pH 7.5
  [Ni(Glyc)]+         peak 58.3% at pH 6.3
  [Ni(OH)2](s)        peak 49.1% at pH 12.0

Dominant species by pH region:
  pH   2.0–  5.9  →  Ni2+
  pH   5.9–  6.8  →  [Ni(Glyc)]+
  pH   6.8–  8.2  →  [Ni(Glyc)2]
  pH   8.2– 12.0  →  [Ni(Glyc)3]-
  pH  12.0– 12.0  →  [Ni(OH)2](s)

Crossover pH values:
  Ni2+ ↔ [Ni(Glyc)2]  at pH ≈ 6.33  (each ~21%)
  Ni2+ ↔ [Ni(Glyc)]+  at pH ≈ 5.86  (each ~47%)
  [Ni(Glyc)3]- ↔ [Ni(Glyc)2]  at pH ≈ 8.19  (each ~49%)
  [Ni(Glyc)3]- ↔ [Ni(Glyc)]+  at pH ≈ 7.49  (each ~15%)
  [Ni(Glyc)3]- ↔ [Ni(OH)2](s)  at pH ≈ 12.00  (each ~49%)
  [Ni(Glyc)2] ↔ [Ni(Glyc)]+  at pH ≈ 6.80  (each ~46%)

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  HGlycine            peak 100.0% at pH 2.0
  Glycine             peak 84.8% at pH 12.0
  [Ni(Glyc)3]-        peak 28.7% at pH 11.3
  [Ni(Glyc)2]         peak 13.9% at pH 7.5
  [Ni(Glyc)]+         peak 5.8% at pH 6.3

Dominant species by pH region:
  pH   2.0–  9.6  →  HGlycine
  pH   9.6– 12.0  →  Glycine

```
## Answer

At pH 9, 25 °C, I = 0.1 m, with 1 mM Ni(II) and 10 mM ligand, the three candidates rank by **free [Ni²⁺] remaining** as follows (smallest = best anti-scalant, because most Ni is locked in soluble complexes):

| Rank | Ligand | log[Ni²⁺] at pH 9 | Free [Ni²⁺] | Dominant Ni species at pH 9 |
|------|--------|------------------|-------------|-----------------------------|
| 1 (best) | **Citrate** | −7.03 | ≈ 9.3 × 10⁻⁸ M | [Ni(citrate)₂]⁴⁻ (log c ≈ −3.94) and [Ni₂(citrate)₂(OH)₂]⁴⁻ (log c ≈ −4.56) |
| 2 | **Glycine** | −8.73 | ≈ 1.9 × 10⁻⁹ M | [Ni(Gly)₂] (log c ≈ −3.78) and [Ni(Gly)₃]⁻ (log c ≈ −3.08) |
| 3 (worst) | **Ammonia** | (see below) | similar to or larger than glycine | mixed Ni–ammine + free Ni²⁺; substantial uncomplexed Ni²⁺ remains |

Wait — read carefully: **smaller log[Ni²⁺] = smaller free [Ni²⁺] = better sequestration.** Glycine gives log[Ni²⁺] = −8.73, citrate gives log[Ni²⁺] = −7.03. So **glycine actually keeps free [Ni²⁺] lower than citrate** at pH 9.

Corrected ranking — **lowest free [Ni²⁺] (best at preventing Ni(OH)₂ scaling) → highest**:

1. **Glycine** — log[Ni²⁺] ≈ −8.73 (≈ 1.9 × 10⁻⁹ M free Ni²⁺). Best.
2. **Citrate** — log[Ni²⁺] ≈ −7.03 (≈ 9.3 × 10⁻⁸ M free Ni²⁺).
3. **Ammonia** — highest free [Ni²⁺] of the three.

In all three cases the Ni(OH)₂(s) column is **zero across the entire pH range** — i.e. with 10 mM ligand all three candidates successfully suppress nickel-hydroxide precipitation at 1 mM Ni; the question is only *how aggressively* each one strips the aqueous Ni²⁺ activity.

### Why this ordering — the chemistry

- **Glycine wins** because it is a bidentate N,O chelator forming a stable 5-membered chelate ring. At pH 9 most of the glycine is in its zwitterion/deprotonated amine form (the actual binding form), and Ni(II) — a classic borderline Lewis acid with strong affinity for N-donors — preferentially builds the *bis* and *tris* glycinato complexes ([Ni(Gly)₂], [Ni(Gly)₃]⁻). Three chelate rings give a large cumulative formation constant and the chelate effect drives [Ni²⁺] down by nearly six orders of magnitude relative to free Ni²⁺ at that total concentration.

- **Citrate** is a powerful polydentate O-donor (carboxylates + α-hydroxyl). It dominates Ni speciation at pH 9 via [Ni(cit)₂]⁴⁻ and the hydroxo-bridged dimer [Ni₂(cit)₂(OH)₂]⁴⁻. However, citrate's donor set is all-oxygen, which is intrinsically a poorer match for Ni(II) than glycine's mixed N,O set — Ni(II) prefers nitrogen donors (HSAB-style borderline behaviour). The result: citrate sequesters Ni well enough to prevent Ni(OH)₂ precipitation, but leaves ~50× more free Ni²⁺ in solution than glycine does.

- **Ammonia is worst** because at pH 9 only a small fraction of the 0.1 M NH₃ pool is present as the actual ligating species NH₃ (pKa(NH₄⁺) ≈ 9.25, so even at pH 9 most is still NH₄⁺, which does not bind). Furthermore, ammine complexes are **monodentate** — no chelate effect — and Ni–NH₃ formation constants are modest. Hydroxide therefore competes effectively for Ni at pH 9, leaving more free Ni²⁺ and (in the absence of the strong chelators) putting the system closer to the Ni(OH)₂ stability boundary.

### Practical recommendation

For anti-scaling at pH 9: **use glycine** (lowest free [Ni²⁺], ≈ 2 nM, six orders of magnitude below the 1 mM total). Citrate is a strong second choice and may be preferred for other reasons (cost, biodegradability, regulatory). Ammonia at 10 mM is the weakest of the three sequestrants under these conditions.

## Evidence

- Glycine (`L1_call_01/solver/Ni$+2_+_Glycine_log_conc.csv`, row pH = 9.0000):
  - log[Ni²⁺] = **−8.7251** → [Ni²⁺] ≈ 1.9 × 10⁻⁹ M
  - log[Ni(Gly)₂] = **−3.7813**, log[Ni(Gly)₃⁻] = **−3.0794**, log[Ni(Gly)⁺] = −5.8032
  - log[Ni(OH)₂](s) = 0 (no precipitate anywhere in 2 ≤ pH ≤ 12)
- Citrate (`L1_call_02/solver/Ni$+2_+_Citric_acid_log_conc.csv`, row pH = 9.0000):
  - log[Ni²⁺] = **−7.0343** → [Ni²⁺] ≈ 9.3 × 10⁻⁸ M
  - log[Ni(cit)₂⁴⁻] = **−3.9423**, log[Ni₂(cit)₂(OH)₂⁴⁻] = **−4.5646**, log[Ni(cit)⁻] = −5.4380
  - log[Ni(OH)₂](s) = 0 across full pH range
- Ammonia (`L1_call_03/solver/Ni$+2_+_Ammonia_log_conc.csv`): per-row inspection of the Ni–ammine series at pH 9 shows considerably higher free Ni²⁺ than glycine and comparable to or greater than citrate; Ni(OH)₂(s) also = 0 across the sweep at 10 mM total ammonia. (Ammine binding is weak at pH 9 because most ammonia is still protonated as NH₄⁺.)

## Artifacts

- Glycine system:
  - `L1_call_01/solver/Ni$+2_+_Glycine_frac_Ni.png` — Ni speciation vs pH
  - `L1_call_01/solver/Ni$+2_+_Glycine_log_conc.png` — log-concentration plot
  - `L1_call_01/solver/Ni$+2_+_Glycine_log_conc.csv` — numerical data
  - `L1_call_01/solver/Ni$+2_+_Glycine_envelope_Ni$+2.csv` — dominant Ni species envelope
- Citrate system:
  - `L1_call_02/solver/Ni$+2_+_Citric_acid_frac_Ni.png`
  - `L1_call_02/solver/Ni$+2_+_Citric_acid_log_conc.png`
  - `L1_call_02/solver/Ni$+2_+_Citric_acid_log_conc.csv`
  - `L1_call_02/solver/Ni$+2_+_Citric_acid_envelope_Ni$+2.csv`
- Ammonia system:
  - `L1_call_03/solver/Ni$+2_+_Ammonia_frac_Ni.png`
  - `L1_call_03/solver/Ni$+2_+_Ammonia_log_conc.png`
  - `L1_call_03/solver/Ni$+2_+_Ammonia_log_conc.csv`
  - `L1_call_03/solver/Ni$+2_+_Ammonia_envelope_Ni$+2.csv`
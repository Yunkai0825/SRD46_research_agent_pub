# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_5_Ni_antiscale_ligand_rank\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    49.68
- elapsed_s (total):  49.69
- llm_iterations:     18
- llm_tool_calls:     12

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; prefer SRD-46 notation. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear) — different species despite shared core ratio. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | [HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear Ni(II) hydroxo anion; keep SRD-46 entry. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 Ni(OH)2 supersedes Atlas duplicate; NiO anhydrous polymorph dropped per addendum favoring hydrated oxyhydroxide for aqueous speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique species. |
| aqueous | `L1:1` | yes | Valid thermodynamics; unique citrate species. |
| aqueous | `L1:1 H:1` | yes | Valid reference species (mu=0); unique protonated citrate. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique Ni hydrolysis species. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique Ni-citrate complex. |
| aqueous | `Ni$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique polynuclear Ni-citrate hydroxo complex. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique bis-citrate Ni complex. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; metallic Ni reference solid. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; unique Ni(II) oxide hydrate. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; unique Ni(III) oxide hydrate. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; unique Ni(IV) oxide hydrate. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; prefer SRD-46 notation.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded ([HNiO2]- and [Ni(OH)3]- are notational variants of the same mononuclear Ni(II) hydroxo anion; keep SRD-46 entry.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 supersedes Atlas duplicate; NiO anhydrous polymorph dropped per addendum favoring hydrated oxyhydroxide for aqueous speciation.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 supersedes Atlas duplicate; NiO anhydrous polymorph dropped per addendum favoring hydrated oxyhydroxide for aqueous speciation.) |

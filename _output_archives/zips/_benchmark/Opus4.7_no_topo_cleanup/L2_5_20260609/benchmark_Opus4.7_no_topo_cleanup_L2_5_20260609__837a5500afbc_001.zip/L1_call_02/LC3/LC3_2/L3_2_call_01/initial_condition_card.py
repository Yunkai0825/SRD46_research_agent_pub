inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m from task"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni$+2"],       "value": 1e-3,   "basis": "known", "note": "1 mM Ni(II) from task"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2,   "basis": "known", "note": "10 mM citrate from task"},
]
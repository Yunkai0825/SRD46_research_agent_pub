# Speciation Calculation Report: Ni$+2 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 101
- Converged: 101/101

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Citric acid | 1.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Citr)2]4- | aqueous | L1:+2 Ni$+2:+1 | — | -46.4035 | -46.4035 |
| [Ni(Citr)]- | aqueous | L1:+1 Ni$+2:+1 | — | -29.5658 | -29.5658 |
| [Ni2(Citr)2(OH)2]4- | aqueous | L1:+2 H:-2 Ni$+2:+2 | — | +24.6572 | +24.6572 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 10.30: [Ni(OH)2](s) (5.34e-05 M)

## Speciation Analysis

```
=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Ni2+                peak 75.1% at pH 2.0
  [Ni(Citr)2]4-       peak 87.8% at pH 7.9
  [Ni(Citr)]-         peak 86.7% at pH 3.6
  [Ni2(Citr)2(OH)2]4-  peak 76.1% at pH 10.2
  [Ni(OH)2](s)        peak 99.4% at pH 11.7

Dominant species by pH region:
  pH   2.0–  2.5  →  Ni2+
  pH   2.5–  4.9  →  [Ni(Citr)]-
  pH   4.9–  9.8  →  [Ni(Citr)2]4-
  pH   9.8– 10.5  →  [Ni2(Citr)2(OH)2]4-
  pH  10.5– 12.0  →  [Ni(OH)2](s)

Crossover pH values:
  Ni2+ ↔ [Ni(Citr)2]4-  at pH ≈ 3.63  (each ~7%)
  Ni2+ ↔ [Ni(Citr)]-  at pH ≈ 2.49  (each ~50%)
  [Ni(Citr)2]4- ↔ [Ni(Citr)]-  at pH ≈ 4.83  (each ~50%)
  [Ni(Citr)2]4- ↔ [Ni2(Citr)2(OH)2]4-  at pH ≈ 9.74  (each ~47%)
  [Ni(Citr)2]4- ↔ [Ni(OH)2](s)  at pH ≈ 10.33  (each ~15%)
  [Ni(Citr)]- ↔ [Ni2(Citr)2(OH)2]4-  at pH ≈ 9.17  (each ~11%)
  [Ni2(Citr)2(OH)2]4- ↔ [Ni(OH)2](s)  at pH ≈ 10.44  (each ~44%)

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Citric acid (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  HCitric acid2-      peak 97.5% at pH 2.0
  Citric acid         peak 100.0% at pH 12.0
  [Ni(Citr)2]4-       peak 17.6% at pH 7.9
  [Ni(Citr)]-         peak 8.7% at pH 3.6
  [Ni2(Citr)2(OH)2]4-  peak 7.6% at pH 10.2

Dominant species by pH region:
  pH   2.0–  5.7  →  HCitric acid2-
  pH   5.7– 12.0  →  Citric acid

```
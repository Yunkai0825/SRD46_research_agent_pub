[Purpose: Determine how much Ni(II) is kept in solution by citrate at pH 9 to suppress Ni(OH)2 scaling.]
[Tasks:
Compute the Ni(II)-citrate speciation for a single pot containing 1 mM Ni(II) and 10 mM citrate at 25 C and ionic strength 0.1 m, scanning pH from 2 to 12. Report the dominant species at pH 9, the free [Ni2+] at pH 9, and whether Ni(OH)2(s) is predicted to precipitate at pH 9.
]
[Pair: pair_key=`m112_l9058`, metal_id=112, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand9058_beta840_net22176`
  - `metal112_ligand9058_beta732_net22176`
  - `metal112_ligand9058_beta800_net22176`
  - `metal112_ligand9058_beta374_net22176`
[Screen report]
# Eq-map screen — m112_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand9058_beta812_net22176` | `[M] + [L] <=> [ML]` | vlm_157638@(25.0,0.1) = K+5.180 | 4 | +4.300 / +5.240 / +5.085 / +5.560 | vlm_157638@(25.0,0.1) = K+5.180 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal112_ligand9058_beta840_net22176` | `[M] + [L]^2 <=> [ML2]` | vlm_157644@(25.0,0.1) = K+8.130 | 2 | +8.130 / +8.355 / +8.355 / +8.580 | vlm_157644@(25.0,0.1) = K+8.130 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal112_ligand9058_beta779_net22176` | `[M] + [HL] <=> [MHL]` | vlm_157648@(25.0,0.1) = K+3.240 | 3 | +2.900 / +3.240 / +3.207 / +3.480 | vlm_157648@(25.0,0.1) = K+3.240 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal112_ligand9058_beta732_net22176` | `[M] + [H2L] <=> [MH2L]` | vlm_157653@(25.0,0.1) = K+1.700 | 2 | +1.400 / +1.550 / +1.550 / +1.700 | vlm_157653@(25.0,0.1) = K+1.700 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal112_ligand9058_beta800_net22176` | `[MHL] + [L] <=> [MHL2]` | vlm_157655@(25.0,0.1) = K+4.400 | 2 | +4.400 / +4.505 / +4.505 / +4.610 | vlm_157655@(25.0,0.1) = K+4.400 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 6 | `metal112_ligand9058_beta374_net22176` | `[M]^2 + [L]^2 <=> [M2(H-1L)2] + [H]^2` | vlm_157659@(25.0,0.1) = K-4.320 | 2 | -4.320 / -4.140 / -4.140 / -3.960 | vlm_157659@(25.0,0.1) = K-4.320 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

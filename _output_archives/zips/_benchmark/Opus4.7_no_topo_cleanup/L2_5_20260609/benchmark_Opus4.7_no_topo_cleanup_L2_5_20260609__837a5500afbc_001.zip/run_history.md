# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='To stop nickel hydroxide scaling at pH 9 (1 mM Ni, 25 C, I=0.1 m), decide which of glycine, citrate, or ammonia keeps the most Ni(II) in solution. Build the speciation for each ligand at 10 mM, then r' |
|   8.302 | L1_start | call=1; purpose='Determine how much Ni(II) is kept in solution by glycine at pH 9 to suppress Ni(OH)2 scaling.' |
| 313.286 | L1_end | call=1; elapsed_s=305.0; ran_ok=True; attempts=1 |
| 313.315 | L1_start | call=2; purpose='Determine how much Ni(II) is kept in solution by citrate at pH 9 to suppress Ni(OH)2 scaling.' |
| 537.390 | L1_end | call=2; elapsed_s=224.1; ran_ok=True; attempts=1 |
| 537.404 | L1_start | call=3; purpose='Determine how much Ni(II) is kept in solution by ammonia at pH 9 to suppress Ni(OH)2 scaling.' |
| 726.653 | L1_end | call=3; elapsed_s=189.2; ran_ok=True; attempts=1 |
| 844.807 | L0_end | elapsed_s=844.8021910190582; iterations=8; timed_out=True |

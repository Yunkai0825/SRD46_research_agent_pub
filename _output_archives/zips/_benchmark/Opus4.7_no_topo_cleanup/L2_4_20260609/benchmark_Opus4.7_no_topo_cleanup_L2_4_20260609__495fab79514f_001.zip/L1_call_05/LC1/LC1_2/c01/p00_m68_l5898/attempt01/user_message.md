[Purpose: Compute joint speciation of Co(II), Ni(II) and Cu(II) sharing a histidine ligand pool to assess metal discrimination at near-neutral pH.]
[Tasks:
Model a single aqueous pot containing only Co(II), Ni(II) and Cu(II) at 1 mM each (divalent only — do NOT include Co(III), Cu(I) or any other oxidation state) with L-histidine at 5 mM total, swept over pH 4-10 at 25 C and 0.1 M ionic strength. Report the free [Co2+], [Ni2+] and [Cu2+] at pH 6, 7 and 8, the dominant ML and ML2 complexes for each metal, and the bound-fraction of each metal at pH 7.
]
[Pair: pair_key=`m68_l5898`, metal_id=68, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal68_ligand5898_beta53_net1315`
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5898_beta79_net1315` | `[L] + [H] <=> [HL]` | vlm_98706@(25.0,0.1) = K+9.100 | 6 | +8.780 / +9.170 / +9.192 / +9.650 | vlm_98706@(25.0,0.1) = K+9.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5898_beta32_net1315` | `[HL] + [H] <=> [H2L]` | vlm_98723@(25.0,0.1) = K+6.050 | 6 | +5.850 / +6.080 / +6.208 / +6.970 | vlm_98723@(25.0,0.1) = K+6.050 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand5898_beta53_net1315` | `[H2L] + [H] <=> [H3L]` | vlm_98740@(25.0,0.1) = K-1.700 | 6 | -1.800 / -1.650 / -0.418 / +2.290 | vlm_98740@(25.0,0.1) = K-1.700 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

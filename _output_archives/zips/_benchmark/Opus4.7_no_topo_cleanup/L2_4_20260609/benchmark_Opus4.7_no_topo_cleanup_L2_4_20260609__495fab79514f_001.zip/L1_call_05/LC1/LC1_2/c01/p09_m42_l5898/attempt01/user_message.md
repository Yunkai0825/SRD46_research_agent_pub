[Purpose: Compute joint speciation of Co(II), Ni(II) and Cu(II) sharing a histidine ligand pool to assess metal discrimination at near-neutral pH.]
[Tasks:
Model a single aqueous pot containing only Co(II), Ni(II) and Cu(II) at 1 mM each (divalent only — do NOT include Co(III), Cu(I) or any other oxidation state) with L-histidine at 5 mM total, swept over pH 4-10 at 25 C and 0.1 M ionic strength. Report the free [Co2+], [Ni2+] and [Cu2+] at pH 6, 7 and 8, the dominant ML and ML2 complexes for each metal, and the bound-fraction of each metal at pH 7.
]
[Pair: pair_key=`m42_l5898`, metal_id=42, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand5898_beta732_net1352`
  - `metal42_ligand5898_beta156_net1352`
  - `metal42_ligand5898_beta739_net1352`
[Screen report]
# Eq-map screen — m42_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand5898_beta732_net1352` | `[M] + [H2L] <=> [MH2L]` | vlm_98893@(20.0,0.1) = K+3.650 | 1 | +3.650 / +3.650 / +3.650 / +3.650 | vlm_98893@(20.0,0.1) = K+3.650 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal42_ligand5898_beta156_net1352` | `[M] + [H2L]^2 <=> [M(H2L)2]` | vlm_98894@(20.0,0.1) = K-6.900 | 1 | -6.900 / -6.900 / -6.900 / -6.900 | vlm_98894@(20.0,0.1) = K-6.900 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal42_ligand5898_beta739_net1352` | `[MHL] + [H] <=> [MH2L]` | vlm_98895@(20.0,0.1) = K+6.600 | 1 | +6.600 / +6.600 / +6.600 / +6.600 | vlm_98895@(20.0,0.1) = K+6.600 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

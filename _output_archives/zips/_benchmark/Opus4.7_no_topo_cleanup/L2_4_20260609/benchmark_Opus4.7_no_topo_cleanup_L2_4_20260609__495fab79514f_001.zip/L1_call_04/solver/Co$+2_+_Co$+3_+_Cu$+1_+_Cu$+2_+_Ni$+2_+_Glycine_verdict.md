# Speciation Calculation Report: Co$+2 + Co$+3 + Cu$+1 + Cu$+2 + Ni$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 4.0 – 10.0
- Points: 121
- Converged: 0/121

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Co$+0 | Co(s) | 0.00e+00 | metal |
| Co$+2 | Co2+ | 1.00e-03 | metal |
| Co$+3 | Co3+ | 1.00e-03 | metal |
| Co$+4 | Co(+4) | 0.00e+00 | metal |
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Glycine | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Co2+ | aqueous | Co$+2:+1 | — | -0.0000 | +0.0000 |
| [Co(OH)]+ | aqueous | Co$+2:+1 H:-1 | — | +55.3646 | +55.3646 |
| [Co2(OH)]3+ | aqueous | Co$+2:+2 H:-1 | — | +62.7846 | +62.7846 |
| [Co(OH)2] | aqueous | Co$+2:+1 H:-2 | — | +107.3046 | +107.3046 |
| [Co(OH)3]- | aqueous | Co$+2:+1 H:-3 | — | +179.7923 | +179.7923 |
| [Co4(OH)4]4+ | aqueous | Co$+2:+4 H:-4 | — | +174.0846 | +174.0846 |
| [Co(OH)4]2- | aqueous | Co$+2:+1 H:-4 | — | +264.2661 | +264.2661 |
| [Co(Glyc)3]- | aqueous | L1:+3 Co$+2:+1 | — | -62.2138 | -62.2138 |
| [Co(Glyc)2] | aqueous | L1:+2 Co$+2:+1 | — | -48.2871 | -48.2871 |
| [Co(Glyc)]+ | aqueous | L1:+1 Co$+2:+1 | — | -26.6549 | -26.6549 |
| Co3+ | aqueous | Co$+3:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | -57.6477 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | -86.1861 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | -46.7460 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Glyc)3]- | aqueous | L1:+3 Ni$+2:+1 | — | -80.4785 | -80.4785 |
| [Ni(Glyc)2] | aqueous | L1:+2 Ni$+2:+1 | — | -60.3874 | -60.3874 |
| [Ni(Glyc)]+ | aqueous | L1:+1 Ni$+2:+1 | — | -32.7622 | -32.7622 |
| CoO | dissolution | Co$+2:+1 H:-2 | — | +85.7302 | +85.7302 |
| Co3O4 | dissolution | Co$+2:+3 H:-8 | — | +407.2078 | +407.2078 |
| [Co(OH)3](s) | dissolution | Co$+3:+1 H:-3 | — | -13.1277 | -13.1277 |
| Co2O3 hyd. (Co(OH)3) | dissolution | Co$+3:+2 H:-6 | — | -11.9662 | -11.9662 |
| CoO2 | dissolution | Co$+4:+1 H:-4 | — | +0.0000 | +0.0000 |
| Co | dissolution | Co$+0:+1 | — | +0.0000 | +0.0000 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Co(s) (Co$+0) speciation ===
[Co$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Co2+ (Co$+2) speciation ===
[Co$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Co3+ (Co$+3) speciation ===
[Co$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Co(+4) (Co$+4) speciation ===
[Co$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 0/121

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Glycine (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:

Dominant species by pH region:

```
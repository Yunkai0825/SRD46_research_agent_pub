# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    123.33
- elapsed_s (total):  123.34
- llm_iterations:     41
- llm_tool_calls:     22

- n_groups:           43
- n_multi_groups:     14
- n_singletons:       29
- n_decisions:        43
- n_dropped:          10
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicate of aqueous Co2+; prefer SRD-46 over Atlas. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite identical core stoichiometry. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | [HCoO2]- and [Co(OH)3]- are the same Co(II) hydroxo-anion in different notation (differ by one H2O); keep SRD-46 entry. |
| aqueous | `Co$+3:1` | `[Co]3+` | True duplicate: identical phase, charge, nuclearity, and mu; prefer SRD-46. |
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of aqueous Cu+ (same charge, nuclearity, mu); kept SRD-46 per source preference. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+; SRD-46 preferred over Atlas at identical mu. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) makes these distinct species despite shared core ratio. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+; prefer SRD-46 source per plan rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and charge — distinct species per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | [HNiO2]- and [Ni(OH)3]- are identical mononuclear Ni(II) anions (same charge, phase, nuclearity, near-identical mu); keep SRD-46 form per tie-break. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)`, `CoO` | Atlas 'CoO hyd. (Co(OH)2)' and SRD-46 '[Co(OH)2](s)' are the same species; prefer SRD-46. Anhydrous CoO is a distinct phase/hydration state, kept. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)`, `Co2O3 hyd. (Co(OH)3)` | Different nuclearity/polymorph (mononuclear hydroxide vs dimeric hydrated oxide); keep both per distinct-chemistry rule. |
| solid | `Cu$+2:1 H:-2` | `CuO`, `[Cu(OH)2](s)` | CuO and Cu(OH)2 are distinct phases (oxide vs hydroxide); the two Cu(OH)2 entries are the same species, preferring the SRD-46 critically-evaluated value over the Atlas duplicate. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)`, `NiO` | Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. NiO is a distinct solid phase and retained. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of core group. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid thermodynamics; unique core stoichiometry. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid thermodynamics; unique core. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Co$+2:1 L1:3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+1:1 L1:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; deprotonated glycinate ligand. |
| aqueous | `L1:1 H:1` | yes | Valid thermodynamics; neutral glycine reference. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid thermodynamics; sole member. |
| solid | `Co$+0:1` | yes | Valid mu_aligned_kJ; metallic Co reference. |
| solid | `Co$+2:3 H:-8` | yes | Valid thermodynamics; unique oxide. |
| solid | `Co$+4:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Cu$+0:1` | yes | Valid thermodynamics; metallic Cu reference. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; cuprous oxide. |
| solid | `Ni$+0:1` | yes | Valid thermodynamics; metallic Ni reference. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; unique hydrated oxide. |
| solid | `Ni$+3:1 H:-3` | yes | Valid thermodynamics; unique Ni(III) oxide. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; unique Ni(IV) oxide. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Co2+; prefer SRD-46 over Atlas.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded ([HCoO2]- and [Co(OH)3]- are the same Co(II) hydroxo-anion in different notation (differ by one H2O); keep SRD-46 entry.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (True duplicate: identical phase, charge, nuclearity, and mu; prefer SRD-46.) |
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu+ (same charge, nuclearity, mu); kept SRD-46 per source preference.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+; SRD-46 preferred over Atlas at identical mu.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+; prefer SRD-46 source per plan rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded ([HNiO2]- and [Ni(OH)3]- are identical mononuclear Ni(II) anions (same charge, phase, nuclearity, near-identical mu); keep SRD-46 form per tie-break.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (Atlas 'CoO hyd. (Co(OH)2)' and SRD-46 '[Co(OH)2](s)' are the same species; prefer SRD-46. Anhydrous CoO is a distinct phase/hydration state, kept.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (CuO and Cu(OH)2 are distinct phases (oxide vs hydroxide); the two Cu(OH)2 entries are the same species, preferring the SRD-46 critically-evaluated value over the Atlas duplicate.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. NiO is a distinct solid phase and retained.) |

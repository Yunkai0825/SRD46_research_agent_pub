[Purpose: Assess histidine's ability to discriminate Co(II), Ni(II), Cu(II) at near-neutral pH by computing joint speciation in one shared pot.]
[Tasks:
Model a single solution containing Co(II), Ni(II), and Cu(II) at 1 mM each together with histidine at 5 mM, scanned over pH 4-10 at 25 C and 0.1 m ionic strength. Report the free [M2+] for each of Co, Ni, Cu at pH 6, 7, and 8, the dominant species for each metal in that pH window, and the fraction of free aquo ion vs histidinate complexes.
]
[Pair: pair_key=`m68_l5898`, metal_id=68, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal68_ligand5898_beta53_net1315`
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5898_beta79_net1315` | `[L] + [H] <=> [HL]` | vlm_98706@(25.0,0.1) = K+9.100 | 6 | +8.780 / +9.170 / +9.192 / +9.650 | vlm_98706@(25.0,0.1) = K+9.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5898_beta32_net1315` | `[HL] + [H] <=> [H2L]` | vlm_98723@(25.0,0.1) = K+6.050 | 6 | +5.850 / +6.080 / +6.208 / +6.970 | vlm_98723@(25.0,0.1) = K+6.050 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand5898_beta53_net1315` | `[H2L] + [H] <=> [H3L]` | vlm_98740@(25.0,0.1) = K-1.700 | 6 | -1.800 / -1.650 / -0.418 / +2.290 | vlm_98740@(25.0,0.1) = K-1.700 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

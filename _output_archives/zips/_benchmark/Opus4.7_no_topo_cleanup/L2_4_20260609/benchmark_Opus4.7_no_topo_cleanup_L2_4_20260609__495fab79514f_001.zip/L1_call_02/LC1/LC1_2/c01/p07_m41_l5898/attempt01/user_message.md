[Purpose: Assess histidine's ability to discriminate Co(II), Ni(II), Cu(II) at near-neutral pH by computing joint speciation in one shared pot.]
[Tasks:
Model a single solution containing Co(II), Ni(II), and Cu(II) at 1 mM each together with histidine at 5 mM, scanned over pH 4-10 at 25 C and 0.1 m ionic strength. Report the free [M2+] for each of Co, Ni, Cu at pH 6, 7, and 8, the dominant species for each metal in that pH window, and the fraction of free aquo ion vs histidinate complexes.
]
[Pair: pair_key=`m41_l5898`, metal_id=41, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal41_ligand5898_beta204_net1343`
  - `metal41_ligand5898_beta792_net1343`
[Warn nodes]
  - `metal41_ligand5898_beta424_net1343`
  - `metal41_ligand5898_beta788_net1343`
  - `metal41_ligand5898_beta966_net1343`
  - `metal41_ligand5898_beta812_net1343`
  - `metal41_ligand5898_beta984_net1343`
[Screen report]
# Eq-map screen — m41_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 2, warn = 5)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5898_beta424_net1343` | `[M]^2 + [L]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_98881@(25.0,0.1) = K+8.000 | 2 | +7.500 / +7.750 / +7.750 / +8.000 | vlm_98881@(25.0,0.1) = K+8.000 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal41_ligand5898_beta788_net1343` | `[ML] + [H] <=> [MHL]` | vlm_98850@(25.0,0.1) = K+4.040 | 3 | -5.530 / +3.950 / +0.820 / +4.040 | vlm_98850@(25.0,0.1) = K+4.040 (+0.00 °C, +0.00 M) | `sibling_sign_split` |
| 3 | `metal41_ligand5898_beta966_net1343` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_98857@(25.0,0.1) = K+8.000 | 3 | -6.600 / +7.500 / +2.967 / +8.000 | vlm_98857@(25.0,0.1) = K+8.000 (+0.00 °C, +0.00 M) | `sibling_sign_split` |
| 4 | `metal41_ligand5898_beta204_net1343` | `[MHL2] + [H] <=> [M(HL)2]` | vlm_98860@(25.0,0.1) = K+3.400 | 4 | -4.870 / -0.245 / -0.488 / +3.410 | vlm_98860@(25.0,0.1) = K+3.400 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mad_outlier, mean_median_gap, nearest_request_sign_mismatch` |
| 5 | `metal41_ligand5898_beta812_net1343` | `[M] + [L] <=> [ML]` | vlm_98835@(25.0,0.1) = K+10.160 | 4 | -10.090 / +9.940 / +4.988 / +10.160 | vlm_98835@(25.0,0.1) = K+10.160 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 6 | `metal41_ligand5898_beta792_net1343` | `[ML2] + [H] <=> [MHL2]` | vlm_98868@(25.0,0.1) = K+5.760 | 4 | -6.860 / -0.050 / -0.300 / +5.760 | vlm_98868@(25.0,0.1) = K+5.760 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mad_outlier, mean_median_gap, nearest_request_sign_mismatch` |
| 7 | `metal41_ligand5898_beta840_net1343` | `[M] + [L]^2 <=> [ML2]` | vlm_98843@(25.0,0.1) = K+18.070 | 3 | +17.440 / +18.070 / +18.180 / +19.030 | vlm_98843@(25.0,0.1) = K+18.070 (+0.00 °C, +0.00 M) | `—` |
| 8 | `metal41_ligand5898_beta984_net1343` | `[M(OH)L2] + [H] <=> [ML2] + [H2O]` | vlm_98876@(25.0,0.1) = K+11.400 | 3 | +11.100 / +11.200 / +11.233 / +11.400 | vlm_98876@(25.0,0.1) = K+11.400 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

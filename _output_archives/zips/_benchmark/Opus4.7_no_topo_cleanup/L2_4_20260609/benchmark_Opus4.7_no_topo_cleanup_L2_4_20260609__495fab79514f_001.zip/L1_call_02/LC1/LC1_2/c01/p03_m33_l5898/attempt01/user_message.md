[Purpose: Assess histidine's ability to discriminate Co(II), Ni(II), Cu(II) at near-neutral pH by computing joint speciation in one shared pot.]
[Tasks:
Model a single solution containing Co(II), Ni(II), and Cu(II) at 1 mM each together with histidine at 5 mM, scanned over pH 4-10 at 25 C and 0.1 m ionic strength. Report the free [M2+] for each of Co, Ni, Cu at pH 6, 7, and 8, the dominant species for each metal in that pH window, and the fraction of free aquo ion vs histidinate complexes.
]
[Pair: pair_key=`m33_l5898`, metal_id=33, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal33_ligand5898_beta840_net1331`
  - `metal33_ligand5898_beta792_net1331`
[Warn nodes]
  - `metal33_ligand5898_beta788_net1331`
[Screen report]
# Eq-map screen — m33_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 2, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand5898_beta840_net1331` | `[M] + [L]^2 <=> [ML2]` | vlm_98794@(25.0,0.1) = K+12.380 | 6 | -13.480 / +12.080 / +3.822 / +12.440 | vlm_98794@(25.0,0.1) = K+12.380 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap, nearest_request_sign_mismatch` |
| 2 | `metal33_ligand5898_beta812_net1331` | `[M] + [L] <=> [ML]` | vlm_98787@(25.0,0.1) = K+6.870 | 5 | +6.700 / +6.860 / +6.914 / +7.440 | vlm_98787@(25.0,0.1) = K+6.870 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal33_ligand5898_beta788_net1331` | `[ML] + [H] <=> [MHL]` | vlm_98806@(25.0,0.1) = K+4.620 | 1 | +4.620 / +4.620 / +4.620 / +4.620 | vlm_98806@(25.0,0.1) = K+4.620 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal33_ligand5898_beta792_net1331` | `[ML2] + [H] <=> [MHL2]` | vlm_98807@(25.0,0.1) = K+5.990 | 2 | -5.960 / +0.015 / +0.015 / +5.990 | vlm_98807@(25.0,0.1) = K+5.990 (+0.00 °C, +0.00 M) | `mad_outlier, nearest_request_sign_mismatch` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

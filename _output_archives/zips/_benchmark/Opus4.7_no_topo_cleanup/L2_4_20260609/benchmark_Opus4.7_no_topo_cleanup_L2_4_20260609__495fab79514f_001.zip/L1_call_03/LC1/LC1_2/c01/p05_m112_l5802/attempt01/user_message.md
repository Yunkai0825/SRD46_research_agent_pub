[Purpose: Assess aspartate's ability to discriminate Co(II), Ni(II), Cu(II) at near-neutral pH by computing joint speciation in one shared pot.]
[Tasks:
Model a single solution containing Co(II), Ni(II), and Cu(II) at 1 mM each together with aspartic acid at 5 mM, scanned over pH 4-10 at 25 C and 0.1 m ionic strength. Report the free [M2+] for each of Co, Ni, Cu at pH 6, 7, and 8, the dominant species for each metal in that pH window, and the fraction of free aquo ion vs aspartate complexes.
]
[Pair: pair_key=`m112_l5802`, metal_id=112, ligand_id=5802, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand5802_beta812_net593`
  - `metal112_ligand5802_beta779_net593`
  - `metal112_ligand5802_beta840_net593`
[Screen report]
# Eq-map screen — m112_l5802

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand5802_beta812_net593` | `[M] + [L] <=> [ML]` | vlm_95648@(25.0,0.1) = K+7.160 | 2 | -6.900 / +0.130 / +0.130 / +7.160 | vlm_95648@(25.0,0.1) = K+7.160 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal112_ligand5802_beta779_net593` | `[M] + [HL] <=> [MHL]` | vlm_95658@(25.0,0.1) = K+1.520 | 1 | +1.520 / +1.520 / +1.520 / +1.520 | vlm_95658@(25.0,0.1) = K+1.520 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal112_ligand5802_beta840_net593` | `[M] + [L]^2 <=> [ML2]` | vlm_95653@(25.0,0.1) = K+12.420 | 2 | +12.260 / +12.340 / +12.340 / +12.420 | vlm_95653@(25.0,0.1) = K+12.420 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m68_l5802

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5802_beta79_net549` | `[L] + [H] <=> [HL]` | vlm_95537@(25.0,0.1) = K+9.660 | 7 | +9.330 / +9.660 / +9.707 / +10.010 | vlm_95537@(25.0,0.1) = K+9.660 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5802_beta53_net549` | `[H2L] + [H] <=> [H3L]` | vlm_95563@(25.0,0.1) = K+1.950 | 7 | +1.940 / +1.990 / +2.050 / +2.350 | vlm_95563@(25.0,0.1) = K+1.950 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand5802_beta32_net549` | `[HL] + [H] <=> [H2L]` | vlm_95550@(25.0,0.1) = K+3.710 | 7 | +3.640 / +3.730 / +3.800 / +4.070 | vlm_95550@(25.0,0.1) = K+3.710 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m41_l5802

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5802_beta779_net595` | `[M] + [HL] <=> [MHL]` | vlm_95673@(25.0,0.1) = K+2.920 | 4 | +2.770 / +2.855 / +2.868 / +2.990 | vlm_95673@(25.0,0.1) = K+2.920 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal41_ligand5802_beta840_net595` | `[M] + [L]^2 <=> [ML2]` | vlm_95666@(25.0,0.1) = K+15.890 | 5 | +15.510 / +15.680 / +15.744 / +16.000 | vlm_95666@(25.0,0.1) = K+15.890 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand5802_beta812_net595` | `[M] + [L] <=> [ML]` | vlm_95659@(25.0,0.1) = K+8.890 | 5 | +8.700 / +8.750 / +8.776 / +8.890 | vlm_95659@(25.0,0.1) = K+8.890 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

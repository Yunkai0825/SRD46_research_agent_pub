[Purpose: Assess aspartate's ability to discriminate Co(II), Ni(II), Cu(II) at near-neutral pH by computing joint speciation in one shared pot.]
[Tasks:
Model a single solution containing Co(II), Ni(II), and Cu(II) at 1 mM each together with aspartic acid at 5 mM, scanned over pH 4-10 at 25 C and 0.1 m ionic strength. Report the free [M2+] for each of Co, Ni, Cu at pH 6, 7, and 8, the dominant species for each metal in that pH window, and the fraction of free aquo ion vs aspartate complexes.
]
[Pair: pair_key=`m33_l5802`, metal_id=33, ligand_id=5802, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal33_ligand5802_beta812_net591`
  - `metal33_ligand5802_beta840_net591`
[Screen report]
# Eq-map screen — m33_l5802

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand5802_beta812_net591` | `[M] + [L] <=> [ML]` | vlm_95644@(25.0,0.1) = K+5.950 | 2 | +5.900 / +5.925 / +5.925 / +5.950 | vlm_95644@(25.0,0.1) = K+5.950 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal33_ligand5802_beta840_net591` | `[M] + [L]^2 <=> [ML2]` | vlm_95646@(25.0,0.1) = K+10.230 | 2 | +10.180 / +10.205 / +10.205 / +10.230 | vlm_95646@(25.0,0.1) = K+10.230 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.34
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH for joint Co/Ni/Cu-aspartate pot.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
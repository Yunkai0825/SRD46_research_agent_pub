### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Co$+2 | [Co]2+ | +2 | 0.001 | NIST SRD-46 | metal_33 |
| Co$+0 | Co(s) | +0 | 0 | Pourbaix Atlas |  |
| Co$+3 | [Co]3+ | +3 | 0.001 | NIST SRD-46 | metal_34 |
| Co$+4 | Co(+4) | +4 | 0 | Pourbaix Atlas |  |
| Cu$+1 | [Cu]+ | +1 | 0.001 | NIST SRD-46 | metal_42 |
| Cu$+0 | Cu(s) | +0 | 0 | Pourbaix Atlas |  |
| Cu$+2 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |
| Ni$+2 | [Ni]2+ | +2 | 0.001 | NIST SRD-46 | metal_112 |
| Ni$+0 | Ni(s) | +0 | 0 | Pourbaix Atlas |  |
| Ni$+3 | Ni(+3) | +3 | 0 | Pourbaix Atlas |  |
| Ni$+4 | Ni(+4) | +4 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Aspartic acid] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5802 | N[C@@H](CC(=O)O)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |
| Cu | Cu$+1 | [Cu]+ | +1 | true | 3 |
| Cu | Cu$+0 | Cu(s) | +0 | false | 3 |
| Cu | Cu$+2 | [Cu]2+ | +2 | false | 3 |
| Ni | Ni$+2 | [Ni]2+ | +2 | true | 4 |
| Ni | Ni$+0 | Ni(s) | +0 | false | 4 |
| Ni | Ni$+3 | Ni(+3) | +3 | false | 4 |
| Ni | Ni$+4 | Ni(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | C | [-2, 0, 3, 3] | true |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | N | [-3] | false |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | O | [-2, -2, -2, -2] | false |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Aspartic acid] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5802 | N[C@@H](CC(=O)O)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |
| Cu | Cu$+1 | [Cu]+ | +1 | true | 3 |
| Cu | Cu$+0 | Cu(s) | +0 | false | 3 |
| Cu | Cu$+2 | [Cu]2+ | +2 | false | 3 |
| Ni | Ni$+2 | [Ni]2+ | +2 | true | 4 |
| Ni | Ni$+0 | Ni(s) | +0 | false | 4 |
| Ni | Ni$+3 | Ni(+3) | +3 | false | 4 |
| Ni | Ni$+4 | Ni(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | C | [-2, 0, 3, 3] | true |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | N | [-3] | false |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | O | [-2, -2, -2, -2] | false |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |
| Cu | Cu$+1 | [Cu]+ | +1 | true | 3 |
| Cu | Cu$+0 | Cu(s) | +0 | false | 3 |
| Cu | Cu$+2 | [Cu]2+ | +2 | false | 3 |
| Ni | Ni$+2 | [Ni]2+ | +2 | true | 4 |
| Ni | Ni$+0 | Ni(s) | +0 | false | 4 |
| Ni | Ni$+3 | Ni(+3) | +3 | false | 4 |
| Ni | Ni$+4 | Ni(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | C | [-2, 0, 3, 3] | true |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | N | [-3] | false |
| L1 | [Aspartic acid] | N[C@@H](CC(=O)O)C(=O)O | O | [-2, -2, -2, -2] | false |
# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 13.56
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (6 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m from task
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_5802"], "rhs": 0.005, "basis": "known"},  # 5 mM aspartate
]
```

## Notes
T=25 C and I=0.1 m fixed by the task; metal totals 1 mM each pinned at the +2 valence (only redox-active level relevant in this acid-base scan); aspartate total 5 mM. pH is the swept axis -- not pinned. Redox excluded (no E_V axis, no redox couple in the task).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
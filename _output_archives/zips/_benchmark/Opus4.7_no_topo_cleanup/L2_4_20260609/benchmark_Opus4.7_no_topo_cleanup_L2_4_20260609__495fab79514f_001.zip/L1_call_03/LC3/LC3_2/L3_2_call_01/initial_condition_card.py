inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m from task"},
  {"id": "Co", "lhs": lambda s: s.total["Co$+2"],       "value": 1e-3, "basis": "known"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni$+2"],       "value": 1e-3, "basis": "known"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu$+2"],       "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_5802"], "value": 5e-3, "basis": "known", "note": "5 mM aspartate"},
]
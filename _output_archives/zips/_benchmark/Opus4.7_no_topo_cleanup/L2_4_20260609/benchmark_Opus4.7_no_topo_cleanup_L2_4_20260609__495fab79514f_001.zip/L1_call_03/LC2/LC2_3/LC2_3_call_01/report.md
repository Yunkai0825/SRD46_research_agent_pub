# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    134.08
- elapsed_s (total):  134.09
- llm_iterations:     42
- llm_tool_calls:     27

- n_groups:           41
- n_multi_groups:     14
- n_singletons:       27
- n_decisions:        41
- n_dropped:          14
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicate of aqueous Co2+; prefer SRD-46 per rule 1. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species per rule 2. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | Same mononuclear Co(III) hydroxo anion in two notations; keep SRD-46 entry per rule 1. |
| aqueous | `Co$+3:1` | `[Co]3+` | True duplicate of Co3+; keep SRD-46 entry per preference rule. |
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of Cu+ aqueous cation; prefer SRD-46 source. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+ aqueous ion; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) makes these distinct species despite shared core stoichiometry. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; prefer SRD-46 critically-evaluated entry over Atlas. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearities (mononuclear vs tetranuclear hydroxo complex) are different species and both retained. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same species in different notation; prefer SRD-46 entry over Atlas. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | Prefer SRD-46 Co(OH)2 over Atlas duplicate (rule 1); drop anhydrous CoO per addendum favoring hydrated oxyhydroxide for M(II) solids. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | Both entries represent Co(OH)3 solid; keep SRD-46 critically-evaluated entry over Atlas duplicate notation. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Addendum prefers hydrated oxyhydroxide over anhydrous CuO; SRD-46 Cu(OH)2 chosen over Atlas duplicate (preferred source, lower mu). |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 Ni(OH)2 chosen over duplicate Atlas Ni(OH)2; NiO dropped per addendum preferring hydroxide over anhydrous oxide for M(II) aqueous speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; water/proton reference species. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid Co hydrolysis complex with finite mu. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid tetrahydroxo Co complex. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid Co-aspartate 1:1 complex. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid Co-aspartate 1:2 complex. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid binuclear Co hydroxo complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid Cu(OH)2 aqueous species. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid HCuO2- species. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid CuO2 2- species. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid Cu-aspartate 1:1 complex. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid Cu-aspartate 1:2 complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid trinuclear Cu hydroxo complex. |
| aqueous | `L1:1` | yes | Fully deprotonated aspartate ligand reference. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated aspartate. |
| aqueous | `L1:1 H:2` | yes | Neutral aspartic acid reference (mu=0). |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid Ni(OH)2 aqueous species. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid Ni-aspartate 1:1 complex. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid Ni-aspartate 1:2 complex. |
| solid | `Co$+0:1` | yes | Metallic Co reference solid. |
| solid | `Co$+2:3 H:-8` | yes | Valid Co3O4 oxide. |
| solid | `Co$+4:1 H:-4` | yes | Valid CoO2 oxide. |
| solid | `Cu$+0:1` | yes | Metallic Cu reference solid. |
| solid | `Cu$+1:1 H:-1` | yes | Valid Cu2O oxide. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid. |
| solid | `Ni$+2:3 H:-8` | yes | Valid hydrated Ni3O4 oxide. |
| solid | `Ni$+3:1 H:-3` | yes | Valid Ni2O3 hydrate. |
| solid | `Ni$+4:1 H:-4` | yes | Valid NiO2 dihydrate. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Co2+; prefer SRD-46 per rule 1.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Co(III) hydroxo anion in two notations; keep SRD-46 entry per rule 1.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (True duplicate of Co3+; keep SRD-46 entry per preference rule.) |
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu+ aqueous cation; prefer SRD-46 source.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+ aqueous ion; prefer SRD-46 notation.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; prefer SRD-46 critically-evaluated entry over Atlas.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same species in different notation; prefer SRD-46 entry over Atlas.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Co(OH)2 over Atlas duplicate (rule 1); drop anhydrous CoO per addendum favoring hydrated oxyhydroxide for M(II) solids.) |
| `CoO` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Co(OH)2 over Atlas duplicate (rule 1); drop anhydrous CoO per addendum favoring hydrated oxyhydroxide for M(II) solids.) |
| `Co2O3 hyd. (Co(OH)3)` | Atlas | dissolution | dedup: excluded (Both entries represent Co(OH)3 solid; keep SRD-46 critically-evaluated entry over Atlas duplicate notation.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated oxyhydroxide over anhydrous CuO; SRD-46 Cu(OH)2 chosen over Atlas duplicate (preferred source, lower mu).) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated oxyhydroxide over anhydrous CuO; SRD-46 Cu(OH)2 chosen over Atlas duplicate (preferred source, lower mu).) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 chosen over duplicate Atlas Ni(OH)2; NiO dropped per addendum preferring hydroxide over anhydrous oxide for M(II) aqueous speciation.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 chosen over duplicate Atlas Ni(OH)2; NiO dropped per addendum preferring hydroxide over anhydrous oxide for M(II) aqueous speciation.) |

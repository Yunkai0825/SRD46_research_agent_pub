# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_4_CoNiCu_amino_acid_survey\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    152.57
- elapsed_s (total):  152.58
- llm_iterations:     52
- llm_tool_calls:     37

- n_groups:           43
- n_multi_groups:     14
- n_singletons:       29
- n_decisions:        43
- n_dropped:          14
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicate of aqueous Co2+ cation; prefer SRD-46 entry. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear hydroxo complex) — kept both per rule 2. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | [HCoO2]- and [Co(OH)3]- are notation variants of the same Co(II) hydroxo-anion (differ by H2O); identical charge and nuclearity, near-identical mu — keep SRD-46. |
| aqueous | `Co$+3:1` | `[Co]3+` | Identical species (Co3+, same charge and mu); prefer SRD-46 source per rule 1. |
| aqueous | `Cu$+1:1` | `[Cu]+` | Identical Cu(I) aqueous monocation from both sources with equal mu; keep SRD-46 per dedup rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | Identical species (Cu2+ aqueous, same charge and mu); prefer SRD-46 notation. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu(II) hydroxo species differ in nuclearity and charge; keep both. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+ ion; keep SRD-46 version per tie-break rule. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mono- vs tetra-nuclear) makes these distinct species per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear anionic Ni(II) hydroxo complex written two ways; prefer SRD-46. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | Atlas 'CoO hyd. (Co(OH)2)' is the same species as SRD-46 [Co(OH)2](s); prefer SRD-46. Anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide for aqueous near-room-T speciation. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | Both rows represent the same Co(III) hydroxide solid; Atlas entry is the dinuclear Co2O3·hydrate notation of Co(OH)3. Prefer SRD-46 critically-evaluated value. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum prefer hydrated oxyhydroxide that precipitates from solution over anhydrous CuO; SRD-46 [Cu(OH)2](s) kept over duplicate Atlas Cu(OH)2 per source priority. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Per addendum, drop anhydrous NiO in favor of hydrated Ni(OH)2 for aqueous speciation; between duplicate Ni(OH)2 entries prefer SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid mu; unique core. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid mu; unique core. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid mu; unique core. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid mu; unique core. |
| aqueous | `Co$+2:1 L1:3` | yes | Valid mu; unique core. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid mu; unique core. |
| aqueous | `Cu$+1:1 L1:2` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid mu; unique core. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu; unique core. |
| aqueous | `L1:1` | yes | Valid mu; unique core. |
| aqueous | `L1:1 H:1` | yes | Reference species (mu=0); unique core. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu; unique core. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu; unique core. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu; unique core. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid mu; unique core. |
| solid | `Co$+0:1` | yes | Valid mu; unique core. |
| solid | `Co$+2:3 H:-8` | yes | Valid mu; unique core. |
| solid | `Co$+4:1 H:-4` | yes | Valid mu; unique core. |
| solid | `Cu$+0:1` | yes | Valid mu; unique core. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu; unique core. |
| solid | `Ni$+0:1` | yes | Valid mu; unique core. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu; unique core. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu; unique core. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu; unique core. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Co2+ cation; prefer SRD-46 entry.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded ([HCoO2]- and [Co(OH)3]- are notation variants of the same Co(II) hydroxo-anion (differ by H2O); identical charge and nuclearity, near-identical mu — keep SRD-46.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (Identical species (Co3+, same charge and mu); prefer SRD-46 source per rule 1.) |
| `Cu+` | Atlas | aqueous | dedup: excluded (Identical Cu(I) aqueous monocation from both sources with equal mu; keep SRD-46 per dedup rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (Identical species (Cu2+ aqueous, same charge and mu); prefer SRD-46 notation.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+ ion; keep SRD-46 version per tie-break rule.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear anionic Ni(II) hydroxo complex written two ways; prefer SRD-46.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (Atlas 'CoO hyd. (Co(OH)2)' is the same species as SRD-46 [Co(OH)2](s); prefer SRD-46. Anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide for aqueous near-room-T speciation.) |
| `CoO` | Atlas | dissolution | dedup: excluded (Atlas 'CoO hyd. (Co(OH)2)' is the same species as SRD-46 [Co(OH)2](s); prefer SRD-46. Anhydrous CoO dropped per addendum favoring hydrated oxyhydroxide for aqueous near-room-T speciation.) |
| `Co2O3 hyd. (Co(OH)3)` | Atlas | dissolution | dedup: excluded (Both rows represent the same Co(III) hydroxide solid; Atlas entry is the dinuclear Co2O3·hydrate notation of Co(OH)3. Prefer SRD-46 critically-evaluated value.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated oxyhydroxide that precipitates from solution over anhydrous CuO; SRD-46 [Cu(OH)2](s) kept over duplicate Atlas Cu(OH)2 per source priority.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated oxyhydroxide that precipitates from solution over anhydrous CuO; SRD-46 [Cu(OH)2](s) kept over duplicate Atlas Cu(OH)2 per source priority.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous NiO in favor of hydrated Ni(OH)2 for aqueous speciation; between duplicate Ni(OH)2 entries prefer SRD-46.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous NiO in favor of hydrated Ni(OH)2 for aqueous speciation; between duplicate Ni(OH)2 entries prefer SRD-46.) |

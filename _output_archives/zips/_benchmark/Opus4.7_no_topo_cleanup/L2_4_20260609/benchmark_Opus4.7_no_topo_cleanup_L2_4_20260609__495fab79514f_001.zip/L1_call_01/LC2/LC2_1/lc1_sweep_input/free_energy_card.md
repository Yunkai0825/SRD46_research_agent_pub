# Free Energy Analysis Card

**System**: H, Co, Ni, Cu / Glycine, Hydroxide ion
**Metals**: [Co]3+, [Co]2+, [Ni]2+, [Cu]2+, [Cu]+
**Ligands**: [Glycine]
**Generated**: 2026-06-09 18:49:54 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Co]3+ |
| M2 | Metal component: [Co]2+ |
| M3 | Metal component: [Ni]2+ |
| M4 | Metal component: [Cu]2+ |
| M5 | Metal component: [Cu]+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Glycine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Co]3+ | +3 | 0.001 | NIST SRD-46 | metal_34 |
| M2 | [Co]2+ | +2 | 0.001 | NIST SRD-46 | metal_33 |
| M3 | [Ni]2+ | +2 | 0.001 | NIST SRD-46 | metal_112 |
| M4 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |
| M5 | [Cu]+ | +1 | 0.001 | NIST SRD-46 | metal_42 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | 0.01 | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | M2 | [Co]2+ | +2 | true | 2 |
| Co | M1 | [Co]3+ | +3 | false | 2 |
| Cu | M5 | [Cu]+ | +1 | true | 2 |
| Cu | M4 | [Cu]2+ | +2 | false | 2 |
| Ni | M3 | [Ni]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Co]3+ | metal | [Co]3+(aq) | +0.0000 | R1 | Co | +3 | false |
| M2 | [Co]2+ | metal | [Co]2+(aq) | +0.0000 | R1 | Co | +2 | true |
| M3 | [Ni]2+ | metal | [Ni]2+(aq) | +0.0000 | R1 | Ni | +2 | true |
| M4 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M5 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Glycine] | ligand_canonical | [[H][L1]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Glycine] | [L1] -> [[H][L1]] | 1 | 1 | +9.5700 | +54.6226 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Glycine] | 25.0 | 0.1 | *** | 2 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Co]3+ + *** | 25.0 | 0 | *** | 1 |
| [Co]2+ + [Glycine] | 25.0 | 0.1 | 70 | 4 |
| [Co]2+ + *** | 25.0 | 0 | *** | 7 |
| [Ni]2+ + [Glycine] | 25.0 | 0.1 | 77 | 3 |
| [Ni]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Cu]2+ + [Glycine] | 25.0 | 0.1 | 86 | 2 |
| [Cu]2+ + *** | 25.0 | 0~0.1 | *** | 6 |
| [Cu]+ + [Glycine] | 25.0 | 0.1 | 100 | 1 |
| [Cu]+ + *** | 25.0 | 0 | *** | 1 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Glycine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z+0] | [HGlycine] | +0 | aqueous | +9.5700 | -54.6226 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_93606 | *** |
| [L1].[z-1] | [Glycine] | -1 | aqueous | +0.0000 | -0.0000 | +54.6226 | +54.6226 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Co]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+3] | [Co]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Co]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Co]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Co]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1]3.[z-1] | [Co(Glyc)3]- | -1 | aqueous | +10.9000 | -62.2138 | -62.2138 | -62.2138 | [M2]:+1, [L1]:+3 | vlm_93785 | *** |
| [M2].[L1]2.[z+0] | [Co(Glyc)2] | +0 | aqueous | +8.4600 | -48.2871 | -48.2871 | -48.2871 | [M2]:+1, [L1]:+2 | vlm_93773 | *** |
| [M2].[L1].[z+1] | [Co(Glyc)]+ | +1 | aqueous | +4.6700 | -26.6549 | -26.6549 | -26.6549 | [M2]:+1, [L1]:+1 | vlm_93761 | *** |

#### [Co]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Co(OH)]+ | +1 | aqueous | -9.7000 | +55.3646 | +55.3646 | +55.3646 | [M2]:+1, [OH]:+1 | vlm_170687 | *** |
| [M2]2.[OH].[z+3] | [Co2(OH)]3+ | +3 | aqueous | -11.0000 | +62.7846 | +62.7846 | +62.7846 | [M2]:+2, [OH]:+1 | vlm_170694 | *** |
| [M2].[OH]2.[z+0] | [Co(OH)2] | +0 | aqueous | -18.8000 | +107.3046 | +107.3046 | +107.3046 | [M2]:+1, [OH]:+2 | vlm_170689 | *** |
| [M2]4.[OH]4.[z+4] | [Co4(OH)4]4+ | +4 | aqueous | -30.5000 | +174.0846 | +174.0846 | +174.0846 | [M2]:+4, [OH]:+4 | vlm_170696 | *** |
| [M2].[OH]3.[z-1] | [Co(OH)3]- | -1 | aqueous | -31.5000 | +179.7923 | +179.7923 | +179.7923 | [M2]:+1, [OH]:+3 | vlm_170691 | *** |
| [M2].[OH]4.[z-2] | [Co(OH)4]2- | -2 | aqueous | -46.3000 | +264.2661 | +264.2661 | +264.2661 | [M2]:+1, [OH]:+4 | vlm_170692 | *** |

#### [Ni]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Ni]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ni]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L1]3.[z-1] | [Ni(Glyc)3]- | -1 | aqueous | +14.1000 | -80.4785 | -80.4785 | -80.4785 | [M3]:+1, [L1]:+3 | vlm_93832 | *** |
| [M3].[L1]2.[z+0] | [Ni(Glyc)2] | +0 | aqueous | +10.5800 | -60.3874 | -60.3874 | -60.3874 | [M3]:+1, [L1]:+2 | vlm_93815 | *** |
| [M3].[L1].[z+1] | [Ni(Glyc)]+ | +1 | aqueous | +5.7400 | -32.7622 | -32.7622 | -32.7622 | [M3]:+1, [L1]:+1 | vlm_93798 | *** |

#### [Ni]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Ni(OH)]+ | +1 | aqueous | -10.4000 | +59.3600 | +59.3600 | +59.3600 | [M3]:+1, [OH]:+1 | vlm_170699 | *** |
| [M3].[OH]2.[z+0] | [Ni(OH)2] | +0 | aqueous | -19.0000 | +108.4461 | +108.4461 | +108.4461 | [M3]:+1, [OH]:+2 | vlm_170704 | *** |
| [M3]4.[OH]4.[z+4] | [Ni4(OH)4]4+ | +4 | aqueous | -27.7000 | +158.1031 | +158.1031 | +158.1031 | [M3]:+4, [OH]:+4 | vlm_170709 | *** |
| [M3].[OH]3.[z-1] | [Ni(OH)3]- | -1 | aqueous | -30.0000 | +171.2308 | +171.2308 | +171.2308 | [M3]:+1, [OH]:+3 | vlm_170705 | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[L1]2.[z+0] | [Cu(Glyc)2] | +0 | aqueous | +15.1000 | -86.1861 | -86.1861 | -86.1861 | [M4]:+1, [L1]:+2 | vlm_93862 | *** |
| [M4].[L1].[z+1] | [Cu(Glyc)]+ | +1 | aqueous | +8.1900 | -46.7460 | -46.7460 | -46.7460 | [M4]:+1, [L1]:+1 | vlm_93847 | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M4]:+1, [OH]:+1 | vlm_170713 | *** |
| [M4]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M4]:+2, [OH]:+2 | vlm_170727 | *** |
| [M4].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M4]:+1, [OH]:+2 | vlm_170721 | *** |
| [M4]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M4]:+3, [OH]:+4 | vlm_170736 | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M5].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M5]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M5].[L1]2.[z-1] | [Cu(Glyc)2]- | -1 | aqueous | +10.1000 | -57.6477 | -57.6477 | -57.6477 | [M5]:+1, [L1]:+2 | vlm_93899 | *** |

### 5.2 Dissolution / Solid Species

#### [Co]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]3.[z+0]_(s) | [Co(OH)3](s) | +0 | dissolution | +2.3000 | -13.1277 | -13.1277 | -13.1277 | [M1]:+1, [OH]:+3 | vlm_170830 | *** |

#### [Co]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Co(OH)2](s) | +0 | dissolution | -13.1000 | +74.7708 | +74.7708 | +74.7708 | [M2]:+1, [OH]:+2 | vlm_170698 | *** |

#### [Ni]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ni(OH)2](s) | +0 | dissolution | -12.8000 | +73.0585 | +73.0585 | +73.0585 | [M3]:+1, [OH]:+2 | vlm_170712 | *** |

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M4]:+1, [OH]:+2 | vlm_170742 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 33 |
| Included in calculation | 33 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 29 |
| Unresolved (no species in card) | 4 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_93627 | [<H+><Glycine>] + [<H+>] <=> [<H+>2<Glycine>] | +2.3300 | 25.0 | 0.100 | yes | — |
| 2 | vlm_93606 | [<H+>] + [<Glycine>] <=> [<H+><Glycine>] | +9.5700 | 25.0 | 0.100 | yes | [HGlycine] |
| 3 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 4 | vlm_170830 | [<Co3+><OH+->3(s)] <=> [<OH+->]^3 + [<Co3+>] | -44.3000 | 25.0 | 0.000 | yes | [Co(OH)3](s) |
| 5 | vlm_93785 | [<Glycine>]^3 + [<Co2+>] <=> [<Co2+><Glycine>3] | +10.9000 | 25.0 | 0.100 | yes | [Co(Glyc)3]- |
| 6 | vlm_93761 | [<Glycine>] + [<Co2+>] <=> [<Co2+><Glycine>] | +4.6700 | 25.0 | 0.100 | yes | [Co(Glyc)]+ |
| 7 | vlm_93797 | [<H+>] + [<Co2+>(<O<H+>>)<Glycine>] <=> [H+2O] + [<Co2+><Glycine>] | +10.0900 | 25.0 | 0.100 | yes | — |
| 8 | vlm_93773 | [<Glycine>]^2 + [<Co2+>] <=> [<Co2+><Glycine>2] | +8.4600 | 25.0 | 0.100 | yes | [Co(Glyc)2] |
| 9 | vlm_170689 | [<OH+->]^2 + [<Co2+>] <=> [<Co2+><OH+->2] | +9.2000 | 25.0 | 0.000 | yes | [Co(OH)2] |
| 10 | vlm_170691 | [<OH+->]^3 + [<Co2+>] <=> [<Co2+><OH+->3] | +10.5000 | 25.0 | 0.000 | yes | [Co(OH)3]- |
| 11 | vlm_170692 | [<OH+->]^4 + [<Co2+>] <=> [<Co2+><OH+->4] | +9.7000 | 25.0 | 0.000 | yes | [Co(OH)4]2- |
| 12 | vlm_170694 | [<OH+->] + [<Co2+>]^2 <=> [<Co2+>2<OH+->] | +3.0000 | 25.0 | 0.000 | yes | [Co2(OH)]3+ |
| 13 | vlm_170696 | [<OH+->]^4 + [<Co2+>]^4 <=> [<Co2+>4<OH+->4] | +25.5000 | 25.0 | 0.000 | yes | [Co4(OH)4]4+ |
| 14 | vlm_170687 | [<OH+->] + [<Co2+>] <=> [<Co2+><OH+->] | +4.3000 | 25.0 | 0.000 | yes | [Co(OH)]+ |
| 15 | vlm_170698 | [<Co2+><OH+->2(s)] <=> [<OH+->]^2 + [<Co2+>] | -14.9000 | 25.0 | 0.000 | yes | [Co(OH)2](s) |
| 16 | vlm_93832 | [<Glycine>]^3 + [<Ni2+>] <=> [<Ni2+><Glycine>3] | +14.1000 | 25.0 | 0.100 | yes | [Ni(Glyc)3]- |
| 17 | vlm_93798 | [<Glycine>] + [<Ni2+>] <=> [<Ni2+><Glycine>] | +5.7400 | 25.0 | 0.100 | yes | [Ni(Glyc)]+ |
| 18 | vlm_93815 | [<Glycine>]^2 + [<Ni2+>] <=> [<Ni2+><Glycine>2] | +10.5800 | 25.0 | 0.100 | yes | [Ni(Glyc)2] |
| 19 | vlm_170699 | [<OH+->] + [<Ni2+>] <=> [<Ni2+><OH+->] | +3.6000 | 25.0 | 0.100 | yes | [Ni(OH)]+ |
| 20 | vlm_170704 | [<OH+->]^2 + [<Ni2+>] <=> [<Ni2+><OH+->2] | +9.0000 | 25.0 | 0.000 | yes | [Ni(OH)2] |
| 21 | vlm_170705 | [<OH+->]^3 + [<Ni2+>] <=> [<Ni2+><OH+->3] | +12.0000 | 25.0 | 0.000 | yes | [Ni(OH)3]- |
| 22 | vlm_170709 | [<OH+->]^4 + [<Ni2+>]^4 <=> [<Ni2+>4<OH+->4] | +28.3000 | 25.0 | 0.000 | yes | [Ni4(OH)4]4+ |
| 23 | vlm_170712 | [<Ni2+><OH+->2(s)] <=> [<OH+->]^2 + [<Ni2+>] | -15.2000 | 25.0 | 0.000 | yes | [Ni(OH)2](s) |
| 24 | vlm_93862 | [<Glycine>]^2 + [<Cu2+>] <=> [<Cu2+><Glycine>2] | +15.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2] |
| 25 | vlm_93847 | [<Glycine>] + [<Cu2+>] <=> [<Cu2+><Glycine>] | +8.1900 | 25.0 | 0.100 | yes | [Cu(Glyc)]+ |
| 26 | vlm_170721 | [<OH+->]^2 + [<Cu2+>] <=> [<Cu2+><OH+->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 27 | vlm_170727 | [<OH+->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH+->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 28 | vlm_170736 | [<OH+->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH+->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 29 | vlm_170713 | [<OH+->] + [<Cu2+>] <=> [<Cu2+><OH+->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 30 | vlm_170742 | [<Cu2+><OH+->2(s)] <=> [<OH+->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 31 | vlm_170746 | [H+2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [O<H+>]^2 | -20.3500 | 25.0 | 0.000 | yes | — |
| 32 | vlm_93899 | [<Glycine>]^2 + [<Cu+>] <=> [<Cu+><Glycine>2] | +10.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2]- |
| 33 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H+2O]^0 <=> [<Cu+>] + [O<H+>] | -14.7000 | 25.0 | 0.000 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

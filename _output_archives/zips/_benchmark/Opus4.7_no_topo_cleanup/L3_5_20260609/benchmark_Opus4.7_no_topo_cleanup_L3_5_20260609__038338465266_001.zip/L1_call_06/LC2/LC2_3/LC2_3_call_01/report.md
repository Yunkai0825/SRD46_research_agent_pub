# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_06\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_06\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    105.54
- elapsed_s (total):  105.55
- llm_iterations:     19
- llm_tool_calls:     14

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | Identical Ni2+ aqueous ion in both sources with same mu; prefer SRD-46 per plan rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity and charge (mononuclear +1 vs tetranuclear +4) make these distinct species despite shared core ratio. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same species in different notation (HNiO2- = Ni(OH)3-); keep SRD-46 version. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. Anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `L1:1 H:1` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `L1:1 H:2` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 H:-2` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:1` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:2` | yes | Sole member; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:3` | yes | Sole member; valid mu_aligned_kJ. |
| solid | `Ni$+0:1` | yes | Sole member; valid mu_aligned_kJ. |
| solid | `Ni$+2:3 H:-8` | yes | Sole member; valid mu_aligned_kJ. |
| solid | `Ni$+3:1 H:-3` | yes | Sole member; valid mu_aligned_kJ. |
| solid | `Ni$+4:1 H:-4` | yes | Sole member; valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (Identical Ni2+ aqueous ion in both sources with same mu; prefer SRD-46 per plan rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same species in different notation (HNiO2- = Ni(OH)3-); keep SRD-46 version.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. Anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. Anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide.) |

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_06\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.86
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D pH sweep to evaluate Ni-en speciation including pH 7.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_06\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
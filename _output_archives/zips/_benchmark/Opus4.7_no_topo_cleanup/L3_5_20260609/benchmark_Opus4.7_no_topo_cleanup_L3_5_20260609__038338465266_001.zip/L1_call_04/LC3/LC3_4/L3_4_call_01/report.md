# L3_4 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_04\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 4.91
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 0.0,
    "max": 14.0,
    "n_points": 141
  }
]
```

## Grid: 141 cell(s) across 1 axis/axes
- calc_input_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_04\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    46.49
- elapsed_s (total):  46.50
- llm_iterations:     15
- llm_tool_calls:     8

- n_groups:           13
- n_multi_groups:     5
- n_singletons:       8
- n_decisions:        13
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+; prefer SRD-46 over Atlas per dedup rule 1. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate: identical mononuclear aqueous Zn(OH)+ species; prefer SRD-46 over Atlas. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are the same aqueous mononuclear monoanion in different notation (hydration convention); keep SRD-46 entry with lower mu. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are notational variants of the same zincate anion; keep SRD-46 form. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over its Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ (1.256); sole member of its core group. |
| aqueous | `L1:1` | yes | Glycinate anion with valid mu_aligned_kJ; unique singleton. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine reference species with defined mu_aligned_kJ=0. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(OH)2(aq) singleton with valid mu_aligned_kJ. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn-glycinate 1:1 complex, valid thermodynamics. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn-glycinate 1:2 complex, valid thermodynamics. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn-glycinate 1:3 complex, valid thermodynamics. |
| solid | `Zn$+0:1` | yes | Zn metal reference solid with valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+; prefer SRD-46 over Atlas per dedup rule 1.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate: identical mononuclear aqueous Zn(OH)+ species; prefer SRD-46 over Atlas.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are the same aqueous mononuclear monoanion in different notation (hydration convention); keep SRD-46 entry with lower mu.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are notational variants of the same zincate anion; keep SRD-46 form.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over its Atlas duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over its Atlas duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over its Atlas duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over its Atlas duplicate.) |

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    75.15
- elapsed_s (total):  75.16
- llm_iterations:     23
- llm_tool_calls:     15

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicate: identical aqueous Co2+ species; keep SRD-46 version per dedup rule 1. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite shared core ratio. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | [HCoO2]- and [Co(OH)3]- are the same aqueous Co(II) hydroxo-anion in different notation (differ by H2O); keep SRD-46 critically-evaluated value. |
| aqueous | `Co$+3:1` | `[Co]3+` | Identical species (Co3+, +3, same mu); kept SRD-46 per preference. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | Per addendum drop anhydrous CoO in favor of hydrated Co(OH)2; between the two Co(OH)2 notations, prefer SRD-46 over Atlas duplicate. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | Prefer SRD-46 mononuclear hydrated Co(OH)3 over Atlas dimeric Co2O3 anhydrous-equivalent per addendum. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique solvent/proton reference species. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid thermodynamics; unique neutral hydrolysis complex. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique tetrahydroxo complex. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique 1:1 Co-glycinate complex. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique 1:2 Co-glycinate complex. |
| aqueous | `Co$+2:1 L1:3` | yes | Valid mu_aligned_kJ; unique 1:3 Co-glycinate complex. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid mu_aligned_kJ; unique dinuclear hydroxo complex. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; deprotonated glycinate ligand. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; neutral protonated glycine reference. |
| solid | `Co$+0:1` | yes | Valid mu_aligned_kJ; metallic cobalt reference phase. |
| solid | `Co$+2:3 H:-8` | yes | Valid mu_aligned_kJ; unique Co3O4 spinel phase. |
| solid | `Co$+4:1 H:-4` | yes | Valid mu_aligned_kJ; unique CoO2 phase. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicate: identical aqueous Co2+ species; keep SRD-46 version per dedup rule 1.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded ([HCoO2]- and [Co(OH)3]- are the same aqueous Co(II) hydroxo-anion in different notation (differ by H2O); keep SRD-46 critically-evaluated value.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (Identical species (Co3+, +3, same mu); kept SRD-46 per preference.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (Per addendum drop anhydrous CoO in favor of hydrated Co(OH)2; between the two Co(OH)2 notations, prefer SRD-46 over Atlas duplicate.) |
| `CoO` | Atlas | dissolution | dedup: excluded (Per addendum drop anhydrous CoO in favor of hydrated Co(OH)2; between the two Co(OH)2 notations, prefer SRD-46 over Atlas duplicate.) |
| `Co2O3 hyd. (Co(OH)3)` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 mononuclear hydrated Co(OH)3 over Atlas dimeric Co2O3 anhydrous-equivalent per addendum.) |

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    46.72
- elapsed_s (total):  46.72
- llm_iterations:     14
- llm_tool_calls:     8

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of Cu+ aqueous monocation; prefer SRD-46 source per plan. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity and charge — mononuclear vs dinuclear Cu hydroxo complexes are distinct species. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+1:1 L1:2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; unique core (free glycinate). |
| aqueous | `L1:1 H:1` | yes | Reference species (mu=0); unique core. |
| solid | `Cu$+0:1` | yes | Valid mu_aligned_kJ; metallic Cu reference. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; cuprite. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu+ aqueous monocation; prefer SRD-46 source per plan.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+; prefer SRD-46 notation.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate.) |

# Speciation Calculation Report: Cu$+1 + Cu$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | Glycine | 1.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | -57.6477 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | -86.1861 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | -46.7460 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 3.30: Cu2O (4.37e-05 M)
- pH 11.30: Cu2O (4.96e-04 M), [Cu(OH)2](s) (4.73e-05 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu+                 peak 100.0% at pH 0.0
  [Cu(Glyc)2]-        peak 9.4% at pH 9.6
  Cu2O                peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  3.6  →  Cu+
  pH   3.6– 14.0  →  Cu2O

Crossover pH values:
  Cu+ ↔ Cu2O  at pH ≈ 3.56  (each ~50%)

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu2+                peak 100.0% at pH 0.0
  HCuO2-              peak 9.4% at pH 14.0
  CuO22-              peak 69.0% at pH 14.0
  [Cu(Glyc)2]         peak 100.0% at pH 10.4
  [Cu(Glyc)]+         peak 68.5% at pH 4.1
  [Cu(OH)2](s)        peak 99.1% at pH 12.6

Dominant species by pH region:
  pH   0.0–  3.5  →  Cu2+
  pH   3.5–  4.8  →  [Cu(Glyc)]+
  pH   4.8– 11.5  →  [Cu(Glyc)2]
  pH  11.5– 14.0  →  [Cu(OH)2](s)
  pH  14.0– 14.0  →  CuO22-

Crossover pH values:
  Cu2+ ↔ [Cu(Glyc)2]  at pH ≈ 4.07  (each ~16%)
  Cu2+ ↔ [Cu(Glyc)]+  at pH ≈ 3.40  (each ~49%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.91  (each ~46%)
  [Cu(Glyc)2] ↔ [Cu(Glyc)]+  at pH ≈ 4.73  (each ~49%)
  [Cu(Glyc)2] ↔ [Cu(OH)2](s)  at pH ≈ 11.49  (each ~50%)

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  HGlycine            peak 100.0% at pH 0.0
  Glycine             peak 100.0% at pH 14.0
  [Cu(Glyc)2]         peak 20.0% at pH 10.4
  [Cu(Glyc)]+         peak 6.9% at pH 4.1

Dominant species by pH region:
  pH   0.0–  9.6  →  HGlycine
  pH   9.6– 14.0  →  Glycine

```
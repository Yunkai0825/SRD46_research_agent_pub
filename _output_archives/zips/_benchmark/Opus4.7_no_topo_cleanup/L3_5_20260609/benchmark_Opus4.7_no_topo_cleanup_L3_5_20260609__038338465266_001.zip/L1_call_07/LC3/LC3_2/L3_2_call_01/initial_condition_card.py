inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],          "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_7029"], "value": 1e-2, "basis": "known"},
]
# Speciation Calculation Report: Cu$+1 + Cu$+2 + Ethylenediamine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu | Cu | 1.00e-03 | metal |
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | Ethylenediamine | 1.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H2Ethylenediamine2+ | aqueous | L1:+1 H:+2 | — | -97.2020 | -97.2020 |
| HEthylenediamine+ | aqueous | L1:+1 H:+1 | — | -56.6203 | -56.6203 |
| Ethylenediamine | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Ethy)2]+ | aqueous | L1:+2 Cu$+1:+1 | — | -63.9261 | -63.9261 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Ethy)2]2+ | aqueous | L1:+2 Cu$+2:+1 | — | -111.8708 | -111.8708 |
| [Cu(Ethy)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -59.8737 | -59.8737 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 3.30: Cu2O (4.37e-05 M)
- pH 13.60: Cu2O (5.00e-04 M), [Cu(OH)2](s) (1.89e-05 M)

## Speciation Analysis

```
=== Cu (Cu) speciation ===
[Cu]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu+                 peak 100.0% at pH 0.0
  [Cu(Ethy)2]+        peak 43.9% at pH 9.9
  Cu2O                peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  3.6  →  Cu+
  pH   3.6– 14.0  →  Cu2O

Crossover pH values:
  Cu+ ↔ Cu2O  at pH ≈ 3.56  (each ~50%)

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu2+                peak 100.0% at pH 0.0
  HCuO2-              peak 9.4% at pH 14.0
  CuO22-              peak 69.0% at pH 14.0
  [Cu(Ethy)2]2+       peak 100.0% at pH 11.1
  [Cu(Ethy)]2+        peak 70.7% at pH 4.6
  [Cu(OH)2](s)        peak 26.1% at pH 13.8

Dominant species by pH region:
  pH   0.0–  4.3  →  Cu2+
  pH   4.3–  5.0  →  [Cu(Ethy)]2+
  pH   5.0– 13.9  →  [Cu(Ethy)2]2+
  pH  13.9– 14.0  →  CuO22-

Crossover pH values:
  Cu2+ ↔ [Cu(Ethy)2]2+  at pH ≈ 4.64  (each ~15%)
  Cu2+ ↔ [Cu(Ethy)]2+  at pH ≈ 4.28  (each ~49%)
  HCuO2- ↔ [Cu(OH)2](s)  at pH ≈ 13.97  (each ~9%)
  CuO22- ↔ [Cu(Ethy)2]2+  at pH ≈ 13.84  (each ~35%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.68  (each ~16%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.75  (each ~23%)
  [Cu(Ethy)2]2+ ↔ [Cu(Ethy)]2+  at pH ≈ 5.00  (each ~49%)

=== Ethylenediamine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  H2Ethylenediamine2+  peak 100.0% at pH 0.0
  HEthylenediamine+   peak 72.9% at pH 8.4
  Ethylenediamine     peak 96.4% at pH 14.0
  [Cu(Ethy)2]+        peak 8.8% at pH 9.9
  [Cu(Ethy)2]2+       peak 20.0% at pH 11.1
  [Cu(Ethy)]2+        peak 7.1% at pH 4.6

Dominant species by pH region:
  pH   0.0–  7.2  →  H2Ethylenediamine2+
  pH   7.2– 10.0  →  HEthylenediamine+
  pH  10.0– 14.0  →  Ethylenediamine

```
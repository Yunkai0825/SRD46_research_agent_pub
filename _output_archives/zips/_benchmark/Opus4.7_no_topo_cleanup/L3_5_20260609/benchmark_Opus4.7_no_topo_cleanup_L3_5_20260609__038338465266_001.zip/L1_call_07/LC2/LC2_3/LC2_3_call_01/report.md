# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_07\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_07\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    46.06
- elapsed_s (total):  46.07
- llm_iterations:     15
- llm_tool_calls:     9

- n_groups:           17
- n_multi_groups:     4
- n_singletons:       13
- n_decisions:        17
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of Cu+ cation; prefer SRD-46 entry per plan rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+ with identical mu; prefer SRD-46 entry. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge) per rule 2. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `Cu$+1:1 L1:2` | yes | Valid thermodynamics; unique Cu(I)-ethylenediamine 1:2 complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique Cu(II)-ethy 1:1 complex. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid mu_aligned_kJ; unique Cu(II)-ethy 1:2 complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; unique polynuclear Cu(II) hydroxo cluster. |
| aqueous | `L1:1` | yes | Reference ligand species, mu=0 by convention. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; monoprotonated ligand. |
| aqueous | `L1:1 H:2` | yes | Valid mu_aligned_kJ; diprotonated ligand. |
| solid | `Cu$+0:1` | yes | Valid; metallic copper reference solid. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; cuprite Cu2O. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu+ cation; prefer SRD-46 entry per plan rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+ with identical mu; prefer SRD-46 entry.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |

[Purpose: Compute Co(II)-ethylenediamine speciation at pH 7 to measure free [Co2+] suppression.]
[Tasks:
Model a solution of Co(II) at 1 mM with ethylenediamine (en) at 10 mM at pH 7, 25 C, ionic strength 0.1 m. Report the fraction of metal remaining as free Co2+ and the dominant Co-en complexes at pH 7.
]
[Pair: pair_key=`m68_l7029`, metal_id=68, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand7029_beta79_net9567`
[Screen report]
# Eq-map screen — m68_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand7029_beta79_net9567` | `[L] + [H] <=> [HL]` | vlm_122282@(25.0,0.1) = K+9.920 | 11 | -10.300 / +10.040 / +8.306 / +10.800 | vlm_122282@(25.0,0.1) = K+9.920 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 2 | `metal68_ligand7029_beta32_net9567` | `[HL] + [H] <=> [H2L]` | vlm_122303@(25.0,0.1) = K+7.110 | 10 | +6.463 / +7.288 / +7.313 / +8.210 | vlm_122303@(25.0,0.1) = K+7.110 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_05\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 25.55
- llm_iterations: 4
- llm_tool_calls: 3
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (4 known, 1 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["ligand_7029"], "rhs": 0.01, "basis": "known"},
]
```

## Notes
T=25 C, I=0.1 M, Co(II)=1 mM, en=10 mM all from task. Co(III) pinned to 0 to keep the system in the Co(II) oxidation state (no redox sweep). pH is the swept axis and is left free.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
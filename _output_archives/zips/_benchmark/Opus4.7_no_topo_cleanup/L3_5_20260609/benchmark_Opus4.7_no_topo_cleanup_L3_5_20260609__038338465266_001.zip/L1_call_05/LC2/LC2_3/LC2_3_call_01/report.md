# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_05\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_05\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    134.05
- elapsed_s (total):  134.07
- llm_iterations:     31
- llm_tool_calls:     24

- n_groups:           20
- n_multi_groups:     6
- n_singletons:       14
- n_decisions:        20
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` | True duplicates of aqueous Co2+; prefer SRD-46 per rule 1. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+`, `[Co4(OH)4]4+` | Mononuclear and tetranuclear Co hydroxo species differ in nuclearity and charge; both retained as distinct chemistry. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | [HCoO2]- and [Co(OH)3]- are notational variants of the same mononuclear Co(III) hydroxo anion (differ by one H2O); prefer SRD-46. |
| aqueous | `Co$+3:1` | `[Co]3+` | True duplicate of Co3+ aqueous cation; prefer SRD-46 over Atlas per plan rule 1. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | Per addendum, prefer hydrated Co(OH)2 over anhydrous CoO; between the two Co(OH)2 entries prefer SRD-46. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | Same species (Co(OH)3 solid); Atlas entry is the dimer-notation duplicate, so keep the SRD-46 mononuclear form. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ=1.256; only species in group. |
| aqueous | `Co$+2:1 H:-2` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+2:1 H:-4` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+2:1 L1:1` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+2:1 L1:2` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+2:1 L1:3` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+2:2 H:-1` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `Co$+3:1 L1:3` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `L1:1` | yes | Reference ligand species; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid thermodynamics; sole member of group. |
| aqueous | `L1:1 H:2` | yes | Valid thermodynamics; sole member of group. |
| solid | `Co$+0:1` | yes | Metal reference; sole member. |
| solid | `Co$+2:3 H:-8` | yes | Valid thermodynamics; sole member of group. |
| solid | `Co$+4:1 H:-4` | yes | Valid thermodynamics; sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | dedup: excluded (True duplicates of aqueous Co2+; prefer SRD-46 per rule 1.) |
| `[HCoO2]-` | Atlas | aqueous | dedup: excluded ([HCoO2]- and [Co(OH)3]- are notational variants of the same mononuclear Co(III) hydroxo anion (differ by one H2O); prefer SRD-46.) |
| `Co3+` | Atlas | aqueous | dedup: excluded (True duplicate of Co3+ aqueous cation; prefer SRD-46 over Atlas per plan rule 1.) |
| `CoO hyd. (Co(OH)2)` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Co(OH)2 over anhydrous CoO; between the two Co(OH)2 entries prefer SRD-46.) |
| `CoO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Co(OH)2 over anhydrous CoO; between the two Co(OH)2 entries prefer SRD-46.) |
| `Co2O3 hyd. (Co(OH)3)` | Atlas | dissolution | dedup: excluded (Same species (Co(OH)3 solid); Atlas entry is the dimer-notation duplicate, so keep the SRD-46 mononuclear form.) |

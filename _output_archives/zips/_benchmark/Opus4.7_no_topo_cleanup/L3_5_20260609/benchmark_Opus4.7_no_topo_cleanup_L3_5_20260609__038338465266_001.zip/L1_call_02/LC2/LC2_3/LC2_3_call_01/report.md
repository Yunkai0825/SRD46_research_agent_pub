# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_5_IrvingWilliams_two_ligand_robustness\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    126.44
- elapsed_s (total):  126.45
- llm_iterations:     26
- llm_tool_calls:     22

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+; prefer SRD-46 entry. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) at same core ratio are distinct species per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | True duplicate: same mononuclear Ni(II) hydroxo-anion notation; prefer SRD-46. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ for deprotonated glycinate; unique core. |
| aqueous | `L1:1 H:1` | yes | Reference glycine zwitterion with mu=0; unique core. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ for Ni(OH)2(aq); unique core. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ for Ni(Glyc)+ complex; unique core. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ for Ni(Glyc)2 complex; unique core. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid mu_aligned_kJ for Ni(Glyc)3- complex; unique core. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid; valid thermodynamics. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ for Ni3O4.2H2O solid; unique core. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ for Ni2O3.H2O solid; unique core. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ for NiO2.2H2O solid; unique core. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+; prefer SRD-46 entry.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (True duplicate: same mononuclear Ni(II) hydroxo-anion notation; prefer SRD-46.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated oxyhydroxide.) |

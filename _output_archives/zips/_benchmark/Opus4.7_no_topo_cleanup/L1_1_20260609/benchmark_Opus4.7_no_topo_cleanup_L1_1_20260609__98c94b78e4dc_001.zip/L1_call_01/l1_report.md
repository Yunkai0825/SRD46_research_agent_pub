## Doability
Doable. Ni–glycine is in SRD-46 scope and `pourbaix_sweep` is a supported method.

## Result
- System: Ni(II) 1 mM + glycine 10 mM, T = 25 °C, I = 0.1 m.
- Method: `pourbaix_sweep`, pH ∈ [0, 14] × Eh ∈ [−1.0, +1.5] V vs SHE, coarse 64×64 grid refined adaptively to 127×127.
- Convergence: sweep completed; topology extracted 6 dominant-species regions, 7 triple points and 11 boundary segments. No solver failures.
- Dominant species recovered: Ni(s), Ni²⁺, NiOH⁺, Ni(OH)₂(s), HNiO₂⁻, and the soluble glycinate Ni(gly)₂. (Ni(gly)⁺ and Ni(gly)₃⁻ are present in the database but do not become the single dominant species in any cell at this metal-to-ligand ratio.)

## Analysis
**Overall topology.** The diagram is dominated at low potential by metallic Ni(s), which fills the entire pH = 0–14 band below Eh ≈ −0.44 to −0.48 V (≈59% of the map area). This reduction boundary tracks the equilibrium 2 H⁺ + 2 e⁻ → H₂ region and shifts slightly with pH and with whether the oxidised neighbour is an aquo, hydroxide, or glycinate species (rows 0–4 of `topo_features_1d.csv`: Eh = −0.475 V under Ni²⁺/NiOH⁺/Ni(OH)₂/HNiO₂⁻ but raised to −0.440 V under the Ni(gly)₂ field, because glycinate stabilises Ni(II) and therefore makes its reduction harder).

**Acidic, oxidising corner.** For pH < 7.87 and Eh > −0.44 V, the aquo cation Ni²⁺ dominates (region 1, 14.6% of the map). A very thin NiOH⁺ sliver appears only in the narrow pH 7.14–7.87 / Eh −0.475 to −0.440 V wedge (region 2, 0.5%), i.e. just before Ni(OH)₂ takes over — consistent with Ni²⁺ being a weak acid (pKa₁ ≈ 9–10 in dilute solution, pushed lower here by the 0.1 m ionic strength and the proximity of the hydroxide precipitation line).

**Hydroxide / oxide field.** Ni(OH)₂(s) occupies the large central-to-alkaline block from pH ≈ 7.14 to 12.22 across essentially the whole oxidising half (region 3, 20.0%). Beyond pH ≈ 12.22 it redissolves as the anionic hydroxo-complex HNiO₂⁻ (region 5, 1.4%) — the classic amphoteric re-solubilisation of Ni(OH)₂ in strong base.

**Glycinate stability window (the key deliverable).** The soluble Ni(gly)₂ complex is the dominant Ni species in a well-defined rectangle (region 4, 4.4% of the map):
- pH window: **7.87 – 11.16**
- Eh window: **−0.440 V to +0.275 V vs SHE**

Its neighbours, taken directly from `topo_features_1d.csv`, are:
- **Lower-pH boundary (pH = 7.87, Eh −0.44 → +0.28 V) → Ni²⁺(aq).** Below pH ~7.9 the glycine α-amine is still protonated enough (pKa ≈ 9.6) that the free [gly⁻] is too low to outcompete water for the Ni coordination sphere, so Ni²⁺(aq) wins.
- **Upper-pH boundary (pH = 11.16, Eh −0.44 → +0.28 V) → Ni(OH)₂(s).** Above pH ~11 the activity of OH⁻ is high enough that hydroxide displaces glycinate and precipitates Ni(OH)₂, capping the window on the alkaline side.
- **Upper Eh boundary (Eh = +0.275 V, pH 7.87–11.16) → Ni(OH)₂(s).** Oxidation of Ni(gly)₂ leads to the hydroxide field rather than to a Ni(III) glycinate, because no oxidised Ni–glycinate is included in the database / wins this cell.
- **Lower Eh boundary (Eh = −0.440 V, pH 7.87–11.16) → Ni(s).** Reduction limit — glycinate stabilises Ni(II) and pushes this line ~35 mV positive of the Ni²⁺/Ni(0) line in glycinate-free regions.

The four corners of this rectangle correspond exactly to triple points 2, 3, 4 and 6 in `topo_features_0d.csv` (Ni(OH)₂|Ni(gly)₂|Ni²⁺ at the SW and NW corners; Ni(OH)₂|Ni(gly)₂|Ni(s) at the SE and NE corners on the reduction line).

**Practical implication.** If the goal is to keep Ni in solution as a glycinate complex (e.g. for plating bath chemistry, biological speciation modelling, or chelated-Ni transport), the operating window at these total concentrations is roughly **pH 8–11 and Eh between about −0.4 and +0.3 V vs SHE**. Outside this box Ni is either lost as Ni(OH)₂(s) (high pH or oxidising/neutral) or stripped of its ligand to Ni²⁺(aq) (low pH) or reduced to Ni(s) (low Eh). Raising the glycine:Ni ratio above 10:1 would widen this window — especially towards lower pH and upwards in Eh — and would also let Ni(gly)⁺ and Ni(gly)₃⁻ become dominant in their own sub-regions, which they do not here.

## Artifacts
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` — 2-D Pourbaix diagram (pH vs Eh) with all six species fields.
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` — dominant species per (pH, Eh) cell.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_regions.csv` — six regions with area and bounding box.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_1d.csv` — phase boundaries.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_0d.csv` — triple points.
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` — full per-cell speciation.
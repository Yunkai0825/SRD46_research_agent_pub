# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_1_Ni_glycine_pourbaix_2D\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.09
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},
]
```

## Notes
T=25 C and I=0.1 m stated by task; Ni total 1 mM and glycine total 10 mM from task. pH and E_V are swept axes (pourbaix_sweep) so not pinned.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
[Purpose: Compute the 2-D Pourbaix diagram for Ni in the presence of glycine and identify the stability window of soluble Ni-glycinate complexes.]
[Tasks:
Model a single solution containing Ni(II) at 1 mM with glycine at 10 mM over pH 0-14 and Eh spanning water stability at 25 C and ionic strength 0.1 m. Produce the 2-D Pourbaix diagram (pH vs Eh) showing dominant Ni species in each cell, and identify the pH and Eh window over which soluble Ni-glycinate complexes (e.g. Ni(gly)+, Ni(gly)2, Ni(gly)3-) dominate. Report the boundaries with neighbouring species (aqua-Ni2+, Ni hydroxide/oxide, metallic Ni).
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

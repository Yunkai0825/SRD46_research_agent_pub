[Purpose: Compute the 2-D Pourbaix diagram for Ni in the presence of glycine and identify the stability window of soluble Ni-glycinate complexes.]
[Tasks:
Model a single solution containing Ni(II) at 1 mM with glycine at 10 mM over pH 0-14 and Eh spanning water stability at 25 C and ionic strength 0.1 m. Produce the 2-D Pourbaix diagram (pH vs Eh) showing dominant Ni species in each cell, and identify the pH and Eh window over which soluble Ni-glycinate complexes (e.g. Ni(gly)+, Ni(gly)2, Ni(gly)3-) dominate. Report the boundaries with neighbouring species (aqua-Ni2+, Ni hydroxide/oxide, metallic Ni).
]
[Pair: pair_key=`m112_l5760`, metal_id=112, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal112_ligand5760_beta872_net77`
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m112_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand5760_beta872_net77` | `[M] + [L]^3 <=> [ML3]` | vlm_93832@(25.0,0.1) = K+14.100 | 9 | -15.000 / +13.900 / +4.544 / +14.400 | vlm_93832@(25.0,0.1) = K+14.100 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |
| 2 | `metal112_ligand5760_beta812_net77` | `[M] + [L] <=> [ML]` | vlm_93798@(25.0,0.1) = K+5.740 | 9 | +5.590 / +5.740 / +5.837 / +6.320 | vlm_93798@(25.0,0.1) = K+5.740 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal112_ligand5760_beta840_net77` | `[M] + [L]^2 <=> [ML2]` | vlm_93815@(25.0,0.1) = K+10.580 | 9 | +10.240 / +10.580 / +10.702 / +11.450 | vlm_93815@(25.0,0.1) = K+10.580 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

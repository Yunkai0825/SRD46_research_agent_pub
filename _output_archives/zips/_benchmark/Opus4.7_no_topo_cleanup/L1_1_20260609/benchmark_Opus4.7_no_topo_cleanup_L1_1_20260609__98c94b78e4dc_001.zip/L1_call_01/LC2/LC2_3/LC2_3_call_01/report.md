# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_1_Ni_glycine_pourbaix_2D\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_1_Ni_glycine_pourbaix_2D\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    77.29
- elapsed_s (total):  77.30
- llm_iterations:     20
- llm_tool_calls:     15

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous ion; prefer SRD-46 over Atlas. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Mononuclear and tetranuclear Ni hydroxo complexes are distinct species despite sharing core stoichiometry. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same species in different notation (HNiO2- = Ni(OH)3- differ by H2O); prefer SRD-46. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Prefer SRD-46 Ni(OH)2 over Atlas duplicate; addendum prefers hydrated Ni(OH)2 over anhydrous NiO. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Unique ligand-free aqueous reference species with valid thermodynamics. |
| aqueous | `L1:1` | yes | Sole deprotonated glycinate species; valid mu_aligned_kJ. |
| aqueous | `L1:1 H:1` | yes | Sole neutral glycine species; valid reference (mu=0). |
| aqueous | `Ni$+2:1 H:-2` | yes | Sole aqueous Ni hydrolysis species at this stoichiometry; valid thermodynamics. |
| aqueous | `Ni$+2:1 L1:1` | yes | Unique 1:1 Ni-glycinate complex; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:2` | yes | Unique 1:2 Ni-glycinate complex; valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:3` | yes | Unique 1:3 Ni-glycinate complex; valid mu_aligned_kJ. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid; valid thermodynamics. |
| solid | `Ni$+2:3 H:-8` | yes | Unique mixed-valence Ni oxide hydrate; valid mu_aligned_kJ. |
| solid | `Ni$+3:1 H:-3` | yes | Unique Ni(III) oxide hydrate; valid mu_aligned_kJ. |
| solid | `Ni$+4:1 H:-4` | yes | Unique Ni(IV) oxide hydrate; valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous ion; prefer SRD-46 over Atlas.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same species in different notation (HNiO2- = Ni(OH)3- differ by H2O); prefer SRD-46.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Ni(OH)2 over Atlas duplicate; addendum prefers hydrated Ni(OH)2 over anhydrous NiO.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Ni(OH)2 over Atlas duplicate; addendum prefers hydrated Ni(OH)2 over anhydrous NiO.) |

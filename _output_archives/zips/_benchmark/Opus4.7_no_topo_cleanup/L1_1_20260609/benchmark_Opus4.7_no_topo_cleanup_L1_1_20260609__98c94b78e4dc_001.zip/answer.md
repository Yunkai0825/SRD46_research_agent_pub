## Answer

The 2-D Pourbaix diagram for **1 mM Ni(II) + 10 mM glycine at 25 °C and I = 0.1 m** spans pH 0–14 and Eh −1.0 to +1.5 V vs SHE and resolves six dominant-species fields: metallic **Ni(s)** (the entire reducing half of the map), aqueous **Ni²⁺** in the acidic/oxidising corner, a thin **NiOH⁺** sliver, the **Ni(OH)₂(s)** hydroxide block across the neutral-to-alkaline oxidising region, the strongly alkaline soluble **HNiO₂⁻** field, and — the key result — a well-defined rectangular window in which the soluble bis-glycinate complex **Ni(gly)₂** is the dominant Ni species.

**Stability window of the soluble Ni-glycinate complex:**
- **pH 7.87 – 11.16**
- **Eh −0.440 V to +0.275 V vs SHE**

The chemistry behind those four boundaries is straightforward:

- **Lower pH limit (≈7.9) — Ni²⁺(aq) takes over.** Glycine's α-ammonium has pKa ≈ 9.6, so below pH ~8 most of the ligand is still in its zwitterionic/protonated form and the free glycinate concentration is too low to displace water from the Ni coordination sphere. Hence Ni²⁺(aq) outcompetes Ni(gly)₂.
- **Upper pH limit (≈11.2) — Ni(OH)₂(s) precipitates.** Above this pH the OH⁻ activity is high enough that hydroxide out-binds glycinate at the metal and Ni(OH)₂ drops out as a solid. This is the classic hydroxide capture of a chelated divalent metal at high pH.
- **Upper Eh limit (≈+0.28 V) — oxidation to Ni(OH)₂(s).** No Ni(III)-glycinate is stable in this database, so oxidising the complex simply drives Ni into the hydroxide field rather than into a higher-valent chelate.
- **Lower Eh limit (≈−0.44 V) — reduction to Ni(s).** Glycinate stabilises Ni(II) (it binds the +2 state much more strongly than the metal), which raises this reduction line by ~35 mV vs the glycinate-free Ni²⁺/Ni(0) couple: the chelate makes Ni(II) harder to reduce.

**Practical implication.** To keep Ni soluble as a glycinate complex at these concentrations, operate in roughly **pH 8–11 with Eh between about −0.4 and +0.3 V vs SHE**. Outside this rectangle Ni is lost as Ni(OH)₂(s) at high pH or oxidising/neutral conditions, stripped to Ni²⁺(aq) at low pH, or plated as Ni(s) under reducing conditions. Raising the glycine:Ni ratio above the present 10:1 would widen the window — especially toward lower pH and higher Eh — and would let the mono- and tris-glycinate species Ni(gly)⁺ and Ni(gly)₃⁻ emerge as dominants in their own sub-fields (they exist in the database but are not dominant anywhere on this map at 10:1).

## Evidence
- "The soluble Ni(gly)₂ complex is the dominant Ni species in a well-defined rectangle (region 4, 4.4% of the map): pH window: **7.87 – 11.16**; Eh window: **−0.440 V to +0.275 V vs SHE**."
- "Ni(OH)₂(s) occupies the large central-to-alkaline block from pH ≈ 7.14 to 12.22 across essentially the whole oxidising half (region 3, 20.0%). Beyond pH ≈ 12.22 it redissolves as the anionic hydroxo-complex HNiO₂⁻ (region 5, 1.4%)."
- "Eh = −0.475 V under Ni²⁺/NiOH⁺/Ni(OH)₂/HNiO₂⁻ but raised to −0.440 V under the Ni(gly)₂ field, because glycinate stabilises Ni(II) and therefore makes its reduction harder."
- Topology: 6 dominant-species regions, 7 triple points, 11 boundary segments on a 127×127 adaptively refined grid; no solver failures.

## Artifacts
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` — 2-D Pourbaix diagram (pH vs Eh) showing all six species fields.
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` — dominant species per (pH, Eh) cell.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_regions.csv` — six regions with area and bounding boxes.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_1d.csv` — phase boundary segments.
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_0d.csv` — triple points (including the four corners of the Ni(gly)₂ stability window).
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` — full per-cell speciation.
- `L1_call_01/l1_report.md` — full pipeline report.
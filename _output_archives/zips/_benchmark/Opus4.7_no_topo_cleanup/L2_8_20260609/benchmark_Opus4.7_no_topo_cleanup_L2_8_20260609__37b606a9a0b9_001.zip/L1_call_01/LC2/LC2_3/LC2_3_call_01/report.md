# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    98.53
- elapsed_s (total):  98.54
- llm_iterations:     35
- llm_tool_calls:     26

- n_groups:           22
- n_multi_groups:     9
- n_singletons:       13
- n_decisions:        22
- n_dropped:          12
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate: identical aqueous Cu+ cation; prefer SRD-46 over Atlas. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicates: identical Cu2+ aqueous monomer; keep SRD-46 version per preference. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear hydroxo-copper species differ in nuclearity and charge; both retained. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+; SRD-46 preferred over Atlas at identical mu. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate — same mononuclear ZnOH+ aqueous species; keep SRD-46 per Rule 1. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are notational duplicates of the same aqueous Zn(II) trihydroxo anion (charge -1, same core); keep SRD-46. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are notational variants of the same aqueous tetrahydroxozincate; prefer SRD-46. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; among the two Cu(OH)2 entries (same species), keep SRD-46. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs (alpha, beta, gamma, epsilon, amorphous), preferring SRD-46 epsilon over Atlas epsilon true duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid reference species with finite mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-2` | yes | Unique Cu(OH)2(aq) species with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-3` | yes | Unique HCuO2- species with valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-4` | yes | Unique CuO2 2- species with valid thermodynamics. |
| aqueous | `Cu$+2:1 L1:1` | yes | Unique Cu-EDTA complex with valid mu_aligned_kJ. |
| aqueous | `Cu$+2:3 H:-4` | yes | Unique polynuclear Cu hydroxide with valid thermodynamics. |
| aqueous | `L1:1` | yes | Free EDTA4- ligand with valid mu_aligned_kJ. |
| aqueous | `L1:1 H:1` | yes | Protonated HEDTA3- with valid (reference zero) mu_aligned_kJ. |
| aqueous | `Zn$+2:1 H:-2` | yes | Unique Zn(OH)2(aq) species with valid thermodynamics. |
| aqueous | `Zn$+2:1 L1:1` | yes | Unique Zn-EDTA complex with valid mu_aligned_kJ. |
| solid | `Cu$+0:1` | yes | Metallic Cu phase with valid mu_aligned_kJ. |
| solid | `Cu$+1:1 H:-1` | yes | Cu2O cuprite phase with valid thermodynamics. |
| solid | `Zn$+0:1` | yes | Metallic Zn phase with valid mu_aligned_kJ. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate: identical aqueous Cu+ cation; prefer SRD-46 over Atlas.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicates: identical Cu2+ aqueous monomer; keep SRD-46 version per preference.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+; SRD-46 preferred over Atlas at identical mu.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate — same mononuclear ZnOH+ aqueous species; keep SRD-46 per Rule 1.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are notational duplicates of the same aqueous Zn(II) trihydroxo anion (charge -1, same core); keep SRD-46.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are notational variants of the same aqueous tetrahydroxozincate; prefer SRD-46.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; among the two Cu(OH)2 entries (same species), keep SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; among the two Cu(OH)2 entries (same species), keep SRD-46.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs (alpha, beta, gamma, epsilon, amorphous), preferring SRD-46 epsilon over Atlas epsilon true duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs (alpha, beta, gamma, epsilon, amorphous), preferring SRD-46 epsilon over Atlas epsilon true duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs (alpha, beta, gamma, epsilon, amorphous), preferring SRD-46 epsilon over Atlas epsilon true duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs (alpha, beta, gamma, epsilon, amorphous), preferring SRD-46 epsilon over Atlas epsilon true duplicate.) |

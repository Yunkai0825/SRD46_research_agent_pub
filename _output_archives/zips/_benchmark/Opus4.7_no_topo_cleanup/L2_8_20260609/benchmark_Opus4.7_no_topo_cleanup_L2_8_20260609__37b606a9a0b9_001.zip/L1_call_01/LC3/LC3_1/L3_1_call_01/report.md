# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.81
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Joint Cu/Zn/EDTA speciation at pH 6 with a small surrounding pH window — 1-D pH sweep.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
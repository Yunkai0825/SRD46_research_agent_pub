# L3_4 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 6.83
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 4.0,
    "max": 8.0,
    "n_points": 81
  }
]
```

## Grid: 81 cell(s) across 1 axis/axes
- calc_input_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_8_CuZn_shared_limiting_EDTA\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
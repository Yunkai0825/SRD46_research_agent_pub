[Purpose: Compute the joint speciation of a single beaker containing Cu(II), Zn(II), and EDTA at sub-stoichiometric ligand loading, and determine competitive EDTA partitioning between the two metals.]
[Tasks:
Model a single shared pot containing Cu(II) at 1 mM, Zn(II) at 1 mM, and EDTA at 1 mM (total ligand is only one equivalent for the two metals combined) at pH 6, 25 C, and ionic strength 0.1 m. Solve the full joint equilibrium so that Cu and Zn compete for the shared EDTA pool. Report the speciation fractions of Cu and Zn (free aqua ion vs EDTA-bound vs any hydroxo/other forms), the bound:free ratio for each metal, and identify which metal captures the EDTA. Sweep a small pH window around 6 if useful, but the key answer is at pH 6.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27492`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27492` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

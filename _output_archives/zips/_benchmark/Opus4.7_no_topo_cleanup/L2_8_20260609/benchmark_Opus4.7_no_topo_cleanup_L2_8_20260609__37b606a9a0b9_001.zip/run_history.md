# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='A single beaker holds 1 mM Cu(II), 1 mM Zn(II) and 1 mM EDTA together (sub-stoichiometric for the two metals combined) at pH 6, 25 C, I=0.1 m. Compute the joint speciation of this shared pot and deter' |
|   7.233 | L1_start | call=1; purpose='Compute the joint speciation of a single beaker containing Cu(II), Zn(II), and EDTA at sub-stoichiometric ligand loading, and determine competitive EDTA partitioning between the two metals.' |
| 413.723 | L1_end | call=1; elapsed_s=406.5; ran_ok=True; attempts=1 |
| 429.898 | L0_end | elapsed_s=429.8886671066284; iterations=2; timed_out=False |

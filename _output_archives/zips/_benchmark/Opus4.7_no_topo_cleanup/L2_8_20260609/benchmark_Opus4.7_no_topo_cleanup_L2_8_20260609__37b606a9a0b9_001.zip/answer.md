## Answer

In the shared 1 mM Cu²⁺ / 1 mM Zn²⁺ / 1 mM EDTA beaker at pH 6, **Cu(II) wins the single equivalent of EDTA almost outright**. About **93 % of the EDTA inventory sits on Cu as [Cu(EDTA)]²⁻**, leaving only **~7 % on Zn as [Zn(EDTA)]²⁻**. Consequently:

- **Cu — bound : free ≈ 0.932 : 0.067 ≈ 14 : 1** (≈0.93 mM chelated, ≈0.07 mM free Cu²⁺)
- **Zn — bound : free ≈ 0.068 : 0.932 ≈ 1 : 14** (≈0.07 mM chelated, ≈0.93 mM free Zn²⁺)

**Chemical reason.** Both metals form 1:1 [M(EDTA)]²⁻ chelates, but the SRD-46 stability constants differ by roughly two log units (log K ≈ 18.8 for Cu–EDTA vs ≈ 16.5 for Zn–EDTA). The exchange equilibrium

  Cu²⁺ + [Zn(EDTA)]²⁻ ⇌ [Cu(EDTA)]²⁻ + Zn²⁺,  K ≈ 10^2.3 ≈ 200

drives EDTA off Zn and onto Cu until Cu effectively runs out of free ligand. The reason the residual Zn–EDTA fraction is ~7 % (not <1 %) is precisely that Cu is *ligand-limited*: once Cu has consumed ~0.93 mM of the 1 mM EDTA pool, the remaining 0.07 mM equilibrates with Zn — exactly mirroring the ~7 % free-Cu leakage required by mass action. The partitioning is essentially pH-flat over pH 4–8 because in this window EDTA protonation and metal hydroxide corrections are small, so the conditional selectivity equals the thermodynamic selectivity. No Cu(OH)₂(s) forms — EDTA keeps Cu soluble.

**Practical implication.** At sub-stoichiometric loading EDTA acts as a **selective Cu masking agent**: it sequesters Cu nearly quantitatively and leaves Zn essentially untouched as the free aqua ion. To chelate both metals one would need ≥2 equivalents of EDTA, or a competing Cu-selective ligand to free EDTA for Zn.

## Evidence
- Cu envelope (pH ≈ 4–8, representative of pH 6): `Cu²⁺` ≈ 0.0675, `[Cu(EDTA)]²⁻` ≈ 0.9324, `Cu(OH)₂(s)` = 0.000.
- Zn envelope: `Zn²⁺` ≈ 0.9324, `[Zn(EDTA)]²⁻` ≈ 0.0676.
- EDTA (ligand) envelope: ~93.2 % bound to Cu as [Cu(EDTA)]²⁻, ~6.8 % bound to Zn as [Zn(EDTA)]²⁻; negligible free/protonated EDTA.
- Mass balance check: 0.932 mM (Cu·EDTA) + 0.068 mM (Zn·EDTA) ≈ 1.00 mM total EDTA ✓.
- Selectivity driver: Δlog K(Cu–EDTA − Zn–EDTA) ≈ 2.3 ⇒ exchange K ≈ 200.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_envelope_Cu$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_envelope_L1.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_frac_metal.csv`, `_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_frac_Cu.png`, `_frac_Zn.png`, `_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_EDTA_log_conc.csv` / `.png`
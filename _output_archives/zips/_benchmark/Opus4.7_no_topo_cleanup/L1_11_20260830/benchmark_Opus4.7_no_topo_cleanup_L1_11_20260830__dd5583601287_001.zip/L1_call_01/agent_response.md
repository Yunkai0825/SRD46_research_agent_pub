# L1 agent response

## Final answer (text emitted by the agent)

The joint two-dimensional Pourbaix diagram for the Cu(II)/Fe(III)/citrate/glycine/Cl⁻/NH₃ electrolyte has been computed successfully. Both element-projected verdicts, the topology and label-map artefacts, the full-speciation CSV, and the deterministic log K / E° reference table are available as staged evidence. The report captures how each metal partitions among aqueous complexes (Cu dominated by citrate hydroxo, glycinate, chloro and ammine complexes; Fe dominated by ferric citrate hydroxo species and Fe(OH)₃(s) in most of the oxic field, with excluded Fe₂O₃/FeOOH/Fe₃O₄/CuO respected), locates the principal region boundaries and triple points, and quotes the log K values the solver actually used from the LC2 free-energy card.

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

A fixed E/Eh value during a pH scan is a condition and remains a one-axis
`pH_sweep`. Treat E/Eh as a Pourbaix dimension only when it is independently
varied with pH or an E–pH predominance field is explicitly requested.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. Call
   `list_outputs` when you need to locate supporting files, then use the
   narrow inspection tools or `read_output_file` on artifacts that answer a
   claim the verdict does not resolve:
   * For a **pH-speciation sweep**, begin with the automatically supplied
     speciation verdict, then use
     component fraction-envelope CSVs, full fraction/concentration tables,
     and `*_state_metrics.csv` when additional sampled evidence is needed.
   * For a **Pourbaix or other predominance sweep**, begin with each
     automatically supplied per-element predominance verdict. It contains
     canonical IDs for connected regions, boundaries/equilibria, and junctions
     (or dimension-qualified N-D features). Use `inspect_verdict_section` for
     one persisted report section and `inspect_topology_feature` for exactly
     one canonical ID. Never request or quote a raw topology JSON dump. Use the
     integer label-map/cell-table CSV for additional classified-grid evidence
     and the full-speciation CSV for concentrations, solids, saturation
     indices, and convergence. If a species occupies disconnected regions,
     preserve their separate verdict IDs; never silently collapse them.
     Compact boundary geometry supports topology and approximate location, but
     exact cuts in the verdict come from the final classified label grid.
     Likewise, quote pKa, log K, or E values only from the automatically
     supplied thermodynamic-reference table or after opening the actual
     persisted card/artifact that contains them, not from general knowledge.
     The table exposes the card's `log_beta` field; call it a pKa or another
     named constant only when the corresponding reaction/species definition
     justifies that name.
   * For either route, inspect and report convergence coverage before drawing
     chemical conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "")`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='') — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Build the joint two-dimensional E-pH Pourbaix diagram of a single aqueous pot containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, to inform electrodeposition electrolyte design.]
[Tasks:
Model a single solution containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and ionic strength 0.1 m. Build the joint two-dimensional Pourbaix (E vs pH) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, treating E and pH as independently varied axes. Prefer hydrated aqueous species (this is a water-rich electrodeposition electrolyte scenario) and explicitly exclude the solid oxides Fe2O3, CuO, FeOOH, and Fe3O4 from the model. Report how Cu and Fe partition among aqueous complexes (with citrate, glycine, chloride, ammonia, hydroxide) and any remaining solids/metals across the field, and describe the principal region boundaries and triple-point junctions using the equilibrium constants (log K) and standard potentials that the solver actually used. Provide the region catalogue (labels, areas, boundaries), the topology JSON, the label map, and the full-speciation table so partitioning and boundary chemistry can be read off directly.
]

## Assistant
<summary>Running the joint 2D Pourbaix pipeline for Cu(II)/Fe(III) with citrate/glycine/Cl/NH3.</summary>
<tool_call>run_analysis_pipeline(notes='Cu-Fe-citrate-glycine-Cl-NH…')</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pourbaix_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 11,
  "output_files": [
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.json",
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.json",
    "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv"
  ],
  "elapsed_s": 20164.2,
  "default_verdict_count": 2,
  "default_verdict_paths": [
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]3[L1]].[z+0] | [H3Citric acid] | aqueous | +12.9000 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-1] | [H2Citric acid]- | aqueous | +10.0000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-2] | [HCitric acid]2- | aqueous | +5.6500 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-3] | [Citric acid] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L2]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z-1] | [Glycine] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L3]]:+1 | SRD-46 | true |
| [L3].[z+0] | [Ammonia] | aqueous | +0.0000 | [L3]:+1 | SRD-46 | true |
| [L4].[z-1] | [Chloride ion] | aqueous | +0.0000 | [L4]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1].[L2]2.[z-1] | [Cu(Glyc)2]- | aqueous | +10.1000 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+1].[L3]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+1]2.[L4]4.[z-2] | [Cu2(Chlo)4]2- | aqueous | +13.0000 | [Cu$+1]:+2, [L4]:+4 | SRD-46 | true |
| [Cu$+1].[L4]2.[z-1] | [Cu(Chlo)2]- | aqueous | +6.0600 | [Cu$+1]:+1, [L4]:+2 | SRD-46 | true |
| [Cu$+1].[L4]3.[z-2] | [Cu(Chlo)3]2- | aqueous | +5.3900 | [Cu$+1]:+1, [L4]:+3 | SRD-46 | true |
| [Cu$+1].[L4].[z+0] | [Cu(Chlo)] | aqueous | +3.1000 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(Citr)H] | aqueous | +9.2600 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | aqueous | +14.5000 | [Cu$+2]:+2, [L1]:+2 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | aqueous | +4.8600 | [Cu$+2]:+2, [[H]-1[L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | aqueous | +11.2000 | [Cu$+2]:+2, [[H]-1[L1]]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | aqueous | +6.3400 | [Cu$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L3]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Cu$+2].[L3]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Cu$+2].[L3]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+2].[L3].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Cu$+2].[L4].[z+1] | [Cu(Chlo)]+ | aqueous | -0.2000 | [Cu$+2]:+1, [L4]:+1 | SRD-46 | true |
| [Fe$+2].[z+2] | [Fe]2+ | aqueous | +0.0000 | [Fe$+2]:+1 | SRD-46 | true |
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | aqueous | -9.8000 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | aqueous | -35.5000 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | aqueous | -29.0000 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | aqueous | -46.0000 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+2].[[H]2[L1]].[z+1] | [Fe(Citr)H2]+ | aqueous | +11.1000 | [Fe$+2]:+1, [[H]2[L1]]:+1 | SRD-46 | true |
| [Fe$+2].[[H][L1]].[z+0] | [Fe(Citr)H] | aqueous | +8.5500 | [Fe$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+2].[L1]2.[H].[z-3] | [Fe(Citr)2H]3- | aqueous | +11.7400 | [Fe$+2]:+1, [L1]:+2, [H]:+1 | SRD-46 | true |
| [Fe$+2].[L1].[z-1] | [Fe(Citr)]- | aqueous | +4.5600 | [Fe$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | aqueous | -5.4000 | [Fe$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Fe$+2].[L2].[z+1] | [Fe(Glyc)]+ | aqueous | +4.3100 | [Fe$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+2].[L2]2.[z+0] | [Fe(Glyc)2] | aqueous | +7.6500 | [Fe$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Fe$+2].[L2]3.[z-1] | [Fe(Glyc)3]- | aqueous | +8.8700 | [Fe$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Fe$+2].[L3]4.[z+2] | [Fe(Ammo)4]2+ | aqueous | +2.7500 | [Fe$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Fe$+2].[L3]3.[z+2] | [Fe(Ammo)3]2+ | aqueous | +2.6800 | [Fe$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Fe$+2].[L3]2.[z+2] | [Fe(Ammo)2]2+ | aqueous | +2.2500 | [Fe$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Fe$+2].[L3].[z+2] | [Fe(Ammo)]2+ | aqueous | +1.4000 | [Fe$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Fe$+2].[L4].[z+1] | [Fe(Chlo)]+ | aqueous | -0.2000 | [Fe$+2]:+1, [L4]:+1 | SRD-46 | true |
| [Fe$+3].[z+3] | [Fe]3+ | aqueous | +0.0000 | [Fe$+3]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | aqueous | -2.7300 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | aqueous | -2.8600 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | aqueous | -6.1500 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | aqueous | -6.3000 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | aqueous | -21.6000 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+1] | [Fe(Citr)H]+ | aqueous | +12.3500 | [Fe$+3]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+3].[L1].[z+0] | [Fe(Citr)] | aqueous | +11.1900 | [Fe$+3]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[L1].[z-1] | [Fe(Citr)(OH)]- | aqueous | +8.4900 | [Fe$+3]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[L1]2.[z-2] | [Fe2(Citr)2(OH)2]2- | aqueous | +21.2000 | [Fe$+3]:+2, [OH]:+2, [L1]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]]2.[z+3] | [Fe(Glyc)2H2]3+ | aqueous | +22.8400 | [Fe$+3]:+1, [[H][L2]]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+3] | [Fe(Glyc)H]3+ | aqueous | +11.3400 | [Fe$+3]:+1, [[H][L2]]:+1 | SRD-46 | true |
| [Fe$+3].[L2].[z+2] | [Fe(Glyc)]2+ | aqueous | -8.5700 | [Fe$+3]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+3].[L4]2.[z+1] | [Fe(Chlo)2]+ | aqueous | +2.1300 | [Fe$+3]:+1, [L4]:+2 | SRD-46 | true |
| [Fe$+3].[L4].[z+2] | [Fe(Chlo)]2+ | aqueous | +0.7800 | [Fe$+3]:+1, [L4]:+1 | SRD-46 | true |
| Fe$+6.OH8.z-2 | [FeO4]2- | aqueous | -0.0000 | Fe$+6:+1 H:-8 | Atlas | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+1].[L4].[z+0]_(s) | [Cu(Chloride ion)](s) | dissolution | +6.7300 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | dissolution | -13.5700 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+3].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | dissolution | -3.2000 | [Fe$+3]:+1, [OH]:+3 | SRD-46 | true |
| Fe$+0.z+0(s) | Fe | dissolution | -0.0000 | Fe$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain: pH [0, 14]; E_V [-1, 1.5]
- Coarse grid spacing: ΔpH=not reported; ΔE_V=not reported
- Final classified-grid spacing: ΔpH=0.0125; ΔE_V=0.003125
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO22-
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu(OH)2](s)
- Dms_6: [Cu2(Citr)2(OH)2]4-
- Dms_7: [Cu(Glyc)2]
- Dms_8: [Cu(Chlo)2]-
- Dms_9: [Cu2(Citr)2(OH)]3-
- Dms_10: Cu2+

## Topology stats
- 10 dominant-species labels
- 13 connected regions
- 26 pairwise boundary curves
- 14 internal junction features
- 10 junction features at a sweep limit
- Disconnected dominant species:
  -- [Cu(Glyc)2]: 2 separate regions [DmsReg_6, DmsReg_8]
  -- [Cu2(Citr)2(OH)2]4-: 2 separate regions [DmsReg_7, DmsReg_9]
  -- [Cu(Chlo)2]-: 2 separate regions [DmsReg_10, DmsReg_11]

## Example classified-grid cut along pH
- Fixed coordinates in domain order: [not reported, 0.2484375]
- Fixed sample indices in domain order: [None, 399]
- samples 0–334, pH [0.00625, 4.18125]: [Cu(Chlo)2]- (Dms_8)
- samples 335–605, pH [4.19375, 7.56875]: [Cu2(Citr)2(OH)2]4- (Dms_6)
  -- preceding label change is bracketed by adjacent samples [4.18125, 4.19375]
- samples 606–890, pH [7.58125, 11.13125]: [Cu(Glyc)2] (Dms_7)
  -- preceding label change is bracketed by adjacent samples [7.56875, 7.58125]
- samples 891–921, pH [11.14375, 11.51875]: [Cu2(Citr)2(OH)2]4- (Dms_6)
  -- preceding label change is bracketed by adjacent samples [11.13125, 11.14375]
- samples 922–1086, pH [11.53125, 13.58125]: [Cu(OH)2](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples [11.51875, 11.53125]
- samples 1087–1119, pH [13.59375, 13.99375]: CuO22- (Dms_3)
  -- preceding label change is bracketed by adjacent samples [13.58125, 13.59375]

## Example classified-grid cut along E_V
- Fixed coordinates in domain order: [6.99375, not reported]
- Fixed sample indices in domain order: [559, None]
- samples 0–335, E_V [-0.9984375, 0.0484375]: Cu (Dms_1)
- samples 336–799, E_V [0.0515625, 1.4984375]: [Cu2(Citr)2(OH)2]4- (Dms_6)
  -- preceding label change is bracketed by adjacent samples [0.0484375, 0.0515625]

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 13.577109
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_1
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_2
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_3
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_4
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_6 {[Cu(Glyc)2]} via DmsRegEq_6
    --- DmsReg_8 {[Cu(Glyc)2]} via DmsRegEq_7
    --- DmsReg_10 {[Cu(Chlo)2]-} via DmsRegEq_8
    --- DmsReg_11 {[Cu(Chlo)2]-} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_1, DmsRegEqJnc_4, DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_16]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.77921875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_1
    --- DmsReg_3 {CuO22-} via DmsRegEq_10
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_11
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_12
    --- DmsReg_7 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_6 {[Cu(Glyc)2]} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_17, DmsRegEqJnc_3, DmsRegEqJnc_8, DmsRegEqJnc_5]
- **DmsReg_3 {CuO22-}**
  -- Measure in the solver coordinate frame: 0.66796875
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_10
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_15
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_17, DmsRegEqJnc_18]
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.27671875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_2
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_11
    --- DmsReg_6 {[Cu(Glyc)2]} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_3]
- **DmsReg_5 {[Cu(OH)2](s)}**
  -- Measure in the solver coordinate frame: 3.1391016
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_3 {CuO22-} via DmsRegEq_15
    --- DmsReg_7 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_8, DmsRegEqJnc_18, DmsRegEqJnc_19]
- **DmsReg_6 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 5.2994922
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_6
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_14
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_16
    --- DmsReg_7 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_18
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_19
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_20, DmsRegEqJnc_21]
- **DmsReg_7 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.56640625
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_17
    --- DmsReg_6 {[Cu(Glyc)2]} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_19, DmsRegEqJnc_20]
- **DmsReg_8 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 0.00015625
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_7
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_20
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_6]
- **DmsReg_9 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 4.9450391
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_3
    --- DmsReg_1 {Cu} via DmsRegEq_4
    --- DmsReg_1 {Cu} via DmsRegEq_5
    --- DmsReg_6 {[Cu(Glyc)2]} via DmsRegEq_19
    --- DmsReg_8 {[Cu(Glyc)2]} via DmsRegEq_20
    --- DmsReg_10 {[Cu(Chlo)2]-} via DmsRegEq_21
    --- DmsReg_11 {[Cu(Chlo)2]-} via DmsRegEq_22
    --- DmsReg_12 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_23
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_21, DmsRegEqJnc_13, DmsRegEqJnc_22]
- **DmsReg_10 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 7.8125e-05
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_21
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12]
- **DmsReg_11 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 1.22875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_22
    --- DmsReg_12 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_24
    --- DmsReg_13 {Cu2+} via DmsRegEq_25
  -- Junction features: [DmsRegEqJnc_16, DmsRegEqJnc_11, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_23]
- **DmsReg_12 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.91535156
  -- Neighboring regions:
    --- DmsReg_9 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_23
    --- DmsReg_11 {[Cu(Chlo)2]-} via DmsRegEq_24
    --- DmsReg_13 {Cu2+} via DmsRegEq_26
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_22, DmsRegEqJnc_14, DmsRegEqJnc_24]
- **DmsReg_13 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.6046094
  -- Neighboring regions:
    --- DmsReg_11 {[Cu(Chlo)2]-} via DmsRegEq_25
    --- DmsReg_12 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_26
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_23, DmsRegEqJnc_24]

### boundary curves/equilibria
- **DmsRegEq_1: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, -0.35], [13.675, -0.3281], [13.6125, -0.3281], [13.4625, -0.3156], [13.4, -0.3156], [10.4625, -0.1406]]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 351, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 33, 38, 54, 59, 350], "t_params": [0.0, 0.0919, 0.1095, 0.152, 0.1697, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, -0.35], [13.675, -0.3281], [13.6125, -0.3281], [13.4625, -0.3156], [13.4, -0.3156], [10.4625, -0.1406]], "envelope_t": [0.0, 0.0919, 0.1095, 0.152, 0.1697, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, -0.35], [10.4625, -0.1406]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.4625, -0.1406], [9.9, -0.1344], [9.3125, -0.1125], [8.9375, -0.0875], [8.175, -0.0156], [7.775, 0.0156]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 266, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 47, 101, 139, 223, 265], "t_params": [0.0, 0.2089, 0.4271, 0.5667, 0.851, 1.0], "envelope_n": 6, "envelope_pts": [[10.4625, -0.1406], [9.9, -0.1344], [9.3125, -0.1125], [8.9375, -0.0875], [8.175, -0.0156], [7.775, 0.0156]], "envelope_t": [0.0, 0.2089, 0.4271, 0.5667, 0.851, 1.0], "adaptive_n": 3, "adaptive_pts": [[10.4625, -0.1406], [9.3125, -0.1125], [7.775, 0.0156]], "adaptive_t": [0.0, 0.4271, 1.0]}
- **DmsRegEq_3: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.3625, 0.0375], [7.375, 0.0375], [7.3875, 0.0375]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 3, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 1, 2], "t_params": [0.0, 0.5, 1.0], "envelope_n": 6, "envelope_pts": [[7.3625, 0.0375], [7.375, 0.0375], [7.3875, 0.0375]], "envelope_t": [0.0, 0.5, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.3625, 0.0375], [7.3875, 0.0375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.3125, 0.0406], [6.725, 0.0594], [6.725, 0.0625], [6.525, 0.0656], [6.525, 0.0688], [6.0875, 0.0781]]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 111, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 53, 54, 71, 72, 110], "t_params": [0.0, 0.4772, 0.4798, 0.6422, 0.6447, 1.0], "envelope_n": 6, "envelope_pts": [[7.3125, 0.0406], [6.725, 0.0594], [6.725, 0.0625], [6.525, 0.0656], [6.525, 0.0688], [6.0875, 0.0781]], "envelope_t": [0.0, 0.4772, 0.4798, 0.6422, 0.6447, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.3125, 0.0406], [6.0875, 0.0781]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.0125, 0.0813], [6.025, 0.0813], [6.0375, 0.0813], [6.05, 0.0813], [6.0625, 0.0813]]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 5, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3, 4], "t_params": [0.0, 0.25, 0.5, 0.75, 1.0], "envelope_n": 6, "envelope_pts": [[6.0125, 0.0813], [6.025, 0.0813], [6.0375, 0.0813], [6.05, 0.0813], [6.0625, 0.0813]], "envelope_t": [0.0, 0.25, 0.5, 0.75, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.0125, 0.0813], [6.0625, 0.0813]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.775, 0.0156], [7.5125, 0.0313], [7.45, 0.0313], [7.45, 0.0344], [7.3875, 0.0344], [7.3875, 0.0375]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 39, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 26, 31, 32, 37, 38], "t_params": [0.0, 0.6671, 0.8256, 0.8335, 0.9921, 1.0], "envelope_n": 6, "envelope_pts": [[7.775, 0.0156], [7.5125, 0.0313], [7.45, 0.0313], [7.45, 0.0344], [7.3875, 0.0344], [7.3875, 0.0375]], "envelope_t": [0.0, 0.6671, 0.8256, 0.8335, 0.9921, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.775, 0.0156], [7.3875, 0.0375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.3625, 0.0375], [7.35, 0.0375], [7.3375, 0.0375], [7.325, 0.0375], [7.3125, 0.0375], [7.3125, 0.0406]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 6, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3, 4, 5], "t_params": [0.0, 0.2353, 0.4706, 0.7059, 0.9412, 1.0], "envelope_n": 6, "envelope_pts": [[7.3625, 0.0375], [7.35, 0.0375], [7.3375, 0.0375], [7.325, 0.0375], [7.3125, 0.0375], [7.3125, 0.0406]], "envelope_t": [0.0, 0.2353, 0.4706, 0.7059, 0.9412, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.3625, 0.0375], [7.3125, 0.0406]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.0875, 0.0781], [6.075, 0.0781], [6.0625, 0.0781], [6.0625, 0.0813]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 4, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3], "t_params": [0.0, 0.4444, 0.8889, 1.0], "envelope_n": 6, "envelope_pts": [[6.0875, 0.0781], [6.075, 0.0781], [6.0625, 0.0781], [6.0625, 0.0813]], "envelope_t": [0.0, 0.4444, 0.8889, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.0875, 0.0781], [6.0625, 0.0813]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.0125, 0.0813], [5.4875, 0.0906], [5.4875, 0.0938], [5.2125, 0.0938], [5.2125, 0.0969], [0.0, 0.0969]]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 487, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 45, 46, 68, 69, 486], "t_params": [0.0, 0.0872, 0.0878, 0.1334, 0.134, 1.0], "envelope_n": 6, "envelope_pts": [[6.0125, 0.0813], [5.4875, 0.0906], [5.4875, 0.0938], [5.2125, 0.0938], [5.2125, 0.0969], [0.0, 0.0969]], "envelope_t": [0.0, 0.0872, 0.0878, 0.1334, 0.134, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.0125, 0.0813], [0.0, 0.0969]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: [(Cu2O)0.5](s) | CuO22-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, -0.1531], [13.975, -0.1531], [13.95, -0.1437], [13.925, -0.1437], [13.9125, -0.1375], [13.5875, -0.0844]]
  -- Boundary/junction features: [DmsRegEqJnc_17, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 56, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 2, 7, 9, 12, 55], "t_params": [0.0, 0.0595, 0.1231, 0.1826, 0.2159, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, -0.1531], [13.975, -0.1531], [13.95, -0.1437], [13.925, -0.1437], [13.9125, -0.1375], [13.5875, -0.0844]], "envelope_t": [0.0, 0.0595, 0.1231, 0.1826, 0.2159, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, -0.1531], [13.5875, -0.0844]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.4625, -0.1406], [10.475, -0.0812], [10.5125, -0.05], [10.6375, -0.0156], [10.8125, 0.0031], [10.8125, 0.0063]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 76, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 20, 33, 54, 74, 75], "t_params": [0.0, 0.1451, 0.2618, 0.5717, 0.9925, 1.0], "envelope_n": 6, "envelope_pts": [[10.4625, -0.1406], [10.475, -0.0812], [10.5125, -0.05], [10.6375, -0.0156], [10.8125, 0.0031], [10.8125, 0.0063]], "envelope_t": [0.0, 0.1451, 0.2618, 0.5717, 0.9925, 1.0], "adaptive_n": 3, "adaptive_pts": [[10.4625, -0.1406], [10.5125, -0.05], [10.8125, 0.0063]], "adaptive_t": [0.0, 0.2532, 1.0]}
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[13.5875, -0.0844], [13.375, -0.0687], [13.3125, -0.0687], [13.1625, -0.0562], [13.1, -0.0562], [11.55, 0.0375]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 203, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 22, 27, 43, 48, 202], "t_params": [0.0, 0.1044, 0.135, 0.2087, 0.2393, 1.0], "envelope_n": 6, "envelope_pts": [[13.5875, -0.0844], [13.375, -0.0687], [13.3125, -0.0687], [13.1625, -0.0562], [13.1, -0.0562], [11.55, 0.0375]], "envelope_t": [0.0, 0.1044, 0.135, 0.2087, 0.2393, 1.0], "adaptive_n": 2, "adaptive_pts": [[13.5875, -0.0844], [11.55, 0.0375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.3375, 0.0344], [11.35, 0.0344], [11.3625, 0.0344], [11.4625, 0.0344], [11.4625, 0.0375], [11.55, 0.0375]]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 19, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 10, 11, 18], "t_params": [0.0, 0.058, 0.1159, 0.5797, 0.5942, 1.0], "envelope_n": 6, "envelope_pts": [[11.3375, 0.0344], [11.35, 0.0344], [11.3625, 0.0344], [11.4625, 0.0344], [11.4625, 0.0375], [11.55, 0.0375]], "envelope_t": [0.0, 0.058, 0.1159, 0.5797, 0.5942, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.3375, 0.0344], [11.55, 0.0375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: [(Cu2O)0.5](s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.8125, 0.0063], [11.025, 0.0219], [11.075, 0.0219], [11.075, 0.025], [11.3375, 0.0313], [11.3375, 0.0344]]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 52, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 22, 26, 27, 50, 51], "t_params": [0.0, 0.4006, 0.4946, 0.5005, 0.9941, 1.0], "envelope_n": 6, "envelope_pts": [[10.8125, 0.0063], [11.025, 0.0219], [11.075, 0.0219], [11.075, 0.025], [11.3375, 0.0313], [11.3375, 0.0344]], "envelope_t": [0.0, 0.4006, 0.4946, 0.5005, 0.9941, 1.0], "adaptive_n": 2, "adaptive_pts": [[10.8125, 0.0063], [11.3375, 0.0344]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_15: CuO22- | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[13.5875, -0.0844], [13.5875, -0.0812], [13.5875, 0.5469], [13.5875, 0.5781], [13.5875, 1.1969], [13.5875, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_18]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 508, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 202, 212, 410, 507], "t_params": [0.0, 0.002, 0.3984, 0.4181, 0.8087, 1.0], "envelope_n": 6, "envelope_pts": [[13.5875, -0.0844], [13.5875, -0.0812], [13.5875, 0.5469], [13.5875, 0.5781], [13.5875, 1.1969], [13.5875, 1.5]], "envelope_t": [0.0, 0.002, 0.3984, 0.4181, 0.8087, 1.0], "adaptive_n": 2, "adaptive_pts": [[13.5875, -0.0844], [13.5875, 1.5]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [Cu(Ammo)2]+ | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.8125, 0.0063], [8.625, 0.0156], [8.625, 0.0188], [7.875, 0.0188], [7.875, 0.0156], [7.775, 0.0156]]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 249, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 178, 179, 239, 240, 248], "t_params": [0.0, 0.7187, 0.7197, 0.9661, 0.9671, 1.0], "envelope_n": 6, "envelope_pts": [[10.8125, 0.0063], [8.625, 0.0156], [8.625, 0.0188], [7.875, 0.0188], [7.875, 0.0156], [7.775, 0.0156]], "envelope_t": [0.0, 0.7187, 0.7197, 0.9661, 0.9671, 1.0], "adaptive_n": 2, "adaptive_pts": [[10.8125, 0.0063], [7.775, 0.0156]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_17: [Cu(OH)2](s) | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.55, 0.0375], [11.55, 0.0406], [11.5375, 0.0406], [11.5375, 0.0688], [11.525, 0.0688], [11.525, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_19]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 471, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 11, 12, 470], "t_params": [0.0, 0.0021, 0.0105, 0.0294, 0.0378, 1.0], "envelope_n": 6, "envelope_pts": [[11.55, 0.0375], [11.55, 0.0406], [11.5375, 0.0406], [11.5375, 0.0688], [11.525, 0.0688], [11.525, 1.5]], "envelope_t": [0.0, 0.0021, 0.0105, 0.0294, 0.0378, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.55, 0.0375], [11.525, 1.5]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.3375, 0.0344], [11.325, 0.0375], [11.2625, 0.0375], [11.1625, 0.0438], [11.1375, 0.0781], [11.1375, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_20]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 486, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 2, 7, 17, 30, 485], "t_params": [0.0, 0.0079, 0.046, 0.1071, 0.133, 1.0], "envelope_n": 6, "envelope_pts": [[11.3375, 0.0344], [11.325, 0.0375], [11.2625, 0.0375], [11.1625, 0.0438], [11.1375, 0.0781], [11.1375, 1.5]], "envelope_t": [0.0, 0.0079, 0.046, 0.1071, 0.133, 1.0], "adaptive_n": 3, "adaptive_pts": [[11.3375, 0.0344], [11.1375, 0.0781], [11.1375, 1.5]], "adaptive_t": [0.0, 0.1259, 1.0]}
- **DmsRegEq_19: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.3875, 0.0375], [7.45, 0.0375], [7.45, 0.0406], [7.525, 0.0438], [7.575, 0.0938], [7.575, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_21]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 484, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 5, 6, 13, 33, 483], "t_params": [0.0, 0.0386, 0.0406, 0.087, 0.1307, 1.0], "envelope_n": 6, "envelope_pts": [[7.3875, 0.0375], [7.45, 0.0375], [7.45, 0.0406], [7.525, 0.0438], [7.575, 0.0938], [7.575, 1.5]], "envelope_t": [0.0, 0.0386, 0.0406, 0.087, 0.1307, 1.0], "adaptive_n": 3, "adaptive_pts": [[7.3875, 0.0375], [7.575, 0.0938], [7.575, 1.5]], "adaptive_t": [0.0, 0.1222, 1.0]}
- **DmsRegEq_20: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.3625, 0.0375], [7.3625, 0.0406], [7.35, 0.0406], [7.3375, 0.0406], [7.325, 0.0406], [7.3125, 0.0406]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 6, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3, 4, 5], "t_params": [0.0, 0.0588, 0.2941, 0.5294, 0.7647, 1.0], "envelope_n": 6, "envelope_pts": [[7.3625, 0.0375], [7.3625, 0.0406], [7.35, 0.0406], [7.3375, 0.0406], [7.325, 0.0406], [7.3125, 0.0406]], "envelope_t": [0.0, 0.0588, 0.2941, 0.5294, 0.7647, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.3625, 0.0375], [7.3125, 0.0406]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_21: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.0875, 0.0781], [6.0875, 0.0813], [6.075, 0.0813], [6.0625, 0.0813]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 4, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3], "t_params": [0.0, 0.1111, 0.5556, 1.0], "envelope_n": 6, "envelope_pts": [[6.0875, 0.0781], [6.0875, 0.0813], [6.075, 0.0813], [6.0625, 0.0813]], "envelope_t": [0.0, 0.1111, 0.5556, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.0875, 0.0781], [6.0625, 0.0813]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_22: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.0125, 0.0813], [5.6375, 0.1], [4.9875, 0.1531], [4.6625, 0.1906], [4.625, 0.1906], [4.0, 0.275]]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 224, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 36, 105, 143, 146, 223], "t_params": [0.0, 0.1856, 0.508, 0.6697, 0.6882, 1.0], "envelope_n": 6, "envelope_pts": [[6.0125, 0.0813], [5.6375, 0.1], [4.9875, 0.1531], [4.6625, 0.1906], [4.625, 0.1906], [4.0, 0.275]], "envelope_t": [0.0, 0.1856, 0.508, 0.6697, 0.6882, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.0125, 0.0813], [4.0, 0.275]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_23: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_12]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[4.0, 0.275], [4.0, 0.2781], [4.0, 0.2812], [4.0, 0.7844], [4.0, 0.9094], [4.0, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_22]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 393, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 163, 203, 392], "t_params": [0.0, 0.0026, 0.0051, 0.4158, 0.5179, 1.0], "envelope_n": 6, "envelope_pts": [[4.0, 0.275], [4.0, 0.2781], [4.0, 0.2812], [4.0, 0.7844], [4.0, 0.9094], [4.0, 1.5]], "envelope_t": [0.0, 0.0026, 0.0051, 0.4158, 0.5179, 1.0], "adaptive_n": 2, "adaptive_pts": [[4.0, 0.275], [4.0, 1.5]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_24: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_11, DmsReg_12]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[4.0, 0.275], [3.5875, 0.3219], [3.575, 0.3281], [3.375, 0.3531], [3.3625, 0.3594], [3.225, 0.3813]]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 97, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 48, 51, 75, 78, 96], "t_params": [0.0, 0.5296, 0.5474, 0.8046, 0.8224, 1.0], "envelope_n": 6, "envelope_pts": [[4.0, 0.275], [3.5875, 0.3219], [3.575, 0.3281], [3.375, 0.3531], [3.3625, 0.3594], [3.225, 0.3813]], "envelope_t": [0.0, 0.5296, 0.5474, 0.8046, 0.8224, 1.0], "adaptive_n": 2, "adaptive_pts": [[4.0, 0.275], [3.225, 0.3813]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_25: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_11, DmsReg_13]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[0.0, 0.3813], [1.6625, 0.3813], [1.9375, 0.3813], [2.8625, 0.3813], [2.9625, 0.3813], [3.225, 0.3813]]
  -- Boundary/junction features: [DmsRegEqJnc_23, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 259, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 133, 155, 229, 237, 258], "t_params": [0.0, 0.5155, 0.6008, 0.8876, 0.9186, 1.0], "envelope_n": 6, "envelope_pts": [[0.0, 0.3813], [1.6625, 0.3813], [1.9375, 0.3813], [2.8625, 0.3813], [2.9625, 0.3813], [3.225, 0.3813]], "envelope_t": [0.0, 0.5155, 0.6008, 0.8876, 0.9186, 1.0], "adaptive_n": 2, "adaptive_pts": [[0.0, 0.3813], [3.225, 0.3813]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_26: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_12, DmsReg_13]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[3.225, 0.3813], [3.225, 1.3531], [3.2125, 1.3531], [3.2125, 1.3781], [3.2, 1.3781], [3.2, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_24]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 361, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 311, 312, 320, 321, 360], "t_params": [0.0, 0.8497, 0.8607, 0.8825, 0.8934, 1.0], "envelope_n": 6, "envelope_pts": [[3.225, 0.3813], [3.225, 1.3531], [3.2125, 1.3531], [3.2125, 1.3781], [3.2, 1.3781], [3.2, 1.5]], "envelope_t": [0.0, 0.8497, 0.8607, 0.8825, 0.8934, 1.0], "adaptive_n": 2, "adaptive_pts": [[3.225, 0.3813], [3.2, 1.5]], "adaptive_t": [0.0, 1.0]}

### junction features
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 10.4625, "E_V": -0.1406}
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_12, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 13.5875, "E_V": -0.0844}
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_11, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 10.8125, "E_V": 0.0063}
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_6, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.775, "E_V": 0.0156}
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_7, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_13, DmsRegEq_14, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.3375, "E_V": 0.0344}
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_7, DmsRegEq_20]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.3625, "E_V": 0.0375}
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_19]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.3875, "E_V": 0.0375}
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(OH)2](s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_12, DmsRegEq_13, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.55, "E_V": 0.0375}
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_7, DmsRegEq_20]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.3125, "E_V": 0.0406}
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_8, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.0875, "E_V": 0.0781}
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_9, DmsRegEq_22]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.0125, "E_V": 0.0813}
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_8, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.0625, "E_V": 0.0813}
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_9, DmsReg_11, DmsReg_12]
  -- Connected boundary manifolds: [DmsRegEq_22, DmsRegEq_23, DmsRegEq_24]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 4.0, "E_V": 0.275}
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_11, DmsReg_12, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_24, DmsRegEq_25, DmsRegEq_26]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 3.225, "E_V": 0.3813}
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.35}
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 0.0, "E_V": 0.0969}
- **DmsRegEqJnc_17** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.1531}
- **DmsRegEqJnc_18** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 13.5875, "E_V": 1.5}
- **DmsRegEqJnc_19** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 11.525, "E_V": 1.5}
- **DmsRegEqJnc_20** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 11.1375, "E_V": 1.5}
- **DmsRegEqJnc_21** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_19]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 7.575, "E_V": 1.5}
- **DmsRegEqJnc_22** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_9, DmsReg_12]
  -- Connected boundary manifolds: [DmsRegEq_23]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 4.0, "E_V": 1.5}
- **DmsRegEqJnc_23** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_11, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_25]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 0.0, "E_V": 0.3813}
- **DmsRegEqJnc_24** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_12, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_26]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 3.2, "E_V": 1.5}

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), [Cu(OH)2](s), Cu]
  -- excluded: [Cu2O, CuO(s), CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain: pH [0, 14]; E_V [-1, 1.5]
- Coarse grid spacing: ΔpH=not reported; ΔE_V=not reported
- Final classified-grid spacing: ΔpH=0.0125; ΔE_V=0.003125
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: [Fe(OH)2](s)
- Dms_4: [Fe2(Citr)2(OH)2]4-
- Dms_5: Fe2+
- Dms_6: [Fe(Citr)]-
- Dms_7: [Fe(OH)3](s)
- Dms_8: [Fe2(Citr)2(OH)2]2-
- Dms_9: FeO42-
- Dms_10: [Fe(Citr)]
- Dms_11: Fe3+

## Topology stats
- 11 dominant-species labels
- 13 connected regions
- 29 pairwise boundary curves
- 17 internal junction features
- 7 junction features at a sweep limit
- Disconnected dominant species:
  -- [Fe(Citr)]-: 3 separate regions [DmsReg_5, DmsReg_6, DmsReg_9]

## Example classified-grid cut along pH
- Fixed coordinates in domain order: [not reported, 0.2484375]
- Fixed sample indices in domain order: [None, 399]
- samples 0–324, pH [0.00625, 4.05625]: Fe2+ (Dms_5)
- samples 325–375, pH [4.06875, 4.69375]: [Fe(Citr)]- (Dms_6)
  -- preceding label change is bracketed by adjacent samples [4.05625, 4.06875]
- samples 376–503, pH [4.70625, 6.29375]: [Fe2(Citr)2(OH)2]2- (Dms_8)
  -- preceding label change is bracketed by adjacent samples [4.69375, 4.70625]
- samples 504–1103, pH [6.30625, 13.79375]: [Fe(OH)3](s) (Dms_7)
  -- preceding label change is bracketed by adjacent samples [6.29375, 6.30625]
- samples 1104–1119, pH [13.80625, 13.99375]: FeO42- (Dms_9)
  -- preceding label change is bracketed by adjacent samples [13.79375, 13.80625]

## Example classified-grid cut along E_V
- Fixed coordinates in domain order: [6.99375, not reported]
- Fixed sample indices in domain order: [559, None]
- samples 0–135, E_V [-0.9984375, -0.5765625]: Fe (Dms_1)
- samples 136–328, E_V [-0.5734375, 0.0265625]: [Fe(Citr)]- (Dms_6)
  -- preceding label change is bracketed by adjacent samples [-0.5765625, -0.5734375]
- samples 329–613, E_V [0.0296875, 0.9171875]: [Fe(OH)3](s) (Dms_7)
  -- preceding label change is bracketed by adjacent samples [0.0265625, 0.0296875]
- samples 614–799, E_V [0.9203125, 1.4984375]: FeO42- (Dms_9)
  -- preceding label change is bracketed by adjacent samples [0.9171875, 0.9203125]

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 5.2927734
  -- Neighboring regions:
    --- DmsReg_2 {[Fe(OH)3]-} via DmsRegEq_1
    --- DmsReg_3 {[Fe(OH)2](s)} via DmsRegEq_2
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_3
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_4
    --- DmsReg_7 {Fe2+} via DmsRegEq_5
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_18, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_19, DmsRegEqJnc_6]
- **DmsReg_2 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.64332031
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_1
    --- DmsReg_3 {[Fe(OH)2](s)} via DmsRegEq_8
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_18, DmsRegEqJnc_1, DmsRegEqJnc_7, DmsRegEqJnc_20]
- **DmsReg_3 {[Fe(OH)2](s)}**
  -- Measure in the solver coordinate frame: 0.30617188
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_2
    --- DmsReg_2 {[Fe(OH)3]-} via DmsRegEq_8
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_10
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1, DmsRegEqJnc_7, DmsRegEqJnc_8]
- **DmsReg_4 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.85136719
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_3
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_3 {[Fe(OH)2](s)} via DmsRegEq_10
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_12
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_13
    --- DmsReg_9 {[Fe(Citr)]-} via DmsRegEq_14
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_15
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_8, DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_11]
- **DmsReg_5 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 3.90625e-05
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
- **DmsReg_6 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.7358203
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_7 {Fe2+} via DmsRegEq_17
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_22
    --- DmsReg_10 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_23
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_13, DmsRegEqJnc_12]
- **DmsReg_7 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.6530469
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_17
    --- DmsReg_10 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_18
    --- DmsReg_12 {[Fe(Citr)]} via DmsRegEq_19
    --- DmsReg_13 {Fe3+} via DmsRegEq_20
  -- Junction features: [DmsRegEqJnc_19, DmsRegEqJnc_6, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_15, DmsRegEqJnc_21]
- **DmsReg_8 {[Fe(OH)3](s)}**
  -- Measure in the solver coordinate frame: 7.1630078
  -- Neighboring regions:
    --- DmsReg_2 {[Fe(OH)3]-} via DmsRegEq_9
    --- DmsReg_3 {[Fe(OH)2](s)} via DmsRegEq_11
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_15
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_16
    --- DmsReg_9 {[Fe(Citr)]-} via DmsRegEq_21
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_22
    --- DmsReg_10 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_24
    --- DmsReg_11 {FeO42-} via DmsRegEq_25
  -- Junction features: [DmsRegEqJnc_20, DmsRegEqJnc_7, DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_16, DmsRegEqJnc_22]
- **DmsReg_9 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 3.90625e-05
  -- Neighboring regions:
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_14
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_21
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11]
- **DmsReg_10 {[Fe2(Citr)2(OH)2]2-}**
  -- Measure in the solver coordinate frame: 4.0710547
  -- Neighboring regions:
    --- DmsReg_7 {Fe2+} via DmsRegEq_18
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_23
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_24
    --- DmsReg_11 {FeO42-} via DmsRegEq_26
    --- DmsReg_12 {[Fe(Citr)]} via DmsRegEq_27
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_12, DmsRegEqJnc_16, DmsRegEqJnc_17]
- **DmsReg_11 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.9420703
  -- Neighboring regions:
    --- DmsReg_8 {[Fe(OH)3](s)} via DmsRegEq_25
    --- DmsReg_10 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_26
    --- DmsReg_12 {[Fe(Citr)]} via DmsRegEq_28
  -- Junction features: [DmsRegEqJnc_16, DmsRegEqJnc_22, DmsRegEqJnc_17, DmsRegEqJnc_23]
- **DmsReg_12 {[Fe(Citr)]}**
  -- Measure in the solver coordinate frame: 0.27640625
  -- Neighboring regions:
    --- DmsReg_7 {Fe2+} via DmsRegEq_19
    --- DmsReg_10 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_27
    --- DmsReg_11 {FeO42-} via DmsRegEq_28
    --- DmsReg_13 {Fe3+} via DmsRegEq_29
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_15, DmsRegEqJnc_17, DmsRegEqJnc_23, DmsRegEqJnc_24]
- **DmsReg_13 {Fe3+}**
  -- Measure in the solver coordinate frame: 1.0648828
  -- Neighboring regions:
    --- DmsReg_7 {Fe2+} via DmsRegEq_20
    --- DmsReg_12 {[Fe(Citr)]} via DmsRegEq_29
  -- Junction features: [DmsRegEqJnc_21, DmsRegEqJnc_15, DmsRegEqJnc_24]

### boundary curves/equilibria
- **DmsRegEq_1: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, -0.9219], [13.725, -0.9], [13.7, -0.8938], [13.55, -0.8844], [13.525, -0.8781], [11.9125, -0.7375]]
  -- Boundary/junction features: [DmsRegEqJnc_18, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 227, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 29, 33, 48, 52, 226], "t_params": [0.0, 0.1316, 0.1439, 0.2156, 0.2279, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, -0.9219], [13.725, -0.9], [13.7, -0.8938], [13.55, -0.8844], [13.525, -0.8781], [11.9125, -0.7375]], "envelope_t": [0.0, 0.1316, 0.1439, 0.2156, 0.2279, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, -0.9219], [11.9125, -0.7375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Fe | [Fe(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.9125, -0.7375], [11.475, -0.7094], [11.4125, -0.7094], [11.2625, -0.6969], [11.2, -0.6969], [10.4875, -0.6531]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 142, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 44, 49, 65, 70, 141], "t_params": [0.0, 0.3071, 0.3508, 0.4563, 0.5, 1.0], "envelope_n": 6, "envelope_pts": [[11.9125, -0.7375], [11.475, -0.7094], [11.4125, -0.7094], [11.2625, -0.6969], [11.2, -0.6969], [10.4875, -0.6531]], "envelope_t": [0.0, 0.3071, 0.3508, 0.4563, 0.5, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.9125, -0.7375], [10.4875, -0.6531]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.4875, -0.6531], [9.3, -0.6219], [8.675, -0.6], [8.3375, -0.5938], [8.3375, -0.5906], [8.0875, -0.5875]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 214, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 105, 162, 191, 192, 213], "t_params": [0.0, 0.4941, 0.7543, 0.8947, 0.896, 1.0], "envelope_n": 6, "envelope_pts": [[10.4875, -0.6531], [9.3, -0.6219], [8.675, -0.6], [8.3375, -0.5938], [8.3375, -0.5906], [8.0875, -0.5875]], "envelope_t": [0.0, 0.4941, 0.7543, 0.8947, 0.896, 1.0], "adaptive_n": 2, "adaptive_pts": [[10.4875, -0.6531], [8.0875, -0.5875]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0375, -0.5844], [8.05, -0.5844], [8.0625, -0.5844], [8.075, -0.5844]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 4, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3], "t_params": [0.0, 0.3333, 0.6667, 1.0], "envelope_n": 6, "envelope_pts": [[8.0375, -0.5844], [8.05, -0.5844], [8.0625, -0.5844], [8.075, -0.5844]], "envelope_t": [0.0, 0.3333, 0.6667, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0375, -0.5844], [8.075, -0.5844]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[4.0375, -0.5531], [3.675, -0.5469], [3.675, -0.5438], [2.825, -0.5406], [2.825, -0.5375], [0.0, -0.5375]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_19]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 329, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 31, 32, 101, 102, 328], "t_params": [0.0, 0.0897, 0.0904, 0.3006, 0.3014, 1.0], "envelope_n": 6, "envelope_pts": [[4.0375, -0.5531], [3.675, -0.5469], [3.675, -0.5438], [2.825, -0.5406], [2.825, -0.5375], [0.0, -0.5375]], "envelope_t": [0.0, 0.0897, 0.0904, 0.3006, 0.3014, 1.0], "adaptive_n": 2, "adaptive_pts": [[4.0375, -0.5531], [0.0, -0.5375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0875, -0.5875], [8.075, -0.5875], [8.075, -0.5844]]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 3, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 1, 2], "t_params": [0.0, 0.8, 1.0], "envelope_n": 6, "envelope_pts": [[8.0875, -0.5875], [8.075, -0.5875], [8.075, -0.5844]], "envelope_t": [0.0, 0.8, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0875, -0.5875], [8.075, -0.5844]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0375, -0.5844], [7.2375, -0.575], [5.2625, -0.575], [5.2625, -0.5719], [4.7125, -0.5688], [4.0375, -0.5531]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 331, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 67, 225, 226, 271, 330], "t_params": [0.0, 0.1998, 0.6932, 0.694, 0.8313, 1.0], "envelope_n": 6, "envelope_pts": [[8.0375, -0.5844], [7.2375, -0.575], [5.2625, -0.575], [5.2625, -0.5719], [4.7125, -0.5688], [4.0375, -0.5531]], "envelope_t": [0.0, 0.1998, 0.6932, 0.694, 0.8313, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0375, -0.5844], [4.0375, -0.5531]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [Fe(OH)3]- | [Fe(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.9125, -0.7375], [11.9125, -0.7344], [11.9125, -0.7312], [11.9125, -0.5688], [11.9125, -0.5656], [11.9125, -0.5219]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 70, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 54, 55, 69], "t_params": [0.0, 0.0145, 0.029, 0.7826, 0.7971, 1.0], "envelope_n": 6, "envelope_pts": [[11.9125, -0.7375], [11.9125, -0.7344], [11.9125, -0.7312], [11.9125, -0.5688], [11.9125, -0.5656], [11.9125, -0.5219]], "envelope_t": [0.0, 0.0145, 0.029, 0.7826, 0.7971, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.9125, -0.7375], [11.9125, -0.5219]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: [Fe(OH)3]- | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.9125, -0.5219], [11.925, -0.5219], [11.9375, -0.5219], [13.7875, -0.5219], [13.7875, -0.5188], [14.0, -0.5188]]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_20]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 169, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 150, 151, 168], "t_params": [0.0, 0.006, 0.012, 0.8969, 0.8984, 1.0], "envelope_n": 6, "envelope_pts": [[11.9125, -0.5219], [11.925, -0.5219], [11.9375, -0.5219], [13.7875, -0.5219], [13.7875, -0.5188], [14.0, -0.5188]], "envelope_t": [0.0, 0.006, 0.012, 0.8969, 0.8984, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.9125, -0.5219], [14.0, -0.5188]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: [Fe(OH)2](s) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.4875, -0.6531], [10.4875, -0.65], [10.4875, -0.6469], [10.4875, -0.4938], [10.4875, -0.4875], [10.4875, -0.4375]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 70, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 51, 53, 69], "t_params": [0.0, 0.0145, 0.029, 0.7391, 0.7681, 1.0], "envelope_n": 6, "envelope_pts": [[10.4875, -0.6531], [10.4875, -0.65], [10.4875, -0.6469], [10.4875, -0.4938], [10.4875, -0.4875], [10.4875, -0.4375]], "envelope_t": [0.0, 0.0145, 0.029, 0.7391, 0.7681, 1.0], "adaptive_n": 2, "adaptive_pts": [[10.4875, -0.6531], [10.4875, -0.4375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: [Fe(OH)2](s) | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.9125, -0.5219], [11.5125, -0.4969], [11.45, -0.4969], [11.25, -0.4813], [11.1875, -0.4813], [10.4875, -0.4375]]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 142, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 40, 45, 66, 71, 141], "t_params": [0.0, 0.2807, 0.3245, 0.465, 0.5088, 1.0], "envelope_n": 6, "envelope_pts": [[11.9125, -0.5219], [11.5125, -0.4969], [11.45, -0.4969], [11.25, -0.4813], [11.1875, -0.4813], [10.4875, -0.4375]], "envelope_t": [0.0, 0.2807, 0.3245, 0.465, 0.5088, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.9125, -0.5219], [10.4875, -0.4375]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_12: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0875, -0.5875], [8.0875, -0.5844], [8.075, -0.5844]]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 3, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 1, 2], "t_params": [0.0, 0.2, 1.0], "envelope_n": 6, "envelope_pts": [[8.0875, -0.5875], [8.0875, -0.5844], [8.075, -0.5844]], "envelope_t": [0.0, 0.2, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0875, -0.5875], [8.075, -0.5844]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0375, -0.5844], [7.9875, -0.5813], [7.9875, -0.5781], [7.9375, -0.5781], [7.9375, -0.1375], [8.0625, -0.1437]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 164, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 5, 6, 10, 151, 163], "t_params": [0.0, 0.0749, 0.0796, 0.1543, 0.8129, 1.0], "envelope_n": 6, "envelope_pts": [[8.0375, -0.5844], [7.9875, -0.5813], [7.9875, -0.5781], [7.9375, -0.5781], [7.9375, -0.1375], [8.0625, -0.1437]], "envelope_t": [0.0, 0.0749, 0.0796, 0.1543, 0.8129, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0375, -0.5844], [8.0625, -0.1437]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0875, -0.1469], [8.075, -0.1469], [8.075, -0.1437]]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 3, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 1, 2], "t_params": [0.0, 0.8, 1.0], "envelope_n": 6, "envelope_pts": [[8.0875, -0.1469], [8.075, -0.1469], [8.075, -0.1437]], "envelope_t": [0.0, 0.8, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0875, -0.1469], [8.075, -0.1437]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_15: [Fe2(Citr)2(OH)2]4- | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.4875, -0.4375], [9.5625, -0.3219], [9.525, -0.3219], [9.225, -0.2812], [8.55, -0.2062], [8.0875, -0.1469]]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 286, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 111, 114, 151, 229, 285], "t_params": [0.0, 0.3855, 0.4011, 0.5263, 0.8071, 1.0], "envelope_n": 6, "envelope_pts": [[10.4875, -0.4375], [9.5625, -0.3219], [9.525, -0.3219], [9.225, -0.2812], [8.55, -0.2062], [8.0875, -0.1469]], "envelope_t": [0.0, 0.3855, 0.4011, 0.5263, 0.8071, 1.0], "adaptive_n": 2, "adaptive_pts": [[10.4875, -0.4375], [8.0875, -0.1469]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [Fe2(Citr)2(OH)2]4- | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0625, -0.1437], [8.075, -0.1437]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 2, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [[8.0625, -0.1437], [8.075, -0.1437]], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0625, -0.1437], [8.075, -0.1437]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_17: Fe2+ | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[4.0375, -0.5531], [4.0375, -0.5438], [4.05, -0.5438], [4.05, 0.2375], [4.0625, 0.2375], [4.075, 0.2906]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 274, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 3, 4, 254, 255, 273], "t_params": [0.0, 0.0108, 0.0251, 0.9229, 0.9373, 1.0], "envelope_n": 6, "envelope_pts": [[4.0375, -0.5531], [4.0375, -0.5438], [4.05, -0.5438], [4.05, 0.2375], [4.0625, 0.2375], [4.075, 0.2906]], "envelope_t": [0.0, 0.0108, 0.0251, 0.9229, 0.9373, 1.0], "adaptive_n": 2, "adaptive_pts": [[4.0375, -0.5531], [4.075, 0.2906]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: Fe2+ | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[4.075, 0.2906], [3.6, 0.3531], [3.1, 0.4375], [2.4375, 0.575], [2.4125, 0.575], [1.8875, 0.7]]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 307, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 58, 125, 222, 224, 306], "t_params": [0.0, 0.2151, 0.4427, 0.7465, 0.7577, 1.0], "envelope_n": 6, "envelope_pts": [[4.075, 0.2906], [3.6, 0.3531], [3.1, 0.4375], [2.4375, 0.575], [2.4125, 0.575], [1.8875, 0.7]], "envelope_t": [0.0, 0.2151, 0.4427, 0.7465, 0.7577, 1.0], "adaptive_n": 2, "adaptive_pts": [[4.075, 0.2906], [1.8875, 0.7]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_19: Fe2+ | [Fe(Citr)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_12]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[1.8875, 0.7], [1.65, 0.7406], [1.625, 0.7406], [1.6, 0.75], [1.575, 0.75], [1.4625, 0.7719]]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 58, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 32, 34, 39, 41, 57], "t_params": [0.0, 0.5574, 0.6153, 0.677, 0.7349, 1.0], "envelope_n": 6, "envelope_pts": [[1.8875, 0.7], [1.65, 0.7406], [1.625, 0.7406], [1.6, 0.75], [1.575, 0.75], [1.4625, 0.7719]], "envelope_t": [0.0, 0.5574, 0.6153, 0.677, 0.7349, 1.0], "adaptive_n": 2, "adaptive_pts": [[1.8875, 0.7], [1.4625, 0.7719]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_20: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_13]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[0.0, 0.7719], [0.4375, 0.7719], [0.475, 0.7719], [0.9375, 0.7719], [1.0, 0.7719], [1.4625, 0.7719]]
  -- Boundary/junction features: [DmsRegEqJnc_21, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 118, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 35, 38, 75, 80, 117], "t_params": [0.0, 0.2991, 0.3248, 0.641, 0.6838, 1.0], "envelope_n": 6, "envelope_pts": [[0.0, 0.7719], [0.4375, 0.7719], [0.475, 0.7719], [0.9375, 0.7719], [1.0, 0.7719], [1.4625, 0.7719]], "envelope_t": [0.0, 0.2991, 0.3248, 0.641, 0.6838, 1.0], "adaptive_n": 2, "adaptive_pts": [[0.0, 0.7719], [1.4625, 0.7719]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_21: [Fe(Citr)]- | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0875, -0.1469], [8.0875, -0.1437], [8.075, -0.1437]]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 3, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 1, 2], "t_params": [0.0, 0.2, 1.0], "envelope_n": 6, "envelope_pts": [[8.0875, -0.1469], [8.0875, -0.1437], [8.075, -0.1437]], "envelope_t": [0.0, 0.2, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0875, -0.1469], [8.075, -0.1437]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_22: [Fe(Citr)]- | [Fe(OH)3](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.0625, -0.1437], [7.475, -0.0562], [6.85, 0.0563], [6.7625, 0.0656], [6.4875, 0.1188], [6.3625, 0.1563]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 233, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 75, 161, 171, 210, 232], "t_params": [0.0, 0.3438, 0.7114, 0.7623, 0.9245, 1.0], "envelope_n": 6, "envelope_pts": [[8.0625, -0.1437], [7.475, -0.0562], [6.85, 0.0563], [6.7625, 0.0656], [6.4875, 0.1188], [6.3625, 0.1563]], "envelope_t": [0.0, 0.3438, 0.7114, 0.7623, 0.9245, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.0625, -0.1437], [6.3625, 0.1563]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_23: [Fe(Citr)]- | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.3625, 0.1563], [6.225, 0.1531], [6.125, 0.1625], [6.0625, 0.1625], [4.35, 0.2688], [4.075, 0.2906]]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 229, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 12, 23, 28, 199, 228], "t_params": [0.0, 0.06, 0.1038, 0.1311, 0.8796, 1.0], "envelope_n": 6, "envelope_pts": [[6.3625, 0.1563], [6.225, 0.1531], [6.125, 0.1625], [6.0625, 0.1625], [4.35, 0.2688], [4.075, 0.2906]], "envelope_t": [0.0, 0.06, 0.1038, 0.1311, 0.8796, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.3625, 0.1563], [4.075, 0.2906]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_24: [Fe(OH)3](s) | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.3625, 0.1563], [6.3125, 0.2094], [6.3, 0.2094], [6.3, 0.9656], [6.3125, 0.9719], [6.3625, 0.975]]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 273, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 21, 22, 264, 267, 272], "t_params": [0.0, 0.0805, 0.0943, 0.9293, 0.9447, 1.0], "envelope_n": 6, "envelope_pts": [[6.3625, 0.1563], [6.3125, 0.2094], [6.3, 0.2094], [6.3, 0.9656], [6.3125, 0.9719], [6.3625, 0.975]], "envelope_t": [0.0, 0.0805, 0.0943, 0.9293, 0.9447, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.3625, 0.1563], [6.3625, 0.975]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_25: [Fe(OH)3](s) | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, 0.2281], [7.1875, 0.9031], [7.1125, 0.9063], [6.8375, 0.9375], [6.5, 0.9688], [6.3625, 0.975]]
  -- Boundary/junction features: [DmsRegEqJnc_22, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 851, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 761, 768, 800, 837, 850], "t_params": [0.0, 0.8921, 0.9018, 0.9379, 0.9821, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, 0.2281], [7.1875, 0.9031], [7.1125, 0.9063], [6.8375, 0.9375], [6.5, 0.9688], [6.3625, 0.975]], "envelope_t": [0.0, 0.8921, 0.9018, 0.9379, 0.9821, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, 0.2281], [6.3625, 0.975]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_26: [Fe2(Citr)2(OH)2]2- | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_10, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.3625, 0.975], [6.2, 1.0031], [5.4125, 1.1094], [4.225, 1.2563], [2.825, 1.4], [1.8875, 1.475]]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_17]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 519, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 22, 119, 261, 419, 518], "t_params": [0.0, 0.0366, 0.213, 0.4787, 0.7912, 1.0], "envelope_n": 6, "envelope_pts": [[6.3625, 0.975], [6.2, 1.0031], [5.4125, 1.1094], [4.225, 1.2563], [2.825, 1.4], [1.8875, 1.475]], "envelope_t": [0.0, 0.0366, 0.213, 0.4787, 0.7912, 1.0], "adaptive_n": 3, "adaptive_pts": [[6.3625, 0.975], [4.225, 1.2563], [1.8875, 1.475]], "adaptive_t": [0.0, 0.4787, 1.0]}
- **DmsRegEq_27: [Fe2(Citr)2(OH)2]2- | [Fe(Citr)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_10, DmsReg_12]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[1.8875, 0.7], [1.85, 0.725], [1.825, 0.7719], [1.825, 1.4625], [1.8625, 1.475], [1.8875, 1.475]]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_17]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 259, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 11, 28, 249, 256, 258], "t_params": [0.0, 0.0528, 0.1151, 0.9244, 0.9707, 1.0], "envelope_n": 6, "envelope_pts": [[1.8875, 0.7], [1.85, 0.725], [1.825, 0.7719], [1.825, 1.4625], [1.8625, 1.475], [1.8875, 1.475]], "envelope_t": [0.0, 0.0528, 0.1151, 0.9244, 0.9707, 1.0], "adaptive_n": 2, "adaptive_pts": [[1.8875, 0.7], [1.8875, 1.475]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_28: FeO42- | [Fe(Citr)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_11, DmsReg_12]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[1.8875, 1.475], [1.8625, 1.4813], [1.825, 1.4813], [1.8, 1.4875], [1.7, 1.4937], [1.675, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_17, DmsRegEqJnc_23]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 26, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 4, 7, 11, 21, 25], "t_params": [0.0, 0.1199, 0.2943, 0.4141, 0.8801, 1.0], "envelope_n": 6, "envelope_pts": [[1.8875, 1.475], [1.8625, 1.4813], [1.825, 1.4813], [1.8, 1.4875], [1.7, 1.4937], [1.675, 1.5]], "envelope_t": [0.0, 0.1199, 0.2943, 0.4141, 0.8801, 1.0], "adaptive_n": 2, "adaptive_pts": [[1.8875, 1.475], [1.675, 1.5]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_29: [Fe(Citr)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_12, DmsReg_13]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[1.4625, 0.7719], [1.4625, 0.775], [1.4625, 0.7781], [1.4625, 1.3938], [1.4625, 1.4156], [1.4625, 1.5]]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_24]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 234, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 199, 206, 233], "t_params": [0.0, 0.0043, 0.0086, 0.8541, 0.8841, 1.0], "envelope_n": 6, "envelope_pts": [[1.4625, 0.7719], [1.4625, 0.775], [1.4625, 0.7781], [1.4625, 1.3938], [1.4625, 1.4156], [1.4625, 1.5]], "envelope_t": [0.0, 0.0043, 0.0086, 0.8541, 0.8841, 1.0], "adaptive_n": 2, "adaptive_pts": [[1.4625, 0.7719], [1.4625, 1.5]], "adaptive_t": [0.0, 1.0]}

### junction features
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, [Fe(OH)2](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.9125, "E_V": -0.7375}
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)2](s), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 10.4875, "E_V": -0.6531}
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.0875, "E_V": -0.5875}
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_7, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.0375, "E_V": -0.5844}
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_6, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.075, "E_V": -0.5844}
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_7, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_7, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 4.0375, "E_V": -0.5531}
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, [Fe(OH)2](s), [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.9125, "E_V": -0.5219}
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)2](s), [Fe2(Citr)2(OH)2]4-, [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_4, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 10.4875, "E_V": -0.4375}
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-, [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_14, DmsRegEq_15, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.0875, "E_V": -0.1469}
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-, [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_13, DmsRegEq_16, DmsRegEq_22]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.0625, "E_V": -0.1437}
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-, [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_14, DmsRegEq_16, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.075, "E_V": -0.1437}
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [Fe(OH)3](s), [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_6, DmsReg_8, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_22, DmsRegEq_23, DmsRegEq_24]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.3625, "E_V": 0.1563}
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_17, DmsRegEq_18, DmsRegEq_23]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 4.075, "E_V": 0.2906}
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe2(Citr)2(OH)2]2-, [Fe(Citr)]]
  -- Neighboring regions: [DmsReg_7, DmsReg_10, DmsReg_12]
  -- Connected boundary manifolds: [DmsRegEq_18, DmsRegEq_19, DmsRegEq_27]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 1.8875, "E_V": 0.7}
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Citr)], Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_12, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_19, DmsRegEq_20, DmsRegEq_29]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 1.4625, "E_V": 0.7719}
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3](s), [Fe2(Citr)2(OH)2]2-, FeO42-]
  -- Neighboring regions: [DmsReg_8, DmsReg_10, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_24, DmsRegEq_25, DmsRegEq_26]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.3625, "E_V": 0.975}
- **DmsRegEqJnc_17** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe2(Citr)2(OH)2]2-, FeO42-, [Fe(Citr)]]
  -- Neighboring regions: [DmsReg_10, DmsReg_11, DmsReg_12]
  -- Connected boundary manifolds: [DmsRegEq_26, DmsRegEq_27, DmsRegEq_28]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 1.8875, "E_V": 1.475}
- **DmsRegEqJnc_18** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.9219}
- **DmsRegEqJnc_19** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 0.0, "E_V": -0.5375}
- **DmsRegEqJnc_20** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, [Fe(OH)3](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.5188}
- **DmsRegEqJnc_21** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_20]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 0.0, "E_V": 0.7719}
- **DmsRegEqJnc_22** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3](s), FeO42-]
  -- Neighboring regions: [DmsReg_8, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_25]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": 0.2281}
- **DmsRegEqJnc_23** — intrinsic dimension 0 (point)
  -- Dominant species: [FeO42-, [Fe(Citr)]]
  -- Neighboring regions: [DmsReg_11, DmsReg_12]
  -- Connected boundary manifolds: [DmsRegEq_28]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 1.675, "E_V": 1.5}
- **DmsRegEqJnc_24** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)], Fe3+]
  -- Neighboring regions: [DmsReg_12, DmsReg_13]
  -- Connected boundary manifolds: [DmsRegEq_29]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 1.4625, "E_V": 1.5}

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), [Cu(OH)2](s), Cu]
  -- excluded: [Cu2O, CuO(s), CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_analysis_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Pipeline succeeded, both Cu and Fe Pourbaix verdicts delivered in full. I have enough to write the analysis directly from these plus the reference constants table. Report will exceed 3500 chars so I'll stage in chunks.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk='## Doability\nDoable and ex…)</tool_call>
<tool_call>append_analysis_chunk(chunk_index=2, analysis_markdown_chunk='## Analysis\n\n### Copper p…')</tool_call>
<tool_call>append_analysis_chunk(chunk_index=3, analysis_markdown_chunk="### Iron partitioning acros…")</tool_call>
<tool_call>append_analysis_chunk(chunk_index=4, analysis_markdown_chunk="### Principal boundaries an…")</tool_call>

## User
<tool_result>
### append_analysis_chunk
OK — staged chunk 1 (1402 chars; 1402 total; next index 2).

### append_analysis_chunk
OK — staged chunk 2 (2906 chars; 4308 total; next index 3).

### append_analysis_chunk
OK — staged chunk 3 (2463 chars; 6771 total; next index 4).

### append_analysis_chunk
OK — staged chunk 4 (1980 chars; 8751 total; next index 5).
</tool_result>

## Assistant
<summary>Four chunks staged (8751 chars). Adding a final artifacts chunk and committing.</summary>
<tool_call>append_analysis_chunk(chunk_index=5, analysis_markdown_chunk='\n## Artifacts\n- `L1_call_…')</tool_call>
<wait/> (1 deferred)

## User
<tool_result>
OK — staged chunk 5 (1266 chars; 10017 total; next index 6).

[WAIT BARRIER COMPLETE] 1 tool(s) finished (append_analysis_chunk). 1 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>All 5 chunks staged (10017 chars total). Committing with record_analysis.</summary>
<tool_call>record_analysis(expected_chunks=5, artifact_paths='L1_call_01/solver/pourbaix_…')</tool_call>

## User
<tool_result>
OK — analysis recorded (10016 chars, 10 artifacts).
</tool_result>

## LLM Response
<answer>
The joint two-dimensional Pourbaix diagram for the Cu(II)/Fe(III)/citrate/glycine/Cl⁻/NH₃ electrolyte has been computed successfully. Both element-projected verdicts, the topology and label-map artefacts, the full-speciation CSV, and the deterministic log K / E° reference table are available as staged evidence. The report captures how each metal partitions among aqueous complexes (Cu dominated by citrate hydroxo, glycinate, chloro and ammine complexes; Fe dominated by ferric citrate hydroxo species and Fe(OH)₃(s) in most of the oxic field, with excluded Fe₂O₃/FeOOH/Fe₃O₄/CuO respected), locates the principal region boundaries and triple points, and quotes the log K values the solver actually used from the LC2 free-energy card.
</answer>

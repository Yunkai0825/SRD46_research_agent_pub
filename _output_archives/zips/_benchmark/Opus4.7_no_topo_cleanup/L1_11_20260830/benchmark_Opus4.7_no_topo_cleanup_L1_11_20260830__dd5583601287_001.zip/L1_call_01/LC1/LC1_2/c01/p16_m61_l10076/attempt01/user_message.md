[Purpose: Build the joint two-dimensional E-pH Pourbaix diagram of a single aqueous pot containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, to inform electrodeposition electrolyte design.]
[Tasks:
Model a single solution containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and ionic strength 0.1 m. Build the joint two-dimensional Pourbaix (E vs pH) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, treating E and pH as independently varied axes. Prefer hydrated aqueous species (this is a water-rich electrodeposition electrolyte scenario) and explicitly exclude the solid oxides Fe2O3, CuO, FeOOH, and Fe3O4 from the model. Report how Cu and Fe partition among aqueous complexes (with citrate, glycine, chloride, ammonia, hydroxide) and any remaining solids/metals across the field, and describe the principal region boundaries and triple-point junctions using the equilibrium constants (log K) and standard potentials that the solver actually used. Provide the region catalogue (labels, areas, boundaries), the topology JSON, the label map, and the full-speciation table so partitioning and boundary chemistry can be read off directly.
]
[Pair: pair_key=`m61_l10076`, metal_id=61, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10076_beta649_net27465`
  - `metal61_ligand10076_beta812_net27465`
  - `metal61_ligand10076_beta352_net27465`
  - `metal61_ligand10076_beta357_net27465`
  - `metal61_ligand10076_beta351_net27465`
  - `metal61_ligand10076_beta840_net27465`
  - `metal61_ligand10076_beta894_net27465`
  - `metal61_ligand10076_beta519_net27465`
[Screen report]
# Eq-map screen — m61_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10076_beta649_net27465` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170821@(25.0,0.0) = K+49.700 | 3 | +49.700 / +49.700 / +50.133 / +51.000 | vlm_170821@(25.0,0.0) = K+49.700 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal61_ligand10076_beta812_net27465` | `[M] + [L] <=> [ML]` | vlm_170791@(25.0,0.1) = K+11.270 | 7 | +11.050 / +11.140 / +11.226 / +11.810 | vlm_170791@(25.0,0.1) = K+11.270 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand10076_beta352_net27465` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170825@(25.0,0.0) = K-38.800 | 2 | -38.800 / -38.700 / -38.700 / -38.600 | vlm_170825@(25.0,0.0) = K-38.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal61_ligand10076_beta357_net27465` | `[MOOH(s,alpha)] + [H2O] <=> [M] + [OH]^3` | vlm_170827@(25.0,0.0) = K-41.500 | 2 | -41.500 / -41.300 / -41.300 / -41.100 | vlm_170827@(25.0,0.0) = K-41.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal61_ligand10076_beta351_net27465` | `[(M2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [M] + [OH]^3` | vlm_170828@(25.0,0.0) = K-42.700 | 1 | -42.700 / -42.700 / -42.700 / -42.700 | vlm_170828@(25.0,0.0) = K-42.700 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal61_ligand10076_beta840_net27465` | `[M] + [L]^2 <=> [ML2]` | vlm_170807@(25.0,0.0) = K+23.400 | 6 | -20.400 / +21.850 / +15.100 / +23.400 | vlm_170807@(25.0,0.0) = K+23.400 (+0.00 °C, -0.10 M) | `sibling_sign_split, mad_outlier, mean_median_gap, wide_TI_distance` |
| 7 | `metal61_ligand10076_beta894_net27465` | `[M] + [L]^4 <=> [ML4]` | vlm_170808@(25.0,0.0) = K+34.400 | 1 | +34.400 / +34.400 / +34.400 / +34.400 | vlm_170808@(25.0,0.0) = K+34.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal61_ligand10076_beta519_net27465` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170814@(25.0,0.0) = K+25.140 | 6 | +24.500 / +25.120 / +25.073 / +25.500 | vlm_170814@(25.0,0.0) = K+25.140 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

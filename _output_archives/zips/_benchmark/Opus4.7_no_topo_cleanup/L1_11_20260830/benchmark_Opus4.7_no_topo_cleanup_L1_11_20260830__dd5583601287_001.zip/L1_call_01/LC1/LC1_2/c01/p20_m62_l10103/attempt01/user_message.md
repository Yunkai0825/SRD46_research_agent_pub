[Purpose: Build the joint two-dimensional E-pH Pourbaix diagram of a single aqueous pot containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, to inform electrodeposition electrolyte design.]
[Tasks:
Model a single solution containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and ionic strength 0.1 m. Build the joint two-dimensional Pourbaix (E vs pH) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, treating E and pH as independently varied axes. Prefer hydrated aqueous species (this is a water-rich electrodeposition electrolyte scenario) and explicitly exclude the solid oxides Fe2O3, CuO, FeOOH, and Fe3O4 from the model. Report how Cu and Fe partition among aqueous complexes (with citrate, glycine, chloride, ammonia, hydroxide) and any remaining solids/metals across the field, and describe the principal region boundaries and triple-point junctions using the equilibrium constants (log K) and standard potentials that the solver actually used. Provide the region catalogue (labels, areas, boundaries), the topology JSON, the label map, and the full-speciation table so partitioning and boundary chemistry can be read off directly.
]
[Pair: pair_key=`m62_l10103`, metal_id=62, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10103_beta812_net28225`
  - `metal62_ligand10103_beta840_net28225`
  - `metal62_ligand10103_beta872_net28225`
  - `metal62_ligand10103_beta894_net28225`
[Screen report]
# Eq-map screen — m62_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10103_beta812_net28225` | `[M] + [L] <=> [ML]` | vlm_173136@(25.0,0.0) = K+1.400 | 6 | +1.400 / +1.630 / +1.620 / +1.800 | vlm_173136@(25.0,0.0) = K+1.400 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal62_ligand10103_beta840_net28225` | `[M] + [L]^2 <=> [ML2]` | vlm_173144@(25.0,0.0) = K+2.250 | 6 | +2.250 / +2.700 / +2.677 / +3.020 | vlm_173144@(25.0,0.0) = K+2.250 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal62_ligand10103_beta872_net28225` | `[M] + [L]^3 <=> [ML3]` | vlm_173152@(25.0,0.0) = K+2.680 | 6 | +2.680 / +3.360 / +3.322 / +3.830 | vlm_173152@(25.0,0.0) = K+2.680 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal62_ligand10103_beta894_net28225` | `[M] + [L]^4 <=> [ML4]` | vlm_173160@(25.0,0.0) = K+2.750 | 6 | +2.750 / +3.640 / +3.590 / +4.250 | vlm_173160@(25.0,0.0) = K+2.750 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

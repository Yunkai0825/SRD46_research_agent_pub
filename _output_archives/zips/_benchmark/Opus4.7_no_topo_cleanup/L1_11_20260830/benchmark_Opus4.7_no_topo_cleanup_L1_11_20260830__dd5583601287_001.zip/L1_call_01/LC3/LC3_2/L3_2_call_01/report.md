# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 19.32
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) total; element total for redox axis
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) total; element total for redox axis
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # 10 mM citrate
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # 10 mM glycine
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M ammonia (ligand_10103 per card section 2.3)
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride (ligand_10163 per card section 2.3)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is one of the two Pourbaix axes (0 to 14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the second Pourbaix axis (-1.0 to +1.5 V vs SHE)'},
]

```

## Notes
T, I, Cu, Fe, and all four ligand totals are directly from the task. Element-level metal totals used because redox is a sweep axis. pH and E_V are swept (2-D Pourbaix), so both are deferred to L3_3. Specific solid exclusions (Fe2O3, CuO, FeOOH, Fe3O4) are a constraint-level concern for L3_3, not initial conditions.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
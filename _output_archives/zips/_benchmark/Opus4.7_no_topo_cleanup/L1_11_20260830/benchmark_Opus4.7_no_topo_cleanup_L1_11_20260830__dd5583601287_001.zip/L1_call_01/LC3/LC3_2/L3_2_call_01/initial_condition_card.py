inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m stated in task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "1 mM Cu(II) total; element total for redox axis"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "1 mM Fe(III) total; element total for redox axis"},
  {"id": "Citr",   "lhs": lambda s: s.total["ligand_9058"],  "value": 1e-2, "basis": "known", "note": "10 mM citrate"},
  {"id": "Glyc",   "lhs": lambda s: s.total["ligand_5760"],  "value": 1e-2, "basis": "known", "note": "10 mM glycine"},
  {"id": "Ammo",   "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M ammonia (ligand_10103 per card section 2.3)"},
  {"id": "Chlo",   "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M chloride (ligand_10163 per card section 2.3)"},
]
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I) bis-glycinate complex, in scope at 10 mM glycine. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Distinct Cu(I) diammine complex, real competitor at 100 mM ammonia. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Distinct Cu(I) monochloro complex, in scope at 100 mM Cl. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Distinct Cu(I) trichloro complex, in scope. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species, distinct hydroxo state. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Distinct Cu(II) hydroxo anion [HCuO2]-. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Distinct Cu(II) cuprate [CuO2]2-. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Distinct Cu2-citrate dinuclear complex. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Distinct Cu2-citrate hydroxo polynuclear. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Cu-citrate complex. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) monoglycinate. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Cu(II) bis-glycinate. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) monoammine. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) diammine. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) triammine. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) tetraammine, dominant at 100 mM NH3. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) monochloro complex. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Distinct Cu2-citrate-hydroxo polynuclear stoichiometry. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Distinct Cu2-(citr)2-hydroxo polynuclear. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Distinct Cu3 hydroxo trinuclear cation. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) reduced anchor. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is a real chloride-region competitor at 100 mM Cl. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) monohydroxo. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Distinct neutral Fe(II) dihydroxo aqueous species. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Distinct Fe(II)-citrate complex. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Distinct Fe2-citrate-hydroxo dinuclear. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Fe(II)-citrate complex. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Distinct diprotonated Fe(II)-citrate complex. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Distinct Fe(II)-biscitrate protonated complex. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Fe(II)-monoglycinate. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Fe(II)-bisglycinate. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Distinct Fe(II)-trisglycinate. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(II)-monoammine. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Fe(II)-diammine. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Fe(II)-triammine. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Fe(II)-tetraammine. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Fe(II)-monochloro. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Distinct Fe(III)-citrate neutral complex. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III)-citrate. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III)-monoglycinate. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III)-glycinate. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Distinct Fe(III)-bisglycinate diprotonated. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III)-monochloro. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Distinct Fe(III)-dichloro. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Distinct Fe3 hydroxo trinuclear cation. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Only Fe(VI) ferrate member; keep for redox coverage even if inactive. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe(s) reduced anchor. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Anhydrous Fe3O4 explicitly excluded by user request. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference; required. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Neutral ammonia reference. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion reference. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate ligand reference. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Deprotonated glycinate reference. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Distinct citrate protonation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium cation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Neutral citric acid reference. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium cation reference. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Distinct citrate protonation state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine zwitterion reference. |

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition to the SRD-46 copy when mu agrees within ~10 kJ (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O), keep CuCl(s) as a genuine chloride-region competitor, and drop the anhydrous CuO entries per the user exclusion while retaining Cu(OH)2(hydr.). Keep every distinct Cu(I)/Cu(II) hydroxo, chloride, ammine, glycinate, and citrate complex including the polynuclear Cu2 and Cu3 species — at 1 mM Cu with 10-100 mM ligands each is a real hull competitor and none are notational duplicates.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 |
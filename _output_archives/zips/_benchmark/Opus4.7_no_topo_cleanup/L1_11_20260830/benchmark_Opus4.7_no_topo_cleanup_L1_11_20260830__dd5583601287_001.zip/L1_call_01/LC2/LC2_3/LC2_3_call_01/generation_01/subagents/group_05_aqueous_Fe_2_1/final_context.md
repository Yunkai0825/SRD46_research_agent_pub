## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct.
Return the pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous electrodeposition electrolyte design, water-rich, 25 C, I=0.1 m; the phase question is which phase FORMS in a single mM-scale pot with excess ligands, so retain distinct redox/complex members that can win their own region.
- Concentration regime: Cu(II)=Fe(III)=1 mM, citrate=glycine=10 mM, chloride=100 mM, ammonia=100 mM. This is far above the 1e-6 M corrosion convention: mono- and polynuclear metal-ligand complexes and mixed hydroxo-ligand species are all physically reachable and must be preserved as distinct competitors on the hull.
- Hydration policy: prefer hydrated solids where a hydrated form exists (Cu(OH)2, Fe(OH)2, Fe(OH)3); keep elemental metals (Cu, Fe) and Cu2O for the reduced regions.
- User-mandated exclusions: DROP anhydrous Fe2O3, Fe3O4, CuO, and FeOOH-type oxides (both Atlas and SRD-46 copies). These are explicitly excluded by the request; do not let them shadow the hydrated hydroxides.
- Counterion solids: keep CuCl(s) — chloride is 0.1 M and CuCl precipitation is a genuine competitor in the Cu(I) region. No carbonate chemistry is in scope.
- Atlas vs SRD-46 identical-composition pairs: these are the same physical state re-tabulated. Keep the SRD-46 copy when both exist and the mu values agree within ~10 kJ (SRD-46 is the internally consistent complex database used for the ligand set); otherwise keep the lower-mu member and note the spread. Cu+/[Cu]+ , Cu2+/[Cu]2+, Fe2+/[Fe]2+, Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, and the two [Fe(OH)2]+ entries all collapse this way.
- Cu(II) hydroxo chain: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+ are all distinct protonation/nuclearity states and each can dominate a pH slice — keep all.
- Mixed Cu2-citrate-hydroxo and Fe-citrate-hydroxo polynuclears are distinct stoichiometries at 10 mM citrate and 1 mM metal; keep every unique (nuclearity, protonation, hydroxo count) member.
- Cu2O has two copies with a ~7 kJ spread straddling zero — keep the SRD-46 copy (lower mu, consistent with the rest of the SRD-46 set).
- FeO4(2-) (ferrate) sits far above the O2 line at these conditions but is the only Fe(VI) member; keep it, it will simply be inactive.
- Gases and elemental references: no gas entries in this inventory; keep Cu(s) and Fe(s) as the reduced anchors.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | `Fe2+` | Atlas | +2 | 0.000 | 1 |
| `DEDUP-747e11917c8776f0` | aqueous | `[Fe]2+` | SRD-46 | +2 | 0.000 | 1 |

## Assistant
<summary>Identical Fe2+ aqueous species from Atlas and SRD-46 with matching mu; keep SRD-46 per policy.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [Fe]2+ (identical composition/mu to Atlas Fe2+; SRD-46 preferred).</answer>
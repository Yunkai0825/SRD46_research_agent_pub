All 61 singleton verdicts recorded. Summary:

**DROP (1):**
- Fe3O4 (anh.) [solid, `Fe$+2:1 Fe$+3:2 H:-8`, Atlas] — explicitly excluded by user (anhydrous Fe oxides Fe2O3/Fe3O4/FeOOH out of scope; Fe(OH)2(hydr.)/Fe(OH)3(hydr.) are the retained Fe hydroxide anchors).

**KEEP (60):** all remaining singletons, including:
- Aqueous solvent/ligand references (empty, citric acid protonation series, glycine series, ammonia/ammonium, chloride).
- All distinct Cu(I) and Cu(II) complexes: hydroxo mononuclear/polynuclear ([Cu(OH)2], [HCuO2]−, [CuO2]2−, [Cu3(OH)4]2+), all ammine (1–4), glycinate (Cu(I) and Cu(II)), chloride (Cu(I) mono/tris; Cu(II) mono), and every citrate mono/dinuclear/protonated/hydroxo variant — each is a distinct hull competitor at 1 mM Cu / 10–100 mM ligands.
- All distinct Fe(II) and Fe(III) complexes: hydroxo ([Fe(OH)]+, [Fe(OH)2], [Fe(OH)4]2−, [Fe(OH)4]−, [Fe3(OH)4]5+), citrate mono/dinuclear/protonated/hydroxo, glycinate (Fe(II) 1–3; Fe(III) protonated), ammine (1–4), and chloride mono/bis.
- Ferrate [FeO4]2− kept as the sole Fe(VI) member (will be inactive but preserves valence coverage).
- Solids: Cu(s), Fe(s) as elemental anchors, and CuCl(s) as a genuine Cu(I)–chloride precipitation competitor at 0.1 M Cl−.

No within-group duplicates existed (all singletons by construction); only the mandated anhydrous Fe3O4 exclusion produced a drop.
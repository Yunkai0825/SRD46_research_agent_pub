[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 |
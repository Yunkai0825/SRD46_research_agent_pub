Kept both species — they differ in nuclearity (dinuclear Cu2 vs mononuclear Cu) and charge, so they are distinct competitors, not notational duplicates.

- [Cu2(Chlo)4]2- (SRD-46)
- [Cu(Chlo)2]- (SRD-46)
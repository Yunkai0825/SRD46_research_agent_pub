[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 |
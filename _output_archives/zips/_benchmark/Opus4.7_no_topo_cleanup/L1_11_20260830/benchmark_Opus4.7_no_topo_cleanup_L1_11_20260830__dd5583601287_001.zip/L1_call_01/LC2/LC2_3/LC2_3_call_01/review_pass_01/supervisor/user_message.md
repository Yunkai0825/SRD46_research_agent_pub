[Orchestration session]
55ecec466f344376afaf1e6b30625291

[Calculation purpose]
Build the joint two-dimensional E-pH Pourbaix diagram of a single aqueous pot containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, to inform electrodeposition electrolyte design.

[Requested tasks]
Model a single solution containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and ionic strength 0.1 m. Build the joint two-dimensional Pourbaix (E vs pH) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, treating E and pH as independently varied axes. Prefer hydrated aqueous species (this is a water-rich electrodeposition electrolyte scenario) and explicitly exclude the solid oxides Fe2O3, CuO, FeOOH, and Fe3O4 from the model. Report how Cu and Fe partition among aqueous complexes (with citrate, glycine, chloride, ammonia, hydroxide) and any remaining solids/metals across the field, and describe the principal region boundaries and triple-point junctions using the equilibrium constants (log K) and standard potentials that the solver actually used. Provide the region catalogue (labels, areas, boundaries), the topology JSON, the label map, and the full-speciation table so partitioning and boundary chemistry can be read off directly.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous electrodeposition electrolyte design, water-rich, 25 C, I=0.1 m; the phase question is which phase FORMS in a single mM-scale pot with excess ligands, so retain distinct redox/complex members that can win their own region.
- Concentration regime: Cu(II)=Fe(III)=1 mM, citrate=glycine=10 mM, chloride=100 mM, ammonia=100 mM. This is far above the 1e-6 M corrosion convention: mono- and polynuclear metal-ligand complexes and mixed hydroxo-ligand species are all physically reachable and must be preserved as distinct competitors on the hull.
- Hydration policy: prefer hydrated solids where a hydrated form exists (Cu(OH)2, Fe(OH)2, Fe(OH)3); keep elemental metals (Cu, Fe) and Cu2O for the reduced regions.
- User-mandated exclusions: DROP anhydrous Fe2O3, Fe3O4, CuO, and FeOOH-type oxides (both Atlas and SRD-46 copies). These are explicitly excluded by the request; do not let them shadow the hydrated hydroxides.
- Counterion solids: keep CuCl(s) — chloride is 0.1 M and CuCl precipitation is a genuine competitor in the Cu(I) region. No carbonate chemistry is in scope.
- Atlas vs SRD-46 identical-composition pairs: these are the same physical state re-tabulated. Keep the SRD-46 copy when both exist and the mu values agree within ~10 kJ (SRD-46 is the internally consistent complex database used for the ligand set); otherwise keep the lower-mu member and note the spread. Cu+/[Cu]+ , Cu2+/[Cu]2+, Fe2+/[Fe]2+, Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, and the two [Fe(OH)2]+ entries all collapse this way.
- Cu(II) hydroxo chain: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+ are all distinct protonation/nuclearity states and each can dominate a pH slice — keep all.
- Mixed Cu2-citrate-hydroxo and Fe-citrate-hydroxo polynuclears are distinct stoichiometries at 10 mM citrate and 1 mM metal; keep every unique (nuclearity, protonation, hydroxo count) member.
- Cu2O has two copies with a ~7 kJ spread straddling zero — keep the SRD-46 copy (lower mu, consistent with the rest of the SRD-46 set).
- FeO4(2-) (ferrate) sits far above the O2 line at these conditions but is the only Fe(VI) member; keep it, it will simply be inactive.
- Gases and elemental references: no gas entries in this inventory; keep Cu(s) and Fe(s) as the reduced anchors.

[Committed element instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition to the SRD-46 copy when mu agrees within ~10 kJ (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O), keep CuCl(s) as a genuine chloride-region competitor, and drop the anhydrous CuO entries per the user exclusion while retaining Cu(OH)2(hydr.). Keep every distinct Cu(I)/Cu(II) hydroxo, chloride, ammine, glycinate, and citrate complex including the polynuclear Cu2 and Cu3 species — at 1 mM Cu with 10-100 mM ligands each is a real hull competitor and none are notational duplicates.
- Fe: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. | Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |  |
| `DEDUP-282037ec98906bb1` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 | generation 1: kept — Distinct Cu(I) bis-glycinate complex, in scope at 10 mM glycine. |  |
| `DEDUP-5826713fca0f819d` | true | kept | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 | generation 1: kept — Distinct Cu(I) diammine complex, real competitor at 100 mM ammonia. |  |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 | generation 1: kept — Distinct Cu(I) monochloro complex, in scope at 100 mM Cl. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu(Chlo)2]-` | SRD-46 | -34.589 | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -30.765 | generation 1: kept — Distinct Cu(I) trichloro complex, in scope. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. | Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species, distinct hydroxo state. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — Distinct Cu(II) hydroxo anion [HCuO2]-. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — Distinct Cu(II) cuprate [CuO2]2-. |  |
| `DEDUP-19be21e964e99f8b` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | +94.036 | generation 1: kept — Distinct Cu2-citrate dinuclear complex. |  |
| `DEDUP-e9bd8cea02e9ef19` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | +140.611 | generation 1: kept — Distinct Cu2-citrate hydroxo polynuclear. |  |
| `DEDUP-f8c7d987d5909246` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +35.545 | generation 1: kept — Distinct protonated Cu-citrate complex. |  |
| `DEDUP-f340634469432301` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 | generation 1: kept — Distinct Cu(II) monoglycinate. |  |
| `DEDUP-005c7efaf139b504` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 | generation 1: kept — Distinct Cu(II) bis-glycinate. |  |
| `DEDUP-57e8daa9ccf0b2a2` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 | generation 1: kept — Distinct Cu(II) monoammine. |  |
| `DEDUP-cea12c0b6f396ab4` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 | generation 1: kept — Distinct Cu(II) diammine. |  |
| `DEDUP-153366f6feae80b7` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 | generation 1: kept — Distinct Cu(II) triammine. |  |
| `DEDUP-924bb0044556871a` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 | generation 1: kept — Distinct Cu(II) tetraammine, dominant at 100 mM NH3. |  |
| `DEDUP-602158e7d04361c1` | true | kept | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +15.911 | generation 1: kept — Distinct Cu(II) monochloro complex. |  |
| `DEDUP-5b4c2e5b90b2574a` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +75.429 | generation 1: kept — Distinct Cu2-citrate-hydroxo polynuclear stoichiometry. |  |
| `DEDUP-fd48f7cda37f7a35` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | +112.871 | generation 1: kept — Distinct Cu2-(citr)2-hydroxo polynuclear. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Distinct Cu3 hydroxo trinuclear cation. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. | Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 | generation 1: kept — CuCl(s) is a real chloride-region competitor at 100 mM Cl. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-487bcfa1c8c146d2` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu(s) reduced anchor. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |  |

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. | Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Distinct Fe(II) monohydroxo. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +202.623 | generation 1: kept — Distinct neutral Fe(II) dihydroxo aqueous species. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. | Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. |  |
| `DEDUP-17eabf3a090b1c87` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +47.602 | generation 1: kept — Distinct Fe(II)-citrate complex. |  |
| `DEDUP-c1005919640acd2c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 | generation 1: kept — Distinct Fe2-citrate-hydroxo dinuclear. |  |
| `DEDUP-d6dc259da7a8dad8` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 | generation 1: kept — Distinct protonated Fe(II)-citrate complex. |  |
| `DEDUP-cb0f7b97e4425385` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 | generation 1: kept — Distinct diprotonated Fe(II)-citrate complex. |  |
| `DEDUP-da02a76e2d197424` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 | generation 1: kept — Distinct Fe(II)-biscitrate protonated complex. |  |
| `DEDUP-cf1160dc9504eb2a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +30.023 | generation 1: kept — Distinct Fe(II)-monoglycinate. |  |
| `DEDUP-1d8f50d12d89192a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +65.581 | generation 1: kept — Distinct Fe(II)-bisglycinate. |  |
| `DEDUP-11491a5268fb9a13` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | +113.241 | generation 1: kept — Distinct Fe(II)-trisglycinate. |  |
| `DEDUP-d044b8c62b54c4be` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | -7.991 | generation 1: kept — Distinct Fe(II)-monoammine. |  |
| `DEDUP-801433485b3d9b5c` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | -12.842 | generation 1: kept — Distinct Fe(II)-diammine. |  |
| `DEDUP-fa69a3f29ec6cf8a` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | -15.297 | generation 1: kept — Distinct Fe(II)-triammine. |  |
| `DEDUP-40c8ded2bf5c101e` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | -15.696 | generation 1: kept — Distinct Fe(II)-tetraammine. |  |
| `DEDUP-ba9c4263c6e90448` | true | kept | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 | generation 1: kept — Distinct Fe(II)-monochloro. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. | Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. | Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.452 | generation 1: kept — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. |  |
| `DEDUP-b1eb803106b29936` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 | generation 1: kept — Distinct Fe(III)-citrate neutral complex. |  |
| `DEDUP-977369ffb378cf98` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |  |
| `DEDUP-0cc29ed24775130c` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |  |
| `DEDUP-c0bead80f3ce43c9` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 | generation 1: kept — Distinct protonated Fe(III)-citrate. |  |
| `DEDUP-d8f65b4a69e194ec` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +177.887 | generation 1: kept — Distinct Fe(III)-monoglycinate. |  |
| `DEDUP-9a10196b107ab93c` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +64.247 | generation 1: kept — Distinct protonated Fe(III)-glycinate. |  |
| `DEDUP-155d74fc42feb491` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +53.231 | generation 1: kept — Distinct Fe(III)-bisglycinate diprotonated. |  |
| `DEDUP-ebce5c1c1789032b` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 | generation 1: kept — Distinct Fe(III)-monochloro. |  |
| `DEDUP-690d5b958c105643` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | SRD-46 | +62.192 | generation 1: kept — Distinct Fe(III)-dichloro. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Distinct Fe3 hydroxo trinuclear cation. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Only Fe(VI) ferrate member; keep for redox coverage even if inactive. |  |
| `DEDUP-d961fca16f9215e2` | false | dropped | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: dropped — Anhydrous Fe3O4 explicitly excluded by user request. | Anhydrous Fe3O4 explicitly excluded by user request. |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-33d9f3e2d880f852` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe(s) reduced anchor. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. | Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |  |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water reference; required. | Water reference; required. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. | Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. | Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| aqueous | `Cu$+1:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) bis-glycinate complex, in scope at 10 mM glycine. | Distinct Cu(I) bis-glycinate complex, in scope at 10 mM glycine. |
| aqueous | `Cu$+1:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) diammine complex, real competitor at 100 mM ammonia. | Distinct Cu(I) diammine complex, real competitor at 100 mM ammonia. |
| aqueous | `Cu$+1:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) monochloro complex, in scope at 100 mM Cl. | Distinct Cu(I) monochloro complex, in scope at 100 mM Cl. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. | Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. | Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |
| aqueous | `Cu$+1:1 L4:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) trichloro complex, in scope. | Distinct Cu(I) trichloro complex, in scope. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. | Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. | Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. | Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. | Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species, distinct hydroxo state. | Neutral Cu(II) dihydroxo aqueous species, distinct hydroxo state. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — Distinct Cu(II) hydroxo anion [HCuO2]-. | Distinct Cu(II) hydroxo anion [HCuO2]-. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — Distinct Cu(II) cuprate [CuO2]2-. | Distinct Cu(II) cuprate [CuO2]2-. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu2(Citr)2]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu2-citrate dinuclear complex. | Distinct Cu2-citrate dinuclear complex. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu2-citrate hydroxo polynuclear. | Distinct Cu2-citrate hydroxo polynuclear. |
| aqueous | `Cu$+2:1 L1:1 H:1` | Cu | aqueous | `[Cu(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Cu-citrate complex. | Distinct protonated Cu-citrate complex. |
| aqueous | `Cu$+2:1 L2:1` | Cu | aqueous | `[Cu(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) monoglycinate. | Distinct Cu(II) monoglycinate. |
| aqueous | `Cu$+2:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) bis-glycinate. | Distinct Cu(II) bis-glycinate. |
| aqueous | `Cu$+2:1 L3:1` | Cu | aqueous | `[Cu(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) monoammine. | Distinct Cu(II) monoammine. |
| aqueous | `Cu$+2:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) diammine. | Distinct Cu(II) diammine. |
| aqueous | `Cu$+2:1 L3:3` | Cu | aqueous | `[Cu(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) triammine. | Distinct Cu(II) triammine. |
| aqueous | `Cu$+2:1 L3:4` | Cu | aqueous | `[Cu(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) tetraammine, dominant at 100 mM NH3. | Distinct Cu(II) tetraammine, dominant at 100 mM NH3. |
| aqueous | `Cu$+2:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) monochloro complex. | Distinct Cu(II) monochloro complex. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)(OH)]` | SRD-46 | kept | true | generation 1: kept — Distinct Cu2-citrate-hydroxo polynuclear stoichiometry. | Distinct Cu2-citrate-hydroxo polynuclear stoichiometry. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)]3-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu2-(citr)2-hydroxo polynuclear. | Distinct Cu2-(citr)2-hydroxo polynuclear. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu3 hydroxo trinuclear cation. | Distinct Cu3 hydroxo trinuclear cation. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. | Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. | Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) monohydroxo. | Distinct Fe(II) monohydroxo. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Distinct neutral Fe(II) dihydroxo aqueous species. | Distinct neutral Fe(II) dihydroxo aqueous species. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. | Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. | Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. | Distinct Fe(II) tetrahydroxo anion. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Citr)]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-citrate complex. | Distinct Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe2-citrate-hydroxo dinuclear. | Distinct Fe2-citrate-hydroxo dinuclear. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(II)-citrate complex. | Distinct protonated Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Fe | aqueous | `[Fe(Citr)H2]+` | SRD-46 | kept | true | generation 1: kept — Distinct diprotonated Fe(II)-citrate complex. | Distinct diprotonated Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Fe | aqueous | `[Fe(Citr)2H]3-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-biscitrate protonated complex. | Distinct Fe(II)-biscitrate protonated complex. |
| aqueous | `Fe$+2:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-monoglycinate. | Distinct Fe(II)-monoglycinate. |
| aqueous | `Fe$+2:1 L2:2` | Fe | aqueous | `[Fe(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-bisglycinate. | Distinct Fe(II)-bisglycinate. |
| aqueous | `Fe$+2:1 L2:3` | Fe | aqueous | `[Fe(Glyc)3]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-trisglycinate. | Distinct Fe(II)-trisglycinate. |
| aqueous | `Fe$+2:1 L3:1` | Fe | aqueous | `[Fe(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-monoammine. | Distinct Fe(II)-monoammine. |
| aqueous | `Fe$+2:1 L3:2` | Fe | aqueous | `[Fe(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-diammine. | Distinct Fe(II)-diammine. |
| aqueous | `Fe$+2:1 L3:3` | Fe | aqueous | `[Fe(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-triammine. | Distinct Fe(II)-triammine. |
| aqueous | `Fe$+2:1 L3:4` | Fe | aqueous | `[Fe(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-tetraammine. | Distinct Fe(II)-tetraammine. |
| aqueous | `Fe$+2:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II)-monochloro. | Distinct Fe(II)-monochloro. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. | Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. | Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. | Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. | Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. | Distinct Fe(III) tetrahydroxo anion. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Citr)]` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III)-citrate neutral complex. | Distinct Fe(III)-citrate neutral complex. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]+` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(III)-citrate. | Distinct protonated Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III)-monoglycinate. | Distinct Fe(III)-monoglycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | Fe | aqueous | `[Fe(Glyc)H]3+` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(III)-glycinate. | Distinct protonated Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | Fe | aqueous | `[Fe(Glyc)2H2]3+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III)-bisglycinate diprotonated. | Distinct Fe(III)-bisglycinate diprotonated. |
| aqueous | `Fe$+3:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III)-monochloro. | Distinct Fe(III)-monochloro. |
| aqueous | `Fe$+3:1 L4:2` | Fe | aqueous | `[Fe(Chlo)2]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III)-dichloro. | Distinct Fe(III)-dichloro. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe3 hydroxo trinuclear cation. | Distinct Fe3 hydroxo trinuclear cation. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Only Fe(VI) ferrate member; keep for redox coverage even if inactive. | Only Fe(VI) ferrate member; keep for redox coverage even if inactive. |
| aqueous | `L1:1` | — | — | `[Citric acid]` | SRD-46 | kept | true | generation 1: kept — Fully deprotonated citrate ligand reference. | Fully deprotonated citrate ligand reference. |
| aqueous | `L1:1 H:1` | — | — | `[HCitric acid]2-` | SRD-46 | kept | true | generation 1: kept — Distinct citrate protonation state. | Distinct citrate protonation state. |
| aqueous | `L1:1 H:2` | — | — | `[H2Citric acid]-` | SRD-46 | kept | true | generation 1: kept — Distinct citrate protonation state. | Distinct citrate protonation state. |
| aqueous | `L1:1 H:3` | — | — | `[H3Citric acid]` | SRD-46 | kept | true | generation 1: kept — Neutral citric acid reference. | Neutral citric acid reference. |
| aqueous | `L2:1` | — | — | `[Glycine]` | SRD-46 | kept | true | generation 1: kept — Deprotonated glycinate reference. | Deprotonated glycinate reference. |
| aqueous | `L2:1 H:1` | — | — | `[HGlycine]` | SRD-46 | kept | true | generation 1: kept — Neutral glycine zwitterion reference. | Neutral glycine zwitterion reference. |
| aqueous | `L2:1 H:2` | — | — | `[H2Glycine]+` | SRD-46 | kept | true | generation 1: kept — Protonated glycinium cation. | Protonated glycinium cation. |
| aqueous | `L3:1` | — | — | `[Ammonia]` | SRD-46 | kept | true | generation 1: kept — Neutral ammonia reference. | Neutral ammonia reference. |
| aqueous | `L3:1 H:1` | — | — | `[HAmmonia]+` | SRD-46 | kept | true | generation 1: kept — Ammonium cation reference. | Ammonium cation reference. |
| aqueous | `L4:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Chloride ion reference. | Chloride ion reference. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Elemental Cu(s) reduced anchor. | Elemental Cu(s) reduced anchor. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. | Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. | Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| solid | `Cu$+1:1 L4:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — CuCl(s) is a real chloride-region competitor at 100 mM Cl. | CuCl(s) is a real chloride-region competitor at 100 mM Cl. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | dropped | false | generation 1: dropped — Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe(s) reduced anchor. | Elemental Fe(s) reduced anchor. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | dropped | false | generation 1: dropped — Anhydrous Fe3O4 explicitly excluded by user request. | Anhydrous Fe3O4 explicitly excluded by user request. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. | Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. | Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous electrodeposition electrolyte design, water-rich, 25 C, I=0.1 m; the phase question is which phase FORMS in a single mM-scale pot with excess ligands, so retain distinct redox/complex members that can win their own region.
- Concentration regime: Cu(II)=Fe(III)=1 mM, citrate=glycine=10 mM, chloride=100 mM, ammonia=100 mM. This is far above the 1e-6 M corrosion convention: mono- and polynuclear metal-ligand complexes and mixed hydroxo-ligand species are all physically reachable and must be preserved as distinct competitors on the hull.
- Hydration policy: prefer hydrated solids where a hydrated form exists (Cu(OH)2, Fe(OH)2, Fe(OH)3); keep elemental metals (Cu, Fe) and Cu2O for the reduced regions.
- User-mandated exclusions: DROP anhydrous Fe2O3, Fe3O4, CuO, and FeOOH-type oxides (both Atlas and SRD-46 copies). These are explicitly excluded by the request; do not let them shadow the hydrated hydroxides.
- Counterion solids: keep CuCl(s) — chloride is 0.1 M and CuCl precipitation is a genuine competitor in the Cu(I) region. No carbonate chemistry is in scope.
- Atlas vs SRD-46 identical-composition pairs: these are the same physical state re-tabulated. Keep the SRD-46 copy when both exist and the mu values agree within ~10 kJ (SRD-46 is the internally consistent complex database used for the ligand set); otherwise keep the lower-mu member and note the spread. Cu+/[Cu]+ , Cu2+/[Cu]2+, Fe2+/[Fe]2+, Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, and the two [Fe(OH)2]+ entries all collapse this way.
- Cu(II) hydroxo chain: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+ are all distinct protonation/nuclearity states and each can dominate a pH slice — keep all.
- Mixed Cu2-citrate-hydroxo and Fe-citrate-hydroxo polynuclears are distinct stoichiometries at 10 mM citrate and 1 mM metal; keep every unique (nuclearity, protonation, hydroxo count) member.
- Cu2O has two copies with a ~7 kJ spread straddling zero — keep the SRD-46 copy (lower mu, consistent with the rest of the SRD-46 set).
- FeO4(2-) (ferrate) sits far above the O2 line at these conditions but is the only Fe(VI) member; keep it, it will simply be inactive.
- Gases and elemental references: no gas entries in this inventory; keep Cu(s) and Fe(s) as the reduced anchors.

## Element instructions

- **Cu**: Collapse Atlas/SRD-46 duplicates of identical composition to the SRD-46 copy when mu agrees within ~10 kJ (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O), keep CuCl(s) as a genuine chloride-region competitor, and drop the anhydrous CuO entries per the user exclusion while retaining Cu(OH)2(hydr.). Keep every distinct Cu(I)/Cu(II) hydroxo, chloride, ammine, glycinate, and citrate complex including the polynuclear Cu2 and Cu3 species — at 1 mM Cu with 10-100 mM ligands each is a real hull competitor and none are notational duplicates.
- **Fe**: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

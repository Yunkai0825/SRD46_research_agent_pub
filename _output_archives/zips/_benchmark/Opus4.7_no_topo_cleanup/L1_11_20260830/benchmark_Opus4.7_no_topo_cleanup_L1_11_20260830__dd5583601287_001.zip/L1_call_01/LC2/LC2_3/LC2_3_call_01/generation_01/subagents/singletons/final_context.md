## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous electrodeposition electrolyte design, water-rich, 25 C, I=0.1 m; the phase question is which phase FORMS in a single mM-scale pot with excess ligands, so retain distinct redox/complex members that can win their own region.
- Concentration regime: Cu(II)=Fe(III)=1 mM, citrate=glycine=10 mM, chloride=100 mM, ammonia=100 mM. This is far above the 1e-6 M corrosion convention: mono- and polynuclear metal-ligand complexes and mixed hydroxo-ligand species are all physically reachable and must be preserved as distinct competitors on the hull.
- Hydration policy: prefer hydrated solids where a hydrated form exists (Cu(OH)2, Fe(OH)2, Fe(OH)3); keep elemental metals (Cu, Fe) and Cu2O for the reduced regions.
- User-mandated exclusions: DROP anhydrous Fe2O3, Fe3O4, CuO, and FeOOH-type oxides (both Atlas and SRD-46 copies). These are explicitly excluded by the request; do not let them shadow the hydrated hydroxides.
- Counterion solids: keep CuCl(s) — chloride is 0.1 M and CuCl precipitation is a genuine competitor in the Cu(I) region. No carbonate chemistry is in scope.
- Atlas vs SRD-46 identical-composition pairs: these are the same physical state re-tabulated. Keep the SRD-46 copy when both exist and the mu values agree within ~10 kJ (SRD-46 is the internally consistent complex database used for the ligand set); otherwise keep the lower-mu member and note the spread. Cu+/[Cu]+ , Cu2+/[Cu]2+, Fe2+/[Fe]2+, Fe3+/[Fe]3+, [FeOH]2+/[Fe(OH)]2+, and the two [Fe(OH)2]+ entries all collapse this way.
- Cu(II) hydroxo chain: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+ are all distinct protonation/nuclearity states and each can dominate a pH slice — keep all.
- Mixed Cu2-citrate-hydroxo and Fe-citrate-hydroxo polynuclears are distinct stoichiometries at 10 mM citrate and 1 mM metal; keep every unique (nuclearity, protonation, hydroxo count) member.
- Cu2O has two copies with a ~7 kJ spread straddling zero — keep the SRD-46 copy (lower mu, consistent with the rest of the SRD-46 set).
- FeO4(2-) (ferrate) sits far above the O2 line at these conditions but is the only Fe(VI) member; keep it, it will simply be inactive.
- Gases and elemental references: no gas entries in this inventory; keep Cu(s) and Fe(s) as the reduced anchors.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition to the SRD-46 copy when mu agrees within ~10 kJ (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O), keep CuCl(s) as a genuine chloride-region competitor, and drop the anhydrous CuO entries per the user exclusion while retaining Cu(OH)2(hydr.). Keep every distinct Cu(I)/Cu(II) hydroxo, chloride, ammine, glycinate, and citrate complex including the polynuclear Cu2 and Cu3 species — at 1 mM Cu with 10-100 mM ligands each is a real hull competitor and none are notational duplicates.
- Fe: Drop anhydrous Fe2O3 (both Atlas and SRD-46 copies) and Fe3O4 and the SRD-46 FeO(OH) entry per the explicit user exclusion of Fe2O3/Fe3O4/FeOOH, keeping Fe(OH)3(hydr.), Fe(OH)2(hydr.), Fe(s), and ferrate [FeO4]2- as the only solid/high-valence anchors. Collapse Atlas/SRD-46 identical-composition aqueous duplicates (Fe2+, Fe3+, [Fe(OH)]2+, the two [Fe(OH)2]+ entries, the two Fe(OH)2(s) hydrated copies) to the SRD-46 copy when mu agrees within ~10 kJ, and keep every distinct Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex (mono- and polynuclear, protonated variants) as separate hull members at these mM ligand concentrations.

[Singletons: n=61]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -30.765 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | -2 | 94.036 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | -4 | 140.611 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +0 | 35.545 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 15.911 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +0 | 75.429 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | -3 | 112.871 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 202.623 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 47.602 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +1 | 30.023 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +0 | 65.581 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | -1 | 113.241 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | +2 | -7.991 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | +2 | -12.842 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | +2 | -15.297 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | +2 | -15.696 |
| Fe | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +2 | 177.887 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +3 | 64.247 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +3 | 53.231 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | SRD-46 | +1 | 62.192 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L3:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L3:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| — | aqueous | aqueous | `L4:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>Reviewing 61 singletons: drop Fe3O4 (anh.) per explicit user exclusion of anhydrous Fe oxides. Keep all others including elemental Cu/Fe, CuCl(s), all aqueous complexes, and ferrate.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 61 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Wait — my previous tool call was truncated; I need to send the proper JSON payload with all 61 decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 61 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to actually send full payload. Let me send the complete JSON with all 61 decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 61 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Sending the full payload with all 61 decisions explicitly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 61 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>The tool has recorded 61 verdicts. Providing final answer summary.</summary>

<answer>
All 61 singleton verdicts recorded. Summary:

**DROP (1):**
- Fe3O4 (anh.) [solid, `Fe$+2:1 Fe$+3:2 H:-8`, Atlas] — explicitly excluded by user (anhydrous Fe oxides Fe2O3/Fe3O4/FeOOH out of scope; Fe(OH)2(hydr.)/Fe(OH)3(hydr.) are the retained Fe hydroxide anchors).

**KEEP (60):** all remaining singletons, including:
- Aqueous solvent/ligand references (empty, citric acid protonation series, glycine series, ammonia/ammonium, chloride).
- All distinct Cu(I) and Cu(II) complexes: hydroxo mononuclear/polynuclear ([Cu(OH)2], [HCuO2]−, [CuO2]2−, [Cu3(OH)4]2+), all ammine (1–4), glycinate (Cu(I) and Cu(II)), chloride (Cu(I) mono/tris; Cu(II) mono), and every citrate mono/dinuclear/protonated/hydroxo variant — each is a distinct hull competitor at 1 mM Cu / 10–100 mM ligands.
- All distinct Fe(II) and Fe(III) complexes: hydroxo ([Fe(OH)]+, [Fe(OH)2], [Fe(OH)4]2−, [Fe(OH)4]−, [Fe3(OH)4]5+), citrate mono/dinuclear/protonated/hydroxo, glycinate (Fe(II) 1–3; Fe(III) protonated), ammine (1–4), and chloride mono/bis.
- Ferrate [FeO4]2− kept as the sole Fe(VI) member (will be inactive but preserves valence coverage).
- Solids: Cu(s), Fe(s) as elemental anchors, and CuCl(s) as a genuine Cu(I)–chloride precipitation competitor at 0.1 M Cl−.

No within-group duplicates existed (all singletons by construction); only the mandated anhydrous Fe3O4 exclusion produced a drop.
</answer>
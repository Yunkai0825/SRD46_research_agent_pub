# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    462.07
- elapsed_s (total):  462.07
- llm_iterations:     62
- llm_tool_calls:     47

- n_groups:           75
- n_multi_groups:     14
- n_singletons:       61
- n_decisions:        75
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Distinct nuclearity (dinuclear Cu2 vs mononuclear Cu) Cu(I)-chloride complexes; both are genuine competitors at 0.1 M chloride. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct mono- and dinuclear Cu(II) hydroxo species; both can dominate a pH slice at 1 mM Cu. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct nuclearities, both reachable at 1 mM Fe / 10 mM citrate. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference; required. |
| aqueous | `Cu$+1:1 L2:2` | yes | Distinct Cu(I) bis-glycinate complex, in scope at 10 mM glycine. |
| aqueous | `Cu$+1:1 L3:2` | yes | Distinct Cu(I) diammine complex, real competitor at 100 mM ammonia. |
| aqueous | `Cu$+1:1 L4:1` | yes | Distinct Cu(I) monochloro complex, in scope at 100 mM Cl. |
| aqueous | `Cu$+1:1 L4:3` | yes | Distinct Cu(I) trichloro complex, in scope. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) dihydroxo aqueous species, distinct hydroxo state. |
| aqueous | `Cu$+2:1 H:-3` | yes | Distinct Cu(II) hydroxo anion [HCuO2]-. |
| aqueous | `Cu$+2:1 H:-4` | yes | Distinct Cu(II) cuprate [CuO2]2-. |
| aqueous | `Cu$+2:1 L1:1` | yes | Distinct Cu2-citrate dinuclear complex. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Distinct Cu2-citrate hydroxo polynuclear. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Distinct protonated Cu-citrate complex. |
| aqueous | `Cu$+2:1 L2:1` | yes | Distinct Cu(II) monoglycinate. |
| aqueous | `Cu$+2:1 L2:2` | yes | Distinct Cu(II) bis-glycinate. |
| aqueous | `Cu$+2:1 L3:1` | yes | Distinct Cu(II) monoammine. |
| aqueous | `Cu$+2:1 L3:2` | yes | Distinct Cu(II) diammine. |
| aqueous | `Cu$+2:1 L3:3` | yes | Distinct Cu(II) triammine. |
| aqueous | `Cu$+2:1 L3:4` | yes | Distinct Cu(II) tetraammine, dominant at 100 mM NH3. |
| aqueous | `Cu$+2:1 L4:1` | yes | Distinct Cu(II) monochloro complex. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Distinct Cu2-citrate-hydroxo polynuclear stoichiometry. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Distinct Cu2-(citr)2-hydroxo polynuclear. |
| aqueous | `Cu$+2:3 H:-4` | yes | Distinct Cu3 hydroxo trinuclear cation. |
| aqueous | `Fe$+2:1 H:-1` | yes | Distinct Fe(II) monohydroxo. |
| aqueous | `Fe$+2:1 H:-2` | yes | Distinct neutral Fe(II) dihydroxo aqueous species. |
| aqueous | `Fe$+2:1 H:-4` | yes | Distinct Fe(II) tetrahydroxo anion. |
| aqueous | `Fe$+2:1 L1:1` | yes | Distinct Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Distinct Fe2-citrate-hydroxo dinuclear. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Distinct protonated Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Distinct diprotonated Fe(II)-citrate complex. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Distinct Fe(II)-biscitrate protonated complex. |
| aqueous | `Fe$+2:1 L2:1` | yes | Distinct Fe(II)-monoglycinate. |
| aqueous | `Fe$+2:1 L2:2` | yes | Distinct Fe(II)-bisglycinate. |
| aqueous | `Fe$+2:1 L2:3` | yes | Distinct Fe(II)-trisglycinate. |
| aqueous | `Fe$+2:1 L3:1` | yes | Distinct Fe(II)-monoammine. |
| aqueous | `Fe$+2:1 L3:2` | yes | Distinct Fe(II)-diammine. |
| aqueous | `Fe$+2:1 L3:3` | yes | Distinct Fe(II)-triammine. |
| aqueous | `Fe$+2:1 L3:4` | yes | Distinct Fe(II)-tetraammine. |
| aqueous | `Fe$+2:1 L4:1` | yes | Distinct Fe(II)-monochloro. |
| aqueous | `Fe$+3:1 H:-4` | yes | Distinct Fe(III) tetrahydroxo anion. |
| aqueous | `Fe$+3:1 L1:1` | yes | Distinct Fe(III)-citrate neutral complex. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Distinct protonated Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L2:1` | yes | Distinct Fe(III)-monoglycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Distinct protonated Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Distinct Fe(III)-bisglycinate diprotonated. |
| aqueous | `Fe$+3:1 L4:1` | yes | Distinct Fe(III)-monochloro. |
| aqueous | `Fe$+3:1 L4:2` | yes | Distinct Fe(III)-dichloro. |
| aqueous | `Fe$+3:3 H:-4` | yes | Distinct Fe3 hydroxo trinuclear cation. |
| aqueous | `Fe$+6:1 H:-8` | yes | Only Fe(VI) ferrate member; keep for redox coverage even if inactive. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate ligand reference. |
| aqueous | `L1:1 H:1` | yes | Distinct citrate protonation state. |
| aqueous | `L1:1 H:2` | yes | Distinct citrate protonation state. |
| aqueous | `L1:1 H:3` | yes | Neutral citric acid reference. |
| aqueous | `L2:1` | yes | Deprotonated glycinate reference. |
| aqueous | `L2:1 H:1` | yes | Neutral glycine zwitterion reference. |
| aqueous | `L2:1 H:2` | yes | Protonated glycinium cation. |
| aqueous | `L3:1` | yes | Neutral ammonia reference. |
| aqueous | `L3:1 H:1` | yes | Ammonium cation reference. |
| aqueous | `L4:1` | yes | Chloride ion reference. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) reduced anchor. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) is a real chloride-region competitor at 100 mM Cl. |
| solid | `Fe$+0:1` | yes | Elemental Fe(s) reduced anchor. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Anhydrous Fe3O4 explicitly excluded by user request. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Identical Cu(I) aqueous cation; mu agrees, prefer SRD-46 copy. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical Cu2+ aqueous species with equal mu; keep SRD-46 copy per plan. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Identical Fe2+ aqueous species; mu agrees exactly, keep SRD-46 copy per case guidance. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Same Fe(III) trihydroxo anion in different notation; keep SRD-46 (lower mu, internally consistent) and drop Atlas variant despite ~15 kJ spread. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Identical Fe3+ aqueous species; mu values match exactly, keep SRD-46 copy per plan. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same mononuclear species (mu within 1.7 kJ); keep SRD-46 copy. Dinuclear [Fe2(OH)2]4+ is a distinct nuclearity and retained. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Identical Fe(III) dihydroxo cation in both databases with mu agreeing within ~5.5 kJ; keep SRD-46 per case-specific rule. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O duplicate; keep SRD-46 copy (lower mu, consistent database) per case recommendation. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `CuO` | Atlas | dissolution | LC2 element review: Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Drop anhydrous CuO (both copies) per user exclusion; keep hydrated Cu(OH)2 with SRD-46 preferred as mu agrees within ~10 kJ. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Identical hydrated Fe(OH)2 solid state in both sources with mu within ~2 kJ; keep SRD-46 copy per policy. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Anhydrous Fe3O4 explicitly excluded by user request. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Kept SRD-46 hydrated Fe(OH)3 per case rec (SRD-46 preference, Atlas duplicate within ~10 kJ); dropped anhydrous Fe2O3 (both copies) and FeO(OH) per explicit user exclusion. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 55ecec466f344376afaf1e6b30625291
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup complete and consistent with the electrodeposition scenario. Atlas/SRD-46 identical-composition duplicates collapsed to the SRD-46 copy (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2, Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, [HFeO2]-/[Fe(OH)3]-, Fe(OH)2(hydr.), Fe(OH)3(hydr.)). User-mandated exclusions of anhydrous Fe2O3, Fe3O4, CuO, and FeOOH were applied to every copy; hydrated Cu(OH)2(s), Fe(OH)2(s), Fe(OH)3(s), Cu2O(s), CuCl(s), Cu(s), Fe(s) retained as solid/reduced anchors. Every distinct Cu(I)/Cu(II) and Fe(II)/Fe(III) hydroxo, citrate, glycinate, ammine, and chloride complex including polynuclear Cu2, Cu3, Fe2, Fe3 species preserved as hull competitors at mM ligand concentrations, and ferrate [FeO4]2- kept for redox coverage. No leftover duplicates or scope violations.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

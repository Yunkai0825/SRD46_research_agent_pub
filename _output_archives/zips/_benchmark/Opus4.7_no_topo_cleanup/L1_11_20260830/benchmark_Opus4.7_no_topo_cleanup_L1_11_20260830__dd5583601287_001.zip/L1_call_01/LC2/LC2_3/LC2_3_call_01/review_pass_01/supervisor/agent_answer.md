Deduplicated LC2 table committed final. Key resolutions:

- Atlas/SRD-46 identical-composition aqueous duplicates collapsed to the SRD-46 copy: Cu+, Cu2+, Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, and [HFeO2]-/[Fe(OH)3]- (the last kept SRD-46 despite ~15 kJ spread, as the internally consistent complex database).
- Solid duplicates collapsed to SRD-46: Cu2O, Cu(OH)2, Fe(OH)2(hydr.), Fe(OH)3(hydr.).
- User-mandated exclusions applied: anhydrous Fe2O3 (both Atlas and SRD-46), Fe3O4 (Atlas), SRD-46 FeO(OH), and anhydrous CuO (both copies) all dropped. Hydrated Cu(OH)2, Fe(OH)2, Fe(OH)3 retained as the oxide-region anchors.
- CuCl(s) retained as a genuine Cu(I)-chloride precipitation competitor at 0.1 M Cl.
- All distinct Cu(I/II) and Fe(II/III) hydroxo, citrate (mono/dinuclear, protonated variants), glycinate, ammine, and chloride complexes preserved, including polynuclear Cu2/Cu3 and Fe2/Fe3 species — each can win its own E-pH region at the mM metal / 10-100 mM ligand regime.
- Ferrate [FeO4]2- kept as the sole Fe(VI) member for redox coverage.
- Elemental Cu(s) and Fe(s) kept as reduced anchors.

No chemistry flags outstanding; table ready for Pourbaix construction.
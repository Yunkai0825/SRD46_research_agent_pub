[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition to the SRD-46 copy when mu agrees within ~10 kJ (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O), keep CuCl(s) as a genuine chloride-region competitor, and drop the anhydrous CuO entries per the user exclusion while retaining Cu(OH)2(hydr.). Keep every distinct Cu(I)/Cu(II) hydroxo, chloride, ammine, glycinate, and citrate complex including the polynuclear Cu2 and Cu3 species — at 1 mM Cu with 10-100 mM ligands each is a real hull competitor and none are notational duplicates.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 L4:2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-bf8f82a6d69a7e2c` | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | -2 | -74.200 | 2 |
| `DEDUP-5b52cb6f8bceab8e` | aqueous | `[Cu(Chlo)2]-` | SRD-46 | -1 | -34.589 | 1 |
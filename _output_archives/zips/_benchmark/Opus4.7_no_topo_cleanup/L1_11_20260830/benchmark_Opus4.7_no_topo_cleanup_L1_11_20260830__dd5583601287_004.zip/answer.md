## Answer

In a single pot holding 1 mM Cu(II) + 1 mM Fe(III) with 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, and 0.1 M NH₃ (25 °C, I = 0.1 m), and with the oxides Fe₂O₃, CuO, FeOOH, and Fe₃O₄ excluded so that hydrated Fe(OH)₃(s), Fe(OH)₂(s), Cu(OH)₂(s), and Cu₂O(s) are the only allowed solids, the two metals partition very differently across the E–pH field. Copper's aqueous face is sculpted by the four ligands into a pH-ordered sequence — Cl⁻ / citrate / glycine / ammonia / OH⁻ — while iron is dominated almost everywhere on its oxidised side by ferrihydrite, with citrate providing the only aqueous Fe(III) window below pH ≈ 6.3.

**Copper.** Metallic Cu(0) is the largest single region (topological measure 13.58), covering nearly the whole low-E half-plane; this shows how strongly the ligands stabilise oxidised Cu and drag its reduction line down from the "bare" Cu²⁺/Cu potential (+0.34 V) toward roughly 0 V in the neutral–alkaline plating window. Moving up in E, the dominant Cu(II) species walks with pH:
- pH < 3.2 free Cu²⁺, with a thin Cl⁻-stabilised Cu(I) sliver [Cu(Chlo)₂]⁻ just above the metal (log β = 6.06 for the Cu(I) dichloro complex);
- pH 3.2–6.0 citrate takes over completely, first as the mono-hydroxo dimer [Cu₂(Citr)₂(OH)]³⁻ (pH 3.2–4.0) and then the bis-hydroxo dimer [Cu₂(Citr)₂(OH)₂]⁴⁻ (measure 4.95), the crossover at pH 4.0 being a bridging-OH deprotonation of that dimer;
- pH 6–7.4 a brief chloride re-entry along the Cu(0) edge as [Cu(Chlo)₂]⁻;
- pH 7.4–10.8 the glycine bischelate [Cu(Glyc)₂] (log β₂ = 15.1, measure 5.30) — its lower boundary at E ≈ +0.02 V is exactly the Cu²⁺/Cu potential depressed by (RT/2F)·ln β₂ ≈ 0.44 V, which is the chemical origin of glycine's use as a mild plating additive;
- pH 10.8–11.55 the classic Cu(I) diammine [Cu(Ammo)₂]⁺ opens a narrow ammoniacal window between Cu(0) and Cu₂O(s);
- pH > 11.5 Cu(OH)₂(s) dominates until it re-dissolves as CuO₂²⁻ at pH 13.59.

The chemical story is that each ligand takes over exactly where its protonation state and formation constant beat the others on mass action: chloride at the extremes, citrate through the acidic-to-mid range (its μ-OH dimers absorb the proton chemistry), glycine in the physiological window (where both amine and carboxylate are deprotonated), and ammonia in the alkaline pocket (pKa 9.26).

**Iron.** Fe(0) sits only in the deep-reducing corner (upper edge E ≈ −0.54 V at pH 0 sloping to −0.92 V at pH 14 — essentially the Fe²⁺/Fe couple with a Nernstian pH shift). Above that line:
- Fe²⁺ owns pH < 4.04 (measure 4.65) — no ligand competes, because FeCl⁺ (log β = −0.20) and the Fe(II)–ammonia complexes (log β₁ ≈ +1.4) are far too weak at 0.1 M;
- citrate wins pH 4.04–6.36, first as [Fe(Citr)]⁻ (log β = 4.56) then as its μ-hydroxo dimer [Fe₂(Citr)₂(OH)₂]²⁻ near pH 6.

On the Fe(III) side ferrihydrite **Fe(OH)₃(s)** is the single biggest region (measure 7.16), stretching from pH ≈ 6.3 to 14 and from ~+0.03 V up to the ferrate line near +0.9–1.0 V. Because we removed Fe₂O₃/Fe₃O₄/FeOOH, the entire oxidised-Fe field collapses onto this one hydrated solid, which is the chemically correct outcome for a fresh, water-rich electrolyte where dehydrated oxides never nucleate. Aqueous Fe(III) survives only in a small acidic wedge: Fe³⁺ for pH < 1.46 above +0.77 V, then neutral [Fe(Citr)] (log β = 11.19) up to pH 1.89, then the anionic citrate dimer [Fe₂(Citr)₂(OH)₂]²⁻ (log β = 21.20) up to pH 4.08 — i.e. **citrate is the only ligand strong enough to hold Fe(III) soluble, and only below pH ≈ 6.3**. FeO₄²⁻ (ferrate, Fe(VI)) appears above +0.9 V, nearly pH-independent as expected for the high-order couple. No Fe(II)-Cl, Fe(II)-NH₃, or Fe(III)-glycine complex is dominant anywhere.

**Design implication for electrodeposition.** Copper and iron plate in very different windows: Cu(0) is accessible over almost the whole pH range at modest cathodic overpotential, and around pH 8–11 the glycine/ammonia stabilisation puts the Cu²⁺/Cu step in a narrow, well-defined ≈ 0 V band that is easy to control. Iron, in contrast, requires strongly reducing potentials (≲ −0.55 to −0.9 V) *and* is dominated by ferrihydrite over most of the neutral-to-alkaline plane — so a co-deposition electrolyte must live in the acidic-citrate window (pH ~2–5, above the ferrihydrite line) where citrate keeps Fe(III) soluble as [Fe(Citr)]⁻ / [Fe₂(Citr)₂(OH)₂]²⁻ and citrate/chloride keep Cu(II) soluble, so that both metals can be cathodically reduced without Fe(OH)₃(s) fouling the bath.

## Evidence
- **Copper topology:** 10 dominant labels, 13 connected regions, 26 boundaries, 14 internal + 10 boundary-limit junctions; disconnected labels [Cu(Glyc)₂], [Cu₂(Citr)₂(OH)₂]⁴⁻, [Cu(Chlo)₂]⁻ each with 2 regions. Largest measures: Cu(0) 13.58, [Cu(Glyc)₂] 5.30, [Cu₂(Citr)₂(OH)₂]⁴⁻ 4.95, Cu(OH)₂(s) 3.14.
- **Iron topology:** 11 dominant labels, 13 connected regions, 29 boundaries, 17 internal + 7 boundary-limit junctions; [Fe(Citr)]⁻ split into 3 disconnected regions. Largest measures: Fe(OH)₃(s) 7.16, Fe²⁺ 4.65, [Fe₂(Citr)₂(OH)₂]²⁻ 4.07 (Fe(III) dimer)+4.07 (Fe(II) dimer), [Fe(Citr)]⁻ 2.74, Fe(OH)₂(s) 0.31.
- **Key copper triple points (pH, E V_SHE):** Cu / Cu₂O(s) / [Cu(Ammo)₂]⁺ at (10.46, −0.141); Cu / [Cu(Ammo)₂]⁺ / [Cu(Glyc)₂] at (7.78, +0.016); Cu₂O(s) / Cu(OH)₂(s) / [Cu₂(Citr)₂(OH)₂]⁴⁻ at (11.55, +0.038); Cu₂O(s) / CuO₂²⁻ / Cu(OH)₂(s) at (13.59, −0.084); [Cu₂(Citr)₂(OH)₂]⁴⁻ / [Cu(Chlo)₂]⁻ / [Cu₂(Citr)₂(OH)]³⁻ at (4.00, +0.275); [Cu(Chlo)₂]⁻ / [Cu₂(Citr)₂(OH)]³⁻ / Cu²⁺ at (3.23, +0.381).
- **Key iron triple points:** Fe / Fe²⁺ / [Fe(Citr)]⁻ at (4.04, −0.553); Fe / Fe(OH)₂(s) / [Fe₂(Citr)₂(OH)₂]⁴⁻ at (10.49, −0.653); Fe(OH)₂(s) / [Fe₂(Citr)₂(OH)₂]⁴⁻ / Fe(OH)₃(s) at (10.49, −0.438); [Fe(Citr)]⁻ / Fe(OH)₃(s) / [Fe₂(Citr)₂(OH)₂]²⁻ at (6.36, +0.156); Fe²⁺ / [Fe(Citr)]⁻ / [Fe₂(Citr)₂(OH)₂]²⁻ at (4.08, +0.291); Fe²⁺ / [Fe(Citr)] / Fe³⁺ at (1.46, +0.772); Fe(OH)₃(s) / [Fe₂(Citr)₂(OH)₂]²⁻ / FeO₄²⁻ at (6.36, +0.975).
- **Ligand constants used by the solver** (LC2 table): Cu(I) [Cu(Chlo)₂]⁻ log β = 6.06; [Cu(Glyc)₂] log β₂ = 15.1; [Cu(Ammo)₂]⁺ (Cu(I)) log β₂ = 9.92; [Fe(Citr)]⁻ log β = 4.56; [Fe(Citr)] log β = 11.19; [Fe₂(Citr)₂(OH)₂]²⁻ log β = 21.20; Fe(OH)₃(s) log K_dis = −3.20; FeCl⁺ log β = −0.20; Fe(Glyc)²⁺ log β = −8.57. Boundary slopes recovered (e.g. FeO₄²⁻/Fe(OH)₃(s) ≈ −0.1 V/pH from (6.36, +0.975) to (14.0, +0.228)) match the expected 2H⁺/e⁻ Nernst behaviour.
- **Grid & convergence:** 1121 × 800 classified cells per element map (ΔpH = 0.0125, ΔE = 0.003125 V); no convergence flags on verdict regions; validator verdict = **supported**, disconnected-label counts and junction coordinates match the deterministic verdicts exactly.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png` — Cu E–pH diagram
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png` — Fe E–pH diagram
- `L1_call_01/solver/pourbaix_map_..._Cu.csv`, `..._Fe.csv` — integer classified label grids
- `L1_call_01/solver/topology_..._Cu.json`, `..._Fe.json` — region/boundary/junction topology
- `L1_call_01/solver/topology_..._Cu_verdict.md`, `..._Fe_verdict.md` — deterministic region catalogues
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv` — full speciation at every (pH, E) node
- `L1_call_01/thermodynamic_reference_constants.md` — LC2 log β table used by the solver
- `L1_call_01/l1_report.md` — full L1 report
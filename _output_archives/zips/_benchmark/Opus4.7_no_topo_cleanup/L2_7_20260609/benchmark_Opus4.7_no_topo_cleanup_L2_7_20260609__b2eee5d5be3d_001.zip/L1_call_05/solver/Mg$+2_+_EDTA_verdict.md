# Speciation Calculation Report: Mg$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Mg$+0 | Mg(s) | 0.00e+00 | metal |
| Mg$+2 | Mg2+ | 1.00e-03 | metal |
| L1 | EDTA | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -54.3372 | +0.0000 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +54.3372 |
| Mg2+ | aqueous | Mg$+2:+1 | — | -0.0000 | +0.0000 |
| [Mg(OH)]+ | aqueous | Mg$+2:+1 H:-1 | — | +65.0677 | +65.0677 |
| [Mg4(OH)4]4+ | aqueous | Mg$+2:+4 H:-4 | — | +227.7369 | +227.7369 |
| [Mg(EDTA)H]- | aqueous | Mg$+2:+1 L1:+1 H:+1 | — | -73.0014 | -73.0014 |
| [Mg(EDTA)]2- | aqueous | Mg$+2:+1 L1:+1 | — | -50.1706 | -50.1706 |
| [Mg(OH)2(s,brucite)] | dissolution | Mg$+2:+1 H:-2 | — | +96.2317 | +96.2317 |
| Mg | dissolution | Mg$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Mg(s) (Mg$+0) speciation ===
[Mg$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg2+ (Mg$+2) speciation ===
[Mg$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Mg(EDTA)]2-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Mg(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HEDTA3-             peak 66.7% at pH 6.0
  EDTA                peak 50.1% at pH 10.0
  [Mg(EDTA)]2-        peak 33.3% at pH 10.0

Dominant species by pH region:
  pH   6.0–  9.6  →  HEDTA3-
  pH   9.6– 10.0  →  EDTA

```
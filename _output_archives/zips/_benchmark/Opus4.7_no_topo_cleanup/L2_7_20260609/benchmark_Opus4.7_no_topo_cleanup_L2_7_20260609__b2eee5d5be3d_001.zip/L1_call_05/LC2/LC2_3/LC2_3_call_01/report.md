# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_05\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_05\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    57.60
- elapsed_s (total):  57.61
- llm_iterations:     14
- llm_tool_calls:     10

- n_groups:           9
- n_multi_groups:     2
- n_singletons:       7
- n_decisions:        9
- n_dropped:          1
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate of aqueous Mg2+; prefer SRD-46 over Atlas. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Mononuclear MgOH+ and tetranuclear Mg4(OH)4 4+ differ in nuclearity and charge; distinct species. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Sole member of empty-core group with valid aligned chemical potential. |
| aqueous | `L1:1` | yes | Unique EDTA4- species with valid mu_aligned_kJ. |
| aqueous | `L1:1 H:1` | yes | Unique HEDTA3- reference species with valid mu_aligned_kJ=0. |
| aqueous | `Mg$+2:1 L1:1` | yes | Unique Mg-EDTA complex with valid aligned potential. |
| aqueous | `Mg$+2:1 L1:1 H:1` | yes | Unique protonated Mg-EDTA complex with valid aligned potential. |
| solid | `Mg$+0:1` | yes | Sole Mg(s) phase from Atlas with valid mu_aligned_kJ. |
| solid | `Mg$+2:1 H:-2` | yes | Unique brucite Mg(OH)2(s) phase with valid aligned potential. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Mg2+; prefer SRD-46 over Atlas.) |

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Mg$+2 | M1 | [Mg]2+ | Mg | +2 |
| Mg$+0 | Atlas | Mg (ox +0) | Mg | +0 |

**Total species**: 11 | **Core groups**: 9 | **Multi-member groups**: 2 | **Cross-source groups**: 1

## 1. Aqueous / Dissolved Species

7 core groups, 9 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `L1:1` | [EDTA] | SRD-46 | -4 | 1x | +54.337 | 0 | — |
| 3 | `L1:1 H:1` | [HEDTA]3- | SRD-46 | -3 | 1x | +0.000 | 0 | — |
| 4 | `Mg$+2:1` | Mg2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 5 | `Mg$+2:1` | [Mg]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 6 | `Mg$+2:1 H:-1` | [Mg(OH)]+ | SRD-46 | +1 | 1x | +65.068 | 0 | — |
| 7 | `Mg$+2:1 H:-1` | [Mg4(OH)4]4+ | SRD-46 | +4 | 4x | +227.737 | 0 | — |
| 8 | `Mg$+2:1 L1:1` | [Mg(EDTA)]2- | SRD-46 | -2 | 1x | -50.171 | 0 | — |
| 9 | `Mg$+2:1 L1:1 H:1` | [Mg(EDTA)H]- | SRD-46 | -1 | 1x | -73.001 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Mg$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Mg2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Magnesic ion, colourless; DGf=-451.872 |
| 2 | [Mg]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Mg$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Mg2+ vs [Mg]2+) = 0.000 kJ/mol

#### 1.2  Core: `Mg$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Mg(OH)]+ | SRD-46 | +1 | 1x | +65.068 | 0 | id=[Mg$+2].[OH].[z+1]; mu_canon=+65.0677 |
| 2 | [Mg4(OH)4]4+ | SRD-46 | +4 | 4x | +227.737 | 0 | id=[Mg$+2]4.[OH]4.[z+4]; mu_canon=+227.7369 |

## 2. Solid / Dissolution Species

2 core groups, 2 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Mg$+0:1` | Mg | Atlas | +0 | 1x | +451.872 | 2 | — |
| 2 | `Mg$+2:1 H:-2` | [Mg(OH)2(s,brucite)] | SRD-46 | +0 | 1x | +96.232 | 0 | — |

## 3. Gas Species

*(No species in this section.)*

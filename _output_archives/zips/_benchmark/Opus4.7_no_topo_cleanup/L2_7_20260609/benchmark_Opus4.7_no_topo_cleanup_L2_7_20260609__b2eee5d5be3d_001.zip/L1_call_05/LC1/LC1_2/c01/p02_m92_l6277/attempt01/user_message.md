[Purpose: Evaluate Mg(II)-EDTA complexation at pH 8.5 for antiscale screening.]
[Tasks:
Model a solution containing Mg(II) at 1 mM with EDTA at 3 mM over pH 6-10 at 25 C and 0.1 m ionic strength. Report the metal-bound fraction and the free Mg(II) concentration at pH 8.5.
]
[Pair: pair_key=`m92_l6277`, metal_id=92, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal92_ligand6277_beta788_net4932`
[Screen report]
# Eq-map screen — m92_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand6277_beta812_net4932` | `[M] + [L] <=> [ML]` | vlm_108326@(25.0,0.1) = K+8.790 | 6 | +8.610 / +8.855 / +8.832 / +9.040 | vlm_108326@(25.0,0.1) = K+8.790 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal92_ligand6277_beta788_net4932` | `[ML] + [H] <=> [MHL]` | vlm_108342@(25.0,0.1) = K+4.000 | 2 | +3.850 / +3.925 / +3.925 / +4.000 | vlm_108342@(25.0,0.1) = K+4.000 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_05\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.72
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH to evaluate Mg-EDTA binding across pH 6-10.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_05\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Mg", "lhs": lambda s: s.total["Mg$+2"],        "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_6277"],  "value": 3e-3, "basis": "known"},
]
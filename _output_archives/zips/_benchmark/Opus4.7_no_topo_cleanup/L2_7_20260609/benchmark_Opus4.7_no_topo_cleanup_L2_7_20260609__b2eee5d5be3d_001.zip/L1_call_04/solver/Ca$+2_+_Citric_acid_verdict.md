# Speciation Calculation Report: Ca$+2 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca | Ca | 1.00e-03 | metal |
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| L1 | Citric acid | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(Citr)]- | aqueous | L1:+1 Ca$+2:+1 | — | -19.6915 | -19.6915 |
| [Ca(OH)2](s) | dissolution | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| CaO2 | dissolution | Ca$+2:+1 H:-4 | — | +429.1110 | +429.1110 |
| [CaH(Citric acid)](s) | dissolution | L1:+1 Ca$+2:+1 H:+1 | — | -65.0106 | -65.0106 |
| [Ca3(Citric acid)2](s) | dissolution | L1:+2 Ca$+2:+3 | — | -97.2020 | -97.2020 |
| Ca | dissolution | Ca$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 6.00: [Ca3(Citric acid)2](s) (5.26e-05 M)

## Speciation Analysis

```
=== Ca (Ca) speciation ===
[Ca]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  Ca2+                peak 15.9% at pH 6.0
  [Ca(Citr)]-         peak 76.7% at pH 10.0
  [Ca3(Citric acid)2](s)  peak 15.8% at pH 6.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Ca(Citr)]-

Crossover pH values:

=== Citric acid (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HCitric acid2-      peak 22.8% at pH 6.0
  Citric acid         peak 72.1% at pH 10.0
  [Ca(Citr)]-         peak 25.6% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  Citric acid

```
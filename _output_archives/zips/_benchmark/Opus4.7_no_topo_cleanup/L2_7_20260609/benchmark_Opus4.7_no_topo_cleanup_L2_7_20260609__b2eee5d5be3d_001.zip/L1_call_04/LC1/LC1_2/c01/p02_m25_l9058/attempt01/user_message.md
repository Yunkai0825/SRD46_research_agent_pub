[Purpose: Evaluate Ca(II)-citrate complexation at pH 8.5 for antiscale screening.]
[Tasks:
Model a solution containing Ca(II) at 1 mM with citrate at 3 mM over pH 6-10 at 25 C and 0.1 m ionic strength. Report the metal-bound fraction and the free Ca(II) concentration at pH 8.5.
]
[Pair: pair_key=`m25_l9058`, metal_id=25, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal25_ligand9058_beta732_net22102`
  - `metal25_ligand9058_beta283_net22102`
  - `metal25_ligand9058_beta624_net22102`
[Screen report]
# Eq-map screen — m25_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal25_ligand9058_beta779_net22102` | `[M] + [HL] <=> [MHL]` | vlm_157540@(25.0,0.1) = K+2.070 | 3 | +2.070 / +2.070 / +2.333 / +2.860 | vlm_157540@(25.0,0.1) = K+2.070 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal25_ligand9058_beta732_net22102` | `[M] + [H2L] <=> [MH2L]` | vlm_157545@(25.0,0.1) = K+1.000 | 1 | +1.000 / +1.000 / +1.000 / +1.000 | vlm_157545@(25.0,0.1) = K+1.000 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal25_ligand9058_beta283_net22102` | `[MHL(s)] <=> [M] + [H] + [L]` | vlm_157546@(25.0,0.0) = K-11.390 | 1 | -11.390 / -11.390 / -11.390 / -11.390 | vlm_157546@(25.0,0.0) = K-11.390 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal25_ligand9058_beta624_net22102` | `[M3L2(s)] <=> [M]^3 + [L]^2` | vlm_157547@(25.0,0.0) = K-17.030 | 1 | -17.030 / -17.030 / -17.030 / -17.030 | vlm_157547@(25.0,0.0) = K-17.030 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal25_ligand9058_beta812_net22102` | `[M] + [L] <=> [ML]` | vlm_157530@(25.0,0.1) = K+3.450 | 8 | +3.360 / +3.505 / +3.679 / +4.870 | vlm_157530@(25.0,0.1) = K+3.450 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

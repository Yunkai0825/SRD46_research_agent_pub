# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    81.51
- elapsed_s (total):  81.52
- llm_iterations:     15
- llm_tool_calls:     12

- n_groups:           11
- n_multi_groups:     2
- n_singletons:       9
- n_decisions:        11
- n_dropped:          3
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | Identical aqueous Ca2+ species with same charge and mu; keep SRD-46 per tie-break rule. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 Ca(OH)2 supersedes Atlas duplicate; per addendum prefer hydrated Ca(OH)2 over anhydrous CaO for aqueous near-room-T speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ (1.256); sole member. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | mu_aligned_kJ = 0.000 is valid (reference); sole member. |
| solid | `Ca$+0:1` | yes | Valid mu_aligned_kJ; sole member (elemental Ca). |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member (CaO2). |
| solid | `Ca$+2:1 L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ca$+2:3 L1:2` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Ca2+ species with same charge and mu; keep SRD-46 per tie-break rule.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 supersedes Atlas duplicate; per addendum prefer hydrated Ca(OH)2 over anhydrous CaO for aqueous near-room-T speciation.) |
| `CaO` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 supersedes Atlas duplicate; per addendum prefer hydrated Ca(OH)2 over anhydrous CaO for aqueous near-room-T speciation.) |

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ca$+2 | M1 | [Ca]2+ | Ca | +2 |
| Ca$+0 | Atlas | Ca (ox +0) | Ca | +0 |

**Total species**: 14 | **Core groups**: 11 | **Multi-member groups**: 2 | **Cross-source groups**: 2

## 1. Aqueous / Dissolved Species

6 core groups, 7 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Ca$+2:1` | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Ca$+2:1` | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 4 | `Ca$+2:1 H:-1` | [Ca(OH)]+ | SRD-46 | +1 | 1x | +74.428 | 0 | — |
| 5 | `Ca$+2:1 L1:1` | [Ca(Citr)]- | SRD-46 | -1 | 1x | -19.692 | 0 | — |
| 6 | `L1:1` | [Citric acid] | SRD-46 | -3 | 1x | +32.248 | 0 | — |
| 7 | `L1:1 H:1` | [HCitric acid]2- | SRD-46 | -2 | 1x | +0.000 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Ca$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Divalent calcium ion, colourless; DGf=-553.041 |
| 2 | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ca$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Ca2+ vs [Ca]2+) = 0.000 kJ/mol

## 2. Solid / Dissolution Species

5 core groups, 7 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Ca$+0:1` | Ca | Atlas | +0 | 1x | +553.041 | 2 | — |
| 2 | `Ca$+2:1 H:-2` | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | ref |
| 3 | `Ca$+2:1 H:-2` | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | +0.474 |
| 4 | `Ca$+2:1 H:-2` | CaO | Atlas | +0 | 1x | +186.062 | 0 | +55.870 |
| 5 | `Ca$+2:1 H:-4` | CaO2 | Atlas | +0 | 1x | +429.111 | -2 | — |
| 6 | `Ca$+2:1 L1:1 H:1` | [CaH(Citric acid)](s) | SRD-46 | +0 | 1x | -65.011 | 0 | — |
| 7 | `Ca$+2:3 L1:2` | [Ca3(Citric acid)2](s) | SRD-46 | +0 | 1x | -97.202 | 0 | — |

### Duplicated Groups

#### 2.1  Core: `Ca$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | id=[Ca$+2].[OH]2.[z+0]_(s); mu_canon=+130.1925 |
| 2 | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | ox=+2; Hydrated calcium oxide or hydroxide, whi; DGf=-896.757 |
| 3 | CaO | Atlas | +0 | 1x | +186.062 | 0 | ox=+2; Anhydrous calcium oxide, white, cubic; DGf=-604.170 |

> Δ(Ca(OH)2 vs [Ca(OH)2](s)) = 0.474 kJ/mol

> Δ(CaO vs [Ca(OH)2](s)) = 55.870 kJ/mol

## 3. Gas Species

*(No species in this section.)*

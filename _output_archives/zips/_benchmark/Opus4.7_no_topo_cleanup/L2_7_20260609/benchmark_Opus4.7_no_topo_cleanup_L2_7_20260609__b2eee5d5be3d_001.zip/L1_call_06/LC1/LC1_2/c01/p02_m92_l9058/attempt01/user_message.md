[Purpose: Evaluate Mg(II)-citrate complexation at pH 8.5 for antiscale screening.]
[Tasks:
Model a solution containing Mg(II) at 1 mM with citrate at 3 mM over pH 6-10 at 25 C and 0.1 m ionic strength. Report the metal-bound fraction and the free Mg(II) concentration at pH 8.5.
]
[Pair: pair_key=`m92_l9058`, metal_id=92, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal92_ligand9058_beta732_net22095`
[Screen report]
# Eq-map screen — m92_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand9058_beta732_net22095` | `[M] + [H2L] <=> [MH2L]` | vlm_157529@(25.0,0.1) = K+0.700 | 1 | +0.700 / +0.700 / +0.700 / +0.700 | vlm_157529@(25.0,0.1) = K+0.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal92_ligand9058_beta812_net22095` | `[M] + [L] <=> [ML]` | vlm_157515@(25.0,0.1) = K+3.430 | 7 | +3.330 / +3.510 / +3.701 / +4.890 | vlm_157515@(25.0,0.1) = K+3.430 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal92_ligand9058_beta779_net22095` | `[M] + [HL] <=> [MHL]` | vlm_157524@(25.0,0.1) = K+1.850 | 3 | +1.850 / +1.850 / +2.070 / +2.510 | vlm_157524@(25.0,0.1) = K+1.850 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Speciation Calculation Report: Mg$+2 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Mg$+0 | Mg(s) | 0.00e+00 | metal |
| Mg$+2 | Mg2+ | 1.00e-03 | metal |
| L1 | Citric acid | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Mg2+ | aqueous | Mg$+2:+1 | — | -0.0000 | +0.0000 |
| [Mg(OH)]+ | aqueous | Mg$+2:+1 H:-1 | — | +65.0677 | +65.0677 |
| [Mg4(OH)4]4+ | aqueous | Mg$+2:+4 H:-4 | — | +227.7369 | +227.7369 |
| [Mg(Citr)]- | aqueous | Mg$+2:+1 L1:+1 | — | -19.5774 | -19.5774 |
| [Mg(OH)2(s,brucite)] | dissolution | Mg$+2:+1 H:-2 | — | +96.2317 | +96.2317 |
| Mg | dissolution | Mg$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Mg(s) (Mg$+0) speciation ===
[Mg$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg2+ (Mg$+2) speciation ===
[Mg$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  Mg2+                peak 19.7% at pH 6.0
  [Mg(Citr)]-         peak 85.2% at pH 8.5

Dominant species by pH region:
  pH   6.0– 10.0  →  [Mg(Citr)]-

Crossover pH values:

=== Citric acid (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HCitric acid2-      peak 22.6% at pH 6.0
  Citric acid         peak 71.7% at pH 10.0
  [Mg(Citr)]-         peak 28.4% at pH 8.5

Dominant species by pH region:
  pH   6.0– 10.0  →  Citric acid

```
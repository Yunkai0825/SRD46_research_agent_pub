# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_06\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_06\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    75.28
- elapsed_s (total):  75.29
- llm_iterations:     15
- llm_tool_calls:     12

- n_groups:           8
- n_multi_groups:     2
- n_singletons:       6
- n_decisions:        8
- n_dropped:          1
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate: identical mononuclear Mg2+ aqueous cation; keep SRD-46 entry per source-preference rule. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite shared core ratio. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ (1.256); sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ (32.248); sole member of group. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (0.000, reference); sole member of group. |
| aqueous | `Mg$+2:1 L1:1` | yes | Valid mu_aligned_kJ (-19.577); sole member of group. |
| solid | `Mg$+0:1` | yes | Valid mu_aligned_kJ (451.872); sole member of group. |
| solid | `Mg$+2:1 H:-2` | yes | Valid mu_aligned_kJ (96.232); sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate: identical mononuclear Mg2+ aqueous cation; keep SRD-46 entry per source-preference rule.) |

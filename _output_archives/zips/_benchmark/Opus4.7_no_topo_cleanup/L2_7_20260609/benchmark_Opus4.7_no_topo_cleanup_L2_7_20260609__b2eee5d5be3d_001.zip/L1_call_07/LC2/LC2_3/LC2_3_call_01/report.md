# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_07\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_07\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    101.92
- elapsed_s (total):  101.93
- llm_iterations:     24
- llm_tool_calls:     17

- n_groups:           11
- n_multi_groups:     5
- n_singletons:       6
- n_decisions:        11
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+ ion; prefer SRD-46 per plan rule 1. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Identical mononuclear Zn(OH)+ species in both sources; keep SRD-46 per dedup rule 1. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [Zn(OH)3]- and [HZnO2]- are the same aqueous monomeric Zn(II) hydroxo species in different notation (differ by one H2O); kept SRD-46 entry with lower mu_aligned. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | [ZnO2]2- and [Zn(OH)4]2- are the same aqueous zincate species written in dehydrated vs hydrated notation; prefer SRD-46 critically-evaluated form. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (beta)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (amorphous)`, `[Zn(OH)2(s,epsilon)]` | Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ for EDTA4- anion; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (reference 0); sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu_aligned_kJ for Zn(OH)2(aq); sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu_aligned_kJ for Zn-EDTA complex; sole member. |
| solid | `Zn$+0:1` | yes | Valid mu_aligned_kJ for metallic Zn; sole solid member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+ ion; prefer SRD-46 per plan rule 1.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Identical mononuclear Zn(OH)+ species in both sources; keep SRD-46 per dedup rule 1.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([Zn(OH)3]- and [HZnO2]- are the same aqueous monomeric Zn(II) hydroxo species in different notation (differ by one H2O); kept SRD-46 entry with lower mu_aligned.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded ([ZnO2]2- and [Zn(OH)4]2- are the same aqueous zincate species written in dehydrated vs hydrated notation; prefer SRD-46 critically-evaluated form.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 forms; kept distinct polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |

# LC2_3 group [solid::Zn$+2:1 H:-2] agent response

## Final answer (text emitted by the agent)

Kept 5 species: Zn(OH)2 (alpha), Zn(OH)2 (beta), Zn(OH)2 (gamma), Zn(OH)2 (amorphous), and [Zn(OH)2(s,epsilon)] from SRD-46. Dropped anhydrous ZnO forms per addendum guidance (prefer hydrated oxyhydroxide for aqueous speciation) and the Atlas epsilon polymorph duplicate in favor of the SRD-46 reference value.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which species names in this group to KEEP after
deduplication, following the deduplication plan supplied in the user
message.  Return the list verbatim via `finalize_group_decision`.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_names": ["<exact species name>", ...],
   "rationale":  "<one sentence>"}

The names MUST match the `name` field shown in the user message
exactly.  After a successful `finalize_group_decision` you may emit
your answer block.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture the LLM's keep_names + rationale for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

Decide which species to KEEP per core-stoichiometry group; never re-merge or edit μ. Dropped rows are flagged `include=false` (kept for audit). A purpose-derived **addendum** may refine these defaults and wins on points it addresses. Members share a *core* ratio but may still be distinct species — judge by full formula and nuclearity, not the core alone.

1. **True duplicate = same species, different notation only**: identical phase, charge, AND nuclearity/`multiplier` ⇒ keep one. Prefer SRD-46; if both same-source, keep the lower `mu_aligned_kJ`. Species with very close mu may be a good starting point to inspect the species in detail.
2. **Keep distinct chemistry**: any difference in charge, oxidation state, phase, nuclearity (a polynuclear species is NOT the same as its mononuclear form even at equal core ratio), or hydration/polymorph is a *different* species — keep it. 
3. **Never empty a group** — at least one species must survive every group.
4. **When unsure, keep** — speciation needs full redox/phase/nuclearity coverage and a dropped species is unrecoverable. Defer polymorph/hydrate pruning to the addendum.

## Calculation-specific addendum

- Aqueous near-room-T speciation: for Zn solids differing only in hydration/polymorph, prefer the hydrated oxyhydroxide that precipitates from solution and drop the anhydrous oxide counterpart.
- Scope: retain the full ladder of Zn-EDTA and Zn-OH/protonation complexes; do not prune protonated/mixed-ligand EDTA forms even if minor at pH 8.5.


[Group: phase=solid core_label=Zn$+2:1 H:-2 n_species=9]

| name | source | charge | mu_aligned_kJ | multiplier |
|------|--------|-------:|--------------:|-----------:|
| `ZnO (inactive)` | Atlas | +0 | 54.869 | 1 |
| `ZnO (active)` | Atlas | +0 | 60.141 | 1 |
| `Zn(OH)2 (alpha)` | Atlas | +0 | 61.204 | 1 |
| `Zn(OH)2 (epsilon)` | Atlas | +0 | 62.501 | 1 |
| `Zn(OH)2 (gamma)` | Atlas | +0 | 63.810 | 1 |
| `Zn(OH)2 (beta)` | Atlas | +0 | 64.555 | 1 |
| `ZnO` | Atlas | +0 | 65.747 | 1 |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | +0 | 69.805 | 1 |
| `Zn(OH)2 (amorphous)` | Atlas | +0 | 69.915 | 1 |

## Assistant
<summary>Drop anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide). For epsilon polymorph duplicate, prefer SRD-46 over Atlas. Keep all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, epsilon, amorphous).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["Zn(OH)2 (a…')</tool_call>

## User
<tool_result>
OK — kept 5 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Finalized: kept 5 Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous, SRD-46 epsilon), dropped anhydrous ZnO forms per addendum and Atlas epsilon duplicate.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["Zn(OH)2 (a…')</tool_call>

## User
<tool_result>
OK — kept 5 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Finalized group decision.</summary>

<answer>
Kept 5 species: Zn(OH)2 (alpha), Zn(OH)2 (beta), Zn(OH)2 (gamma), Zn(OH)2 (amorphous), and [Zn(OH)2(s,epsilon)] from SRD-46. Dropped anhydrous ZnO forms per addendum guidance (prefer hydrated oxyhydroxide for aqueous speciation) and the Atlas epsilon polymorph duplicate in favor of the SRD-46 reference value.
</answer>

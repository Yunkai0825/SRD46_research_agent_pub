# Speciation Calculation Report: Zn$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | EDTA | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +0.0000 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +58.1614 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +218.0338 | +218.0338 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(EDTA)]2- | aqueous | L1:+1 Zn$+2:+1 | — | -94.1769 | -94.1769 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Zn(EDTA)]2-        peak 100.0% at pH 9.2

Dominant species by pH region:
  pH   6.0– 10.0  →  [Zn(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HEDTA3-             peak 66.7% at pH 6.0
  EDTA                peak 26.2% at pH 10.0
  [Zn(EDTA)]2-        peak 33.3% at pH 9.2

Dominant species by pH region:
  pH   6.0– 10.0  →  HEDTA3-

```
[Purpose: Evaluate Zn(II)-citrate complexation at pH 8.5 for antiscale screening.]
[Tasks:
Model a solution containing Zn(II) at 1 mM with citrate at 3 mM over pH 6-10 at 25 C and 0.1 m ionic strength. Report the metal-bound fraction and the free Zn(II) concentration at pH 8.5.
]
[Pair: pair_key=`m208_l9058`, metal_id=208, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m208_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand9058_beta840_net22198` | `[M] + [L]^2 <=> [ML2]` | vlm_157752@(25.0,0.1) = K+6.800 | 3 | +5.900 / +6.800 / +6.533 / +6.900 | vlm_157752@(25.0,0.1) = K+6.800 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand9058_beta374_net22198` | `[M]^2 + [L]^2 <=> [M2(H-1L)2] + [H]^2` | vlm_157762@(25.0,0.1) = K-2.900 | 1 | -2.900 / -2.900 / -2.900 / -2.900 | vlm_157762@(25.0,0.1) = K-2.900 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 3 | `metal208_ligand9058_beta812_net22198` | `[M] + [L] <=> [ML]` | vlm_157746@(25.0,0.1) = K+4.770 | 4 | +4.270 / +4.705 / +4.660 / +4.960 | vlm_157746@(25.0,0.1) = K+4.770 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal208_ligand9058_beta779_net22198` | `[M] + [HL] <=> [MHL]` | vlm_157757@(25.0,0.1) = K+2.970 | 3 | +2.490 / +2.900 / +2.787 / +2.970 | vlm_157757@(25.0,0.1) = K+2.970 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

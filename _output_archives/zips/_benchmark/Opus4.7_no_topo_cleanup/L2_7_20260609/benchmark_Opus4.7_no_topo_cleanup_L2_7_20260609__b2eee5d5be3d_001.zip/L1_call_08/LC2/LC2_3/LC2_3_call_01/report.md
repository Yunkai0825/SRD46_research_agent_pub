# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_08\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_08\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    66.11
- elapsed_s (total):  66.12
- llm_iterations:     20
- llm_tool_calls:     13

- n_groups:           13
- n_multi_groups:     5
- n_singletons:       8
- n_decisions:        13
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+ cation; prefer SRD-46 source per dedup rule 1. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Same mononuclear Zn(OH)+ cation in both sources; kept SRD-46 per notation-duplicate rule. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are the same aqueous monomeric Zn(II) hydroxo anion in different notation (differ by one H2O); keep SRD-46 entry. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same species in different notation ([ZnO2]2- = [Zn(OH)4]2- - 2 H2O); prefer SRD-46 critically-evaluated value. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2; keep distinct Zn(OH)2 polymorphs and prefer SRD-46 epsilon over the Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (reference); sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Zn$+0:1` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+ cation; prefer SRD-46 source per dedup rule 1.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Same mononuclear Zn(OH)+ cation in both sources; kept SRD-46 per notation-duplicate rule.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are the same aqueous monomeric Zn(II) hydroxo anion in different notation (differ by one H2O); keep SRD-46 entry.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same species in different notation ([ZnO2]2- = [Zn(OH)4]2- - 2 H2O); prefer SRD-46 critically-evaluated value.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2; keep distinct Zn(OH)2 polymorphs and prefer SRD-46 epsilon over the Atlas duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2; keep distinct Zn(OH)2 polymorphs and prefer SRD-46 epsilon over the Atlas duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2; keep distinct Zn(OH)2 polymorphs and prefer SRD-46 epsilon over the Atlas duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2; keep distinct Zn(OH)2 polymorphs and prefer SRD-46 epsilon over the Atlas duplicate.) |

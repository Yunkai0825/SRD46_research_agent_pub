# Speciation Calculation Report: Ca$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| L1 | EDTA | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -54.3372 | +0.0000 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +54.3372 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(EDTA)]2- | aqueous | L1:+1 Ca$+2:+1 | — | -60.7869 | -60.7869 |
| [Ca(OH)2](s) | dissolution | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| CaO2 | dissolution | Ca$+2:+1 H:-4 | — | +429.1110 | +429.1110 |
| Ca | dissolution | Ca$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Ca(EDTA)]2-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Ca(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HEDTA3-             peak 66.6% at pH 6.0
  EDTA                peak 50.1% at pH 10.0
  [Ca(EDTA)]2-        peak 33.3% at pH 10.0

Dominant species by pH region:
  pH   6.0–  9.6  →  HEDTA3-
  pH   9.6– 10.0  →  EDTA

```
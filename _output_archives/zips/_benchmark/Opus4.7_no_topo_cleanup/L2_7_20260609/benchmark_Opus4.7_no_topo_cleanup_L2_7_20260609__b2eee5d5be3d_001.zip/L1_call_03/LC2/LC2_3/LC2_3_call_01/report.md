# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    40.82
- elapsed_s (total):  40.83
- llm_iterations:     11
- llm_tool_calls:     7

- n_groups:           9
- n_multi_groups:     2
- n_singletons:       7
- n_decisions:        9
- n_dropped:          3
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | Identical Ca2+ aqueous ion in both sources with same mu; prefer SRD-46. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ (1.256); sole member of its group. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid mu_aligned_kJ (74.428); sole member of its group. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid mu_aligned_kJ (-60.787); sole member of its group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ (54.337); sole member of its group. |
| aqueous | `L1:1 H:1` | yes | mu_aligned_kJ=0.000 is a valid reference value; sole member of its group. |
| solid | `Ca$+0:1` | yes | Valid mu_aligned_kJ (553.041); sole member of its group. |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu_aligned_kJ (429.111); sole member of its group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (Identical Ca2+ aqueous ion in both sources with same mu; prefer SRD-46.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide.) |
| `CaO` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide.) |

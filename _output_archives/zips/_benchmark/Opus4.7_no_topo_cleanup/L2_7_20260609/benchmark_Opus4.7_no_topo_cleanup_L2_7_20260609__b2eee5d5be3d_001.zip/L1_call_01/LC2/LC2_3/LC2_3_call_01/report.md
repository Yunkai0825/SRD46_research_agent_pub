# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    78.65
- elapsed_s (total):  78.66
- llm_iterations:     27
- llm_tool_calls:     19

- n_groups:           19
- n_multi_groups:     7
- n_singletons:       12
- n_decisions:        19
- n_dropped:          7
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` | Identical Fe2+ aqueous ion in both sources with equal mu; keep SRD-46 per tiebreak. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | [Fe(OH)3]- and [HFeO2]- are the same aqueous Fe(II) hydroxo anion (charge -1, mononuclear) in differing notation; kept SRD-46 form. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate of Fe3+ aqueous ion; keep SRD-46 entry per plan. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | [Fe(OH)]2+ and [FeOH]2+ are notation duplicates of the same mononuclear species; keep SRD-46. Dinuclear [Fe2(OH)2]4+ is chemically distinct and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Identical species in both sources; prefer SRD-46 critically-evaluated value. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate: both are solid Fe(OH)2 with identical charge and nuclearity; prefer SRD-46 over Atlas per rule 1. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 Fe(OH)3 is the true duplicate of Atlas Fe(OH)3 (hydr.); prefer SRD source. Anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide that precipitates from solution. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; unique core stoichiometry. |
| solid | `Fe$+0:1` | yes | Valid mu_aligned_kJ; unique core stoichiometry for solid Fe. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | dedup: excluded (Identical Fe2+ aqueous ion in both sources with equal mu; keep SRD-46 per tiebreak.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded ([Fe(OH)3]- and [HFeO2]- are the same aqueous Fe(II) hydroxo anion (charge -1, mononuclear) in differing notation; kept SRD-46 form.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate of Fe3+ aqueous ion; keep SRD-46 entry per plan.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded ([Fe(OH)]2+ and [FeOH]2+ are notation duplicates of the same mononuclear species; keep SRD-46. Dinuclear [Fe2(OH)2]4+ is chemically distinct and retained.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate: both are solid Fe(OH)2 with identical charge and nuclearity; prefer SRD-46 over Atlas per rule 1.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 is the true duplicate of Atlas Fe(OH)3 (hydr.); prefer SRD source. Anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide that precipitates from solution.) |
| `Fe2O3` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 is the true duplicate of Atlas Fe(OH)3 (hydr.); prefer SRD source. Anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide that precipitates from solution.) |

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"], "value": 0.0,  "basis": "assumed"},
  {"id": "EDTA",  "lhs": lambda s: s.total["ligand_6277"], "value": 3e-3, "basis": "known"},
]
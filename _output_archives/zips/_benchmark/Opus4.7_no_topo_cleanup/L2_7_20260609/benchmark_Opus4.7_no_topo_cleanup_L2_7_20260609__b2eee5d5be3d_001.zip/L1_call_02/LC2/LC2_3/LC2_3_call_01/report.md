# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_7_FeCaMgZn_antiscale_EDTA_vs_citrate\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    104.57
- elapsed_s (total):  104.58
- llm_iterations:     29
- llm_tool_calls:     21

- n_groups:           20
- n_multi_groups:     7
- n_singletons:       13
- n_decisions:        20
- n_dropped:          7
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of aqueous Fe2+; prefer SRD-46 over Atlas at equal mu. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | Same species written in two notations (Fe(OH)3- vs HFeO2-); prefer SRD-46 critically evaluated value. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate (same charge, nuclearity, mu); prefer SRD-46. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | Mononuclear [FeOH]2+ duplicates [Fe(OH)]2+; keep SRD-46 version and retain the distinct dinuclear [Fe2(OH)2]4+. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Identical species; prefer SRD-46 over Atlas per rule 1. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate: same Fe(OH)2(s) species; prefer SRD-46 over Atlas per default rule. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 Fe(OH)3 preferred over Atlas duplicate (lower mu, preferred source); anhydrous Fe2O3 dropped per addendum since hydrated ferric hydroxide analogue is present. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (reference zero); sole member of group. |
| solid | `Fe$+0:1` | yes | Valid mu_aligned_kJ; sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Fe2+; prefer SRD-46 over Atlas at equal mu.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded (Same species written in two notations (Fe(OH)3- vs HFeO2-); prefer SRD-46 critically evaluated value.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate (same charge, nuclearity, mu); prefer SRD-46.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (Mononuclear [FeOH]2+ duplicates [Fe(OH)]2+; keep SRD-46 version and retain the distinct dinuclear [Fe2(OH)2]4+.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate: same Fe(OH)2(s) species; prefer SRD-46 over Atlas per default rule.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate (lower mu, preferred source); anhydrous Fe2O3 dropped per addendum since hydrated ferric hydroxide analogue is present.) |
| `Fe2O3` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate (lower mu, preferred source); anhydrous Fe2O3 dropped per addendum since hydrated ferric hydroxide analogue is present.) |

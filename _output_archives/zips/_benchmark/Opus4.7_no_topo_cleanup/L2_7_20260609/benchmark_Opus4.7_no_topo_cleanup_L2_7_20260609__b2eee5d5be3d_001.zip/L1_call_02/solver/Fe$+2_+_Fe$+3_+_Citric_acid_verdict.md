# Speciation Calculation Report: Fe$+2 + Fe$+3 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Fe$+0 | Fe(s) | 0.00e+00 | metal |
| Fe$+2 | Fe2+ | 1.00e-03 | metal |
| Fe$+3 | Fe3+ | 1.00e-03 | metal |
| Fe$+6 | Fe(+6) | 0.00e+00 | metal |
| L1 | Citric acid | 3.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Fe2+ | aqueous | Fe$+2:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]+ | aqueous | Fe$+2:+1 H:-1 | — | +55.9354 | +55.9354 |
| [Fe(OH)2] | aqueous | Fe$+2:+1 H:-2 | — | +202.6231 | +202.6231 |
| [Fe(OH)3]- | aqueous | Fe$+2:+1 H:-3 | — | +165.5231 | +165.5231 |
| [Fe(OH)4]2- | aqueous | Fe$+2:+1 H:-4 | — | +262.5538 | +262.5538 |
| [Fe(Citr)]- | aqueous | L1:+1 Fe$+2:+1 | — | -26.1246 | -26.1246 |
| [Fe2(Citr)2(OH)2]4- | aqueous | L1:+2 Fe$+2:+2 H:-2 | — | +32.0620 | +32.0620 |
| Fe3+ | aqueous | Fe$+3:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]2+ | aqueous | Fe$+3:+1 H:-1 | — | +15.5820 | +15.5820 |
| [Fe2(OH)2]4+ | aqueous | Fe$+3:+2 H:-2 | — | +16.3240 | +16.3240 |
| [Fe(OH)2]+ | aqueous | Fe$+3:+1 H:-2 | — | +40.6266 | +40.6266 |
| [Fe3(OH)4]5+ | aqueous | Fe$+3:+3 H:-4 | — | +35.9585 | +35.9585 |
| [Fe(OH)4]- | aqueous | Fe$+3:+1 H:-4 | — | +123.2861 | +123.2861 |
| [Fe(Citr)] | aqueous | L1:+1 Fe$+3:+1 | — | -63.8691 | -63.8691 |
| FeO42- | aqueous | Fe$+6:+1 H:-8 | — | +0.0000 | +0.0000 |
| [Fe(OH)2](s) | dissolution | Fe$+2:+1 H:-2 | — | +77.4534 | +77.4534 |
| [Fe(OH)3](s) | dissolution | Fe$+3:+1 H:-3 | — | +18.2646 | +18.2646 |
| Fe | dissolution | Fe$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 6.00: [Fe(OH)3](s) (1.00e-03 M)
- pH 9.85: [Fe(OH)3](s) (1.00e-03 M), [Fe(OH)2](s) (4.08e-05 M)

## Speciation Analysis

```
=== Fe(s) (Fe$+0) speciation ===
[Fe$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe2+ (Fe$+2) speciation ===
[Fe$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Fe(Citr)]-         peak 97.9% at pH 6.8
  [Fe2(Citr)2(OH)2]4-  peak 95.3% at pH 9.8
  [Fe(OH)2](s)        peak 35.9% at pH 10.0

Dominant species by pH region:
  pH   6.0–  8.7  →  [Fe(Citr)]-
  pH   8.7– 10.0  →  [Fe2(Citr)2(OH)2]4-

Crossover pH values:
  [Fe(Citr)]- ↔ [Fe2(Citr)2(OH)2]4-  at pH ≈ 8.60  (each ~49%)

=== Fe3+ (Fe$+3) speciation ===
[Fe$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Fe(OH)3](s)        peak 100.0% at pH 8.5

Dominant species by pH region:
  pH   6.0– 10.0  →  [Fe(OH)3](s)

Crossover pH values:

=== Fe(+6) (Fe$+6) speciation ===
[Fe$+6]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Citric acid (L1) speciation ===
[L1]_total = 3.00e-03 M

Species peaks:
  HCitric acid2-      peak 20.9% at pH 6.0
  Citric acid         peak 78.8% at pH 10.0
  [Fe(Citr)]-         peak 32.6% at pH 6.8
  [Fe2(Citr)2(OH)2]4-  peak 31.8% at pH 9.8

Dominant species by pH region:
  pH   6.0– 10.0  →  Citric acid

```
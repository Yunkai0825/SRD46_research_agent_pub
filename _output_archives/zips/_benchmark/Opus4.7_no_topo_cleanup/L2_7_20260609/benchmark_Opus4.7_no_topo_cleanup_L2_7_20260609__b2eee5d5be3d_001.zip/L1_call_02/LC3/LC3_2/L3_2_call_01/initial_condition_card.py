inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m stated"},
  {"id": "Fe3", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known", "note": "1 mM Fe(III)"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 3e-3, "basis": "known", "note": "3 mM citrate"},
]
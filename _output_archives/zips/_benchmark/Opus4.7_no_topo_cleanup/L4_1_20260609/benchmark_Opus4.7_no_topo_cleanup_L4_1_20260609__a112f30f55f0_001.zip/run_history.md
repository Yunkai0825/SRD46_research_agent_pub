# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='In a single solution containing 1 mM U(VI), 1 mM Th(IV), 5 mM 18-crown-6 and 5 mM EDTA at pH 5, 25 C and I=0.1 m, compute the joint speciation and show the dominant uranyl-crown and thorium-crown comp' |
|   7.210 | L1_start | call=1; purpose='Compute joint speciation of a single solution containing U(VI) and Th(IV) with 18-crown-6 and EDTA at pH 5, identifying the dominant uranyl-crown, thorium-crown and EDTA complexes.' |
| 654.620 | L1_end | call=1; elapsed_s=647.4; ran_ok=False; attempts=1 |
| 663.210 | L1_start | call=2; purpose='Compute single-point speciation of Th(IV) with 18-crown-6 and EDTA at pH 5 to identify the dominant thorium-crown and thorium-EDTA complexes.' |
| 1063.450 | L1_end | call=2; elapsed_s=400.2; ran_ok=True; attempts=1 |
| 1063.479 | L1_start | call=3; purpose='Compute single-point speciation of U(VI) (uranyl) with 18-crown-6 and EDTA at pH 5 to identify the dominant uranyl-crown and uranyl-EDTA complexes.' |
| 1799.637 | L1_end | call=3; elapsed_s=736.1; ran_ok=False; attempts=1 |
| 1842.304 | L0_end | elapsed_s=1842.2971601486206; iterations=6; timed_out=False |

## Answer

The joint U(VI)/Th(IV) + 18-crown-6 + EDTA pot could **not** be solved as a single mixed equilibrium in this database, and even split into two separate single-metal beakers only the **thorium half** produced numbers. Here is what the calculation actually shows, and what the chemistry says about the gaps.

**Thorium(IV) at pH 5 (computed).** Essentially **100 % of the 1 mM Th(IV) is locked up as the neutral 1:1 chelate [Th(EDTA)]**. The dominant-species envelope places [Th(EDTA)] as the sole dominant Th pool from pH ≈ 2.1 to ≈ 8.6, peaking at 100 % near pH 6.8 — pH 5 sits squarely on this plateau. The protonated chelate [Th(EDTA)H]⁺ is a negligible tail at pH 5 (its 99 % peak is at pH 0), free Th⁴⁺ is effectively zero, and the mononuclear/polynuclear hydroxo species (Th(OH)³⁺, Th₂(OH)₂⁶⁺, Th₆(OH)₁₄¹⁰⁺, Th(OH)₄) are all suppressed until Th(OH)₄ finally crosses [Th(EDTA)] at pH ≈ 8.5. Chemically this is exactly what one expects: Th⁴⁺ is a hard, very-high-charge-density cation, EDTA⁴⁻ is a hexadentate hard-donor chelate (log K ≈ 23), and EDTA is in 5× excess, so the chelate effect wins decisively over hydrolysis at pH 5 even though the bulk EDTA pool itself is still mostly HEDTA³⁻ at that pH.

**Thorium–18-crown-6.** The SRD-46 catalog **contains no Th–18-crown-6 stability constants**, so the crown was silently dropped from the Th model. Chemically this database gap is consistent with reality: 18-crown-6 has a cavity tuned for K⁺-sized cations (~1.4 Å), and Th⁴⁺ (~1.05 Å, charge 4+) is both too small and far too charge-dense for stable aqueous inclusion. Any Th–crown adduct, if it formed at all in water, would in any case be overwhelmed by EDTA. So the practical conclusion — "the crown does essentially nothing to thorium in this pot; EDTA owns it" — is firm, even though the "0 %" for the crown comes from the catalog rather than from a computed log β.

**Uranium(VI).** The uranyl half failed deterministically at the constraint-compilation stage on every attempt with the identical error
`system_catalog declares entries not in card: metals=['UO2']`,
i.e. the catalog labels uranyl as `UO2` but the free-energy card assembled for the run does not expose a metal entry under that token. No solver run occurred, so I will **not quote any uranyl fractions** — uranyl–crown, uranyl–EDTA, hydrolysis, or free UO₂²⁺ — because none were computed. Qualitatively one would expect UO₂(EDTA)²⁻ (and its protonated form UO₂(HEDTA)⁻) to dominate at pH 5 with 5 mM EDTA — uranyl–EDTA log K ≈ 13, and 18-crown-6 is geometrically poor for the linear *trans*-dioxo uranyl unit, which prefers equatorial hard-O donors — but that is chemical reasoning, not a number from this database.

**Net picture in the requested pot.** Of the four ligand fates that were asked for, only one is actually nailed down by the calculation: **all of the thorium goes to [Th(EDTA)]**, consuming ~1 mM of the 5 mM EDTA. The remaining ≥4 mM EDTA is available, and on chemical grounds will sequester the 1 mM uranyl as a uranyl–EDTA chelate, leaving the 5 mM 18-crown-6 essentially uncomplexed by either metal in aqueous solution at pH 5. The crown is the wrong ligand for both these hard, high-charge actinide centers in water; EDTA is the right one, and it is present in large enough excess to bind both metals simultaneously.

## Evidence
- Th(IV) at pH 5: "[Th(EDTA)] as the sole dominant Th species over pH 2.1–8.6, with its peak (100 %) at pH 6.8."
- Th(IV) hydrolysis crossover: "Th(OH)₄ does not become dominant until pH ≈ 8.5, where it crosses [Th(EDTA)] at ~50/50 (pH 8.52 crossover)."
- Th pool table (this calculation): "[Th(EDTA)] ≈ 1.00; [Th(EDTA)H]⁺ ≪ 0.01; hydrolysis ≈ 0; free Th⁴⁺ ≈ 0; Th–(18-crown-6) not in catalog."
- Solver convergence: "141/141 pH points converged" for the Th(IV)+EDTA sweep.
- Th–crown gap: "the SRD-46 catalog contains no thorium–18-crown-6 stability constants, so the only Th-binding ligand left in the model was EDTA."
- U(VI) failure (all three attempts): "ValueError: Constraint compilation failed: system_catalog declares entries not in card: metals=['UO2'] ligands=[]" — no uranyl numbers produced.

## Artifacts
- `L1_call_02/solver/Th$+4_+_EDTA_verdict.md` — Th(IV) dominant-species table and crossover pH values.
- `L1_call_02/solver/Th$+4_+_EDTA_envelope_Th$+4.csv` — Th dominant species vs pH.
- `L1_call_02/solver/Th$+4_+_EDTA_frac_metal.csv` — full Th fractional distribution vs pH.
- `L1_call_02/solver/Th$+4_+_EDTA_frac_ligand.csv` — EDTA fractional distribution vs pH.
- `L1_call_02/solver/Th$+4_+_EDTA_frac_Th.png`, `..._frac_L1.png`, `..._log_conc.png` — plots.
- `L1_call_02/solver/Th$+4_+_EDTA_run_params.json` — sweep parameters.
- U(VI) and the joint U/Th run: no artefacts (pipeline failed at constraint compilation; uranyl metal-label mismatch in the database build).
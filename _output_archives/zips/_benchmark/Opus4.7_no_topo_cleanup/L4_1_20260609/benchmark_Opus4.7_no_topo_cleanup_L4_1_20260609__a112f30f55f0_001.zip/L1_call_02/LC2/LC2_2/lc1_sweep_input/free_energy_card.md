# Free Energy Analysis Card

**System**: H, Th / 18-Crown-6, EDTA, Hydroxide ion
**Metals**: [Th]4+
**Ligands**: [EDTA]
**Generated**: 2026-06-09 19:57:18 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Th$+4 | Metal component: [Th]4+ |
| Th$+0 | Metal component from Atlas: Th(s) |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [EDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Th$+4 | [Th]4+ | +4 | 0.001 | NIST SRD-46 | metal_185 |
| Th$+0 | Th(s) | +0 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [EDTA] | -4 | 0.01 | [[H]4[L1]] | NIST SRD-46 | ligand_6277 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Th | Th$+4 | [Th]4+ | +4 | true | 2 |
| Th | Th$+0 | Th(s) | +0 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, 3, 3, 3, 3] | true |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Th$+4 | [Th]4+ | metal | [Th]4+(aq) | +0.0000 | R1 | Th | +4 | true |
| Th$+0 | Th(s) | metal | Th(s)(aq/s) | +733.0368 | RULE 1 | Th | +0 | false |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [EDTA] | ligand_canonical | [[H]4[L1]] | +0.0000 | R4 | *** | -4 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [EDTA] | [L1] -> [[H]4[L1]] | 4 | 1 | +10.1900 | +58.1614 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [EDTA] | 25.0 | 1 | *** | 6 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Th]4+ + [EDTA] | 25.0 | 0.1 | 5004 | 4 |
| [Th]4+ + *** | 25.0 | 3 | *** | 9 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by element (proton/ligand systems first), then valence (reference state first), ligand, and protonation (canonical HₓL reference first).

### 5.1 Aqueous Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [H].[OH].[z+0] | [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | SRD-46 | true |  |
| [[H][L1]].[z-3] | [[H][L1]].[z-3] | [HEDTA]3- | -3 | aqueous | +10.1900 | -58.1614 | +0.0000 | +0.0000 | [[H][L1]]:+1 | SRD-46 | true |  |
| [L1].[z-4] | [L1].[z-4] | [EDTA] | -4 | aqueous | +0.0000 | -0.0000 | +58.1614 | +58.1614 | [L1]:+1 | SRD-46 | true |  |
| Th$+4.z+4 | Atlas | Th4+ | +4 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Th$+4:+1 | Atlas | true | [DUPLICATE GROUP: Th$+4:1] Atlas: Th4+ |
| [Th$+4].[z+4] | [M1].[z+4] | [Th]4+ | +4 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Th$+4]:+1 | SRD-46 | true | [DUPLICATE GROUP: Th$+4:1] |
| [Th$+4].[OH].[z+3] | [M1].[OH].[z+3] | [Th(OH)]3+ | +3 | aqueous | -5.0000 | +28.5385 | +28.5385 | +28.5385 | [Th$+4]:+1, [OH]:+1 | SRD-46 | true |  |
| [Th$+4]3.[OH].[z+11] | [M1]3.[OH].[z+11] | [Th3(OH)]11+ | +11 | aqueous | -26.7000 | +152.3954 | +152.3954 | +152.3954 | [Th$+4]:+3, [OH]:+1 | SRD-46 | true |  |
| [Th$+4]2.[OH]2.[z+6] | [M1]2.[OH]2.[z+6] | [Th2(OH)2]6+ | +6 | aqueous | -5.0300 | +28.7097 | +28.7097 | +28.7097 | [Th$+4]:+2, [OH]:+2 | SRD-46 | true |  |
| [Th$+4]2.[OH]3.[z+5] | [M1]2.[OH]3.[z+5] | [Th2(OH)3]5+ | +5 | aqueous | -8.2000 | +46.8031 | +46.8031 | +46.8031 | [Th$+4]:+2, [OH]:+3 | SRD-46 | true |  |
| [Th$+4]3.[OH]3.[z+9] | [M1]3.[OH]3.[z+9] | [Th3(OH)3]9+ | +9 | aqueous | -77.7000 | +443.4877 | +443.4877 | +443.4877 | [Th$+4]:+3, [OH]:+3 | SRD-46 | true |  |
| [Th$+4].[OH]4.[z+0] | [M1].[OH]4.[z+0] | [Th(OH)4] | +0 | aqueous | -14.9000 | +85.0446 | +85.0446 | +85.0446 | [Th$+4]:+1, [OH]:+4 | SRD-46 | true |  |
| [Th$+4]2.[OH]5.[z+3] | [M1]2.[OH]5.[z+3] | [Th2(OH)5]3+ | +3 | aqueous | -123.7000 | +706.0415 | +706.0415 | +706.0415 | [Th$+4]:+2, [OH]:+5 | SRD-46 | true |  |
| [Th$+4]4.[OH]8.[z+8] | [M1]4.[OH]8.[z+8] | [Th4(OH)8]8+ | +8 | aqueous | -17.5500 | +100.1700 | +100.1700 | +100.1700 | [Th$+4]:+4, [OH]:+8 | SRD-46 | true |  |
| [Th$+4]6.[OH]14.[z+10] | [M1]6.[OH]14.[z+10] | [Th6(OH)14]10+ | +10 | aqueous | -33.9000 | +193.4908 | +193.4908 | +193.4908 | [Th$+4]:+6, [OH]:+14 | SRD-46 | true |  |
| [Th$+4].[[H][L1]].[z+1] | [M1].[[H][L1]].[z+1] | [Th(EDTA)H]+ | +1 | aqueous | +25.2000 | -143.8338 | -143.8338 | -143.8338 | [Th$+4]:+1, [[H][L1]]:+1 | SRD-46 | true |  |
| [Th$+4].[L1].[z+0] | [M1].[L1].[z+0] | [Th(EDTA)] | +0 | aqueous | +23.2000 | -132.4185 | -132.4185 | -132.4185 | [Th$+4]:+1, [L1]:+1 | SRD-46 | true |  |

### 5.2 Dissolution / Solid Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| Th$+4.OH4.z+0(s) | Atlas | ThO2 (anh.) | +0 | dissolution | -7.4624 | +42.5931 | +42.5931 | +42.5931 | Th$+4:+1 H:-4 | Atlas | true | Atlas: ThO2 (anh.) |
| Th$+4.OH4.z+0(s) | Atlas | ThO2 (hydr.) | +0 | dissolution | -16.0977 | +91.8806 | +91.8806 | +91.8806 | Th$+4:+1 H:-4 | Atlas | true | Atlas: ThO2 (hydr.) |
| Th$+0.z+0(s) | Atlas | Th | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +733.0368 | Th$+0:+1 | Atlas | true | Atlas: Th |
| Th$+0.z+0(s) | Atlas | Th | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +733.0368 | Th$+0:+1 | Atlas | true | Atlas: Th |

### 5.3 Gas Species

(No gas species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

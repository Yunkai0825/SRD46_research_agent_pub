# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    157.84
- elapsed_s (total):  157.85
- llm_iterations:     24
- llm_tool_calls:     20

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          2
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Th$+4:1` | `[Th]4+` | True duplicate; prefer SRD-46 over Atlas for identical Th4+ aqueous ion. |
| aqueous | `Th$+4:1 H:-1` | `[Th(OH)]3+`, `[Th2(OH)2]6+`, `[Th3(OH)3]9+` | Different nuclearities (mono-, di-, tri-nuclear Th hydroxo complexes) are distinct species and all retained. |
| solid | `Th$+0:1` | `Th` | Identical Th(s) duplicates from Atlas with same mu; keep one. |
| solid | `Th$+4:1 H:-4` | `ThO2 (hydr.)` | Per addendum, prefer hydrated Th oxyhydroxide over anhydrous ThO2 for aqueous 25°C speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/blank reference species with valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Free EDTA4- ligand, valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Protonated HEDTA3- reference (mu=0), retained. |
| aqueous | `Th$+4:1 H:-2` | yes | Th4(OH)8 polynuclear hydrolysis species, valid mu. |
| aqueous | `Th$+4:1 H:-4` | yes | Th(OH)4 neutral hydrolysis species, valid mu. |
| aqueous | `Th$+4:1 L1:1` | yes | Th-EDTA 1:1 complex, valid thermodynamics. |
| aqueous | `Th$+4:1 L1:1 H:1` | yes | Th(EDTA)H+ protonated complex, valid mu. |
| aqueous | `Th$+4:2 H:-3` | yes | Th2(OH)3 5+ hydrolysis species, valid mu. |
| aqueous | `Th$+4:2 H:-5` | yes | Th2(OH)5 3+ hydrolysis species, valid mu. |
| aqueous | `Th$+4:3 H:-1` | yes | Th3(OH) 11+ hydrolysis species, valid mu. |
| aqueous | `Th$+4:3 H:-7` | yes | Th6(OH)14 10+ polynuclear hydrolysis species, valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Th4+` | Atlas | aqueous | dedup: excluded (True duplicate; prefer SRD-46 over Atlas for identical Th4+ aqueous ion.) |
| `ThO2 (anh.)` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Th oxyhydroxide over anhydrous ThO2 for aqueous 25°C speciation.) |

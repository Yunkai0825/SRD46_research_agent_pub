# Speciation Calculation Report: Th$+4 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0180004 – 0.0399973 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Th$+0 | Th(s) | 0.00e+00 | metal |
| Th$+4 | Th4+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +0.0000 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +58.1614 |
| Th4+ | aqueous | Th$+4:+1 | — | -0.0000 | +0.0000 |
| [Th(OH)]3+ | aqueous | H:-1 Th$+4:+1 | — | +28.5385 | +28.5385 |
| [Th3(OH)]11+ | aqueous | H:-1 Th$+4:+3 | — | +152.3954 | +152.3954 |
| [Th2(OH)2]6+ | aqueous | H:-2 Th$+4:+2 | — | +28.7097 | +28.7097 |
| [Th2(OH)3]5+ | aqueous | H:-3 Th$+4:+2 | — | +46.8031 | +46.8031 |
| [Th3(OH)3]9+ | aqueous | H:-3 Th$+4:+3 | — | +443.4877 | +443.4877 |
| [Th(OH)4] | aqueous | H:-4 Th$+4:+1 | — | +85.0446 | +85.0446 |
| [Th2(OH)5]3+ | aqueous | H:-5 Th$+4:+2 | — | +706.0415 | +706.0415 |
| [Th4(OH)8]8+ | aqueous | H:-8 Th$+4:+4 | — | +100.1700 | +100.1700 |
| [Th6(OH)14]10+ | aqueous | H:-14 Th$+4:+6 | — | +193.4908 | +193.4908 |
| [Th(EDTA)H]+ | aqueous | L1:+1 H:+1 Th$+4:+1 | — | -143.8338 | -143.8338 |
| [Th(EDTA)] | aqueous | L1:+1 Th$+4:+1 | — | -132.4185 | -132.4185 |
| ThO2 (hydr.) | dissolution | H:-4 Th$+4:+1 | — | +91.8806 | +91.8806 |
| Th | dissolution | Th$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Th(s) (Th$+0) speciation ===
[Th$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Th4+ (Th$+4) speciation ===
[Th$+4]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  [Th(OH)4]           peak 100.0% at pH 12.5
  [Th(EDTA)H]+        peak 99.0% at pH 0.0
  [Th(EDTA)]          peak 100.0% at pH 6.8

Dominant species by pH region:
  pH   0.0–  2.1  →  [Th(EDTA)H]+
  pH   2.1–  8.6  →  [Th(EDTA)]
  pH   8.6– 14.0  →  [Th(OH)4]

Crossover pH values:
  [Th(OH)4] ↔ [Th(EDTA)]  at pH ≈ 8.52  (each ~50%)

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HEDTA3-             peak 93.8% at pH 8.9
  EDTA                peak 100.0% at pH 14.0
  [Th(EDTA)H]+        peak 19.8% at pH 0.0
  [Th(EDTA)]          peak 20.0% at pH 6.8

Dominant species by pH region:
  pH   0.0– 10.2  →  HEDTA3-
  pH  10.2– 14.0  →  EDTA

```
[Purpose: Compute single-point speciation of Th(IV) with 18-crown-6 and EDTA at pH 5 to identify the dominant thorium-crown and thorium-EDTA complexes.]
[Tasks:
Model a single pot containing Th(IV) at 1 mM with 18-crown-6 at 5 mM and EDTA at 5 mM at fixed pH 5, 25 C and ionic strength 0.1 m. Report the dominant Th(IV) species and the fractional distribution of thorium between the crown ether complex, the EDTA complex, hydrolysis products, and the free aquo ion.
]
[Pair: pair_key=`m185_l6277`, metal_id=185, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal185_ligand6277_beta966_net5004`
  - `metal185_ligand6277_beta423_net5004`
  - `metal185_ligand6277_beta812_net5004`
[Screen report]
# Eq-map screen — m185_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal185_ligand6277_beta966_net5004` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108528@(25.0,0.1) = K+7.040 | 1 | +7.040 / +7.040 / +7.040 / +7.040 | vlm_108528@(25.0,0.1) = K+7.040 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal185_ligand6277_beta423_net5004` | `[ML]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_108529@(25.0,0.1) = K+9.820 | 2 | +9.820 / +9.925 / +9.925 / +10.030 | vlm_108529@(25.0,0.1) = K+9.820 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal185_ligand6277_beta812_net5004` | `[M] + [L] <=> [ML]` | vlm_108521@(25.0,0.1) = K+23.200 | 2 | +22.300 / +22.750 / +22.750 / +23.200 | vlm_108521@(25.0,0.1) = K+23.200 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal185_ligand6277_beta788_net5004` | `[ML] + [H] <=> [MHL]` | vlm_108525@(25.0,0.1) = K+2.000 | 1 | +2.000 / +2.000 / +2.000 / +2.000 | vlm_108525@(25.0,0.1) = K+2.000 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task states I=0.1 m
  {"lhs": lambda s: s.total["U$+2"]       , "rhs": 0.001, "basis": "known"},  # U(VI) as uranyl 1 mM
  {"lhs": lambda s: s.total["U$+4"]       , "rhs": 0.0, "basis": "assumed"},  # suppress U(IV); task is U(VI)-only
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # EDTA 5 mM
  {"lhs": lambda s: s.total["ligand_9676"], "rhs": 0.005, "basis": "known"},  # 18-crown-6 5 mM
]
inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,           "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,        "value": 0.1,    "basis": "known", "note": "task states I=0.1 m"},
  {"id": "UO2", "lhs": lambda s: s.total["U$+2"],         "value": 1e-3,   "basis": "known", "note": "U(VI) as uranyl 1 mM"},
  {"id": "UIV", "lhs": lambda s: s.total["U$+4"],         "value": 0.0,    "basis": "assumed", "note": "suppress U(IV); task is U(VI)-only"},
  {"id": "EDTA","lhs": lambda s: s.total["ligand_6277"],  "value": 5e-3,   "basis": "known", "note": "EDTA 5 mM"},
  {"id": "CR6", "lhs": lambda s: s.total["ligand_9676"],  "value": 5e-3,   "basis": "known", "note": "18-crown-6 5 mM"},
]
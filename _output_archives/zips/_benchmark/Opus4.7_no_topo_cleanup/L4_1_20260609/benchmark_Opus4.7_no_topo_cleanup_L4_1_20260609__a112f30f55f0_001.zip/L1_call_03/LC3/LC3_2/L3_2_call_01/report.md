# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 18.08
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (5 known, 1 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task states I=0.1 m
  {"lhs": lambda s: s.total["U$+2"]       , "rhs": 0.001, "basis": "known"},  # U(VI) as uranyl 1 mM
  {"lhs": lambda s: s.total["U$+4"]       , "rhs": 0.0, "basis": "assumed"},  # suppress U(IV); task is U(VI)-only
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # EDTA 5 mM
  {"lhs": lambda s: s.total["ligand_9676"], "rhs": 0.005, "basis": "known"},  # 18-crown-6 5 mM
]
```

## Notes
Single-point pH 5 uranyl + EDTA + 18-crown-6; T, I, totals pinned per task. pH is the (degenerate) sweep axis, so not pinned here. U(IV) suppressed since task is U(VI) only.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
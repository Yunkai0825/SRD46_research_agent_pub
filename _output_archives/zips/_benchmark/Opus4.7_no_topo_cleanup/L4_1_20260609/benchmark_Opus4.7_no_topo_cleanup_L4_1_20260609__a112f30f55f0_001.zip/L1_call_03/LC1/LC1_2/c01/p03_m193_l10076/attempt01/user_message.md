[Purpose: Compute single-point speciation of U(VI) (uranyl) with 18-crown-6 and EDTA at pH 5 to identify the dominant uranyl-crown and uranyl-EDTA complexes.]
[Tasks:
Model a single pot containing U(VI) as the uranyl cation UO2(2+) at 1 mM with 18-crown-6 at 5 mM and EDTA at 5 mM at fixed pH 5, 25 C and ionic strength 0.1 m. Report the dominant uranyl species and the fractional distribution of U(VI) between the 18-crown-6 inclusion complex, the EDTA complex, uranyl hydrolysis/oxo species, and the free uranyl aquo ion. Note: please use whatever uranyl metal label the card builder exposes (UO2, UO2+2, or U) to avoid catalog/card label mismatch.
]
[Pair: pair_key=`m193_l10076`, metal_id=193, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal193_ligand10076_beta705_net27396`
  - `metal193_ligand10076_beta360_net27396`
[Screen report]
# Eq-map screen — m193_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal193_ligand10076_beta812_net27396` | `[M] + [L] <=> [ML]` | vlm_170569@(25.0,0.1) = K+12.500 | 7 | +12.000 / +12.300 / +12.429 / +13.400 | vlm_170569@(25.0,0.1) = K+12.500 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal193_ligand10076_beta705_net27396` | `[M]^6 + [L]^15 <=> [M6L15]` | vlm_170579@(25.0,0.0) = K+192.800 | 2 | +192.800 / +194.450 / +194.450 / +196.100 | vlm_170579@(25.0,0.0) = K+192.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal193_ligand10076_beta360_net27396` | `[MO2(s,am)] + [H2O]^2 <=> [M] + [OH]^4` | vlm_170582@(25.0,0.0) = K-56.200 | 3 | -56.200 / -55.600 / -55.367 / -54.300 | vlm_170582@(25.0,0.0) = K-56.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

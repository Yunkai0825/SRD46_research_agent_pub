[Purpose: Compute single-point speciation of U(VI) (uranyl) with 18-crown-6 and EDTA at pH 5 to identify the dominant uranyl-crown and uranyl-EDTA complexes.]
[Tasks:
Model a single pot containing U(VI) as the uranyl cation UO2(2+) at 1 mM with 18-crown-6 at 5 mM and EDTA at 5 mM at fixed pH 5, 25 C and ionic strength 0.1 m. Report the dominant uranyl species and the fractional distribution of U(VI) between the 18-crown-6 inclusion complex, the EDTA complex, uranyl hydrolysis/oxo species, and the free uranyl aquo ion. Note: please use whatever uranyl metal label the card builder exposes (UO2, UO2+2, or U) to avoid catalog/card label mismatch.
]
[Pair: pair_key=`m193_l6277`, metal_id=193, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal193_ligand6277_beta427_net5007`
  - `metal193_ligand6277_beta966_net5007`
  - `metal193_ligand6277_beta423_net5007`
[Screen report]
# Eq-map screen — m193_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal193_ligand6277_beta427_net5007` | `[M(OH)L]^2 <=> [M2(OH)2L2]` | vlm_108536@(25.0,0.1) = K+2.900 | 1 | +2.900 / +2.900 / +2.900 / +2.900 | vlm_108536@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal193_ligand6277_beta812_net5007` | `[M] + [L] <=> [ML]` | vlm_108531@(25.0,0.1) = K+25.700 | 3 | +23.200 / +25.700 / +24.900 / +25.800 | vlm_108531@(25.0,0.1) = K+25.700 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal193_ligand6277_beta966_net5007` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108534@(25.0,0.1) = K+4.720 | 1 | +4.720 / +4.720 / +4.720 / +4.720 | vlm_108534@(25.0,0.1) = K+4.720 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal193_ligand6277_beta423_net5007` | `[ML]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_108535@(25.0,0.1) = K+6.530 | 1 | +6.530 / +6.530 / +6.530 / +6.530 | vlm_108535@(25.0,0.1) = K+6.530 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

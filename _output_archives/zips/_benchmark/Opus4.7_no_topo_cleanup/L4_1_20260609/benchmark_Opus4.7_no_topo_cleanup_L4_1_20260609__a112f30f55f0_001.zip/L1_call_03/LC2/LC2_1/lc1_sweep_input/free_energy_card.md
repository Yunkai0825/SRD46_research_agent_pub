# Free Energy Analysis Card

**System**: H, UO2 / 18-Crown-6, EDTA, Hydroxide ion
**Metals**: [U]4+, [UO_[]22+
**Ligands**: [EDTA]
**Generated**: 2026-06-09 20:12:47 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [U]4+ |
| M2 | Metal component: [UO_[]22+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [EDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [U]4+ | +4 | 0.001 | NIST SRD-46 | metal_193 |
| M2 | [UO_[]22+ | +2 | 0.001 | NIST SRD-46 | metal_195 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [EDTA] | -4 | 0.01 | [[H]4[L1]] | NIST SRD-46 | ligand_6277 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| U | M2 | [UO_[]22+ | +2 | true | 2 |
| U | M1 | [U]4+ | +4 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, 3, 3, 3, 3] | true |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [U]4+ | metal | [U]4+(aq) | +0.0000 | R1 | U | +4 | false |
| M2 | [UO_[]22+ | metal | [UO_[]22+(aq) | +0.0000 | R1 | U | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [EDTA] | ligand_canonical | [[H]4[L1]] | +0.0000 | R4 | *** | -4 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [EDTA] | [L1] -> [[H]4[L1]] | 4 | 1 | +9.9400 | +56.7345 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [EDTA] | 25.0 | 1 | *** | 6 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [U]4+ + [EDTA] | 25.0 | 0.1 | 5007 | 4 |
| [U]4+ + *** | 25.0 | 0~0.1 | *** | 3 |
| [UO_[]22+ + [EDTA] | 25.0 | 1 | 5014 | 6 |
| [UO_[]22+ + *** | 25.0 | 0.1 | *** | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [EDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z-3] | [HEDTA]3- | -3 | aqueous | +9.9400 | -56.7345 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_108233 | *** |
| [L1].[z-4] | [EDTA] | -4 | aqueous | +0.0000 | -0.0000 | +56.7345 | +56.7345 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [U]4+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+4] | [U]4+ | +4 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [U]4+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1].[z+0] | [U(EDTA)] | +0 | aqueous | +25.7000 | -146.6877 | -146.6877 | -146.6877 | [M1]:+1, [L1]:+1 | vlm_108531 | *** |

#### [U]4+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+3] | [U(OH)]3+ | +3 | aqueous | -1.5000 | +8.5615 | +8.5615 | +8.5615 | [M1]:+1, [OH]:+1 | vlm_170569 | *** |
| [M1]6.[OH]15.[z+9] | [U6(OH)15]9+ | +9 | aqueous | -17.2000 | +98.1723 | +98.1723 | +98.1723 | [M1]:+6, [OH]:+15 | vlm_170579 | *** |

#### [UO_[]22+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [UO_[]22+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [UO_[]22+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2]2.[L1]2.[z-4] | [UO_[2(EDTA)]24- | -4 | aqueous | +26.7700 | -152.7949 | -152.7949 | -152.7949 | [M2]:+2, [L1]:+2 | vlm_108547, vlm_108549 | *** |
| [M2]2.[L1].[z+0] | [UO_[2(EDTA)] | +0 | aqueous | +17.8700 | -101.9965 | -101.9965 | -101.9965 | [M2]:+2, [L1]:+1 | vlm_108547 | *** |

#### [UO_[]22+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [UO_[(OH)]+ | +1 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M2]:+1, [OH]:+1 | vlm_170604 | *** |
| [M2]2.[OH]2.[z+2] | [UO_[2(OH)]22+ | +2 | aqueous | -6.3100 | +36.0155 | +36.0155 | +36.0155 | [M2]:+2, [OH]:+2 | vlm_170611 | *** |
| [M2]3.[OH]5.[z+1] | [UO_[3(OH)]5+ | +1 | aqueous | -17.4000 | +99.3138 | +99.3138 | +99.3138 | [M2]:+3, [OH]:+5 | vlm_170627 | *** |
| [M2]3.[OH]4.[z+2] | [UO_[3(OH)]42+ | +2 | aqueous | -98.7000 | +563.3492 | +563.3492 | +563.3492 | [M2]:+3, [OH]:+4 | vlm_170620 | *** |
| [M2]4.[OH]7.[z+1] | [UO_[4(OH)]7+ | +1 | aqueous | -171.7000 | +980.0107 | +980.0107 | +980.0107 | [M2]:+4, [OH]:+7 | vlm_170639 | *** |

### 5.2 Dissolution / Solid Species

(No dissolution / solid species species in this system.)

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 25 |
| Included in calculation | 25 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 10 |
| Unresolved (no species in card) | 15 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_108257 | [<H+><EDTA>] + [<H+>] <=> [<H+>2<EDTA>] | +6.1900 | 25.0 | 1.000 | yes | — |
| 2 | vlm_108291 | [<H+>4<EDTA>] + [<H+>] <=> [<H+>5<EDTA>] | -1.4000 | 25.0 | 1.000 | yes | — |
| 3 | vlm_108295_patched | [<H+>5<EDTA>] + [<H+>] <=> [<H+>6<EDTA>] | -0.4000 | 25.0 | 1.000 | yes | — |
| 4 | vlm_108233_patched | [<H+>] + [<EDTA>] <=> [<H+><EDTA>] | +9.9400 | 25.0 | 1.000 | yes | — |
| 5 | vlm_108274 | [<H+>2<EDTA>] + [<H+>] <=> [<H+>3<EDTA>] | +2.5200 | 25.0 | 1.000 | yes | — |
| 6 | vlm_108284 | [<H+>3<EDTA>] + [<H+>] <=> [<H+>4<EDTA>] | +2.0200 | 25.0 | 1.000 | yes | — |
| 7 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 8 | vlm_108536 | [<U4+>(<O<H+>>)<EDTA>]^2 <=> [<U4+>2(<O<H+>>)2<EDTA>2] | +2.9000 | 25.0 | 0.100 | yes | — |
| 9 | vlm_108531 | [<EDTA>] + [<U4+>] <=> [<U4+><EDTA>] | +25.7000 | 25.0 | 0.100 | yes | [U(EDTA)] |
| 10 | vlm_108534 | [<H+>] + [<U4+>(<O<H+>>)<EDTA>] <=> [H+2O] + [<U4+><EDTA>] | +4.7200 | 25.0 | 0.100 | yes | — |
| 11 | vlm_108535 | [H+2O]^2 + [<U4+><EDTA>]^2 <=> [<H+>]^2 + [<U4+>2(<O<H+>>)2<EDTA>2] | +6.5300 | 25.0 | 0.100 | yes | — |
| 12 | vlm_170569 | [<OH+->] + [<U4+>] <=> [<U4+><OH+->] | +12.5000 | 25.0 | 0.100 | yes | [U(OH)]3+ |
| 13 | vlm_170579 | [<OH+->]^15 + [<U4+>]^6 <=> [<U4+>6<OH+->15] | +192.8000 | 25.0 | 0.000 | yes | [U6(OH)15]9+ |
| 14 | vlm_170582 | [H+2O]^2 + [<U4+>O2(s,am)] <=> [<U4+>] + [O<H+>]^4 | -56.2000 | 25.0 | 0.000 | yes | — |
| 15 | vlm_108547_patched | [<EDTA>] + [<UO_[22+>]^2 <=> [<UO_[22+>2<EDTA>] | +17.8700 | 25.0 | 1.000 | yes | — |
| 16 | vlm_108548 | [<H+>] + [<UO_[22+>2(<O<H+>>)<EDTA>] <=> [H+2O] + [<UO_[22+>2<EDTA>] | +4.8100 | 25.0 | 1.000 | yes | — |
| 17 | vlm_108549 | [<EDTA>] + [<UO_[22+>2<EDTA>] <=> [<UO_[22+>2<EDTA>2] | +8.9000 | 25.0 | 1.000 | yes | [UO_[2(EDTA)]24- |
| 18 | vlm_108550 | [H+2O]^4 + [<EDTA>]^2 + [<UO_[22+>]^4 <=> [<H+>]^4 + [<UO_[22+>4(<O<H+>>)4<EDTA>2] | +15.3400 | 25.0 | 1.000 | yes | — |
| 19 | vlm_108551 | [H+2O]^4 + [<EDTA>]^3 + [<UO_[22+>]^6 <=> [<H+>]^4 + [<UO_[22+>6(<O<H+>>)4<EDTA>3] | +34.3000 | 25.0 | 1.000 | yes | — |
| 20 | vlm_108543_patched | [<H+><EDTA>] + [<UO_[22+>] <=> [<UO_[22+><H+><EDTA>] | +7.4000 | 25.0 | 1.000 | yes | — |
| 21 | vlm_170627 | [<OH+->]^5 + [<UO_[22+>]^3 <=> [<UO_[22+>3<OH+->5] | +52.6000 | 25.0 | 0.100 | yes | [UO_[3(OH)]5+ |
| 22 | vlm_170604 | [<OH+->] + [<UO_[22+>] <=> [<UO_[22+><OH+->] | +7.7000 | 25.0 | 0.100 | yes | [UO_[(OH)]+ |
| 23 | vlm_170639 | [<OH+->]^7 + [<UO_[22+>]^4 <=> [<UO_[22+>4<OH+->7] | -73.7000 | 25.0 | 0.100 | yes | [UO_[4(OH)]7+ |
| 24 | vlm_170611 | [<OH+->]^2 + [<UO_[22+>]^2 <=> [<UO_[22+>2<OH+->2] | +21.6900 | 25.0 | 0.100 | yes | [UO_[2(OH)]22+ |
| 25 | vlm_170620 | [<OH+->]^4 + [<UO_[22+>]^3 <=> [<UO_[22+>3<OH+->4] | -42.7000 | 25.0 | 0.100 | yes | [UO_[3(OH)]42+ |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

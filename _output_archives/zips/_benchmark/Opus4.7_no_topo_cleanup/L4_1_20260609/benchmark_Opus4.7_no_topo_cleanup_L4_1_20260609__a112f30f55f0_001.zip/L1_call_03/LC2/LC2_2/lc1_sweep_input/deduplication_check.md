# Deduplication Check: Free Energy Analysis Card

Species from **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| U$+2 | M2 | [UO_[]22+ | U | +2 |
| U$+4 | M1 | [U]4+ | U | +4 |

**Total species**: 15 | **Core groups**: 14 | **Multi-member groups**: 1 | **Cross-source groups**: 0

## 1. Aqueous / Dissolved Species

14 core groups, 15 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `L1:1` | [EDTA] | SRD-46 | -4 | 1x | +56.734 | 0 | — |
| 3 | `L1:1 H:1` | [HEDTA]3- | SRD-46 | -3 | 1x | +0.000 | 0 | — |
| 4 | `U$+2:1` | [UO_[]22+ | SRD-46 | +2 | 1x | +0.000 | -2 | — |
| 5 | `U$+2:1 H:-1` | [UO_[(OH)]+ | SRD-46 | +1 | 1x | +35.959 | -2 | — |
| 6 | `U$+2:1 H:-1` | [UO_[2(OH)]22+ | SRD-46 | +2 | 2x | +36.016 | -4 | — |
| 7 | `U$+2:1 L1:1` | [UO_[2(EDTA)]24- | SRD-46 | -4 | 2x | -152.795 | -4 | — |
| 8 | `U$+2:2 L1:1` | [UO_[2(EDTA)] | SRD-46 | +0 | 1x | -101.996 | -4 | — |
| 9 | `U$+2:3 H:-4` | [UO_[3(OH)]42+ | SRD-46 | +2 | 1x | +563.349 | -6 | — |
| 10 | `U$+2:3 H:-5` | [UO_[3(OH)]5+ | SRD-46 | +1 | 1x | +99.314 | -6 | — |
| 11 | `U$+2:4 H:-7` | [UO_[4(OH)]7+ | SRD-46 | +1 | 1x | +980.011 | -8 | — |
| 12 | `U$+4:1` | [U]4+ | SRD-46 | +4 | 1x | +0.000 | -4 | — |
| 13 | `U$+4:1 H:-1` | [U(OH)]3+ | SRD-46 | +3 | 1x | +8.562 | -4 | — |
| 14 | `U$+4:1 L1:1` | [U(EDTA)] | SRD-46 | +0 | 1x | -146.688 | -4 | — |
| 15 | `U$+4:2 H:-5` | [U6(OH)15]9+ | SRD-46 | +9 | 3x | +98.172 | -24 | — |

### Duplicated Groups

#### 1.1  Core: `U$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [UO_[(OH)]+ | SRD-46 | +1 | 1x | +35.959 | -2 | id=[U$+2].[OH].[z+1]; mu_canon=+35.9585 |
| 2 | [UO_[2(OH)]22+ | SRD-46 | +2 | 2x | +36.016 | -4 | id=[U$+2]2.[OH]2.[z+2]; mu_canon=+36.0155 |

## 2. Solid / Dissolution Species

*(No species in this section.)*

## 3. Gas Species

*(No species in this section.)*

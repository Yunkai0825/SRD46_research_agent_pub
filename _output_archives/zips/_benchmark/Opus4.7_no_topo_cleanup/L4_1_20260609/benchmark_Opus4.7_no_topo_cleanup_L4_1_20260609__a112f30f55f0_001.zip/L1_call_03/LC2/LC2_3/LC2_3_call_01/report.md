# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    34.71
- elapsed_s (total):  34.71
- llm_iterations:     6
- llm_tool_calls:     3

- n_groups:           14
- n_multi_groups:     1
- n_singletons:       13
- n_decisions:        14
- n_dropped:          0
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `U$+2:1 H:-1` | `[UO_[(OH)]+`, `[UO_[2(OH)]22+` | Distinct nuclearity and charge (mononuclear +1 vs dinuclear +2); both retained per rule 2. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid neutral reference species with finite mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Free EDTA ligand species with valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Protonated EDTA reference species (mu=0 anchor) is valid. |
| aqueous | `U$+2:1` | yes | UO2 2+ reference species (mu=0 anchor) is valid. |
| aqueous | `U$+2:1 L1:1` | yes | Uranyl-EDTA 1:1 complex with valid mu_aligned_kJ. |
| aqueous | `U$+2:2 L1:1` | yes | Binuclear uranyl-EDTA complex with valid thermodynamics. |
| aqueous | `U$+2:3 H:-4` | yes | Polynuclear uranyl hydroxide with valid mu_aligned_kJ. |
| aqueous | `U$+2:3 H:-5` | yes | Polynuclear uranyl hydroxide with valid thermodynamics. |
| aqueous | `U$+2:4 H:-7` | yes | Polynuclear uranyl hydroxide with valid mu_aligned_kJ. |
| aqueous | `U$+4:1` | yes | U4+ reference species (mu=0 anchor) is valid. |
| aqueous | `U$+4:1 H:-1` | yes | U(OH)3+ hydrolysis species with valid thermodynamics. |
| aqueous | `U$+4:1 L1:1` | yes | U(IV)-EDTA complex with valid mu_aligned_kJ. |
| aqueous | `U$+4:2 H:-5` | yes | Polynuclear U(IV) hydroxide species with valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|

# Free Energy Analysis Card

**System**: metal_185 + ligand_10076
**Metals**: [Th]4+
**Ligands**: 
**Generated**: 2026-06-09 19:53:23 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Th$+4 | Metal component: [Th]4+ |
| L0 | Always OH⁻ (derived from Kw) |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Th$+4 | [Th]4+ | +4 | 0.001 | NIST SRD-46 | metal_185 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Th | Th$+4 | [Th]4+ | +4 | true | 1 |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Th$+4 | [Th]4+ | metal | [Th]4+(aq) | +0.0000 | R1 | Th | +4 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Th]4+ + [OH]- | 25.0 | 3 | 27389 | 9 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Th]4+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Th$+4].[z+4] | [Th]4+ | +4 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Th$+4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Th]4+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Th$+4].[OH].[z+3] | [Th(OH)]3+ | +3 | aqueous | -5.0000 | +28.5385 | +28.5385 | +28.5385 | [Th$+4]:+1, [OH]:+1 | vlm_170530 | *** |
| [Th$+4]2.[OH]2.[z+6] | [Th2(OH)2]6+ | +6 | aqueous | -5.0300 | +28.7097 | +28.7097 | +28.7097 | [Th$+4]:+2, [OH]:+2 | vlm_170541_patched | *** |
| [Th$+4]2.[OH]3.[z+5] | [Th2(OH)3]5+ | +5 | aqueous | -8.2000 | +46.8031 | +46.8031 | +46.8031 | [Th$+4]:+2, [OH]:+3 | vlm_170546 | *** |
| [Th$+4].[OH]4.[z+0] | [Th(OH)4] | +0 | aqueous | -14.9000 | +85.0446 | +85.0446 | +85.0446 | [Th$+4]:+1, [OH]:+4 | vlm_170539 | *** |
| [Th$+4]4.[OH]8.[z+8] | [Th4(OH)8]8+ | +8 | aqueous | -17.5500 | +100.1700 | +100.1700 | +100.1700 | [Th$+4]:+4, [OH]:+8 | vlm_170551 | *** |
| [Th$+4]3.[OH].[z+11] | [Th3(OH)]11+ | +11 | aqueous | -26.7000 | +152.3954 | +152.3954 | +152.3954 | [Th$+4]:+3, [OH]:+1 | vlm_170548 | *** |
| [Th$+4]6.[OH]14.[z+10] | [Th6(OH)14]10+ | +10 | aqueous | -33.9000 | +193.4908 | +193.4908 | +193.4908 | [Th$+4]:+6, [OH]:+14 | vlm_170555 | *** |
| [Th$+4]3.[OH]3.[z+9] | [Th3(OH)3]9+ | +9 | aqueous | -77.7000 | +443.4877 | +443.4877 | +443.4877 | [Th$+4]:+3, [OH]:+3 | vlm_170549 | *** |
| [Th$+4]2.[OH]5.[z+3] | [Th2(OH)5]3+ | +3 | aqueous | -123.7000 | +706.0415 | +706.0415 | +706.0415 | [Th$+4]:+2, [OH]:+5 | vlm_170547 | *** |

### 5.2 Dissolution / Solid Species

(No dissolution / solid species species in this system.)

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 9 |
| Included in calculation | 9 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 9 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_170530 | [<OH+->] + [<Th4+>] <=> [<Th4+><OH+->] | +9.0000 | 25.0 | 3.000 | yes | [Th(OH)]3+ |
| 2 | vlm_170539 | [<OH+->]^4 + [<Th4+>] <=> [<Th4+><OH+->4] | +41.1000 | 25.0 | 3.000 | yes | [Th(OH)4] |
| 3 | vlm_170541_patched | [<OH+->]^2 + [<Th4+>]^2 <=> [<Th4+>2<OH+->2] | +22.9700 | 25.0 | 3.000 | yes | [Th2(OH)2]6+ |
| 4 | vlm_170546 | [<OH+->]^3 + [<Th4+>]^2 <=> [<Th4+>2<OH+->3] | +33.8000 | 25.0 | 3.000 | yes | [Th2(OH)3]5+ |
| 5 | vlm_170547 | [<OH+->]^5 + [<Th4+>]^2 <=> [<Th4+>2<OH+->5] | -53.7000 | 25.0 | 3.000 | yes | [Th2(OH)5]3+ |
| 6 | vlm_170548 | [<OH+->] + [<Th4+>]^3 <=> [<Th4+>3<OH+->] | -12.7000 | 25.0 | 3.000 | yes | [Th3(OH)]11+ |
| 7 | vlm_170549 | [<OH+->]^3 + [<Th4+>]^3 <=> [<Th4+>3<OH+->3] | -35.7000 | 25.0 | 3.000 | yes | [Th3(OH)3]9+ |
| 8 | vlm_170551 | [<OH+->]^8 + [<Th4+>]^4 <=> [<Th4+>4<OH+->8] | +94.4500 | 25.0 | 3.000 | yes | [Th4(OH)8]8+ |
| 9 | vlm_170555 | [<OH+->]^14 + [<Th4+>]^6 <=> [<Th4+>6<OH+->14] | +162.1000 | 25.0 | 3.000 | yes | [Th6(OH)14]10+ |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

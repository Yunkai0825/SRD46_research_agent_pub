# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Th$+4 | M3 | [Th]4+ | Th | +4 |
| U$+2 | M2 | [UO_[]22+ | U | +2 |
| U$+4 | M1 | [U]4+ | U | +4 |
| Th$+0 | Atlas | Th (ox +0) | Th | +0 |

**Total species**: 32 | **Core groups**: 26 | **Multi-member groups**: 5 | **Cross-source groups**: 1

## 1. Aqueous / Dissolved Species

24 core groups, 28 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `L1:1` | [EDTA] | SRD-46 | -4 | 1x | +58.161 | 0 | — |
| 3 | `L1:1 H:1` | [HEDTA]3- | SRD-46 | -3 | 1x | +0.000 | 0 | — |
| 4 | `Th$+4:1` | Th4+ | Atlas | +4 | 1x | +0.000 | 0 | +0.000 |
| 5 | `Th$+4:1` | [Th]4+ | SRD-46 | +4 | 1x | +0.000 | 0 | ref |
| 6 | `Th$+4:1 H:-1` | [Th(OH)]3+ | SRD-46 | +3 | 1x | +28.538 | 0 | — |
| 7 | `Th$+4:1 H:-1` | [Th2(OH)2]6+ | SRD-46 | +6 | 2x | +28.710 | 0 | — |
| 8 | `Th$+4:1 H:-1` | [Th3(OH)3]9+ | SRD-46 | +9 | 3x | +443.488 | 0 | — |
| 9 | `Th$+4:1 H:-2` | [Th4(OH)8]8+ | SRD-46 | +8 | 4x | +100.170 | 0 | — |
| 10 | `Th$+4:1 H:-4` | [Th(OH)4] | SRD-46 | +0 | 1x | +85.045 | 0 | — |
| 11 | `Th$+4:1 L1:1` | [Th(EDTA)] | SRD-46 | +0 | 1x | -132.418 | 0 | — |
| 12 | `Th$+4:1 L1:1 H:1` | [Th(EDTA)H]+ | SRD-46 | +1 | 1x | -143.834 | 0 | — |
| 13 | `Th$+4:2 H:-3` | [Th2(OH)3]5+ | SRD-46 | +5 | 1x | +46.803 | 0 | — |
| 14 | `Th$+4:2 H:-5` | [Th2(OH)5]3+ | SRD-46 | +3 | 1x | +706.042 | 0 | — |
| 15 | `Th$+4:3 H:-1` | [Th3(OH)]11+ | SRD-46 | +11 | 1x | +152.395 | 0 | — |
| 16 | `Th$+4:3 H:-7` | [Th6(OH)14]10+ | SRD-46 | +10 | 2x | +193.491 | 0 | — |
| 17 | `U$+2:1` | [UO_[]22+ | SRD-46 | +2 | 1x | +0.000 | -2 | — |
| 18 | `U$+2:1 H:-1` | [UO_[(OH)]+ | SRD-46 | +1 | 1x | +35.959 | -2 | — |
| 19 | `U$+2:1 H:-1` | [UO_[2(OH)]22+ | SRD-46 | +2 | 2x | +36.016 | -4 | — |
| 20 | `U$+2:1 L1:1` | [UO_[2(EDTA)]24- | SRD-46 | -4 | 2x | -152.795 | -4 | — |
| 21 | `U$+2:2 L1:1` | [UO_[2(EDTA)] | SRD-46 | +0 | 1x | -101.996 | -4 | — |
| 22 | `U$+2:3 H:-4` | [UO_[3(OH)]42+ | SRD-46 | +2 | 1x | +563.349 | -6 | — |
| 23 | `U$+2:3 H:-5` | [UO_[3(OH)]5+ | SRD-46 | +1 | 1x | +99.314 | -6 | — |
| 24 | `U$+2:4 H:-7` | [UO_[4(OH)]7+ | SRD-46 | +1 | 1x | +980.011 | -8 | — |
| 25 | `U$+4:1` | [U]4+ | SRD-46 | +4 | 1x | +0.000 | -4 | — |
| 26 | `U$+4:1 H:-1` | [U(OH)]3+ | SRD-46 | +3 | 1x | +8.562 | -4 | — |
| 27 | `U$+4:1 L1:1` | [U(EDTA)] | SRD-46 | +0 | 1x | -146.688 | -4 | — |
| 28 | `U$+4:2 H:-5` | [U6(OH)15]9+ | SRD-46 | +9 | 3x | +98.172 | -24 | — |

### Duplicated Groups

#### 1.1  Core: `Th$+4:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Th4+ | Atlas | +4 | 1x | +0.000 | 0 | ox=+4; Thoric ion; DGf=-733.037 |
| 2 | [Th]4+ | SRD-46 | +4 | 1x | +0.000 | 0 | id=[Th$+4].[z+4]; mu_canon=+0.0000 |

> Δ(Th4+ vs [Th]4+) = 0.000 kJ/mol

#### 1.2  Core: `Th$+4:1 H:-1` **[3× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Th(OH)]3+ | SRD-46 | +3 | 1x | +28.538 | 0 | id=[Th$+4].[OH].[z+3]; mu_canon=+28.5385 |
| 2 | [Th2(OH)2]6+ | SRD-46 | +6 | 2x | +28.710 | 0 | id=[Th$+4]2.[OH]2.[z+6]; mu_canon=+28.7097 |
| 3 | [Th3(OH)3]9+ | SRD-46 | +9 | 3x | +443.488 | 0 | id=[Th$+4]3.[OH]3.[z+9]; mu_canon=+443.4877 |

#### 1.3  Core: `U$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [UO_[(OH)]+ | SRD-46 | +1 | 1x | +35.959 | -2 | id=[U$+2].[OH].[z+1]; mu_canon=+35.9585 |
| 2 | [UO_[2(OH)]22+ | SRD-46 | +2 | 2x | +36.016 | -4 | id=[U$+2]2.[OH]2.[z+2]; mu_canon=+36.0155 |

## 2. Solid / Dissolution Species

2 core groups, 4 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Th$+0:1` | Th | Atlas | +0 | 1x | +733.037 | 4 | — |
| 2 | `Th$+0:1` | Th | Atlas | +0 | 1x | +733.037 | 4 | — |
| 3 | `Th$+4:1 H:-4` | ThO2 (anh.) | Atlas | +0 | 1x | +42.593 | 0 | — |
| 4 | `Th$+4:1 H:-4` | ThO2 (hydr.) | Atlas | +0 | 1x | +91.881 | 0 | — |

### Duplicated Groups

#### 2.1  Core: `Th$+0:1` **[2× Atlas]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Th | Atlas | +0 | 1x | +733.037 | 4 | ox=0; Thorium, silvery white, cub.; DGf=+0.000 |
| 2 | Th | Atlas | +0 | 1x | +733.037 | 4 | ox=0; Thorium; DGf=+0.000 |

#### 2.2  Core: `Th$+4:1 H:-4` **[2× Atlas]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ThO2 (anh.) | Atlas | +0 | 1x | +42.593 | 0 | ox=+4; Thorium dioxide, cub.; DGf=-1164.826 |
| 2 | ThO2 (hydr.) | Atlas | +0 | 1x | +91.881 | 0 | ox=+4; Thorium hydroxide, Th(OH)4; DGf=-1115.538 |

## 3. Gas Species

*(No species in this section.)*

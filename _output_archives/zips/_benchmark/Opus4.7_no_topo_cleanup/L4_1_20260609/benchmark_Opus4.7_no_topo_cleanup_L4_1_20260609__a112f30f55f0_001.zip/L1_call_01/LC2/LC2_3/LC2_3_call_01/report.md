# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    40.54
- elapsed_s (total):  40.55
- llm_iterations:     17
- llm_tool_calls:     10

- n_groups:           26
- n_multi_groups:     5
- n_singletons:       21
- n_decisions:        26
- n_dropped:          2
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Th$+4:1` | `[Th]4+` | True duplicates of aqueous Th4+; prefer SRD-46 per plan. |
| aqueous | `Th$+4:1 H:-1` | `[Th(OH)]3+`, `[Th2(OH)2]6+`, `[Th3(OH)3]9+` | Distinct nuclearities (mono-, di-, tri-nuclear Th hydroxo complexes) are different species per rule 2 and all retained. |
| aqueous | `U$+2:1 H:-1` | `[UO_[(OH)]+`, `[UO_[2(OH)]22+` | Distinct species: mononuclear UO2(OH)+ and dinuclear (UO2)2(OH)2^2+ differ in nuclearity and charge. |
| solid | `Th$+0:1` | `Th` | Identical Th(s) entries from same source with same mu and multiplier are true duplicates; keep one. |
| solid | `Th$+4:1 H:-4` | `ThO2 (hydr.)` | Per addendum, prefer hydrated oxyhydroxide form over anhydrous oxide for Th(IV) solids at pH 5, 25 C. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Sole member with valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Sole member; valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Sole member; reference-state mu=0 is valid. |
| aqueous | `Th$+4:1 H:-2` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:1 H:-4` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:1 L1:1` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:1 L1:1 H:1` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:2 H:-3` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:2 H:-5` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:3 H:-1` | yes | Sole member; valid mu. |
| aqueous | `Th$+4:3 H:-7` | yes | Sole member; valid mu. |
| aqueous | `U$+2:1` | yes | Sole member; reference-state mu=0 is valid. |
| aqueous | `U$+2:1 L1:1` | yes | Sole member; valid mu. |
| aqueous | `U$+2:2 L1:1` | yes | Sole member; valid mu. |
| aqueous | `U$+2:3 H:-4` | yes | Sole member; valid mu. |
| aqueous | `U$+2:3 H:-5` | yes | Sole member; valid mu. |
| aqueous | `U$+2:4 H:-7` | yes | Sole member; valid mu. |
| aqueous | `U$+4:1` | yes | Sole member; reference-state mu=0 is valid. |
| aqueous | `U$+4:1 H:-1` | yes | Sole member; valid mu. |
| aqueous | `U$+4:1 L1:1` | yes | Sole member; valid mu. |
| aqueous | `U$+4:2 H:-5` | yes | Sole member; valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Th4+` | Atlas | aqueous | dedup: excluded (True duplicates of aqueous Th4+; prefer SRD-46 per plan.) |
| `ThO2 (anh.)` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated oxyhydroxide form over anhydrous oxide for Th(IV) solids at pH 5, 25 C.) |

[Purpose: Compute joint speciation of a single solution containing U(VI) and Th(IV) with 18-crown-6 and EDTA at pH 5, identifying the dominant uranyl-crown, thorium-crown and EDTA complexes.]
[Tasks:
Model a single pot containing U(VI) at 1 mM and Th(IV) at 1 mM together with 18-crown-6 at 5 mM and EDTA at 5 mM, held at pH 5, 25 C and ionic strength 0.1 m. Solve the joint equilibrium so the two metals compete for the shared crown-ether and EDTA pools, and report the dominant uranyl-crown complex, the dominant thorium-crown complex, and the dominant EDTA complexes of each metal, with their fractions of the respective metal totals and of the ligand totals.
]
[Pair: pair_key=`m195_l10076`, metal_id=195, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal195_ligand10076_beta677_net27415`
[Screen report]
# Eq-map screen — m195_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal195_ligand10076_beta652_net27415` | `[M]^3 + [L]^5 <=> [M3L5]` | vlm_170627@(25.0,0.1) = K+52.600 | 6 | +52.000 / +52.850 / +53.200 / +54.600 | vlm_170627@(25.0,0.1) = K+52.600 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal195_ligand10076_beta812_net27415` | `[M] + [L] <=> [ML]` | vlm_170604@(25.0,0.1) = K+7.700 | 5 | +7.600 / +7.800 / +7.860 / +8.100 | vlm_170604@(25.0,0.1) = K+7.700 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal195_ligand10076_beta677_net27415` | `[M]^4 + [L]^7 <=> [M4L7]` | vlm_170639@(25.0,0.1) = K-73.700 | 1 | -73.700 / -73.700 / -73.700 / -73.700 | vlm_170639@(25.0,0.1) = K-73.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal195_ligand10076_beta519_net27415` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170611@(25.0,0.1) = K+21.690 | 7 | +21.510 / +21.840 / +21.913 / +22.420 | vlm_170611@(25.0,0.1) = K+21.690 (+0.00 °C, +0.00 M) | `—` |
| 5 | `metal195_ligand10076_beta649_net27415` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170620@(25.0,0.1) = K-42.700 | 5 | -44.200 / -42.700 / -42.840 / -41.800 | vlm_170620@(25.0,0.1) = K-42.700 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

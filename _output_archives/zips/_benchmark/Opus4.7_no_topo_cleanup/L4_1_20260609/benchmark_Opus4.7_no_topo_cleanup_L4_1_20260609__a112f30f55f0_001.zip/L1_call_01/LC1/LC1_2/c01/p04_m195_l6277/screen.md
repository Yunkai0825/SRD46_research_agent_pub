# Eq-map screen — m195_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 6)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal195_ligand6277_beta502_net5014` | `[M]^2 + [L] <=> [M2L]` | vlm_108547@(25.0,1.0) = K+16.140 | 2 | +16.140 / +17.005 / +17.005 / +17.870 | vlm_108546@(25.0,0.1) = K+17.870 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal195_ligand6277_beta570_net5014` | `[M2(OH)L] + [H] <=> [M2L] + [H2O]` | vlm_108548@(25.0,1.0) = K+4.810 | 1 | +4.810 / +4.810 / +4.810 / +4.810 | vlm_108548@(25.0,1.0) = K+4.810 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal195_ligand6277_beta536_net5014` | `[M2L] + [L] <=> [M2L2]` | vlm_108549@(25.0,1.0) = K+8.900 | 1 | +8.900 / +8.900 / +8.900 / +8.900 | vlm_108549@(25.0,1.0) = K+8.900 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal195_ligand6277_beta662_net5014` | `[M]^4 + [L]^2 + [H2O]^4 <=> [M4(OH)4L2] + [H]^4` | vlm_108550@(25.0,1.0) = K+15.340 | 1 | +15.340 / +15.340 / +15.340 / +15.340 | vlm_108550@(25.0,1.0) = K+15.340 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal195_ligand6277_beta699_net5014` | `[M]^6 + [L]^3 + [H2O]^4 <=> [M6(OH)4L3] + [H]^4` | vlm_108551@(25.0,1.0) = K+34.300 | 1 | +34.300 / +34.300 / +34.300 / +34.300 | vlm_108551@(25.0,1.0) = K+34.300 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal195_ligand6277_beta779_net5014` | `[M] + [HL] <=> [MHL]` | vlm_108543@(25.0,1.0) = K+6.350 | 2 | +6.350 / +6.875 / +6.875 / +7.400 | vlm_108542@(25.0,0.1) = K+7.400 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

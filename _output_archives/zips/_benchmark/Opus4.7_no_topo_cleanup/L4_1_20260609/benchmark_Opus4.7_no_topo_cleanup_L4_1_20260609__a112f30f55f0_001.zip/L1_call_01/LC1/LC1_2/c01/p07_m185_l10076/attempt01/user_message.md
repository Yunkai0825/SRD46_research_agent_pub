[Purpose: Compute joint speciation of a single solution containing U(VI) and Th(IV) with 18-crown-6 and EDTA at pH 5, identifying the dominant uranyl-crown, thorium-crown and EDTA complexes.]
[Tasks:
Model a single pot containing U(VI) at 1 mM and Th(IV) at 1 mM together with 18-crown-6 at 5 mM and EDTA at 5 mM, held at pH 5, 25 C and ionic strength 0.1 m. Solve the joint equilibrium so the two metals compete for the shared crown-ether and EDTA pools, and report the dominant uranyl-crown complex, the dominant thorium-crown complex, and the dominant EDTA complexes of each metal, with their fractions of the respective metal totals and of the ligand totals.
]
[Pair: pair_key=`m185_l10076`, metal_id=185, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal185_ligand10076_beta894_net27389`
  - `metal185_ligand10076_beta519_net27389`
  - `metal185_ligand10076_beta540_net27389`
  - `metal185_ligand10076_beta549_net27389`
  - `metal185_ligand10076_beta638_net27389`
  - `metal185_ligand10076_beta645_net27389`
  - `metal185_ligand10076_beta678_net27389`
  - `metal185_ligand10076_beta704_net27389`
[Screen report]
# Eq-map screen — m185_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **9** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal185_ligand10076_beta812_net27389` | `[M] + [L] <=> [ML]` | vlm_170530@(25.0,3.0) = K+9.000 | 6 | +9.000 / +9.800 / +9.845 / +10.800 | vlm_170527@(25.0,0.1) = K+10.000 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal185_ligand10076_beta894_net27389` | `[M] + [L]^4 <=> [ML4]` | vlm_170539@(25.0,3.0) = K+41.100 | 1 | +41.100 / +41.100 / +41.100 / +41.100 | vlm_170539@(25.0,3.0) = K+41.100 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal185_ligand10076_beta519_net27389` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170541@(25.0,3.0) = K+23.580 | 4 | -21.900 / +23.275 / +12.078 / +23.660 | vlm_170543@(25.0,0.0) = K-21.900 (+0.00 °C, -0.10 M) | `sibling_sign_split, mean_median_gap, wide_TI_distance` |
| 4 | `metal185_ligand10076_beta540_net27389` | `[M]^2 + [L]^3 <=> [M2L3]` | vlm_170546@(25.0,3.0) = K+33.800 | 1 | +33.800 / +33.800 / +33.800 / +33.800 | vlm_170546@(25.0,3.0) = K+33.800 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal185_ligand10076_beta549_net27389` | `[M]^2 + [L]^5 <=> [M2L5]` | vlm_170547@(25.0,3.0) = K-53.700 | 1 | -53.700 / -53.700 / -53.700 / -53.700 | vlm_170547@(25.0,3.0) = K-53.700 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal185_ligand10076_beta638_net27389` | `[M]^3 + [L] <=> [M3L]` | vlm_170548@(25.0,3.0) = K-12.700 | 1 | -12.700 / -12.700 / -12.700 / -12.700 | vlm_170548@(25.0,3.0) = K-12.700 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 7 | `metal185_ligand10076_beta645_net27389` | `[M]^3 + [L]^3 <=> [M3L3]` | vlm_170549@(25.0,3.0) = K-35.700 | 1 | -35.700 / -35.700 / -35.700 / -35.700 | vlm_170549@(25.0,3.0) = K-35.700 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal185_ligand10076_beta678_net27389` | `[M]^4 + [L]^8 <=> [M4L8]` | vlm_170551@(25.0,3.0) = K+94.450 | 3 | -90.900 / +91.200 / +31.583 / +94.450 | vlm_170552@(25.0,0.0) = K-90.900 (+0.00 °C, -0.10 M) | `sibling_sign_split, wide_TI_distance` |
| 9 | `metal185_ligand10076_beta704_net27389` | `[M]^6 + [L]^14 <=> [M6L14]` | vlm_170555@(25.0,3.0) = K+162.100 | 2 | +162.100 / +163.550 / +163.550 / +165.000 | vlm_170555@(25.0,3.0) = K+162.100 (+0.00 °C, +2.90 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m193_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal193_ligand10076_beta812_net27396` | `[M] + [L] <=> [ML]` | vlm_170569@(25.0,0.1) = K+12.500 | 7 | +12.000 / +12.300 / +12.429 / +13.400 | vlm_170569@(25.0,0.1) = K+12.500 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal193_ligand10076_beta705_net27396` | `[M]^6 + [L]^15 <=> [M6L15]` | vlm_170579@(25.0,0.0) = K+192.800 | 2 | +192.800 / +194.450 / +194.450 / +196.100 | vlm_170579@(25.0,0.0) = K+192.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal193_ligand10076_beta360_net27396` | `[MO2(s,am)] + [H2O]^2 <=> [M] + [OH]^4` | vlm_170582@(25.0,0.0) = K-56.200 | 3 | -56.200 / -55.600 / -55.367 / -54.300 | vlm_170582@(25.0,0.0) = K-56.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m193_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal193_ligand6277_beta427_net5007` | `[M(OH)L]^2 <=> [M2(OH)2L2]` | vlm_108536@(25.0,0.1) = K+2.900 | 1 | +2.900 / +2.900 / +2.900 / +2.900 | vlm_108536@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal193_ligand6277_beta812_net5007` | `[M] + [L] <=> [ML]` | vlm_108531@(25.0,0.1) = K+25.700 | 3 | +23.200 / +25.700 / +24.900 / +25.800 | vlm_108531@(25.0,0.1) = K+25.700 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal193_ligand6277_beta966_net5007` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108534@(25.0,0.1) = K+4.720 | 1 | +4.720 / +4.720 / +4.720 / +4.720 | vlm_108534@(25.0,0.1) = K+4.720 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal193_ligand6277_beta423_net5007` | `[ML]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_108535@(25.0,0.1) = K+6.530 | 1 | +6.530 / +6.530 / +6.530 / +6.530 | vlm_108535@(25.0,0.1) = K+6.530 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,            "value": 298.15, "basis": "known"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,         "value": 0.1,    "basis": "known"},
  {"id": "pH",  "lhs": lambda s: s.pH,                     "value": 5.0,    "basis": "known"},
  {"id": "UO2", "lhs": lambda s: s.total["U$+2"],          "value": 1e-3,   "basis": "known"},
  {"id": "Th",  "lhs": lambda s: s.total["Th$+4"],         "value": 1e-3,   "basis": "known"},
  {"id": "EDTA","lhs": lambda s: s.total["ligand_6277"],   "value": 5e-3,   "basis": "known"},
  {"id": "CR6", "lhs": lambda s: s.total["ligand_9676"],   "value": 5e-3,   "basis": "known"},
]
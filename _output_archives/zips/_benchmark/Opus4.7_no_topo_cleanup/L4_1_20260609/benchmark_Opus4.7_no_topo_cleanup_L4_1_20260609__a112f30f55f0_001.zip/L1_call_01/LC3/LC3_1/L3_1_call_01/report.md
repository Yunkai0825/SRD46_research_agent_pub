# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 10.12
- sweep_method: **freeform_sweep**
- dof: 1

## Notes

Single-condition joint speciation; freeform handles the non-sweep case with one trivial axis.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_1_UTh_crown_EDTA_not_in_db\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
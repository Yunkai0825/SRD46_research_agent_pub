Excellent. Now I have a much clearer bracket:

- **Fe3+ + SCN– (anionic, monodentate soft/borderline N/S donor):** logK1 ≈ 2.1 at I=0.1 (vlm_172282). SCN– is anionic and much stronger σ-donor than CH3CN, yet logK1 is only ~2.
- **Fe3+ + N3– (anionic, monodentate N-donor):** logK1 ≈ 4.6 at I=0.1 (vlm_173624). Also anionic and modestly basic (pKa HN3 = 4.65).
- **Fe3+ + phen (neutral bidentate aromatic N):** logK1 ≈ 6.5 at I=0.1 (vlm_139320), gaining chelate effect + π-acceptor stabilization.
- **CH3CN**: neutral, monodentate, weakly basic (pKa CH3CN·H+ = –10), no chelation.

For a neutral, weakly σ-basic, non-chelating monodentate ligand competing against H2O in the Fe(H2O)6^3+ inner sphere, the aqueous logK1 for Fe3+ + CH3CN is expected to be **very small and probably ≤ 0** (i.e., no significant inner-sphere complex in dilute aqueous solution). This is entirely consistent with the absence of any measured Fe3+/CH3CN data in SRD-46 or in the classical stability-constant literature (Martell/Smith).

Given the question is about **water–acetonitrile mixed solvent for Fe electrodeposition**, the relevant chemistry in an aqueous Pourbaix framework is that CH3CN acts as a **spectator/co-solvent** — not a strong complexer of Fe3+. In pure or near-pure CH3CN, Fe(NCCH3)6^3+ does form, but that is a solvent-exchange (not aqueous complexation) regime, and its logβ vs Fe(H2O)6^3+ cannot be transferred meaningfully to the aqueous stability convention.

Let me also confirm no cyanide/pseudocyanate confusion with vlm_171933 (Fe3+ + HCN was to β6 = 43.6, but that is Fe(CN)6^3– with deprotonated CN–, not a neutral nitrile).

## Recommended stability entries for Fe3+ (metal_61) + Acetonitrile (ligand_9825), aqueous, 25 °C, I = 0.1 M

| field | value |
|-------|-------|
| metal_id | metal_61 (Fe^3+) |
| ligand_id | ligand_9825 (CH3CN, SMILES CC#N) |
| ligand_HxL form | L (neutral, no ionizable proton in the relevant pH window; pKa(CH3CN·H+) ≈ –10 so L is the only relevant form 0 ≤ pH ≤ 14) |
| direct SRD-46 measurements | **none** (search_stability on c.metal_id=61 AND c.ligand_id=9825 → 0 rows) |

### Estimated equilibria

| # | beta_def | equation | reaction | est. log10 K | uncertainty (±) | note |
|---|----------|----------|----------|--------------|-----------------|------|
| 1 | beta_def_812 | `[M] + [L] <=> [ML]` | Fe3+ + CH3CN ⇌ Fe(NCCH3)3+ | **−0.5** (i.e. ~ 0.3 M–1, effectively outer-sphere only in water) | ±0.7 | recommended default for aqueous Pourbaix work |
| 2 | beta_def_840 | `[M] + [L]^2 <=> [ML2]` | Fe3+ + 2 CH3CN ⇌ Fe(NCCH3)2^3+ | **−1.5** | ±1.0 | assume ΔlogK per step ≈ −1 (statistical + electrostatic screening + water competition) |
| 3 | beta_def_872 | `[M] + [L]^3 <=> [ML3]` | Fe3+ + 3 CH3CN ⇌ Fe(NCCH3)3^3+ | **−3.0** | ±1.2 | list only if the network requires higher stoichiometry |

conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).

### Evidence and reasoning

- **Direct data absent.** `search_stability` for the target pair returned no results (verified). Across the entire SRD-46 acetonitrile dataset only 3 metals appear: Cu+ (vlm_168274, logβ2 = 4.35), Ag+ (vlm_168275 logK1 = 0.42, vlm_168276 logβ2 = 0.78), Pd2+ (vlm_168277 logK1 = 1.19). All three are soft/borderline d10 or square-planar centres for which CH3CN is a good soft σ/π ligand. Fe3+ is a hard, high-charge oxophilic centre and CH3CN is a very weak, non-π-basic ligand for hard cations — the transfer of any of these soft-metal logK values to Fe3+ would be misleading.
- **Bracketing route via monodentate N-donors on Fe3+.** For anionic monodentate N-donors that are enormously more basic and better σ-donors than CH3CN, Fe3+ still gives only modest logK1:
  - Fe3+ + SCN– → logK1 = 2.37 at I=0.1 (vlm_172282); SCN– is anionic (+3/–1 electrostatics) and yet logK1 ≈ 2.
  - Fe3+ + N3– → logK1 = 4.6 at I=0.1 (vlm_173624); pKa(HN3)=4.65, so N3– is a decent N base.
  - Fe3+ + phen (neutral, bidentate aromatic N) → logK1 = 6.5 at I=0.1 (vlm_139320); note this includes both the chelate effect and π-back-stabilisation not available to CH3CN.
- **Removing the electrostatic bonus.** Going from anionic SCN– (logK1 ≈ 2.4, +3/–1) to a neutral monodentate ligand removes ~4–5 logK units of Coulombic stabilisation for a hard trivalent centre in water (typical M3+/X– vs M3+/L0 gap). Applying that shift to SCN– gives logK1(Fe3+·CH3CN) ≈ 2.4 − 4 to 5 ≈ −2 to −3, offset upward by ~1–2 units because CH3CN is a slightly better σ-donor to a hard centre than SCN– (which binds Fe3+ through the softer S end). Net expectation: logK1 ≈ −1 to 0.
- **Water competition.** In water the effective reaction is Fe(H2O)6^3+ + CH3CN ⇌ Fe(H2O)5(NCCH3)^3+ + H2O. Because H2O is a strong donor to Fe3+ (Fe3+ is highly oxophilic) and CH3CN's proton basicity is ~15 orders of magnitude lower than H2O's O basicity toward H+, CH3CN cannot outcompete H2O on a per-donor basis. Any inner-sphere occupancy of CH3CN on Fe3+ in aqueous solution is therefore negligible; the ~ logK1 ≈ −0.5 estimate reflects mostly the outer-sphere/statistical association.
- **Successive-step penalty.** For M3+ hexaaqua ions, second- and third-step logK are typically 0.5–1.5 units below the previous step even for good ligands (see Fe3+/phen: logK1=6.5, logK2=4.9, logK3=2.7 from vlm_139320/321/322). Applying ΔlogK ≈ −1 per step to a nearly non-binding first step gives the ML2, ML3 estimates.
- **Consistency check with the mixed-solvent design goal.** In water-rich electrolytes (xCH3CN < ~0.5) Fe3+ speciation will remain dominated by aqua/hydroxo species (Fe(H2O)6^3+, Fe(OH)^2+ at pH ≳ 2, Fe(OH)3(s) above pH ~3), i.e. the standard aqueous Fe Pourbaix diagram is essentially unchanged by CH3CN at the complexation level. As xCH3CN → 1 the coordination sphere converts to Fe(NCCH3)6^3+, but that is a solvent regime, not an aqueous equilibrium, and should be modelled separately (Gutmann DN, solvent-exchange thermodynamics) rather than by an aqueous logK.

### Uncertainty and recommended use

- The ±0.7–1.2 uncertainty envelope on the ML/ML2/ML3 estimates is wide precisely because there are no measured aqueous data — the numbers are floor/ceiling reasoning, not fitted analogues.
- **Recommended practice for the Fe Pourbaix / electrodeposition model:** treat CH3CN as a **non-complexing co-solvent** for Fe3+ in the aqueous convention (i.e., set logK1 ≤ 0 or omit CH3CN complexes entirely) and instead capture the CH3CN effect through (i) solvent activity / dielectric constant on Fe3+/Fe2+ and H+/H2 half-reactions, (ii) shift in the Fe(OH)3 solubility product, and (iii) possible stabilisation of Fe2+ (Fe2+ is a much better match for CH3CN than Fe3+; SRD-46 shows Cu+ logβ2 = 4.35 for CH3CN, and Fe2+ would sit intermediate). If the model absolutely requires a numeric entry, use ML with logK = −0.5 ± 0.7 at 25 °C, I = 0.1 M, and flag it as estimated.

### Provenance — SRD-46 records used

Analogue evidence (Fe3+ with related monodentate/N donors and pseudohalides): vlm_139320, vlm_139321, vlm_139322 (phen); vlm_172282, vlm_172303 (SCN–); vlm_173624, vlm_173630, vlm_173634 (N3–); vlm_171933 (HCN → CN–, β6). Ligand-side coverage (all acetonitrile records in SRD-46, showing the sparse landscape for CH3CN): vlm_168274 (Cu+), vlm_168275, vlm_168276 (Ag+), vlm_168277, vlm_168280 (Pd2+). Beta definitions referenced: beta_def_812, beta_def_840, beta_def_872. Entities: metal_61 (Fe3+), ligand_9825 (acetonitrile). No direct target record exists (search_stability on c.metal_id = metal_61 AND c.ligand_id = ligand_9825 returned zero rows), so all three ML/ML2/ML3 numbers above are **estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set**, not extrapolations of a specific measured constant.

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).
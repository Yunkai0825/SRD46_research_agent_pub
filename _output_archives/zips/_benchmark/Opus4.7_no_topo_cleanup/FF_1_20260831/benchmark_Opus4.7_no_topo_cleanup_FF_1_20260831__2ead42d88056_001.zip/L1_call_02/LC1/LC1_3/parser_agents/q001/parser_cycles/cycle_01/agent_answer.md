Extraction was performed against the QueryAgent's estimated aqueous stability constants for Fe^3+ (metal_61) + acetonitrile (ligand_9825) at 25 °C, I = 0.1 M. Three target equilibria were drafted:

1. Fe^3+ + CH3CN ⇌ Fe(NCCH3)^3+  (beta_def_812)  log K1 = −0.5 ± 0.7
2. Fe^3+ + 2 CH3CN ⇌ Fe(NCCH3)2^3+  (beta_def_840)  log β2 = −1.5 ± 1.0
3. Fe^3+ + 3 CH3CN ⇌ Fe(NCCH3)3^3+  (beta_def_872)  log β3 = −3.0 ± 1.2

Estimation method: chemistry judgement anchored on the SRD-46 Fe^3+ analogue set (no direct Fe^3+/CH3CN aqueous data exist). Supporting analogues cited: Fe^3+/phen (vlm_139320, 139321, 139322), Fe^3+/SCN⁻ (vlm_172282, 172303), Fe^3+/N3⁻ (vlm_173624, 173630, 173634), Fe^3+/HCN→CN⁻ (vlm_171933), and all SRD-46 acetonitrile records for other metals (vlm_168274 Cu⁺; vlm_168275, 168276 Ag⁺; vlm_168277, 168280 Pd^2+).

Key assumptions carried through: aqueous convention with the ML species expressed relative to Fe(H2O)6^3+ + L(aq); ΔlogK per successive step ≈ −1 (statistical + electrostatic screening + water competition); H2O outcompetes CH3CN in the Fe^3+ inner sphere so any complexation is essentially outer-sphere/statistical.

Recommended practice as stated by the QueryAgent: treat CH3CN as a non-complexing co-solvent for Fe^3+ in the aqueous Pourbaix framework; if a numeric entry is required, use the ML value log K1 = −0.5 ± 0.7 and flag it as estimated. The full workflow could not be closed to a committed workspace revision within the available turns (the network-gate step was not reached), so the three drafts above represent the extracted content but were not finalised.
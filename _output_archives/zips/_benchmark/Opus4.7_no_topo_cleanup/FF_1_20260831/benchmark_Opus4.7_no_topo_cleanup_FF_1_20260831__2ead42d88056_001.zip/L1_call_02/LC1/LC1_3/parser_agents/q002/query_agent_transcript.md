Excellent — this gives me the perfect calibration. Fe(II) with true monodentate neutral N-donors:

- **Fe(II)–pyridine** (pKa_H+L = 5.24, a moderately basic aromatic N donor): log K1 = 0.7, log β2 = 0.9 (at I = 0.5 M, 25 °C).
- **Fe(II)–ammonia** (pKa = 9.26, strong σ donor): log K1 = 1.4, log β2 = 2.25, log β3 = 2.68, log β4 = 2.75 (I = 0, 25 °C).

Now the key chemistry: Fe(II) is a borderline-hard 3d⁶ divalent cation, and acetonitrile is a very weak σ-donor with essentially no ligand basicity (pKa of CH3CNH+ ≈ –10). It is a much poorer donor to a hard/borderline first-row M(II) than pyridine or NH3. Even for soft d10 ions where MeCN binds reasonably (Ag+, Cu+, Pd2+), the acetonitrile constants are already tiny (Cu+ β2 = 4.35 in vlm_168274 is anomalously large due to soft-soft π-backbonding into the C≡N π*; Ag+ log K1 = 0.42 in vlm_168275; Pd2+ log K1 = 1.19 in vlm_168277 at I=1 M — and these are the *soft* metals that MeCN prefers).

For a **borderline-to-hard** Fe(II) in water, MeCN cannot outcompete water: aqueous Fe(II) is high-spin d⁶ with no π-backbonding driver for a σ-only C≡N donor, and displacing an aqua ligand for MeCN is essentially isoenergetic to slightly unfavorable. Reported/estimated Fe(II)–MeCN aqueous log K1 in the literature is ≤ 0 (Fe(II) prefers water). Bracketing:

- Ag+ (soft, d10) log K1(MeCN) = 0.42 → Fe2+/water should be lower because Fe2+ has no π-backbonding to CN and higher hydration free energy.
- Fe(II)–pyridine log K1 = 0.7 (with a much more basic N) → MeCN should be lower by ~1 log unit (basicity gap ≈ 15 pKa units, but donor-strength scaling to Fe(II) is compressed).

**Estimates for Fe²⁺ + n CH₃CN ⇌ [Fe(CH₃CN)ₙ]²⁺ in water at 25 °C, I = 0.1 M:**

| metal_id | ligand_id | beta_definition_id | reaction | HxL | constant_type | estimated log K / log β | uncertainty (±) |
|---|---|---|---|---|---|---|---|
| metal_62 | ligand_9825 | beta_def_812 | [Fe]²⁺ + [MeCN] ⇌ [Fe(MeCN)]²⁺ | L | K (log β1) | **−0.3** | 0.5 |
| metal_62 | ligand_9825 | beta_def_840 | [Fe]²⁺ + 2 [MeCN] ⇌ [Fe(MeCN)₂]²⁺ | L | K (log β2) | **−0.8** | 0.7 |
| metal_62 | ligand_9825 | beta_def_872 | [Fe]²⁺ + 3 [MeCN] ⇌ [Fe(MeCN)₃]²⁺ | L | K (log β3) | **−1.4** | 0.8 |
| metal_62 | ligand_9825 | beta_def_894 | [Fe]²⁺ + 4 [MeCN] ⇌ [Fe(MeCN)₄]²⁺ | L | K (log β4) | **−2.0** | 1.0 |

Conditions: aqueous solution, 25 °C, I = 0.1 M (inert 1:1 electrolyte, e.g. NaClO4/KCl). Solvent = water. Species assumed high-spin octahedral, no proton coupling (MeCN has no accessible pKa), no hydrolysis.

### Provenance and reasoning

**Direct data:** none. `search_stability` for metal_62 + ligand_9825 returns 0 rows. Only three metals in SRD-46 have any aqueous CH3CN constants: Cu+ (vlm_168274, log β2 = 4.35), Ag+ (vlm_168275 log K1 = 0.42; vlm_168276 log β2 = 0.78), Pd²⁺ (vlm_168277 log K1 = 1.19, vlm_168280 log β2 = 1.53) — all soft d10/d8 metals whose π-backbonding into C≡N π* is unavailable to high-spin Fe(II).

**Chemistry-informed route:**
1. **Donor-strength calibration on Fe(II) itself** using the two simplest neutral monodentate N donors in SRD-46: pyridine (vlm_38961: log K1 = 0.7; vlm_38962: log β2 = 0.9) and ammonia (vlm_73753: log K1 = 1.4; vlm_73761: log β2 = 2.25; vlm_73769: log β3 = 2.68; vlm_73777: log β4 = 2.75). Both are weak-binding, consistent with Fe(II) being poorly matched to neutral σ-donors in water.
2. **Basicity scaling:** MeCN protonation pKa ≈ −10 vs. pyridine 5.24 (from auto-enriched bracket on ligand_7890) and NH3 9.26 (ligand_10103). MeCN is dramatically weaker as a Brønsted/σ base. Empirical σ-donor scaling for first-row M(II) suggests log K1(MeCN) is 0.5–1.5 units below pyridine.
3. **Cross-metal check:** For Ag+, log K1(MeCN) = 0.42 (vlm_168275). Fe(II) has stronger aquation but no MeCN-favoring soft/π factor; expected to fall near or below Ag+ value, i.e. ≤ 0.
4. **Successive-K decrement:** For weak monodentate binding in water, stepwise Kn typically decreases by ~0.5–0.8 log units per step (statistical + electrostatic), as seen in Fe(II)–NH3 (ΔlogK ≈ 0.5–0.6 per step at I=0).

**Assumptions:** (i) aqueous phase only — in real water–MeCN mixed solvent, apparent stability is much larger because bulk MeCN activity is high and the aqua-ion reference state shifts; the constants above apply to dilute aqueous conditions relevant to the aqueous-side Pourbaix. (ii) No hydrolysis coupling. (iii) High-spin octahedral [Fe(H2O)6−n(MeCN)n]²⁺; no spin-state change. (iv) Ionic-strength adjustment from ammonia I=0 baseline to I=0.1 M is small (≤ 0.1 log unit).

**Uncertainty:** dominated by the absence of any direct Fe(II)–nitrile datum; ±0.5 log unit on K1 is realistic, growing to ±1.0 by β4.

**Pourbaix implication:** at typical aqueous [MeCN] ≤ 1 M, these constants predict <10% MeCN speciation of Fe(II) — the aqueous-side Pourbaix diagram for Fe is essentially unperturbed by MeCN complexation, and Fe electrodeposition selectivity in water–MeCN mixed solvent will be dominated by solvent activity, double-layer, and Fe(H2O)6²⁺/Fe(OH)+ hydrolysis rather than by Fe(II)–MeCN complex formation.

**SRD-46 records cited:** metal_62; ligand_9825; ligand_7890; ligand_10103; beta_def_812; beta_def_840; beta_def_872; beta_def_894; vlm_38961; vlm_38962; vlm_73748; vlm_73753; vlm_73761; vlm_73769; vlm_73777; vlm_168274; vlm_168275; vlm_168276; vlm_168277; vlm_168280.

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).
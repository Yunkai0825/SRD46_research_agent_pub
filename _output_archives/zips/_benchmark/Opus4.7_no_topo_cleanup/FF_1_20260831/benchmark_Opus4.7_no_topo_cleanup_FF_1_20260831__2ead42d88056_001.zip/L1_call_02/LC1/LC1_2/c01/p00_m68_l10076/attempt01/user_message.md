[Purpose: Evaluate Fe speciation and Pourbaix behavior in a water-acetonitrile mixed solvent electrolyte to inform Fe electrodeposition design.]
[Tasks:
Model a single aqueous electrolyte containing 0.1 M Fe(II/III) with 1 M acetonitrile (ACN, CH3CN) as a co-solvent/ligand. Compute the Pourbaix (E-pH) diagram over pH 0-14 and a potential window covering Fe(0)/Fe(II)/Fe(III) at 25 C and 0.1 M ionic strength. Report dominant Fe species per region, the Fe(II) stability window, hydroxide/oxide precipitation boundaries, and any acetonitrile complexation. If Fe-acetonitrile stability constants are missing in SRD-46, estimate them from analogous nitrile/soft-N donors in SRD-46 and clearly flag them as estimates. Also produce a pH speciation slice showing Fe(II) fractions across pH.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

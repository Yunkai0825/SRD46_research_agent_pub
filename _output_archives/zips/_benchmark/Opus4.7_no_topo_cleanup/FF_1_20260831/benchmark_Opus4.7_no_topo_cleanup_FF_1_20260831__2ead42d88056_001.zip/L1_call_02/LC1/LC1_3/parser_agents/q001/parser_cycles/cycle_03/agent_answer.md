Committed three estimated aqueous stability entries for Fe³⁺ + acetonitrile (25 °C, I = 0.1 M):

- ML (β = [ML]/[M][L]): log K = −0.5 ± 0.7
- ML₂ (β = [ML₂]/[M][L]²): log β₂ = −1.5 ± 1.0
- ML₃ (β = [ML₃]/[M][L]³): log β₃ = −3.0 ± 1.2

All three are flagged as chemistry-judgment estimates anchored on the SRD-46 Fe³⁺ analogue set (Fe³⁺/phen, Fe³⁺/SCN⁻, Fe³⁺/N₃⁻) plus the ligand-side acetonitrile coverage for Cu⁺/Ag⁺/Pd²⁺; no direct Fe³⁺/CH₃CN measurement exists.
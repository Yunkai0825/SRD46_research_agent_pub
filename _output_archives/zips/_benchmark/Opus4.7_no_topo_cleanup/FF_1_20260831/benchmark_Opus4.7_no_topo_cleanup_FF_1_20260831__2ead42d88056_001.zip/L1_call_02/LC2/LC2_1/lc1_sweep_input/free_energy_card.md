# Free Energy Analysis Card

**System**: H, Fe / Acetonitrile, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+
**Ligands**: [Acetonitrile]
**Generated**: 2026-08-31 23:11:19 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Acetonitrile] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetonitrile] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9825 | CC#N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetonitrile] | CC#N | C | [-3, 3] | true |
| L1 | [Acetonitrile] | CC#N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Acetonitrile] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Acetonitrile] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Fe]3+ + [Acetonitrile] | 25.0 | 0.1 | *** | 3 |
| [Fe]2+ + [Acetonitrile] | 25.0 | 0.1 | *** | 1 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [Acetonitrile] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [Acetonitrile] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [Acetonitrile]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L1].[z+3] | [Fe(Acet)]3+ | +3 | aqueous | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M1]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","CH3CN cannot outcompete H2O on a per-donor basis. Any inner-sphere occupancy of CH3CN on Fe3+ in aqueous solution is therefore negligible; the ~ logK1 \u2248 \u22120.5 estimate reflects mostly the outer-sphere/statistical association."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"In water the effective reaction is Fe(H2O)6^3+ + CH3CN \u21cc Fe(H2O)5(NCCH3)^3+ + H2O. Because H2O is a strong donor to Fe3+ (Fe3+ is highly oxophilic) and CH3CN's proton basicity is ~15 orders of magnitude lower than H2O's O basicity toward H+, CH3CN cannot outcompete H2O on a per-donor basis. Any inner-sphere occupancy of CH3CN on Fe3+ in aqueous solution is therefore negligible; the ~ logK1 \u2248 \u22120.5 estimate reflects mostly the outer-sphere/statistical association.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |
| [M1].[L1]2.[z+3] | [Fe(Acet)2]3+ | +3 | aqueous | -1.5000 | +8.5615 | +8.5615 | +8.5615 | [M1]:+1, [L1]:+2 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","assume \u0394logK per step \u2248 \u22121 (statistical + electrostatic screening + water competition)"],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"For M3+ hexaaqua ions, second- and third-step logK are typically 0.5\u20131.5 units below the previous step even for good ligands (see Fe3+/phen: logK1=6.5, logK2=4.9, logK3=2.7 from vlm_139320/321/322). Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| [M1].[L1]3.[z+3] | [Fe(Acet)3]3+ | +3 | aqueous | -3.0000 | +17.1231 | +17.1231 | +17.1231 | [M1]:+1, [L1]:+3 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"For M3+ hexaaqua ions, second- and third-step logK are typically 0.5\u20131.5 units below the previous step even for good ligands (see Fe3+/phen: logK1=6.5, logK2=4.9, logK3=2.7 from vlm_139320/321/322). Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":1.2}],"source":"SRD46 query estimated values"} |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +35.3877 | [M1]:+1, [OH]:+2 | vlm_170807 | true | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [Acetonitrile]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L1].[z+2] | [Fe(Acet)]2+ | +2 | aqueous | -0.3000 | +1.7123 | +1.7123 | +1.7123 | [M2]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["(i) aqueous phase only \u2014 in real water\u2013MeCN mixed solvent, apparent stability is much larger because bulk MeCN activity is high and the aqua-ion reference state shifts; the constants above apply to dilute aqueous conditions relevant to the aqueous-side Pourbaix.","(ii) No hydrolysis coupling.","(iii) High-spin octahedral [Fe(H2O)6\u2212n(MeCN)n]\u00b2\u207a; no spin-state change.","(iv) Ionic-strength adjustment from ammonia I=0 baseline to I=0.1 M is small (\u2264 0.1 log unit)."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Chemistry-informed route:\n1. Donor-strength calibration on Fe(II) itself using the two simplest neutral monodentate N donors in SRD-46: pyridine (vlm_38961: log K1 = 0.7; vlm_38962: log \u03b22 = 0.9) and ammonia (vlm_73753: log K1 = 1.4; vlm_73761: log \u03b22 = 2.25; vlm_73769: log \u03b23 = 2.68; vlm_73777: log \u03b24 = 2.75). Both are weak-binding, consistent with Fe(II) being poorly matched to neutral \u03c3-donors in water.\n2. Basicity scaling: MeCN protonation pKa \u2248 \u221210 vs. pyridine 5.24 (from auto-enriched bracket on ligand_7890) and NH3 9.26 (ligand_10103). MeCN is dramatically weaker as a Br\u00f8nsted/\u03c3 base. Empirical \u03c3-donor scaling for first-row M(II) suggests log K1(MeCN) is 0.5\u20131.5 units below pyridine.\n3. Cross-metal check: For Ag+, log K1(MeCN) = 0.42 (vlm_168275). Fe(II) has stronger aquation but no MeCN-favoring soft/\u03c0 factor; expected to fall near or below Ag+ value, i.e. \u2264 0.\n4. Successive-K decrement: For weak monodentate binding in water, stepwise Kn typically decreases by ~0.5\u20130.8 log units per step (statistical + electrostatic), as seen in Fe(II)\u2013NH3 (\u0394logK \u2248 0.5\u20130.6 per step at I=0).","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"c4b3b0dc73bca3fae0413b810fe4a998c5bb4c4f82f81b6cbbd0cecb72eb5cb9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275"],"query_answer_sha256":"abc6675e6ddf441048e08212bdc8d22392c81fd57a06e118f9d16fbedf00212d","query_id":"q002","rationale":"Now the key chemistry: Fe(II) is a borderline-hard 3d\u2076 divalent cation, and acetonitrile is a very weak \u03c3-donor with essentially no ligand basicity (pKa of CH3CNH+ \u2248 \u201310). It is a much poorer donor to a hard/borderline first-row M(II) than pyridine or NH3. Even for soft d10 ions where MeCN binds reasonably (Ag+, Cu+, Pd2+), the acetonitrile constants are already tiny (Cu+ \u03b22 = 4.35 in vlm_168274 is anomalously large due to soft-soft \u03c0-backbonding into the C\u2261N \u03c0*; Ag+ log K1 = 0.42 in vlm_168275; Pd2+ log K1 = 1.19 in vlm_168277 at I=1 M \u2014 and these are the *soft* metals that MeCN prefers).","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [M2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M1]:+1, [H]:-3 | vlm_170828 | true | *** |
| [M1].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M1]:+1, [H]:-3 | vlm_170827 | true | *** |
| [M1].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | true | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 18 |
| Included in calculation | 18 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 13 |
| Unresolved (no species in card) | 5 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 2 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 3 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 4 | vlm_170807_patched | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +21.8000 | 25.0 | 0.000 | yes | — |
| 5 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 6 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 7 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 8 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 9 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O] <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |
| 10 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 11 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 12 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 13 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 14 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 15 | session_eq_node_-4000001 | [<Acetonitrile>] + [<Fe3+>] <=> [<Fe3+><Acetonitrile>] | -0.5000 | 25.0 | 0.100 | yes | — |
| 16 | session_eq_node_-4000002 | [<Acetonitrile>]^2 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>2] | -1.5000 | 25.0 | 0.100 | yes | — |
| 17 | session_eq_node_-4000003 | [<Acetonitrile>]^3 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>3] | -3.0000 | 25.0 | 0.100 | yes | — |
| 18 | session_eq_node_-4000004 | [<Acetonitrile>] + [<Fe2+>] <=> [<Fe2+><Acetonitrile>] | -0.3000 | 25.0 | 0.100 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

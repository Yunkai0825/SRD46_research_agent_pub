{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Empty aqueous placeholder (solvent/water reference) retained as the required baseline entry."},
{"phase":"aqueous","core_label":"Fe$+2:1 H:-1","keep":true,"rationale":"SRD-46 [Fe(OH)]+ is the sole Fe(II) monohydroxo cation in this batch and is in scope."},
{"phase":"aqueous","core_label":"Fe$+2:1 H:-2","keep":true,"rationale":"SRD-46 neutral Fe(II) dihydroxo aqueous species; distinct hull member, no twin present."},
{"phase":"aqueous","core_label":"Fe$+2:1 H:-4","keep":true,"rationale":"SRD-46 Fe(II) tetrahydroxo anion [Fe(OH)4]2-; unique species with no duplicate."},
{"phase":"aqueous","core_label":"Fe$+2:1 L1:1","keep":true,"rationale":"Estimated Fe(II)-acetonitrile complex explicitly required by the purpose (ACN as N-donor ligand)."},
{"phase":"aqueous","core_label":"Fe$+3:1 H:-4","keep":true,"rationale":"SRD-46 Fe(III) tetrahydroxo anion [Fe(OH)4]-; unique high-pH Fe(III) species."},
{"phase":"aqueous","core_label":"Fe$+3:1 L1:1","keep":true,"rationale":"Estimated Fe(III)-mono(acetonitrile) complex required by the purpose as distinct hull member."},
{"phase":"aqueous","core_label":"Fe$+3:1 L1:2","keep":true,"rationale":"Estimated Fe(III)-bis(acetonitrile) complex required by the purpose as distinct hull member."},
{"phase":"aqueous","core_label":"Fe$+3:1 L1:3","keep":true,"rationale":"Estimated Fe(III)-tris(acetonitrile) complex required by the purpose as distinct hull member."},
{"phase":"aqueous","core_label":"Fe$+3:3 H:-4","keep":true,"rationale":"Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+ is physically real at 0.1 M Fe and must be retained."},
{"phase":"aqueous","core_label":"Fe$+6:1 H:-8","keep":true,"rationale":"Ferrate [FeO4]2- is the sole Fe(VI) species and closes the upper potential window."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free acetonitrile ligand reference required to define ACN chemical potential in complexation equilibria."},
{"phase":"solid","core_label":"Fe$+0:1","keep":true,"rationale":"Fe(0) metal is the deposition target and required reference solid."},
{"phase":"solid","core_label":"Fe$+2:1 Fe$+3:2 H:-8","keep":true,"rationale":"Magnetite Fe3O4 is a distinct mixed-valence phase relevant at the cathodic/neutral boundary."}
]}
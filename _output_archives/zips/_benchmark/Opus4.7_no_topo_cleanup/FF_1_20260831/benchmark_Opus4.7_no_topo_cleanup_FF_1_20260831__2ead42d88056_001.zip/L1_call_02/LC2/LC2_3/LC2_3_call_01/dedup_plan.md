# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous Fe electrodeposition Pourbaix in a water-rich electrolyte with ACN as auxiliary N-donor ligand; treat water as the solvent (aH2O~1) and ACN as a solute ligand.
- Concentration regime: 0.1 M Fe total (not 1e-6 M corrosion convention), so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real and must be retained as distinct hull competitors.
- Notation duplicates: collapse pure spelling twins from Atlas vs SRD-46 that share stoichiometry, charge, and mu (Fe2+/[Fe]2+, Fe3+/[Fe]3+); for [FeOH]2+ Atlas vs [Fe(OH)]2+ SRD-46 (Delta mu ~1.7 kJ) and the two [Fe(OH)2]+ entries (Delta mu ~5 kJ), keep the SRD-46 version as the internally consistent source. [HFeO2]- and [Fe(OH)3]- are the same Fe(II) trihydroxo anion in different notations: keep the SRD-46 [Fe(OH)3]-.
- Estimated Fe-ACN complexes: purpose explicitly requires them, so keep all three ([Fe(Acet)]2+, [Fe(Acet)]3+/2+/3+ series) as distinct hull members flagged as estimates.
- Hydration/polymorph choice: for Fe(III) oxyhydroxide, keep both amorphous Fe(OH)3 (kinetic deposition product) and alpha-FeOOH/goethite (thermodynamic ground state) because electrodeposition explicitly cares which phase forms; drop the redundant hydrated Fe(OH)3 twin and the redundant Fe(OH)2 twin, retaining the SRD-46 entries. For Fe2O3, keep only the SRD-46 alpha-hematite (Atlas Fe2O3 has ~70 kJ offset indicating a normalization mismatch and would spuriously dominate).
- Mixed-valence and high-valent: retain Fe3O4 magnetite (distinct Fe(II)/Fe(III) chain member relevant at cathodic/neutral boundary) and [FeO4]2- ferrate (only Fe(VI) species, needed to close the upper potential window).
- Reference solids: keep Fe(0) metal (deposition target).

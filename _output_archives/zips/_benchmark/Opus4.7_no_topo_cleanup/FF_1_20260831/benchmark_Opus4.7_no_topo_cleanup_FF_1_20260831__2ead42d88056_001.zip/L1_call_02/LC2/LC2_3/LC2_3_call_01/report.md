# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    244.82
- elapsed_s (total):  244.82
- llm_iterations:     36
- llm_tool_calls:     27

- n_groups:           21
- n_multi_groups:     7
- n_singletons:       14
- n_decisions:        21
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Empty aqueous placeholder for solvent reference; in scope. |
| aqueous | `Fe$+2:1 H:-1` | yes | SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-2` | yes | SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-4` | yes | SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |
| aqueous | `Fe$+2:1 L1:1` | yes | Estimated Fe(II)-acetonitrile complex required by purpose; keep. |
| aqueous | `Fe$+3:1 H:-4` | yes | SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |
| aqueous | `Fe$+3:1 L1:1` | yes | Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:2` | yes | Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:3` | yes | Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate Fe(VI) closes upper potential window; keep. |
| aqueous | `L1:1` | yes | Free acetonitrile ligand reference; in scope. |
| solid | `Fe$+0:1` | yes | Fe(0) metal is the deposition target; keep. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: ac1b03e9de964364b4b90140b40aed67
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe dedup applied cleanly per committed guidance: eight Atlas notation/hydration twins dropped (Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]-, Fe(OH)2 hydr., Fe(OH)3 hydr., Fe2O3 anh.) in favor of internally consistent SRD-46 canonicals. Retained: both Fe(III) oxyhydroxide polymorphs (amorphous [Fe(OH)3](s) and alpha-FeOOH goethite) since electrodeposition distinguishes kinetic vs thermodynamic products; alpha-hematite from SRD-46; polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ real at 0.1 M Fe; all three estimated Fe-ACN complexes required by purpose; Fe3O4 magnetite as mixed-valence chain member; [FeO4]2- ferrate to close upper potential window; Fe(0) as deposition target. Hull is complete and non-redundant for aqueous Fe electrodeposition Pourbaix with ACN co-ligand.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

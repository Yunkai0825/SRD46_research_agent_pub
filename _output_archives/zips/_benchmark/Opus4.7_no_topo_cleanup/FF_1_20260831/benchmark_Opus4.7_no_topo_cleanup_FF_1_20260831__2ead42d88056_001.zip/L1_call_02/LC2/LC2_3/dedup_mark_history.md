# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |
| `DEDUP-41859b22381cbd2d` | `[Fe(Acet)]2+` | SRD46 query estimated values | generation 1: kept — Estimated Fe(II)-acetonitrile complex required by purpose; keep. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |
| `DEDUP-a706452a17d92d7b` | `[Fe(Acet)]3+` | SRD46 query estimated values | generation 1: kept — Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |
| `DEDUP-49144781e9d2e1d4` | `[Fe(Acet)2]3+` | SRD46 query estimated values | generation 1: kept — Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |
| `DEDUP-e815279089a844ec` | `[Fe(Acet)3]3+` | SRD46 query estimated values | generation 1: kept — Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate Fe(VI) closes upper potential window; keep. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Fe(0) metal is the deposition target; keep. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Empty aqueous placeholder for solvent reference; in scope. |
| — | `[Acetonitrile]` | SRD-46 | generation 1: kept — Free acetonitrile ligand reference; in scope. |

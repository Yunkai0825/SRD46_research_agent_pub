[Orchestration session]
ac1b03e9de964364b4b90140b40aed67

[Calculation purpose]
Evaluate Fe speciation and Pourbaix behavior in a water-acetonitrile mixed solvent electrolyte to inform Fe electrodeposition design.

[Requested tasks]
Model a single aqueous electrolyte containing 0.1 M Fe(II/III) with 1 M acetonitrile (ACN, CH3CN) as a co-solvent/ligand. Compute the Pourbaix (E-pH) diagram over pH 0-14 and a potential window covering Fe(0)/Fe(II)/Fe(III) at 25 C and 0.1 M ionic strength. Report dominant Fe species per region, the Fe(II) stability window, hydroxide/oxide precipitation boundaries, and any acetonitrile complexation. If Fe-acetonitrile stability constants are missing in SRD-46, estimate them from analogous nitrile/soft-N donors in SRD-46 and clearly flag them as estimates. Also produce a pH speciation slice showing Fe(II) fractions across pH.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous Fe electrodeposition Pourbaix in a water-rich electrolyte with ACN as auxiliary N-donor ligand; treat water as the solvent (aH2O~1) and ACN as a solute ligand.
- Concentration regime: 0.1 M Fe total (not 1e-6 M corrosion convention), so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real and must be retained as distinct hull competitors.
- Notation duplicates: collapse pure spelling twins from Atlas vs SRD-46 that share stoichiometry, charge, and mu (Fe2+/[Fe]2+, Fe3+/[Fe]3+); for [FeOH]2+ Atlas vs [Fe(OH)]2+ SRD-46 (Delta mu ~1.7 kJ) and the two [Fe(OH)2]+ entries (Delta mu ~5 kJ), keep the SRD-46 version as the internally consistent source. [HFeO2]- and [Fe(OH)3]- are the same Fe(II) trihydroxo anion in different notations: keep the SRD-46 [Fe(OH)3]-.
- Estimated Fe-ACN complexes: purpose explicitly requires them, so keep all three ([Fe(Acet)]2+, [Fe(Acet)]3+/2+/3+ series) as distinct hull members flagged as estimates.
- Hydration/polymorph choice: for Fe(III) oxyhydroxide, keep both amorphous Fe(OH)3 (kinetic deposition product) and alpha-FeOOH/goethite (thermodynamic ground state) because electrodeposition explicitly cares which phase forms; drop the redundant hydrated Fe(OH)3 twin and the redundant Fe(OH)2 twin, retaining the SRD-46 entries. For Fe2O3, keep only the SRD-46 alpha-hematite (Atlas Fe2O3 has ~70 kJ offset indicating a normalization mismatch and would spuriously dominate).
- Mixed-valence and high-valent: retain Fe3O4 magnetite (distinct Fe(II)/Fe(III) chain member relevant at cathodic/neutral boundary) and [FeO4]2- ferrate (only Fe(VI) species, needed to close the upper potential window).
- Reference solids: keep Fe(0) metal (deposition target).

[Committed element instructions]
- Fe: Collapse pure notation twins to the SRD-46 entry: drop Atlas Fe2+ (keep SRD-46 [Fe]2+), drop Atlas Fe3+ (keep SRD-46 [Fe]3+), drop Atlas [FeOH]2+ (keep SRD-46 [Fe(OH)]2+), drop Atlas [Fe(OH)2]+ (keep SRD-46 [Fe(OH)2]+), drop Atlas [HFeO2]- (keep SRD-46 [Fe(OH)3]- as the same Fe(II) trihydroxo anion), drop the hydrated-solid twins Atlas Fe(OH)2 and Atlas Fe(OH)3 (keep SRD-46 [Fe(OH)2](s) and [Fe(OH)3](s)), and drop Atlas Fe2O3 (keep SRD-46 alpha-hematite whose mu is internally consistent). Keep everything else: both Fe(III) oxyhydroxide polymorphs ([Fe(OH)3](s) amorphous and alpha-FeOOH) since electrodeposition distinguishes kinetic vs thermodynamic products, all polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) which are real at 0.1 M Fe, all three estimated Fe-acetonitrile complexes required by the purpose, Fe3O4 magnetite, [FeO4]2- ferrate, and Fe(0) metal.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +202.623 | generation 1: kept — SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |  |
| `DEDUP-41859b22381cbd2d` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Acet)]2+` | SRD46 query estimated values | +1.712 | generation 1: kept — Estimated Fe(II)-acetonitrile complex required by purpose; keep. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.737 | generation 1: kept — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |  |
| `DEDUP-a706452a17d92d7b` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Acet)]3+` | SRD46 query estimated values | +77.204 | generation 1: kept — Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |  |
| `DEDUP-49144781e9d2e1d4` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Acet)2]3+` | SRD46 query estimated values | +82.911 | generation 1: kept — Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |  |
| `DEDUP-e815279089a844ec` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(Acet)3]3+` | SRD46 query estimated values | +91.473 | generation 1: kept — Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate Fe(VI) closes upper potential window; keep. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Fe(0) metal is the deposition target; keep. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Notation/hydration twin collapsed to SRD-46 entry per element instructions. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Empty aqueous placeholder for solvent reference; in scope. | Empty aqueous placeholder for solvent reference; in scope. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. | SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. | SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. | SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Acet)]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(II)-acetonitrile complex required by purpose; keep. | Estimated Fe(II)-acetonitrile complex required by purpose; keep. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. | SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Acet)]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:2` | Fe | aqueous | `[Fe(Acet)2]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:3` | Fe | aqueous | `[Fe(Acet)3]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. | Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate Fe(VI) closes upper potential window; keep. | Ferrate Fe(VI) closes upper potential window; keep. |
| aqueous | `L1:1` | — | — | `[Acetonitrile]` | SRD-46 | kept | true | generation 1: kept — Free acetonitrile ligand reference; in scope. | Free acetonitrile ligand reference; in scope. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Fe(0) metal is the deposition target; keep. | Fe(0) metal is the deposition target; keep. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; keep. | Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse pure notation twins to the SRD-46 entry: drop Atlas Fe2+ (keep SRD-46 [Fe]2+), drop Atlas Fe3+ (keep SRD-46 [Fe]3+), drop Atlas [FeOH]2+ (keep SRD-46 [Fe(OH)]2+), drop Atlas [Fe(OH)2]+ (keep SRD-46 [Fe(OH)2]+), drop Atlas [HFeO2]- (keep SRD-46 [Fe(OH)3]- as the same Fe(II) trihydroxo anion), drop the hydrated-solid twins Atlas Fe(OH)2 and Atlas Fe(OH)3 (keep SRD-46 [Fe(OH)2](s) and [Fe(OH)3](s)), and drop Atlas Fe2O3 (keep SRD-46 alpha-hematite whose mu is internally consistent). Keep everything else: both Fe(III) oxyhydroxide polymorphs ([Fe(OH)3](s) amorphous and alpha-FeOOH) since electrodeposition distinguishes kinetic vs thermodynamic products, all polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) which are real at 0.1 M Fe, all three estimated Fe-acetonitrile complexes required by the purpose, Fe3O4 magnetite, [FeO4]2- ferrate, and Fe(0) metal.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-d63c0f9c5f3c796d` | aqueous | `[Fe(OH)3]-` | SRD-46 | -1 | 165.523 | 1 |
| `DEDUP-d4163178d9826de9` | aqueous | `[HFeO2]-` | Atlas | -1 | 180.134 | 1 |
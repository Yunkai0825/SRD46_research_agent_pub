Kept:
- [(Fe2O3)0.5(s,alpha)] (SRD-46) — alpha-hematite, internally consistent mu
- [FeO(OH)(s,alpha)] (SRD-46) — goethite, thermodynamic Fe(III) oxyhydroxide
- [Fe(OH)3](s) (SRD-46) — amorphous Fe(III) hydroxide, kinetic deposition product

Dropped:
- Fe(OH)3 (hydr.) (Atlas) — notation twin of SRD-46 [Fe(OH)3](s)
- Fe2O3 (anh.) (Atlas) — ~70 kJ offset vs SRD-46 alpha-hematite indicates normalization mismatch
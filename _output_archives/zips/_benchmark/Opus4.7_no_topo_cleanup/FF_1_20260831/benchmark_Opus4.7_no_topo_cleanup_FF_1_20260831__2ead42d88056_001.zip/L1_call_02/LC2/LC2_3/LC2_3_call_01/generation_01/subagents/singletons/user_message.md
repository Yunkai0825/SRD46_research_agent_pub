[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse pure notation twins to the SRD-46 entry: drop Atlas Fe2+ (keep SRD-46 [Fe]2+), drop Atlas Fe3+ (keep SRD-46 [Fe]3+), drop Atlas [FeOH]2+ (keep SRD-46 [Fe(OH)]2+), drop Atlas [Fe(OH)2]+ (keep SRD-46 [Fe(OH)2]+), drop Atlas [HFeO2]- (keep SRD-46 [Fe(OH)3]- as the same Fe(II) trihydroxo anion), drop the hydrated-solid twins Atlas Fe(OH)2 and Atlas Fe(OH)3 (keep SRD-46 [Fe(OH)2](s) and [Fe(OH)3](s)), and drop Atlas Fe2O3 (keep SRD-46 alpha-hematite whose mu is internally consistent). Keep everything else: both Fe(III) oxyhydroxide polymorphs ([Fe(OH)3](s) amorphous and alpha-FeOOH) since electrodeposition distinguishes kinetic vs thermodynamic products, all polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) which are real at 0.1 M Fe, all three estimated Fe-acetonitrile complexes required by the purpose, Fe3O4 magnetite, [FeO4]2- ferrate, and Fe(0) metal.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 202.623 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Acet)]2+` | SRD46 query estimated values | +2 | 1.712 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Acet)]3+` | SRD46 query estimated values | +3 | 77.204 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Acet)2]3+` | SRD46 query estimated values | +3 | 82.911 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(Acet)3]3+` | SRD46 query estimated values | +3 | 91.473 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Acetonitrile]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
Session closed. The Fe inventory for the 0.1 M Fe / 1 M acetonitrile electrodeposition Pourbaix has been deduplicated and committed as final.

Kept (17 Fe-bearing entries + solvent/ligand references):
- Aqueous mononuclear: [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]−, [Fe(OH)4]2−, [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]−
- Polynuclear Fe(III) hydrolysis (real at 0.1 M): [Fe2(OH)2]4+, [Fe3(OH)4]5+
- Fe(VI): [FeO4]2− (closes upper potential window)
- Estimated Fe–acetonitrile complexes (flagged): [Fe(Acet)]2+, [Fe(Acet)]3+, [Fe(Acet)2]3+, [Fe(Acet)3]3+
- Solids: Fe(0) metal, Fe3O4 magnetite, α-Fe2O3 hematite (SRD-46), α-FeOOH goethite, amorphous [Fe(OH)3](s), [Fe(OH)2](s)

Dropped as notation/source twins of SRD-46 canonical entries:
- Atlas Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]−, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)

Both Fe(III) oxyhydroxide polymorphs (thermodynamic goethite and kinetic amorphous Fe(OH)3) are retained deliberately because electrodeposition distinguishes which phase forms.
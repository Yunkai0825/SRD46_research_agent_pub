## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Orchestration session]
ac1b03e9de964364b4b90140b40aed67

[Calculation purpose]
Evaluate Fe speciation and Pourbaix behavior in a water-acetonitrile mixed solvent electrolyte to inform Fe electrodeposition design.

[Requested tasks]
Model a single aqueous electrolyte containing 0.1 M Fe(II/III) with 1 M acetonitrile (ACN, CH3CN) as a co-solvent/ligand. Compute the Pourbaix (E-pH) diagram over pH 0-14 and a potential window covering Fe(0)/Fe(II)/Fe(III) at 25 C and 0.1 M ionic strength. Report dominant Fe species per region, the Fe(II) stability window, hydroxide/oxide precipitation boundaries, and any acetonitrile complexation. If Fe-acetonitrile stability constants are missing in SRD-46, estimate them from analogous nitrile/soft-N donors in SRD-46 and clearly flag them as estimates. Also produce a pH speciation slice showing Fe(II) fractions across pH.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous Fe electrodeposition Pourbaix in a water-rich electrolyte with ACN as auxiliary N-donor ligand; treat water as the solvent (aH2O~1) and ACN as a solute ligand.
- Concentration regime: 0.1 M Fe total (not 1e-6 M corrosion convention), so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real and must be retained as distinct hull competitors.
- Notation duplicates: collapse pure spelling twins from Atlas vs SRD-46 that share stoichiometry, charge, and mu (Fe2+/[Fe]2+, Fe3+/[Fe]3+); for [FeOH]2+ Atlas vs [Fe(OH)]2+ SRD-46 (Delta mu ~1.7 kJ) and the two [Fe(OH)2]+ entries (Delta mu ~5 kJ), keep the SRD-46 version as the internally consistent source. [HFeO2]- and [Fe(OH)3]- are the same Fe(II) trihydroxo anion in different notations: keep the SRD-46 [Fe(OH)3]-.
- Estimated Fe-ACN complexes: purpose explicitly requires them, so keep all three ([Fe(Acet)]2+, [Fe(Acet)]3+/2+/3+ series) as distinct hull members flagged as estimates.
- Hydration/polymorph choice: for Fe(III) oxyhydroxide, keep both amorphous Fe(OH)3 (kinetic deposition product) and alpha-FeOOH/goethite (thermodynamic ground state) because electrodeposition explicitly cares which phase forms; drop the redundant hydrated Fe(OH)3 twin and the redundant Fe(OH)2 twin, retaining the SRD-46 entries. For Fe2O3, keep only the SRD-46 alpha-hematite (Atlas Fe2O3 has ~70 kJ offset indicating a normalization mismatch and would spuriously dominate).
- Mixed-valence and high-valent: retain Fe3O4 magnetite (distinct Fe(II)/Fe(III) chain member relevant at cathodic/neutral boundary) and [FeO4]2- ferrate (only Fe(VI) species, needed to close the upper potential window).
- Reference solids: keep Fe(0) metal (deposition target).

[Committed element instructions]
- Fe: Collapse pure notation twins to the SRD-46 entry: drop Atlas Fe2+ (keep SRD-46 [Fe]2+), drop Atlas Fe3+ (keep SRD-46 [Fe]3+), drop Atlas [FeOH]2+ (keep SRD-46 [Fe(OH)]2+), drop Atlas [Fe(OH)2]+ (keep SRD-46 [Fe(OH)2]+), drop Atlas [HFeO2]- (keep SRD-46 [Fe(OH)3]- as the same Fe(II) trihydroxo anion), drop the hydrated-solid twins Atlas Fe(OH)2 and Atlas Fe(OH)3 (keep SRD-46 [Fe(OH)2](s) and [Fe(OH)3](s)), and drop Atlas Fe2O3 (keep SRD-46 alpha-hematite whose mu is internally consistent). Keep everything else: both Fe(III) oxyhydroxide polymorphs ([Fe(OH)3](s) amorphous and alpha-FeOOH) since electrodeposition distinguishes kinetic vs thermodynamic products, all polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) which are real at 0.1 M Fe, all three estimated Fe-acetonitrile complexes required by the purpose, Fe3O4 magnetite, [FeO4]2- ferrate, and Fe(0) metal.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +202.623 | generation 1: kept — SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |  |
| `DEDUP-41859b22381cbd2d` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Acet)]2+` | SRD46 query estimated values | +1.712 | generation 1: kept — Estimated Fe(II)-acetonitrile complex required by purpose; keep. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.737 | generation 1: kept — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |  |
| `DEDUP-a706452a17d92d7b` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Acet)]3+` | SRD46 query estimated values | +77.204 | generation 1: kept — Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |  |
| `DEDUP-49144781e9d2e1d4` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Acet)2]3+` | SRD46 query estimated values | +82.911 | generation 1: kept — Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |  |
| `DEDUP-e815279089a844ec` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(Acet)3]3+` | SRD46 query estimated values | +91.473 | generation 1: kept — Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate Fe(VI) closes upper potential window; keep. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Fe(0) metal is the deposition target; keep. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Notation/hydration twin collapsed to SRD-46 entry per element instructions. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Empty aqueous placeholder for solvent reference; in scope. | Empty aqueous placeholder for solvent reference; in scope. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. | Notation twins with identical charge and mu; keep SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. | SRD-46 Fe(II) monohydroxo cation; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. | SRD-46 neutral Fe(II) dihydroxo complex; distinct in-scope species. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. | Notation twin: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) trihydroxo anion; keep SRD-46 per case-specific guidance. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. | SRD-46 Fe(II) tetrahydroxo dianion; distinct in-scope species. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Acet)]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(II)-acetonitrile complex required by purpose; keep. | Estimated Fe(II)-acetonitrile complex required by purpose; keep. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. | Pure notation twin; keep SRD-46 [Fe]3+ and drop Atlas Fe3+ per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. | Dropped Atlas [FeOH]2+ as pure notation twin of SRD-46 [Fe(OH)]2+; kept polynuclear [Fe2(OH)2]4+ as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. | Notation twin: keep SRD-46 [Fe(OH)2]+ as internally consistent source; drop Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. | SRD-46 Fe(III) tetrahydroxo anion; distinct in-scope species. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Acet)]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:1 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:2` | Fe | aqueous | `[Fe(Acet)2]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:2 complex required by purpose; keep. |
| aqueous | `Fe$+3:1 L1:3` | Fe | aqueous | `[Fe(Acet)3]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. | Estimated Fe(III)-ACN 1:3 complex required by purpose; keep. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. | Polynuclear Fe(III) hydrolysis species real at 0.1 M Fe; keep. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate Fe(VI) closes upper potential window; keep. | Ferrate Fe(VI) closes upper potential window; keep. |
| aqueous | `L1:1` | — | — | `[Acetonitrile]` | SRD-46 | kept | true | generation 1: kept — Free acetonitrile ligand reference; in scope. | Free acetonitrile ligand reference; in scope. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Fe(0) metal is the deposition target; keep. | Fe(0) metal is the deposition target; keep. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; keep. | Magnetite Fe3O4 is a distinct mixed-valence phase; keep. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Notation/hydration twin collapsed to SRD-46 entry per element instructions. | Notation/hydration twin collapsed to SRD-46 entry per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. | Keep SRD-46 alpha-hematite and both Fe(III) oxyhydroxide polymorphs (goethite and amorphous Fe(OH)3); drop Atlas hydrated Fe(OH)3 twin and Atlas Fe2O3 per case-specific instructions. |


## Assistant
<summary>The dedup outcome matches the committed instructions exactly: all Atlas notation twins dropped, SRD-46 canonical entries retained, both Fe(III) oxyhydroxide polymorphs kept, polynuclear species preserved, all three estimated Fe-ACN complexes retained, magnetite and ferrate kept, Fe(0) kept. No corrections needed.</summary>
<tool_call>commit_final(summary='Fe dedup applied cleanly: A…')</tool_call>

## User
<tool_result>
ERROR: invalid JSON: JSONDecodeError('Expecting value: line 1 column 1 (char 0)')
</tool_result>

## Assistant
<summary>Tool call needs JSON payload string; retrying with proper JSON.</summary>
<tool_call>commit_final(json_payload='{"summary": "Fe dedup appli…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<summary>Final commit recorded. Fe deduplication is consistent with the committed case recommendations: Atlas notation twins dropped in favor of SRD-46 canonical entries; polymorphs (hematite, goethite, amorphous Fe(OH)3), polynuclear hydrolysis species, all three estimated Fe-ACN complexes, magnetite, ferrate, and Fe(0) all retained as distinct hull members appropriate for the 0.1 M Fe electrodeposition Pourbaix scenario.</summary>

<answer>
Session closed. The Fe inventory for the 0.1 M Fe / 1 M acetonitrile electrodeposition Pourbaix has been deduplicated and committed as final.

Kept (17 Fe-bearing entries + solvent/ligand references):
- Aqueous mononuclear: [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]−, [Fe(OH)4]2−, [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]−
- Polynuclear Fe(III) hydrolysis (real at 0.1 M): [Fe2(OH)2]4+, [Fe3(OH)4]5+
- Fe(VI): [FeO4]2− (closes upper potential window)
- Estimated Fe–acetonitrile complexes (flagged): [Fe(Acet)]2+, [Fe(Acet)]3+, [Fe(Acet)2]3+, [Fe(Acet)3]3+
- Solids: Fe(0) metal, Fe3O4 magnetite, α-Fe2O3 hematite (SRD-46), α-FeOOH goethite, amorphous [Fe(OH)3](s), [Fe(OH)2](s)

Dropped as notation/source twins of SRD-46 canonical entries:
- Atlas Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]−, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)

Both Fe(III) oxyhydroxide polymorphs (thermodynamic goethite and kinetic amorphous Fe(OH)3) are retained deliberately because electrodeposition distinguishes which phase forms.
</answer>
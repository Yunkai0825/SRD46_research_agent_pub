# Free Energy Analysis Card

**System**: metal_61 + ligand_9825
**Metals**: [Fe]3+
**Ligands**: [Acetonitrile]
**Generated**: 2026-08-31 23:11:19 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+3 | Metal component: [Fe]3+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Acetonitrile] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetonitrile] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9825 | CC#N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+3 | [Fe]3+ | +3 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetonitrile] | CC#N | C | [-3, 3] | true |
| L1 | [Acetonitrile] | CC#N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+3 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Acetonitrile] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Acetonitrile] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]3+ + [Acetonitrile] | 25.0 | 0.1 | *** | 3 |
| [Fe]3+ + [OH]- | 25.0 | 0~0.1 | 27465 | 8 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Acetonitrile] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [Acetonitrile] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [Acetonitrile]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[L1].[z+3] | [Fe(Acet)]3+ | +3 | aqueous | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [Fe$+3]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","CH3CN cannot outcompete H2O on a per-donor basis. Any inner-sphere occupancy of CH3CN on Fe3+ in aqueous solution is therefore negligible; the ~ logK1 \u2248 \u22120.5 estimate reflects mostly the outer-sphere/statistical association."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"In water the effective reaction is Fe(H2O)6^3+ + CH3CN \u21cc Fe(H2O)5(NCCH3)^3+ + H2O. Because H2O is a strong donor to Fe3+ (Fe3+ is highly oxophilic) and CH3CN's proton basicity is ~15 orders of magnitude lower than H2O's O basicity toward H+, CH3CN cannot outcompete H2O on a per-donor basis. Any inner-sphere occupancy of CH3CN on Fe3+ in aqueous solution is therefore negligible; the ~ logK1 \u2248 \u22120.5 estimate reflects mostly the outer-sphere/statistical association.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1]2.[z+3] | [Fe(Acet)2]3+ | +3 | aqueous | -1.5000 | +8.5615 | +8.5615 | +8.5615 | [Fe$+3]:+1, [L1]:+2 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","assume \u0394logK per step \u2248 \u22121 (statistical + electrostatic screening + water competition)"],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"For M3+ hexaaqua ions, second- and third-step logK are typically 0.5\u20131.5 units below the previous step even for good ligands (see Fe3+/phen: logK1=6.5, logK2=4.9, logK3=2.7 from vlm_139320/321/322). Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1]3.[z+3] | [Fe(Acet)3]3+ | +3 | aqueous | -3.0000 | +17.1231 | +17.1231 | +17.1231 | [Fe$+3]:+1, [L1]:+3 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["conditions applied to all three entries: temperature_c = 25.0, ionic_strength_mol_l = 0.1, solvent = water (aqueous convention; the ML species is the inner-sphere complex expressed relative to Fe(H2O)6^3+ + L(aq)), electrolyte unspecified (NaClO4 or NaCl typical for SRD-46 Fe3+ records).","Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"estimates from chemistry judgment anchored on the SRD-46 Fe3+ analogue set","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"ce228c3ca30fd30faef643534185bfd87cb8654dfb46c2411975aa37233aee1d","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_139320","vlm_139321","vlm_139322","vlm_172282","vlm_172303","vlm_173624","vlm_173630","vlm_173634","vlm_171933","vlm_168274","vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_sha256":"37d134be9e2940e2115714c956e6f6e480993bcbeaee2bff192596eef6d5c102","query_id":"q001","rationale":"For M3+ hexaaqua ions, second- and third-step logK are typically 0.5\u20131.5 units below the previous step even for good ligands (see Fe3+/phen: logK1=6.5, logK2=4.9, logK3=2.7 from vlm_139320/321/322). Applying \u0394logK \u2248 \u22121 per step to a nearly non-binding first step gives the ML2, ML3 estimates.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":1.2}],"source":"SRD46 query estimated values"} |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [Fe$+3]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [Fe$+3]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +35.3877 | [Fe$+3]:+1, [OH]:+2 | vlm_170807_patched | true | *** |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [Fe$+3]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [Fe$+3]:+1, [OH]:+4 | vlm_170808 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH]3.[z+0(s)[1]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [Fe$+3]:+1, [H]:-3 | vlm_170828 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[2]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [Fe$+3]:+1, [H]:-3 | vlm_170827 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[3]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [Fe$+3]:+1, [OH]:+3 | vlm_170825 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 11 |
| Included in calculation | 11 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 11 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000001 | [<Acetonitrile>] + [<Fe3+>] <=> [<Fe3+><Acetonitrile>] | -0.5000 | 25.0 | 0.100 | yes | [Fe(Acet)]3+ |
| 2 | session_eq_node_-4000002 | [<Acetonitrile>]^2 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>2] | -1.5000 | 25.0 | 0.100 | yes | [Fe(Acet)2]3+ |
| 3 | session_eq_node_-4000003 | [<Acetonitrile>]^3 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>3] | -3.0000 | 25.0 | 0.100 | yes | [Fe(Acet)3]3+ |
| 4 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 5 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 6 | vlm_170807_patched | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +21.8000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 7 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 8 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 9 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 10 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 11 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O] <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

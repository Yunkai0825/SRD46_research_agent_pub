inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M ionic strength stated by task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 0.1,    "basis": "known", "note": "0.1 M Fe(II/III) total stated by task; element-level total appropriate for redox axis mode"},
  {"id": "ACN", "lhs": lambda s: s.total["ligand_9825"], "value": 1.0, "basis": "known", "note": "1 M acetonitrile co-solvent/ligand stated by task"},
]
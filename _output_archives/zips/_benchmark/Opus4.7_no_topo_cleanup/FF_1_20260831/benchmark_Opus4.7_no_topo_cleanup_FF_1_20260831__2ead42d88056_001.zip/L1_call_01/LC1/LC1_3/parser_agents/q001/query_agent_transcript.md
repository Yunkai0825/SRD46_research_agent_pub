SRD-46 has no direct or reaction-frame-matched analogue for aqueous Fe(3+) + neutral DMF association. Below is the evidence and the resulting chemistry-based estimate.

## SRD-46 evidence search

| Query | Result |
|---|---|
| `search_stability` on ligand_11422 (any metal) | 0 rows — DMF has no stability data in SRD-46 |
| `inspect_card` ligand_11422 | Class = "Ligands not selected"; 0 metal partners; no pKa; no fingerprint |
| `search_similar_ligands` on ligand_11422 | Error — no fingerprint data available |
| Fe3+ (metal_61) amide/urea-motif ligand scan | 50 hits, **all hydroxamic acids or amide-tethered polydentate chelates** (e.g., ligand_9873 acetohydroxamic acid, ligand_6982 glycinehydroxamic acid, ligand_9910 desferrioxamine B); every one deprotonates its N–OH to give an anionic (O⁻,O) chelate — a fundamentally different reaction frame from neutral monodentate DMF |
| Fe3+ with DMSO / formamide / acetamide / urea / NMP / THF | 0 rows |

**Conclusion of the SRD-46 search:** no measured logK, no reaction-frame-matched analogue, and no fingerprint-based similarity route is available. The estimate below is therefore made from chemistry reasoning, clearly labeled as such.

## Chemistry reasoning for the estimate

Species definition: **Fe³⁺ + DMF ⇌ [Fe(DMF)]³⁺**, neutral monodentate O-donor (amide carbonyl O), no proton coupling, no hydroxo bridging, 25 °C, I = 0.1 M (aqueous reference state).

Key structural/thermodynamic considerations for DMF:
- Neutral, monodentate, O-donor through the carbonyl oxygen (amide N is delocalized into C=O and is a very poor donor).
- Strongly basic amide O relative to water: DMF pKBH+ ≈ −0.3 to −1 (i.e., DMF is a moderately strong H-bond acceptor and Gutmann donor number DN ≈ 26.6, vs H₂O DN ≈ 18 and DMSO DN ≈ 29.8).
- No net charge change on complexation ⇒ small electrostatic driving force; binding is essentially donor-strength driven.
- In water, DMF must displace one aquo ligand of hard, hexaaquo Fe(H₂O)₆³⁺; the substitution is nearly isodesmic (O for O) with a modest donor-strength gain.

Fe³⁺ is a hard Lewis acid that binds anionic O-donors very strongly (e.g., Fe³⁺ + F⁻ logK₁ ≈ 6; Fe³⁺ + SO₄²⁻ logK₁ ≈ 4; Fe³⁺ + acetate logK₁ ≈ 3.4 at I = 0.1 M). Neutral O-donors bind much more weakly because they lack the ionic contribution — for the classical "monodentate neutral O donor" reference points in the aqueous coordination-chemistry literature (Hancock, Martell; not in SRD-46 for this system):

| Neutral O-donor | Fe³⁺ logK₁ (aq, 25 °C, I≈0.1) | Comment |
|---|---|---|
| H₂O | 0 (reference) | self-exchange |
| Urea | ≈ 0.4–0.8 | weak, similar donor strength to DMF |
| DMSO | ≈ 1.2–1.6 | DN 29.8, upper bracket |
| Acetone | ≈ 0.3–0.6 | weak |

DMF sits **between urea and DMSO** in donor strength (DN 26.6). By donor-number interpolation and by analogy with the well-studied M³⁺ / neutral-amide association behavior:

- **Estimated logK₁ ≈ 0.8 ± 0.5** for Fe³⁺ + DMF ⇌ [Fe(DMF)]³⁺, 25 °C, I = 0.1 M (aq).
- Higher-order stepwise constants (logK₂, logK₃…) are expected to decrease by ~0.3–0.5 per step (statistical + steric), and the cumulative β_n values quickly become negligible relative to Fe(III) hydrolysis (pKa₁ of Fe(H₂O)₆³⁺ ≈ 2.2), so beyond n = 1 the species are not populated in aqueous-rich medium.

**Speciation relevance for Pourbaix / electrodeposition:** in a water-DMF mixed solvent, at any pH where free Fe³⁺ is not overwhelmed by hydrolysis (roughly pH < 2), the small logK₁ means DMF will only compete with water at very high DMF mole fraction. Above pH ≈ 2–3, Fe(OH)ₓ hydrolysis products dominate the Pourbaix diagram regardless of DMF; DMF acts mainly as a bulk co-solvent modifying activity coefficients and Fe(III) hydrolysis equilibria, not as a Fe(III)-chelating ligand in the coordination sense.

## Dummy stability record (self-contained)

| Field | Value |
|---|---|
| metal_id | metal_61 |
| ligand_id | ligand_11422 |
| beta_definition | Fe³⁺ + L ⇌ FeL³⁺ (n = 1, neutral monodentate, HxL form = L, no protonation change) |
| constant_type | K (stepwise, log₁₀) |
| constant_value | **0.8** |
| uncertainty (1σ) | ± 0.5 |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (aqueous reference) |
| electrolyte | unspecified 1:1 background (0.1 M) |
| SRD-46 vlm_id support | *none — no measurements exist for this system* |
| Reference-state analogues consulted (SRD-46) | metal_61 amide-motif scan returned only hydroxamates (e.g., ligand_9873, ligand_9910, ligand_6982) — rejected as wrong reaction frame (anionic (O⁻,O) chelation, not neutral monodentate O) |
| Route | Chemical estimate from Gutmann donor-number interpolation between water (DN 18), urea, DMF (DN 26.6), and DMSO (DN 29.8); calibrated to typical Fe³⁺ + neutral-O-donor logK₁ (literature/textbook, not SRD-46) |
| Higher-order species | β₂, β₃… not recommended for the Pourbaix map — set inactive or ≪ hydrolysis products (Fe(OH)²⁺ logK ≈ −2.2 already dominates by pH 2–3) |
| Assumptions | Aqueous reference state; DMF treated as neutral monodentate O-donor; ignore DMF-induced medium effects on Fe(III) hydrolysis (these must be handled separately in the mixed-solvent Pourbaix module) |
| Confidence | Low — pure chemistry judgment, no SRD-46 numerical support |

**Source:** NIST SRD-46 (queried tables: ligandmetal_card, ligandmetal_stability_measured, ligand_card). No matching records; estimate is chemistry-based and clearly labeled as such.

Now I have the SRD-46-anchored bracketing evidence. Let me interpret and finalize.

## Fe(III) + DMF: SRD-46-anchored bracketing evidence

### Direct data — none exists
- `search_stability` on `ligand_11422` (DMF, any metal) → 0 rows
- `inspect_card` `ligand_11422` → 0 metal partners, no fingerprint, class "Ligands not selected"
- Fe³⁺ (metal_61) with DMSO / formamide / acetamide / urea / NMP / THF / sulfoxide / pyrrolidone → 0 rows
- `search_similar_ligands` `ligand_11422` → no fingerprint available (route unavailable)

### SRD-46 upper anchors — Fe³⁺ + small anionic O-donor, 1:1 ML (`beta_def_812` = [M]+[L]⇌[ML]), 25 °C, I = 0.1 M

| ligand_id | Ligand | logK₁ | vlm_prefixed |
|---|---|---|---|
| ligand_10148 | HSO₄⁻ (hydrogensulfate) | **2.80** | vlm_176061 |
| ligand_8465 | acetate (CH₃COO⁻) | **3.60** | vlm_144783 |
| ligand_10149 | thiosulfate (S₂O₃²⁻) | 1.98 | vlm_176248 |
| ligand_10092 | thiocyanate (NCS⁻) | 2.37 | vlm_172282 |
| ligand_10106 | azide (N₃⁻) | 4.60 | vlm_173624 |
| ligand_9192 | phenolate (PhO⁻) | 7.78 | vlm_159875 |

Anchor logic: DMF is neutral, so it *cannot* deliver the ~2–4 log unit ionic contribution that even a singly charged, weakly basic anionic O-donor like acetate or bisulfate gives Fe³⁺. Therefore **logK₁(Fe³⁺–DMF) must sit well below ~2**.

### SRD-46 lower anchor — Fe³⁺ hydrolysis dominance
Every Fe³⁺ system in the 25 °C, I = 0.1 M window that involves H₂O appears as ternary M(OH)L species (e.g. vlm_99820 `[ML]/[M(OH)L][H]` = 5.78 for glyphosate, vlm_101099 = 11.78 for EHPG). SRD-46 does not carry pure Fe³⁺ + H₂O ⇌ FeOH²⁺ + H⁺ in `ligandmetal_stability_measured`, but the widely cited value is pKₐ₁(Fe(H₂O)₆³⁺) ≈ 2.2 (aq, 25 °C, I ≈ 0.1 M; NIST critical database & Baes-Mesmer, not in SRD-46 for this system). This means that above pH ≈ 2, hydrolysis dominates any neutral O-donor association.

### Neutral-O-donor scaling (chemistry knowledge, not SRD-46)
Textbook aqueous logK₁ for Fe³⁺ with neutral monodentate O-donors:

| Donor | Gutmann DN | logK₁(Fe³⁺), aq, 25 °C |
|---|---|---|
| H₂O | 18 | 0 (ref) |
| urea | ~22 | 0.4–0.8 |
| **DMF** | **26.6** | **estimated target** |
| DMSO | 29.8 | 1.2–1.6 |

DMF sits between urea and DMSO by donor number.

### Final estimate

Combining the SRD-46 upper bracket (Fe³⁺ + HSO₄⁻ = 2.80, acetate = 3.60, both anionic and thus ≫ any neutral donor) with donor-number interpolation between urea and DMSO:

| Field | Value |
|---|---|
| metal_id | metal_61 |
| ligand_id | ligand_11422 |
| beta_definition | Fe³⁺ + L ⇌ FeL³⁺ (n = 1, neutral monodentate O-donor, HxL form = L, no protonation change) — matches SRD-46 template `beta_def_812` |
| constant_type | K (stepwise, log₁₀) |
| **constant_value** | **≈ 0.8** |
| **uncertainty (1σ)** | **± 0.5** |
| **implied bracket** | 0.3 ≲ logK₁ ≲ 1.8 |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (aqueous reference) |
| electrolyte | unspecified 1:1 background (0.1 M) |
| Higher-order (β₂, β₃…) | set inactive; hydrolysis dominates by pH ≈ 2–3 |
| **SRD-46 upper-bracket anchors** | **vlm_176061 (HSO₄⁻, logK 2.80), vlm_144783 (acetate, logK 3.60), vlm_176248 (thiosulfate, 1.98), vlm_172282 (thiocyanate, 2.37), vlm_173624 (azide, 4.60); all under beta_def_812, metal_61, 25 °C, I = 0.1 M** |
| **SRD-46 hydrolysis-context anchors** | ternary Fe(OH)L records under beta_def_966 (`[ML]/[M(OH)L][H]`) e.g. vlm_99820, vlm_100506, vlm_101099, vlm_101956 — confirming Fe³⁺ hydrolysis is the dominant competing aqueous reaction |
| **SRD-46 records explicitly rejected as wrong reaction frame** | all Fe³⁺ hydroxamate/amide-tethered chelates (e.g. ligand_9873 acetohydroxamic acid logK 11.38 vlm_168447; ligand_6982 vlm_121459; ligand_9910 desferrioxamine B) — anionic (O⁻,O) bidentate, not neutral monodentate O |
| Route | (i) SRD-46 upper bracket: DMF logK₁ must be well below Fe³⁺–HSO₄⁻ and Fe³⁺–acetate (both anionic O-donors give 2.8–3.6). (ii) SRD-46 competing-reaction anchor: Fe³⁺ hydrolysis dominates ternary Fe(III) speciation by pH ≈ 2–3. (iii) Chemistry-based donor-number interpolation between urea (~0.5) and DMSO (~1.4) places DMF at ≈ 0.8 |
| Assumptions | Aqueous reference state; DMF treated as neutral monodentate O-donor (amide carbonyl O); no H⁺ or OH⁻ coupling; ignore DMF-induced medium effects on Fe(III) hydrolysis (must be handled separately in the mixed-solvent Pourbaix module) |
| Confidence | Low-to-moderate — upper bound is firm from SRD-46; central value comes from donor-number interpolation |

### Pourbaix / electrodeposition implication
Because logK₁ is small (~10⁰·⁸ ≈ 6 M⁻¹), free DMF in the electrolyte competes with H₂O only when DMF activity is high (bulk co-solvent regime). Above pH ≈ 2, Fe(OH)ₓ hydrolysis products dominate the aqueous branch of the Pourbaix diagram regardless of DMF binding, so DMF's principal role in the electrodeposition mixture is as a bulk co-solvent (activity-coefficient / dielectric modifier) rather than as an inner-sphere Fe(III) ligand.

**Source:** NIST SRD-46 tables `ligandmetal_card`, `ligandmetal_stability_measured`, `ligand_card`, `ligand_pka_bracket`. Direct Fe³⁺–DMF records absent; upper-bracket anchors listed above are quoted verbatim from SRD-46; the central estimate is chemistry-based and clearly labeled as such.
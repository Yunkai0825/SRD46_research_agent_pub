Committed four Fe(II)–DMF cumulative stability constant estimates at 25 °C, I = 0.1 M:

- log K₁ ≈ 1.0 ± 0.5 (beta_def_812, [ML]/[M][L])
- log β₂ ≈ 1.5 ± 0.6 (beta_def_840, [ML₂]/[M][L]²)
- log β₃ ≈ 1.8 ± 0.7 (beta_def_872, [ML₃]/[M][L]³)
- log β₄ ≈ 2.1 ± 0.8 (beta_def_894, [ML₄]/[M][L]⁴)

Each estimate is anchored to the Cd²⁺–urea ladder in SRD-46 (vlm_169421–169424), with a +~0.15 log unit adjustment for DMF's higher donor number relative to urea. All entry gates and the network gate passed.
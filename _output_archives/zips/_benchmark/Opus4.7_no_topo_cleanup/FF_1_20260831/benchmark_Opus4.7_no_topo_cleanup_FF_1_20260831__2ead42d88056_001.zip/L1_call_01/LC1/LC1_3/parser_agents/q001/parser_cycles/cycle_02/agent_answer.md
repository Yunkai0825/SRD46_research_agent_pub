Committed one target-equilibrium entry for Fe³⁺ + N,N-dimethylformamide (DMF):

- Reaction: Fe³⁺ + L ⇌ [FeL]³⁺ (canonical beta_def_812, [ML]/[M][L], K)
- log₁₀K₁ = 0.8, uncertainty (1σ) = ±0.5
- Conditions: T = 25 °C, I = 0.1 M, aqueous reference
- Estimation method: SRD-46 upper-bracket anchoring (Fe³⁺ with HSO₄⁻ 2.80, acetate 3.60, thiosulfate 1.98, thiocyanate 2.37, azide 4.60 — all anionic O-donors, so a neutral O-donor must sit well below) combined with donor-number interpolation between urea (~0.5) and DMSO (~1.4).
- Evidence (SRD-46 vlm anchors): vlm_176061, vlm_144783, vlm_176248, vlm_172282, vlm_173624
- Key assumptions: aqueous reference state; DMF treated as neutral monodentate carbonyl-O donor; no H⁺/OH⁻ coupling; DMF-induced medium effects on Fe(III) hydrolysis handled separately in the mixed-solvent Pourbaix module.

Draft, entry gate, and network gate all passed; committed cleanly.
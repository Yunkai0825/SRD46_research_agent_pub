Extraction of Fe(II)–DMF aqueous stability constants from the QueryAgent analysis could not be finalized within this cycle. Four analogue-based estimates were prepared as target-equilibrium drafts on the SRD-46 cumulative forms:

- log K₁ (Fe²⁺ + DMF ⇌ [Fe(DMF)]²⁺) ≈ 1.0 ± 0.5, anchored on Cd²⁺–urea (log K = 0.85).
- log β₂ (Fe²⁺ + 2 DMF ⇌ [Fe(DMF)₂]²⁺) ≈ 1.5 ± 0.6, anchored on Cd²⁺–urea (1.36).
- log β₃ (Fe²⁺ + 3 DMF ⇌ [Fe(DMF)₃]²⁺) ≈ 1.8 ± 0.7, anchored on Cd²⁺–urea (1.64).
- log β₄ (Fe²⁺ + 4 DMF ⇌ [Fe(DMF)₄]²⁺) ≈ 2.1 ± 0.8, anchored on Cd²⁺–urea (1.94).

Basis: no direct Fe²⁺–DMF records in SRD-46; transfer route uses Cd²⁺→Fe²⁺ (divalent, borderline, high-spin) and urea→DMF (both neutral C=O amide O-donors, +~0.15 log units for higher DMF donor number). Conditions: aqueous, 25 °C, I = 0.1 M. All four values are judgment-based analogue estimates, not measurements, and should be flagged as such in any downstream equilibrium map. They apply to the low-DMF-mole-fraction limit only; at high x(DMF) the reference state changes and these constants are no longer meaningful.

The drafts were correctly formed with beta_definition_id assignments and single-analogue vlm citations, but topology resolution from the table-row excerpts failed at the entry gate (the row wording resolved to generic placeholder patterns). The intended remediation was to switch to beta_definition_excerpt spans binding each estimate to its literal beta_def_812/840/872/894 token, which was not landed before the iteration limit. No committed entries were produced this cycle.
## Estimated Fe(II)–DMF aqueous stability constants

### 1. Direct SRD-46 records for the target pair
- `metal_62` (Fe^[2+]) with `ligand_11422` (N,N‑dimethylformamide, DMF): **no records** in SRD-46 (`search_stability` on the pair returns empty; `ligand_11422` has 0 metal partners and no pKa data).
- Broader scan for `ligand_11422` alone: no stability, no networks, no pKa. DMF is not tabulated as an aqueous complex-forming ligand in SRD‑46.
- SMILES/fingerprint for `ligand_11422` is not populated, so `search_similar_ligands` cannot run. The closest tabulated neutral carbonyl-amide O-donors in SRD‑46 are urea (`ligand_10003`, `NC(N)=O`) and acetamide (`ligand_9947`), both under the "amide" functional-group bucket.

### 2. Chemistry frame chosen for the estimate
DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp² delocalized, non-basic). It has no accessible pKa in water (protonation of the carbonyl only in strong acid, pKa ≈ −1), so there are no proton-coupled or hydrolyzed complexation channels — the only meaningful aqueous equilibria are outer/inner-sphere replacement of coordinated water on Fe(H₂O)₆²⁺:

`[Fe(H2O)6]^2+  +  n DMF  ⇌  [Fe(H2O)(6−n)(DMF)n]^2+  +  n H2O`

expressed as the SRD-46 cumulative forms `[MLn]/[M][L]^n`. Fe(II) is borderline hard, high-spin d⁶, prefers O-donors, and water itself is already a fairly good O-donor for Fe²⁺; the driving force for DMF ↔ H₂O exchange in dilute aqueous solution is small. This is exactly the same electronic situation as urea on Cd²⁺, which SRD-46 does resolve.

### 3. Analogue evidence used (all SRD-46)
Only urea gives a clean full stepwise ladder at 25 °C, I = 0.1 M in aqueous solution (`ref_eq_map_26936`):

| vlm_id | beta_def | equation | log K | T (°C) | I (M) |
|---|---|---|---|---|---|
| vlm_169421 | beta_def_812 | [M] + [L] ⇌ [ML] | 0.85 | 25 | 0.1 |
| vlm_169422 | beta_def_840 | [M] + 2[L] ⇌ [ML2] | 1.36 | 25 | 0.1 |
| vlm_169423 | beta_def_872 | [M] + 3[L] ⇌ [ML3] | 1.64 | 25 | 0.1 |
| vlm_169424 | beta_def_894 | [M] + 4[L] ⇌ [ML4] | 1.94 | 25 | 0.1 |

Cross‑checks / context in SRD-46:
- Ca²⁺–urea, `vlm_169418`/`vlm_169419` (beta_def_812, 37 °C, I 0–1 M): log K₁ ≈ −0.95 (essentially no complexation for a truly hard s-block cation with a weak neutral O-donor).
- Tl⁺–urea, `vlm_169420` (beta_def_812): log K₁ = −0.3.
- Hg²⁺–urea, `vlm_169425` (beta_def_812, 30 °C): log K₁ = 2.1; Hg²⁺–acetamide `vlm_169107`–`vlm_169109` (beta_def_123/726/949) log K spans −5.79 to 0 — Hg²⁺ is a soft, N-preferring cation and its numbers are not transferable to Fe²⁺.
- H⁺–urea, `vlm_169409`–`vlm_169415` (beta_def_79): log K = −0.29 to −0.1, i.e. neutral amide O is very weakly basic.
- No Fe²⁺ record exists for any neutral O-only amide/urea/DMF ligand in SRD‑46.

The transferable analogue is therefore **Cd²⁺–urea**. Cd²⁺ and Fe²⁺ are both divalent, high-spin, borderline (Fe²⁺ slightly harder), with similar ionic radii (Fe²⁺ HS ~0.78 Å, Cd²⁺ ~0.95 Å in 6-coordinate). For weakly bound neutral O‑donors on divalent 3d/4d metals, log K₁ values are typically bunched within ±0.3–0.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor. DMF is a modestly stronger σ‑donor than urea (Gutmann donor number DN(DMF) = 26.6 vs DN(urea) ≈ 20 in aqueous‑like scales; the carbonyl of an N,N‑dialkyl amide is more polar than that of urea because the two NH₂ groups in urea delocalize the C=O less asymmetrically). Empirically in non-aqueous coordination chemistry, DMF adducts of divalent 3d metals are 0.2–0.5 log units more stable than the corresponding urea adducts. I therefore push each Cd–urea step up by ~+0.2 log units to get the Fe²⁺–DMF estimate, and inflate the uncertainty because:

1. metal transfer Cd²⁺ → Fe²⁺ (±0.3),
2. ligand transfer urea → DMF (±0.3),
3. lack of any Fe²⁺ neutral‑amide anchor in SRD‑46 (±0.2 systematic).

Combined uncertainty ≈ **±0.5 log units** on each step (1σ, judgment).

### 4. Recommended aqueous equilibria and log K estimates (25 °C, I = 0.1 M, water)

| metal_id | ligand_id | beta_def | beta_def_name | equation | HxL form / protonation | constant_type | estimated log K | uncertainty (±) | basis |
|---|---|---|---|---|---|---|---|---|---|
| metal_62 | ligand_11422 | beta_def_812 | [ML]/[M][L] | [Fe]²⁺ + DMF ⇌ [Fe(DMF)]²⁺ | L, neutral DMF | log K₁ | **≈ 1.0** | 0.5 | Cd²⁺–urea `vlm_169421` (0.85) + ~+0.15 for DMF > urea donor strength |
| metal_62 | ligand_11422 | beta_def_840 | [ML2]/[M][L]² | [Fe]²⁺ + 2 DMF ⇌ [Fe(DMF)₂]²⁺ | L, neutral DMF | log β₂ | **≈ 1.5** | 0.6 | Cd²⁺–urea `vlm_169422` (1.36) + ~+0.15 |
| metal_62 | ligand_11422 | beta_def_872 | [ML3]/[M][L]³ | [Fe]²⁺ + 3 DMF ⇌ [Fe(DMF)₃]²⁺ | L, neutral DMF | log β₃ | **≈ 1.8** | 0.7 | Cd²⁺–urea `vlm_169423` (1.64) + ~+0.15 |
| metal_62 | ligand_11422 | beta_def_894 | [ML4]/[M][L]⁴ | [Fe]²⁺ + 4 DMF ⇌ [Fe(DMF)₄]²⁺ | L, neutral DMF | log β₄ | **≈ 2.1** | 0.8 | Cd²⁺–urea `vlm_169424` (1.94) + ~+0.15 |

Solvent: H₂O; electrolyte: I = 0.1 M inert (matches the analogue set: `ref_eq_map_26936`, NaClO₄/KNO₃ style backgrounds); reaction type: homogeneous_aqueous; stoichiometry: no H⁺, no OH⁻, no bridging; charge on all Fe–DMF species is 2+.

The stepwise increments K_n/K_{n−1} are gently decreasing (statistical for successive H₂O↔DMF exchange on an octahedral Fe(H₂O)₆²⁺ core), consistent with the Cd²⁺–urea pattern. No log β for n = 5, 6 is proposed: in dilute aqueous DMF (Pourbaix use case) the mole fraction of DMF is small and the higher adducts are not populated; also the incremental K_n almost certainly turn over to essentially 0 as sterics on Fe(II) build.

### 5. Important assumptions and caveats for the Pourbaix / electrodeposition use
- These constants describe the **aqueous** medium at I = 0.1 M. In a genuine water–DMF **mixed solvent** the reference state for “free DMF” changes and the operative K values shift: as x(DMF) rises, activity coefficient corrections and preferential solvation make the reported log Ks effectively **decrease** in magnitude (DMF is no longer being pulled out of a dilute pool but is the bulk medium). For Pourbaix construction in a water-DMF electrolyte, treat these values as the low-x(DMF) limit; at x(DMF) ≳ 0.3 the Fe(II) speciation becomes dominated by fully DMF-solvated [Fe(DMF)₆]²⁺ (well known from non-aqueous coordination chemistry), for which no aqueous log K is meaningful.
- DMF has essentially no pH-dependent speciation in the electrochemical window of Fe electrodeposition; DMF-related terms **do not shift the Fe²⁺/Fe⁰ or Fe(OH)₂/Fe²⁺ boundaries appreciably at low mole fraction**. The dominant Pourbaix drivers remain Fe²⁺ hydrolysis (FeOH⁺, Fe(OH)₂(s), Fe(OH)₃⁻) and, at higher E, Fe(III) hydrolysis. The estimated Fe(II)–DMF constants only slightly stabilize Fe²⁺ toward hydrolysis (shift the Fe²⁺/Fe(OH)₂(s) boundary by a few hundredths of a pH unit at [DMF] = 0.1–1 M).
- Slow DMF hydrolysis to dimethylamine + formate under Fe electrocatalysis is a separate kinetic issue; it is not represented by any equilibrium constant here.
- All four estimated log K values are **judgment-based analogue estimates**, not measurements; they should be flagged as such in the downstream equilibrium map.

### 6. Provenance summary (all IDs in fully prefixed underscore form)
- Target: `metal_62`, `ligand_11422`; no direct SRD-46 records.
- Primary analogue (transfer basis): Cd²⁺–urea ladder in `ref_eq_map_26936` — `vlm_169421`, `vlm_169422`, `vlm_169423`, `vlm_169424` on `beta_def_812`, `beta_def_840`, `beta_def_872`, `beta_def_894`.
- Supporting context: `vlm_169418`, `vlm_169419` (Ca²⁺–urea), `vlm_169420` (Tl⁺–urea), `vlm_169425` (Hg²⁺–urea), `vlm_169107`, `vlm_169108`, `vlm_169109` (Hg²⁺–acetamide, `beta_def_123`, `beta_def_726`, `beta_def_949`), and `vlm_169409`–`vlm_169415` (H⁺–urea, `beta_def_79`) establishing the donor-strength scale for neutral carbonyl-amide O-donors.
- Route: Cd²⁺→Fe²⁺ metal transfer within divalent borderline cations + urea→DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).
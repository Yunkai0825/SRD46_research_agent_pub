SRD-46 has no direct or reaction-frame-matched analogue for aqueous Fe(3+) + neutral DMF association. Below is the evidence and the resulting chemistry-based estimate.

## SRD-46 evidence search

| Query | Result |
|---|---|
| `search_stability` on ligand_11422 (any metal) | 0 rows — DMF has no stability data in SRD-46 |
| `inspect_card` ligand_11422 | Class = "Ligands not selected"; 0 metal partners; no pKa; no fingerprint |
| `search_similar_ligands` on ligand_11422 | Error — no fingerprint data available |
| Fe3+ (metal_61) amide/urea-motif ligand scan | 50 hits, **all hydroxamic acids or amide-tethered polydentate chelates** (e.g., ligand_9873 acetohydroxamic acid, ligand_6982 glycinehydroxamic acid, ligand_9910 desferrioxamine B); every one deprotonates its N–OH to give an anionic (O⁻,O) chelate — a fundamentally different reaction frame from neutral monodentate DMF |
| Fe3+ with DMSO / formamide / acetamide / urea / NMP / THF | 0 rows |

**Conclusion of the SRD-46 search:** no measured logK, no reaction-frame-matched analogue, and no fingerprint-based similarity route is available. The estimate below is therefore made from chemistry reasoning, clearly labeled as such.

## Chemistry reasoning for the estimate

Species definition: **Fe³⁺ + DMF ⇌ [Fe(DMF)]³⁺**, neutral monodentate O-donor (amide carbonyl O), no proton coupling, no hydroxo bridging, 25 °C, I = 0.1 M (aqueous reference state).

Key structural/thermodynamic considerations for DMF:
- Neutral, monodentate, O-donor through the carbonyl oxygen (amide N is delocalized into C=O and is a very poor donor).
- Strongly basic amide O relative to water: DMF pKBH+ ≈ −0.3 to −1 (i.e., DMF is a moderately strong H-bond acceptor and Gutmann donor number DN ≈ 26.6, vs H₂O DN ≈ 18 and DMSO DN ≈ 29.8).
- No net charge change on complexation ⇒ small electrostatic driving force; binding is essentially donor-strength driven.
- In water, DMF must displace one aquo ligand of hard, hexaaquo Fe(H₂O)₆³⁺; the substitution is nearly isodesmic (O for O) with a modest donor-strength gain.

Fe³⁺ is a hard Lewis acid that binds anionic O-donors very strongly (e.g., Fe³⁺ + F⁻ logK₁ ≈ 6; Fe³⁺ + SO₄²⁻ logK₁ ≈ 4; Fe³⁺ + acetate logK₁ ≈ 3.4 at I = 0.1 M). Neutral O-donors bind much more weakly because they lack the ionic contribution — for the classical "monodentate neutral O donor" reference points in the aqueous coordination-chemistry literature (Hancock, Martell; not in SRD-46 for this system):

| Neutral O-donor | Fe³⁺ logK₁ (aq, 25 °C, I≈0.1) | Comment |
|---|---|---|
| H₂O | 0 (reference) | self-exchange |
| Urea | ≈ 0.4–0.8 | weak, similar donor strength to DMF |
| DMSO | ≈ 1.2–1.6 | DN 29.8, upper bracket |
| Acetone | ≈ 0.3–0.6 | weak |

DMF sits **between urea and DMSO** in donor strength (DN 26.6). By donor-number interpolation and by analogy with the well-studied M³⁺ / neutral-amide association behavior:

- **Estimated logK₁ ≈ 0.8 ± 0.5** for Fe³⁺ + DMF ⇌ [Fe(DMF)]³⁺, 25 °C, I = 0.1 M (aq).
- Higher-order stepwise constants (logK₂, logK₃…) are expected to decrease by ~0.3–0.5 per step (statistical + steric), and the cumulative β_n values quickly become negligible relative to Fe(III) hydrolysis (pKa₁ of Fe(H₂O)₆³⁺ ≈ 2.2), so beyond n = 1 the species are not populated in aqueous-rich medium.

**Speciation relevance for Pourbaix / electrodeposition:** in a water-DMF mixed solvent, at any pH where free Fe³⁺ is not overwhelmed by hydrolysis (roughly pH < 2), the small logK₁ means DMF will only compete with water at very high DMF mole fraction. Above pH ≈ 2–3, Fe(OH)ₓ hydrolysis products dominate the Pourbaix diagram regardless of DMF; DMF acts mainly as a bulk co-solvent modifying activity coefficients and Fe(III) hydrolysis equilibria, not as a Fe(III)-chelating ligand in the coordination sense.

## Dummy stability record (self-contained)

| Field | Value |
|---|---|
| metal_id | metal_61 |
| ligand_id | ligand_11422 |
| beta_definition | Fe³⁺ + L ⇌ FeL³⁺ (n = 1, neutral monodentate, HxL form = L, no protonation change) |
| constant_type | K (stepwise, log₁₀) |
| constant_value | **0.8** |
| uncertainty (1σ) | ± 0.5 |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (aqueous reference) |
| electrolyte | unspecified 1:1 background (0.1 M) |
| SRD-46 vlm_id support | *none — no measurements exist for this system* |
| Reference-state analogues consulted (SRD-46) | metal_61 amide-motif scan returned only hydroxamates (e.g., ligand_9873, ligand_9910, ligand_6982) — rejected as wrong reaction frame (anionic (O⁻,O) chelation, not neutral monodentate O) |
| Route | Chemical estimate from Gutmann donor-number interpolation between water (DN 18), urea, DMF (DN 26.6), and DMSO (DN 29.8); calibrated to typical Fe³⁺ + neutral-O-donor logK₁ (literature/textbook, not SRD-46) |
| Higher-order species | β₂, β₃… not recommended for the Pourbaix map — set inactive or ≪ hydrolysis products (Fe(OH)²⁺ logK ≈ −2.2 already dominates by pH 2–3) |
| Assumptions | Aqueous reference state; DMF treated as neutral monodentate O-donor; ignore DMF-induced medium effects on Fe(III) hydrolysis (these must be handled separately in the mixed-solvent Pourbaix module) |
| Confidence | Low — pure chemistry judgment, no SRD-46 numerical support |

**Source:** NIST SRD-46 (queried tables: ligandmetal_card, ligandmetal_stability_measured, ligand_card). No matching records; estimate is chemistry-based and clearly labeled as such.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+ is a distinct protonation state needed at 0.1 M Fe. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Neutral Fe(II) dihydroxo species; distinct protonation state in the Pourbaix map. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) [Fe(OH)4]2- high-pH species; distinct charge/protonation state. |
| `DEDUP-cd0dc84afdfe594c` | `[Fe(DMF)]2+` | SRD46 query estimated values | generation 1: kept — Fe(II)-DMF n=1 complex; central deliverable, keep despite estimated provenance. |
| `DEDUP-6dbcc079680b4f6a` | `[Fe(DMF)2]2+` | SRD46 query estimated values | generation 1: kept — Fe(II)-DMF n=2 complex; distinct stepwise coordination. |
| `DEDUP-8bc2eebf95f6810c` | `[Fe(DMF)3]2+` | SRD46 query estimated values | generation 1: kept — Fe(II)-DMF n=3 complex; distinct stepwise coordination. |
| `DEDUP-ae52be8eb139348c` | `[Fe(DMF)4]2+` | SRD46 query estimated values | generation 1: kept — Fe(II)-DMF n=4 complex; distinct stepwise coordination. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) [Fe(OH)4]- high-pH species; distinct from lower protonation states. |
| `DEDUP-da67ba77865fffb3` | `[Fe(DMF)]3+` | SRD46 query estimated values | generation 1: kept — Fe(III)-DMF n=1 complex; only Fe(III)-DMF entry available, keep. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) [Fe3(OH)4]5+ physically real at 0.1 M loading. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate [FeO4]2- retained as legitimate high-E boundary marker. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Metallic Fe(0) is essential low-E phase for electrodeposition study. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; must remain. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference entry required for aqueous framework. |
| — | `[DMF]` | SRD-46 | generation 1: kept — Free DMF ligand reference required for L1 activity axis. |

Final deduplicated Fe inventory committed for the aqueous-DMF Fe electrodeposition Pourbaix study.

Kept (21 entries):
- Aqueous Fe(II): [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2- (SRD-46)
- Aqueous Fe(III): [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]- (SRD-46)
- Polynuclear Fe(III): [Fe2(OH)2]4+, [Fe3(OH)4]5+ (SRD-46) — retained at 0.1 M loading
- Fe(II)-DMF stepwise complexes: [Fe(DMF)]2+, [Fe(DMF)2]2+, [Fe(DMF)3]2+, [Fe(DMF)4]2+ (estimated)
- Fe(III)-DMF: [Fe(DMF)]3+ (estimated; n=2-6 absent from inventory, flagged)
- Ferrate: [FeO4]2- (Atlas) — high-E boundary marker
- Solids: Fe(0), Fe3O4 magnetite, hematite Fe2O3, goethite FeO(OH), Fe(OH)2(s), Fe(OH)3(s) (SRD-46 preferred)
- References: water, free DMF

Dropped (8 entries, all Atlas cross-source duplicates collapsed to SRD-46 per the internal-consistency rule): Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+ (Fe(III)), [HFeO2]-, Fe2O3(anh), Fe(OH)2(hydr), Fe(OH)3(hydr).

Notable flag carried forward: only n=1 Fe(III)-DMF is available; higher [Fe(DMF)n]3+ (n=2-6) are missing from the inventory and cannot be invented here.
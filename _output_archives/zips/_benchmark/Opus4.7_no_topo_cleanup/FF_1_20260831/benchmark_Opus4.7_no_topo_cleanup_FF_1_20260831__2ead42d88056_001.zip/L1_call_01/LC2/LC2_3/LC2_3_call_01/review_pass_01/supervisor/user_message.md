[Orchestration session]
362fbc2d0f8841af9c786c22ecee0ff8

[Calculation purpose]
Evaluate Fe speciation and Pourbaix behavior in a water-DMF mixed solvent electrolyte to inform Fe electrodeposition design.

[Requested tasks]
Model a single aqueous electrolyte containing 0.1 M Fe(II/III) with 1 M N,N-dimethylformamide (DMF) as a co-solvent/ligand. Compute the Pourbaix (E-pH) diagram over pH 0-14 and a reasonable potential window covering Fe(0)/Fe(II)/Fe(III) at 25 C and 0.1 M ionic strength. Report the dominant Fe species in each region, the Fe(II) stability window, hydroxide/oxide precipitation boundaries, and where DMF coordination shifts speciation. If DMF-Fe stability constants are missing in SRD-46, estimate them with justification from analogous amide/carbonyl donors in SRD-46 and clearly flag the estimates. Also produce a pH speciation slice showing Fe(II) fractions across pH.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: Fe electrodeposition study in aqueous-DMF mixed electrolyte, [Fe]_total = 0.1 M with 1 M DMF; treat as an aqueous Pourbaix problem with DMF as an explicit ligand family L1. Both stability (regions) and formation (which species appear) matter — keep competing distinct species rather than aggressively collapsing.
- Concentration 0.1 M (not 1e-6): polynuclear Fe(III) hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real at this loading and must be retained. All mononuclear Fe(III) hydroxo protonation states ([FeOH]2+, [Fe(OH)2]+, [Fe(OH)3](aq if present), [Fe(OH)4]-) and Fe(II) hydroxo species are real and distinct — do not merge across protonation.
- DMF-Fe complexes are the central deliverable and are already flagged as estimated. Keep every [Fe(DMF)n]2+ (n=1-4) and [Fe(DMF)]3+ entry as-is; they compete stepwise for the same Fe center and each defines a distinct region of the L1-activity axis. Do not drop despite estimated provenance.
- Cross-source duplicates of the exact same species (same composition, same charge, same physical state) from Atlas vs SRD-46 are true duplicates: keep the SRD-46 value as the internally consistent reference set unless the Atlas mu is markedly different (>~5 kJ), in which case flag and keep SRD-46.
- Solids: Fe(0), magnetite Fe3O4, hematite Fe2O3 (anhydrous), FeOOH, Fe(OH)2, and Fe(OH)3 hydrated forms are chemically distinct competing phases and must all remain. Where the same solid stoichiometry appears twice (Atlas vs SRD-46 of Fe2O3, Fe(OH)2, Fe(OH)3), collapse to one entry preferring SRD-46; hematite Fe2O3 and goethite FeO(OH) are distinct phases and both stay.
- FeO4(2-) ferrate is far above the water oxidation limit and out of the Fe(0/II/III) window requested but is a legitimate high-E boundary marker — keep. No carbonate/other counterion solids are in scope.
- Note ambiguity: DMF complexes with Fe(III) are represented only at n=1; higher [Fe(DMF)n]3+ (n=2-6) are absent from the inventory. Flag but do not resolve — cannot invent entries.

[Committed element instructions]
- Fe: Collapse exact cross-source duplicates (same composition and charge) by keeping the SRD-46 entry and dropping the Atlas counterpart: for Fe2+, Fe3+, [Fe(OH)]2+/[FeOH]2+, [Fe(OH)2]+ (Fe(III)), the Fe(II) [HFeO2]-/[Fe(OH)3]- pair, and the solid pairs Fe2O3(anh), Fe(OH)2(hydr), Fe(OH)3(hydr) — preferring SRD-46 in each case. Keep all polynuclear Fe(III) hydroxo species, every [Fe(DMF)n]2+/3+ estimate, distinct oxide/oxyhydroxide polymorphs (Fe3O4, hematite Fe2O3, FeO(OH) goethite, Fe(OH)2, Fe(OH)3), Fe(0), and ferrate [FeO4]2- because they occupy chemically distinct regions of the E-pH-ligand phase space at 0.1 M Fe with 1 M DMF.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. | Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+ is a distinct protonation state needed at 0.1 M Fe. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +202.623 | generation 1: kept — Neutral Fe(II) dihydroxo species; distinct protonation state in the Pourbaix map. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. | Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(II) [Fe(OH)4]2- high-pH species; distinct charge/protonation state. |  |
| `DEDUP-cd0dc84afdfe594c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DMF)]2+` | SRD46 query estimated values | -5.708 | generation 1: kept — Fe(II)-DMF n=1 complex; central deliverable, keep despite estimated provenance. |  |
| `DEDUP-6dbcc079680b4f6a` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(DMF)2]2+` | SRD46 query estimated values | -8.562 | generation 1: kept — Fe(II)-DMF n=2 complex; distinct stepwise coordination. |  |
| `DEDUP-8bc2eebf95f6810c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:3` | `[Fe(DMF)3]2+` | SRD46 query estimated values | -10.274 | generation 1: kept — Fe(II)-DMF n=3 complex; distinct stepwise coordination. |  |
| `DEDUP-ae52be8eb139348c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:4` | `[Fe(DMF)4]2+` | SRD46 query estimated values | -11.986 | generation 1: kept — Fe(II)-DMF n=4 complex; distinct stepwise coordination. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. | Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. | Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. | Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) [Fe(OH)4]- high-pH species; distinct from lower protonation states. |  |
| `DEDUP-da67ba77865fffb3` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DMF)]3+` | SRD46 query estimated values | +69.784 | generation 1: kept — Fe(III)-DMF n=1 complex; only Fe(III)-DMF entry available, keep. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) [Fe3(OH)4]5+ physically real at 0.1 M loading. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate [FeO4]2- retained as legitimate high-E boundary marker. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; must remain. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Metallic Fe(0) is essential low-E phase for electrodeposition study. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. | Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Solvent/water reference entry required for aqueous framework. | Solvent/water reference entry required for aqueous framework. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. | Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. | Exact cross-source duplicate of Fe2+ aqueous cation; keep SRD-46 as internally consistent reference per element instructions. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+ is a distinct protonation state needed at 0.1 M Fe. | Fe(II) monohydroxo [Fe(OH)]+ is a distinct protonation state needed at 0.1 M Fe. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Neutral Fe(II) dihydroxo species; distinct protonation state in the Pourbaix map. | Neutral Fe(II) dihydroxo species; distinct protonation state in the Pourbaix map. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. | Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. | Same Fe(II) hydroxo monoanion in different notation; keep SRD-46 per element instruction. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(II) [Fe(OH)4]2- high-pH species; distinct charge/protonation state. | Fe(II) [Fe(OH)4]2- high-pH species; distinct charge/protonation state. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(DMF)]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(II)-DMF n=1 complex; central deliverable, keep despite estimated provenance. | Fe(II)-DMF n=1 complex; central deliverable, keep despite estimated provenance. |
| aqueous | `Fe$+2:1 L1:2` | Fe | aqueous | `[Fe(DMF)2]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(II)-DMF n=2 complex; distinct stepwise coordination. | Fe(II)-DMF n=2 complex; distinct stepwise coordination. |
| aqueous | `Fe$+2:1 L1:3` | Fe | aqueous | `[Fe(DMF)3]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(II)-DMF n=3 complex; distinct stepwise coordination. | Fe(II)-DMF n=3 complex; distinct stepwise coordination. |
| aqueous | `Fe$+2:1 L1:4` | Fe | aqueous | `[Fe(DMF)4]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(II)-DMF n=4 complex; distinct stepwise coordination. | Fe(II)-DMF n=4 complex; distinct stepwise coordination. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. | Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. | Exact cross-source duplicate of Fe3+; kept SRD-46 per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. | Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. | Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. | Collapsed Atlas [FeOH]2+ duplicate into SRD-46 [Fe(OH)]2+; retained distinct polynuclear [Fe2(OH)2]4+ per case guidance at 0.1 M Fe. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. | Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. | Exact cross-source duplicate of Fe(III) [Fe(OH)2]+; keep SRD-46 as internally consistent reference and drop Atlas per element instructions. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) [Fe(OH)4]- high-pH species; distinct from lower protonation states. | Fe(III) [Fe(OH)4]- high-pH species; distinct from lower protonation states. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(DMF)]3+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(III)-DMF n=1 complex; only Fe(III)-DMF entry available, keep. | Fe(III)-DMF n=1 complex; only Fe(III)-DMF entry available, keep. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) [Fe3(OH)4]5+ physically real at 0.1 M loading. | Polynuclear Fe(III) [Fe3(OH)4]5+ physically real at 0.1 M loading. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate [FeO4]2- retained as legitimate high-E boundary marker. | Ferrate [FeO4]2- retained as legitimate high-E boundary marker. |
| aqueous | `L1:1` | — | — | `[DMF]` | SRD-46 | kept | true | generation 1: kept — Free DMF ligand reference required for L1 activity axis. | Free DMF ligand reference required for L1 activity axis. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Metallic Fe(0) is essential low-E phase for electrodeposition study. | Metallic Fe(0) is essential low-E phase for electrodeposition study. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4 is a distinct mixed-valence phase; must remain. | Magnetite Fe3O4 is a distinct mixed-valence phase; must remain. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. | Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. | Cross-source duplicate hydrated Fe(OH)2 solid; SRD-46 preferred per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. | Kept SRD-46 hematite, goethite, and Fe(OH)3 as distinct polymorphs; dropped Atlas duplicates of Fe2O3(anh) and Fe(OH)3(hydr) per SRD-46 preference. |

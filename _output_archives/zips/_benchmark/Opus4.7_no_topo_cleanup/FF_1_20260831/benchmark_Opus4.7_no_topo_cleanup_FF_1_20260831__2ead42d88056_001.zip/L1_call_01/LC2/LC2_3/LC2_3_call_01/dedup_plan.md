# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: Fe electrodeposition study in aqueous-DMF mixed electrolyte, [Fe]_total = 0.1 M with 1 M DMF; treat as an aqueous Pourbaix problem with DMF as an explicit ligand family L1. Both stability (regions) and formation (which species appear) matter — keep competing distinct species rather than aggressively collapsing.
- Concentration 0.1 M (not 1e-6): polynuclear Fe(III) hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real at this loading and must be retained. All mononuclear Fe(III) hydroxo protonation states ([FeOH]2+, [Fe(OH)2]+, [Fe(OH)3](aq if present), [Fe(OH)4]-) and Fe(II) hydroxo species are real and distinct — do not merge across protonation.
- DMF-Fe complexes are the central deliverable and are already flagged as estimated. Keep every [Fe(DMF)n]2+ (n=1-4) and [Fe(DMF)]3+ entry as-is; they compete stepwise for the same Fe center and each defines a distinct region of the L1-activity axis. Do not drop despite estimated provenance.
- Cross-source duplicates of the exact same species (same composition, same charge, same physical state) from Atlas vs SRD-46 are true duplicates: keep the SRD-46 value as the internally consistent reference set unless the Atlas mu is markedly different (>~5 kJ), in which case flag and keep SRD-46.
- Solids: Fe(0), magnetite Fe3O4, hematite Fe2O3 (anhydrous), FeOOH, Fe(OH)2, and Fe(OH)3 hydrated forms are chemically distinct competing phases and must all remain. Where the same solid stoichiometry appears twice (Atlas vs SRD-46 of Fe2O3, Fe(OH)2, Fe(OH)3), collapse to one entry preferring SRD-46; hematite Fe2O3 and goethite FeO(OH) are distinct phases and both stay.
- FeO4(2-) ferrate is far above the water oxidation limit and out of the Fe(0/II/III) window requested but is a legitimate high-E boundary marker — keep. No carbonate/other counterion solids are in scope.
- Note ambiguity: DMF complexes with Fe(III) are represented only at n=1; higher [Fe(DMF)n]3+ (n=2-6) are absent from the inventory. Flag but do not resolve — cannot invent entries.

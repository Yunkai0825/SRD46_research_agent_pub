[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse exact cross-source duplicates (same composition and charge) by keeping the SRD-46 entry and dropping the Atlas counterpart: for Fe2+, Fe3+, [Fe(OH)]2+/[FeOH]2+, [Fe(OH)2]+ (Fe(III)), the Fe(II) [HFeO2]-/[Fe(OH)3]- pair, and the solid pairs Fe2O3(anh), Fe(OH)2(hydr), Fe(OH)3(hydr) — preferring SRD-46 in each case. Keep all polynuclear Fe(III) hydroxo species, every [Fe(DMF)n]2+/3+ estimate, distinct oxide/oxyhydroxide polymorphs (Fe3O4, hematite Fe2O3, FeO(OH) goethite, Fe(OH)2, Fe(OH)3), Fe(0), and ferrate [FeO4]2- because they occupy chemically distinct regions of the E-pH-ligand phase space at 0.1 M Fe with 1 M DMF.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 |
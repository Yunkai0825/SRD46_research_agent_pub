# Free Energy Analysis Card

**System**: H, Fe / DMF, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+
**Ligands**: [DMF]
**Generated**: 2026-08-31 21:49:02 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DMF] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DMF] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_11422 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [DMF] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DMF] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Fe]3+ + [DMF] | 25.0 | 0.1 | *** | 1 |
| [Fe]2+ + [DMF] | 25.0 | 0.1 | *** | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [DMF] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [DMF] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [DMF]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L1].[z+3] | [Fe(DMF)]3+ | +3 | aqueous | +0.8000 | -4.5662 | -4.5662 | -4.5662 | [M1]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["Aqueous reference state","DMF treated as neutral monodentate O-donor (amide carbonyl O)","no H\u207a or OH\u207b coupling","ignore DMF-induced medium effects on Fe(III) hydrolysis (must be handled separately in the mixed-solvent Pourbaix module)"],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"(i) SRD-46 upper bracket: DMF logK\u2081 must be well below Fe\u00b3\u207a\u2013HSO\u2084\u207b and Fe\u00b3\u207a\u2013acetate (both anionic O-donors give 2.8\u20133.6). (ii) SRD-46 competing-reaction anchor: Fe\u00b3\u207a hydrolysis dominates ternary Fe(III) speciation by pH \u2248 2\u20133. (iii) Chemistry-based donor-number interpolation between urea (~0.5) and DMSO (~1.4) places DMF at \u2248 0.8","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"b33bdb1ed3c86a5c732067d4bbace1257348d4be31ce109194fbe1cd16aadca1","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_176061","vlm_144783","vlm_176248","vlm_172282","vlm_173624"],"query_answer_sha256":"5c2d1b4a56a0679374bdb057ec2f175fe43f95096e0540789467ccc83f99bfa5","query_id":"q001","rationale":"Combining the SRD-46 upper bracket (Fe\u00b3\u207a + HSO\u2084\u207b = 2.80, acetate = 3.60, both anionic and thus \u226b any neutral donor) with donor-number interpolation between urea and DMSO","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [M1]:+1, [OH]:+2 | vlm_170807 | true | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [DMF]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L1]4.[z+2] | [Fe(DMF)4]2+ | +2 | aqueous | +2.1000 | -11.9862 | -11.9862 | -11.9862 | [M2]:+1, [L1]:+4 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":894,"beta_definition_name":"[ML<sub>4</sub>]/[M][L]<sup>4</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169424"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000005,"session_vlm_id":-5000005,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000005","uncertainty_log10":0.8}],"source":"SRD46 query estimated values"} |
| [M2].[L1]3.[z+2] | [Fe(DMF)3]2+ | +2 | aqueous | +1.8000 | -10.2738 | -10.2738 | -10.2738 | [M2]:+1, [L1]:+3 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169423"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |
| [M2].[L1]2.[z+2] | [Fe(DMF)2]2+ | +2 | aqueous | +1.5000 | -8.5615 | -8.5615 | -8.5615 | [M2]:+1, [L1]:+2 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169422"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":0.6}],"source":"SRD46 query estimated values"} |
| [M2].[L1].[z+2] | [Fe(DMF)]2+ | +2 | aqueous | +1.0000 | -5.7077 | -5.7077 | -5.7077 | [M2]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [M2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M1]:+1, [H]:-3 | vlm_170828 | true | *** |
| [M1].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M1]:+1, [H]:-3 | vlm_170827 | true | *** |
| [M1].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | true | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 19 |
| Included in calculation | 19 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 14 |
| Unresolved (no species in card) | 5 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 2 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 3 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 4 | vlm_170807 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 5 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 6 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 7 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 8 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 9 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O] <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |
| 10 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 11 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 12 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 13 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 14 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 15 | session_eq_node_-4000001 | [<DMF>] + [<Fe3+>] <=> [<Fe3+><DMF>] | +0.8000 | 25.0 | 0.100 | yes | — |
| 16 | session_eq_node_-4000002 | [<DMF>] + [<Fe2+>] <=> [<Fe2+><DMF>] | +1.0000 | 25.0 | 0.100 | yes | — |
| 17 | session_eq_node_-4000003 | [<DMF>]^2 + [<Fe2+>] <=> [<Fe2+><DMF>2] | +1.5000 | 25.0 | 0.100 | yes | — |
| 18 | session_eq_node_-4000004 | [<DMF>]^3 + [<Fe2+>] <=> [<Fe2+><DMF>3] | +1.8000 | 25.0 | 0.100 | yes | — |
| 19 | session_eq_node_-4000005 | [<DMF>]^4 + [<Fe2+>] <=> [<Fe2+><DMF>4] | +2.1000 | 25.0 | 0.100 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

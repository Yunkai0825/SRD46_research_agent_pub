## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: Fe electrodeposition study in aqueous-DMF mixed electrolyte, [Fe]_total = 0.1 M with 1 M DMF; treat as an aqueous Pourbaix problem with DMF as an explicit ligand family L1. Both stability (regions) and formation (which species appear) matter — keep competing distinct species rather than aggressively collapsing.
- Concentration 0.1 M (not 1e-6): polynuclear Fe(III) hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically real at this loading and must be retained. All mononuclear Fe(III) hydroxo protonation states ([FeOH]2+, [Fe(OH)2]+, [Fe(OH)3](aq if present), [Fe(OH)4]-) and Fe(II) hydroxo species are real and distinct — do not merge across protonation.
- DMF-Fe complexes are the central deliverable and are already flagged as estimated. Keep every [Fe(DMF)n]2+ (n=1-4) and [Fe(DMF)]3+ entry as-is; they compete stepwise for the same Fe center and each defines a distinct region of the L1-activity axis. Do not drop despite estimated provenance.
- Cross-source duplicates of the exact same species (same composition, same charge, same physical state) from Atlas vs SRD-46 are true duplicates: keep the SRD-46 value as the internally consistent reference set unless the Atlas mu is markedly different (>~5 kJ), in which case flag and keep SRD-46.
- Solids: Fe(0), magnetite Fe3O4, hematite Fe2O3 (anhydrous), FeOOH, Fe(OH)2, and Fe(OH)3 hydrated forms are chemically distinct competing phases and must all remain. Where the same solid stoichiometry appears twice (Atlas vs SRD-46 of Fe2O3, Fe(OH)2, Fe(OH)3), collapse to one entry preferring SRD-46; hematite Fe2O3 and goethite FeO(OH) are distinct phases and both stay.
- FeO4(2-) ferrate is far above the water oxidation limit and out of the Fe(0/II/III) window requested but is a legitimate high-E boundary marker — keep. No carbonate/other counterion solids are in scope.
- Note ambiguity: DMF complexes with Fe(III) are represented only at n=1; higher [Fe(DMF)n]3+ (n=2-6) are absent from the inventory. Flag but do not resolve — cannot invent entries.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse exact cross-source duplicates (same composition and charge) by keeping the SRD-46 entry and dropping the Atlas counterpart: for Fe2+, Fe3+, [Fe(OH)]2+/[FeOH]2+, [Fe(OH)2]+ (Fe(III)), the Fe(II) [HFeO2]-/[Fe(OH)3]- pair, and the solid pairs Fe2O3(anh), Fe(OH)2(hydr), Fe(OH)3(hydr) — preferring SRD-46 in each case. Keep all polynuclear Fe(III) hydroxo species, every [Fe(DMF)n]2+/3+ estimate, distinct oxide/oxyhydroxide polymorphs (Fe3O4, hematite Fe2O3, FeO(OH) goethite, Fe(OH)2, Fe(OH)3), Fe(0), and ferrate [FeO4]2- because they occupy chemically distinct regions of the E-pH-ligand phase space at 0.1 M Fe with 1 M DMF.

[Singletons: n=15]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 202.623 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DMF)]2+` | SRD46 query estimated values | +2 | -5.708 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(DMF)2]2+` | SRD46 query estimated values | +2 | -8.562 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:3` | `[Fe(DMF)3]2+` | SRD46 query estimated values | +2 | -10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:4` | `[Fe(DMF)4]2+` | SRD46 query estimated values | +2 | -11.986 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DMF)]3+` | SRD46 query estimated values | +3 | 69.784 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[DMF]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>All 15 singletons are chemically distinct and in scope per case-specific recommendations: solvent/ligand references, Fe(II)/Fe(III) hydroxo protonation states, polynuclear Fe(III), all DMF complexes, ferrate boundary, Fe(0), and magnetite. Keeping all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Recorded all 15 keep verdicts.</summary>

<answer>
All 15 singletons kept. Each occupies a distinct region of the Fe E–pH–L1(DMF) phase space at 0.1 M Fe / 1 M DMF: solvent/ligand reference (water, DMF); Fe(II) hydroxo protonation states [Fe(OH)]+, [Fe(OH)2], [Fe(OH)4]2−; Fe(III) hydroxo [Fe(OH)4]−; polynuclear Fe(III) [Fe3(OH)4]5+; the full stepwise Fe(II)-DMF ladder [Fe(DMF)n]2+ (n=1–4) plus [Fe(DMF)]3+; high-E ferrate [FeO4]2−; and solids Fe(0) and magnetite Fe3O4. No cross-source duplicates present in this singleton set to collapse.
</answer>
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse exact cross-source duplicates (same composition and charge) by keeping the SRD-46 entry and dropping the Atlas counterpart: for Fe2+, Fe3+, [Fe(OH)]2+/[FeOH]2+, [Fe(OH)2]+ (Fe(III)), the Fe(II) [HFeO2]-/[Fe(OH)3]- pair, and the solid pairs Fe2O3(anh), Fe(OH)2(hydr), Fe(OH)3(hydr) — preferring SRD-46 in each case. Keep all polynuclear Fe(III) hydroxo species, every [Fe(DMF)n]2+/3+ estimate, distinct oxide/oxyhydroxide polymorphs (Fe3O4, hematite Fe2O3, FeO(OH) goethite, Fe(OH)2, Fe(OH)3), Fe(0), and ferrate [FeO4]2- because they occupy chemically distinct regions of the E-pH-ligand phase space at 0.1 M Fe with 1 M DMF.

[Singletons: n=15]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 202.623 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DMF)]2+` | SRD46 query estimated values | +2 | -5.708 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(DMF)2]2+` | SRD46 query estimated values | +2 | -8.562 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:3` | `[Fe(DMF)3]2+` | SRD46 query estimated values | +2 | -10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:4` | `[Fe(DMF)4]2+` | SRD46 query estimated values | +2 | -11.986 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DMF)]3+` | SRD46 query estimated values | +3 | 69.784 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[DMF]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
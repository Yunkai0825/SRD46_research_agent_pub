# Free Energy Analysis Card

**System**: metal_62 + ligand_11422
**Metals**: [Fe]2+
**Ligands**: [DMF]
**Generated**: 2026-08-31 21:49:02 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+2 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DMF] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DMF] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_11422 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+2 | [Fe]2+ | +2 | true | 1 |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [DMF] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DMF] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]2+ + [DMF] | 25.0 | 0.1 | *** | 4 |
| [Fe]2+ + [OH]- | 25.0 | 0~0.1 | 27433 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [DMF] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [DMF] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [DMF]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[L1]4.[z+2] | [Fe(DMF)4]2+ | +2 | aqueous | +2.1000 | -11.9862 | -11.9862 | -11.9862 | [Fe$+2]:+1, [L1]:+4 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":894,"beta_definition_name":"[ML<sub>4</sub>]/[M][L]<sup>4</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169424"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000005,"session_vlm_id":-5000005,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000005","uncertainty_log10":0.8}],"source":"SRD46 query estimated values"} |
| [Fe$+2].[L1]3.[z+2] | [Fe(DMF)3]2+ | +2 | aqueous | +1.8000 | -10.2738 | -10.2738 | -10.2738 | [Fe$+2]:+1, [L1]:+3 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169423"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |
| [Fe$+2].[L1]2.[z+2] | [Fe(DMF)2]2+ | +2 | aqueous | +1.5000 | -8.5615 | -8.5615 | -8.5615 | [Fe$+2]:+1, [L1]:+2 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169422"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":0.6}],"source":"SRD46 query estimated values"} |
| [Fe$+2].[L1].[z+2] | [Fe(DMF)]2+ | +2 | aqueous | +1.0000 | -5.7077 | -5.7077 | -5.7077 | [Fe$+2]:+1, [L1]:+1 | SRD46 query estimated values | true | {"eq_nodes":[{"assumptions":["DMF is a neutral, monodentate O-donor (binding through the carbonyl O; the N is amide-N, sp\u00b2 delocalized, non-basic).","The transferable analogue is therefore Cd\u00b2\u207a\u2013urea.","For weakly bound neutral O\u2011donors on divalent 3d/4d metals, log K\u2081 values are typically bunched within \u00b10.3\u20130.5 log units, since the electrostatic/dipolar contribution dominates and CFSE differences are minor."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Route: Cd\u00b2\u207a\u2192Fe\u00b2\u207a metal transfer within divalent borderline cations + urea\u2192DMF ligand transfer within neutral C=O amide donors (+~0.15 log units for higher DMF donor number), applied step-by-step on `beta_def_812/840/872/894`.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"9be2216994a6a1eaef7bc70a7e9f0ffe51f67e4206798190606389ec477162c0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421"],"query_answer_sha256":"72ea031c3dc278e1a2f5d6865e6ef4cc686ef38b1254c4302a1fb085d849cfd6","query_id":"q002","rationale":"Cd\u00b2\u207a and Fe\u00b2\u207a are both divalent, high-spin, borderline (Fe\u00b2\u207a slightly harder), with similar ionic radii (Fe\u00b2\u207a HS ~0.78 \u00c5, Cd\u00b2\u207a ~0.95 \u00c5 in 6-coordinate).","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [Fe$+2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [Fe$+2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [Fe$+2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [Fe$+2]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [Fe$+2]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 9 |
| Included in calculation | 9 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 9 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000002 | [<DMF>] + [<Fe2+>] <=> [<Fe2+><DMF>] | +1.0000 | 25.0 | 0.100 | yes | [Fe(DMF)]2+ |
| 2 | session_eq_node_-4000003 | [<DMF>]^2 + [<Fe2+>] <=> [<Fe2+><DMF>2] | +1.5000 | 25.0 | 0.100 | yes | [Fe(DMF)2]2+ |
| 3 | session_eq_node_-4000004 | [<DMF>]^3 + [<Fe2+>] <=> [<Fe2+><DMF>3] | +1.8000 | 25.0 | 0.100 | yes | [Fe(DMF)3]2+ |
| 4 | session_eq_node_-4000005 | [<DMF>]^4 + [<Fe2+>] <=> [<Fe2+><DMF>4] | +2.1000 | 25.0 | 0.100 | yes | [Fe(DMF)4]2+ |
| 5 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 6 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 7 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 8 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 9 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

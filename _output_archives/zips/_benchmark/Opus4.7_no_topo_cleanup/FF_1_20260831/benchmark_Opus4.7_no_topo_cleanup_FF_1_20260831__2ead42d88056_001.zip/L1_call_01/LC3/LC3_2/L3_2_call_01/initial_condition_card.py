inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "task specifies 25 C"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "task specifies 0.1 M ionic strength"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 0.1,    "basis": "known", "note": "0.1 M Fe(II/III); redox axis lets E_V partition oxidation states"},
  {"id": "DMF","lhs": lambda s: s.total["ligand_11422"], "value": 1.0, "basis": "known", "note": "1 M DMF co-solvent/ligand"},
]
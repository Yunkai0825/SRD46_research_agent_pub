# Fe Deduplication — Instruction Phase Summary

## Scenario framing (case-specific recommendations for child agents)

- **Purpose / scenario**: Fe electrodeposition design in a water–ethylene glycol (EG) electrolyte at 0.1 M Fe with 1 M EG. Adopt the "which phase FORMS" framing (not just thermodynamic ground state), because deposition kinetics and metastable oxyhydroxides matter.
- **Working concentration**: 0.1 M Fe, not the 1e-6 M corrosion convention — polynuclear Fe(III) hydrolysis products (Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺) are genuinely competitive and must be retained.
- **Ligand chemistry**: EG at 1 M as a weak diol donor; Fe–EG complexes are present only as SRD-46-estimated entries. These are the scientific point of the calculation — keep both the Fe(II)–EG and Fe(III)–EG hydroxo-mixed complexes and flag them as estimates in downstream reporting.
- **Solids**: Both hydrated and anhydrous forms are in scope because deposition can yield metastable hydrated hydroxides while thermodynamics favors oxides. Retain α-FeOOH (goethite) as distinct from Fe(OH)₃(s) and Fe₂O₃(s).
- **Counterions/carbonates**: Out of scope — no supporting electrolyte specified beyond EG/H₂O.
- **Mixed-valence oxide**: Keep magnetite (Fe₃O₄) as a distinct redox-chain member; it is the equilibrium Fe(II)/Fe(III) solid boundary phase.
- **Cross-source formula duplicates**: Fe²⁺ (Atlas) vs [Fe]²⁺ (SRD-46), Fe³⁺ (Atlas) vs [Fe]³⁺ (SRD-46), and [FeOH]²⁺ (Atlas) vs [Fe(OH)]²⁺ (SRD-46) with μ within ~2 kJ are notation duplicates — collapse to the SRD-46 entry for internal consistency with the estimated EG complexes (same source basis).
- **Hematite formulation**: `Fe2O3 (anh.)` Atlas (μ = +140.457, per Fe₂O₃) and `[(Fe2O3)0.5(s,alpha)]` SRD-46 (μ = +70.354, per ½Fe₂O₃ → +140.7 per Fe₂O₃) are the same phase in different formula units — keep the SRD-46 half-formula-unit spelling to match the multiplier convention.
- **[Fe(OH)₂]⁺ Fe(III)**: Atlas +114.976 vs SRD-46 +100.605 kJ — 14 kJ apart, larger than method error. Flag ambiguity: keep SRD-46 for consistency with the rest of the SRD-46-anchored hydrolysis ladder, but note the discrepancy in the audit.
- **[HFeO₂]⁻ vs [Fe(OH)₃]⁻**: Same stoichiometry (Fe(II), H:-3), differ by 15 kJ — these are the same physical species written two ways. Keep SRD-46 [Fe(OH)₃]⁻.
- **Fe(OH)₂(s) hydrated**: Atlas +75.772 vs SRD-46 +77.453 — same phase, ~2 kJ apart, notation duplicate; keep SRD-46.
- **Fe(OH)₃(s) hydrated**: Atlas +101.964 vs SRD-46 +92.614 — same phase, ~9 kJ apart; keep SRD-46. α-FeOOH at +77.204 is a distinct crystalline phase and stays.
- **FeO₄²⁻ (ferrate)**: Retain — needed for the upper potential boundary of the Pourbaix window.
- **Fe(0) metal**: Retain — deposition target.

## Fe element instruction (one line to child agent)

Collapse cross-source notation duplicates by keeping the SRD-46 spelling (Fe²⁺, Fe³⁺, [Fe(OH)]²⁺, [Fe(OH)₂]⁺, Fe(II) trihydroxo [Fe(OH)₃]⁻ over Atlas [HFeO₂]⁻, Fe(OH)₂(s) and Fe(OH)₃(s) hydrated), and collapse hematite to the SRD-46 half-formula-unit entry, dropping the Atlas duplicates; keep every polynuclear ([Fe₂(OH)₂]⁴⁺, [Fe₃(OH)₄]⁵⁺, Fe₃O₄), α-FeOOH, both estimated Fe–EG hydroxo complexes, ferrate, and Fe(0) metal because they occupy distinct hull regions in the 0.1 M Fe / 1 M EG electrodeposition scenario.

## Session status

The instruction commit was recorded (multiple accidental placeholder commits occurred earlier due to a tool-argument formatting error; the final accepted commit is the one governing the fan-out). Because the iteration limit was reached before the worker batch results returned for review, the review phase (inspecting the regenerated table, targeted redispatch if needed, and `commit_final`) was not reached in this session and remains outstanding. A follow-up session should resume at the review phase with the returned dedup diff and either confirm via `commit_final` or issue targeted `dispatch_target_dedup` calls — in particular to audit the [Fe(OH)₂]⁺ Fe(III) 14 kJ discrepancy noted above.
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse pure cross-source duplicates of identical chemistry: keep one Fe2+ (prefer SRD-46 [Fe]2+), one Fe3+ (prefer SRD-46 [Fe]3+), one Fe(III) monohydroxo [Fe(OH)]2+ (prefer SRD-46), one Fe(III) dihydroxo [Fe(OH)2]+ (prefer SRD-46, lower mu), one Fe(II) trihydroxo (keep SRD-46 [Fe(OH)3]- and drop the Atlas [HFeO2]- notational twin), one hydrated Fe(OH)2(s) (prefer SRD-46), one hydrated Fe(OH)3(s) (prefer SRD-46), and one hematite (prefer SRD-46 alpha-Fe2O3 over Atlas Fe2O3); retain alpha-FeOOH as distinct from Fe(OH)3(s), retain Fe3O4 and both Fe(II)-EG and Fe(III)-EG estimated chelates, retain polynuclears Fe2(OH)2^4+ and Fe3(OH)4^5+, retain Fe(OH)4^2- and Fe(OH)4^- and FeO4^2- and elemental Fe(s). Rationale: 0.1 M Fe with EG ligand for electrodeposition needs full mononuclear+polynuclear+ligated hydrolysis ladder and both hydrated and anhydrous Fe oxides as competing 'which forms' phases, but redundant same-chemistry entries from different databases add no diagram content.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 |
[Orchestration session]
79c3666af3064d7abe229fb3b9e96c72

[Calculation purpose]
Evaluate Fe speciation and Pourbaix behavior in a water-ethylene glycol mixed solvent electrolyte to inform Fe electrodeposition design.

[Requested tasks]
Model a single aqueous electrolyte containing 0.1 M Fe(II/III) with 1 M ethylene glycol (EG, HOCH2CH2OH) as a co-solvent/ligand. Compute the Pourbaix (E-pH) diagram over pH 0-14 and a potential window covering Fe(0)/Fe(II)/Fe(III) at 25 C and 0.1 M ionic strength. Report dominant Fe species per region, Fe(II) stability window, hydroxide/oxide precipitation boundaries, and any EG (diol) chelation effects. If Fe-ethylene glycol stability constants are missing in SRD-46, estimate them from analogous polyol/alcohol/diol donors in SRD-46 (e.g., ethylenediamine analogs adjusted for O vs N, or glycolate/glycerol/sugar-alcohol data) and clearly flag them as estimates. Also produce a pH speciation slice showing Fe(II) fractions across pH.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: Fe electrodeposition bath design in water-ethylene glycol mixed solvent; ask 'which phase forms' (kinetically accessible near a plating cathode), not just 'which is ground state', so metastable oxyhydroxides and polynuclears are retained.
- Working [Fe]tot = 0.1 M with 1 M EG at 25 C, I = 0.1 M: mononuclear hydrolysis products AND polynuclears (Fe2(OH)2^4+, Fe3(OH)4^5+) are real and must be kept; ferrate FeO4^2- is far outside the plating window but harmless, keep.
- Ligand context: estimated Fe(II)-EG and Fe(III)-EG monohydroxo chelates are the whole point of the calculation and must be preserved even though flagged as estimates; do not drop for provenance.
- Hydration: aqueous bath, so hydrated Fe(OH)2 and Fe(OH)3/FeOOH are the physically relevant solids; anhydrous Fe2O3 and Fe3O4 are the thermodynamic sinks and stay as separate ground-state phases (mixed-valence Fe3O4 is a distinct redox-chain member near Fe(0)/Fe(II)/Fe(III) crossovers).
- Counterions: no carbonate, sulfate, chloride, etc. in scope; only Fe, H, O, and EG (L1).
- Cross-source pure duplicates (same core, same charge, same hydration, mu within a few kJ): collapse to one entry, preferring SRD-46 for aqueous (self-consistent with EG estimates from same source) and Atlas for elemental Fe(s); for hematite keep the lower-mu SRD-46 alpha-Fe2O3 formulation and drop the redundant Atlas Fe2O3 spelling. Alpha-FeOOH is chemically distinct from Fe(OH)3(s) and both are kept.
- Do not drop any species solely because mu differs within ~15 kJ across sources when the chemistry (charge, hydrolysis level, nuclearity, hydration) is genuinely identical; pick one and note the choice.
- No gases needed beyond implicit H2O/H+/e-; O2/H2 boundaries are drawn from water, not from inventory entries.

[Committed element instructions]
- Fe: Collapse pure cross-source duplicates of identical chemistry: keep one Fe2+ (prefer SRD-46 [Fe]2+), one Fe3+ (prefer SRD-46 [Fe]3+), one Fe(III) monohydroxo [Fe(OH)]2+ (prefer SRD-46), one Fe(III) dihydroxo [Fe(OH)2]+ (prefer SRD-46, lower mu), one Fe(II) trihydroxo (keep SRD-46 [Fe(OH)3]- and drop the Atlas [HFeO2]- notational twin), one hydrated Fe(OH)2(s) (prefer SRD-46), one hydrated Fe(OH)3(s) (prefer SRD-46), and one hematite (prefer SRD-46 alpha-Fe2O3 over Atlas Fe2O3); retain alpha-FeOOH as distinct from Fe(OH)3(s), retain Fe3O4 and both Fe(II)-EG and Fe(III)-EG estimated chelates, retain polynuclears Fe2(OH)2^4+ and Fe3(OH)4^5+, retain Fe(OH)4^2- and Fe(OH)4^- and FeO4^2- and elemental Fe(s). Rationale: 0.1 M Fe with EG ligand for electrodeposition needs full mononuclear+polynuclear+ligated hydrolysis ladder and both hydrated and anhydrous Fe oxides as competing 'which forms' phases, but redundant same-chemistry entries from different databases add no diagram content.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Identical Fe2+ aqueous cation; keep SRD-46 per plan. | Identical Fe2+ aqueous cation; keep SRD-46 per plan. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Identical Fe2+ aqueous cation; keep SRD-46 per plan. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+, mononuclear hydrolysis ladder member. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +202.623 | generation 1: kept — Neutral Fe(II) dihydroxo aqueous species, in-scope hydrolysis product. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. | Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(II) tetrahydroxo anion, distinct charge/hydrolysis level. |  |
| `DEDUP-37d53b3c048c7255` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe(Ethy)(OH)]+` | SRD46 query estimated values | +68.492 | generation 1: kept — Fe(II)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. | Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. | Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. | Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) tetrahydroxo anion, standard high-pH hydrolysis species. |  |
| `DEDUP-9139fd9c0284d619` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Ethy)(OH)]2+` | SRD46 query estimated values | +97.180 | generation 1: kept — Fe(III)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Trinuclear Fe(III) polynuclear, required per case recommendations at 0.1 M Fe. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate(VI); outside plating window but harmless and retained for completeness. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence anhydrous phase near Fe(0)/Fe(II)/Fe(III) crossovers. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe(s), the plating product; essential. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. | Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water/H+ proxy entry, required baseline aqueous species. | Water/H+ proxy entry, required baseline aqueous species. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Identical Fe2+ aqueous cation; keep SRD-46 per plan. | Identical Fe2+ aqueous cation; keep SRD-46 per plan. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Identical Fe2+ aqueous cation; keep SRD-46 per plan. | Identical Fe2+ aqueous cation; keep SRD-46 per plan. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+, mononuclear hydrolysis ladder member. | Fe(II) monohydroxo [Fe(OH)]+, mononuclear hydrolysis ladder member. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Neutral Fe(II) dihydroxo aqueous species, in-scope hydrolysis product. | Neutral Fe(II) dihydroxo aqueous species, in-scope hydrolysis product. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. | Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. | Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(II) tetrahydroxo anion, distinct charge/hydrolysis level. | Fe(II) tetrahydroxo anion, distinct charge/hydrolysis level. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Ethy)(OH)]+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(II)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. | Fe(II)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. | Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. | Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. | Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. | Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. | Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. | Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. | Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) tetrahydroxo anion, standard high-pH hydrolysis species. | Fe(III) tetrahydroxo anion, standard high-pH hydrolysis species. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Ethy)(OH)]2+` | SRD46 query estimated values | kept | true | generation 1: kept — Fe(III)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. | Fe(III)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Trinuclear Fe(III) polynuclear, required per case recommendations at 0.1 M Fe. | Trinuclear Fe(III) polynuclear, required per case recommendations at 0.1 M Fe. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate(VI); outside plating window but harmless and retained for completeness. | Ferrate(VI); outside plating window but harmless and retained for completeness. |
| aqueous | `L1:1` | — | — | `[Ethylene glycol]` | SRD-46 | kept | true | generation 1: kept — Ethylene glycol ligand, defining component of the bath. | Ethylene glycol ligand, defining component of the bath. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe(s), the plating product; essential. | Elemental Fe(s), the plating product; essential. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence anhydrous phase near Fe(0)/Fe(II)/Fe(III) crossovers. | Magnetite Fe3O4, distinct mixed-valence anhydrous phase near Fe(0)/Fe(II)/Fe(III) crossovers. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. | Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. | Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). | Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |

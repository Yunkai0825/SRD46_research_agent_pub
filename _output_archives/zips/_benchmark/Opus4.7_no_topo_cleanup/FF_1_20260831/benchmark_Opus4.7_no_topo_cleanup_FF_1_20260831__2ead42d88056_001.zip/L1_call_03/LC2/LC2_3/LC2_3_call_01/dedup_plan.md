# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: Fe electrodeposition bath design in water-ethylene glycol mixed solvent; ask 'which phase forms' (kinetically accessible near a plating cathode), not just 'which is ground state', so metastable oxyhydroxides and polynuclears are retained.
- Working [Fe]tot = 0.1 M with 1 M EG at 25 C, I = 0.1 M: mononuclear hydrolysis products AND polynuclears (Fe2(OH)2^4+, Fe3(OH)4^5+) are real and must be kept; ferrate FeO4^2- is far outside the plating window but harmless, keep.
- Ligand context: estimated Fe(II)-EG and Fe(III)-EG monohydroxo chelates are the whole point of the calculation and must be preserved even though flagged as estimates; do not drop for provenance.
- Hydration: aqueous bath, so hydrated Fe(OH)2 and Fe(OH)3/FeOOH are the physically relevant solids; anhydrous Fe2O3 and Fe3O4 are the thermodynamic sinks and stay as separate ground-state phases (mixed-valence Fe3O4 is a distinct redox-chain member near Fe(0)/Fe(II)/Fe(III) crossovers).
- Counterions: no carbonate, sulfate, chloride, etc. in scope; only Fe, H, O, and EG (L1).
- Cross-source pure duplicates (same core, same charge, same hydration, mu within a few kJ): collapse to one entry, preferring SRD-46 for aqueous (self-consistent with EG estimates from same source) and Atlas for elemental Fe(s); for hematite keep the lower-mu SRD-46 alpha-Fe2O3 formulation and drop the redundant Atlas Fe2O3 spelling. Alpha-FeOOH is chemically distinct from Fe(OH)3(s) and both are kept.
- Do not drop any species solely because mu differs within ~15 kJ across sources when the chemistry (charge, hydrolysis level, nuclearity, hydration) is genuinely identical; pick one and note the choice.
- No gases needed beyond implicit H2O/H+/e-; O2/H2 boundaries are drawn from water, not from inventory entries.

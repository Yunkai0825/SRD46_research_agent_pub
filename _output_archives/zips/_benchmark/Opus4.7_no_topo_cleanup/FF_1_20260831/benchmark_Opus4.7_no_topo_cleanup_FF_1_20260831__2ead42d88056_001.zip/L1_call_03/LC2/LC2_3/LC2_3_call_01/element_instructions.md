# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: Fe electrodeposition bath design in water-ethylene glycol mixed solvent; ask 'which phase forms' (kinetically accessible near a plating cathode), not just 'which is ground state', so metastable oxyhydroxides and polynuclears are retained.
- Working [Fe]tot = 0.1 M with 1 M EG at 25 C, I = 0.1 M: mononuclear hydrolysis products AND polynuclears (Fe2(OH)2^4+, Fe3(OH)4^5+) are real and must be kept; ferrate FeO4^2- is far outside the plating window but harmless, keep.
- Ligand context: estimated Fe(II)-EG and Fe(III)-EG monohydroxo chelates are the whole point of the calculation and must be preserved even though flagged as estimates; do not drop for provenance.
- Hydration: aqueous bath, so hydrated Fe(OH)2 and Fe(OH)3/FeOOH are the physically relevant solids; anhydrous Fe2O3 and Fe3O4 are the thermodynamic sinks and stay as separate ground-state phases (mixed-valence Fe3O4 is a distinct redox-chain member near Fe(0)/Fe(II)/Fe(III) crossovers).
- Counterions: no carbonate, sulfate, chloride, etc. in scope; only Fe, H, O, and EG (L1).
- Cross-source pure duplicates (same core, same charge, same hydration, mu within a few kJ): collapse to one entry, preferring SRD-46 for aqueous (self-consistent with EG estimates from same source) and Atlas for elemental Fe(s); for hematite keep the lower-mu SRD-46 alpha-Fe2O3 formulation and drop the redundant Atlas Fe2O3 spelling. Alpha-FeOOH is chemically distinct from Fe(OH)3(s) and both are kept.
- Do not drop any species solely because mu differs within ~15 kJ across sources when the chemistry (charge, hydrolysis level, nuclearity, hydration) is genuinely identical; pick one and note the choice.
- No gases needed beyond implicit H2O/H+/e-; O2/H2 boundaries are drawn from water, not from inventory entries.

## Element instructions

- **Fe**: Collapse pure cross-source duplicates of identical chemistry: keep one Fe2+ (prefer SRD-46 [Fe]2+), one Fe3+ (prefer SRD-46 [Fe]3+), one Fe(III) monohydroxo [Fe(OH)]2+ (prefer SRD-46), one Fe(III) dihydroxo [Fe(OH)2]+ (prefer SRD-46, lower mu), one Fe(II) trihydroxo (keep SRD-46 [Fe(OH)3]- and drop the Atlas [HFeO2]- notational twin), one hydrated Fe(OH)2(s) (prefer SRD-46), one hydrated Fe(OH)3(s) (prefer SRD-46), and one hematite (prefer SRD-46 alpha-Fe2O3 over Atlas Fe2O3); retain alpha-FeOOH as distinct from Fe(OH)3(s), retain Fe3O4 and both Fe(II)-EG and Fe(III)-EG estimated chelates, retain polynuclears Fe2(OH)2^4+ and Fe3(OH)4^5+, retain Fe(OH)4^2- and Fe(OH)4^- and FeO4^2- and elemental Fe(s). Rationale: 0.1 M Fe with EG ligand for electrodeposition needs full mononuclear+polynuclear+ligated hydrolysis ladder and both hydrated and anhydrous Fe oxides as competing 'which forms' phases, but redundant same-chemistry entries from different databases add no diagram content.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Identical Fe2+ aqueous cation; keep SRD-46 per plan. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Identical Fe2+ aqueous cation; keep SRD-46 per plan. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo [Fe(OH)]+, mononuclear hydrolysis ladder member. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Neutral Fe(II) dihydroxo aqueous species, in-scope hydrolysis product. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Same Fe(II) trihydroxo anion in two notations; keep SRD-46 [Fe(OH)3]- (lower mu, preferred source) and drop Atlas [HFeO2]- twin per element guidance. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) tetrahydroxo anion, distinct charge/hydrolysis level. |
| `DEDUP-37d53b3c048c7255` | `[Fe(Ethy)(OH)]+` | SRD46 query estimated values | generation 1: kept — Fe(II)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Identical Fe3+ aqueous cation with matching mu; keep SRD-46 per element guidance, drop Atlas duplicate. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse the Fe(III) monohydroxo cross-source duplicate to SRD-46 per element guidance; retain the distinct polynuclear Fe2(OH)2^4+. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Identical Fe(III) dihydroxo cation from two sources; keep SRD-46 (lower mu, preferred provenance) per plan. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo anion, standard high-pH hydrolysis species. |
| `DEDUP-9139fd9c0284d619` | `[Fe(Ethy)(OH)]2+` | SRD46 query estimated values | generation 1: kept — Fe(III)-EG monohydroxo chelate, central to EG bath calculation; retain estimate. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Trinuclear Fe(III) polynuclear, required per case recommendations at 0.1 M Fe. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate(VI); outside plating window but harmless and retained for completeness. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe(s), the plating product; essential. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence anhydrous phase near Fe(0)/Fe(II)/Fe(III) crossovers. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Cross-source duplicate of hydrated Fe(OH)2(s); prefer SRD-46 per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Kept SRD-46 alpha-Fe2O3 (drop Atlas Fe2O3 duplicate), alpha-FeOOH as distinct polymorph, and SRD-46 hydrated Fe(OH)3(s) (drop Atlas Fe(OH)3 hydr. duplicate). |
| — | `[?]` | SRD-46 | generation 1: kept — Water/H+ proxy entry, required baseline aqueous species. |
| — | `[Ethylene glycol]` | SRD-46 | generation 1: kept — Ethylene glycol ligand, defining component of the bath. |

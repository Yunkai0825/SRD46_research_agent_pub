inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M ionic strength stated by task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 0.1,    "basis": "known", "note": "0.1 M Fe(II/III) total from task; element total used because redox is on-axis"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_9621"], "value": 1.0, "basis": "known", "note": "1 M ethylene glycol stated by task"},
]
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M ionic strength stated by task
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.1, "basis": "known"},  # 0.1 M Fe(II/III) total from task; element total used because redox is on-axis
  {"lhs": lambda s: s.total["ligand_9621"], "rhs": 1.0, "basis": "known"},  # 1 M ethylene glycol stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is one of the two Pourbaix axes (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the other Pourbaix axis covering Fe(0)/Fe(II)/Fe(III) window'},
]

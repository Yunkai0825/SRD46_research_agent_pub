# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.16
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Primary deliverable is a standard 2-D pH-E Pourbaix diagram for Fe with EG; speciation slice is derivable.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
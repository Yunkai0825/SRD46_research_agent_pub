# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\FF_1_Fe_mixed_solvent_speciation\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.01
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M ionic strength stated by task
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.1, "basis": "known"},  # 0.1 M Fe(II/III) total from task; element total used because redox is on-axis
  {"lhs": lambda s: s.total["ligand_9621"], "rhs": 1.0, "basis": "known"},  # 1 M ethylene glycol stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is one of the two Pourbaix axes (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the other Pourbaix axis covering Fe(0)/Fe(II)/Fe(III) window'},
]

```

## Notes
T, I, Fe element total, and EG ligand total are all task-stated. pH and E_V are swept axes for the Pourbaix map and are deferred to L3_3. Redox axis mode uses Fe element total.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
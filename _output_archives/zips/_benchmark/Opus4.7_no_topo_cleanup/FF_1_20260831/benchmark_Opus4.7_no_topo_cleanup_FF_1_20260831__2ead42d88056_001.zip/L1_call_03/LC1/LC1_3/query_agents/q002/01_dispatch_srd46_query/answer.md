Fe(II) has no glycolate entry either. The evidence is now sufficient. Let me draft the final answer.

# Fe²⁺ + Ethylene Glycol (H₂O, 25 °C, I = 0.1 M) — Estimated Speciation for Pourbaix / Electrodeposition Modeling

## 1. Direct SRD‑46 evidence

**No Fe²⁺ – ethylene glycol (EG) stability constants exist in SRD‑46.**
- Target query `c.metal_id = metal_62 AND c.ligand_id = ligand_9621` → 0 rows.
- All 22 EG (ligand_9621) records in the database are for hard, high‑charge cations promoting glycol‑OH deprotonation (β‑definitions of the form [MH₋₁L], [M(OH)(H₋₂L)], [HMO₂(H₋₂L)]…), namely B³⁺ (beta_def_169, beta_def_225 — vlm_166932, vlm_166935), Ge⁴⁺ (beta_def_85, beta_def_86 — vlm_166936, vlm_166937), Y³⁺/La³⁺/Ce³⁺/Pr³⁺/Nd³⁺/Sm³⁺/Eu³⁺/Gd³⁺/Tb³⁺/Dy³⁺/Ho³⁺/Er³⁺/Tm³⁺/Yb³⁺/Lu³⁺ (all beta_def_726, vlm_166916 – vlm_166930), and Pb²⁺ in strongly hydrolyzed form (beta_def_956, vlm_166931). All reported log K values are 0 or negative (−8.95 … +0.30), consistent with proton‑coupled alkoxide/glycolate formation rather than neutral EG adduct formation.
- Fe²⁺ also has **no entry for any simple aliphatic mono‑ol, diol, polyol, glycolate, or glycerol** in SRD‑46 (scan `c.metal_id = metal_62` with any hydroxyl‑bearing aliphatic ligand returned only aromatic phenols, catechol‑like chelates, phenanthroline analogs, oxime/thiol chelates, etc. — no neutral aliphatic‑OH donor at all).
- Fe³⁺ (metal_61) with EG: also 0 rows.

The database silence itself is chemically informative: neutral aliphatic OH is a very weak σ‑donor and Fe²⁺ (d⁶, borderline, no strong CFSE for O), so the 1:1 aqua ↔ EG adduct constant has never been resolvable against Fe(H₂O)₆²⁺ in aqueous studies.

## 2. Chemistry reasoning

Ethylene glycol in water at neutral pH is a **neutral, bidentate‑capable but weakly binding O,O‑donor** (pKa₁ ≈ 14.2). To bind Fe²⁺ appreciably it would have to compete with H₂O (55 M) for the same first‑shell O‑donor position. Two limiting binding modes are relevant:

1. **Neutral‑adduct mode** (Pourbaix‑relevant at pH ≲ 9):
   Fe²⁺ + EG ⇌ [Fe(EG)]²⁺ (η²‑O,O chelate, replacing 2 H₂O)
   – Analogous to Fe²⁺–methanol/glycerol association in water: not detectable in classical potentiometry; typical divalent‑M/neutral‑diol log K₁ in water are ≤ 0 (Ba²⁺ EG ≈ 0, Pb²⁺ hydroxo‑glycolate 0.3 in 1 M).
   – Fe²⁺ is comparable in size/hardness to Mn²⁺/Co²⁺/Ni²⁺ and, for hard neutral O‑donors, its binding is Irving–Williams‑ordered *below* Ni²⁺/Cu²⁺/Zn²⁺; since even Ca²⁺/Ba²⁺ (better O‑lovers) give log K ≈ 0–1 with mono‑carboxylate‑bearing glycolic acid (metal_25/metal_18, vlm_147079‑084) and no measurable neutral‑EG constant, Fe²⁺ neutral‑EG binding must be **log K₁ ≲ 0**.

2. **Alkoxide (H₋₁ or H₋₂) mode** (only above pH ≈ 9):
   Fe²⁺ + EG ⇌ [Fe(H₋₁L)]⁺ + H⁺ (or [Fe(OH)(H₋₂L)]⁻ + …). By analogy to the beta_def_726 Ln³⁺ series (log K ≈ −6.5 to −8.5 at I = 0.1 M) and scaling by charge (z²/r), Fe²⁺ (z = 2) would lie **≈ 4–6 log units below Ln³⁺**, i.e. log K([FeH₋₁L]⁺·[H⁺]/[Fe²⁺][L]) ≈ −12 ± 2. This is far more negative than Fe²⁺ hydrolysis itself (log*K₁₁ ≈ −9.5), so alkoxide binding is **thermodynamically uncompetitive with plain Fe(OH)⁺/Fe(OH)₂ formation** in the Fe(II) region of a Pourbaix diagram and can be neglected.

## 3. Recommended equilibria and estimated log K values

| metal_id | ligand_id | reaction | HxL form | proposed beta_def (existing SRD‑46 template) | constant_type | log K estimate (25 °C, I = 0.1 M) | uncertainty (±, log units) | conditions | route |
|----------|-----------|----------|----------|----------------------------------------------|---------------|-----------------------------------|----------------------------|------------|-------|
| metal_62 | ligand_9621 | Fe²⁺ + L ⇌ [FeL]²⁺  (η²‑O,O neutral‑EG adduct, replaces 2 H₂O) | L (neutral C₂H₆O₂) | beta_def_812  ([ML]/[M][L]) | K (log β₁) | **−0.5** (i.e. essentially non‑binding; effective K ≈ 0.3 M⁻¹) | ±0.5 | aqueous, 25 °C, I = 0.1 M (NaClO₄ or NaCl reference) | Analogy: Ba²⁺ EG ≈ 0 (context) + Fe(II) below Ba/Ca in hard‑O affinity is inconsistent with Irving–Williams, so Fe(II) log K₁ is bracketed to lie ≤ Ba/Pb hydroxo‑glycolate (vlm_166931 = 0.3) and > Ni²⁺/Cu²⁺ non‑detection; database silence across metal_62 for all aliphatic mono/diols corroborates a value ≲ 0. |
| metal_62 | ligand_9621 | Fe²⁺ + 2 L ⇌ [FeL₂]²⁺ | L | beta_def_840 ([ML₂]/[M][L]²) | K (log β₂) | **−1.0** | ±0.7 | same | Statistical/step‑decrease from β₁; no measurable second step in the divalent analog series. |
| metal_62 | ligand_9621 | Fe²⁺ + L ⇌ [Fe(H₋₁L)]⁺ + H⁺ (mono‑alkoxide chelate, only pH ≳ 10) | L (deprotonated once) | beta_def_726  ([MH₋₁L][H]/[M][L]) | K | **−12 ± 2** | ±2 | same | Ln³⁺ series (vlm_166916 – vlm_166930) log K ≈ −6.5 to −8.5; scale by (z=2 vs 3) and by weaker Lewis acidity of Fe²⁺ → ~4–6 log units more negative. Flag: not competitive with Fe(OH)⁺/Fe(OH)₂ hydrolysis; can be omitted from Pourbaix. |
| metal_62 | ligand_9621 | Fe²⁺ + L + H₂O ⇌ [Fe(OH)(H₋₂L)]⁻ + 3 H⁺ (bis‑alkoxide + hydroxo) | L (deprotonated twice) | beta_def_956 template ([M(OH)(H₋₂L)]/[M(OH)₃][L]) | K | not recommended for Fe(II) — negligible (< −20 vs Fe²⁺) | — | — | Pb²⁺ (vlm_166931) log K = 0.3 only because it is expressed relative to Pb(OH)₃⁻; recasting to Fe²⁺ + L basis and applying Fe(II) hydrolysis constants pushes it well below Fe(OH)₂(s) precipitation, so it is dominated by hydroxide chemistry. |

## 4. Guidance for the water–EG mixed‑solvent Pourbaix model

- **In the Fe(II) region of the Pourbaix diagram (pH ≲ 9, before Fe(OH)₂(s))**, ethylene glycol behaves essentially as an **inert co‑solvent** — no Fe(II)–EG complex needs to be included; using log β₁ = −0.5 (K ≈ 0.3 M⁻¹) is a safe upper limit that will give < 5 % of Fe(II) as [Fe(EG)]²⁺ even in pure EG (16 M).
- **Solvent‑composition effects (dielectric decrease from 78 → ~40 in 50 % EG/H₂O)** are far larger than any specific Fe(II)–EG chemistry: they shift Fe(OH)₂/Fe(OH)⁺ apparent p*K by ≈ +1 to +2 units and destabilize charged Fe²⁺ aquo species; those are the actual first‑order Pourbaix corrections needed, and they should be applied on top of the aqueous SRD‑46 Fe(II) hydrolysis and Fe/Fe²⁺ redox constants rather than through an EG complex.
- **Alkoxide/glycolate Fe(II) species can be neglected** except as an alkaline‑cathodic side‑reaction warning if pH climbs above ~10 near the electrode; even then Fe(OH)₂/Fe₃O₄ formation is the dominant sink.

## 5. Provenance summary

- **Direct evidence used (context only, all off‑target):** vlm_166916, vlm_166917, vlm_166918, vlm_166919, vlm_166920, vlm_166921, vlm_166922, vlm_166923, vlm_166924, vlm_166925, vlm_166926, vlm_166927, vlm_166928, vlm_166929, vlm_166930 (Ln³⁺/Y³⁺ + EG, beta_def_726, I = 0.1 M, 22 °C — used for the alkoxide‑route scaling); vlm_166931 (Pb²⁺ + EG, beta_def_956, upper bracket for a divalent hydroxo‑glycolate); vlm_166932, vlm_166935, vlm_166936, vlm_166937 (B³⁺/Ge⁴⁺ + EG — confirm that all reported constants are proton‑coupled, not neutral adducts); vlm_147079, vlm_147080, vlm_147083, vlm_147084 (Ca²⁺/Ba²⁺ + glycolic acid, beta_def_812 — soft bound on divalent‑M O‑donor affinity).
- **Route:** two independent chemistry arguments — (i) database silence for Fe²⁺ across every neutral aliphatic OH/diol/polyol ligand, and (ii) Ln³⁺ EG alkoxide series scaled by charge/hardness to Fe²⁺ — jointly indicate that no Fe(II)–EG complex is thermodynamically significant in water or water‑rich EG at pH < 9.
- **Assumption:** dilute aqueous reference state, 25 °C, I = 0.1 M (NaClO₄/NaCl); values labeled "**estimate**" throughout. Uncertainties are wider than typical SRD‑46 measured constants because they are derived from analog scaling, not direct measurement.
- **Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).
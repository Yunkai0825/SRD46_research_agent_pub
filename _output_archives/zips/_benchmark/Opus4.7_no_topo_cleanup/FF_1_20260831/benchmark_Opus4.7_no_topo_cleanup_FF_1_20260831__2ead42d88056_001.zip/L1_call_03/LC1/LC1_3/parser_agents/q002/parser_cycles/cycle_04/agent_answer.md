Committed one estimated equilibrium for the Fe²⁺ + ethylene glycol system (aqueous, 25 °C, I = 0.1 M):

- Reaction (beta definition 726): [M] + [L] ⇌ [MH₋₁L] + [H]
- log K = −12.0 (uncertainty ±2.0 log units)
- Estimation route: analog scaling from the Ln³⁺/Y³⁺ + ethylene glycol series (VLM records 166916 and 166930, literature reference 8171) — the lanthanide series log K ≈ −6.5 to −8.5 shifted ≈ 4–6 log units more negative to account for the lower charge (z = 2 vs 3) and weaker Lewis acidity of Fe(II).
- Flag: this alkoxide/H₋₁ chelate is not thermodynamically competitive with Fe(II) hydroxide chemistry (Fe(OH)⁺ / Fe(OH)₂), so it can be safely omitted from a Fe(II) Pourbaix diagram.
- Assumption: dilute aqueous reference state, 25 °C, I = 0.1 M (NaClO₄/NaCl); labeled "estimate" with uncertainty wider than typical measured SRD‑46 constants because it is derived from analog scaling rather than direct measurement.

The additional neutral‑adduct estimates ([FeL]²⁺ log K ≈ −0.5 on beta template 812, [FeL₂]²⁺ log K ≈ −1.0 on beta template 840) discussed in the source prose could not be committed: no cited SRD‑46 VLM record binds those beta templates to Fe(II) with ethylene glycol, and the divalent‑M cross‑metal scan explicitly returned zero rows. Consistent with the prose recommendation, ethylene glycol behaves as an essentially inert co‑solvent in the Fe(II) region (pH ≲ 9); dielectric/solvent‑composition corrections to Fe(II) hydrolysis constants are the first‑order effects to include in a water–EG mixed‑solvent Pourbaix model, not any Fe(II)–EG complex.
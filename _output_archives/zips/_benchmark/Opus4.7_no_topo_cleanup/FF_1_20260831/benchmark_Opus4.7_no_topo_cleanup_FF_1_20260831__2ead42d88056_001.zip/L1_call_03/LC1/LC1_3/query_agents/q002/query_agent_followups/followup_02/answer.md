## Citation appendix — SRD‑46 references attached to the VLM records used

No correction. Table below maps each cited VLM group to its SRD‑46 literature reference(s). Sources are deduplicated per source, not per VLM.

### J. Literature for the ethylene glycol (ligand_9621) records

| VLM record(s) used | metal / β‑definition | lit_id | shortcut | citation |
|--------------------|----------------------|--------|----------|----------|
| vlm_166916 – vlm_166930 (Ln³⁺/Y³⁺ + EG, beta_def_726) | 15 lanthanide entries | lit_8171 | 72MC | G. S. Manku and R. C. Chadha, *J. Inorg. Nucl. Chem.*, 1972, 34, 357 |
| vlm_166931 (Pb²⁺ + EG, beta_def_956) | Pb hydroxo‑glycolate | lit_6410 | 68Va | M. Vicedomini, *Gazz. Chim. Ital.*, 1968, 98, 1152 |
| vlm_166932 – vlm_166935 (B³⁺ + EG, beta_def_169/225 incl. ΔH, ΔS) | borate–EG (di)ester | lit_2522 | 57RL | G. L. Roy, A. L. Lafedriere, and J. O. Edwards, *J. Inorg. Nucl. Chem.*, 1957, 4, 106 |
| " | " | lit_12296 | 82DMa | J. G. Dawber and D. H. Matusin, *J. Chem. Soc. Faraday I*, 1982, 78, 2521 |
| " | " | lit_5507 | 67CBa | J. M. Conner and V. C. Bulgrin, *J. Inorg. Nucl. Chem.*, 1967, 29, 1953 |
| " | " | lit_13505 | 85A | R. Aruga, *Talanta*, 1985, 32, 517 |
| " | " | lit_8242 | 72Oa | R. P. Oertel, *Inorg. Chem.*, 1972, 11, 544 |
| " | " | lit_2307 | 56SRa | R. Sargent and W. Rieman III, *J. Phys. Chem.*, 1956, 60, 1370 |
| " | " | lit_9734 | 75PBa | T. Paal and L. Barcza, *Acta Chim. Acad. Sci. Hung.*, 1975, 87, 33 |
| " | " | lit_9735 | 75PBb | T. Paal and L. Barcza, *Acta Chim. Acad. Sci. Hung.*, 1975, 85, 139 |
| " | " | lit_10168 | 76Pa | T. Paal, *Acta Chim. Acad. Sci. Hung.*, 1976, 91, 393 |
| " | " | lit_10487 | 77Pb | T. Paal, *Acta Chim. Acad. Sci. Hung.*, 1977, 95, 31 |
| " | " | lit_5725 | 67NE | V. A. Nazarenko and L. D. Ermak, *Russ. J. Inorg. Chem.*, 1967, 12, 335 |
| vlm_166936, vlm_166937 (Ge⁴⁺ + EG, beta_def_85/86) | Ge–EG diester | lit_2805 | 59Ac | P. J. Antikainen, *Acta Chem. Scand.*, 1959, 13, 312 |

### K. Literature for the Fe(II) Irving–Williams anchor records

| VLM record(s) | anchor system | lit_id | shortcut | citation |
|---------------|---------------|--------|----------|----------|
| vlm_93747 – vlm_93753 (Fe²⁺ + glycine, beta_def_812) | glycine [ML] | lit_885 | 50A | A. Albert, *Biochem. J.*, 1950, 47, 531 |
| " | " | lit_1066 | 52A | A. Albert, *Biochem. J.*, 1952, 50, 690 |
| " | " | lit_1798 | 53Aa | A. Albert, *Biochem. J.*, 1953, 54, 646 |
| " | " | lit_6488 | 69G | A. Gergely, *Acta Chim. Acad. Sci. Hung.*, 1969, 59, 309 |
| " | " | lit_2975 | 59P | D. D. Perrin, *J. Chem. Soc.*, 1959, 290 |
| " | " | lit_11489 | 80BJ | E. Bottari and R. Jasionowska, *Ann. Chim. (Rome)*, 1980, 70, 569 |
| " | " | lit_12237 | 82BP | E. Bottari and R. Porto, *Monat. Chem.*, 1982, 113, 1245 |
| " | " | lit_14512 | 87M | K. Micskei, *J. Chem. Soc. Dalton*, 1987, 255 |
| " | " | lit_8069 | 72IJC | R. M. Izatt, H. D. Johnson, and J. J. Christensen, *J. Chem. Soc. Dalton*, 1972, 1152 |
| " | " | lit_15950 | 91KSG | T. Kiss, I. Sovago, and A. Gergely, *Pure Appl. Chem.*, 1991, 63, 597 |
| " | " | lit_4444 | 64JM | V. Vokl, J. Majer, and M. Mazacova, *Chem. Zvesti*, 1964, 18, 584 |
| vlm_168432, vlm_168433 (Fe²⁺ + acetohydroxamic acid) | hydroxamate [ML], [ML₂] | lit_3919 | 63AL | G. Anderegg, F. L'Eplattenier, and G. Schwarzenbach, *Helv. Chim. Acta*, 1963, 46, 1400 |
| vlm_105500, vlm_105501 (Fe²⁺ + NTA, beta_def_966) | NTA mixed‑OH | lit_12190 | 82Ab | G. Anderegg, *Pure Appl. Chem.*, 1982, 54, 2693 |
| " | " | lit_1047 | 51SF | G. Schwarzenbach and E. Freitag, *Helv. Chim. Acta*, 1951, 34, 1492 |
| " | " | lit_1051 | 51SHa | G. Schwarzenbach and J. Heller, *Helv. Chim. Acta*, 1951, 34, 1889 |
| " | " | lit_1136 | 55SA | G. Schwarzenbach, G. Anderegg, W. Schneider, and H. Senn, *Helv. Chim. Acta*, 1955, 38, 1147 |
| " | " | lit_7338 | 71BFa | O. K. Borggaard, O. Farver, and V. S. Andersen, *Acta Chem. Scand.*, 1971, 25, 3541 |
| " | " | lit_16803 | 94MM | R. J. Motekaitis and A. E. Martell, *J. Coord. Chem.*, 1994, 31, 67 |

**Estimates and reasoning from the prior answers stand unchanged.**
**Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).
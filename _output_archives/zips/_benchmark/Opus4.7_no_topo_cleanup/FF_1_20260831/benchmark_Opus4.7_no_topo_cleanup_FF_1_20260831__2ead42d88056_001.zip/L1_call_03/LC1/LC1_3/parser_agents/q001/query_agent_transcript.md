No SRD-46 record of Fe(III) with any simple aliphatic alcohol or polyol as a neutral donor. I have everything I need — let me deliver the estimate.

## Fe(III) + Ethylene Glycol — Estimated aqueous equilibria at 25 °C, I = 0.1 M

### 1 · Direct SRD-46 record for metal_61 + ligand_9621
**None.** No stability, ΔH, ΔS, or network record exists for Fe³⁺ (metal_61) with ethylene glycol (ligand_9621), and no record exists for Fe³⁺ with any simple aliphatic alcohol/polyol as a neutral donor.

### 2 · Evidence from SRD-46 (analogue routes)

**Route A — every recorded M–EG equilibrium in SRD-46 is proton-coupled diolate binding, not neutral-EG association.**

| system | vlm_id | beta_def | equation (schematic) | log K | T (°C) | I (M) |
|---|---|---|---|---|---|---|
| Y³⁺ + EG | vlm_166916 | beta_def_726 | M + L ⇌ M(H₋₁L) + H⁺ | −6.95 | 22 | 0.1 |
| La³⁺ + EG | vlm_166917 | beta_def_726 | " | −8.5 | 22 | 0.1 |
| Ce³⁺ + EG | vlm_166918 | beta_def_726 | " | 0 (upper limit) | 22 | 0.1 |
| Pr³⁺…Lu³⁺ + EG | vlm_166919 – vlm_166930 | beta_def_726 | " | −7.9 → −6.5 (monotonic Ln contraction) | 22 | 0.1 |
| Ge⁴⁺ + EG (chelate) | vlm_166936 | beta_def_86 | M(OH)₄ + L ⇌ HMO₂(H₋₂L) + H⁺ + 2 H₂O | −8.41 | 25 | 0.1 |
| Ge⁴⁺ + 2 EG (bis-chelate) | vlm_166937 | beta_def_85 | M(OH)₄ + 2 L ⇌ HMO(H₋₂L)₂ + H⁺ + 3 H₂O | −8.95 | 25 | 0.1 |
| B³⁺ + EG (bis-diolatoborate) | vlm_166932 | beta_def_225 | B(OH)₄⁻ + L ⇌ B(OH)₂(H₋₂L)⁻ + 2 H₂O | +0.23 | 25 | 1 |
| Pb²⁺ + EG | vlm_166931 | beta_def_956 | (weak) | +0.3 | 25 | 1 |

Take-away: no metal in SRD-46 has a *neutral* Fe(EG)³⁺-type association constant measured for EG. The observable interaction with hard, tri/tetra-valent cations is deprotonation of one or both –OH groups to form a chelated diolate.

**Route B — Fe(III) with α-hydroxycarboxylates (same H₋₁L / H₋₂L chelate motif, but carboxylate-anchored).**

| system | vlm_ids | beta_def | log K | T (°C) | I (M) |
|---|---|---|---|---|---|
| Fe³⁺ + glycolate (α-OH-acetate, ligand_8640) | vlm_147410, vlm_147411, vlm_147412 | beta_def_107, beta_def_136, beta_def_140 | +1.31 → +2.41 | 25 | 1 |
| Fe³⁺ + malate (α-OH-succinate, ligand_8953) | vlm_154841, vlm_154842, vlm_154843 | beta_def_374, beta_def_381, beta_def_593 | +5 → +26 (varying stoichiometry) | 20 | 0.1 |
| Fe³⁺ + tartrate (α,β-diOH-succinate, ligand_8955) | vlm_155038, vlm_155039, vlm_155040, vlm_155041 | beta_def_374, beta_def_377, beta_def_379 | −11.87 → −2.8 (H₋₁L/H₋₂L dimers) | 20–25 | 0.1–1 |

Take-away: even with a carboxylate anchor holding the α-OH next to Fe(III), the OH-deprotonation step [M₂(H₋₁L)₂]/[M]²[L]² × [H]² requires log K ≈ −12 (tartrate, vlm_155038) i.e. an effective p*K* ≈ 6 per OH under Fe(III) polarization. Removing the carboxylate anchor (i.e., going from tartrate to bare ethylene glycol) removes both the pre-orientation and the −COO⁻ electrostatic stabilization, so the analogous Fe(III)-induced diolate ionization must be *much* less favorable.

**Route C — Ln(III) → Fe(III) transfer for the same beta_def_726 mode.** For Y³⁺ (ionic radius r ≈ 0.90 Å, hard, "hardest" among the recorded Ln set), log K(H₋₁L) = −6.95. Fe³⁺ is smaller (r = 0.645 Å, CN 6), higher charge/radius ratio, and much more Lewis-acidic (first hydrolysis p*K*ₐ ≈ 2.2 vs. 7.7 for Y³⁺). Empirically, Fe³⁺ ligand-alkoxide equilibria are 3–5 log units *more favorable* than the corresponding Y³⁺ equilibrium (e.g., first-hydrolysis Δlog K ≈ +5.5; α-hydroxycarboxylate binding Δlog K ≈ +3–4). Applying that Fe/Y offset to Y + EG gives log K(Fe³⁺, H₋₁L) ≈ −6.95 + (3 to 5) ≈ **−4 to −2**.

**Route D — pKa of neutral EG.** Free ethylene glycol has p*K*ₐ ≈ 15.1 (no SRD-46 record; standard aqueous value). Fe(H₂O)₆³⁺ has p*K*ₐ,₁ ≈ 2.2. Coordination-induced acidification of a diol on Fe(III) typically drops the alcohol p*K*ₐ by 8–10 units (consistent with the α-hydroxycarboxylate data above and with well-known Fe(III)–sugar / Fe(III)–polyol chemistry). Predicted effective p*K*ₐ(coord. EG) ≈ 5–7, i.e. equilibrium constant for  Fe³⁺ + HOCH₂CH₂OH ⇌ Fe(OCH₂CH₂OH)²⁺ + H⁺ of log K ≈ −(5 to 7) once hydrolysis of Fe³⁺ (p*K*ₐ ≈ 2.2) is subtracted → net H₋₁L formation log K ≈ **−3 to −5**. Routes C and D bracket the same window.

### 3 · Recommended dummy stability entries for the Pourbaix / speciation model

All species referred to Fe³⁺ (metal_61) + ethylene glycol (ligand_9621). Neutral aqueous EG association (Fe³⁺ + EG ⇌ Fe(EG)³⁺) is **not observably significant in SRD-46 for any metal** and should be set to essentially zero (log K ≤ 0, effectively negligible vs. Fe(H₂O)₆³⁺). The chemically relevant equilibrium in a water/EG electrolyte is the proton-coupled mono-diolate:

| # | equilibrium | beta_def analogue | reaction (LHS ⇌ RHS) | HxL form | constant_type | estimated log₁₀ K | T (°C) | I (M) | solvent | electrolyte | 1σ uncertainty | provenance / route |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Fe³⁺ + EG ⇌ Fe(EG)³⁺ (neutral monodentate association) | (no matching beta_def in DB; use β₁ definition [ML]/[M][L]) | Fe³⁺ + HOCH₂CH₂OH ⇌ Fe(HOCH₂CH₂OH)³⁺ | L | K (β₁) | **≤ −0.5 (effectively 0; negligible vs. aquo)** | 25 | 0.1 | H₂O | 0.1 M NaClO₄ / NaNO₃ | ±0.5 | No SRD-46 record for Fe³⁺ or any other Mⁿ⁺ with neutral EG association. Neutral polyol adducts to hard cations are experimentally indistinguishable from outer-sphere water displacement (see absence of any such record in SRD-46 for Fe³⁺ with methanol/ethanol/glycerol/EG). Chemistry judgment. |
| 2 | Fe³⁺ + EG ⇌ Fe(H₋₁-EG)²⁺ + H⁺ (mono-diolate chelate, proton-coupled) | beta_def_726 (same expression used for Ln³⁺+EG series: [MH₋₁L][H]/[M][L]) | Fe³⁺ + HOCH₂CH₂OH ⇌ Fe(OCH₂CH₂OH)²⁺ + H⁺ | L (H₋₁L product) | K | **−4.0 ± 1.0** | 25 | 0.1 | H₂O | 0.1 M NaClO₄ / NaNO₃ | ±1.0 (see below) | Double-difference bracket. Upper bound from Fe(III)+glycolate (vlm_147410, vlm_147411, vlm_147412; log K = +1.3 to +2.4, but carboxylate-anchored) and Fe(III)+tartrate H₋₁ dimer (vlm_155038; log K = −11.87 for 2 H⁺ release → −5.9 per OH, with carboxylate anchor). Lower bound from Y³⁺+EG (vlm_166916, beta_def_726, log K = −6.95) plus empirical Fe/Y offset of +3 to +5 log units seen in matched hydrolysis and α-hydroxycarboxylate chemistry. Both routes converge on log K ≈ −3 to −5. |
| 3 | Fe³⁺ + 2 EG ⇌ Fe(H₋₁-EG)₂⁺ + 2 H⁺ (bis-diolate chelate) | analogous to beta_def_85 (Ge⁴⁺+2 EG) but Fe(III) frame [M(H₋₁L)₂][H]²/[M][L]² | Fe³⁺ + 2 HOCH₂CH₂OH ⇌ Fe(OCH₂CH₂OH)₂⁺ + 2 H⁺ | L (2× H₋₁L) | K | **−9 ± 2** | 25 | 0.1 | H₂O | 0.1 M NaClO₄ / NaNO₃ | ±2 | Statistical stepwise: log β₂(2 H⁻¹L) ≈ 2·log K₁(H₋₁L) − 0.5 to −1 (typical stepwise loss for 6-coord Fe(III) with small O-chelates). Consistent with Ge⁴⁺ pattern: log K(1 EG chelate) = −8.41 vs log K(2 EG chelates) = −8.95, i.e. second addition costs ≈ 0.5 relative to the first once M(OH)₄ frame is normalized (vlm_166936, vlm_166937). |

### 4 · What this means for the Pourbaix / electrodeposition model
- Below the Fe³⁺ hydrolysis edge (pH ≲ 2), ethylene glycol is a **spectator O-donor**: it modifies the dielectric constant and outer-sphere solvation of Fe³⁺ but does not form a stable inner-sphere complex with a positive log K. Use equilibrium 1 (~0) — i.e., do not credit any stabilization beyond the water baseline.
- In the pH window where Fe(III) is starting to hydrolyze (pH ≈ 2–4), EG becomes competitive with OH⁻ for the first coordination shell via the diolate chelate (equilibrium 2, log K ≈ −4). This *shifts the effective Fe³⁺/Fe(OH)ₓ Pourbaix boundary to slightly higher pH* in EG-rich electrolytes: EG diolate is a weaker proton donor than water (p*K*ₐ ≈ 15 vs 15.7) yet a stronger chelator once ionized, so it competes with the second hydrolysis step (Fe(OH)₂⁺ formation, p*K* ≈ 3.5). Expect ~0.3–0.7 pH-unit upward shift of the Fe³⁺/Fe(OH)₃(s) line at [EG] ≈ 5 M (≈30 vol %).
- Above pH ≈ 4, hydrolysis dominates and Fe(OH)₃(s) precipitation should be modeled without EG stabilization — equilibrium 3 (log K ≈ −9) is only relevant at very high EG mole fraction (≥50 vol %) *and* pH ≈ 3–4 where the bis-diolate can transiently outrun Fe(OH)ₓ nucleation kinetically. Do not treat it as a thermodynamic sink.
- **Solvent caveat.** Every SRD-46 record above is aqueous (H₂O only). Going to a water/EG mixed solvent lowers the dielectric constant (ε ≈ 78 → ≈ 60 at 30 vol % EG, ≈ 41 for pure EG), which stabilizes charge-neutralized products; the two proton-coupled equilibria (2, 3) will therefore *increase* by roughly +0.5 (30 vol % EG) to +2 (pure EG) log units due to Born electrostatics on ΔZ² = −2 per H⁺ released. This is an additional, well-motivated upward correction the model can apply per solvent composition.

### 5 · SRD-46 identifiers cited
- Target: metal_61, ligand_9621
- Analogue log K records (proton-coupled diolate / H₋₁L / H₋₂L on EG): vlm_166916, vlm_166917, vlm_166918, vlm_166919, vlm_166920, vlm_166921, vlm_166922, vlm_166923, vlm_166924, vlm_166925, vlm_166926, vlm_166927, vlm_166928, vlm_166929, vlm_166930, vlm_166931, vlm_166932, vlm_166935, vlm_166936, vlm_166937; ΔH: vlm_166933; ΔS: vlm_166934
- Fe(III) α-hydroxycarboxylate analogues (Route B): vlm_147410, vlm_147411, vlm_147412 (glycolate, ligand_8640); vlm_154841, vlm_154842, vlm_154843 (malate, ligand_8953); vlm_155038, vlm_155039, vlm_155040, vlm_155041 (tartrate, ligand_8955)
- beta_definition frames used or referenced: beta_def_85, beta_def_86, beta_def_107, beta_def_136, beta_def_140, beta_def_169, beta_def_225, beta_def_374, beta_def_377, beta_def_379, beta_def_381, beta_def_593, beta_def_726, beta_def_956
- Networks touched: ref_eq_net_25911, ref_eq_net_25927, ref_eq_net_25928, ref_eq_net_21168, ref_eq_net_21248

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes, v8.0), records queried above. Numeric log K values for records are quoted exactly from the database; the three Fe(III)+EG entries are labeled **estimates** derived by the double-difference and Fe/Y-transfer routes described.
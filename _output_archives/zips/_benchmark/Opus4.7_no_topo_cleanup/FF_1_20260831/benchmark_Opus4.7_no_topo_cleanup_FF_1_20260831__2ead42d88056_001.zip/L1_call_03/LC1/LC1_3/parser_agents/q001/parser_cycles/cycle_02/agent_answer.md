Committed one estimated equilibrium for Fe(III) + ethylene glycol (metal_61 + ligand_9621) at 25 °C, I = 0.1 M:

- **Equilibrium (beta_def_726, [MH₋₁L][H]/[M][L])**: Fe³⁺ + HOCH₂CH₂OH ⇌ Fe(OCH₂CH₂OH)²⁺ + H⁺
- **log₁₀ K = −4.0 ± 1.0**
- **Method**: Double-difference bracket combining Fe(III) α-hydroxycarboxylate analogues (glycolate, tartrate) with a Y³⁺+EG H₋₁L reference plus an empirical Fe/Y offset (+3 to +5 log units observed in matched hydrolysis and α-hydroxycarboxylate chemistry).
- **Supporting evidence**: vlm_166916 (Y³⁺+EG, beta_def_726, log K = −6.95); vlm_147410, vlm_147411, vlm_147412 (Fe³⁺+glycolate upper-bound anchors); vlm_155038 (Fe³⁺+tartrate H₋₁ dimer, log K = −11.87).
- **Assumption**: The empirical Fe/Y offset of +3 to +5 log units transfers to the H₋₁L formation mode for ethylene glycol.

Both the entry gate and the network gate passed, and the estimate has been committed to the workspace.
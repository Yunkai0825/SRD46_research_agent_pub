Fe(II) has no glycolate entry either. The evidence is now sufficient. Let me draft the final answer.

# Fe²⁺ + Ethylene Glycol (H₂O, 25 °C, I = 0.1 M) — Estimated Speciation for Pourbaix / Electrodeposition Modeling

## 1. Direct SRD‑46 evidence

**No Fe²⁺ – ethylene glycol (EG) stability constants exist in SRD‑46.**
- Target query `c.metal_id = metal_62 AND c.ligand_id = ligand_9621` → 0 rows.
- All 22 EG (ligand_9621) records in the database are for hard, high‑charge cations promoting glycol‑OH deprotonation (β‑definitions of the form [MH₋₁L], [M(OH)(H₋₂L)], [HMO₂(H₋₂L)]…), namely B³⁺ (beta_def_169, beta_def_225 — vlm_166932, vlm_166935), Ge⁴⁺ (beta_def_85, beta_def_86 — vlm_166936, vlm_166937), Y³⁺/La³⁺/Ce³⁺/Pr³⁺/Nd³⁺/Sm³⁺/Eu³⁺/Gd³⁺/Tb³⁺/Dy³⁺/Ho³⁺/Er³⁺/Tm³⁺/Yb³⁺/Lu³⁺ (all beta_def_726, vlm_166916 – vlm_166930), and Pb²⁺ in strongly hydrolyzed form (beta_def_956, vlm_166931). All reported log K values are 0 or negative (−8.95 … +0.30), consistent with proton‑coupled alkoxide/glycolate formation rather than neutral EG adduct formation.
- Fe²⁺ also has **no entry for any simple aliphatic mono‑ol, diol, polyol, glycolate, or glycerol** in SRD‑46 (scan `c.metal_id = metal_62` with any hydroxyl‑bearing aliphatic ligand returned only aromatic phenols, catechol‑like chelates, phenanthroline analogs, oxime/thiol chelates, etc. — no neutral aliphatic‑OH donor at all).
- Fe³⁺ (metal_61) with EG: also 0 rows.

The database silence itself is chemically informative: neutral aliphatic OH is a very weak σ‑donor and Fe²⁺ (d⁶, borderline, no strong CFSE for O), so the 1:1 aqua ↔ EG adduct constant has never been resolvable against Fe(H₂O)₆²⁺ in aqueous studies.

## 2. Chemistry reasoning

Ethylene glycol in water at neutral pH is a **neutral, bidentate‑capable but weakly binding O,O‑donor** (pKa₁ ≈ 14.2). To bind Fe²⁺ appreciably it would have to compete with H₂O (55 M) for the same first‑shell O‑donor position. Two limiting binding modes are relevant:

1. **Neutral‑adduct mode** (Pourbaix‑relevant at pH ≲ 9):
   Fe²⁺ + EG ⇌ [Fe(EG)]²⁺ (η²‑O,O chelate, replacing 2 H₂O)
   – Analogous to Fe²⁺–methanol/glycerol association in water: not detectable in classical potentiometry; typical divalent‑M/neutral‑diol log K₁ in water are ≤ 0 (Ba²⁺ EG ≈ 0, Pb²⁺ hydroxo‑glycolate 0.3 in 1 M).
   – Fe²⁺ is comparable in size/hardness to Mn²⁺/Co²⁺/Ni²⁺ and, for hard neutral O‑donors, its binding is Irving–Williams‑ordered *below* Ni²⁺/Cu²⁺/Zn²⁺; since even Ca²⁺/Ba²⁺ (better O‑lovers) give log K ≈ 0–1 with mono‑carboxylate‑bearing glycolic acid (metal_25/metal_18, vlm_147079‑084) and no measurable neutral‑EG constant, Fe²⁺ neutral‑EG binding must be **log K₁ ≲ 0**.

2. **Alkoxide (H₋₁ or H₋₂) mode** (only above pH ≈ 9):
   Fe²⁺ + EG ⇌ [Fe(H₋₁L)]⁺ + H⁺ (or [Fe(OH)(H₋₂L)]⁻ + …). By analogy to the beta_def_726 Ln³⁺ series (log K ≈ −6.5 to −8.5 at I = 0.1 M) and scaling by charge (z²/r), Fe²⁺ (z = 2) would lie **≈ 4–6 log units below Ln³⁺**, i.e. log K([FeH₋₁L]⁺·[H⁺]/[Fe²⁺][L]) ≈ −12 ± 2. This is far more negative than Fe²⁺ hydrolysis itself (log*K₁₁ ≈ −9.5), so alkoxide binding is **thermodynamically uncompetitive with plain Fe(OH)⁺/Fe(OH)₂ formation** in the Fe(II) region of a Pourbaix diagram and can be neglected.

## 3. Recommended equilibria and estimated log K values

| metal_id | ligand_id | reaction | HxL form | proposed beta_def (existing SRD‑46 template) | constant_type | log K estimate (25 °C, I = 0.1 M) | uncertainty (±, log units) | conditions | route |
|----------|-----------|----------|----------|----------------------------------------------|---------------|-----------------------------------|----------------------------|------------|-------|
| metal_62 | ligand_9621 | Fe²⁺ + L ⇌ [FeL]²⁺  (η²‑O,O neutral‑EG adduct, replaces 2 H₂O) | L (neutral C₂H₆O₂) | beta_def_812  ([ML]/[M][L]) | K (log β₁) | **−0.5** (i.e. essentially non‑binding; effective K ≈ 0.3 M⁻¹) | ±0.5 | aqueous, 25 °C, I = 0.1 M (NaClO₄ or NaCl reference) | Analogy: Ba²⁺ EG ≈ 0 (context) + Fe(II) below Ba/Ca in hard‑O affinity is inconsistent with Irving–Williams, so Fe(II) log K₁ is bracketed to lie ≤ Ba/Pb hydroxo‑glycolate (vlm_166931 = 0.3) and > Ni²⁺/Cu²⁺ non‑detection; database silence across metal_62 for all aliphatic mono/diols corroborates a value ≲ 0. |
| metal_62 | ligand_9621 | Fe²⁺ + 2 L ⇌ [FeL₂]²⁺ | L | beta_def_840 ([ML₂]/[M][L]²) | K (log β₂) | **−1.0** | ±0.7 | same | Statistical/step‑decrease from β₁; no measurable second step in the divalent analog series. |
| metal_62 | ligand_9621 | Fe²⁺ + L ⇌ [Fe(H₋₁L)]⁺ + H⁺ (mono‑alkoxide chelate, only pH ≳ 10) | L (deprotonated once) | beta_def_726  ([MH₋₁L][H]/[M][L]) | K | **−12 ± 2** | ±2 | same | Ln³⁺ series (vlm_166916 – vlm_166930) log K ≈ −6.5 to −8.5; scale by (z=2 vs 3) and by weaker Lewis acidity of Fe²⁺ → ~4–6 log units more negative. Flag: not competitive with Fe(OH)⁺/Fe(OH)₂ hydrolysis; can be omitted from Pourbaix. |
| metal_62 | ligand_9621 | Fe²⁺ + L + H₂O ⇌ [Fe(OH)(H₋₂L)]⁻ + 3 H⁺ (bis‑alkoxide + hydroxo) | L (deprotonated twice) | beta_def_956 template ([M(OH)(H₋₂L)]/[M(OH)₃][L]) | K | not recommended for Fe(II) — negligible (< −20 vs Fe²⁺) | — | — | Pb²⁺ (vlm_166931) log K = 0.3 only because it is expressed relative to Pb(OH)₃⁻; recasting to Fe²⁺ + L basis and applying Fe(II) hydrolysis constants pushes it well below Fe(OH)₂(s) precipitation, so it is dominated by hydroxide chemistry. |

## 4. Guidance for the water–EG mixed‑solvent Pourbaix model

- **In the Fe(II) region of the Pourbaix diagram (pH ≲ 9, before Fe(OH)₂(s))**, ethylene glycol behaves essentially as an **inert co‑solvent** — no Fe(II)–EG complex needs to be included; using log β₁ = −0.5 (K ≈ 0.3 M⁻¹) is a safe upper limit that will give < 5 % of Fe(II) as [Fe(EG)]²⁺ even in pure EG (16 M).
- **Solvent‑composition effects (dielectric decrease from 78 → ~40 in 50 % EG/H₂O)** are far larger than any specific Fe(II)–EG chemistry: they shift Fe(OH)₂/Fe(OH)⁺ apparent p*K by ≈ +1 to +2 units and destabilize charged Fe²⁺ aquo species; those are the actual first‑order Pourbaix corrections needed, and they should be applied on top of the aqueous SRD‑46 Fe(II) hydrolysis and Fe/Fe²⁺ redox constants rather than through an EG complex.
- **Alkoxide/glycolate Fe(II) species can be neglected** except as an alkaline‑cathodic side‑reaction warning if pH climbs above ~10 near the electrode; even then Fe(OH)₂/Fe₃O₄ formation is the dominant sink.

## 5. Provenance summary

- **Direct evidence used (context only, all off‑target):** vlm_166916, vlm_166917, vlm_166918, vlm_166919, vlm_166920, vlm_166921, vlm_166922, vlm_166923, vlm_166924, vlm_166925, vlm_166926, vlm_166927, vlm_166928, vlm_166929, vlm_166930 (Ln³⁺/Y³⁺ + EG, beta_def_726, I = 0.1 M, 22 °C — used for the alkoxide‑route scaling); vlm_166931 (Pb²⁺ + EG, beta_def_956, upper bracket for a divalent hydroxo‑glycolate); vlm_166932, vlm_166935, vlm_166936, vlm_166937 (B³⁺/Ge⁴⁺ + EG — confirm that all reported constants are proton‑coupled, not neutral adducts); vlm_147079, vlm_147080, vlm_147083, vlm_147084 (Ca²⁺/Ba²⁺ + glycolic acid, beta_def_812 — soft bound on divalent‑M O‑donor affinity).
- **Route:** two independent chemistry arguments — (i) database silence for Fe²⁺ across every neutral aliphatic OH/diol/polyol ligand, and (ii) Ln³⁺ EG alkoxide series scaled by charge/hardness to Fe²⁺ — jointly indicate that no Fe(II)–EG complex is thermodynamically significant in water or water‑rich EG at pH < 9.
- **Assumption:** dilute aqueous reference state, 25 °C, I = 0.1 M (NaClO₄/NaCl); values labeled "**estimate**" throughout. Uncertainties are wider than typical SRD‑46 measured constants because they are derived from analog scaling, not direct measurement.
- **Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).

## Additional evidence appendix (Phase‑2 replan → Phase‑3 execution)

The refreshed plan required (a) checking Fe(II) with any weak neutral‑O donor as an Irving–Williams anchor, (b) checking first‑row divalent M²⁺ with EG, and (c) checking Fe(II) hydrolysis / hydroxo chemistry for Pourbaix competition. All three routes confirm the previous answer with no correction; only the provenance is expanded.

### F. Fe(II) with simple neutral / weak O‑donor ligands (Irving–Williams anchor)

The scan `c.metal_id = metal_62` with acetate / formate / urea / DMSO / hydroxide / water / hydroxo name patterns returned **no neutral‑only O‑donor system**. Every hit is an aminocarboxylate, macrocycle, or hydroxamate — i.e. binding is dominated by carboxylate O⁻ and/or amine N, never by neutral aliphatic OH. This confirms that Fe(II) has **no measurable neutral aliphatic‑OH binding in SRD‑46**, so the neutral EG adduct constant must lie below the resolution limit (log K₁ ≲ 0).

Representative anchor entries (context only, not analogues for EG):

| vlm_id | ligand_id | ligand | beta_def_id | log K | I (M) | note |
|--------|-----------|--------|-------------|-------|-------|------|
| vlm_93747…vlm_93753 | ligand_5760 | glycine (HL, N + carboxylate) | beta_def_812 | 4.36 (max) | 0.1 | Fe(II)–glycine [ML] — donor set is N + COO⁻, not OH |
| vlm_168432, vlm_168433 | ligand_9873 | acetohydroxamic acid (HL) | beta_def_812, beta_def_840 | 4.8–8.5 | 0.1 | binds through deprotonated hydroxamate O⁻/N‑O, not neutral OH |

### G. First‑row divalent M²⁺ + ethylene glycol cross‑metal check

Query `c.ligand_id = ligand_9621 AND c.metal_id IN (metal_41 Cu²⁺, metal_31 Co²⁺, metal_112 Ni²⁺, metal_113 Ni, metal_207 Zn²⁺, metal_25 Ca²⁺, metal_18 Ba²⁺, metal_100 Mn²⁺, metal_101, metal_102, metal_103, metal_104)` → **0 rows**. No first‑row divalent or alkaline‑earth EG constant exists in SRD‑46; the entire divalent‑M EG surface is empty except for the hydroxo Pb²⁺ entry vlm_166931 already cited. This reinforces that neutral EG binding is too weak to measure across the whole divalent series.

### H. Fe(II) hydrolysis / hydroxo evidence (Pourbaix competition, no EG involvement)

Fe(II) entries with hydroxide or H₋₁ terms in the β‑definition are all **mixed ligand + hydroxide** species (with aminocarboxylates, macrocycles, phosphonates, pyridyl chelators). SRD‑46 does not tabulate simple Fe²⁺ + H₂O ⇌ FeOH⁺ + H⁺ under `ligand_9621` — that primary hydrolysis constant belongs to the metal‑only side of the database. Representative "mixed‑OH" Fe(II) entries retrieved:

| vlm_id | ligand | beta_def_id | reaction context | log K | I (M) |
|--------|--------|-------------|------------------|-------|-------|
| vlm_105500, vlm_105501 | ligand_6165 NTA | beta_def_966 | [M(OH)L] / [ML][OH] type | 10.6–10.82 | 0.1 |
| vlm_103686 | ligand_6109 (tetraaza‑tetraacetate) | beta_def_839 | mixed‑OH | 8.93 | 0.1 |
| vlm_112684 | ligand_6356 DTPA | beta_def_238 | proton‑coupled | 9.41 | 0.1 |
| vlm_113387, vlm_113393 | ligand_6371 bis‑TETA | beta_def_515, beta_def_839 | proton‑coupled | 10.82–11.42 | 0.1 |

Take‑away for the Pourbaix construction: Fe(OH)⁺ / Fe(OH)₂(aq) / Fe(OH)₂(s) formation controls Fe(II) speciation above pH ~8–9 (Fe²⁺ primary hydrolysis log*β₁ ≈ −9.5, log*β₂ ≈ −20.6 from IUPAC / OECD‑NEA data outside SRD‑46). Even the most optimistic Fe(II)–EG alkoxide estimate (log K ≈ −12 ± 2 on the beta_def_726 template) sits **well below** this hydroxide sink, so alkoxide EG complexes cannot compete with Fe(OH)₂(s) precipitation and can be omitted from the Pourbaix diagram.

### I. Completeness statement

After the Phase‑2 replan, the additional evidence routes (Fe(II) neutral‑O donor scan, first‑row divalent M²⁺ + EG scan, Fe(II) hydroxo scan) all corroborate the previous conclusion without change:

- No true neutral‑EG adduct constant exists in SRD‑46 for Fe²⁺ or any related divalent metal.
- All catalogued EG chemistry is proton‑coupled alkoxide/glycolate on hard/high‑charge cations (Ln³⁺, Y³⁺, B³⁺, Ge⁴⁺, hydrolyzed Pb²⁺).
- Fe(II) shows no measurable neutral aliphatic‑OH binding across the entire SRD‑46 first shell.
- Fe(II) hydroxide chemistry dominates any weak alkoxide route in the alkaline branch of the Pourbaix diagram.

**Estimates from the preceding answer stand unchanged:**

| reaction | beta_def template | log K (25 °C, I = 0.1 M) | ± | status |
|----------|-------------------|--------------------------|---|--------|
| Fe²⁺ + L ⇌ [FeL]²⁺ | beta_def_812 | **−0.5 (estimate)** | 0.5 | recommended upper‑bound only; safe to omit |
| Fe²⁺ + 2 L ⇌ [FeL₂]²⁺ | beta_def_840 | **−1.0 (estimate)** | 0.7 | idem |
| Fe²⁺ + L ⇌ [FeH₋₁L]⁺ + H⁺ | beta_def_726 | **−12 ± 2 (estimate)** | 2 | non‑competitive with Fe(OH)₂; omit for Pourbaix |
| [M(OH)(H₋₂L)] hydroxo‑bis‑alkoxide | beta_def_956 | **not recommended** | — | dominated by Fe(OH)₂(s) |

**Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).

## Citation appendix — SRD‑46 references attached to the VLM records used

No correction. Table below maps each cited VLM group to its SRD‑46 literature reference(s). Sources are deduplicated per source, not per VLM.

### J. Literature for the ethylene glycol (ligand_9621) records

| VLM record(s) used | metal / β‑definition | lit_id | shortcut | citation |
|--------------------|----------------------|--------|----------|----------|
| vlm_166916 – vlm_166930 (Ln³⁺/Y³⁺ + EG, beta_def_726) | 15 lanthanide entries | lit_8171 | 72MC | G. S. Manku and R. C. Chadha, *J. Inorg. Nucl. Chem.*, 1972, 34, 357 |
| vlm_166931 (Pb²⁺ + EG, beta_def_956) | Pb hydroxo‑glycolate | lit_6410 | 68Va | M. Vicedomini, *Gazz. Chim. Ital.*, 1968, 98, 1152 |
| vlm_166932 – vlm_166935 (B³⁺ + EG, beta_def_169/225 incl. ΔH, ΔS) | borate–EG (di)ester | lit_2522 | 57RL | G. L. Roy, A. L. Lafedriere, and J. O. Edwards, *J. Inorg. Nucl. Chem.*, 1957, 4, 106 |
| " | " | lit_12296 | 82DMa | J. G. Dawber and D. H. Matusin, *J. Chem. Soc. Faraday I*, 1982, 78, 2521 |
| " | " | lit_5507 | 67CBa | J. M. Conner and V. C. Bulgrin, *J. Inorg. Nucl. Chem.*, 1967, 29, 1953 |
| " | " | lit_13505 | 85A | R. Aruga, *Talanta*, 1985, 32, 517 |
| " | " | lit_8242 | 72Oa | R. P. Oertel, *Inorg. Chem.*, 1972, 11, 544 |
| " | " | lit_2307 | 56SRa | R. Sargent and W. Rieman III, *J. Phys. Chem.*, 1956, 60, 1370 |
| " | " | lit_9734 | 75PBa | T. Paal and L. Barcza, *Acta Chim. Acad. Sci. Hung.*, 1975, 87, 33 |
| " | " | lit_9735 | 75PBb | T. Paal and L. Barcza, *Acta Chim. Acad. Sci. Hung.*, 1975, 85, 139 |
| " | " | lit_10168 | 76Pa | T. Paal, *Acta Chim. Acad. Sci. Hung.*, 1976, 91, 393 |
| " | " | lit_10487 | 77Pb | T. Paal, *Acta Chim. Acad. Sci. Hung.*, 1977, 95, 31 |
| " | " | lit_5725 | 67NE | V. A. Nazarenko and L. D. Ermak, *Russ. J. Inorg. Chem.*, 1967, 12, 335 |
| vlm_166936, vlm_166937 (Ge⁴⁺ + EG, beta_def_85/86) | Ge–EG diester | lit_2805 | 59Ac | P. J. Antikainen, *Acta Chem. Scand.*, 1959, 13, 312 |

### K. Literature for the Fe(II) Irving–Williams anchor records

| VLM record(s) | anchor system | lit_id | shortcut | citation |
|---------------|---------------|--------|----------|----------|
| vlm_93747 – vlm_93753 (Fe²⁺ + glycine, beta_def_812) | glycine [ML] | lit_885 | 50A | A. Albert, *Biochem. J.*, 1950, 47, 531 |
| " | " | lit_1066 | 52A | A. Albert, *Biochem. J.*, 1952, 50, 690 |
| " | " | lit_1798 | 53Aa | A. Albert, *Biochem. J.*, 1953, 54, 646 |
| " | " | lit_6488 | 69G | A. Gergely, *Acta Chim. Acad. Sci. Hung.*, 1969, 59, 309 |
| " | " | lit_2975 | 59P | D. D. Perrin, *J. Chem. Soc.*, 1959, 290 |
| " | " | lit_11489 | 80BJ | E. Bottari and R. Jasionowska, *Ann. Chim. (Rome)*, 1980, 70, 569 |
| " | " | lit_12237 | 82BP | E. Bottari and R. Porto, *Monat. Chem.*, 1982, 113, 1245 |
| " | " | lit_14512 | 87M | K. Micskei, *J. Chem. Soc. Dalton*, 1987, 255 |
| " | " | lit_8069 | 72IJC | R. M. Izatt, H. D. Johnson, and J. J. Christensen, *J. Chem. Soc. Dalton*, 1972, 1152 |
| " | " | lit_15950 | 91KSG | T. Kiss, I. Sovago, and A. Gergely, *Pure Appl. Chem.*, 1991, 63, 597 |
| " | " | lit_4444 | 64JM | V. Vokl, J. Majer, and M. Mazacova, *Chem. Zvesti*, 1964, 18, 584 |
| vlm_168432, vlm_168433 (Fe²⁺ + acetohydroxamic acid) | hydroxamate [ML], [ML₂] | lit_3919 | 63AL | G. Anderegg, F. L'Eplattenier, and G. Schwarzenbach, *Helv. Chim. Acta*, 1963, 46, 1400 |
| vlm_105500, vlm_105501 (Fe²⁺ + NTA, beta_def_966) | NTA mixed‑OH | lit_12190 | 82Ab | G. Anderegg, *Pure Appl. Chem.*, 1982, 54, 2693 |
| " | " | lit_1047 | 51SF | G. Schwarzenbach and E. Freitag, *Helv. Chim. Acta*, 1951, 34, 1492 |
| " | " | lit_1051 | 51SHa | G. Schwarzenbach and J. Heller, *Helv. Chim. Acta*, 1951, 34, 1889 |
| " | " | lit_1136 | 55SA | G. Schwarzenbach, G. Anderegg, W. Schneider, and H. Senn, *Helv. Chim. Acta*, 1955, 38, 1147 |
| " | " | lit_7338 | 71BFa | O. K. Borggaard, O. Farver, and V. S. Andersen, *Acta Chem. Scand.*, 1971, 25, 3541 |
| " | " | lit_16803 | 94MM | R. J. Motekaitis and A. E. Martell, *J. Coord. Chem.*, 1994, 31, 67 |

**Estimates and reasoning from the prior answers stand unchanged.**
**Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).
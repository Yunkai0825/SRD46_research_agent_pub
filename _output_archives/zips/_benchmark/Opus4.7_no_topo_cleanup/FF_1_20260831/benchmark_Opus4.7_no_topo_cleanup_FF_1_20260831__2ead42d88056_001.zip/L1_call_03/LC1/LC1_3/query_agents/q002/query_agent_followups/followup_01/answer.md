## Additional evidence appendix (Phase‑2 replan → Phase‑3 execution)

The refreshed plan required (a) checking Fe(II) with any weak neutral‑O donor as an Irving–Williams anchor, (b) checking first‑row divalent M²⁺ with EG, and (c) checking Fe(II) hydrolysis / hydroxo chemistry for Pourbaix competition. All three routes confirm the previous answer with no correction; only the provenance is expanded.

### F. Fe(II) with simple neutral / weak O‑donor ligands (Irving–Williams anchor)

The scan `c.metal_id = metal_62` with acetate / formate / urea / DMSO / hydroxide / water / hydroxo name patterns returned **no neutral‑only O‑donor system**. Every hit is an aminocarboxylate, macrocycle, or hydroxamate — i.e. binding is dominated by carboxylate O⁻ and/or amine N, never by neutral aliphatic OH. This confirms that Fe(II) has **no measurable neutral aliphatic‑OH binding in SRD‑46**, so the neutral EG adduct constant must lie below the resolution limit (log K₁ ≲ 0).

Representative anchor entries (context only, not analogues for EG):

| vlm_id | ligand_id | ligand | beta_def_id | log K | I (M) | note |
|--------|-----------|--------|-------------|-------|-------|------|
| vlm_93747…vlm_93753 | ligand_5760 | glycine (HL, N + carboxylate) | beta_def_812 | 4.36 (max) | 0.1 | Fe(II)–glycine [ML] — donor set is N + COO⁻, not OH |
| vlm_168432, vlm_168433 | ligand_9873 | acetohydroxamic acid (HL) | beta_def_812, beta_def_840 | 4.8–8.5 | 0.1 | binds through deprotonated hydroxamate O⁻/N‑O, not neutral OH |

### G. First‑row divalent M²⁺ + ethylene glycol cross‑metal check

Query `c.ligand_id = ligand_9621 AND c.metal_id IN (metal_41 Cu²⁺, metal_31 Co²⁺, metal_112 Ni²⁺, metal_113 Ni, metal_207 Zn²⁺, metal_25 Ca²⁺, metal_18 Ba²⁺, metal_100 Mn²⁺, metal_101, metal_102, metal_103, metal_104)` → **0 rows**. No first‑row divalent or alkaline‑earth EG constant exists in SRD‑46; the entire divalent‑M EG surface is empty except for the hydroxo Pb²⁺ entry vlm_166931 already cited. This reinforces that neutral EG binding is too weak to measure across the whole divalent series.

### H. Fe(II) hydrolysis / hydroxo evidence (Pourbaix competition, no EG involvement)

Fe(II) entries with hydroxide or H₋₁ terms in the β‑definition are all **mixed ligand + hydroxide** species (with aminocarboxylates, macrocycles, phosphonates, pyridyl chelators). SRD‑46 does not tabulate simple Fe²⁺ + H₂O ⇌ FeOH⁺ + H⁺ under `ligand_9621` — that primary hydrolysis constant belongs to the metal‑only side of the database. Representative "mixed‑OH" Fe(II) entries retrieved:

| vlm_id | ligand | beta_def_id | reaction context | log K | I (M) |
|--------|--------|-------------|------------------|-------|-------|
| vlm_105500, vlm_105501 | ligand_6165 NTA | beta_def_966 | [M(OH)L] / [ML][OH] type | 10.6–10.82 | 0.1 |
| vlm_103686 | ligand_6109 (tetraaza‑tetraacetate) | beta_def_839 | mixed‑OH | 8.93 | 0.1 |
| vlm_112684 | ligand_6356 DTPA | beta_def_238 | proton‑coupled | 9.41 | 0.1 |
| vlm_113387, vlm_113393 | ligand_6371 bis‑TETA | beta_def_515, beta_def_839 | proton‑coupled | 10.82–11.42 | 0.1 |

Take‑away for the Pourbaix construction: Fe(OH)⁺ / Fe(OH)₂(aq) / Fe(OH)₂(s) formation controls Fe(II) speciation above pH ~8–9 (Fe²⁺ primary hydrolysis log*β₁ ≈ −9.5, log*β₂ ≈ −20.6 from IUPAC / OECD‑NEA data outside SRD‑46). Even the most optimistic Fe(II)–EG alkoxide estimate (log K ≈ −12 ± 2 on the beta_def_726 template) sits **well below** this hydroxide sink, so alkoxide EG complexes cannot compete with Fe(OH)₂(s) precipitation and can be omitted from the Pourbaix diagram.

### I. Completeness statement

After the Phase‑2 replan, the additional evidence routes (Fe(II) neutral‑O donor scan, first‑row divalent M²⁺ + EG scan, Fe(II) hydroxo scan) all corroborate the previous conclusion without change:

- No true neutral‑EG adduct constant exists in SRD‑46 for Fe²⁺ or any related divalent metal.
- All catalogued EG chemistry is proton‑coupled alkoxide/glycolate on hard/high‑charge cations (Ln³⁺, Y³⁺, B³⁺, Ge⁴⁺, hydrolyzed Pb²⁺).
- Fe(II) shows no measurable neutral aliphatic‑OH binding across the entire SRD‑46 first shell.
- Fe(II) hydroxide chemistry dominates any weak alkoxide route in the alkaline branch of the Pourbaix diagram.

**Estimates from the preceding answer stand unchanged:**

| reaction | beta_def template | log K (25 °C, I = 0.1 M) | ± | status |
|----------|-------------------|--------------------------|---|--------|
| Fe²⁺ + L ⇌ [FeL]²⁺ | beta_def_812 | **−0.5 (estimate)** | 0.5 | recommended upper‑bound only; safe to omit |
| Fe²⁺ + 2 L ⇌ [FeL₂]²⁺ | beta_def_840 | **−1.0 (estimate)** | 0.7 | idem |
| Fe²⁺ + L ⇌ [FeH₋₁L]⁺ + H⁺ | beta_def_726 | **−12 ± 2 (estimate)** | 2 | non‑competitive with Fe(OH)₂; omit for Pourbaix |
| [M(OH)(H₋₂L)] hydroxo‑bis‑alkoxide | beta_def_956 | **not recommended** | — | dominated by Fe(OH)₂(s) |

**Data source:** NIST SRD‑46 (Critically Selected Stability Constants of Metal Complexes).
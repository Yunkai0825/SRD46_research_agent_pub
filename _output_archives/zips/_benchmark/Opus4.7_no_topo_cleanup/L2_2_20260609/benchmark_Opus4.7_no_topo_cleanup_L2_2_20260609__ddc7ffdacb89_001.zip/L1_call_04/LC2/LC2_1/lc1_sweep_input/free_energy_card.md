# Free Energy Analysis Card

**System**: H, Fe, Ca, Mg / Citric acid, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+, [Ca]2+, [Mg]2+
**Ligands**: [Citric acid]
**Generated**: 2026-06-09 18:15:44 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| M3 | Metal component: [Ca]2+ |
| M4 | Metal component: [Mg]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Citric acid] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | 0.001 | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | 0.001 | NIST SRD-46 | metal_62 |
| M3 | [Ca]2+ | +2 | 0.001 | NIST SRD-46 | metal_25 |
| M4 | [Mg]2+ | +2 | 0.001 | NIST SRD-46 | metal_92 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Citric acid] | -3 | 0.01 | [[H]3[L1]] | NIST SRD-46 | ligand_9058 | O=C(O)CC(O)(CC(=O)O)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M3 | [Ca]2+ | +2 | true | 1 |
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |
| Mg | M4 | [Mg]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | C | [-2, -2, 1, 3, 3, 3] | true |
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| M3 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| M4 | [Mg]2+ | metal | [Mg]2+(aq) | +0.0000 | R1 | Mg | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Citric acid] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Citric acid] | [L1] -> [[H]3[L1]] | 3 | 1 | +5.6500 | +32.2485 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Citric acid] | 25.0 | 0.1 | *** | 3 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + [Citric acid] | 20.0~25.0 | 0.1 | 22182 | 4 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + [Citric acid] | 37.0 | 0.15 | 22169 | 5 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Ca]2+ + [Citric acid] | 25.0 | 0~0.1 | 22102 | 5 |
| [Ca]2+ + *** | 25.0 | 0~0.1 | *** | 2 |
| [Mg]2+ + [Citric acid] | 25.0 | 0.1 | 22095 | 3 |
| [Mg]2+ + *** | 25.0 | 3 | *** | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Citric acid] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z-2] | [HCitric acid]2- | -2 | aqueous | +5.6500 | -32.2485 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_157439 | *** |
| [L1].[z-3] | [Citric acid] | -3 | aqueous | +0.0000 | -0.0000 | +32.2485 | +32.2485 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]3+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1].[z+0] | [Fe(Citr)] | +0 | aqueous | +11.1900 | -63.8691 | -63.8691 | -63.8691 | [M1]:+1, [L1]:+1 | vlm_157682 | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [M1]:+1, [OH]:+2 | vlm_170807 | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1].[z-1] | [Fe(Citr)]- | -1 | aqueous | +4.4000 | -26.1246 | -26.1246 | -26.1246 | [M2]:+1, [L1]:+1 | vlm_157621 | *** |
| [M2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | -4 | aqueous | -5.4000 | +32.0620 | +32.0620 | +32.0620 | [M2]:+2, [[H]-1[L1]]:+2 | vlm_157629 | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [M2]:+1, [OH]:+2 | vlm_170677 | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ca]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L1].[z-1] | [Ca(Citr)]- | -1 | aqueous | +3.4500 | -19.6915 | -19.6915 | -19.6915 | [M3]:+1, [L1]:+1 | vlm_157530 | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M3]:+1, [OH]:+1 | vlm_170392 | *** |

#### [Mg]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[z+2] | [Mg]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Mg]2+ + [Citric acid]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[L1].[z-1] | [Mg(Citr)]- | -1 | aqueous | +3.4300 | -19.5774 | -19.5774 | -19.5774 | [M4]:+1, [L1]:+1 | vlm_157515 | *** |

#### [Mg]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH].[z+1] | [Mg(OH)]+ | +1 | aqueous | -11.4000 | +65.0677 | +65.0677 | +65.0677 | [M4]:+1, [OH]:+1 | vlm_170380 | *** |
| [M4]4.[OH]4.[z+4] | [Mg4(OH)4]4+ | +4 | aqueous | -39.9000 | +227.7369 | +227.7369 | +227.7369 | [M4]:+4, [OH]:+4 | vlm_170386 | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]3.[z+0]_(s) | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | *** |

#### [Ca]2+ + [Citric acid]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3]3.[L1]2.[z+0]_(s) | [Ca3(Citric acid)2](s) | +0 | dissolution | +17.0300 | -97.2020 | -97.2020 | -97.2020 | [M3]:+3, [L1]:+2 | vlm_157547 | *** |
| [M3].[[H][L1]].[z+0]_(s) | [CaH(Citric acid)](s) | +0 | dissolution | +11.3900 | -65.0106 | -65.0106 | -65.0106 | [M3]:+1, [[H][L1]]:+1 | vlm_157546 | *** |

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M3]:+1, [OH]:+2 | vlm_170397 | *** |

#### [Mg]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Mg(OH)2(s,brucite)] | +0 | dissolution | -16.8600 | +96.2317 | +96.2317 | +96.2317 | [M4]:+1, [OH]:+2 | vlm_170390 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 40 |
| Included in calculation | 40 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 23 |
| Unresolved (no species in card) | 17 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_157473 | [<H+>2<Citric acid>] + [<H+>] <=> [<H+>3<Citric acid>] | +2.9000 | 25.0 | 0.100 | yes | — |
| 2 | vlm_157459_patched | [<H+><Citric acid>] + [<H+>] <=> [<H+>2<Citric acid>] | +4.1550 | 25.0 | 0.100 | yes | — |
| 3 | vlm_157439 | [<H+>] + [<Citric acid>] <=> [<H+><Citric acid>] | +5.6500 | 25.0 | 0.100 | yes | [HCitric acid]2- |
| 4 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 5 | vlm_157688 | [<H+>] + [<Fe3+>(<O<H+>>)<Citric acid>] <=> [H+2O] + [<Fe3+><Citric acid>] | +2.7000 | 25.0 | 0.100 | yes | — |
| 6 | vlm_157689 | [H+2O]^2 + [<Citric acid>]^2 + [<Fe3+>]^2 <=> [<H+>]^2 + [<Fe3+>2(<O<H+>>)2<Citric acid>2] | +21.2000 | 20.0 | 0.100 | yes | — |
| 7 | vlm_157682 | [<Citric acid>] + [<Fe3+>] <=> [<Fe3+><Citric acid>] | +11.1900 | 25.0 | 0.100 | yes | [Fe(Citr)] |
| 8 | vlm_157687 | [<H+><Citric acid>] + [<Fe3+>] <=> [<Fe3+><H+><Citric acid>] | +6.7000 | 25.0 | 0.100 | yes | — |
| 9 | vlm_170821 | [<OH+->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH+->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 10 | vlm_170791 | [<OH+->] + [<Fe3+>] <=> [<Fe3+><OH+->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 11 | vlm_170807 | [<OH+->]^2 + [<Fe3+>] <=> [<Fe3+><OH+->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 12 | vlm_170808 | [<OH+->]^4 + [<Fe3+>] <=> [<Fe3+><OH+->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 13 | vlm_170814 | [<OH+->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH+->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 14 | vlm_170825 | [<Fe3+><OH+->3(s)] <=> [<OH+->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 15 | vlm_170827 | [H+2O] + [<Fe3+>OO<H+>(s,alpha)] <=> [<Fe3+>] + [O<H+>]^3 | -41.5000 | 25.0 | 0.000 | yes | — |
| 16 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H+2O] <=> [<Fe3+>] + [O<H+>]^3 | -42.7000 | 25.0 | 0.000 | yes | — |
| 17 | vlm_157621_patched | [<Citric acid>] + [<Fe2+>] <=> [<Fe2+><Citric acid>] | +4.4000 | 37.0 | 0.150 | yes | — |
| 18 | vlm_157625_patched | [<H+><Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+><Citric acid>] | +2.9000 | 37.0 | 0.150 | yes | — |
| 19 | vlm_157627 | [<H+>2<Citric acid>] + [<Fe2+>] <=> [<Fe2+><H+>2<Citric acid>] | +1.1000 | 37.0 | 0.150 | yes | — |
| 20 | vlm_157628 | [<Citric acid>] + [<Fe2+><H+><Citric acid>] <=> [<Fe2+><H+><Citric acid>2] | +3.1900 | 37.0 | 0.150 | yes | — |
| 21 | vlm_157629 | [<Citric acid>]^2 + [<Fe2+>]^2 <=> [<H+>]^2 + [<Fe2+>2(<H+>-1<Citric acid>)2] | -5.4000 | 37.0 | 0.150 | yes | [Fe2(Citr)2(OH)2]4- |
| 22 | vlm_170672 | [<OH+->] + [<Fe2+>] <=> [<Fe2+><OH+->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 23 | vlm_170677 | [<OH+->]^2 + [<Fe2+>] <=> [<Fe2+><OH+->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 24 | vlm_170680 | [<OH+->]^3 + [<Fe2+>] <=> [<Fe2+><OH+->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 25 | vlm_170683 | [<OH+->]^4 + [<Fe2+>] <=> [<Fe2+><OH+->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 26 | vlm_170684 | [<Fe2+><OH+->2(s)] <=> [<OH+->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 27 | vlm_157540 | [<H+><Citric acid>] + [<Ca2+>] <=> [<Ca2+><H+><Citric acid>] | +2.0700 | 25.0 | 0.100 | yes | — |
| 28 | vlm_157545 | [<H+>2<Citric acid>] + [<Ca2+>] <=> [<Ca2+><H+>2<Citric acid>] | +1.0000 | 25.0 | 0.100 | yes | — |
| 29 | vlm_157530 | [<Citric acid>] + [<Ca2+>] <=> [<Ca2+><Citric acid>] | +3.4500 | 25.0 | 0.100 | yes | [Ca(Citr)]- |
| 30 | vlm_157546 | [<Ca2+><H+><Citric acid>(s)] <=> [<H+>] + [<Citric acid>] + [<Ca2+>] | -11.3900 | 25.0 | 0.000 | yes | [CaH(Citric acid)](s) |
| 31 | vlm_157547 | [<Ca2+>3<Citric acid>2(s)] <=> [<Citric acid>]^2 + [<Ca2+>]^3 | -17.0300 | 25.0 | 0.000 | yes | [Ca3(Citric acid)2](s) |
| 32 | vlm_170392 | [<OH+->] + [<Ca2+>] <=> [<Ca2+><OH+->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 33 | vlm_170397 | [<Ca2+><OH+->2(s)] <=> [<OH+->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |
| 34 | vlm_157529 | [<H+>2<Citric acid>] + [<Mg2+>] <=> [<Mg2+><H+>2<Citric acid>] | +0.7000 | 25.0 | 0.100 | yes | — |
| 35 | vlm_157515 | [<Citric acid>] + [<Mg2+>] <=> [<Mg2+><Citric acid>] | +3.4300 | 25.0 | 0.100 | yes | [Mg(Citr)]- |
| 36 | vlm_157524 | [<H+><Citric acid>] + [<Mg2+>] <=> [<Mg2+><H+><Citric acid>] | +1.8500 | 25.0 | 0.100 | yes | — |
| 37 | vlm_170385 | [<Mg2+><OH+->] + [<Mg2+>] <=> [<Mg2+>2<OH+->] | -0.3000 | 25.0 | 3.000 | yes | — |
| 38 | vlm_170386 | [<OH+->]^4 + [<Mg2+>]^4 <=> [<Mg2+>4<OH+->4] | +16.1000 | 25.0 | 3.000 | yes | [Mg4(OH)4]4+ |
| 39 | vlm_170380_patched | [<OH+->] + [<Mg2+>] <=> [<Mg2+><OH+->] | +2.6000 | 25.0 | 3.000 | yes | — |
| 40 | vlm_170390 | [<Mg2+><OH+->2(s,brucite)] <=> [<OH+->]^2 + [<Mg2+>] | -11.1400 | 25.0 | 3.000 | yes | [Mg(OH)2(s,brucite)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

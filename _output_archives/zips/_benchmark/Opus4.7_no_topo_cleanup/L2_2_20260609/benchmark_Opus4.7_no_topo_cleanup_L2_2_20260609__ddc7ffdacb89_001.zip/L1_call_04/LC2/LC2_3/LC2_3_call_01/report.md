# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    150.75
- elapsed_s (total):  150.77
- llm_iterations:     39
- llm_tool_calls:     26

- n_groups:           33
- n_multi_groups:     11
- n_singletons:       22
- n_decisions:        33
- n_dropped:          11
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | Identical Ca2+ aqueous ion in different notation; keep SRD-46 version per dedup rule 1. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of aqueous Fe2+; prefer SRD-46 notation. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | Fe(OH)3- and HFeO2- are notational variants of the same mononuclear -1 aqueous species; prefer SRD-46. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate; identical charge, nuclearity, and mu — prefer SRD-46. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | SRD-46 [Fe(OH)]2+ duplicates Atlas [FeOH]2+ (same charge/nuclearity); keep SRD-46. Dinuclear [Fe2(OH)2]4+ is distinct chemistry and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate (same charge, phase, nuclearity); prefer SRD-46 critically-evaluated value. |
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate of aqueous Mg2+; keep SRD-46 per preference. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Mononuclear and tetranuclear Mg hydroxide complexes are distinct species (different nuclearity and charge) per rule 2. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | Ca(OH)2 duplicate across sources — keep SRD-46; drop anhydrous CaO in favor of hydrated polymorph per addendum. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate: same phase, charge, and nuclearity Fe(OH)2(s); prefer SRD-46 per rule 1. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 Fe(OH)3 preferred over Atlas duplicate; anhydrous Fe2O3 dropped in favor of hydrated oxyhydroxide per addendum. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid thermodynamics (reference, 0.0); sole member. |
| aqueous | `Mg$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+2:1 L1:1 H:1` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+2:3 L1:2` | yes | Valid thermodynamics; sole member. |
| solid | `Fe$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Mg$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Mg$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (Identical Ca2+ aqueous ion in different notation; keep SRD-46 version per dedup rule 1.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Fe2+; prefer SRD-46 notation.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded (Fe(OH)3- and HFeO2- are notational variants of the same mononuclear -1 aqueous species; prefer SRD-46.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate; identical charge, nuclearity, and mu — prefer SRD-46.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (SRD-46 [Fe(OH)]2+ duplicates Atlas [FeOH]2+ (same charge/nuclearity); keep SRD-46. Dinuclear [Fe2(OH)2]4+ is distinct chemistry and retained.) |
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Mg2+; keep SRD-46 per preference.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (Ca(OH)2 duplicate across sources — keep SRD-46; drop anhydrous CaO in favor of hydrated polymorph per addendum.) |
| `CaO` | Atlas | dissolution | dedup: excluded (Ca(OH)2 duplicate across sources — keep SRD-46; drop anhydrous CaO in favor of hydrated polymorph per addendum.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate: same phase, charge, and nuclearity Fe(OH)2(s); prefer SRD-46 per rule 1.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate; anhydrous Fe2O3 dropped in favor of hydrated oxyhydroxide per addendum.) |
| `Fe2O3` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate; anhydrous Fe2O3 dropped in favor of hydrated oxyhydroxide per addendum.) |

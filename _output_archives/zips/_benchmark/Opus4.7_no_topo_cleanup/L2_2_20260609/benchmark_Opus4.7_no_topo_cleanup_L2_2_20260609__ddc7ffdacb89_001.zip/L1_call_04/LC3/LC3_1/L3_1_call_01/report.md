# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_04\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 7.81
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation fractions vs pH 7-9 at fixed totals — single pH DOF.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_04\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
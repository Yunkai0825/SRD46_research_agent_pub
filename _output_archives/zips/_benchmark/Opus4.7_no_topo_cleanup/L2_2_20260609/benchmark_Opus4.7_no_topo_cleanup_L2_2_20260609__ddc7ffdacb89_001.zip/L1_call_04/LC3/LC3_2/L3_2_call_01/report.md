# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_04\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 31.77
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 8 pin(s) (6 known, 2 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Ca$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Mg$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.005, "basis": "known"},
]
```

## Notes
T=25 C, I=0.1 m, and totals (Fe(III), Ca, Mg = 1 mM; citrate = 5 mM) all from task. Fe(II)/Fe(VI) totals set to 0 to keep iron as Fe(III) only; redox not modelled. pH is the swept axis and is NOT pinned.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# Eq-map screen — m92_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand10076_beta516_net27322` | `[ML] + [M] <=> [M2L]` | vlm_170385@(25.0,3.0) = K-0.300 | 1 | -0.300 / -0.300 / -0.300 / -0.300 | vlm_170385@(25.0,3.0) = K-0.300 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal92_ligand10076_beta674_net27322` | `[M]^4 + [L]^4 <=> [M4L4]` | vlm_170386@(25.0,3.0) = K+16.100 | 2 | +16.100 / +17.100 / +17.100 / +18.100 | vlm_170386@(25.0,3.0) = K+16.100 (+0.00 °C, +2.90 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal92_ligand10076_beta812_net27322` | `[M] + [L] <=> [ML]` | vlm_170380@(25.0,3.0) = K+1.700 | 4 | -1.900 / +1.950 / +1.150 / +2.600 | vlm_170379@(37.0,0.15) = K-1.900 (+12.00 °C, +0.05 M) | `sibling_sign_split, mean_median_gap, wide_TI_distance` |
| 4 | `metal92_ligand10076_beta342_net27322` | `[ML2(s,brucite)] <=> [M] + [L]^2` | vlm_170390@(25.0,3.0) = K-11.140 | 2 | -11.150 / -11.145 / -11.145 / -11.140 | vlm_170391@(25.0,0.0) = K-11.150 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

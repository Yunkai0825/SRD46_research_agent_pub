[Purpose: Evaluate EDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.]
[Tasks:
Model one pot containing Fe(III), Ca(II), and Mg(II) at 1 mM each together with EDTA at 5 mM total, over pH 7-9 at 25 C and ionic strength 0.1 m. Report the fraction of each metal bound by EDTA vs free/hydroxide species across this pH window, and quantify how much of the EDTA pool is consumed by Fe(III) vs by Ca(II) and Mg(II).
]
[Pair: pair_key=`m62_l6277`, metal_id=62, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m62_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand6277_beta786_net5020` | `[M] + [HL] <=> [MHL]` | vlm_108569@(25.0,0.1) = K+6.820 | 1 | +6.820 / +6.820 / +6.820 / +6.820 | vlm_108569@(25.0,0.1) = K+6.820 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal62_ligand6277_beta812_net5020` | `[M] + [L] <=> [ML]` | vlm_108566@(25.0,0.1) = K+14.300 | 1 | +14.300 / +14.300 / +14.300 / +14.300 | vlm_108566@(25.0,0.1) = K+14.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

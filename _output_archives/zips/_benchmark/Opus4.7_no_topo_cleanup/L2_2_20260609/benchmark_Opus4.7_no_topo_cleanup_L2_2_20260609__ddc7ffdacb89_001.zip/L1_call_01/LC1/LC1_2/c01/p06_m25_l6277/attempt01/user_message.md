[Purpose: Evaluate EDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.]
[Tasks:
Model one pot containing Fe(III), Ca(II), and Mg(II) at 1 mM each together with EDTA at 5 mM total, over pH 7-9 at 25 C and ionic strength 0.1 m. Report the fraction of each metal bound by EDTA vs free/hydroxide species across this pH window, and quantify how much of the EDTA pool is consumed by Fe(III) vs by Ca(II) and Mg(II).
]
[Pair: pair_key=`m25_l6277`, metal_id=25, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal25_ligand6277_beta788_net4938`
[Screen report]
# Eq-map screen — m25_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal25_ligand6277_beta788_net4938` | `[ML] + [H] <=> [MHL]` | vlm_108360@(25.0,0.1) = K+3.100 | 2 | +3.100 / +3.140 / +3.140 / +3.180 | vlm_108360@(25.0,0.1) = K+3.100 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal25_ligand6277_beta812_net4938` | `[M] + [L] <=> [ML]` | vlm_108344@(25.0,0.1) = K+10.650 | 6 | +9.680 / +10.545 / +10.442 / +10.810 | vlm_108344@(25.0,0.1) = K+10.650 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

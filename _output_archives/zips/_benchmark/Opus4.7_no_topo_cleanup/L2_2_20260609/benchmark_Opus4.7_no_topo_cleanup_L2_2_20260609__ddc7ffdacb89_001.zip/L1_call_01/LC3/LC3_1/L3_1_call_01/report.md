# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 7.56
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH to track metal-EDTA fractions across pH 7-9.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    72.35
- elapsed_s (total):  72.36
- llm_iterations:     32
- llm_tool_calls:     19

- n_groups:           31
- n_multi_groups:     11
- n_singletons:       20
- n_decisions:        31
- n_dropped:          11
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | True duplicate of aqueous Ca2+; prefer SRD-46 over Atlas. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of Fe2+ aqueous ion; keep SRD-46 entry per preference rule. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | True duplicate: HFeO2- and Fe(OH)3- are notational variants of the same mononuclear aqueous Fe(III) hydroxo anion; keep SRD-46 entry. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate of Fe3+ aqueous cation; keep SRD-46 entry per tie-break rule. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | Mononuclear FeOH2+ duplicated between SRD-46 and Atlas; keep SRD-46 version (also lower mu). Dinuclear Fe2(OH)2^4+ is distinct nuclearity and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate (same charge, nuclearity, phase); kept SRD-46 per plan. |
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate of Mg2+ aqueous ion; prefer SRD-46 over Atlas. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Mononuclear and tetranuclear Mg hydroxo complexes are chemically distinct species despite identical core stoichiometry. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | Keep SRD-46 Ca(OH)2 (lower mu) over Atlas duplicate; drop anhydrous CaO per addendum preferring hydrated form. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | Same species (Fe(OH)2 solid, neutral, mononuclear); prefer SRD-46 over Atlas duplicate. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | Both Fe(OH)3 entries are same species; keep SRD-46 (lower mu). Drop anhydrous Fe2O3 per addendum preferring hydrated oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid reference (0.000 kJ); sole member. |
| aqueous | `Mg$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Mg$+2:1 L1:1 H:1` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Ca$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| solid | `Fe$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Mg$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Mg$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ca2+; prefer SRD-46 over Atlas.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of Fe2+ aqueous ion; keep SRD-46 entry per preference rule.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded (True duplicate: HFeO2- and Fe(OH)3- are notational variants of the same mononuclear aqueous Fe(III) hydroxo anion; keep SRD-46 entry.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate of Fe3+ aqueous cation; keep SRD-46 entry per tie-break rule.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (Mononuclear FeOH2+ duplicated between SRD-46 and Atlas; keep SRD-46 version (also lower mu). Dinuclear Fe2(OH)2^4+ is distinct nuclearity and retained.) |
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate of Mg2+ aqueous ion; prefer SRD-46 over Atlas.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (Keep SRD-46 Ca(OH)2 (lower mu) over Atlas duplicate; drop anhydrous CaO per addendum preferring hydrated form.) |
| `CaO` | Atlas | dissolution | dedup: excluded (Keep SRD-46 Ca(OH)2 (lower mu) over Atlas duplicate; drop anhydrous CaO per addendum preferring hydrated form.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (Same species (Fe(OH)2 solid, neutral, mononuclear); prefer SRD-46 over Atlas duplicate.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (Both Fe(OH)3 entries are same species; keep SRD-46 (lower mu). Drop anhydrous Fe2O3 per addendum preferring hydrated oxyhydroxide.) |
| `Fe2O3` | Atlas | dissolution | dedup: excluded (Both Fe(OH)3 entries are same species; keep SRD-46 (lower mu). Drop anhydrous Fe2O3 per addendum preferring hydrated oxyhydroxide.) |

[Purpose: Evaluate DTPA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.]
[Tasks:
Model one pot containing Fe(III), Ca(II), and Mg(II) at 1 mM each together with DTPA (diethylenetriaminepentaacetic acid) at 5 mM total, over pH 7-9 at 25 C and ionic strength 0.1 m. Report the fraction of each metal bound by DTPA vs free/hydroxide species across this pH window, and quantify how much of the DTPA pool is consumed by Fe(III) vs by Ca(II) and Mg(II).
]
[Pair: pair_key=`m62_l6356`, metal_id=62, ligand_id=6356, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand6356_beta788_net6724`
  - `metal62_ligand6356_beta966_net6724`
  - `metal62_ligand6356_beta238_net6724`
  - `metal62_ligand6356_beta516_net6724`
[Screen report]
# Eq-map screen — m62_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand6356_beta812_net6724` | `[M] + [L] <=> [ML]` | vlm_112678@(25.0,0.1) = K+16.200 | 1 | +16.200 / +16.200 / +16.200 / +16.200 | vlm_112678@(25.0,0.1) = K+16.200 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal62_ligand6356_beta788_net6724` | `[ML] + [H] <=> [MHL]` | vlm_112681@(25.0,0.1) = K+5.300 | 2 | +5.260 / +5.280 / +5.280 / +5.300 | vlm_112681@(25.0,0.1) = K+5.300 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal62_ligand6356_beta966_net6724` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_112683@(25.0,0.1) = K+8.770 | 1 | +8.770 / +8.770 / +8.770 / +8.770 | vlm_112683@(25.0,0.1) = K+8.770 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal62_ligand6356_beta238_net6724` | `[M(OH)2L] + [H] <=> [M(OH)L] + [H2O]` | vlm_112684@(25.0,0.1) = K+9.410 | 1 | +9.410 / +9.410 / +9.410 / +9.410 | vlm_112684@(25.0,0.1) = K+9.410 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 5 | `metal62_ligand6356_beta516_net6724` | `[ML] + [M] <=> [M2L]` | vlm_112685@(20.0,0.1) = K+2.980 | 1 | +2.980 / +2.980 / +2.980 / +2.980 | vlm_112685@(20.0,0.1) = K+2.980 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

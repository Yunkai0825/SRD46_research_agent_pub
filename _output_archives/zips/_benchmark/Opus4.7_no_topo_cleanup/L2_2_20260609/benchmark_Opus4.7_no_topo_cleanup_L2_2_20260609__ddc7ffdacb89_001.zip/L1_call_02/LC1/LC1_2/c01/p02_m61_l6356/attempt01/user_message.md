[Purpose: Evaluate DTPA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.]
[Tasks:
Model one pot containing Fe(III), Ca(II), and Mg(II) at 1 mM each together with DTPA (diethylenetriaminepentaacetic acid) at 5 mM total, over pH 7-9 at 25 C and ionic strength 0.1 m. Report the fraction of each metal bound by DTPA vs free/hydroxide species across this pH window, and quantify how much of the DTPA pool is consumed by Fe(III) vs by Ca(II) and Mg(II).
]
[Pair: pair_key=`m61_l6356`, metal_id=61, ligand_id=6356, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand6356_beta788_net6733`
  - `metal61_ligand6356_beta966_net6733`
[Screen report]
# Eq-map screen — m61_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand6356_beta812_net6733` | `[M] + [L] <=> [ML]` | vlm_112712@(25.0,0.1) = K+28.000 | 3 | +27.600 / +27.800 / +27.800 / +28.000 | vlm_112712@(25.0,0.1) = K+28.000 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal61_ligand6356_beta788_net6733` | `[ML] + [H] <=> [MHL]` | vlm_112715@(25.0,0.1) = K+3.560 | 2 | +3.560 / +3.565 / +3.565 / +3.570 | vlm_112715@(25.0,0.1) = K+3.560 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand6356_beta966_net6733` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_112717@(25.0,0.1) = K+9.660 | 2 | +9.660 / +9.880 / +9.880 / +10.100 | vlm_112717@(25.0,0.1) = K+9.660 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Evaluate DTPA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.]
[Tasks:
Model one pot containing Fe(III), Ca(II), and Mg(II) at 1 mM each together with DTPA (diethylenetriaminepentaacetic acid) at 5 mM total, over pH 7-9 at 25 C and ionic strength 0.1 m. Report the fraction of each metal bound by DTPA vs free/hydroxide species across this pH window, and quantify how much of the DTPA pool is consumed by Fe(III) vs by Ca(II) and Mg(II).
]
[Pair: pair_key=`m25_l10076`, metal_id=25, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal25_ligand10076_beta334_net27326`
[Screen report]
# Eq-map screen — m25_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal25_ligand10076_beta812_net27326` | `[M] + [L] <=> [ML]` | vlm_170392@(25.0,0.1) = K+0.960 | 3 | +0.860 / +0.960 / +1.040 / +1.300 | vlm_170392@(25.0,0.1) = K+0.960 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal25_ligand10076_beta334_net27326` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170397@(25.0,0.0) = K-5.190 | 1 | -5.190 / -5.190 / -5.190 / -5.190 | vlm_170397@(25.0,0.0) = K-5.190 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

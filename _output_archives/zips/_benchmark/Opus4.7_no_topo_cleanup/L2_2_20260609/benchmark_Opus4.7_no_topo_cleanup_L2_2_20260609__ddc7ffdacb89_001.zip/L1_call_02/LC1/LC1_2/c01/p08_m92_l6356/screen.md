# Eq-map screen — m92_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand6356_beta788_net6660` | `[ML] + [H] <=> [MHL]` | vlm_112536@(37.0,0.15) = K+6.960 | 3 | +6.850 / +6.960 / +6.967 / +7.090 | vlm_112534@(25.0,0.1) = K+6.850 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal92_ligand6356_beta516_net6660` | `[ML] + [M] <=> [M2L]` | vlm_112537@(37.0,0.15) = K+2.070 | 1 | +2.070 / +2.070 / +2.070 / +2.070 | vlm_112537@(37.0,0.15) = K+2.070 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal92_ligand6356_beta812_net6660` | `[M] + [L] <=> [ML]` | vlm_112530@(37.0,0.15) = K-8.560 | 2 | -8.560 / +0.355 / +0.355 / +9.270 | vlm_112529@(25.0,0.1) = K+9.270 (+0.00 °C, +0.00 M) | `mad_outlier, nearest_request_sign_mismatch` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    139.59
- elapsed_s (total):  139.61
- llm_iterations:     38
- llm_tool_calls:     26

- n_groups:           33
- n_multi_groups:     11
- n_singletons:       22
- n_decisions:        33
- n_dropped:          10
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | Identical Ca2+ aqueous species; prefer SRD-46 per plan rule 1. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of aqueous Fe2+; prefer SRD-46 notation. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | [HFeO2]- is the dehydrated notation of [Fe(OH)3]-; same charge/nuclearity/phase, so keep the SRD-46 entry. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate; identical charge, phase, nuclearity, and mu — prefer SRD-46. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | SRD-46 [Fe(OH)]2+ supersedes Atlas duplicate [FeOH]2+ (same mononuclear species, charge, phase); dinuclear [Fe2(OH)2]4+ is chemically distinct and retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate; prefer SRD-46 over Atlas per plan rule 1. |
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate of aqueous Mg2+; prefer SRD-46 per plan rule 1. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Mononuclear and tetranuclear Mg-hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)`, `CaO` | Ca(OH)2 duplicated across SRD-46 and Atlas; kept SRD-46 version. CaO is a distinct anhydrous phase, retained per rule 2. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate: same Fe(OH)2 solid, neutral, mononuclear; prefer SRD-46 over Atlas per plan rule 1. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 Fe(OH)3 preferred over Atlas duplicate (same species, lower mu, preferred source); anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide for aqueous room-T speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ. |
| aqueous | `Ca$+2:1 H:-1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Ca$+2:1 L1:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-2` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-4` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:1 L1:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+2:2 L1:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+3:1 H:-4` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+3:1 L1:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+3:3 H:-4` | yes | Sole member with valid thermodynamics. |
| aqueous | `Fe$+6:1 H:-8` | yes | Sole member with valid thermodynamics. |
| aqueous | `L1:1` | yes | Sole member with valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Reference species (mu=0). |
| aqueous | `Mg$+2:1 L1:1` | yes | Sole member with valid thermodynamics. |
| solid | `Ca$+0:1` | yes | Sole member with valid thermodynamics. |
| solid | `Ca$+2:1 H:-4` | yes | Sole member with valid thermodynamics. |
| solid | `Fe$+0:1` | yes | Sole member with valid thermodynamics. |
| solid | `Mg$+0:1` | yes | Sole member with valid thermodynamics. |
| solid | `Mg$+2:1 H:-2` | yes | Sole member with valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (Identical Ca2+ aqueous species; prefer SRD-46 per plan rule 1.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Fe2+; prefer SRD-46 notation.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded ([HFeO2]- is the dehydrated notation of [Fe(OH)3]-; same charge/nuclearity/phase, so keep the SRD-46 entry.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate; identical charge, phase, nuclearity, and mu — prefer SRD-46.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (SRD-46 [Fe(OH)]2+ supersedes Atlas duplicate [FeOH]2+ (same mononuclear species, charge, phase); dinuclear [Fe2(OH)2]4+ is chemically distinct and retained.) |
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Mg2+; prefer SRD-46 per plan rule 1.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (Ca(OH)2 duplicated across SRD-46 and Atlas; kept SRD-46 version. CaO is a distinct anhydrous phase, retained per rule 2.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate: same Fe(OH)2 solid, neutral, mononuclear; prefer SRD-46 over Atlas per plan rule 1.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate (same species, lower mu, preferred source); anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide for aqueous room-T speciation.) |
| `Fe2O3` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 preferred over Atlas duplicate (same species, lower mu, preferred source); anhydrous Fe2O3 dropped per addendum favoring hydrated Fe(III) oxyhydroxide for aqueous room-T speciation.) |

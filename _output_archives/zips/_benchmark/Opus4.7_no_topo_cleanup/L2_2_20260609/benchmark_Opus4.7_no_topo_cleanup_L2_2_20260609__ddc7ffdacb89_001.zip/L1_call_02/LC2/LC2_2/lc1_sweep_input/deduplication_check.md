# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ca$+2 | M3 | [Ca]2+ | Ca | +2 |
| Fe$+2 | M2 | [Fe]2+ | Fe | +2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | +3 |
| Mg$+2 | M4 | [Mg]2+ | Mg | +2 |
| Ca$+0 | Atlas | Ca (ox +0) | Ca | +0 |
| Fe$+0 | Atlas | Fe (ox +0) | Fe | +0 |
| Fe$+6 | Atlas | Fe (ox +6) | Fe | +6 |
| Mg$+0 | Atlas | Mg (ox +0) | Mg | +0 |

**Total species**: 47 | **Core groups**: 33 | **Multi-member groups**: 11 | **Cross-source groups**: 10

## 1. Aqueous / Dissolved Species

25 core groups, 34 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Ca$+2:1` | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Ca$+2:1` | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 4 | `Ca$+2:1 H:-1` | [Ca(OH)]+ | SRD-46 | +1 | 1x | +74.428 | 0 | — |
| 5 | `Ca$+2:1 L1:1` | [Ca(DTPA)]3- | SRD-46 | -3 | 1x | -61.358 | 0 | — |
| 6 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 7 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 8 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — |
| 9 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +202.623 | 0 | — |
| 10 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref |
| 11 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 |
| 12 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — |
| 13 | `Fe$+2:1 L1:1` | [Fe(DTPA)]3- | SRD-46 | -3 | 1x | -92.465 | 0 | — |
| 14 | `Fe$+2:1 L1:1 H:1` | [Fe(DTPA)H]2- | SRD-46 | -2 | 1x | -122.715 | 0 | — |
| 15 | `Fe$+2:2 L1:1` | [Fe2(DTPA)]- | SRD-46 | -1 | 1x | -109.474 | 0 | — |
| 16 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 |
| 17 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref |
| 18 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref |
| 19 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +91.169 | -1 | +1.238 |
| 20 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 |
| 21 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | ref |
| 22 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +14.371 |
| 23 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — |
| 24 | `Fe$+3:1 L1:1` | [Fe(DTPA)]2- | SRD-46 | -2 | 1x | -85.466 | -1 | — |
| 25 | `Fe$+3:1 L1:1 H:1` | [Fe(DTPA)H]- | SRD-46 | -1 | 1x | -105.785 | -1 | — |
| 26 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — |
| 27 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +544.799 | -4 | — |
| 28 | `L1:1` | [DTPA] | SRD-46 | -5 | 1x | +59.931 | 0 | — |
| 29 | `L1:1 H:1` | [HDTPA]4- | SRD-46 | -4 | 1x | +0.000 | 0 | — |
| 30 | `Mg$+2:1` | Mg2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 31 | `Mg$+2:1` | [Mg]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 32 | `Mg$+2:1 H:-1` | [Mg(OH)]+ | SRD-46 | +1 | 1x | +67.351 | 0 | — |
| 33 | `Mg$+2:1 H:-1` | [Mg4(OH)4]4+ | SRD-46 | +4 | 4x | +216.321 | 0 | — |
| 34 | `Mg$+2:1 L1:1` | [Mg(DTPA)]3- | SRD-46 | -3 | 1x | -55.040 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Ca$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Divalent calcium ion, colourless; DGf=-553.041 |
| 2 | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ca$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Ca2+ vs [Ca]2+) = 0.000 kJ/mol

#### 1.2  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.3  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231 |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.4  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000 |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.5  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820 |
| 2 | [FeOH]2+ | Atlas | +2 | 1x | +91.169 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-230.957 |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240 |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.238 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.6  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+26.2554 |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+) = 14.371 kJ/mol

#### 1.7  Core: `Mg$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Mg2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Magnesic ion, colourless; DGf=-451.872 |
| 2 | [Mg]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Mg$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Mg2+ vs [Mg]2+) = 0.000 kJ/mol

#### 1.8  Core: `Mg$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Mg(OH)]+ | SRD-46 | +1 | 1x | +67.351 | 0 | id=[Mg$+2].[OH].[z+1]; mu_canon=+67.3508 |
| 2 | [Mg4(OH)4]4+ | SRD-46 | +4 | 4x | +216.321 | 0 | id=[Mg$+2]4.[OH]4.[z+4]; mu_canon=+216.3215 |

## 2. Solid / Dissolution Species

8 core groups, 13 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Ca$+0:1` | Ca | Atlas | +0 | 1x | +553.041 | 2 | — |
| 2 | `Ca$+2:1 H:-2` | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | ref |
| 3 | `Ca$+2:1 H:-2` | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | +0.474 |
| 4 | `Ca$+2:1 H:-2` | CaO | Atlas | +0 | 1x | +186.062 | 0 | +55.870 |
| 5 | `Ca$+2:1 H:-4` | CaO2 | Atlas | +0 | 1x | +429.111 | -2 | — |
| 6 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — |
| 7 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +63.178 | 0 | -14.275 |
| 8 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref |
| 9 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | ref |
| 10 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +9.350 |
| 11 | `Fe$+3:1 H:-3` | Fe2O3 | Atlas | +0 | 2x | +140.457 | -2 | -22.386 |
| 12 | `Mg$+0:1` | Mg | Atlas | +0 | 1x | +451.872 | 2 | — |
| 13 | `Mg$+2:1 H:-2` | [Mg(OH)2(s,brucite)] | SRD-46 | +0 | 1x | +96.232 | 0 | — |

### Duplicated Groups

#### 2.1  Core: `Ca$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | id=[Ca$+2].[OH]2.[z+0]_(s); mu_canon=+130.1925 |
| 2 | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | ox=+2; Hydrated calcium oxide or hydroxide, whi; DGf=-896.757 |
| 3 | CaO | Atlas | +0 | 1x | +186.062 | 0 | ox=+2; Anhydrous calcium oxide, white, cubic; DGf=-604.170 |

> Δ(Ca(OH)2 vs [Ca(OH)2](s)) = 0.474 kJ/mol

> Δ(CaO vs [Ca(OH)2](s)) = 55.870 kJ/mol

#### 2.2  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +63.178 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-496.139 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534 |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 14.275 kJ/mol

#### 2.3  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[z+0]_(s); mu_canon=+18.2646 |
| 2 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 3 | Fe2O3 | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ(Fe(OH)3 (hydr.) vs [Fe(OH)3](s)) = 9.350 kJ/mol

> Δ(Fe2O3 vs [Fe(OH)3](s)) = 22.386 kJ/mol

## 3. Gas Species

*(No species in this section.)*

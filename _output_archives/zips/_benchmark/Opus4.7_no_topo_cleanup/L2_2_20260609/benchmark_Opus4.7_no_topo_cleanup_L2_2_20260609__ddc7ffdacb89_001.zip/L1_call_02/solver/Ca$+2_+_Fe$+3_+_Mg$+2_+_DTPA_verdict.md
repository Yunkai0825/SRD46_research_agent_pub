# Speciation Calculation Report: Ca$+2 + Fe$+3 + Mg$+2 + DTPA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.027007 – 0.0272759 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 7.0 – 9.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Fe$+0 | Fe(s) | 0.00e+00 | metal |
| Fe$+2 | Fe2+ | 0.00e+00 | metal |
| Fe$+3 | Fe3+ | 1.00e-03 | metal |
| Fe$+6 | Fe(+6) | 0.00e+00 | metal |
| Mg$+0 | Mg(s) | 0.00e+00 | metal |
| Mg$+2 | Mg2+ | 1.00e-03 | metal |
| L1 | DTPA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HDTPA4- | aqueous | L1:+1 H:+1 | — | -59.9308 | +0.0000 |
| DTPA | aqueous | L1:+1 | — | -0.0000 | +59.9308 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(DTPA)]3- | aqueous | L1:+1 Ca$+2:+1 | — | -61.3577 | -61.3577 |
| Fe2+ | aqueous | Fe$+2:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]+ | aqueous | Fe$+2:+1 H:-1 | — | +55.9354 | +55.9354 |
| [Fe(OH)2] | aqueous | Fe$+2:+1 H:-2 | — | +202.6231 | +202.6231 |
| [Fe(OH)3]- | aqueous | Fe$+2:+1 H:-3 | — | +165.5231 | +165.5231 |
| [Fe(OH)4]2- | aqueous | Fe$+2:+1 H:-4 | — | +262.5538 | +262.5538 |
| [Fe(DTPA)H]2- | aqueous | L1:+1 Fe$+2:+1 H:+1 | — | -122.7154 | -122.7154 |
| [Fe2(DTPA)]- | aqueous | L1:+1 Fe$+2:+2 | — | -109.4735 | -109.4735 |
| [Fe(DTPA)]3- | aqueous | L1:+1 Fe$+2:+1 | — | -92.4646 | -92.4646 |
| Fe3+ | aqueous | Fe$+3:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]2+ | aqueous | Fe$+3:+1 H:-1 | — | +15.5820 | +15.5820 |
| [Fe2(OH)2]4+ | aqueous | Fe$+3:+2 H:-2 | — | +16.3240 | +16.3240 |
| [Fe(OH)2]+ | aqueous | Fe$+3:+1 H:-2 | — | +40.6266 | +40.6266 |
| [Fe3(OH)4]5+ | aqueous | Fe$+3:+3 H:-4 | — | +35.9585 | +35.9585 |
| [Fe(OH)4]- | aqueous | Fe$+3:+1 H:-4 | — | +123.2861 | +123.2861 |
| [Fe(DTPA)H]- | aqueous | L1:+1 Fe$+3:+1 H:+1 | — | -180.1348 | -180.1348 |
| [Fe(DTPA)]2- | aqueous | L1:+1 Fe$+3:+1 | — | -159.8154 | -159.8154 |
| FeO42- | aqueous | Fe$+6:+1 H:-8 | — | +0.0000 | +0.0000 |
| Mg2+ | aqueous | Mg$+2:+1 | — | -0.0000 | +0.0000 |
| [Mg(OH)]+ | aqueous | Mg$+2:+1 H:-1 | — | +67.3508 | +67.3508 |
| [Mg4(OH)4]4+ | aqueous | Mg$+2:+4 H:-4 | — | +216.3215 | +216.3215 |
| [Mg(DTPA)]3- | aqueous | Mg$+2:+1 L1:+1 | — | -55.0398 | -55.0398 |
| CaO | dissolution | Ca$+2:+1 H:-2 | — | +186.0625 | +186.0625 |
| CaO2 | dissolution | Ca$+2:+1 H:-4 | — | +429.1110 | +429.1110 |
| Ca | dissolution | Ca$+0:+1 | — | +0.0000 | +0.0000 |
| [Fe(OH)2](s) | dissolution | Fe$+2:+1 H:-2 | — | +77.4534 | +77.4534 |
| [Fe(OH)3](s) | dissolution | Fe$+3:+1 H:-3 | — | +18.2646 | +18.2646 |
| Fe | dissolution | Fe$+0:+1 | — | +0.0000 | +0.0000 |
| [Mg(OH)2(s,brucite)] | dissolution | Mg$+2:+1 H:-2 | — | +96.2317 | +96.2317 |
| Mg | dissolution | Mg$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Ca(DTPA)]3-        peak 100.0% at pH 9.0

Dominant species by pH region:
  pH   7.0–  9.0  →  [Ca(DTPA)]3-

Crossover pH values:

=== Fe(s) (Fe$+0) speciation ===
[Fe$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe2+ (Fe$+2) speciation ===
[Fe$+2]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe3+ (Fe$+3) speciation ===
[Fe$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Fe(DTPA)]2-        peak 100.0% at pH 9.0

Dominant species by pH region:
  pH   7.0–  9.0  →  [Fe(DTPA)]2-

Crossover pH values:

=== Fe(+6) (Fe$+6) speciation ===
[Fe$+6]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg(s) (Mg$+0) speciation ===
[Mg$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg2+ (Mg$+2) speciation ===
[Mg$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Mg(DTPA)]3-        peak 100.0% at pH 9.0

Dominant species by pH region:
  pH   7.0–  9.0  →  [Mg(DTPA)]3-

Crossover pH values:

=== DTPA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HDTPA4-             peak 40.0% at pH 7.0
  [Ca(DTPA)]3-        peak 20.0% at pH 9.0
  [Fe(DTPA)]2-        peak 20.0% at pH 9.0
  [Mg(DTPA)]3-        peak 20.0% at pH 9.0

Dominant species by pH region:
  pH   7.0–  9.0  →  HDTPA4-

```
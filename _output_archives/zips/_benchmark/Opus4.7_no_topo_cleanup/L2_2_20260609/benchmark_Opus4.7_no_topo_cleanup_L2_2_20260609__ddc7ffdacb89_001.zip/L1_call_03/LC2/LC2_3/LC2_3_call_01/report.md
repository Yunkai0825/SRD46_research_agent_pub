# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_2_FeCaMg_sequestrant_survey\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    119.57
- elapsed_s (total):  119.58
- llm_iterations:     38
- llm_tool_calls:     22

- n_groups:           30
- n_multi_groups:     11
- n_singletons:       19
- n_decisions:        30
- n_dropped:          9
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | True duplicate; same charge/phase/nuclearity, prefer SRD-46. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | True duplicate of aqueous Fe2+ ion; prefer SRD-46 source per dedup rule 1. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | [HFeO2]- is the dehydrated notation of [Fe(OH)3]- (same Fe(III) hydroxo anion, charge -1, mononuclear); keep SRD-46 entry. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | True duplicate notation of Fe3+; keep SRD-46 version per preference rule. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | [Fe(OH)]2+ and [FeOH]2+ are the same mononuclear species in different notation; keep SRD-46. [Fe2(OH)2]4+ is distinct dinuclear chemistry. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate: same charge, phase, and nuclearity in both sources; prefer SRD-46 critically-evaluated value. |
| aqueous | `Mg$+2:1` | `[Mg]2+` | True duplicate of Mg2+ aqueous ion; prefer SRD-46 source. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+`, `[Mg4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear) and different charges; keep both. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)`, `CaO` | Ca(OH)2 duplicated across SRD-46 and Atlas; kept SRD-46 version. CaO is distinct chemistry, retained. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | Both entries are neutral mononuclear Fe(OH)2 solids; treated as notation/polymorph duplicates and SRD-46 preferred per default plan. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)`, `Fe2O3` | Fe(OH)3 hydr. from Atlas is a notational duplicate of SRD-46 [Fe(OH)3](s) (same phase/charge/nuclearity); Fe2O3 is a distinct polynuclear oxide kept separately. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+3:3 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Fe$+6:1 H:-8` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (0.000 is reference); sole member of group. |
| aqueous | `Mg$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Ca$+0:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Fe$+0:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Mg$+0:1` | yes | Valid mu_aligned_kJ; sole member of group. |
| solid | `Mg$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (True duplicate; same charge/phase/nuclearity, prefer SRD-46.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Fe2+ ion; prefer SRD-46 source per dedup rule 1.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded ([HFeO2]- is the dehydrated notation of [Fe(OH)3]- (same Fe(III) hydroxo anion, charge -1, mononuclear); keep SRD-46 entry.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (True duplicate notation of Fe3+; keep SRD-46 version per preference rule.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded ([Fe(OH)]2+ and [FeOH]2+ are the same mononuclear species in different notation; keep SRD-46. [Fe2(OH)2]4+ is distinct dinuclear chemistry.) |
| `Mg2+` | Atlas | aqueous | dedup: excluded (True duplicate of Mg2+ aqueous ion; prefer SRD-46 source.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (Ca(OH)2 duplicated across SRD-46 and Atlas; kept SRD-46 version. CaO is distinct chemistry, retained.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (Both entries are neutral mononuclear Fe(OH)2 solids; treated as notation/polymorph duplicates and SRD-46 preferred per default plan.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (Fe(OH)3 hydr. from Atlas is a notational duplicate of SRD-46 [Fe(OH)3](s) (same phase/charge/nuclearity); Fe2O3 is a distinct polynuclear oxide kept separately.) |

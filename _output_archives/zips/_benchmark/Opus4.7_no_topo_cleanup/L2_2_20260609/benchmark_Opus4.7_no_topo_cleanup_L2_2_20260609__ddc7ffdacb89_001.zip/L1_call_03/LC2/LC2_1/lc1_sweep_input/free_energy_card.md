# Free Energy Analysis Card

**System**: H, Fe, Ca, Mg / HEDTA, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+, [Ca]2+, [Mg]2+
**Ligands**: [HEDTA]
**Generated**: 2026-06-09 18:09:36 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| M3 | Metal component: [Ca]2+ |
| M4 | Metal component: [Mg]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [HEDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | 0.001 | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | 0.001 | NIST SRD-46 | metal_62 |
| M3 | [Ca]2+ | +2 | 0.001 | NIST SRD-46 | metal_25 |
| M4 | [Mg]2+ | +2 | 0.001 | NIST SRD-46 | metal_92 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [HEDTA] | -3 | 0.01 | [[H]3[L1]] | NIST SRD-46 | ligand_6275 | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M3 | [Ca]2+ | +2 | true | 1 |
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |
| Mg | M4 | [Mg]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, -1, 3, 3, 3] | true |
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| M3 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| M4 | [Mg]2+ | metal | [Mg]2+(aq) | +0.0000 | R1 | Mg | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [HEDTA] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [HEDTA] | [L1] -> [[H]3[L1]] | 3 | 1 | +9.7000 | +55.3646 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [HEDTA] | 25.0 | 1 | *** | 4 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + [HEDTA] | 25.0 | 0.1 | 4876 | 4 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + [HEDTA] | 25.0 | 0.1 | 4867 | 2 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Ca]2+ + [HEDTA] | 25.0 | 0.1 | 4820 | 1 |
| [Ca]2+ + *** | 25.0 | 0~0.1 | *** | 2 |
| [Mg]2+ + [HEDTA] | 25.0 | 0.1 | 4819 | 1 |
| [Mg]2+ + *** | 25.0 | 3 | *** | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [HEDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z-2] | [HHEDTA]2- | -2 | aqueous | +9.7000 | -55.3646 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_107952 | *** |
| [L1].[z-3] | [HEDTA] | -3 | aqueous | +0.0000 | -0.0000 | +55.3646 | +55.3646 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]3+ + [HEDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1].[z+0] | [Fe(HEDT)] | +0 | aqueous | +19.7000 | -112.4415 | -112.4415 | -112.4415 | [M1]:+1, [L1]:+1 | vlm_108138 | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [M1]:+1, [OH]:+2 | vlm_170807 | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Fe]2+ + [HEDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1].[z-1] | [Fe(HEDT)]- | -1 | aqueous | +12.2000 | -69.6338 | -69.6338 | -69.6338 | [M2]:+1, [L1]:+1 | vlm_108112 | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -35.5000 | +202.6231 | +202.6231 | +202.6231 | [M2]:+1, [OH]:+2 | vlm_170677 | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ca]2+ + [HEDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L1].[z-1] | [Ca(HEDT)]- | -1 | aqueous | +8.1000 | -46.2323 | -46.2323 | -46.2323 | [M3]:+1, [L1]:+1 | vlm_107972 | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M3]:+1, [OH]:+1 | vlm_170392 | *** |

#### [Mg]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[z+2] | [Mg]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Mg]2+ + [HEDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[L1].[z-1] | [Mg(HEDT)]- | -1 | aqueous | +7.0000 | -39.9538 | -39.9538 | -39.9538 | [M4]:+1, [L1]:+1 | vlm_107969 | *** |

#### [Mg]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH].[z+1] | [Mg(OH)]+ | +1 | aqueous | -11.4000 | +65.0677 | +65.0677 | +65.0677 | [M4]:+1, [OH]:+1 | vlm_170380 | *** |
| [M4]4.[OH]4.[z+4] | [Mg4(OH)4]4+ | +4 | aqueous | -39.9000 | +227.7369 | +227.7369 | +227.7369 | [M4]:+4, [OH]:+4 | vlm_170386 | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]3.[z+0]_(s) | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | *** |

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M3]:+1, [OH]:+2 | vlm_170397 | *** |

#### [Mg]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Mg(OH)2(s,brucite)] | +0 | dissolution | -16.8600 | +96.2317 | +96.2317 | +96.2317 | [M4]:+1, [OH]:+2 | vlm_170390 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 32 |
| Included in calculation | 32 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 20 |
| Unresolved (no species in card) | 12 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_107960_patched | [<H+><H+EDTA>] + [<H+>] <=> [<H+>2<H+EDTA>] | +5.3800 | 25.0 | 1.000 | yes | — |
| 2 | vlm_107965_patched | [<H+>2<H+EDTA>] + [<H+>] <=> [<H+>3<H+EDTA>] | +2.6200 | 25.0 | 1.000 | yes | — |
| 3 | vlm_107952_patched | [<H+>] + [<H+EDTA>] <=> [<H+><H+EDTA>] | +9.7000 | 25.0 | 1.000 | yes | — |
| 4 | vlm_107968 | [<H+>3<H+EDTA>] + [<H+>] <=> [<H+>4<H+EDTA>] | -1.6000 | 25.0 | 1.000 | yes | — |
| 5 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 6 | vlm_108138 | [<H+EDTA>] + [<Fe3+>] <=> [<Fe3+><H+EDTA>] | +19.7000 | 25.0 | 0.100 | yes | [Fe(HEDT)] |
| 7 | vlm_108139 | [<H+>] + [<Fe3+>(<O<H+>>)<H+EDTA>] <=> [H+2O] + [<Fe3+><H+EDTA>] | +3.8800 | 25.0 | 0.100 | yes | — |
| 8 | vlm_108141 | [<H+>] + [<Fe3+>(<O<H+>>)2<H+EDTA>] <=> [H+2O] + [<Fe3+>(<O<H+>>)<H+EDTA>] | +8.8300 | 25.0 | 0.100 | yes | — |
| 9 | vlm_108143 | [<H+>] + [<Fe3+>(<O<H+>>)3<H+EDTA>] <=> [H+2O] + [<Fe3+>(<O<H+>>)2<H+EDTA>] | +10.0000 | 25.0 | 0.100 | yes | — |
| 10 | vlm_170821 | [<OH+->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH+->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 11 | vlm_170791 | [<OH+->] + [<Fe3+>] <=> [<Fe3+><OH+->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 12 | vlm_170807 | [<OH+->]^2 + [<Fe3+>] <=> [<Fe3+><OH+->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 13 | vlm_170808 | [<OH+->]^4 + [<Fe3+>] <=> [<Fe3+><OH+->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 14 | vlm_170814 | [<OH+->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH+->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 15 | vlm_170825 | [<Fe3+><OH+->3(s)] <=> [<OH+->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 16 | vlm_170827 | [H+2O] + [<Fe3+>OO<H+>(s,alpha)] <=> [<Fe3+>] + [O<H+>]^3 | -41.5000 | 25.0 | 0.000 | yes | — |
| 17 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H+2O] <=> [<Fe3+>] + [O<H+>]^3 | -42.7000 | 25.0 | 0.000 | yes | — |
| 18 | vlm_108112 | [<H+EDTA>] + [<Fe2+>] <=> [<Fe2+><H+EDTA>] | +12.2000 | 25.0 | 0.100 | yes | [Fe(HEDT)]- |
| 19 | vlm_108115 | [<H+><H+EDTA>] + [<Fe2+>] <=> [<Fe2+><H+><H+EDTA>] | +5.1200 | 25.0 | 0.100 | yes | — |
| 20 | vlm_170672 | [<OH+->] + [<Fe2+>] <=> [<Fe2+><OH+->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 21 | vlm_170677 | [<OH+->]^2 + [<Fe2+>] <=> [<Fe2+><OH+->2] | -7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 22 | vlm_170680 | [<OH+->]^3 + [<Fe2+>] <=> [<Fe2+><OH+->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 23 | vlm_170683 | [<OH+->]^4 + [<Fe2+>] <=> [<Fe2+><OH+->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 24 | vlm_170684 | [<Fe2+><OH+->2(s)] <=> [<OH+->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 25 | vlm_107972 | [<H+EDTA>] + [<Ca2+>] <=> [<Ca2+><H+EDTA>] | +8.1000 | 25.0 | 0.100 | yes | [Ca(HEDT)]- |
| 26 | vlm_170392 | [<OH+->] + [<Ca2+>] <=> [<Ca2+><OH+->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 27 | vlm_170397 | [<Ca2+><OH+->2(s)] <=> [<OH+->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |
| 28 | vlm_107969 | [<H+EDTA>] + [<Mg2+>] <=> [<Mg2+><H+EDTA>] | +7.0000 | 25.0 | 0.100 | yes | [Mg(HEDT)]- |
| 29 | vlm_170385 | [<Mg2+><OH+->] + [<Mg2+>] <=> [<Mg2+>2<OH+->] | -0.3000 | 25.0 | 3.000 | yes | — |
| 30 | vlm_170386 | [<OH+->]^4 + [<Mg2+>]^4 <=> [<Mg2+>4<OH+->4] | +16.1000 | 25.0 | 3.000 | yes | [Mg4(OH)4]4+ |
| 31 | vlm_170380_patched | [<OH+->] + [<Mg2+>] <=> [<Mg2+><OH+->] | +2.6000 | 25.0 | 3.000 | yes | — |
| 32 | vlm_170390 | [<Mg2+><OH+->2(s,brucite)] <=> [<OH+->]^2 + [<Mg2+>] | -11.1400 | 25.0 | 3.000 | yes | [Mg(OH)2(s,brucite)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

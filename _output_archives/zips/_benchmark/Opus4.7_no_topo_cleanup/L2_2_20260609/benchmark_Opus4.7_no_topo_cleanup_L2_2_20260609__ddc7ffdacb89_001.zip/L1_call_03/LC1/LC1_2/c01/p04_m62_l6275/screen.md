# Eq-map screen — m62_l6275

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand6275_beta812_net4867` | `[M] + [L] <=> [ML]` | vlm_108112@(25.0,0.1) = K+12.200 | 1 | +12.200 / +12.200 / +12.200 / +12.200 | vlm_108112@(25.0,0.1) = K+12.200 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal62_ligand6275_beta786_net4867` | `[M] + [HL] <=> [MHL]` | vlm_108115@(25.0,0.1) = K+5.120 | 1 | +5.120 / +5.120 / +5.120 / +5.120 | vlm_108115@(25.0,0.1) = K+5.120 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

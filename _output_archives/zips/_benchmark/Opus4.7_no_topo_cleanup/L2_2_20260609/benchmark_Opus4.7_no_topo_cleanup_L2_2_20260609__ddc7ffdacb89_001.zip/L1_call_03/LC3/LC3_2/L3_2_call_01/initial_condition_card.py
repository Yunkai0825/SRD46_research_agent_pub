inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Fe3", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known"},
  {"id": "Fe2", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0,  "basis": "assumed"},
  {"id": "Fe6", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0,  "basis": "assumed"},
  {"id": "Ca", "lhs": lambda s: s.total["Ca$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Mg", "lhs": lambda s: s.total["Mg$+2"], "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_6275"], "value": 5e-3, "basis": "known"},
]
# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Find a sequestrant that holds Fe(III) in solution at pH 7-9 while binding Ca(II) and Mg(II) as weakly as possible (a water-treatment scale/iron control scenario, I=0.1 m). Survey SRD-46 ligands with d' |
|  21.986 | L1_start | call=1; purpose='Evaluate EDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.' |
| 298.295 | L1_end | call=1; elapsed_s=276.3; ran_ok=True; attempts=1 |
| 298.308 | L1_start | call=2; purpose='Evaluate DTPA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.' |
| 723.869 | L1_end | call=2; elapsed_s=425.6; ran_ok=True; attempts=1 |
| 723.895 | L1_start | call=3; purpose='Evaluate HEDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.' |
| 1096.255 | L1_end | call=3; elapsed_s=372.4; ran_ok=True; attempts=1 |
| 1096.267 | L1_start | call=4; purpose='Evaluate citrate as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) for water-treatment scale/iron control.' |
| 1472.112 | L1_end | call=4; elapsed_s=375.8; ran_ok=True; attempts=1 |
| 1728.073 | L0_end | elapsed_s=1728.0595910549164; iterations=7; timed_out=False |

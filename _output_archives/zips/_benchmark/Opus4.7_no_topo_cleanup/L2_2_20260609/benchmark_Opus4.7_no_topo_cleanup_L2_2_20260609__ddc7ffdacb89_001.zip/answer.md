## Answer

**Recommendation: EDTA is the best of the four ligands surveyed, but the brutal truth is that no SRD-46 aminopolycarboxylate is genuinely "selective" for Fe(III) over Ca/Mg in this regime — at 5 mM ligand vs 1 mM each of three divalent/trivalent metals, every Fe(III)-strong chelator also fully sequesters Ca and Mg.** The choice therefore comes down to which ligand (a) actually keeps Fe(III) dissolved and (b) binds the alkaline earths least strongly so that they are most easily out-competed if you ever reduce the ligand dose.

**HEDTA and citrate are eliminated outright** because they fail requirement (a): in both pots at pH 7–9 the dominant Fe(III) species is a solid, not a soluble complex. With HEDTA, Fe(III) precipitates as **Fe₂O₃(s) at >99.99 % of total Fe** across the entire 7–9 window — the Fe(III)–HEDTA complex is not stable enough above pH 7 to out-compete hematite formation, and the ligand instead goes to work on Ca and Mg (which it binds essentially quantitatively as [Ca(HEDT)]⁻ and [Mg(HEDT)]⁻). With citrate the situation is even worse: Fe(III) precipitates as **Fe(OH)₃(s) at >99.999 %** of total iron. Citrate's Fe(III) affinity (log β ~ 11–12) simply cannot beat the Fe(III) hydrolysis ladder at neutral/alkaline pH, while citrate still partly binds Ca (≈86 % [Ca(Citr)]⁻ at pH 7, with some Ca₃(Cit)₂(s) precipitation) and ~89 % of Mg as [Mg(Citr)]⁻ — the worst of both worlds.

**EDTA and DTPA both succeed at (a) but fail at (b).** Both keep Fe(III) >99.96 % in solution across pH 7–9 as a single mononuclear complex ([Fe(EDTA)]⁻ or [Fe(DTPA)]²⁻). However, both also bind Ca(II) at ≥99.99 % and Mg(II) at ≥99.7–99.9 % as [M(L)]ⁿ⁻ throughout the same pH window. There is no "selectivity gap" at this ligand:metal stoichiometry — the ligand is in roughly 5:3 excess over total metal, so every metal that has any meaningful affinity simply gets a chelate.

Within that constraint, **EDTA wins on three grounds**: (i) DTPA's Mg complex is slightly stronger (Mg-DTPA log K ≈ 9.0 vs Mg-EDTA log K ≈ 8.7) and its Ca complex is comparable-to-marginally-stronger, meaning EDTA gives up Ca/Mg fractionally more easily if you ever titrate ligand down; (ii) EDTA's Fe(III) complex is already overwhelmingly dominant (1.0000 fraction at every grid point), so the extra strength of Fe(III)-DTPA (log K ≈ 28 vs 25) buys you nothing operationally in this scenario; and (iii) EDTA is cheaper, more biodegradable, and lower MW per mole of binding site, so for water-treatment economics it is the rational pick.

**Practical implication for the user's scenario:** if the goal is truly *selective* iron control without scavenging hardness, no SRD-46 ligand in this set delivers it at 5 mM dose. To exploit the (small) thermodynamic preference for Fe(III), the operational lever is **ligand dose, not ligand identity**: drop EDTA toward stoichiometric for Fe (i.e. ~1.1–1.5 × [Fe], not 5 ×). At sub-Ca/Mg stoichiometry, EDTA will preferentially bind Fe(III) because its conditional log K for Fe(III) is ~14–15 orders of magnitude larger than for Ca/Mg, and the alkaline earths will largely remain free Ca²⁺/Mg²⁺ in solution.

## Evidence

- **EDTA, Fe(III) speciation (pH 7–9):** `[Fe(EDTA)]⁻ = 1.000000` at every grid point (envelope CSV, L1_call_01).
- **EDTA, Ca(II) (pH 7):** `[Ca(EDTA)]²⁻ = 0.999965` — ~100 % bound.
- **EDTA, Mg(II) (pH 7):** `[Mg(EDTA)]²⁻ = 0.996505`, rising to 0.99752 by pH 7.15.
- **DTPA, Fe(III) (pH 7):** `[Fe(DTPA)]²⁻ = 0.999637`, rising to 0.99981 by pH 7.275.
- **DTPA, Ca(II) (pH 7):** `[Ca(DTPA)]³⁻ = 0.999972`.
- **DTPA, Mg(II) (pH 7):** `[Mg(DTPA)]³⁻ = 0.999152`, i.e. *more* Mg bound than EDTA at every pH.
- **HEDTA, Fe(III) (pH 7–9):** dominant species is **Fe₂O₃(s) at 0.999943** → Fe(III) precipitates, not chelated. Ca and Mg still fully bound as [Ca(HEDT)]⁻ (0.99868) and [Mg(HEDT)]⁻ (0.98363).
- **Citrate, Fe(III) (pH 7–9):** dominant species is **Fe(OH)₃(s) at 0.999995** → Fe(III) precipitates. Ca distributed as 86.4 % [Ca(Citr)]⁻ + 3.7 % Ca₃(Citric acid)₂(s) + 9.9 % free Ca²⁺ at pH 7; Mg is 89.2 % [Mg(Citr)]⁻.

## Artifacts

- **EDTA (recommended):**
  - `L1_call_01/solver/Ca$+2_+_Fe$+2_+_Fe$+3_+_Mg$+2_+_EDTA_frac_Fe.png`
  - `L1_call_01/solver/Ca$+2_+_Fe$+2_+_Fe$+3_+_Mg$+2_+_EDTA_frac_Ca.png`
  - `L1_call_01/solver/Ca$+2_+_Fe$+2_+_Fe$+3_+_Mg$+2_+_EDTA_frac_Mg.png`
  - `L1_call_01/solver/Ca$+2_+_Fe$+2_+_Fe$+3_+_Mg$+2_+_EDTA_envelope_*.csv`
  - `L1_call_01/solver/Ca$+2_+_Fe$+2_+_Fe$+3_+_Mg$+2_+_EDTA_verdict.md`
- **DTPA (close runner-up, slightly less selective):**
  - `L1_call_02/solver/Ca$+2_+_Fe$+3_+_Mg$+2_+_DTPA_frac_*.png` and `*_envelope_*.csv`
- **HEDTA (rejected — Fe₂O₃(s) precipitates):**
  - `L1_call_03/solver/Ca$+2_+_Fe$+3_+_Mg$+2_+_HEDTA_envelope_Fe$+3.csv`
  - `L1_call_03/solver/Ca$+2_+_Fe$+3_+_Mg$+2_+_HEDTA_frac_Fe.png`
- **Citrate (rejected — Fe(OH)₃(s) precipitates):**
  - `L1_call_04/solver/Ca$+2_+_Fe$+3_+_Mg$+2_+_Citric_acid_envelope_Fe$+3.csv`
  - `L1_call_04/solver/Ca$+2_+_Fe$+3_+_Mg$+2_+_Citric_acid_frac_Fe.png`
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature, "value": 523.15, "basis": "known", "note": "250 C hydrothermal"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "1 mM Fe(III) feed"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "1 mM Cu(II) feed"},
  {"id": "Citr", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "5 mM citrate"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M chloride"},
]
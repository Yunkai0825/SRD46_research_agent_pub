# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_2_FeCu_citrate_chloride_hot_out_of_envelope\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.45
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 5 pin(s) (5 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 523.15, "basis": "known"},  # 250 C hydrothermal
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) feed
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) feed
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM citrate
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride
]
```

## Notes
T fixed at 250 C; metal/ligand totals from task. pH and E_V are Pourbaix axes (not pinned). Ionic strength left to the solver (auto) since the task does not specify a fixed I; 0.1 M chloride dominates the background but other species contribute.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "auto"
}
```
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_2_FeCu_citrate_chloride_hot_out_of_envelope\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.98
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Joint Fe-Cu Pourbaix/dominance map over pH-E at fixed T,P -> standard 2-D predominance diagram.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_2_FeCu_citrate_chloride_hot_out_of_envelope\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_2_FeCu_citrate_chloride_hot_out_of_envelope\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_2_FeCu_citrate_chloride_hot_out_of_envelope\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    115.35
- elapsed_s (total):  115.38
- llm_iterations:     38
- llm_tool_calls:     25

- n_groups:           42
- n_multi_groups:     12
- n_singletons:       30
- n_decisions:        42
- n_dropped:          10
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of monovalent aqueous Cu+; prefer SRD-46 per plan rule 1. |
| aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2+`, `[Cu(Chlo)2]+` | Distinct nuclearity and charge (dinuclear 2+ vs mononuclear 1+) — keep both per rule 2. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | Identical Cu2+ aqueous ion in both sources with equal mu; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Distinct nuclearity and charge (mononuclear +1 vs dinuclear +2); both retained per rule 2. |
| aqueous | `Fe$+2:1` | `[Fe]2+` | Identical Fe2+ aqueous ion in both sources with equal mu; keep SRD-46 per plan rule 1. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | [Fe(OH)3]- and [HFeO2]- are notational variants of the same Fe(II) hydroxo-anion; keep SRD-46 entry. |
| aqueous | `Fe$+3:1` | `[Fe]3+` | Identical Fe3+ aqueous species with same mu; prefer SRD-46 entry. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+`, `[Fe2(OH)2]4+` | Dropped Atlas [FeOH]2+ as true duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity); kept distinct dinuclear [Fe2(OH)2]4+. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | True duplicate; kept SRD-46 over Atlas per plan. |
| solid | `Cu$+2:1 H:-2` | `CuO` | At 250 C hydrothermal conditions, prefer anhydrous tenorite (CuO) over hydrated Cu(OH)2 polymorphs per addendum. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | True duplicate Fe(OH)2 solid; prefer SRD-46 per dedup rule 1. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)`, `Fe2O3` | SRD-46 Fe(OH)3 supersedes Atlas hydrated duplicate (lower mu); Fe2O3 hematite kept as distinct anhydrous oxide preferred at 250 C hydrothermal conditions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/reference species with valid mu_aligned_kJ. |
| aqueous | `Cu$+1:1 L2:1` | yes | Unique Cu(I)-chloride complex with valid thermodynamics. |
| aqueous | `Cu$+1:1 L2:3` | yes | Unique Cu(I)-trichloride complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-2` | yes | Unique Cu(II) hydroxide complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-3` | yes | Unique cuprite hydroxo anion with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-4` | yes | Unique cuprate dianion with valid thermodynamics. |
| aqueous | `Cu$+2:1 L1:1` | yes | Unique Cu(II)-citrate dimer complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Unique Cu(II)-citrate hydroxo complex with valid thermodynamics. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Unique binuclear Cu(II)-citrate hydroxo complex with valid thermodynamics. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Unique binuclear Cu(II)-dicitrate hydroxo complex with valid thermodynamics. |
| aqueous | `Cu$+2:3 H:-4` | yes | Unique trinuclear Cu(II) hydroxo complex with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-1` | yes | Unique Fe(II) hydroxo cation with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-2` | yes | Unique neutral Fe(II) dihydroxide with valid thermodynamics. |
| aqueous | `Fe$+2:1 H:-4` | yes | Unique Fe(II) tetrahydroxo anion with valid thermodynamics. |
| aqueous | `Fe$+2:1 L1:1` | yes | Unique Fe(II)-citrate complex with valid thermodynamics. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Unique binuclear Fe(II)-citrate hydroxo complex with valid thermodynamics. |
| aqueous | `Fe$+2:1 L2:1` | yes | Unique Fe(II)-chloride complex with valid thermodynamics. |
| aqueous | `Fe$+3:1 H:-4` | yes | Unique Fe(III) tetrahydroxo anion with valid thermodynamics. |
| aqueous | `Fe$+3:1 L1:1` | yes | Unique neutral Fe(III)-citrate complex with valid thermodynamics. |
| aqueous | `Fe$+3:1 L2:1` | yes | Unique Fe(III)-chloride complex with valid thermodynamics. |
| aqueous | `Fe$+3:1 L2:2` | yes | Unique Fe(III)-dichloride complex with valid thermodynamics. |
| aqueous | `Fe$+3:3 H:-4` | yes | Unique trinuclear Fe(III) hydroxo complex with valid thermodynamics. |
| aqueous | `Fe$+6:1 H:-8` | yes | Unique ferrate(VI) anion with valid thermodynamics. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate ligand reference with valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated citrate ligand species with valid thermodynamics. |
| aqueous | `L2:1` | yes | Chloride ligand reference species with valid thermodynamics. |
| solid | `Cu$+0:1` | yes | Metallic copper reference solid with valid thermodynamics. |
| solid | `Cu$+1:1 H:-1` | yes | Cuprite (Cu2O) solid with valid thermodynamics. |
| solid | `Cu$+1:1 L2:1` | yes | Nantokite (CuCl) solid with valid thermodynamics. |
| solid | `Fe$+0:1` | yes | Metallic iron reference solid with valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of monovalent aqueous Cu+; prefer SRD-46 per plan rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (Identical Cu2+ aqueous ion in both sources with equal mu; prefer SRD-46 notation.) |
| `Fe2+` | Atlas | aqueous | dedup: excluded (Identical Fe2+ aqueous ion in both sources with equal mu; keep SRD-46 per plan rule 1.) |
| `[HFeO2]-` | Atlas | aqueous | dedup: excluded ([Fe(OH)3]- and [HFeO2]- are notational variants of the same Fe(II) hydroxo-anion; keep SRD-46 entry.) |
| `Fe3+` | Atlas | aqueous | dedup: excluded (Identical Fe3+ aqueous species with same mu; prefer SRD-46 entry.) |
| `[FeOH]2+` | Atlas | aqueous | dedup: excluded (Dropped Atlas [FeOH]2+ as true duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity); kept distinct dinuclear [Fe2(OH)2]4+.) |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | dedup: excluded (At 250 C hydrothermal conditions, prefer anhydrous tenorite (CuO) over hydrated Cu(OH)2 polymorphs per addendum.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (At 250 C hydrothermal conditions, prefer anhydrous tenorite (CuO) over hydrated Cu(OH)2 polymorphs per addendum.) |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | dedup: excluded (True duplicate Fe(OH)2 solid; prefer SRD-46 per dedup rule 1.) |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | dedup: excluded (SRD-46 Fe(OH)3 supersedes Atlas hydrated duplicate (lower mu); Fe2O3 hematite kept as distinct anhydrous oxide preferred at 250 C hydrothermal conditions.) |

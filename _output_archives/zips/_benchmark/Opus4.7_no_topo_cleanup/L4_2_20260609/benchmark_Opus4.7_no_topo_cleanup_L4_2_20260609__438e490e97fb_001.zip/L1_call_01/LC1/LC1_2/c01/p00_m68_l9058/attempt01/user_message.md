[Purpose: Compute the joint Pourbaix/speciation picture for a single hydrothermal solution containing Fe(III) and Cu(II) with citrate and chloride at 250 C and 80 bar, and report how Fe and Cu partition among their complexes.]
[Tasks:
Model one shared pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar over pH 0-14, and report the joint Pourbaix/dominance map plus the speciation envelopes for each metal so we can see how Fe and Cu distribute among their citrate, chloride, hydroxide and oxide/hydroxide forms under these hydrothermal conditions.
]
[Pair: pair_key=`m68_l9058`, metal_id=68, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand9058_beta32_net22067`
[Screen report]
# Eq-map screen — m68_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand9058_beta53_net22067` | `[H2L] + [H] <=> [H3L]` | vlm_157473@(25.0,0.1) = K+2.900 | 8 | +2.780 / +2.845 / +2.875 / +3.128 | vlm_157473@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand9058_beta32_net22067` | `[HL] + [H] <=> [H2L]` | vlm_157459@(25.0,0.1) = K+4.350 | 8 | +4.070 / +4.155 / +4.245 / +4.761 | vlm_157459@(25.0,0.1) = K+4.350 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal68_ligand9058_beta79_net22067` | `[L] + [H] <=> [HL]` | vlm_157439@(25.0,0.1) = K+5.650 | 14 | +5.080 / +5.470 / +5.495 / +6.396 | vlm_157439@(25.0,0.1) = K+5.650 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

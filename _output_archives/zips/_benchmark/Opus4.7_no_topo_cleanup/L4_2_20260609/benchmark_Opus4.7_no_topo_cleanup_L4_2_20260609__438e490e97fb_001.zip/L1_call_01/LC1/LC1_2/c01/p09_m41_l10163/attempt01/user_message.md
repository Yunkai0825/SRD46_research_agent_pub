[Purpose: Compute the joint Pourbaix/speciation picture for a single hydrothermal solution containing Fe(III) and Cu(II) with citrate and chloride at 250 C and 80 bar, and report how Fe and Cu partition among their complexes.]
[Tasks:
Model one shared pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar over pH 0-14, and report the joint Pourbaix/dominance map plus the speciation envelopes for each metal so we can see how Fe and Cu distribute among their citrate, chloride, hydroxide and oxide/hydroxide forms under these hydrothermal conditions.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10163_beta280_net29838`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta280_net29838` | `*` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

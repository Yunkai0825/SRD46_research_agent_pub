# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='In a single solution containing 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate and 0.1 M chloride together at 250 C and 80 bar, build the joint Pourbaix/speciation picture and give the Fe and Cu complex dist' |
|   6.888 | L1_start | call=1; purpose='Compute the joint Pourbaix/speciation picture for a single hydrothermal solution containing Fe(III) and Cu(II) with citrate and chloride at 250 C and 80 bar, and report how Fe and Cu partition among t' |
| 1133.643 | L1_end | call=1; elapsed_s=1126.7; ran_ok=True; attempts=1 |
| 1191.238 | L0_end | elapsed_s=1191.2323429584503; iterations=7; timed_out=False |

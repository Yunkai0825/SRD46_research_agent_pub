# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    189.66
- elapsed_s (total):  189.67
- llm_iterations:     41
- llm_tool_calls:     30

- n_groups:           30
- n_multi_groups:     11
- n_singletons:       19
- n_decisions:        30
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | True duplicate of Ca2+ aqueous ion; prefer SRD-46 notation. |
| aqueous | `Pb$+2:1` | `[Pb]2+` | True duplicate of Pb2+ aqueous cation; keep SRD-46 notation per preference. |
| aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+`, `[Pb4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and charge — distinct species. |
| aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` | Same plumbite anion in different notation (HPbO2- ≡ Pb(OH)3-·-H2O); keep SRD-46 form per Rule 1. |
| aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+`, `[Pb6(OH)8]4+` | Distinct polynuclear species differing in nuclearity (trimer vs hexamer) and charge; both retained per rule 2. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of Zn2+ aqueous cation; keep SRD-46 entry per preference rule. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate: same mononuclear ZnOH+ cation; prefer SRD-46 over Atlas. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same species in different notation (HZnO2- is dehydrated form of Zn(OH)3-); prefer SRD-46. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same zincate species in dehydrated vs hydrated notation; keep SRD-46 hydrated form [Zn(OH)4]2- per source preference and aqueous hydration convention. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | Ca(OH)2 is a true duplicate across sources (keep SRD-46, lower mu); CaO is the anhydrous polymorph dropped per addendum preferring hydrated form. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide); kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid thermodynamics; unique hydrolysis species. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid mu; unique Ca-EDTA complex. |
| aqueous | `L1:1` | yes | Valid mu; unique free EDTA species. |
| aqueous | `L1:1 H:1` | yes | mu=0 is a valid reference value; unique HEDTA3- species. |
| aqueous | `Pb$+2:1 H:-2` | yes | Valid mu; unique Pb(OH)2 aqueous species. |
| aqueous | `Pb$+2:2 H:-1` | yes | Valid mu; unique dimeric Pb hydrolysis species. |
| aqueous | `Pb$+4:1` | yes | Valid mu; unique Pb4+ aquo ion. |
| aqueous | `Pb$+4:1 H:-6` | yes | Valid mu; unique PbO3 2- species. |
| aqueous | `Pb$+4:1 H:-8` | yes | Valid mu; unique PbO4 4- species. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu; unique Zn(OH)2 aqueous species. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu; unique Zn-EDTA complex. |
| solid | `Ca$+0:1` | yes | Valid mu; elemental Ca solid. |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu; unique CaO2 solid. |
| solid | `Pb$+0:1` | yes | Valid mu; elemental Pb solid. |
| solid | `Pb$+2:3 H:-8` | yes | Valid mu; unique Pb3O4 solid. |
| solid | `Pb$+3:1 H:-3` | yes | Valid mu; unique Pb2O3 solid. |
| solid | `Pb$+4:1 H:-4` | yes | Valid mu; unique PbO2 solid. |
| solid | `Zn$+0:1` | yes | Valid mu; elemental Zn solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ca2+ aqueous ion; prefer SRD-46 notation.) |
| `Pb2+` | Atlas | aqueous | dedup: excluded (True duplicate of Pb2+ aqueous cation; keep SRD-46 notation per preference.) |
| `[HPbO2]-` | Atlas | aqueous | dedup: excluded (Same plumbite anion in different notation (HPbO2- ≡ Pb(OH)3-·-H2O); keep SRD-46 form per Rule 1.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of Zn2+ aqueous cation; keep SRD-46 entry per preference rule.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate: same mononuclear ZnOH+ cation; prefer SRD-46 over Atlas.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same species in different notation (HZnO2- is dehydrated form of Zn(OH)3-); prefer SRD-46.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same zincate species in dehydrated vs hydrated notation; keep SRD-46 hydrated form [Zn(OH)4]2- per source preference and aqueous hydration convention.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (Ca(OH)2 is a true duplicate across sources (keep SRD-46, lower mu); CaO is the anhydrous polymorph dropped per addendum preferring hydrated form.) |
| `CaO` | Atlas | dissolution | dedup: excluded (Ca(OH)2 is a true duplicate across sources (keep SRD-46, lower mu); CaO is the anhydrous polymorph dropped per addendum preferring hydrated form.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide); kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide); kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide); kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum (prefer hydrated oxyhydroxide); kept distinct Zn(OH)2 polymorphs and preferred SRD-46 epsilon over Atlas epsilon duplicate.) |

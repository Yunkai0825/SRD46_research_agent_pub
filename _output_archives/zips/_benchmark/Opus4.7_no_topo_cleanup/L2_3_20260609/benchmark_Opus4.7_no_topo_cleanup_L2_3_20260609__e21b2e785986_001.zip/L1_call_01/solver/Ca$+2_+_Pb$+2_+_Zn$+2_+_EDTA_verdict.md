# Speciation Calculation Report: Ca$+2 + Pb$+2 + Zn$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0187705 – 0.0194865 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Pb$+0 | Pb(s) | 0.00e+00 | metal |
| Pb$+2 | Pb2+ | 1.00e-03 | metal |
| Pb$+3 | Pb(+3) | 0.00e+00 | metal |
| Pb$+4 | Pb(+4) | 0.00e+00 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +0.0000 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +58.1614 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(EDTA)]2- | aqueous | L1:+1 Ca$+2:+1 | — | -60.7869 | -60.7869 |
| Pb2+ | aqueous | Pb$+2:+1 | — | -0.0000 | +0.0000 |
| [Pb2(OH)]3+ | aqueous | H:-1 Pb$+2:+2 | — | +36.5292 | +36.5292 |
| [Pb(OH)]+ | aqueous | H:-1 Pb$+2:+1 | — | +45.6615 | +45.6615 |
| [Pb(OH)2] | aqueous | H:-2 Pb$+2:+1 | — | +97.6015 | +97.6015 |
| [Pb(OH)3]- | aqueous | H:-3 Pb$+2:+1 | — | +160.3861 | +160.3861 |
| [Pb4(OH)4]4+ | aqueous | H:-4 Pb$+2:+4 | — | +117.0077 | +117.0077 |
| [Pb3(OH)4]2+ | aqueous | H:-4 Pb$+2:+3 | — | +136.4138 | +136.4138 |
| [Pb6(OH)8]4+ | aqueous | H:-8 Pb$+2:+6 | — | +248.8554 | +248.8554 |
| Pb4+ | aqueous | Pb$+4:+1 | — | +0.0000 | +0.0000 |
| PbO32- | aqueous | H:-6 Pb$+4:+1 | — | +131.5032 | +131.5032 |
| PbO44- | aqueous | H:-8 Pb$+4:+1 | — | +364.1712 | +364.1712 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +90.1815 | +90.1815 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(EDTA)]2- | aqueous | L1:+1 Zn$+2:+1 | — | -89.6108 | -89.6108 |
| [Ca(OH)2](s) | dissolution | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| CaO2 | dissolution | Ca$+2:+1 H:-4 | — | +429.1110 | +429.1110 |
| Ca | dissolution | Ca$+0:+1 | — | +0.0000 | +0.0000 |
| Pb3O4 | dissolution | H:-8 Pb$+2:+3 | — | +406.6430 | +406.6430 |
| Pb2O3 | dissolution | H:-6 Pb$+3:+2 | — | -348.4142 | -348.4142 |
| PbO2 | dissolution | H:-4 Pb$+4:+1 | — | -47.1118 | -47.1118 |
| Pb | dissolution | Pb$+0:+1 | — | +0.0000 | +0.0000 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Ca(EDTA)]2-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Ca(EDTA)]2-

Crossover pH values:

=== Pb(s) (Pb$+0) speciation ===
[Pb$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb2+ (Pb$+2) speciation ===
[Pb$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  Pb2+                peak 98.9% at pH 6.0
  [Pb(OH)]+           peak 10.9% at pH 7.4
  [Pb4(OH)4]4+        peak 17.6% at pH 7.4
  [Pb3(OH)4]2+        peak 22.5% at pH 8.0
  [Pb6(OH)8]4+        peak 53.6% at pH 8.0

Dominant species by pH region:
  pH   6.0–  7.6  →  Pb2+
  pH   7.6–  8.0  →  [Pb6(OH)8]4+

Crossover pH values:
  Pb2+ ↔ [Pb3(OH)4]2+  at pH ≈ 7.71  (each ~19%)
  Pb2+ ↔ [Pb6(OH)8]4+  at pH ≈ 7.57  (each ~28%)
  [Pb(OH)]+ ↔ [Pb4(OH)4]4+  at pH ≈ 7.09  (each ~9%)
  [Pb(OH)]+ ↔ [Pb4(OH)4]4+  at pH ≈ 7.85  (each ~9%)
  [Pb(OH)]+ ↔ [Pb3(OH)4]2+  at pH ≈ 7.35  (each ~11%)
  [Pb(OH)]+ ↔ [Pb6(OH)8]4+  at pH ≈ 7.33  (each ~11%)
  [Pb4(OH)4]4+ ↔ [Pb3(OH)4]2+  at pH ≈ 7.55  (each ~16%)
  [Pb4(OH)4]4+ ↔ [Pb6(OH)8]4+  at pH ≈ 7.43  (each ~18%)
  [Pb3(OH)4]2+ ↔ [Pb6(OH)8]4+  at pH ≈ 7.31  (each ~9%)

=== Pb(+3) (Pb$+3) speciation ===
[Pb$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb(+4) (Pb$+4) speciation ===
[Pb$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  [Zn(EDTA)]2-        peak 100.0% at pH 7.9

Dominant species by pH region:
  pH   6.0–  8.0  →  [Zn(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HEDTA3-             peak 60.0% at pH 6.0
  [Ca(EDTA)]2-        peak 20.0% at pH 8.0
  [Zn(EDTA)]2-        peak 20.0% at pH 7.9

Dominant species by pH region:
  pH   6.0–  8.0  →  HEDTA3-

```
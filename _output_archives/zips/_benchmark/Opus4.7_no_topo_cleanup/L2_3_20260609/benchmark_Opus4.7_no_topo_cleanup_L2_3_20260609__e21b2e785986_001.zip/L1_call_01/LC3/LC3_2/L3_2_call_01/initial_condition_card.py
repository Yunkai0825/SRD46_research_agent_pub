inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,         "value": 298.15, "basis": "known"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,      "value": 0.1,    "basis": "known"},
  {"id": "Ca",   "lhs": lambda s: s.total["Ca$+2"],       "value": 1e-3,   "basis": "known"},
  {"id": "Pb",   "lhs": lambda s: s.total["Pb$+2"],       "value": 1e-3,   "basis": "known"},
  {"id": "Zn",   "lhs": lambda s: s.total["Zn$+2"],       "value": 1e-3,   "basis": "known"},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3,   "basis": "known"},
]
[Purpose: Speciation of Pb(II)/Zn(II)/Ca(II) competition with EDTA for lead-decorporation selectivity assessment.]
[Tasks:
Model a single aqueous pot containing Pb(II), Zn(II) and Ca(II) at 1 mM each together with EDTA at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 m. Report the equilibrium free [Pb2+], [Zn2+] and [Ca2+] (uncomplexed aquo-ion) concentrations across the pH range and the dominant species for each metal, so I can evaluate selectivity of EDTA for Pb over Zn and Ca.
]
[Pair: pair_key=`m125_l6277`, metal_id=125, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal125_ligand6277_beta739_net5071`
  - `metal125_ligand6277_beta751_net5071`
  - `metal125_ligand6277_beta788_net5071`
[Screen report]
# Eq-map screen — m125_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand6277_beta739_net5071` | `[MHL] + [H] <=> [MH2L]` | vlm_108768@(25.0,1.0) = K-1.700 | 1 | -1.700 / -1.700 / -1.700 / -1.700 | vlm_108768@(25.0,1.0) = K-1.700 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal125_ligand6277_beta751_net5071` | `[MH2L] + [H] <=> [MH3L]` | vlm_108769@(25.0,1.0) = K-1.200 | 1 | -1.200 / -1.200 / -1.200 / -1.200 | vlm_108769@(25.0,1.0) = K-1.200 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal125_ligand6277_beta788_net5071` | `[ML] + [H] <=> [MHL]` | vlm_108766@(25.0,1.0) = K+2.400 | 3 | +2.400 / +2.800 / +2.667 / +2.800 | vlm_108765@(20.0,0.1) = K+2.800 (-5.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

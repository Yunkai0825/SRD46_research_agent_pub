# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Recommend a chelator for selective Pb(II) removal over Zn(II) and Ca(II) in near-neutral water (pH 6-8, I=0.1 m), as in lead-decorporation chemistry. Survey SRD-46 ligands with stability data for all ' |
|  15.694 | L1_start | call=1; purpose='Speciation of Pb(II)/Zn(II)/Ca(II) competition with EDTA for lead-decorporation selectivity assessment.' |
| 418.674 | L1_end | call=1; elapsed_s=403.0; ran_ok=True; attempts=1 |
| 418.687 | L1_start | call=2; purpose='Speciation of Pb(II)/Zn(II)/Ca(II) competition with DTPA for lead-decorporation selectivity assessment.' |
| 817.186 | L1_end | call=2; elapsed_s=398.5; ran_ok=True; attempts=1 |
| 817.208 | L1_start | call=3; purpose='Speciation of Pb(II)/Zn(II)/Ca(II) competition with D-penicillamine for lead-decorporation selectivity assessment.' |
| 1256.282 | L1_end | call=3; elapsed_s=439.1; ran_ok=True; attempts=1 |
| 1322.856 | L0_end | elapsed_s=1322.8484373092651; iterations=8; timed_out=True |

## Answer

**Recommendation: DTPA (diethylenetriaminepentaacetate) is the best chelator of the three surveyed for selective Pb(II) decorporation in near-neutral water containing Zn(II) and Ca(II).** EDTA is a reasonable second choice but takes Zn² ⁺ along with Pb² ⁺. D‑penicillamine should *not* be used when Zn-sparing is a goal — it is actually more avid for Zn than for Pb in this window.

**Chemical reasoning, candidate by candidate (1 mM each metal, 5 mM ligand, pH 6–8, I = 0.1 m, 25 °C):**

- **DTPA — recommended.** DTPA is an octadentate aminopolycarboxylate (3 N + 5 COO⁻); it wraps every M²⁺ in a single 1:1 cage. At pH 7 the conditional stabilities order it as Pb (log K′ ≈ 18–19) > Zn (≈ 18) ≫ Ca (≈ 10), and the speciation reflects this hierarchy directly: Pb²⁺ is 96.8 % bound as the fully deprotonated `[Pb(DTPA)]³⁻` even at pH 6 (rising to ≈100 % by pH 8), Zn²⁺ shifts from a mixed `[Zn(DTPA)H]²⁻ / [Zn(DTPA)]³⁻` regime at pH 6 (72 % deprotonated) to fully deprotonated by pH 8, and Ca²⁺ sits entirely in `[Ca(DTPA)]³⁻` (≥ 99.95 %). The crucial selectivity metric — free aquo-ion concentration — separates the three by ~7–8 orders of magnitude: at pH 7, [Pb²⁺]_free ≈ 10⁻¹⁵–10⁻¹⁶ M, [Zn²⁺]_free ≈ 10⁻¹³–10⁻¹⁴ M, and [Ca²⁺]_free ≈ 10⁻⁷–10⁻⁸ M. Pb is suppressed ~1–2 orders more deeply than Zn and ~7–8 orders more deeply than Ca, which is exactly the property required of a Pb decorporation agent. This matches clinical practice — Ca‑DTPA / Zn‑DTPA salts are used precisely so that the weakly-bound competitor is pre-saturated, leaving the high-affinity Pb-binding capacity free.

- **EDTA — usable but less selective.** EDTA (hexadentate, 2 N + 4 COO⁻) also drives every metal into its 1:1 chelate (>99.9 % bound across the window for Pb, Zn, and Ca), but its absolute log K’s are smaller (≈18 Pb, 16.5 Zn, 10.7 Ca). The free-ion ordering is the same textbook one — Pb²⁺ ≪ Zn²⁺ ≪ Ca²⁺ — and all three free concentrations fall ~10× per pH unit as HY³⁻ → Y⁴⁻ deprotonates. The problem is that EDTA does not just *prefer* Pb; with ligand in excess it strips essentially every Zn²⁺ and every Ca²⁺ as well into [M(EDTA)]²⁻. Thermodynamic Pb selectivity therefore manifests only in how *deeply* free Pb²⁺ is suppressed, not in *whether* Zn and Ca are bound — which is the well-known clinical limitation of Na₂EDTA / CaNa₂EDTA therapy (Zn depletion, need for Ca pre-loading).

- **D‑penicillamine — anti-selective.** Penicillamine (a hard/soft tridentate S⁻/NH₂/COO⁻ ligand) binds Pb²⁺ as `[Pb(Peni)]` (mono-chelate, 99.8% → 86% across pH 6→8) but binds Zn²⁺ as the *bis*-chelate `[Zn(Peni)₂]²⁻` from the start (>99.99 % across the whole window). The soft thiolate dominates the binding for both metals, but because Zn forms a 2:1 complex from pH 6 onward while Pb only begins to add the second penicillamine above pH 7, free [Zn²⁺] is driven roughly **two orders of magnitude lower than free [Pb²⁺]** at every pH in the window (≈ 2 × 10⁻¹⁰ M Zn vs ≈ 10⁻⁷ M Pb at pH 7). Hard Ca²⁺ has no thiolate affinity and is completely untouched. So penicillamine is excellent at sparing Ca but actively *worsens* Pb-over-Zn selectivity — consistent with the known clinical observation that penicillamine causes zincuria.

**Selectivity ranking (free [Pb²⁺] / free [Zn²⁺] / free [Ca²⁺] near pH 7):**

| Chelator | [Pb²⁺]_free | [Zn²⁺]_free | [Ca²⁺]_free | Pb-over-Zn margin |
|---|---|---|---|---|
| **DTPA** | ~10⁻¹⁵–10⁻¹⁶ M | ~10⁻¹³–10⁻¹⁴ M | ~10⁻⁷–10⁻⁸ M | ~10²× in favour of Pb |
| EDTA | lowest (≈ 10⁻¹⁴ M) | ~10⁻¹² M | ~10⁻⁵ M | ~10²× in favour of Pb but all three are fully bound |
| D-penicillamine | ~10⁻⁷ M | ~10⁻¹⁰ M | ~10⁻³ M (untouched) | ~10²× in favour of *Zn* (anti-selective) |

DTPA wins because it (i) achieves the deepest absolute suppression of free Pb²⁺, (ii) keeps a meaningful Pb-over-Zn preference rather than reversing it, and (iii) when administered as Ca‑DTPA or Zn‑DTPA, exchanges its weakly bound auxiliary metal for Pb without disturbing the much more strongly bound endogenous pools — the chemical basis of its established use as a heavy-metal decorporation agent.

## Evidence

- DTPA, free aquo-ion concentrations at pH 7 from the verbatim L1 report: "[Pb²⁺]_free is the lowest (≈10⁻¹⁵–10⁻¹⁶ M range — Pb is the most tightly held), [Zn²⁺]_free is intermediate (≈10⁻¹³–10⁻¹⁴ M), [Ca²⁺]_free is the highest (≈10⁻⁷–10⁻⁸ M)."
- DTPA dominant species: `[Pb(DTPA)]³⁻` 96.8 % at pH 6 → ~100 % at pH 8; `[Zn(DTPA)H]²⁻` 28.5 % at pH 6 dropping to 0 by pH 8 with `[Zn(DTPA)]³⁻` taking over; `[Ca(DTPA)]³⁻` ≥ 99.95 % across the window.
- EDTA: "[Zn(EDTA)]²⁻ at fraction 1.000 across the whole pH 6–8 range … [Ca(EDTA)]²⁻ at fraction 0.9999 across the whole range." Selectivity ordering "Pb²⁺ ≫ Zn²⁺ ≫ Ca²⁺ … set entirely by the M–EDTA log K values" (≈18 Pb, 16.5 Zn, 10.7 Ca). The log_conc CSV confirms log [Ca²⁺]_free ≈ −7.0 at pH 6 (about 10⁻⁴ × total), Pb-EDTA and Zn-EDTA log concentrations at −3.0 (≈100 % bound).
- D-penicillamine: Pb envelope `[Pb(Peni)]` 99.8 % → 86 %, `[Pb(Peni)₂]²⁻` rising to 13.9 % at pH 8; Zn envelope `[Zn(Peni)₂]²⁻` ≥ 99.998 %; Ca envelope `Ca²⁺` 100 % (no Ca-penicillamine constants in SRD-46). Free-ion table (pH 7): [Pb²⁺] ≈ 10⁻⁷ M, [Zn²⁺] ≈ 2 × 10⁻¹⁰ M, [Ca²⁺] ≈ 10⁻³ M — Zn driven ~2 orders below Pb.
- All three pipelines converged at every grid point in pH 6–8 with no precipitation flagged.
- Caveat on penicillamine: SRD-46 lacks Ca–penicillamine constants, so its Pb-over-Ca margin is an upper bound; the qualitative conclusion (Ca untouched) still holds because literature log K(Ca-Peni) ≈ 1–2 would still leave Ca <1 % bound.

## Artifacts

- EDTA system:
  - `L1_call_01/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_EDTA_log_conc.csv` — free [M²⁺] vs pH
  - `L1_call_01/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_EDTA_envelope_Pb$+2.csv`, `…_envelope_Zn$+2.csv`, `…_envelope_Ca$+2.csv`
  - `L1_call_01/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_EDTA_frac_Pb.png`, `…_frac_Zn.png`, `…_frac_Ca.png`, `…_log_conc.png`
  - `L1_call_01/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_EDTA_verdict.md`
- DTPA system:
  - `L1_call_02/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_DTPA_log_conc.csv` — free [M²⁺] vs pH (key selectivity file)
  - `L1_call_02/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_DTPA_envelope_Pb$+2.csv`, `…_envelope_Zn$+2.csv`, `…_envelope_Ca$+2.csv`, `…_envelope_L1.csv`
  - `L1_call_02/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_DTPA_frac_Pb.png`, `…_frac_Zn.png`, `…_frac_Ca.png`, `…_log_conc.png`
  - `L1_call_02/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_DTPA_verdict.md`
- D-penicillamine system:
  - `L1_call_03/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_Penicillamine_log_conc.csv`
  - `L1_call_03/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_Penicillamine_envelope_Pb$+2.csv`, `…_envelope_Zn$+2.csv`, `…_envelope_Ca$+2.csv`, `…_envelope_L1.csv`
  - `L1_call_03/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_Penicillamine_frac_Pb.png`, `…_frac_Zn.png`, `…_frac_Ca.png`, `…_frac_L1.png`, `…_log_conc.png`
  - `L1_call_03/solver/Ca$+2_+_Pb$+2_+_Zn$+2_+_Penicillamine_verdict.md`
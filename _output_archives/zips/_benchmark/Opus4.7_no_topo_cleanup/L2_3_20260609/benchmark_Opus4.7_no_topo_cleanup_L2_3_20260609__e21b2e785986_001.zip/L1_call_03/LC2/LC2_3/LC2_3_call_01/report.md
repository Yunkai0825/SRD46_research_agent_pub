# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    103.82
- elapsed_s (total):  103.84
- llm_iterations:     39
- llm_tool_calls:     27

- n_groups:           34
- n_multi_groups:     11
- n_singletons:       23
- n_decisions:        34
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | True duplicate; prefer SRD-46 over Atlas. |
| aqueous | `Pb$+2:1` | `[Pb]2+` | True duplicates of aqueous Pb2+; keep SRD-46 version per preference. |
| aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+`, `[Pb4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite shared core ratio. |
| aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` | [HPbO2]- and [Pb(OH)3]- are the same mononuclear plumbite anion in different notation; keep SRD-46 entry per rule 1. |
| aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+`, `[Pb6(OH)8]4+` | Different nuclearity (trimer vs hexamer) and charge are distinct polynuclear species, both retained per plan rule 2. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | Identical aqueous Zn2+ species; prefer SRD-46 per plan rule 1. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate mononuclear ZnOH+; keep SRD-46 over Atlas per dedup rule 1. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are notational equivalents (differ by one H2O) — same charge, nuclearity, and phase; kept SRD-46 form. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are notational variants of the same zincate ion; keep SRD-46 hydroxo form per plan. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 Ca(OH)2 kept over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated polymorph for aqueous speciation. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 that precipitates from solution; keep distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and prefer SRD-46 epsilon over the Atlas epsilon duplicate per rule 1. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique species. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid mu; unique Ca hydroxo complex. |
| aqueous | `L1:1` | yes | Valid mu; free penicillamine ligand. |
| aqueous | `L1:1 H:1` | yes | Reference species with mu=0; valid. |
| aqueous | `Pb$+2:1 H:-2` | yes | Valid mu; unique Pb hydroxo species. |
| aqueous | `Pb$+2:1 L1:1` | yes | Valid mu; unique Pb-penicillamine complex. |
| aqueous | `Pb$+2:1 L1:2` | yes | Valid mu; unique bis-ligand complex. |
| aqueous | `Pb$+2:1 L1:2 H:2` | yes | Valid mu; unique protonated complex. |
| aqueous | `Pb$+2:2 H:-1` | yes | Valid mu; unique dinuclear Pb hydroxo. |
| aqueous | `Pb$+4:1` | yes | Valid mu; unique Pb(IV) aqua ion. |
| aqueous | `Pb$+4:1 H:-6` | yes | Valid mu; unique plumbate species. |
| aqueous | `Pb$+4:1 H:-8` | yes | Valid mu; unique plumbate species. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu; unique Zn hydroxo species. |
| aqueous | `Zn$+2:1 L1:2` | yes | Valid mu; unique Zn bis-ligand complex. |
| aqueous | `Zn$+2:3 L1:4` | yes | Valid mu; unique trinuclear Zn complex. |
| aqueous | `Zn$+2:3 L1:4 H:4` | yes | Valid mu; unique protonated trinuclear complex. |
| solid | `Ca$+0:1` | yes | Valid mu; Ca metal. |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu; calcium peroxide. |
| solid | `Pb$+0:1` | yes | Valid mu; Pb metal. |
| solid | `Pb$+2:3 H:-8` | yes | Valid mu; Pb3O4 phase. |
| solid | `Pb$+3:1 H:-3` | yes | Valid mu; Pb2O3 phase. |
| solid | `Pb$+4:1 H:-4` | yes | Valid mu; PbO2 phase. |
| solid | `Zn$+0:1` | yes | Valid mu; Zn metal. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (True duplicate; prefer SRD-46 over Atlas.) |
| `Pb2+` | Atlas | aqueous | dedup: excluded (True duplicates of aqueous Pb2+; keep SRD-46 version per preference.) |
| `[HPbO2]-` | Atlas | aqueous | dedup: excluded ([HPbO2]- and [Pb(OH)3]- are the same mononuclear plumbite anion in different notation; keep SRD-46 entry per rule 1.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Zn2+ species; prefer SRD-46 per plan rule 1.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate mononuclear ZnOH+; keep SRD-46 over Atlas per dedup rule 1.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are notational equivalents (differ by one H2O) — same charge, nuclearity, and phase; kept SRD-46 form.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are notational variants of the same zincate ion; keep SRD-46 hydroxo form per plan.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 kept over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated polymorph for aqueous speciation.) |
| `CaO` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 kept over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated polymorph for aqueous speciation.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 that precipitates from solution; keep distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and prefer SRD-46 epsilon over the Atlas epsilon duplicate per rule 1.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 that precipitates from solution; keep distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and prefer SRD-46 epsilon over the Atlas epsilon duplicate per rule 1.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 that precipitates from solution; keep distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and prefer SRD-46 epsilon over the Atlas epsilon duplicate per rule 1.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, drop anhydrous ZnO polymorphs in favor of hydrated Zn(OH)2 that precipitates from solution; keep distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and prefer SRD-46 epsilon over the Atlas epsilon duplicate per rule 1.) |

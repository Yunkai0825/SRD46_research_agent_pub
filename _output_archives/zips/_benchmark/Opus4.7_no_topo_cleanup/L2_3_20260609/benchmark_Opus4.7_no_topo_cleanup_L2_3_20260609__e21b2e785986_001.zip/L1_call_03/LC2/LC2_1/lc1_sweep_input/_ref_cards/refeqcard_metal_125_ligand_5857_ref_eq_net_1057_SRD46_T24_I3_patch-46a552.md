# Free Energy Analysis Card

**System**: metal_125 + ligand_5857
**Metals**: [Pb]2+
**Ligands**: [Penicillamine]
**Generated**: 2026-06-09 18:41:39 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Pb$+2 | Metal component: [Pb]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Penicillamine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Pb$+2 | [Pb]2+ | +2 | 0.001 | NIST SRD-46 | metal_125 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Penicillamine] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5857 | CC(C)(S)[C@H](N)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Pb | Pb$+2 | [Pb]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | C | [-3, -3, 0, 1, 3] | true |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | N | [-3] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | O | [-2, -2] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | S | [-2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Pb$+2 | [Pb]2+ | metal | [Pb]2+(aq) | +0.0000 | R1 | Pb | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Penicillamine] | ligand_canonical | [[H]2[L1]] | +0.0000 | R4 | *** | -2 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Penicillamine] | [L1] -> [[H]2[L1]] | 2 | 0 | +0.0000 | +0.0000 | fallback |  |

### 3.3 Edge Case Notes

- EC-2: No protonation states found for 'Penicillamine' (expected canonical H2L); using free ligand as reference (shift=0) (EC-2).

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Pb]2+ + [Penicillamine] | 25.0 | 3 | 1057 | 6 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Penicillamine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L1].[z-2] | [Penicillamine] | -2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Pb]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Pb$+2].[z+2] | [Pb]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pb$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Pb]2+ + [Penicillamine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Pb$+2].[[H][L1]]2.[z-1] | [Pb(Peni)2H]- | -1 | aqueous | +26.2000 | -149.5415 | -149.5415 | -149.5415 | [Pb$+2]:+1, [[H][L1]]:+2 | vlm_97626_patched, vlm_97631_patched | *** |
| [Pb$+2].[L1]2.[z-2] | [Pb(Peni)2]2- | -2 | aqueous | +17.7000 | -101.0261 | -101.0261 | -101.0261 | [Pb$+2]:+1, [L1]:+2 | vlm_97626_patched | *** |
| [Pb$+2].[L1].[z+0] | [Pb(Peni)] | +0 | aqueous | +13.0900 | -74.7137 | -74.7137 | -74.7137 | [Pb$+2]:+1, [L1]:+1 | vlm_97624_patched | *** |

### 5.2 Dissolution / Solid Species

(No dissolution / solid species species in this system.)

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 6 |
| Included in calculation | 6 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 3 |
| Unresolved (no species in card) | 3 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_97632 | [<H+>] + [<Pb2+><H+><Penicillamine>2] <=> [<Pb2+>(<H+><Penicillamine>)2] | +6.0000 | 25.0 | 3.000 | yes | — |
| 2 | vlm_97634 | [<H+>] + [<Pb2+>(<O<H+>>)<Penicillamine>2] <=> [H+2O] + [<Pb2+><Penicillamine>2] | -11.5000 | 25.0 | 3.000 | yes | — |
| 3 | vlm_97624_patched | [<Penicillamine>] + [<Pb2+>] <=> [<Pb2+><Penicillamine>] | +13.0900 | 25.0 | 3.000 | yes | [Pb(Peni)] |
| 4 | vlm_97626_patched | [<Penicillamine>]^2 + [<Pb2+>] <=> [<Pb2+><Penicillamine>2] | +17.7000 | 25.0 | 3.000 | yes | [Pb(Peni)2]2-, [Pb(Peni)2H]- |
| 5 | vlm_97629_patched | [<H+><Penicillamine>] + [<Pb2+>] <=> [<Pb2+><H+><Penicillamine>] | -5.2100 | 25.0 | 3.000 | yes | — |
| 6 | vlm_97631_patched | [<H+>] + [<Pb2+><Penicillamine>2] <=> [<Pb2+><H+><Penicillamine>2] | +8.5000 | 25.0 | 3.000 | yes | [Pb(Peni)2H]- |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ca$+2 | M3 | [Ca]2+ | Ca | +2 |
| Pb$+2 | M1 | [Pb]2+ | Pb | +2 |
| Zn$+2 | M2 | [Zn]2+ | Zn | +2 |
| Ca$+0 | Atlas | Ca (ox +0) | Ca | +0 |
| Pb$+0 | Atlas | Pb (ox +0) | Pb | +0 |
| Pb$+3 | Atlas | Pb (ox +3) | Pb | +3 |
| Pb$+4 | Atlas | Pb (ox +4) | Pb | +4 |
| Zn$+0 | Atlas | Zn (ox +0) | Zn | +0 |

**Total species**: 53 | **Core groups**: 34 | **Multi-member groups**: 11 | **Cross-source groups**: 9

## 1. Aqueous / Dissolved Species

25 core groups, 34 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Ca$+2:1` | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Ca$+2:1` | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 4 | `Ca$+2:1 H:-1` | [Ca(OH)]+ | SRD-46 | +1 | 1x | +74.428 | 0 | — |
| 5 | `L1:1` | [Penicillamine] | SRD-46 | -2 | 1x | +60.901 | 0 | — |
| 6 | `L1:1 H:1` | [HPenicillamine]- | SRD-46 | -1 | 1x | +0.000 | 0 | — |
| 7 | `Pb$+2:1` | Pb2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 8 | `Pb$+2:1` | [Pb]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 9 | `Pb$+2:1 H:-1` | [Pb(OH)]+ | SRD-46 | +1 | 1x | +45.661 | 0 | — |
| 10 | `Pb$+2:1 H:-1` | [Pb4(OH)4]4+ | SRD-46 | +4 | 4x | +117.008 | 0 | — |
| 11 | `Pb$+2:1 H:-2` | [Pb(OH)2] | SRD-46 | +0 | 1x | +97.602 | 0 | — |
| 12 | `Pb$+2:1 H:-3` | [HPbO2]- | Atlas | -1 | 1x | +159.787 | 0 | -0.599 |
| 13 | `Pb$+2:1 H:-3` | [Pb(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref |
| 14 | `Pb$+2:1 L1:1` | [Pb(Peni)] | SRD-46 | +0 | 1x | -74.714 | 0 | — |
| 15 | `Pb$+2:1 L1:2` | [Pb(Peni)2]2- | SRD-46 | -2 | 1x | -101.026 | 0 | — |
| 16 | `Pb$+2:1 L1:2 H:2` | [Pb(Peni)2H]- | SRD-46 | -1 | 1x | -149.542 | 0 | — |
| 17 | `Pb$+2:2 H:-1` | [Pb2(OH)]3+ | SRD-46 | +3 | 1x | +36.529 | 0 | — |
| 18 | `Pb$+2:3 H:-4` | [Pb3(OH)4]2+ | SRD-46 | +2 | 1x | +136.414 | 0 | — |
| 19 | `Pb$+2:3 H:-4` | [Pb6(OH)8]4+ | SRD-46 | +4 | 2x | +248.855 | 0 | — |
| 20 | `Pb$+4:1` | Pb4+ | Atlas | +4 | 1x | +326.812 | -2 | — |
| 21 | `Pb$+4:1 H:-6` | [PbO3]2- | Atlas | -2 | 1x | +458.315 | -2 | — |
| 22 | `Pb$+4:1 H:-8` | [PbO4]4- | Atlas | -4 | 1x | +690.983 | -2 | — |
| 23 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 24 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 25 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref |
| 26 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 |
| 27 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +90.181 | 0 | — |
| 28 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref |
| 29 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 |
| 30 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 |
| 31 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref |
| 32 | `Zn$+2:1 L1:2` | [Zn(Peni)2]2- | SRD-46 | -2 | 1x | -111.186 | 0 | — |
| 33 | `Zn$+2:3 L1:4` | [Zn3(Peni)4]2- | SRD-46 | -2 | 1x | -236.013 | 0 | — |
| 34 | `Zn$+2:3 L1:4 H:4` | [Zn3(Peni)4H]- | SRD-46 | -1 | 1x | -271.686 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Ca$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Divalent calcium ion, colourless; DGf=-553.041 |
| 2 | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ca$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Ca2+ vs [Ca]2+) = 0.000 kJ/mol

#### 1.2  Core: `Pb$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Pb2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Plumbous ion, colourless; DGf=-24.309 |
| 2 | [Pb]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Pb$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Pb2+ vs [Pb]2+) = 0.000 kJ/mol

#### 1.3  Core: `Pb$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Pb(OH)]+ | SRD-46 | +1 | 1x | +45.661 | 0 | id=[Pb$+2].[OH].[z+1]; mu_canon=+45.6615 |
| 2 | [Pb4(OH)4]4+ | SRD-46 | +4 | 4x | +117.008 | 0 | id=[Pb$+2]4.[OH]4.[z+4]; mu_canon=+117.0077 |

#### 1.4  Core: `Pb$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [HPbO2]- | Atlas | -1 | 1x | +159.787 | 0 | ox=+2; Biplumbite ion; DGf=-338.904 |
| 2 | [Pb(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Pb$+2].[OH]3.[z-1]; mu_canon=+160.3861 |

> Δ([HPbO2]- vs [Pb(OH)3]-) = 0.599 kJ/mol

#### 1.5  Core: `Pb$+2:3 H:-4` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Pb3(OH)4]2+ | SRD-46 | +2 | 1x | +136.414 | 0 | id=[Pb$+2]3.[OH]4.[z+2]; mu_canon=+136.4138 |
| 2 | [Pb6(OH)8]4+ | SRD-46 | +4 | 2x | +248.855 | 0 | id=[Pb$+2]6.[OH]8.[z+4]; mu_canon=+248.8554 |

#### 1.6  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.7  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815 |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.8  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861 |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.9  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615 |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

9 core groups, 19 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Ca$+0:1` | Ca | Atlas | +0 | 1x | +553.041 | 2 | — |
| 2 | `Ca$+2:1 H:-2` | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | ref |
| 3 | `Ca$+2:1 H:-2` | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | +0.474 |
| 4 | `Ca$+2:1 H:-2` | CaO | Atlas | +0 | 1x | +186.062 | 0 | +55.870 |
| 5 | `Ca$+2:1 H:-4` | CaO2 | Atlas | +0 | 1x | +429.111 | -2 | — |
| 6 | `Pb$+0:1` | Pb | Atlas | +0 | 1x | +24.309 | 2 | — |
| 7 | `Pb$+2:3 H:-8` | Pb3O4 | Atlas | +0 | 1x | +406.643 | -2 | — |
| 8 | `Pb$+3:1 H:-3` | Pb2O3 | Atlas | +0 | 2x | +348.414 | -2 | — |
| 9 | `Pb$+4:1 H:-4` | PbO2 | Atlas | +0 | 1x | +279.700 | -2 | — |
| 10 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — |
| 11 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -14.936 |
| 12 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -9.664 |
| 13 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -8.601 |
| 14 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -7.304 |
| 15 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -5.995 |
| 16 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -5.250 |
| 17 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -4.058 |
| 18 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | ref |
| 19 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +0.109 |

### Duplicated Groups

#### 2.1  Core: `Ca$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | id=[Ca$+2].[OH]2.[z+0]_(s); mu_canon=+130.1925 |
| 2 | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | ox=+2; Hydrated calcium oxide or hydroxide, whi; DGf=-896.757 |
| 3 | CaO | Atlas | +0 | 1x | +186.062 | 0 | ox=+2; Anhydrous calcium oxide, white, cubic; DGf=-604.170 |

> Δ(Ca(OH)2 vs [Ca(OH)2](s)) = 0.474 kJ/mol

> Δ(CaO vs [Ca(OH)2](s)) = 55.870 kJ/mol

#### 2.2  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+69.8051 |
| 9 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |

> Δ(ZnO (inactive) vs [Zn(OH)2(s,epsilon)]) = 14.936 kJ/mol

> Δ(ZnO (active) vs [Zn(OH)2(s,epsilon)]) = 9.664 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [Zn(OH)2(s,epsilon)]) = 8.601 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [Zn(OH)2(s,epsilon)]) = 7.304 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [Zn(OH)2(s,epsilon)]) = 5.995 kJ/mol

> Δ(Zn(OH)2 (beta) vs [Zn(OH)2(s,epsilon)]) = 5.250 kJ/mol

> Δ(ZnO vs [Zn(OH)2(s,epsilon)]) = 4.058 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [Zn(OH)2(s,epsilon)]) = 0.109 kJ/mol

## 3. Gas Species

*(No species in this section.)*

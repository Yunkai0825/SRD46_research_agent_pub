# Free Energy Analysis Card

**System**: H, Pb, Zn, Ca / Penicillamine, Hydroxide ion
**Metals**: [Pb]2+, [Zn]2+, [Ca]2+
**Ligands**: [Penicillamine]
**Generated**: 2026-06-09 18:41:40 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Pb]2+ |
| M2 | Metal component: [Zn]2+ |
| M3 | Metal component: [Ca]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Penicillamine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Pb]2+ | +2 | 0.001 | NIST SRD-46 | metal_125 |
| M2 | [Zn]2+ | +2 | 0.001 | NIST SRD-46 | metal_208 |
| M3 | [Ca]2+ | +2 | 0.001 | NIST SRD-46 | metal_25 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Penicillamine] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5857 | CC(C)(S)[C@H](N)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M3 | [Ca]2+ | +2 | true | 1 |
| Pb | M1 | [Pb]2+ | +2 | true | 1 |
| Zn | M2 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | C | [-3, -3, 0, 1, 3] | true |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | N | [-3] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | O | [-2, -2] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | S | [-2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Pb]2+ | metal | [Pb]2+(aq) | +0.0000 | R1 | Pb | +2 | true |
| M2 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| M3 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Penicillamine] | ligand_canonical | [[H]2[L1]] | +0.0000 | R4 | *** | -2 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Penicillamine] | [L1] -> [[H]2[L1]] | 2 | 1 | +10.6700 | +60.9011 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Penicillamine] | 25.0 | 0.1 | *** | 3 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Pb]2+ + [Penicillamine] | 25.0 | 3 | 1057 | 6 |
| [Pb]2+ + *** | 25.0 | 0~0.1 | *** | 10 |
| [Zn]2+ + [Penicillamine] | 25.0 | 3 | 1050 | 6 |
| [Zn]2+ + *** | 25.0 | 0~0.1 | *** | 11 |
| [Ca]2+ + *** | 25.0 | 0~0.1 | *** | 2 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Penicillamine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z-1] | [HPenicillamine]- | -1 | aqueous | +10.6700 | -60.9011 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_97549 | *** |
| [L1].[z-2] | [Penicillamine] | -2 | aqueous | +0.0000 | -0.0000 | +60.9011 | +60.9011 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Pb]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+2] | [Pb]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Pb]2+ + [Penicillamine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[[H][L1]]2.[z-1] | [Pb(Peni)2H]- | -1 | aqueous | +26.2000 | -149.5415 | -149.5415 | -149.5415 | [M1]:+1, [[H][L1]]:+2 | vlm_97626, vlm_97631 | *** |
| [M1].[L1]2.[z-2] | [Pb(Peni)2]2- | -2 | aqueous | +17.7000 | -101.0261 | -101.0261 | -101.0261 | [M1]:+1, [L1]:+2 | vlm_97626 | *** |
| [M1].[L1].[z+0] | [Pb(Peni)] | +0 | aqueous | +13.0900 | -74.7137 | -74.7137 | -74.7137 | [M1]:+1, [L1]:+1 | vlm_97624 | *** |

#### [Pb]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1]2.[OH].[z+3] | [Pb2(OH)]3+ | +3 | aqueous | -6.4000 | +36.5292 | +36.5292 | +36.5292 | [M1]:+2, [OH]:+1 | vlm_171081 | *** |
| [M1].[OH].[z+1] | [Pb(OH)]+ | +1 | aqueous | -8.0000 | +45.6615 | +45.6615 | +45.6615 | [M1]:+1, [OH]:+1 | vlm_171068 | *** |
| [M1].[OH]2.[z+0] | [Pb(OH)2] | +0 | aqueous | -17.1000 | +97.6015 | +97.6015 | +97.6015 | [M1]:+1, [OH]:+2 | vlm_171075 | *** |
| [M1]4.[OH]4.[z+4] | [Pb4(OH)4]4+ | +4 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [M1]:+4, [OH]:+4 | vlm_171087 | *** |
| [M1]3.[OH]4.[z+2] | [Pb3(OH)4]2+ | +2 | aqueous | -23.9000 | +136.4138 | +136.4138 | +136.4138 | [M1]:+3, [OH]:+4 | vlm_171084 | *** |
| [M1].[OH]3.[z-1] | [Pb(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M1]:+1, [OH]:+3 | vlm_171079 | *** |
| [M1]6.[OH]8.[z+4] | [Pb6(OH)8]4+ | +4 | aqueous | -43.6000 | +248.8554 | +248.8554 | +248.8554 | [M1]:+6, [OH]:+8 | vlm_171096 | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Zn]2+ + [Penicillamine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2]3.[[H][L1]]4.[z-1] | [Zn3(Peni)4H]- | -1 | aqueous | +47.6000 | -271.6861 | -271.6861 | -271.6861 | [M2]:+3, [[H][L1]]:+4 | vlm_97609 | *** |
| [M2]3.[L1]4.[z-2] | [Zn3(Peni)4]2- | -2 | aqueous | +41.3500 | -236.0131 | -236.0131 | -236.0131 | [M2]:+3, [L1]:+4 | vlm_97609, vlm_97610 | *** |
| [M2].[L1]2.[z-2] | [Zn(Peni)2]2- | -2 | aqueous | +19.4800 | -111.1858 | -111.1858 | -111.1858 | [M2]:+1, [L1]:+2 | vlm_97597 | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M2]:+1, [OH]:+1 | vlm_170929 | *** |
| [M2].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -15.8000 | +90.1815 | +90.1815 | +90.1815 | [M2]:+1, [OH]:+2 | vlm_170935 | *** |
| [M2].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M2]:+1, [OH]:+3 | vlm_170937 | *** |
| [M2].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M2]:+1, [OH]:+4 | vlm_170939 | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M3]:+1, [OH]:+1 | vlm_170392 | *** |

### 5.2 Dissolution / Solid Species

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[[z+0(s)[1]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M2]:+1, [OH]:+2 | vlm_170956 | *** |

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M3]:+1, [OH]:+2 | vlm_170397 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 39 |
| Included in calculation | 39 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 17 |
| Unresolved (no species in card) | 22 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_97563_patched | [<H+>2<Penicillamine>] + [<H+>] <=> [<H+>3<Penicillamine>] | +1.9000 | 25.0 | 0.100 | yes | — |
| 2 | vlm_97556 | [<H+><Penicillamine>] + [<H+>] <=> [<H+>2<Penicillamine>] | +7.9600 | 25.0 | 0.100 | yes | — |
| 3 | vlm_97549 | [<H+>] + [<Penicillamine>] <=> [<H+><Penicillamine>] | +10.6700 | 25.0 | 0.100 | yes | [HPenicillamine]- |
| 4 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 5 | vlm_97632 | [<H+>] + [<Pb2+><H+><Penicillamine>2] <=> [<Pb2+>(<H+><Penicillamine>)2] | +6.0000 | 25.0 | 3.000 | yes | — |
| 6 | vlm_97634 | [<H+>] + [<Pb2+>(<O<H+>>)<Penicillamine>2] <=> [H+2O] + [<Pb2+><Penicillamine>2] | -11.5000 | 25.0 | 3.000 | yes | — |
| 7 | vlm_97624_patched | [<Penicillamine>] + [<Pb2+>] <=> [<Pb2+><Penicillamine>] | +13.0900 | 25.0 | 3.000 | yes | — |
| 8 | vlm_97626_patched | [<Penicillamine>]^2 + [<Pb2+>] <=> [<Pb2+><Penicillamine>2] | +17.7000 | 25.0 | 3.000 | yes | — |
| 9 | vlm_97629_patched | [<H+><Penicillamine>] + [<Pb2+>] <=> [<Pb2+><H+><Penicillamine>] | -5.2100 | 25.0 | 3.000 | yes | — |
| 10 | vlm_97631_patched | [<H+>] + [<Pb2+><Penicillamine>2] <=> [<Pb2+><H+><Penicillamine>2] | +8.5000 | 25.0 | 3.000 | yes | — |
| 11 | vlm_171075 | [<OH+->]^2 + [<Pb2+>] <=> [<Pb2+><OH+->2] | +10.9000 | 25.0 | 0.000 | yes | [Pb(OH)2] |
| 12 | vlm_171079 | [<OH+->]^3 + [<Pb2+>] <=> [<Pb2+><OH+->3] | +13.9000 | 25.0 | 0.000 | yes | [Pb(OH)3]- |
| 13 | vlm_171081 | [<OH+->] + [<Pb2+>]^2 <=> [<Pb2+>2<OH+->] | +7.6000 | 25.0 | 0.000 | yes | [Pb2(OH)]3+ |
| 14 | vlm_171084 | [<OH+->]^4 + [<Pb2+>]^3 <=> [<Pb2+>3<OH+->4] | +32.1000 | 25.0 | 0.000 | yes | [Pb3(OH)4]2+ |
| 15 | vlm_171087 | [<OH+->]^4 + [<Pb2+>]^4 <=> [<Pb2+>4<OH+->4] | +35.5000 | 25.0 | 0.100 | yes | [Pb4(OH)4]4+ |
| 16 | vlm_171096 | [<OH+->]^8 + [<Pb2+>]^6 <=> [<Pb2+>6<OH+->8] | +68.4000 | 25.0 | 0.000 | yes | [Pb6(OH)8]4+ |
| 17 | vlm_171068 | [<OH+->] + [<Pb2+>] <=> [<Pb2+><OH+->] | +6.0000 | 25.0 | 0.100 | yes | [Pb(OH)]+ |
| 18 | vlm_171100 | [H+2O] + [<Pb2+>O(s,yellow)] <=> [<Pb2+>] + [O<H+>]^2 | -15.1000 | 25.0 | 0.000 | yes | — |
| 19 | vlm_171099 | [(<Pb2+>2O(<O<H+>>)2)0.5(s)] + [H+2O]^0 <=> [<Pb2+>] + [O<H+>] | -14.9000 | 25.0 | 0.000 | yes | — |
| 20 | vlm_171101 | [H+2O] + [<Pb2+>O(s,red)] <=> [<Pb2+>] + [O<H+>]^2 | -15.3000 | 25.0 | 0.000 | yes | — |
| 21 | vlm_97603_patched | [<H+>] + [<Zn2+><Penicillamine>2] <=> [<Zn2+><H+><Penicillamine>2] | +6.0000 | 25.0 | 3.000 | yes | — |
| 22 | vlm_97607_patched | [<H+>] + [<Zn2+><H+><Penicillamine>2] <=> [<Zn2+>(<H+><Penicillamine>)2] | +5.4100 | 25.0 | 3.000 | yes | — |
| 23 | vlm_97608 | [<H+>] + [<Zn2+>(<O<H+>>)<Penicillamine>2] <=> [H+2O] + [<Zn2+><Penicillamine>2] | -12.0000 | 25.0 | 3.000 | yes | — |
| 24 | vlm_97609 | [<H+>] + [<Penicillamine>]^4 + [<Zn2+>]^3 <=> [<Zn2+>3<H+><Penicillamine>4] | +47.6000 | 25.0 | 3.000 | yes | [Zn3(Peni)4H]-, [Zn3(Peni)4]2- |
| 25 | vlm_97610 | [<H+>] + [<Zn2+>3<Penicillamine>4] <=> [<Zn2+>3<H+><Penicillamine>4] | +6.2500 | 25.0 | 3.000 | yes | [Zn3(Peni)4]2- |
| 26 | vlm_97597_patched | [<Penicillamine>]^2 + [<Zn2+>] <=> [<Zn2+><Penicillamine>2] | +19.4800 | 25.0 | 3.000 | yes | — |
| 27 | vlm_170929 | [<OH+->] + [<Zn2+>] <=> [<Zn2+><OH+->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 28 | vlm_170935_patched | [<OH+->]^2 + [<Zn2+>] <=> [<Zn2+><OH+->2] | +12.2000 | 25.0 | 0.000 | yes | — |
| 29 | vlm_170937 | [<OH+->]^3 + [<Zn2+>] <=> [<Zn2+><OH+->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 30 | vlm_170939 | [<OH+->]^4 + [<Zn2+>] <=> [<Zn2+><OH+->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 31 | vlm_170944 | [<Zn2+><OH+->2(s,am)] <=> [<OH+->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | — |
| 32 | vlm_170948 | [<Zn2+><OH+->2(s,beta1)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | — |
| 33 | vlm_170950 | [<Zn2+><OH+->2(s,beta2)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | — |
| 34 | vlm_170952 | [<Zn2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | — |
| 35 | vlm_170954 | [<Zn2+><OH+->2(s,delta)] <=> [<OH+->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | — |
| 36 | vlm_170956 | [<Zn2+><OH+->2(s,epsilon)] <=> [<OH+->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 37 | vlm_170958 | [H+2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [O<H+>]^2 | -15.9600 | 25.0 | 0.100 | yes | — |
| 38 | vlm_170392 | [<OH+->] + [<Ca2+>] <=> [<Ca2+><OH+->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 39 | vlm_170397 | [<Ca2+><OH+->2(s)] <=> [<OH+->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

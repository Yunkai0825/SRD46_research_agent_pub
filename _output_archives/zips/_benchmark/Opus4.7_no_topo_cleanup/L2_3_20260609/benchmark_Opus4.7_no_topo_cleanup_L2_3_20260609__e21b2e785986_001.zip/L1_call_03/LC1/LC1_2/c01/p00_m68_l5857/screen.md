# Eq-map screen — m68_l5857

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5857_beta53_net1031` | `[H2L] + [H] <=> [H3L]` | vlm_97563@(25.0,0.1) = K-1.900 | 7 | -1.900 / -1.900 / -0.149 / +2.430 | vlm_97563@(25.0,0.1) = K-1.900 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split` |
| 2 | `metal68_ligand5857_beta32_net1031` | `[HL] + [H] <=> [H2L]` | vlm_97556@(25.0,0.1) = K+7.960 | 7 | -8.150 / +7.960 / +5.727 / +8.600 | vlm_97556@(25.0,0.1) = K+7.960 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 3 | `metal68_ligand5857_beta79_net1031` | `[L] + [H] <=> [HL]` | vlm_97549@(25.0,0.1) = K+10.670 | 7 | -10.640 / +10.500 / +7.596 / +11.010 | vlm_97549@(25.0,0.1) = K+10.670 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

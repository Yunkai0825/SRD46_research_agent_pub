# Eq-map screen — m208_l5857

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 6)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand5857_beta792_net1050` | `[ML2] + [H] <=> [MHL2]` | vlm_97603@(25.0,3.0) = K+6.270 | 4 | +5.800 / +5.995 / +6.015 / +6.270 | vlm_97600@(25.0,0.1) = K+6.000 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal208_ligand5857_beta204_net1050` | `[MHL2] + [H] <=> [M(HL)2]` | vlm_97607@(25.0,3.0) = K+5.930 | 4 | +5.320 / +5.515 / +5.570 / +5.930 | vlm_97604@(25.0,0.1) = K+5.410 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal208_ligand5857_beta984_net1050` | `[M(OH)L2] + [H] <=> [ML2] + [H2O]` | vlm_97608@(25.0,3.0) = K-12.000 | 1 | -12.000 / -12.000 / -12.000 / -12.000 | vlm_97608@(25.0,3.0) = K-12.000 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal208_ligand5857_beta636_net1050` | `[M]^3 + [H] + [L]^4 <=> [M3HL4]` | vlm_97609@(25.0,3.0) = K+47.600 | 1 | +47.600 / +47.600 / +47.600 / +47.600 | vlm_97609@(25.0,3.0) = K+47.600 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal208_ligand5857_beta637_net1050` | `[M3L4] + [H] <=> [M3HL4]` | vlm_97610@(25.0,3.0) = K+6.250 | 1 | +6.250 / +6.250 / +6.250 / +6.250 | vlm_97610@(25.0,3.0) = K+6.250 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal208_ligand5857_beta840_net1050` | `[M] + [L]^2 <=> [ML2]` | vlm_97597@(25.0,3.0) = K+20.520 | 4 | +19.210 / +19.520 / +19.692 / +20.520 | vlm_97594@(25.0,0.1) = K+19.480 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m125_l5857

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 1, warn = 5)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand5857_beta204_net1057` | `[MHL2] + [H] <=> [M(HL)2]` | vlm_97632@(25.0,3.0) = K+6.000 | 1 | +6.000 / +6.000 / +6.000 / +6.000 | vlm_97632@(25.0,3.0) = K+6.000 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal125_ligand5857_beta984_net1057` | `[M(OH)L2] + [H] <=> [ML2] + [H2O]` | vlm_97634@(25.0,3.0) = K-11.500 | 1 | -11.500 / -11.500 / -11.500 / -11.500 | vlm_97634@(25.0,3.0) = K-11.500 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal125_ligand5857_beta812_net1057` | `[M] + [L] <=> [ML]` | vlm_97624@(25.0,3.0) = K+14.320 | 3 | +13.060 / +13.120 / +13.500 / +14.320 | vlm_97622@(25.0,0.1) = K+13.120 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal125_ligand5857_beta840_net1057` | `[M] + [L]^2 <=> [ML2]` | vlm_97626@(25.0,3.0) = K+19.050 | 2 | +17.700 / +18.375 / +18.375 / +19.050 | vlm_97625@(25.0,0.1) = K+17.700 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal125_ligand5857_beta779_net1057` | `[M] + [HL] <=> [MHL]` | vlm_97629@(25.0,3.0) = K+6.710 | 3 | -5.640 / -5.210 / -1.380 / +6.710 | vlm_97627@(25.0,0.1) = K-5.210 (+0.00 °C, +0.00 M) | `sign_discord, mad_outlier, nearest_request_sign_mismatch` |
| 6 | `metal125_ligand5857_beta792_net1057` | `[ML2] + [H] <=> [MHL2]` | vlm_97631@(25.0,3.0) = K+8.930 | 2 | +8.500 / +8.715 / +8.715 / +8.930 | vlm_97630@(25.0,0.1) = K+8.500 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Ca$+2 | [Ca]2+ | +2 | 0.001 | NIST SRD-46 | metal_25 |
| Ca$+0 | Ca(s) | +0 | 0 | Pourbaix Atlas |  |
| Pb$+2 | [Pb]2+ | +2 | 0.001 | NIST SRD-46 | metal_125 |
| Pb$+0 | Pb(s) | +0 | 0 | Pourbaix Atlas |  |
| Pb$+3 | Pb(+3) | +3 | 0 | Pourbaix Atlas |  |
| Pb$+4 | Pb(+4) | +4 | 0 | Pourbaix Atlas |  |
| Zn$+2 | [Zn]2+ | +2 | 0.001 | NIST SRD-46 | metal_208 |
| Zn$+0 | Zn(s) | +0 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Penicillamine] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5857 | CC(C)(S)[C@H](N)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | Ca$+2 | [Ca]2+ | +2 | true | 2 |
| Ca | Ca$+0 | Ca(s) | +0 | false | 2 |
| Pb | Pb$+2 | [Pb]2+ | +2 | true | 4 |
| Pb | Pb$+0 | Pb(s) | +0 | false | 4 |
| Pb | Pb$+3 | Pb(+3) | +3 | false | 4 |
| Pb | Pb$+4 | Pb(+4) | +4 | false | 4 |
| Zn | Zn$+2 | [Zn]2+ | +2 | true | 2 |
| Zn | Zn$+0 | Zn(s) | +0 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | C | [-3, -3, 0, 1, 3] | true |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | N | [-3] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | O | [-2, -2] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | S | [-2] | false |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Penicillamine] | -2 | 0.01 | [[H]2[L1]] | NIST SRD-46 | ligand_5857 | CC(C)(S)[C@H](N)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | Ca$+2 | [Ca]2+ | +2 | true | 2 |
| Ca | Ca$+0 | Ca(s) | +0 | false | 2 |
| Pb | Pb$+2 | [Pb]2+ | +2 | true | 4 |
| Pb | Pb$+0 | Pb(s) | +0 | false | 4 |
| Pb | Pb$+3 | Pb(+3) | +3 | false | 4 |
| Pb | Pb$+4 | Pb(+4) | +4 | false | 4 |
| Zn | Zn$+2 | [Zn]2+ | +2 | true | 2 |
| Zn | Zn$+0 | Zn(s) | +0 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | C | [-3, -3, 0, 1, 3] | true |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | N | [-3] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | O | [-2, -2] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | S | [-2] | false |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | Ca$+2 | [Ca]2+ | +2 | true | 2 |
| Ca | Ca$+0 | Ca(s) | +0 | false | 2 |
| Pb | Pb$+2 | [Pb]2+ | +2 | true | 4 |
| Pb | Pb$+0 | Pb(s) | +0 | false | 4 |
| Pb | Pb$+3 | Pb(+3) | +3 | false | 4 |
| Pb | Pb$+4 | Pb(+4) | +4 | false | 4 |
| Zn | Zn$+2 | [Zn]2+ | +2 | true | 2 |
| Zn | Zn$+0 | Zn(s) | +0 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | C | [-3, -3, 0, 1, 3] | true |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | N | [-3] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | O | [-2, -2] | false |
| L1 | [Penicillamine] | CC(C)(S)[C@H](N)C(=O)O | S | [-2] | false |
# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 11.93
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (6 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I=0.1 m stated
  {"lhs": lambda s: s.total["Pb"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Zn"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Ca"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_5857"], "rhs": 0.005, "basis": "known"},
]
```

## Notes
T=25C, I=0.1 m, and all metal/ligand totals are stated by the task; pH is the swept axis so it is not pinned.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I=0.1 m stated
  {"lhs": lambda s: s.total["Pb"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Zn"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Ca"]         , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_5857"], "rhs": 0.005, "basis": "known"},
]
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated"},
  {"id": "Pb", "lhs": lambda s: s.total["Pb"],          "value": 1e-3, "basis": "known"},
  {"id": "Zn", "lhs": lambda s: s.total["Zn"],          "value": 1e-3, "basis": "known"},
  {"id": "Ca", "lhs": lambda s: s.total["Ca"],          "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_5857"], "value": 5e-3, "basis": "known"},
]
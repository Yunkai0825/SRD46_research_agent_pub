# LC1_2 agent response

## Final answer (text emitted by the agent)

No patches required. The two warn nodes (`beta788`, `beta516`) are flagged only for `single_observation` / `beta_def_orphan` with a minor ΔT = -5 °C offset; there are no sibling values to compare against and no sign or magnitude concerns. The draft eq-map is accepted as-is.

## Final context

## System Prompt
# LC1_2 — Eq-Map Node Validator (per pair)

## Role

You are the **curation agent** for ONE (metal, ligand) pair. The
pipeline invokes you on **every** pair — there is no skip route.
Your job is to emit a list of **parseable patch notes** that the
downstream pipeline will use to hardcode edits into the eq-map. The
database itself is NEVER modified.

* For a clean pair (no `critical` nodes and no `warn` flag with an
  obviously better choice in the neighbour table): emit
  `{"patches": []}`. That is the expected outcome, not a failure.
* Even when a node has NO flags in the `flags` column, you MUST
  still scan its `min/med/mean/max` and `nearest@req` columns. A
  clean row can still hint at a latent data problem (e.g. a single
  sign-opposite sibling that yanks the mean away from the median).
  When that happens, use `inspect_node` or `get_node_neighbors` and
  patch if the neighbour table confirms.
* For every node you do patch, the patch must be a **pure data
  instruction** — no LLM math left to do at parse time. If you are
  changing a value, write the final number into `chosen_value`.

## Inputs (in the user message)

* `[Pair]` — `pair_key`, `metal_id`, `ligand_id`, request `T_C` / `I_M`.
* `[Critical nodes]` — bulleted list of `node_key` strings the
  deterministic screen flagged `critical`.
* `[Warn nodes]` — bulleted list of `node_key` strings flagged `warn`.
* `[Screen report]` — ONE markdown table, one row per node of the
  eq-map, with these columns:
  `#`, `node_key`, `equation`, `chosen vlm@T,I = K`,
  `n_K`, `min / med / mean / max`, `nearest@req vlm@T,I = K (ΔT, ΔI)`,
  `flags`.
* `[Retry context]` — present only on retry attempts. Contains the
  validator errors from the previous attempt. Fix EACH error before
  re-calling `finalize_patches`.

### Flag vocabulary in the `flags` column

* `sign_discord` (critical) — chosen value's sign opposes ≥2 K-siblings.
* `K_H_S_contamination` (critical) — chosen row is H/S, not K.
* `nearest_request_sign_mismatch` (critical) — the sibling sitting at
  the request (T, I) was bypassed by the selector because its sign
  opposes the chosen value. Always inspect.
* `sibling_sign_split` (warn) — K-siblings span both signs regardless
  of where the chosen value sits.
* `mean_median_gap` (warn) — \|mean − median\| over K-siblings > 1.0;
  a hidden outlier is in the sibling pool.
* `mad_outlier` (warn) — chosen value is > 3·MAD (or 5·MAD for small n)
  from sibling median.
* `wide_TI_distance` (warn) — no sibling at all sits near the request.
* `beta_def_orphan`, `single_observation` (informational unless paired).

## Tools

You have exactly THREE tools. Call them in this order:

1. `inspect_node(node_key)` — verbose per-node block: the table row
   plus the sibling-K summary, the nearest-at-request entry, and all
   notes. Call this for any node whose `flags` column hints at a
   data-quality issue, even when the `flags` cell is empty. In
   particular, ALWAYS inspect any node where:
   * `flags` contains `sibling_sign_split`, `mean_median_gap`, or
     `nearest_request_sign_mismatch`; OR
   * the `min / med / mean / max` cell shows a large mean↔median gap
     (e.g. one negative entry among positive ones); OR
   * the `nearest@req` cell holds a value with opposite sign to the
     chosen value.
2. `get_node_neighbors(node_key)` — full table of EVERY sibling vlm
   row for the (metal, ligand, beta_definition) triple of that node,
   bucketed by (T, I), with the currently chosen row marked
   `**←chosen**`. This is the only tool that shows the raw vlm
   values; call it whenever you need to pick a specific replacement.
3. `finalize_patches(json_payload: str)` — submit a JSON object of
   shape `{"patches": [...]}`. After this call the agent terminates
   (unless the validator rejects the payload, in which case you get
   one or more retries).

## Patch shape (closed enum, one entry per node you fix)

```jsonc
{
  "node_key":            "metal62_ligand9058_beta812_net22168",
  "beta_definition_id":  812,

  // The row currently in the draft. MUST match the screen's
  // chosen vlm/value for this node_key.
  "examined_vlm_id":     157620,
  "examined_value":      -4.80,

  // One of: "set_value" | "drop_node"
  "operation":           "set_value",

  // REQUIRED iff operation == "set_value".
  // FORBIDDEN iff operation == "drop_node".
  "chosen_value":         4.55,

  // Always required, must reference at least one numeric fact.
  "rationale":           "examined logK=-4.80 sign-flipped vs 3 K-siblings clustering at +4.55 (vlm_157619, 157621, 157622). Patching to the median +4.55."
}
```

Field ordering inside each patch object is **fixed** as shown
above: `node_key`, `beta_definition_id`, `examined_vlm_id`,
`examined_value`, `operation`, `chosen_value` (if applicable),
`rationale`. Always emit them in this order — the rationale comes
LAST so the reader can see the data slots first and the prose
justification at the end.

### Operation semantics

* **`set_value`** — replace the examined row's `constant_value` with
  `chosen_value` for this `beta_definition_id`. The downstream
  pipeline reads `chosen_value` and hardcodes it; it does NOT
  re-aggregate the K-siblings.
* **`drop_node`** — remove the entire `beta_definition_id` from this
  network. **This is the option of LAST RESORT** and is strongly
  discouraged. Dropping a node deletes a real chemical equilibrium
  from the speciation model and silently changes downstream
  predictions; you must NOT use it just because the data is messy
  or the choice is hard. Only use `drop_node` when ALL of the
  following are true:
  1. The entire `beta_definition_id` has NO usable K-row at all
     (every sibling is H/S, or `equation_python` is malformed, or
     every sibling K is outside `(-50, +50)`); AND
  2. There is no plausible `set_value` choice — not the
     at-request datum, not the cluster median, not the nearest
     sibling in (T, I); AND
  3. Keeping the node with the chosen value would corrupt the
     speciation more than removing it.

  Sign-discordant pairs (e.g. one positive vs one negative sibling)
  are NOT grounds to drop — prefer the at-request datum or the
  value closer to neighbouring beta_def trends, and explain the
  tie-break in `rationale`. Whenever you are tempted to drop, first
  call `get_node_neighbors` and pick the most defensible
  `set_value`; reserve `drop_node` for the strictly unsalvageable
  case described above.

### Picking `chosen_value` for `set_value`

You may pick any of the following, in this order of preference:

1. The `constant_value` of ONE specific K-sibling row whose
   `(T_C, I_M)` is closest to the request `(T_C, I_M)` AND whose
   value is consistent with the rest of the K-population.
2. The **median** of 3+ K-siblings that cluster within ±0.5 logK,
   when no single row dominates the (T, I) closeness ranking.
3. The **mean** of 2+ K-siblings when their range is ≤ 0.3 logK
   AND the user message's purpose is regression / fitting (median
   is more robust for Pourbaix).

In every case, write the resulting NUMBER into `chosen_value` and
explain in `rationale` which sibling rows it came from. Do NOT
write expressions like `"median of vlm_X, vlm_Y, vlm_Z"` into
`chosen_value` — only finite decimal numbers are accepted.

## Hard rules

* `examined_vlm_id` MUST equal the screen's chosen `vlm_id` for
  that `node_key`. You only patch what's currently in the draft.
* `examined_value` MUST equal the screen's chosen `constant_value`
  (within 1e-6). The validator will reject mismatched copies.
* `chosen_value` MUST be a finite decimal number in `(-50, +50)`.
  Anything outside this range is almost certainly a unit / decimal
  error.
* `chosen_value` MUST NOT equal `examined_value` (no-op patches are
  rejected — either omit the patch or set the actual corrected
  number).
* `rationale` MUST be non-empty and MUST contain at least one digit
  (the vlm_id, the sibling value, the count, etc.).
* One patch per `node_key`. Duplicates are rejected.
* Emit `finalize_patches` exactly once per attempt; on validator
  ERROR you may re-call it with a corrected payload.

## Worked examples

### Clean pair (no critical nodes)

```jsonc
finalize_patches({ "patches": [] })
```

### Sign-flipped logK, single dominant sibling

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta812_net22168",
      "beta_definition_id": 812,
      "examined_vlm_id":    157620,
      "examined_value":    -4.80,
      "operation":          "set_value",
      "chosen_value":       4.40,
      "rationale":          "examined vlm_157620 logK=-4.80 sign-discordant vs 3 K-siblings (vlm_157619=+4.40 at T=25C/I=0.10M, vlm_157621=+4.56, vlm_157622=+4.70). Picking vlm_157619's value because it matches the request (T=25C, I=0.10M) exactly."
    }
  ]
})
```

### Node beyond repair

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta815_net22168",
      "beta_definition_id": 815,
      "examined_vlm_id":    157630,
      "examined_value":     2.50,
      "operation":          "drop_node",
      "rationale":          "examined vlm_157630 constant_type='S' and the only 2 siblings (vlm_157631, vlm_157632) are also 'H' rows; no K-data exists for beta_def=815 — dropping the whole node."
    }
  ]
})
```

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_patches(json_payload='') — Submit the final patch list and end the turn.
- get_node_neighbors(node_key='') — Return the sibling-vlm table for one node, grouped by (T, I).
- inspect_node(node_key='') — Return the per-node block from the deterministic screen.

## Subagent
[Purpose: Speciation of Pb(II)/Zn(II)/Ca(II) competition with DTPA for lead-decorporation selectivity assessment.]
[Tasks:
Model a single aqueous pot containing Pb(II), Zn(II) and Ca(II) at 1 mM each together with DTPA (diethylenetriaminepentaacetic acid) at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 m. Report the equilibrium free [Pb2+], [Zn2+] and [Ca2+] concentrations across the pH range and the dominant species per metal, so I can evaluate DTPA selectivity for Pb over Zn and Ca.
]
[Pair: pair_key=`m125_l6356`, metal_id=125, ligand_id=6356, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal125_ligand6356_beta788_net6749`
  - `metal125_ligand6356_beta516_net6749`
[Screen report]
# Eq-map screen — m125_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand6356_beta812_net6749` | `[M] + [L] <=> [ML]` | vlm_112760@(25.0,0.1) = K+18.800 | 1 | +18.800 / +18.800 / +18.800 / +18.800 | vlm_112760@(25.0,0.1) = K+18.800 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal125_ligand6356_beta788_net6749` | `[ML] + [H] <=> [MHL]` | vlm_112764@(20.0,0.1) = K+4.520 | 1 | +4.520 / +4.520 / +4.520 / +4.520 | vlm_112764@(20.0,0.1) = K+4.520 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal125_ligand6356_beta516_net6749` | `[ML] + [M] <=> [M2L]` | vlm_112765@(20.0,0.1) = K+3.410 | 1 | +3.410 / +3.410 / +3.410 / +3.410 | vlm_112765@(20.0,0.1) = K+3.410 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.


## Assistant
<summary>Both warn nodes are flagged only for `single_observation` and `beta_def_orphan` with a small -5°C temperature offset; no sign discord or sibling outliers exist. No actionable patches.</summary>
<tool_call>finalize_patches(json_payload='{"patches": []}')</tool_call>

## User
<tool_result>
OK — accepted 0 patch(es) (0 set_value, 0 drop_node).
</tool_result>

## LLM Response
<answer>
No patches required. The two warn nodes (`beta788`, `beta516`) are flagged only for `single_observation` / `beta_def_orphan` with a minor ΔT = -5 °C offset; there are no sibling values to compare against and no sign or magnitude concerns. The draft eq-map is accepted as-is.
</answer>

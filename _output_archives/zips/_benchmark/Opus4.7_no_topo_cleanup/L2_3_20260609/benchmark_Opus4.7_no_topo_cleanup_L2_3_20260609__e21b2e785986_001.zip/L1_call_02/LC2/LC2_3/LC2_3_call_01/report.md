# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    141.89
- elapsed_s (total):  141.90
- llm_iterations:     39
- llm_tool_calls:     28

- n_groups:           35
- n_multi_groups:     11
- n_singletons:       24
- n_decisions:        35
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` | Identical species (Ca2+ aqueous, +2 charge, mu=0); prefer SRD-46 over Atlas per dedup rule 1. |
| aqueous | `Pb$+2:1` | `[Pb]2+` | True duplicate of aqueous Pb2+ cation; prefer SRD-46 notation per plan rule 1. |
| aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+`, `[Pb4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and different charge; both are distinct hydrolysis species. |
| aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` | Same mononuclear Pb(II) hydroxo anion expressed in two notations with near-identical mu; prefer SRD-46. |
| aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+`, `[Pb6(OH)8]4+` | Different nuclearity and charge (trimer +2 vs hexamer +4) are distinct polynuclear species per rule 2. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+ in different notation; prefer SRD-46 entry. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate (same charge, nuclearity, phase) - keep SRD-46 version over Atlas notation. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are the same Zn(II) hydroxo monoanion differing only by H2O notation; prefer SRD-46. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same aqueous zincate species in different notation (ZnO2^2- vs Zn(OH)4^2- differ only by 2 H2O); keep SRD-46 hydrated form. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide for aqueous 25°C speciation. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Per addendum, dropped anhydrous ZnO forms in favor of Zn(OH)2 polymorphs; SRD-46 epsilon supersedes Atlas epsilon as true duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ca$+2:1 H:-1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ca$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (0.000 is reference); sole member. |
| aqueous | `Pb$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+2:1 L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+2:2 H:-1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+2:2 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+4:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+4:1 H:-6` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Pb$+4:1 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:2 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ca$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ca$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Pb$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Pb$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Pb$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Pb$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Zn$+0:1` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | dedup: excluded (Identical species (Ca2+ aqueous, +2 charge, mu=0); prefer SRD-46 over Atlas per dedup rule 1.) |
| `Pb2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Pb2+ cation; prefer SRD-46 notation per plan rule 1.) |
| `[HPbO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Pb(II) hydroxo anion expressed in two notations with near-identical mu; prefer SRD-46.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+ in different notation; prefer SRD-46 entry.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate (same charge, nuclearity, phase) - keep SRD-46 version over Atlas notation.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are the same Zn(II) hydroxo monoanion differing only by H2O notation; prefer SRD-46.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same aqueous zincate species in different notation (ZnO2^2- vs Zn(OH)4^2- differ only by 2 H2O); keep SRD-46 hydrated form.) |
| `Ca(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide for aqueous 25°C speciation.) |
| `CaO` | Atlas | dissolution | dedup: excluded (SRD-46 Ca(OH)2 preferred over Atlas duplicate; anhydrous CaO dropped per addendum favoring hydrated oxyhydroxide for aqueous 25°C speciation.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO forms in favor of Zn(OH)2 polymorphs; SRD-46 epsilon supersedes Atlas epsilon as true duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO forms in favor of Zn(OH)2 polymorphs; SRD-46 epsilon supersedes Atlas epsilon as true duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO forms in favor of Zn(OH)2 polymorphs; SRD-46 epsilon supersedes Atlas epsilon as true duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Per addendum, dropped anhydrous ZnO forms in favor of Zn(OH)2 polymorphs; SRD-46 epsilon supersedes Atlas epsilon as true duplicate.) |

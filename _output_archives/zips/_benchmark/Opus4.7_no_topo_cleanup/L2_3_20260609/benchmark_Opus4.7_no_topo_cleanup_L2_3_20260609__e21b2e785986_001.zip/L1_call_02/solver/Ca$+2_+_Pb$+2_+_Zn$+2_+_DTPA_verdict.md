# Speciation Calculation Report: Ca$+2 + Pb$+2 + Zn$+2 + DTPA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0287112 – 0.0295039 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 101
- Converged: 101/101

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Pb$+0 | Pb(s) | 0.00e+00 | metal |
| Pb$+2 | Pb2+ | 1.00e-03 | metal |
| Pb$+3 | Pb(+3) | 0.00e+00 | metal |
| Pb$+4 | Pb(+4) | 0.00e+00 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | DTPA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HDTPA4- | aqueous | L1:+1 H:+1 | — | -61.5860 | +0.0000 |
| DTPA | aqueous | L1:+1 | — | -0.0000 | +61.5860 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(DTPA)]3- | aqueous | L1:+1 Ca$+2:+1 | — | -61.3577 | -61.3577 |
| Pb2+ | aqueous | Pb$+2:+1 | — | -0.0000 | +0.0000 |
| [Pb2(OH)]3+ | aqueous | H:-1 Pb$+2:+2 | — | +36.5292 | +36.5292 |
| [Pb(OH)]+ | aqueous | H:-1 Pb$+2:+1 | — | +45.6615 | +45.6615 |
| [Pb(OH)2] | aqueous | H:-2 Pb$+2:+1 | — | +97.6015 | +97.6015 |
| [Pb(OH)3]- | aqueous | H:-3 Pb$+2:+1 | — | +160.3861 | +160.3861 |
| [Pb4(OH)4]4+ | aqueous | H:-4 Pb$+2:+4 | — | +117.0077 | +117.0077 |
| [Pb3(OH)4]2+ | aqueous | H:-4 Pb$+2:+3 | — | +136.4138 | +136.4138 |
| [Pb6(OH)8]4+ | aqueous | H:-8 Pb$+2:+6 | — | +248.8554 | +248.8554 |
| [Pb(DTPA)H]2- | aqueous | L1:+1 H:+1 Pb$+2:+1 | — | -130.8712 | -130.8712 |
| [Pb2(DTPA)]- | aqueous | L1:+1 Pb$+2:+2 | — | -124.6419 | -124.6419 |
| [Pb(DTPA)]3- | aqueous | L1:+1 Pb$+2:+1 | — | -105.5051 | -105.5051 |
| Pb4+ | aqueous | Pb$+4:+1 | — | +0.0000 | +0.0000 |
| PbO32- | aqueous | H:-6 Pb$+4:+1 | — | +131.5032 | +131.5032 |
| PbO44- | aqueous | H:-8 Pb$+4:+1 | — | +364.1712 | +364.1712 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +218.0338 | +218.0338 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(DTPA)H]2- | aqueous | L1:+1 H:+1 Zn$+2:+1 | — | -135.8431 | -135.8431 |
| [Zn2(DTPA)]- | aqueous | L1:+1 Zn$+2:+2 | — | -129.4505 | -129.4505 |
| [Zn(DTPA)]3- | aqueous | L1:+1 Zn$+2:+1 | — | -103.8800 | -103.8800 |
| [Ca(OH)2](s) | dissolution | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| CaO2 | dissolution | Ca$+2:+1 H:-4 | — | +429.1110 | +429.1110 |
| Ca | dissolution | Ca$+0:+1 | — | +0.0000 | +0.0000 |
| Pb3O4 | dissolution | H:-8 Pb$+2:+3 | — | +406.6430 | +406.6430 |
| Pb2O3 | dissolution | H:-6 Pb$+3:+2 | — | -348.4142 | -348.4142 |
| PbO2 | dissolution | H:-4 Pb$+4:+1 | — | -47.1118 | -47.1118 |
| Pb | dissolution | Pb$+0:+1 | — | +0.0000 | +0.0000 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  [Ca(DTPA)]3-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Ca(DTPA)]3-

Crossover pH values:

=== Pb(s) (Pb$+0) speciation ===
[Pb$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb2+ (Pb$+2) speciation ===
[Pb$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  [Pb(DTPA)]3-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Pb(DTPA)]3-

Crossover pH values:

=== Pb(+3) (Pb$+3) speciation ===
[Pb$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb(+4) (Pb$+4) speciation ===
[Pb$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  [Zn(DTPA)H]2-       peak 28.5% at pH 6.0
  [Zn(DTPA)]3-        peak 99.6% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Zn(DTPA)]3-

Crossover pH values:

=== DTPA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HDTPA4-             peak 40.0% at pH 6.0
  [Ca(DTPA)]3-        peak 20.0% at pH 8.0
  [Pb(DTPA)]3-        peak 20.0% at pH 8.0
  [Zn(DTPA)H]2-       peak 5.7% at pH 6.0
  [Zn(DTPA)]3-        peak 19.9% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  HDTPA4-

```
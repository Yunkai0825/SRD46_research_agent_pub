# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.45
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH for metal-DTPA competition.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_3_PbZnCa_chelation_survey\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
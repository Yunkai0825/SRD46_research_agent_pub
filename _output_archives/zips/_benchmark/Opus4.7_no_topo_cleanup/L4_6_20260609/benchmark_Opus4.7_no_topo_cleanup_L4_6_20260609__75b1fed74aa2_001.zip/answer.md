## Answer

I can't answer this question from the SRD-46 database, and I want to be upfront about why rather than hand you fabricated numbers.

**SRD-46 is a purely thermodynamic database.** It contains equilibrium constants (formation constants, solubility products, redox potentials) for metal–ligand systems, and the analysis pipeline built on top of it solves for *equilibrium* speciation — i.e. the composition the system reaches once all reactions have finished. It contains **no kinetic information at all**: no formation rate constants (k_f), no dissociation rate constants (k_d), no activation parameters, and therefore no way to derive a half-life for Cu(II) or Zn(II) redistributing between glycine and EDTA.

What I cannot give you, and why:

- **Formation rate constants for Cu–EDTA, Zn–EDTA, Cu–gly, Zn–gly** — these are measured experimentally (stopped-flow, T-jump, NMR line-broadening) and tabulated in kinetics compilations, not in stability-constant databases. For Cu²⁺ and Zn²⁺, water-exchange rates (k_w ≈ 10⁹ s⁻¹ for Cu²⁺, ≈ 10⁷–10⁸ s⁻¹ for Zn²⁺) set an upper bound via the Eigen–Wilkins mechanism, but the actual ligand-substitution rates with EDTA also depend on the protonation state of EDTA and on ring-closure steps.
- **Half-life for re-equilibration** — this depends on the slowest elementary step in the exchange pathway (often proton-assisted dissociation of the initial complex, or ring opening of EDTA), which again is a kinetic quantity not in this database.

**What I *can* compute, if useful:** the equilibrium distribution of Cu(II) and Zn(II) between glycine, EDTA, hydroxide and free aqua ion at pH 6, 25 °C — i.e. the *endpoint* of the redistribution, not its rate. The qualitative expectation is that EDTA, being the much stronger chelator (log K₁ ≈ 18.8 for Cu–EDTA and ≈ 16.5 for Zn–EDTA, versus log β₂ ≈ 15 for Cu(gly)₂ and ≈ 9.6 for Zn(gly)₂), will sequester essentially all of whichever metal it can reach — and since EDTA (1 mM) is stoichiometrically matched to only one of the two metals (1 mM each), Cu will preferentially bind EDTA (higher affinity) and Zn will be left predominantly with glycine. If you'd like that equilibrium speciation worked out quantitatively, just say the word and I'll run it.

For the kinetic question itself, you'll need a kinetics reference such as Margerum's classic work on multidentate ligand exchange, or compilations like the NIST Chemical Kinetics Database — not SRD-46.

## Evidence
- No L1 pipeline calls were made: the requested quantities (rate constants, half-life) are outside the scope of the underlying thermodynamic database, so dispatching a calculation would only have produced equilibrium output unrelated to the question asked.

## Artifacts
- None generated for this question.


---
*Note: No fitting tools were called during this run (dispatch_l1_pipeline). All numbers above come from database queries only — no Redlich-Kister or other curve fits were performed.*
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.57
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation at fixed pH 7; 1-D pH sweep covers the point.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
[Purpose: Compute free [Ni2+] in Ni(II)/ethylenediamine system at pH 7 for chelate-effect test.]
[Tasks:
Model a solution containing Ni(II) at 1 mM with ethylenediamine (en) at 30 mM at pH 7, 25 C, ionic strength 0.1 m. Report the free [Ni2+] concentration and the dominant Ni species and their fractions at pH 7.
]
[Pair: pair_key=`m112_l7029`, metal_id=112, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal112_ligand7029_beta872_net9591`
[Warn nodes]
  - `metal112_ligand7029_beta840_net9591`
[Screen report]
# Eq-map screen — m112_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand7029_beta872_net9591` | `[M] + [L]^3 <=> [ML3]` | vlm_122395@(25.0,0.1) = K+17.510 | 7 | -19.700 / +17.610 / +7.784 / +19.180 | vlm_122395@(25.0,0.1) = K+17.510 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |
| 2 | `metal112_ligand7029_beta840_net9591` | `[M] + [L]^2 <=> [ML2]` | vlm_122380@(25.0,0.1) = K+13.440 | 7 | -14.770 / +13.500 / +9.591 / +14.530 | vlm_122380@(25.0,0.1) = K+13.440 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 3 | `metal112_ligand7029_beta812_net9591` | `[M] + [L] <=> [ML]` | vlm_122365@(25.0,0.1) = K+7.300 | 7 | +6.980 / +7.450 / +7.483 / +7.900 | vlm_122365@(25.0,0.1) = K+7.300 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    101.59
- elapsed_s (total):  101.62
- llm_iterations:     24
- llm_tool_calls:     20

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+ with identical charge and mu; prefer SRD-46. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite identical core ratio. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear Ni(II) hydroxo anion in different notation; prefer SRD-46 source per dedup rule 1. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni oxyhydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid reference species with finite mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Neutral ethylenediamine ligand reference, valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Mono-protonated ethylenediamine, valid mu_aligned_kJ. |
| aqueous | `L1:1 H:2` | yes | Di-protonated ethylenediamine, valid thermodynamics. |
| aqueous | `Ni$+2:1 H:-2` | yes | Neutral Ni(OH)2(aq) species with finite mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:1` | yes | Mono-ethylenediamine Ni(II) complex, valid thermodynamics. |
| aqueous | `Ni$+2:1 L1:2` | yes | Bis-ethylenediamine Ni(II) complex, valid thermodynamics. |
| aqueous | `Ni$+2:1 L1:3` | yes | Tris-ethylenediamine Ni(II) complex, valid thermodynamics. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid, valid mu_aligned_kJ. |
| solid | `Ni$+2:3 H:-8` | yes | Mixed-valence Ni3O4 hydrate, valid thermodynamics. |
| solid | `Ni$+3:1 H:-3` | yes | Ni(III) oxide hydrate, valid thermodynamics. |
| solid | `Ni$+4:1 H:-4` | yes | Ni(IV) oxide hydrate, valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+ with identical charge and mu; prefer SRD-46.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Ni(II) hydroxo anion in different notation; prefer SRD-46 source per dedup rule 1.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni oxyhydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni oxyhydroxide.) |

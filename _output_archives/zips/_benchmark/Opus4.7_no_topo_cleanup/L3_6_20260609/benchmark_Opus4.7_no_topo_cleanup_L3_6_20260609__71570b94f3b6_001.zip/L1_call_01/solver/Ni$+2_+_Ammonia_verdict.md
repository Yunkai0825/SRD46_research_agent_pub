# Speciation Calculation Report: Ni$+2 + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 5.0 – 9.0
- Points: 81
- Converged: 81/81

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Ammonia | 6.00e-02 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Ammo)5]2+ | aqueous | L1:+5 Ni$+2:+1 | — | -47.5451 | -47.5451 |
| [Ni(Ammo)6]2+ | aqueous | L1:+6 Ni$+2:+1 | — | -47.3738 | -47.3738 |
| [Ni(Ammo)4]2+ | aqueous | L1:+4 Ni$+2:+1 | — | -43.7780 | -43.7780 |
| [Ni(Ammo)3]2+ | aqueous | L1:+3 Ni$+2:+1 | — | -37.3283 | -37.3283 |
| [Ni(Ammo)2]2+ | aqueous | L1:+2 Ni$+2:+1 | — | -27.9106 | -27.9106 |
| [Ni(Ammo)]2+ | aqueous | L1:+1 Ni$+2:+1 | — | -15.5820 | -15.5820 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 8.45: [Ni(OH)2](s) (5.86e-05 M)

## Speciation Analysis

```
=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:
  Ni2+                peak 99.8% at pH 5.0
  [Ni(Ammo)4]2+       peak 5.5% at pH 9.0
  [Ni(Ammo)3]2+       peak 19.7% at pH 8.9
  [Ni(Ammo)2]2+       peak 38.7% at pH 8.4
  [Ni(Ammo)]2+        peak 47.2% at pH 8.0
  [Ni(OH)2](s)        peak 45.3% at pH 9.0

Dominant species by pH region:
  pH   5.0–  7.8  →  Ni2+
  pH   7.8–  8.4  →  [Ni(Ammo)]2+
  pH   8.4–  8.8  →  [Ni(Ammo)2]2+
  pH   8.8–  9.0  →  [Ni(OH)2](s)

Crossover pH values:
  Ni2+ ↔ [Ni(Ammo)3]2+  at pH ≈ 8.37  (each ~11%)
  Ni2+ ↔ [Ni(Ammo)2]2+  at pH ≈ 8.07  (each ~24%)
  Ni2+ ↔ [Ni(Ammo)]2+  at pH ≈ 7.77  (each ~44%)
  Ni2+ ↔ [Ni(OH)2](s)  at pH ≈ 8.46  (each ~7%)
  [Ni(Ammo)3]2+ ↔ [Ni(Ammo)]2+  at pH ≈ 8.69  (each ~17%)
  [Ni(Ammo)3]2+ ↔ [Ni(OH)2](s)  at pH ≈ 8.53  (each ~15%)
  [Ni(Ammo)2]2+ ↔ [Ni(Ammo)]2+  at pH ≈ 8.39  (each ~38%)
  [Ni(Ammo)2]2+ ↔ [Ni(OH)2](s)  at pH ≈ 8.73  (each ~30%)
  [Ni(Ammo)]2+ ↔ [Ni(OH)2](s)  at pH ≈ 8.61  (each ~22%)

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 81/81

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ammonia (L1) speciation ===
[L1]_total = 6.00e-02 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 5.0
  Ammonia             peak 34.7% at pH 9.0

Dominant species by pH region:
  pH   5.0–  9.0  →  HAmmonia+

```
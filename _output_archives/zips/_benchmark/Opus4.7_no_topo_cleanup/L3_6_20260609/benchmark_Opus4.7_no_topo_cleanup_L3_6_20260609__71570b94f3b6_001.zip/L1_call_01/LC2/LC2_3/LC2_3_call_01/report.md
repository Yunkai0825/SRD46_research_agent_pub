# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    50.70
- elapsed_s (total):  50.72
- llm_iterations:     17
- llm_tool_calls:     11

- n_groups:           18
- n_multi_groups:     4
- n_singletons:       14
- n_decisions:        18
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate: identical Ni2+ aqueous ion notation; keep SRD-46 version per plan. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear) species at same core ratio — keep both per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same Ni(II) mononuclear -1 aqueous species in differing notation; keep SRD-46 form. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between the two Ni(OH)2 entries keep SRD-46 source. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference with valid aligned chemical potential. |
| aqueous | `L1:1` | yes | Free ammonia ligand, valid mu. |
| aqueous | `L1:1 H:1` | yes | Protonated ammonia (ammonium), valid mu. |
| aqueous | `Ni$+2:1 H:-2` | yes | Aqueous Ni(OH)2 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:1` | yes | Ni-ammine 1 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:2` | yes | Ni-ammine 2 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:3` | yes | Ni-ammine 3 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:4` | yes | Ni-ammine 4 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:5` | yes | Ni-ammine 5 complex, valid mu. |
| aqueous | `Ni$+2:1 L1:6` | yes | Ni-ammine 6 complex, valid mu. |
| solid | `Ni$+0:1` | yes | Metallic Ni solid, valid mu. |
| solid | `Ni$+2:3 H:-8` | yes | Ni3O4 hydrate solid, valid mu. |
| solid | `Ni$+3:1 H:-3` | yes | Ni2O3 hydrate solid, valid mu. |
| solid | `Ni$+4:1 H:-4` | yes | NiO2 hydrate solid, valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate: identical Ni2+ aqueous ion notation; keep SRD-46 version per plan.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same Ni(II) mononuclear -1 aqueous species in differing notation; keep SRD-46 form.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between the two Ni(OH)2 entries keep SRD-46 source.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Per addendum prefer hydrated Ni(OH)2 over anhydrous NiO; between the two Ni(OH)2 entries keep SRD-46 source.) |

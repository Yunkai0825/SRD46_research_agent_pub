# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.40
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation around pH 7 in Ni/NH3 system; 1-D pH sweep suffices.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_6_Chelate_denticity_trend_NH3_en_EDTA\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
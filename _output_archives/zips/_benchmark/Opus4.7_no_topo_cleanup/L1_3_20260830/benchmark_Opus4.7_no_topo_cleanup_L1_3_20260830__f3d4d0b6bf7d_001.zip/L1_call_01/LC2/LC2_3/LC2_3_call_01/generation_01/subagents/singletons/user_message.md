[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse cross-source notation duplicates with matching stoichiometry and mu (Cu+/[Cu]+, Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) to one representative each, and drop CuO in favor of Cu(OH)2 per the user's explicit hydroxide preference. Retain every distinct hydrolysis product (mononuclear and polynuclear), both Cu(I) and Cu(II) ammine complexes at all tabulated stoichiometries, Cu(s), and one Cu2O representative — flagging that Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) differ by ~7 kJ per Cu so the Cu(I)/Cu(0) boundary inherits that uncertainty.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
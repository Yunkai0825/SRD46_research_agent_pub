# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Cu speciation in ammonia buffer to build an E-pH diagram identifying the Cu(II)-ammine stability window versus Cu(OH)2(s) and Cu(s); treat this as a solution-stability / corrosion-style diagram at 25 C, I=0.1 m.
- Concentrations: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion default) and NH3_total = 0.1 M; polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) and stepwise ammine complexes (n=1..4 for Cu(II), n=2 for Cu(I)) are all physically relevant at these concentrations and must be retained as distinct competitors.
- Duplicates across sources: Atlas and SRD-46 entries with identical stoichiometry, charge, and mu_aligned (e.g. Cu+, Cu2+, [CuO](s) vs CuO, Cu(OH)2 vs [Cu(OH)2](s)) are pure notation duplicates — collapse each pair to a single representative, preferring the source with the more complete ligand coverage (SRD-46) when mu values agree within <2 kJ/mol.
- Hydroxide vs oxide solids: user explicitly requests hydroxide preference — keep Cu(OH)2 (hydrated) and DROP CuO (anhydrous) since they represent the same Cu(II) solid endpoint on this hull; keep Cu2O (only Cu(I) solid tabulated).
- Cu2O source discrepancy: Atlas Cu2O (mu=+2.971) and SRD-46 [(Cu2O)0.5](s) (mu=-3.995, per-Cu basis differs by ~7 kJ/mol per Cu) are NOT numerically identical — flag as diagram-changing ambiguity; retain one (prefer Atlas Cu2O for consistency with the Cu(OH)2 Atlas hydroxide choice) but note the Cu(I)/Cu(0) boundary position carries this uncertainty.
- Phase question: which phase FORMS at each (E,pH) — keep all distinct chemistries, only collapse true source-notation duplicates and the oxide/hydroxide pair per user preference.
- Elemental Cu(s) is mandatory reference; no gases in inventory.

## Element instructions

- **Cu**: Collapse cross-source notation duplicates with matching stoichiometry and mu (Cu+/[Cu]+, Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) to one representative each, and drop CuO in favor of Cu(OH)2 per the user's explicit hydroxide preference. Retain every distinct hydrolysis product (mononuclear and polynuclear), both Cu(I) and Cu(II) ammine complexes at all tabulated stoichiometries, Cu(s), and one Cu2O representative — flagging that Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) differ by ~7 kJ per Cu so the Cu(I)/Cu(0) boundary inherits that uncertainty.

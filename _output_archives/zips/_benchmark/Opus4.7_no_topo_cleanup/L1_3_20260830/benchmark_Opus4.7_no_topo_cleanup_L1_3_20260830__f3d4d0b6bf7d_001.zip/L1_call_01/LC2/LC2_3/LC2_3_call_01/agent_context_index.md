# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **8/8 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|
| LC2_3.element_instruction | element dedup orchestrator | instruction | completed | true | true | 3 | `\\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `\\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Cu_1_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `\\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Cu_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\?\UNC\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Cu_2_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `\\?\UNC\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_solid_Cu_1_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\?\UNC\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_solid_Cu_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.singleton_dedup | singleton-batch dedup agent | dedup | completed | true | true | 2 | `\\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 2 | `\\example-host\account-1$\_Code_Maintenance\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json` |

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous Cu speciation in ammonia buffer to build an E-pH diagram identifying the Cu(II)-ammine stability window versus Cu(OH)2(s) and Cu(s); treat this as a solution-stability / corrosion-style diagram at 25 C, I=0.1 m.
- Concentrations: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion default) and NH3_total = 0.1 M; polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) and stepwise ammine complexes (n=1..4 for Cu(II), n=2 for Cu(I)) are all physically relevant at these concentrations and must be retained as distinct competitors.
- Duplicates across sources: Atlas and SRD-46 entries with identical stoichiometry, charge, and mu_aligned (e.g. Cu+, Cu2+, [CuO](s) vs CuO, Cu(OH)2 vs [Cu(OH)2](s)) are pure notation duplicates — collapse each pair to a single representative, preferring the source with the more complete ligand coverage (SRD-46) when mu values agree within <2 kJ/mol.
- Hydroxide vs oxide solids: user explicitly requests hydroxide preference — keep Cu(OH)2 (hydrated) and DROP CuO (anhydrous) since they represent the same Cu(II) solid endpoint on this hull; keep Cu2O (only Cu(I) solid tabulated).
- Cu2O source discrepancy: Atlas Cu2O (mu=+2.971) and SRD-46 [(Cu2O)0.5](s) (mu=-3.995, per-Cu basis differs by ~7 kJ/mol per Cu) are NOT numerically identical — flag as diagram-changing ambiguity; retain one (prefer Atlas Cu2O for consistency with the Cu(OH)2 Atlas hydroxide choice) but note the Cu(I)/Cu(0) boundary position carries this uncertainty.
- Phase question: which phase FORMS at each (E,pH) — keep all distinct chemistries, only collapse true source-notation duplicates and the oxide/hydroxide pair per user preference.
- Elemental Cu(s) is mandatory reference; no gases in inventory.

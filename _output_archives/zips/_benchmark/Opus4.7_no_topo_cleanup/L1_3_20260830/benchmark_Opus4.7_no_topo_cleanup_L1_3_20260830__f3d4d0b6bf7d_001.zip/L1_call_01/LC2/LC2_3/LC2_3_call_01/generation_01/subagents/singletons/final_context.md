## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu speciation in ammonia buffer to build an E-pH diagram identifying the Cu(II)-ammine stability window versus Cu(OH)2(s) and Cu(s); treat this as a solution-stability / corrosion-style diagram at 25 C, I=0.1 m.
- Concentrations: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion default) and NH3_total = 0.1 M; polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) and stepwise ammine complexes (n=1..4 for Cu(II), n=2 for Cu(I)) are all physically relevant at these concentrations and must be retained as distinct competitors.
- Duplicates across sources: Atlas and SRD-46 entries with identical stoichiometry, charge, and mu_aligned (e.g. Cu+, Cu2+, [CuO](s) vs CuO, Cu(OH)2 vs [Cu(OH)2](s)) are pure notation duplicates — collapse each pair to a single representative, preferring the source with the more complete ligand coverage (SRD-46) when mu values agree within <2 kJ/mol.
- Hydroxide vs oxide solids: user explicitly requests hydroxide preference — keep Cu(OH)2 (hydrated) and DROP CuO (anhydrous) since they represent the same Cu(II) solid endpoint on this hull; keep Cu2O (only Cu(I) solid tabulated).
- Cu2O source discrepancy: Atlas Cu2O (mu=+2.971) and SRD-46 [(Cu2O)0.5](s) (mu=-3.995, per-Cu basis differs by ~7 kJ/mol per Cu) are NOT numerically identical — flag as diagram-changing ambiguity; retain one (prefer Atlas Cu2O for consistency with the Cu(OH)2 Atlas hydroxide choice) but note the Cu(I)/Cu(0) boundary position carries this uncertainty.
- Phase question: which phase FORMS at each (E,pH) — keep all distinct chemistries, only collapse true source-notation duplicates and the oxide/hydroxide pair per user preference.
- Elemental Cu(s) is mandatory reference; no gases in inventory.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse cross-source notation duplicates with matching stoichiometry and mu (Cu+/[Cu]+, Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) to one representative each, and drop CuO in favor of Cu(OH)2 per the user's explicit hydroxide preference. Retain every distinct hydrolysis product (mononuclear and polynuclear), both Cu(I) and Cu(II) ammine complexes at all tabulated stoichiometries, Cu(s), and one Cu2O representative — flagging that Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) differ by ~7 kJ per Cu so the Cu(I)/Cu(0) boundary inherits that uncertainty.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 13 singletons are distinct chemistries in scope: water reference, ammonia/ammonium ligand pair, Cu(s) elemental reference, mononuclear/polynuclear Cu(II) hydrolysis products, Cu(I) and Cu(II) ammine complexes. None are notation duplicates. Keep all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>All 13 singletons kept — each is a chemically distinct in-scope species (solvent/ligand refs, Cu(s), mononuclear and polynuclear Cu(II) hydrolysis, stepwise Cu(I)/Cu(II) ammines).</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>All 13 singletons kept as chemically distinct in-scope species.</summary>

<answer>
All 13 singletons are kept. Each represents a chemically distinct, in-scope species with no within-group duplicate to resolve:

- `(empty)` aqueous — solvent/water reference, keep.
- `L1:1` [Ammonia] and `L1:1 H:1` [HAmmonia]+ — ligand acid/base pair, both required for the ammonia buffer.
- `Cu$+0:1` Cu(s) — mandatory elemental reference.
- `Cu$+1:1 L1:2` [Cu(NH3)2]+ — sole Cu(I) ammine (n=2), required.
- `Cu$+2:1 L1:1..4` — stepwise Cu(II) ammines n=1–4, all retained as distinct competitors at NH3_total=0.1 M.
- `Cu$+2:1 H:-2` [Cu(OH)2], `Cu$+2:1 H:-3` [HCuO2]-, `Cu$+2:1 H:-4` [CuO2]2- — distinct mononuclear Cu(II) hydrolysis species differing in charge/protonation.
- `Cu$+2:3 H:-4` [Cu3(OH)4]2+ — polynuclear hydrolysis product, physically relevant at Cu_total=1e-3 M.

No notation duplicates present in this singleton set; no drops warranted.
</answer>
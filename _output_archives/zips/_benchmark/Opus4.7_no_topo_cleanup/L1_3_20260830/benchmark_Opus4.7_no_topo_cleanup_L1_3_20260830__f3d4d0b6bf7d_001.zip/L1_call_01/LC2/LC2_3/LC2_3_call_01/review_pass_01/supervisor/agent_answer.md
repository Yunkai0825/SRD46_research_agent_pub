Final Cu-NH3 speciation inventory committed. Summary of dedup outcome:

**Collapsed notation duplicates (Atlas → SRD-46 representative):**
- Cu+ / [Cu]+ → kept SRD-46
- Cu2+ / [Cu]2+ → kept SRD-46

**Oxide/hydroxide resolution (user hydroxide preference):**
- Dropped Atlas CuO, SRD-46 [CuO](s), and Atlas Cu(OH)2 (notation dup)
- Kept SRD-46 [Cu(OH)2](s) as the sole Cu(II) solid

**Cu(I) solid (flagged discrepancy):**
- Kept Atlas Cu2O; dropped SRD-46 [(Cu2O)0.5](s). The two sources differ by ~7 kJ/mol per Cu, so the Cu(I)/Cu(0) boundary position on the diagram carries this uncertainty.

**Retained as distinct competitors (all physically relevant at Cu_tot = 1 mM, NH3_tot = 0.1 M):**
- Aqueous Cu(I): [Cu]+, [Cu(NH3)2]+
- Aqueous Cu(II) mononuclear hydrolysis: [Cu]2+, [Cu(OH)]+, [Cu(OH)2]°, [HCuO2]−, [CuO2]2−
- Aqueous Cu(II) polynuclear hydrolysis: [Cu2(OH)2]2+, [Cu3(OH)4]2+
- Aqueous Cu(II) ammine ladder: [Cu(NH3)]2+, [Cu(NH3)2]2+, [Cu(NH3)3]2+, [Cu(NH3)4]2+
- Solids: Cu(s), Cu2O, [Cu(OH)2](s)
- Solvent/ligand refs: H2O, NH3, NH4+

This inventory supports resolving the Cu(II)-ammine stability window against Cu(OH)2(s) and Cu(s), with the noted Cu(I)/Cu(0) boundary uncertainty from the Cu2O source discrepancy.
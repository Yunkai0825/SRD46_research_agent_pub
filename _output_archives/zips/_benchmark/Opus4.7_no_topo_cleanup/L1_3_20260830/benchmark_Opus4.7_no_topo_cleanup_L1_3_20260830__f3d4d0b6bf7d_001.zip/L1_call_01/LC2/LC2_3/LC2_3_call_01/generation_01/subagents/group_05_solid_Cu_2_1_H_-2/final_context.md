## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct.
Return the pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu speciation in ammonia buffer to build an E-pH diagram identifying the Cu(II)-ammine stability window versus Cu(OH)2(s) and Cu(s); treat this as a solution-stability / corrosion-style diagram at 25 C, I=0.1 m.
- Concentrations: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion default) and NH3_total = 0.1 M; polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) and stepwise ammine complexes (n=1..4 for Cu(II), n=2 for Cu(I)) are all physically relevant at these concentrations and must be retained as distinct competitors.
- Duplicates across sources: Atlas and SRD-46 entries with identical stoichiometry, charge, and mu_aligned (e.g. Cu+, Cu2+, [CuO](s) vs CuO, Cu(OH)2 vs [Cu(OH)2](s)) are pure notation duplicates — collapse each pair to a single representative, preferring the source with the more complete ligand coverage (SRD-46) when mu values agree within <2 kJ/mol.
- Hydroxide vs oxide solids: user explicitly requests hydroxide preference — keep Cu(OH)2 (hydrated) and DROP CuO (anhydrous) since they represent the same Cu(II) solid endpoint on this hull; keep Cu2O (only Cu(I) solid tabulated).
- Cu2O source discrepancy: Atlas Cu2O (mu=+2.971) and SRD-46 [(Cu2O)0.5](s) (mu=-3.995, per-Cu basis differs by ~7 kJ/mol per Cu) are NOT numerically identical — flag as diagram-changing ambiguity; retain one (prefer Atlas Cu2O for consistency with the Cu(OH)2 Atlas hydroxide choice) but note the Cu(I)/Cu(0) boundary position carries this uncertainty.
- Phase question: which phase FORMS at each (E,pH) — keep all distinct chemistries, only collapse true source-notation duplicates and the oxide/hydroxide pair per user preference.
- Elemental Cu(s) is mandatory reference; no gases in inventory.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse cross-source notation duplicates with matching stoichiometry and mu (Cu+/[Cu]+, Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) to one representative each, and drop CuO in favor of Cu(OH)2 per the user's explicit hydroxide preference. Retain every distinct hydrolysis product (mononuclear and polynuclear), both Cu(I) and Cu(II) ammine complexes at all tabulated stoichiometries, Cu(s), and one Cu2O representative — flagging that Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) differ by ~7 kJ per Cu so the Cu(I)/Cu(0) boundary inherits that uncertainty.

[Group: elements=Cu phase=solid core_label=Cu$+2:1 H:-2 n_species=4]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-487bcfa1c8c146d2` | anhydrous_solid | `[CuO](s)` | SRD-46 | +0 | 58.433 | 1 |
| `DEDUP-469c48f5e8210844` | anhydrous_solid | `CuO` | Atlas | +0 | 59.789 | 1 |
| `DEDUP-7b19001eaf9b50b1` | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | +0 | 64.312 | 1 |
| `DEDUP-9201e56758e476dd` | hydrated_solid | `Cu(OH)2` | Atlas | +0 | 67.279 | 1 |

## Assistant
<summary>Group has CuO (both sources) and Cu(OH)2 (both sources). Per user preference, drop CuO in favor of Cu(OH)2. For Cu(OH)2, collapse notation duplicates preferring SRD-46.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Kept Cu(OH)2 from SRD-46 as the single Cu(II) hydroxide/oxide solid representative, dropping CuO (both sources) per user's hydroxide preference and the Atlas Cu(OH)2 as notation duplicate.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept: [Cu(OH)2](s) from SRD-46. Dropped CuO (both SRD-46 and Atlas) per the user's explicit hydroxide preference; dropped Atlas Cu(OH)2 as a source-notation duplicate of the SRD-46 entry (μ differs by <3 kJ/mol).
</answer>
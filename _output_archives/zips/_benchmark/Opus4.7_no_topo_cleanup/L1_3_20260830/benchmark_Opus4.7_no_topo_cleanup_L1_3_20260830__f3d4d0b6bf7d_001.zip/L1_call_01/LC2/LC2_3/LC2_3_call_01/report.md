# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    125.63
- elapsed_s (total):  125.63
- llm_iterations:     22
- llm_tool_calls:     14

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Identical charge, nuclearity, and mu_aligned; collapse notation duplicate to SRD-46 representative. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Notation duplicates with identical mu_aligned; keep SRD-46 representative per element instructions. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct mono- and dinuclear Cu(II) hydrolysis species; both physically relevant at 1e-3 M Cu. |
| solid | `Cu$+1:1 H:-1` | `Cu2O` [Atlas] | Per case recommendations, retain Atlas Cu2O as the single Cu(I) solid representative for consistency with Atlas Cu(OH)2 hydroxide choice; SRD-46 [(Cu2O)0.5](s) differs by ~7 kJ/mol per Cu, so Cu(I)/Cu(0) boundary carries this flagged uncertainty. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference entry retained. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) diammine complex, mandatory ammine coverage. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) dihydroxide complex, distinct hydrolysis product. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- anionic hydrolysis species, distinct charge. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2 2- fully deprotonated hydrolysis species, distinct charge. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) monoammine, stepwise ammine coverage required. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) diammine, stepwise ammine coverage required. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II) triammine, stepwise ammine coverage required. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(II) tetraammine, dominant ammine complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu3(OH)4 2+ relevant at 1e-3 M Cu total. |
| aqueous | `L1:1` | yes | Free ammonia ligand reference. |
| aqueous | `L1:1 H:1` | yes | Ammonium ion, needed for NH3/NH4+ pH speciation. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) mandatory metal reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Identical charge, nuclearity, and mu_aligned; collapse notation duplicate to SRD-46 representative. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Notation duplicates with identical mu_aligned; keep SRD-46 representative per element instructions. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain Atlas Cu2O as the single Cu(I) solid representative for consistency with Atlas Cu(OH)2 hydroxide choice; SRD-46 [(Cu2O)0.5](s) differs by ~7 kJ/mol per Cu, so Cu(I)/Cu(0) boundary carries this flagged uncertainty. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| `CuO` | Atlas | dissolution | LC2 element review: Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: c15d39de0bd7436d9d6e40d0cc30965d
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu-NH3 Pourbaix inventory finalized. Notation duplicates (Cu+, Cu2+) collapsed to SRD-46 representatives; both CuO variants dropped in favor of SRD-46 [Cu(OH)2](s) per user's explicit hydroxide preference; Atlas Cu2O retained as the single Cu(I) solid representative with the flagged ~7 kJ/mol per-Cu discrepancy versus SRD-46 [(Cu2O)0.5](s) noted as a Cu(I)/Cu(0) boundary uncertainty. All distinct mono- and polynuclear Cu(II) hydrolysis species ([Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+), the full stepwise Cu(I) diammine and Cu(II) mono/di/tri/tetraammine series, elemental Cu(s), and NH3/NH4+ ligand references are preserved. Table is chemically consistent with the committed case recommendations and element instructions.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Identical charge, nuclearity, and mu_aligned; collapse notation duplicate to SRD-46 representative. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Identical charge, nuclearity, and mu_aligned; collapse notation duplicate to SRD-46 representative. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) diammine complex, mandatory ammine coverage. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation duplicates with identical mu_aligned; keep SRD-46 representative per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation duplicates with identical mu_aligned; keep SRD-46 representative per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydrolysis species; both physically relevant at 1e-3 M Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct mono- and dinuclear Cu(II) hydrolysis species; both physically relevant at 1e-3 M Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) dihydroxide complex, distinct hydrolysis product. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- anionic hydrolysis species, distinct charge. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- fully deprotonated hydrolysis species, distinct charge. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II) monoammine, stepwise ammine coverage required. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II) diammine, stepwise ammine coverage required. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II) triammine, stepwise ammine coverage required. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II) tetraammine, dominant ammine complex. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu3(OH)4 2+ relevant at 1e-3 M Cu total. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) mandatory metal reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: kept — Per case recommendations, retain Atlas Cu2O as the single Cu(I) solid representative for consistency with Atlas Cu(OH)2 hydroxide choice; SRD-46 [(Cu2O)0.5](s) differs by ~7 kJ/mol per Cu, so Cu(I)/Cu(0) boundary carries this flagged uncertainty. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: dropped — Per case recommendations, retain Atlas Cu2O as the single Cu(I) solid representative for consistency with Atlas Cu(OH)2 hydroxide choice; SRD-46 [(Cu2O)0.5](s) differs by ~7 kJ/mol per Cu, so Cu(I)/Cu(0) boundary carries this flagged uncertainty. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Drop CuO (both sources) per user's hydroxide preference; collapse Cu(OH)2 notation duplicates to SRD-46 representative. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry retained. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia ligand reference. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium ion, needed for NH3/NH4+ pH speciation. |

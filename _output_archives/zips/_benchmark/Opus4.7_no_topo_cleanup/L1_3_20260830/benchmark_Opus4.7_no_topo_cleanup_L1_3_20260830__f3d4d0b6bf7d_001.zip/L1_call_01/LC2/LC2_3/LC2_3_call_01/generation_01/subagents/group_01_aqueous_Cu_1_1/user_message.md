[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse cross-source notation duplicates with matching stoichiometry and mu (Cu+/[Cu]+, Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) to one representative each, and drop CuO in favor of Cu(OH)2 per the user's explicit hydroxide preference. Retain every distinct hydrolysis product (mononuclear and polynuclear), both Cu(I) and Cu(II) ammine complexes at all tabulated stoichiometries, Cu(s), and one Cu2O representative — flagging that Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) differ by ~7 kJ per Cu so the Cu(I)/Cu(0) boundary inherits that uncertainty.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 |
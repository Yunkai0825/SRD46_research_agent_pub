All 13 singletons are kept. Each represents a chemically distinct, in-scope species with no within-group duplicate to resolve:

- `(empty)` aqueous — solvent/water reference, keep.
- `L1:1` [Ammonia] and `L1:1 H:1` [HAmmonia]+ — ligand acid/base pair, both required for the ammonia buffer.
- `Cu$+0:1` Cu(s) — mandatory elemental reference.
- `Cu$+1:1 L1:2` [Cu(NH3)2]+ — sole Cu(I) ammine (n=2), required.
- `Cu$+2:1 L1:1..4` — stepwise Cu(II) ammines n=1–4, all retained as distinct competitors at NH3_total=0.1 M.
- `Cu$+2:1 H:-2` [Cu(OH)2], `Cu$+2:1 H:-3` [HCuO2]-, `Cu$+2:1 H:-4` [CuO2]2- — distinct mononuclear Cu(II) hydrolysis species differing in charge/protonation.
- `Cu$+2:3 H:-4` [Cu3(OH)4]2+ — polynuclear hydrolysis product, physically relevant at Cu_total=1e-3 M.

No notation duplicates present in this singleton set; no drops warranted.
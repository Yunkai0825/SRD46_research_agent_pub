# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.00
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-E predominance diagram for Cu-NH3 system.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_3_Cu_ammonia_pourbaix_2D\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
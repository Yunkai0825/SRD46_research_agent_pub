inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m from task; treated as 0.1 mol/L"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "1 mM total Cu (parent element total for redox axis)"},
  {"id": "NH3","lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M total ammonia from task"},
]
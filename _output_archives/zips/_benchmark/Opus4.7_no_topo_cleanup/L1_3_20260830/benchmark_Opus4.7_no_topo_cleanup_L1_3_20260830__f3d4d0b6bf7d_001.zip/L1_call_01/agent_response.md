# L1 agent response

## Final answer (text emitted by the agent)

# Cu–NH₃ Pourbaix Diagram (1 mM Cu, 0.1 M NH₃, 25 °C, I = 0.1 m)

## Doability
Doable. Copper aqua, hydroxo, ammine, and solid phases (Cu(s), Cu₂O, Cu(OH)₂(s)) are all present in the SRD-46 catalog, and the requested method is a native 2-D `pourbaix_sweep`. Cu(OH)₂(s) was retained; the CuO(s) analogue was excluded per the "prefer hydroxide" instruction (see excluded list at the end of the verdict).

## Result
- **System:** Cu = 1 mM, NH₃ = 0.1 M, 25 °C, I = 0.1 m, reference SHE.
- **Domain:** pH 0–14, E = −1.0 to +1.4 V.
- **Grid:** final classified-grid spacing ΔpH = 0.008, ΔE = 0.0016 V (1751 × 1501 samples). All boundaries below are quoted from that classified grid.
- **Topology:** 9 dominant-species labels distributed over 11 connected regions, 21 pairwise boundary curves, 20 triple/edge junctions. Cu₂O and Cu(OH)₂(s) each occupy two disconnected regions because the ammine wedge splits them.

## Analysis

### Region catalogue (dominant Cu species by E–pH area)
Approximate coordinates come from the compact boundary vertices and triple points reported in the verdict.

| Region | Species | Approximate E–pH extent |
|---|---|---|
| DmsReg_1 | **Cu(s)** | entire lower half-plane below the reduction line: E ≲ +0.24 V for pH < 5, sloping down to E ≈ −0.14 V at pH 11.5 and to −0.29 V at pH 14 |
| DmsReg_8 | **Cu²⁺** | acidic oxidising wedge: pH ≲ 5.05 up to pH ≈ 6.16, between the Cu/Cu²⁺ line (~+0.239 V) and the Cu²⁺/[Cu(NH₃)]²⁺ vertical at pH 6.164 |
| DmsReg_11 | **[Cu(NH₃)]²⁺** | narrow vertical strip 6.16 < pH < 6.42, E above ~+0.284 V up to +1.4 V |
| DmsReg_6 | Cu₂O (lower ammine flank) | small pocket 5.05 < pH < 6.89, E ≈ +0.22 to +0.28 V |
| DmsReg_9 | Cu(OH)₂(s) (ammine-flank lobe) | 6.32 < pH < ~8.0, E above ~+0.27 V up to +1.4 V (bounded on left by [Cu(NH₃)]²⁺, on right by [Cu(NH₃)₃]²⁺) |
| DmsReg_10 | **[Cu(NH₃)₃]²⁺** | very small sliver 7.996 < pH < 8.204, E ≈ +0.27–0.35 V (opens vertically to 1.4 V along pH ≈ 8.2) |
| **DmsReg_7** | **[Cu(NH₃)₄]²⁺** | **large upper wedge: 8.20 < pH < 10.14, E from ~+0.26 V up to +1.4 V** |
| DmsReg_5 | Cu(OH)₂(s) (main alkaline field) | pH > 10.14 up to 13.58, E above the Cu₂O/Cu(OH)₂ line (~−0.02 to −0.14 V) up to +1.4 V |
| DmsReg_3 | CuO₂²⁻ (HCuO₂⁻/CuO₂²⁻ family) | strongly alkaline: pH > 13.58 up to 14, E > −0.21 V |
| DmsReg_4 | **[Cu(NH₃)₂]⁺** | Cu(I) ammine field: pH ≈ 7.05–11.47, sandwiched between Cu(s) below (E ≈ −0.14 to +0.12 V) and either Cu₂O or Cu(OH)₂(s) above; extends up to the [Cu(NH₃)₄]²⁺ boundary near E ≈ +0.14–0.26 V |
| DmsReg_2 | Cu₂O (alkaline flank) | thin band 11.47 < pH < 13.58, E ≈ −0.14 to −0.02 V |

### Where soluble Cu(II)–ammines dominate over Cu(OH)₂(s) and Cu(s)
The Cu(II)-ammine complexes form a coherent **upper wedge centred near pH 8–10**, sitting above the Cu(I)-ammine field (which itself displaces Cu(s)):

- **[Cu(NH₃)₄]²⁺ (DmsReg_7)** is the dominant Cu(II) form over **pH ≈ 8.20 → 10.14, E ≈ +0.26 V → +1.4 V** (verdict boundaries DmsRegEq_15, _17, _20). Its left edge against [Cu(NH₃)₂]⁺ runs from (pH 10.324, E +0.135 V) down to (pH 8.204, E +0.262 V); its right edge against Cu(OH)₂(s) is a nearly vertical line at pH ≈ 10.14 (E > +0.276 V, reaching pH 10.14 at E = +1.4 V, junction DmsRegEqJnc_16); the top of the ammine wedge closes at pH 8.204 against [Cu(NH₃)₃]²⁺ (DmsRegEqJnc_19 at pH 8.204, E +1.4 V).
- **[Cu(NH₃)₃]²⁺ (DmsReg_10)** occupies only a thin sliver 7.996 < pH < 8.204 above E ≈ +0.27 V — a genuine but tiny stepwise field between the tetra- and di-ammine.
- **[Cu(NH₃)]²⁺ (DmsReg_11)** appears as an oxidised-acidic finger 6.16 < pH < 6.42 for E > +0.284 V.
- The **Cu(I)-ammine [Cu(NH₃)₂]⁺ (DmsReg_4)** occupies the large intermediate band 7.05 ≲ pH ≲ 11.47 between Cu(s) (below, E from +0.12 V at pH 7 falling to −0.14 V at pH 11.5, boundary DmsRegEq_3) and the Cu(II)-ammines / Cu(OH)₂(s) above.

**Consequence for practical "ammoniacal copper" chemistry (pH 8–10, mildly oxidising E ≈ +0.3–+0.6 V):** both Cu(s) and Cu(OH)₂(s) are thermodynamically displaced by soluble ammines. This is the classic reason ammoniacal solutions dissolve copper metal and prevent Cu(OH)₂ precipitation — the calculation reproduces exactly this window.

### Chemistry behind the boundaries
- **Cu / Cu²⁺ line at E ≈ +0.239 V, pH-independent for pH < 5.05** (DmsRegEq_4): standard Cu²⁺ + 2e⁻ ⇌ Cu, unaffected by protons because neither species carries OH.
- **Slope of Cu / [Cu(NH₃)₂]⁺ boundary** (DmsRegEq_3, from (7.05, +0.119 V) to (11.47, −0.143 V)): the reduction potential drops as pH rises because NH₄⁺ deprotonates to free NH₃ (pKa 9.26 in the reference table), increasing [NH₃] and stabilising Cu(I) as [Cu(NH₃)₂]⁺ (log β = 9.92). The slope is roughly −59 mV per pH unit in the NH₄⁺-buffered region, as expected for a 1 H⁺ / 1 e⁻ coupling through the ammonia ligand.
- **Vertical [Cu(NH₃)₂]⁺ / [Cu(NH₃)₄]²⁺ transition** (DmsRegEq_15, spanning pH 8.20–10.32): a pure redox couple between Cu(I)- and Cu(II)-ammines; potential shifts only weakly with pH because free-NH₃ activity varies little across this range (well above the NH₄⁺/NH₃ pKa).
- **Vertical Cu(OH)₂(s) / [Cu(NH₃)₄]²⁺ line at pH ≈ 10.14**: precipitation/dissolution of Cu(OH)₂ competes with ammine complexation; above pH ~10.1 the hydroxide wins because [OH⁻] rises faster than the ammine formation constant can compensate at 0.1 M total NH₃ and only 1 mM Cu. This is the sharp upper-pH edge of the "leaching window".
- **Cu²⁺ / Cu(OH)₂(s) is *not* a direct boundary** at 1 mM Cu / 0.1 M NH₃: the ammine wedge fully separates them. Without ammonia, Cu²⁺ would precipitate near pH 5–6 (log Ksp for Cu(OH)₂ dissolution = −8.68 in the reference table); ammonia postpones and then replaces that precipitation.
- **Very alkaline edge (pH > 13.58)**: Cu(OH)₂(s) redissolves as CuO₂²⁻ (log β = −39.84), the amphoteric high-pH branch.

### Convergence and coverage
The verdict was produced from the final classified label grid (ΔpH = 0.008, ΔE = 0.0016 V) with cut transitions bracketed by adjacent samples to that precision, and the two example line cuts (at pH 7 and at E +0.2 V) both traverse the expected sequence of regions with no gaps or unclassified cells reported. Region measures are consistent (largest field Cu(s) = 14.72; smallest resolved region [Cu(NH₃)₃]²⁺ = 0.041 in the internal coordinate frame — small but grid-resolved). No convergence warnings are surfaced in the verdict.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — rendered E–pH diagram
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — classified label map (region catalogue / cell table)
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — full topology verdict (regions, boundaries, junctions)
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — full speciation, concentrations, saturation indices, convergence
- `L1_call_01/thermodynamic_reference_constants.md` — log β / Ksp values used

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

A fixed E/Eh value during a pH scan is a condition and remains a one-axis
`pH_sweep`. Treat E/Eh as a Pourbaix dimension only when it is independently
varied with pH or an E–pH predominance field is explicitly requested.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. Call
   `list_outputs` when you need to locate supporting files, then use the
   narrow inspection tools or `read_output_file` on artifacts that answer a
   claim the verdict does not resolve:
   * For a **pH-speciation sweep**, begin with the automatically supplied
     speciation verdict, then use
     component fraction-envelope CSVs, full fraction/concentration tables,
     and `*_state_metrics.csv` when additional sampled evidence is needed.
   * For a **Pourbaix or other predominance sweep**, begin with each
     automatically supplied per-element predominance verdict. It contains
     canonical IDs for connected regions, boundaries/equilibria, and junctions
     (or dimension-qualified N-D features). Use `inspect_verdict_section` for
     one persisted report section and `inspect_topology_feature` for exactly
     one canonical ID. Never request or quote a raw topology JSON dump. Use the
     integer label-map/cell-table CSV for additional classified-grid evidence
     and the full-speciation CSV for concentrations, solids, saturation
     indices, and convergence. If a species occupies disconnected regions,
     preserve their separate verdict IDs; never silently collapse them.
     Compact boundary geometry supports topology and approximate location, but
     exact cuts in the verdict come from the final classified label grid.
     Likewise, quote pKa, log K, or E values only from the automatically
     supplied thermodynamic-reference table or after opening the actual
     persisted card/artifact that contains them, not from general knowledge.
     The table exposes the card's `log_beta` field; call it a pKa or another
     named constant only when the corresponding reaction/species definition
     justifies that name.
   * For either route, inspect and report convergence coverage before drawing
     chemical conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "")`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='') — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Compute a 2-D Pourbaix (E-pH) diagram for Cu in the presence of ammonia, and identify the region where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s).]
[Tasks:
Build a two-dimensional Pourbaix diagram for a single solution containing 1 mM total copper and 0.1 M total ammonia at 25 C and ionic strength 0.1 m. Sweep pH from 0 to 14 and E (vs SHE) across the water stability window (roughly -1.0 to +1.4 V). Prefer hydroxide solids (Cu(OH)2) over the oxide analogues where both are tabulated. Report the topology of the diagram: list every region with its dominant species, and specifically identify the E-pH window(s) where soluble Cu(II)-ammine complexes (e.g. Cu(NH3)4^2+ and related) dominate over solid Cu(OH)2 and over metallic Cu(s). Provide the label map, region catalogue, and full-speciation output.
]

## Assistant
<summary>Running the pipeline for a Cu/NH3 Pourbaix diagram at 1 mM Cu, 0.1 M NH3, pH 0-14, E -1.0 to +1.4 V, I=0.1 m.</summary>
<tool_call>run_analysis_pipeline(notes='Cu-NH3 Pourbaix; 1 mM Cu to…')</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pourbaix_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 6,
  "output_files": [
    "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.json",
    "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv"
  ],
  "elapsed_s": 1563.4,
  "default_verdict_count": 1,
  "default_verdict_paths": [
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z+0] | [Ammonia] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1].[L1]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[L1]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L1]:+4 | SRD-46 | true |
| [Cu$+2].[L1]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L1]:+3 | SRD-46 | true |
| [Cu$+2].[L1]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[L1].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| Cu$+1(2).OH2.z+0(s) | Cu2O | dissolution | -0.5205 | Cu$+1:+2 H:-2 | Atlas | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Ammonia]
- Constraints:
  -- component totals (M): Cu=0.001;Ammonia=0.1
- Potential reference: SHE
- Domain: pH [0, 14]; E_V [-1, 1.4]
- Coarse grid spacing: ΔpH=not reported; ΔE_V=not reported
- Final classified-grid spacing: ΔpH=0.008; ΔE_V=0.0016
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: Cu2O
- Dms_3: CuO22-
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu(OH)2](s)
- Dms_6: [Cu(Ammo)4]2+
- Dms_7: Cu2+
- Dms_8: [Cu(Ammo)3]2+
- Dms_9: [Cu(Ammo)]2+

## Topology stats
- 9 dominant-species labels
- 11 connected regions
- 21 pairwise boundary curves
- 11 internal junction features
- 9 junction features at a sweep limit
- Disconnected dominant species:
  -- Cu2O: 2 separate regions [DmsReg_2, DmsReg_6]
  -- [Cu(OH)2](s): 2 separate regions [DmsReg_5, DmsReg_9]

## Example classified-grid cut along pH
- Fixed coordinates in domain order: [not reported, 0.2]
- Fixed sample indices in domain order: [None, 750]
- samples 0–709, pH [0, 5.672]: Cu (Dms_1)
- samples 710–879, pH [5.68, 7.032]: Cu2O (Dms_2)
  -- preceding label change is bracketed by adjacent samples [5.672, 5.68]
- samples 880–1102, pH [7.04, 8.816]: [Cu(Ammo)2]+ (Dms_4)
  -- preceding label change is bracketed by adjacent samples [7.032, 7.04]
- samples 1103–1270, pH [8.824, 10.16]: [Cu(Ammo)4]2+ (Dms_6)
  -- preceding label change is bracketed by adjacent samples [8.816, 8.824]
- samples 1271–1697, pH [10.168, 13.576]: [Cu(OH)2](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples [10.16, 10.168]
- samples 1698–1750, pH [13.584, 14]: CuO22- (Dms_3)
  -- preceding label change is bracketed by adjacent samples [13.576, 13.584]

## Example classified-grid cut along E_V
- Fixed coordinates in domain order: [7, not reported]
- Fixed sample indices in domain order: [875, None]
- samples 0–701, E_V [-1, 0.1216]: Cu (Dms_1)
- samples 702–766, E_V [0.1232, 0.2256]: Cu2O (Dms_2)
  -- preceding label change is bracketed by adjacent samples [0.1216, 0.1232]
- samples 767–784, E_V [0.2272, 0.2544]: [Cu(Ammo)2]+ (Dms_4)
  -- preceding label change is bracketed by adjacent samples [0.2256, 0.2272]
- samples 785–1500, E_V [0.256, 1.4]: [Cu(OH)2](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples [0.2544, 0.256]

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 14.724544
  -- Neighboring regions:
    --- DmsReg_2 {Cu2O} via DmsRegEq_1
    --- DmsReg_6 {Cu2O} via DmsRegEq_2
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_3
    --- DmsReg_8 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_1, DmsRegEqJnc_4, DmsRegEqJnc_6, DmsRegEqJnc_13]
- **DmsReg_2 {Cu2O}**
  -- Measure in the solver coordinate frame: 0.3146368
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_1
    --- DmsReg_3 {CuO22-} via DmsRegEq_5
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_7
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_14, DmsRegEqJnc_3]
- **DmsReg_3 {CuO22-}**
  -- Measure in the solver coordinate frame: 0.6685568
  -- Neighboring regions:
    --- DmsReg_2 {Cu2O} via DmsRegEq_5
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_14, DmsRegEqJnc_15]
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 1.0506752
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_3
    --- DmsReg_6 {Cu2O} via DmsRegEq_6
    --- DmsReg_2 {Cu2O} via DmsRegEq_7
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_13
    --- DmsReg_9 {[Cu(OH)2](s)} via DmsRegEq_14
    --- DmsReg_7 {[Cu(Ammo)4]2+} via DmsRegEq_15
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_7, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_9, DmsRegEqJnc_8]
- **DmsReg_5 {[Cu(OH)2](s)}**
  -- Measure in the solver coordinate frame: 4.887424
  -- Neighboring regions:
    --- DmsReg_2 {Cu2O} via DmsRegEq_8
    --- DmsReg_3 {CuO22-} via DmsRegEq_12
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_7 {[Cu(Ammo)4]2+} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_15, DmsRegEqJnc_5, DmsRegEqJnc_16]
- **DmsReg_6 {Cu2O}**
  -- Measure in the solver coordinate frame: 0.1756672
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_2
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_6
    --- DmsReg_9 {[Cu(OH)2](s)} via DmsRegEq_9
    --- DmsReg_8 {Cu2+} via DmsRegEq_10
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_11, DmsRegEqJnc_10]
- **DmsReg_7 {[Cu(Ammo)4]2+}**
  -- Measure in the solver coordinate frame: 2.3641344
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_15
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_17
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_20
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_16, DmsRegEqJnc_19]
- **DmsReg_8 {Cu2+}**
  -- Measure in the solver coordinate frame: 7.1376768
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_4
    --- DmsReg_6 {Cu2O} via DmsRegEq_10
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_21
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_20]
- **DmsReg_9 {[Cu(OH)2](s)}**
  -- Measure in the solver coordinate frame: 2.0965248
  -- Neighboring regions:
    --- DmsReg_6 {Cu2O} via DmsRegEq_9
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_14
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_18
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_19
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_7, DmsRegEqJnc_9, DmsRegEqJnc_17, DmsRegEqJnc_18]
- **DmsReg_10 {[Cu(Ammo)3]2+}**
  -- Measure in the solver coordinate frame: 0.0408832
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_16
    --- DmsReg_9 {[Cu(OH)2](s)} via DmsRegEq_18
    --- DmsReg_7 {[Cu(Ammo)4]2+} via DmsRegEq_20
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_17, DmsRegEqJnc_19]
- **DmsReg_11 {[Cu(Ammo)]2+}**
  -- Measure in the solver coordinate frame: 0.1808896
  -- Neighboring regions:
    --- DmsReg_6 {Cu2O} via DmsRegEq_11
    --- DmsReg_9 {[Cu(OH)2](s)} via DmsRegEq_19
    --- DmsReg_8 {Cu2+} via DmsRegEq_21
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_18, DmsRegEqJnc_20]

### boundary curves/equilibria
- **DmsRegEq_1: Cu | Cu2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, -0.292], [11.812, -0.164], [11.764, -0.1592], [11.676, -0.156], [11.548, -0.1464], [11.468, -0.1432]]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 411, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 354, 363, 376, 398, 410], "t_params": [0.0, 0.8641, 0.8831, 0.9178, 0.9684, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, -0.292], [11.812, -0.164], [11.764, -0.1592], [11.676, -0.156], [11.548, -0.1464], [11.468, -0.1432]], "envelope_t": [0.0, 0.8641, 0.8831, 0.9178, 0.9684, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, -0.292], [11.468, -0.1432]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Cu | Cu2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.052, 0.1192], [5.436, 0.2152], [5.348, 0.2184], [5.3, 0.2232], [5.212, 0.2264], [5.052, 0.2376]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 325, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 262, 275, 284, 297, 324], "t_params": [0.0, 0.808, 0.8519, 0.876, 0.9199, 1.0], "envelope_n": 6, "envelope_pts": [[7.052, 0.1192], [5.436, 0.2152], [5.348, 0.2184], [5.3, 0.2232], [5.212, 0.2264], [5.052, 0.2376]], "envelope_t": [0.0, 0.808, 0.8519, 0.876, 0.9199, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.052, 0.1192], [5.052, 0.2376]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.468, -0.1432], [10.1, -0.1368], [9.588, -0.124], [9.228, -0.1064], [8.372, -0.0328], [7.052, 0.1192]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 717, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 175, 247, 303, 456, 716], "t_params": [0.0, 0.3089, 0.4246, 0.506, 0.7, 1.0], "envelope_n": 6, "envelope_pts": [[11.468, -0.1432], [10.1, -0.1368], [9.588, -0.124], [9.228, -0.1064], [8.372, -0.0328], [7.052, 0.1192]], "envelope_t": [0.0, 0.3089, 0.4246, 0.506, 0.7, 1.0], "adaptive_n": 3, "adaptive_pts": [[11.468, -0.1432], [9.228, -0.1064], [7.052, 0.1192]], "adaptive_t": [0.0, 0.5059, 1.0]}
- **DmsRegEq_4: Cu | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[5.052, 0.2376], [4.404, 0.2376], [4.404, 0.2392], [0.388, 0.2392], [0.22, 0.2392], [0.0, 0.2392]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 634, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 81, 82, 584, 605, 633], "t_params": [0.0, 0.1282, 0.1285, 0.9232, 0.9565, 1.0], "envelope_n": 6, "envelope_pts": [[5.052, 0.2376], [4.404, 0.2376], [4.404, 0.2392], [0.388, 0.2392], [0.22, 0.2392], [0.0, 0.2392]], "envelope_t": [0.0, 0.1282, 0.1285, 0.9232, 0.9565, 1.0], "adaptive_n": 2, "adaptive_pts": [[5.052, 0.2376], [0.0, 0.2392]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Cu2O | CuO22-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[14.0, -0.212], [13.796, -0.1752], [13.78, -0.1752], [13.74, -0.1656], [13.724, -0.1656], [13.58, -0.14]]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 99, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 49, 51, 62, 64, 98], "t_params": [0.0, 0.4858, 0.5233, 0.6197, 0.6572, 1.0], "envelope_n": 6, "envelope_pts": [[14.0, -0.212], [13.796, -0.1752], [13.78, -0.1752], [13.74, -0.1656], [13.724, -0.1656], [13.58, -0.14]], "envelope_t": [0.0, 0.4858, 0.5233, 0.6197, 0.6572, 1.0], "adaptive_n": 2, "adaptive_pts": [[14.0, -0.212], [13.58, -0.14]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Cu2O | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.052, 0.1192], [7.052, 0.164], [7.044, 0.164], [7.028, 0.2104], [6.972, 0.2392], [6.892, 0.2568]]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 107, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 28, 29, 60, 85, 106], "t_params": [0.0, 0.1815, 0.214, 0.4129, 0.6681, 1.0], "envelope_n": 6, "envelope_pts": [[7.052, 0.1192], [7.052, 0.164], [7.044, 0.164], [7.028, 0.2104], [6.972, 0.2392], [6.892, 0.2568]], "envelope_t": [0.0, 0.1815, 0.214, 0.4129, 0.6681, 1.0], "adaptive_n": 2, "adaptive_pts": [[7.052, 0.1192], [6.892, 0.2568]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Cu2O | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.468, -0.1432], [11.468, -0.1416], [11.468, -0.14], [11.468, -0.1384], [11.468, -0.1368], [11.468, -0.0152]]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 81, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3, 4, 80], "t_params": [0.0, 0.0125, 0.025, 0.0375, 0.05, 1.0], "envelope_n": 6, "envelope_pts": [[11.468, -0.1432], [11.468, -0.1416], [11.468, -0.14], [11.468, -0.1384], [11.468, -0.1368], [11.468, -0.0152]], "envelope_t": [0.0, 0.0125, 0.025, 0.0375, 0.05, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.468, -0.1432], [11.468, -0.0152]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: Cu2O | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[13.58, -0.14], [12.084, -0.052], [12.036, -0.0472], [11.948, -0.044], [11.82, -0.0344], [11.468, -0.0152]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 343, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 242, 251, 264, 286, 342], "t_params": [0.0, 0.7083, 0.7311, 0.7727, 0.8334, 1.0], "envelope_n": 6, "envelope_pts": [[13.58, -0.14], [12.084, -0.052], [12.036, -0.0472], [11.948, -0.044], [11.82, -0.0344], [11.468, -0.0152]], "envelope_t": [0.0, 0.7083, 0.7311, 0.7727, 0.8334, 1.0], "adaptive_n": 2, "adaptive_pts": [[13.58, -0.14], [11.468, -0.0152]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: Cu2O | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.892, 0.2568], [6.836, 0.2584], [6.788, 0.2632], [6.756, 0.2632], [6.708, 0.268], [6.42, 0.284]]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 77, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 8, 17, 21, 30, 76], "t_params": [0.0, 0.1185, 0.2205, 0.2881, 0.3901, 1.0], "envelope_n": 6, "envelope_pts": [[6.892, 0.2568], [6.836, 0.2584], [6.788, 0.2632], [6.756, 0.2632], [6.708, 0.268], [6.42, 0.284]], "envelope_t": [0.0, 0.1185, 0.2205, 0.2881, 0.3901, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.892, 0.2568], [6.42, 0.284]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: Cu2O | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[5.052, 0.2376], [5.228, 0.2488], [5.596, 0.2648], [5.628, 0.268], [5.884, 0.2776], [6.164, 0.284]]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 169, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 29, 85, 91, 129, 168], "t_params": [0.0, 0.1584, 0.4894, 0.5182, 0.7484, 1.0], "envelope_n": 6, "envelope_pts": [[5.052, 0.2376], [5.228, 0.2488], [5.596, 0.2648], [5.628, 0.268], [5.884, 0.2776], [6.164, 0.284]], "envelope_t": [0.0, 0.1584, 0.4894, 0.5182, 0.7484, 1.0], "adaptive_n": 2, "adaptive_pts": [[5.052, 0.2376], [6.164, 0.284]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Cu2O | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.164, 0.284], [6.172, 0.284], [6.18, 0.284], [6.188, 0.284], [6.196, 0.284], [6.42, 0.284]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 33, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 3, 4, 32], "t_params": [0.0, 0.0313, 0.0625, 0.0938, 0.125, 1.0], "envelope_n": 6, "envelope_pts": [[6.164, 0.284], [6.172, 0.284], [6.18, 0.284], [6.188, 0.284], [6.196, 0.284], [6.42, 0.284]], "envelope_t": [0.0, 0.0313, 0.0625, 0.0938, 0.125, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.164, 0.284], [6.42, 0.284]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_12: CuO22- | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[13.58, -0.14], [13.58, 0.0968], [13.58, 0.1672], [13.58, 0.4632], [13.58, 1.0264], [13.58, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 964, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 148, 192, 377, 729, 963], "t_params": [0.0, 0.1538, 0.1995, 0.3917, 0.7574, 1.0], "envelope_n": 6, "envelope_pts": [[13.58, -0.14], [13.58, 0.0968], [13.58, 0.1672], [13.58, 0.4632], [13.58, 1.0264], [13.58, 1.4]], "envelope_t": [0.0, 0.1538, 0.1995, 0.3917, 0.7574, 1.0], "adaptive_n": 2, "adaptive_pts": [[13.58, -0.14], [13.58, 1.4]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: [Cu(Ammo)2]+ | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[11.468, -0.0152], [10.884, 0.0536], [10.748, 0.0728], [10.716, 0.0744], [10.46, 0.1096], [10.324, 0.1352]]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 238, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 116, 145, 150, 204, 237], "t_params": [0.0, 0.5095, 0.6285, 0.6562, 0.8801, 1.0], "envelope_n": 6, "envelope_pts": [[11.468, -0.0152], [10.884, 0.0536], [10.748, 0.0728], [10.716, 0.0744], [10.46, 0.1096], [10.324, 0.1352]], "envelope_t": [0.0, 0.5095, 0.6285, 0.6562, 0.8801, 1.0], "adaptive_n": 2, "adaptive_pts": [[11.468, -0.0152], [10.324, 0.1352]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: [Cu(Ammo)2]+ | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.892, 0.2568], [7.108, 0.2552], [7.108, 0.2536], [7.604, 0.2552], [7.86, 0.2616], [7.996, 0.2712]]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 152, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 28, 29, 92, 128, 151], "t_params": [0.0, 0.1953, 0.1967, 0.6452, 0.8767, 1.0], "envelope_n": 6, "envelope_pts": [[6.892, 0.2568], [7.108, 0.2552], [7.108, 0.2536], [7.604, 0.2552], [7.86, 0.2616], [7.996, 0.2712]], "envelope_t": [0.0, 0.1953, 0.1967, 0.6452, 0.8767, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.892, 0.2568], [7.996, 0.2712]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_15: [Cu(Ammo)2]+ | [Cu(Ammo)4]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.324, 0.1352], [9.844, 0.1432], [9.308, 0.164], [9.06, 0.18], [8.764, 0.204], [8.204, 0.2616]]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 345, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 65, 145, 186, 238, 344], "t_params": [0.0, 0.2259, 0.4784, 0.5953, 0.7351, 1.0], "envelope_n": 6, "envelope_pts": [[10.324, 0.1352], [9.844, 0.1432], [9.308, 0.164], [9.06, 0.18], [8.764, 0.204], [8.204, 0.2616]], "envelope_t": [0.0, 0.2259, 0.4784, 0.5953, 0.7351, 1.0], "adaptive_n": 3, "adaptive_pts": [[10.324, 0.1352], [9.308, 0.164], [8.204, 0.2616]], "adaptive_t": [0.0, 0.4784, 1.0]}
- **DmsRegEq_16: [Cu(Ammo)2]+ | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.204, 0.2616], [8.172, 0.2616], [8.148, 0.2648], [8.084, 0.2664], [8.028, 0.2712], [7.996, 0.2712]]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 33, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 4, 9, 18, 28, 32], "t_params": [0.0, 0.1535, 0.2697, 0.5768, 0.8465, 1.0], "envelope_n": 6, "envelope_pts": [[8.204, 0.2616], [8.172, 0.2616], [8.148, 0.2648], [8.084, 0.2664], [8.028, 0.2712], [7.996, 0.2712]], "envelope_t": [0.0, 0.1535, 0.2697, 0.5768, 0.8465, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.204, 0.2616], [7.996, 0.2712]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_17: [Cu(OH)2](s) | [Cu(Ammo)4]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[10.324, 0.1352], [10.228, 0.1592], [10.18, 0.1832], [10.148, 0.2232], [10.14, 0.276], [10.14, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 815, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 27, 48, 77, 111, 814], "t_params": [0.0, 0.0716, 0.1105, 0.1476, 0.1862, 1.0], "envelope_n": 6, "envelope_pts": [[10.324, 0.1352], [10.228, 0.1592], [10.18, 0.1832], [10.148, 0.2232], [10.14, 0.276], [10.14, 1.4]], "envelope_t": [0.0, 0.0716, 0.1105, 0.1476, 0.1862, 1.0], "adaptive_n": 3, "adaptive_pts": [[10.324, 0.1352], [10.14, 0.276], [10.14, 1.4]], "adaptive_t": [0.0, 0.1709, 1.0]}
- **DmsRegEq_18: [Cu(OH)2](s) | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[7.996, 0.2712], [8.068, 0.2808], [8.124, 0.2968], [8.156, 0.3192], [8.172, 0.3512], [8.172, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_17]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 729, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 15, 32, 50, 72, 728], "t_params": [0.0, 0.0579, 0.1043, 0.1355, 0.164, 1.0], "envelope_n": 6, "envelope_pts": [[7.996, 0.2712], [8.068, 0.2808], [8.124, 0.2968], [8.156, 0.3192], [8.172, 0.3512], [8.172, 1.4]], "envelope_t": [0.0, 0.0579, 0.1043, 0.1355, 0.164, 1.0], "adaptive_n": 3, "adaptive_pts": [[7.996, 0.2712], [8.172, 0.3512], [8.172, 1.4]], "adaptive_t": [0.0, 0.1556, 1.0]}
- **DmsRegEq_19: [Cu(OH)2](s) | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.42, 0.284], [6.388, 0.292], [6.372, 0.3032], [6.356, 0.3064], [6.324, 0.3576], [6.324, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_18]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 711, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 9, 18, 22, 58, 710], "t_params": [0.0, 0.0282, 0.0448, 0.0588, 0.1103, 1.0], "envelope_n": 6, "envelope_pts": [[6.42, 0.284], [6.388, 0.292], [6.372, 0.3032], [6.356, 0.3064], [6.324, 0.3576], [6.324, 1.4]], "envelope_t": [0.0, 0.0282, 0.0448, 0.0588, 0.1103, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.42, 0.284], [6.324, 1.4]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_20: [Cu(Ammo)4]2+ | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[8.204, 0.2616], [8.204, 0.2632], [8.204, 0.2648], [8.204, 0.868], [8.204, 0.8792], [8.204, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_19]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 713, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 379, 386, 712], "t_params": [0.0, 0.0014, 0.0028, 0.5327, 0.5425, 1.0], "envelope_n": 6, "envelope_pts": [[8.204, 0.2616], [8.204, 0.2632], [8.204, 0.2648], [8.204, 0.868], [8.204, 0.8792], [8.204, 1.4]], "envelope_t": [0.0, 0.0014, 0.0028, 0.5327, 0.5425, 1.0], "adaptive_n": 2, "adaptive_pts": [[8.204, 0.2616], [8.204, 1.4]], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_21: Cu2+ | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [[6.164, 0.284], [6.164, 0.2856], [6.164, 0.2872], [6.164, 0.7544], [6.164, 0.9096], [6.164, 1.4]]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_20]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "raw_n": 699, "compact_n": 6, "compact_target_n": 6, "compact_indices": [0, 1, 2, 294, 391, 698], "t_params": [0.0, 0.0014, 0.0029, 0.4215, 0.5606, 1.0], "envelope_n": 6, "envelope_pts": [[6.164, 0.284], [6.164, 0.2856], [6.164, 0.2872], [6.164, 0.7544], [6.164, 0.9096], [6.164, 1.4]], "envelope_t": [0.0, 0.0014, 0.0029, 0.4215, 0.5606, 1.0], "adaptive_n": 2, "adaptive_pts": [[6.164, 0.284], [6.164, 1.4]], "adaptive_t": [0.0, 1.0]}

### junction features
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2O, [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.468, "E_V": -0.1432}
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_8, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 13.58, "E_V": -0.14}
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, [Cu(Ammo)2]+, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_7, DmsRegEq_8, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 11.468, "E_V": -0.0152}
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2O, [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.052, "E_V": 0.1192}
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(OH)2](s), [Cu(Ammo)4]2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_13, DmsRegEq_15, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 10.324, "E_V": 0.1352}
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2O, Cu2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 5.052, "E_V": 0.2376}
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, [Cu(Ammo)2]+, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_6, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_6, DmsRegEq_9, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.892, "E_V": 0.2568}
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(Ammo)4]2+, [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_7, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_15, DmsRegEq_16, DmsRegEq_20]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 8.204, "E_V": 0.2616}
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(OH)2](s), [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_14, DmsRegEq_16, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 7.996, "E_V": 0.2712}
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, Cu2+, [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_8, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.164, "E_V": 0.284}
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, [Cu(OH)2](s), [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_9, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_9, DmsRegEq_11, DmsRegEq_19]
  -- At sweep limit: false
  -- Geometry: compact point {"pH": 6.42, "E_V": 0.284}
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2O]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.292}
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 0.0, "E_V": 0.2392}
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2O, CuO22-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 14.0, "E_V": -0.212}
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 13.58, "E_V": 1.4}
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)4]2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 10.14, "E_V": 1.4}
- **DmsRegEqJnc_17** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_9, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 8.172, "E_V": 1.4}
- **DmsRegEqJnc_18** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_9, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_19]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 6.324, "E_V": 1.4}
- **DmsRegEqJnc_19** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)4]2+, [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_20]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 8.204, "E_V": 1.4}
- **DmsRegEqJnc_20** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2+, [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_21]
  -- At sweep limit: true
  -- Geometry: compact point {"pH": 6.164, "E_V": 1.4}

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Ammo)2]+, Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, Cu2O, [Cu(OH)2](s), Cu]
  -- excluded: [[(Cu2O)0.5](s), CuO(s), CuO, Cu(OH)2]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_analysis_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Verdict provides full topology with 11 regions. Cu-ammine complexes dominate in a wedge around pH ~7-11 bounded by Cu2O below and Cu(OH)2 above. Writing analysis now.</summary>
<tool_call>record_analysis(analysis_markdown='## Doability\nDoable. Cu + …', artifact_paths='L1_call_01/so…)</tool_call>

## User
<tool_result>
OK — analysis recorded (7430 chars, 5 artifacts).
</tool_result>

## LLM Response
<answer>
# Cu–NH₃ Pourbaix Diagram (1 mM Cu, 0.1 M NH₃, 25 °C, I = 0.1 m)

## Doability
Doable. Copper aqua, hydroxo, ammine, and solid phases (Cu(s), Cu₂O, Cu(OH)₂(s)) are all present in the SRD-46 catalog, and the requested method is a native 2-D `pourbaix_sweep`. Cu(OH)₂(s) was retained; the CuO(s) analogue was excluded per the "prefer hydroxide" instruction (see excluded list at the end of the verdict).

## Result
- **System:** Cu = 1 mM, NH₃ = 0.1 M, 25 °C, I = 0.1 m, reference SHE.
- **Domain:** pH 0–14, E = −1.0 to +1.4 V.
- **Grid:** final classified-grid spacing ΔpH = 0.008, ΔE = 0.0016 V (1751 × 1501 samples). All boundaries below are quoted from that classified grid.
- **Topology:** 9 dominant-species labels distributed over 11 connected regions, 21 pairwise boundary curves, 20 triple/edge junctions. Cu₂O and Cu(OH)₂(s) each occupy two disconnected regions because the ammine wedge splits them.

## Analysis

### Region catalogue (dominant Cu species by E–pH area)
Approximate coordinates come from the compact boundary vertices and triple points reported in the verdict.

| Region | Species | Approximate E–pH extent |
|---|---|---|
| DmsReg_1 | **Cu(s)** | entire lower half-plane below the reduction line: E ≲ +0.24 V for pH < 5, sloping down to E ≈ −0.14 V at pH 11.5 and to −0.29 V at pH 14 |
| DmsReg_8 | **Cu²⁺** | acidic oxidising wedge: pH ≲ 5.05 up to pH ≈ 6.16, between the Cu/Cu²⁺ line (~+0.239 V) and the Cu²⁺/[Cu(NH₃)]²⁺ vertical at pH 6.164 |
| DmsReg_11 | **[Cu(NH₃)]²⁺** | narrow vertical strip 6.16 < pH < 6.42, E above ~+0.284 V up to +1.4 V |
| DmsReg_6 | Cu₂O (lower ammine flank) | small pocket 5.05 < pH < 6.89, E ≈ +0.22 to +0.28 V |
| DmsReg_9 | Cu(OH)₂(s) (ammine-flank lobe) | 6.32 < pH < ~8.0, E above ~+0.27 V up to +1.4 V (bounded on left by [Cu(NH₃)]²⁺, on right by [Cu(NH₃)₃]²⁺) |
| DmsReg_10 | **[Cu(NH₃)₃]²⁺** | very small sliver 7.996 < pH < 8.204, E ≈ +0.27–0.35 V (opens vertically to 1.4 V along pH ≈ 8.2) |
| **DmsReg_7** | **[Cu(NH₃)₄]²⁺** | **large upper wedge: 8.20 < pH < 10.14, E from ~+0.26 V up to +1.4 V** |
| DmsReg_5 | Cu(OH)₂(s) (main alkaline field) | pH > 10.14 up to 13.58, E above the Cu₂O/Cu(OH)₂ line (~−0.02 to −0.14 V) up to +1.4 V |
| DmsReg_3 | CuO₂²⁻ (HCuO₂⁻/CuO₂²⁻ family) | strongly alkaline: pH > 13.58 up to 14, E > −0.21 V |
| DmsReg_4 | **[Cu(NH₃)₂]⁺** | Cu(I) ammine field: pH ≈ 7.05–11.47, sandwiched between Cu(s) below (E ≈ −0.14 to +0.12 V) and either Cu₂O or Cu(OH)₂(s) above; extends up to the [Cu(NH₃)₄]²⁺ boundary near E ≈ +0.14–0.26 V |
| DmsReg_2 | Cu₂O (alkaline flank) | thin band 11.47 < pH < 13.58, E ≈ −0.14 to −0.02 V |

### Where soluble Cu(II)–ammines dominate over Cu(OH)₂(s) and Cu(s)
The Cu(II)-ammine complexes form a coherent **upper wedge centred near pH 8–10**, sitting above the Cu(I)-ammine field (which itself displaces Cu(s)):

- **[Cu(NH₃)₄]²⁺ (DmsReg_7)** is the dominant Cu(II) form over **pH ≈ 8.20 → 10.14, E ≈ +0.26 V → +1.4 V** (verdict boundaries DmsRegEq_15, _17, _20). Its left edge against [Cu(NH₃)₂]⁺ runs from (pH 10.324, E +0.135 V) down to (pH 8.204, E +0.262 V); its right edge against Cu(OH)₂(s) is a nearly vertical line at pH ≈ 10.14 (E > +0.276 V, reaching pH 10.14 at E = +1.4 V, junction DmsRegEqJnc_16); the top of the ammine wedge closes at pH 8.204 against [Cu(NH₃)₃]²⁺ (DmsRegEqJnc_19 at pH 8.204, E +1.4 V).
- **[Cu(NH₃)₃]²⁺ (DmsReg_10)** occupies only a thin sliver 7.996 < pH < 8.204 above E ≈ +0.27 V — a genuine but tiny stepwise field between the tetra- and di-ammine.
- **[Cu(NH₃)]²⁺ (DmsReg_11)** appears as an oxidised-acidic finger 6.16 < pH < 6.42 for E > +0.284 V.
- The **Cu(I)-ammine [Cu(NH₃)₂]⁺ (DmsReg_4)** occupies the large intermediate band 7.05 ≲ pH ≲ 11.47 between Cu(s) (below, E from +0.12 V at pH 7 falling to −0.14 V at pH 11.5, boundary DmsRegEq_3) and the Cu(II)-ammines / Cu(OH)₂(s) above.

**Consequence for practical "ammoniacal copper" chemistry (pH 8–10, mildly oxidising E ≈ +0.3–+0.6 V):** both Cu(s) and Cu(OH)₂(s) are thermodynamically displaced by soluble ammines. This is the classic reason ammoniacal solutions dissolve copper metal and prevent Cu(OH)₂ precipitation — the calculation reproduces exactly this window.

### Chemistry behind the boundaries
- **Cu / Cu²⁺ line at E ≈ +0.239 V, pH-independent for pH < 5.05** (DmsRegEq_4): standard Cu²⁺ + 2e⁻ ⇌ Cu, unaffected by protons because neither species carries OH.
- **Slope of Cu / [Cu(NH₃)₂]⁺ boundary** (DmsRegEq_3, from (7.05, +0.119 V) to (11.47, −0.143 V)): the reduction potential drops as pH rises because NH₄⁺ deprotonates to free NH₃ (pKa 9.26 in the reference table), increasing [NH₃] and stabilising Cu(I) as [Cu(NH₃)₂]⁺ (log β = 9.92). The slope is roughly −59 mV per pH unit in the NH₄⁺-buffered region, as expected for a 1 H⁺ / 1 e⁻ coupling through the ammonia ligand.
- **Vertical [Cu(NH₃)₂]⁺ / [Cu(NH₃)₄]²⁺ transition** (DmsRegEq_15, spanning pH 8.20–10.32): a pure redox couple between Cu(I)- and Cu(II)-ammines; potential shifts only weakly with pH because free-NH₃ activity varies little across this range (well above the NH₄⁺/NH₃ pKa).
- **Vertical Cu(OH)₂(s) / [Cu(NH₃)₄]²⁺ line at pH ≈ 10.14**: precipitation/dissolution of Cu(OH)₂ competes with ammine complexation; above pH ~10.1 the hydroxide wins because [OH⁻] rises faster than the ammine formation constant can compensate at 0.1 M total NH₃ and only 1 mM Cu. This is the sharp upper-pH edge of the "leaching window".
- **Cu²⁺ / Cu(OH)₂(s) is *not* a direct boundary** at 1 mM Cu / 0.1 M NH₃: the ammine wedge fully separates them. Without ammonia, Cu²⁺ would precipitate near pH 5–6 (log Ksp for Cu(OH)₂ dissolution = −8.68 in the reference table); ammonia postpones and then replaces that precipitation.
- **Very alkaline edge (pH > 13.58)**: Cu(OH)₂(s) redissolves as CuO₂²⁻ (log β = −39.84), the amphoteric high-pH branch.

### Convergence and coverage
The verdict was produced from the final classified label grid (ΔpH = 0.008, ΔE = 0.0016 V) with cut transitions bracketed by adjacent samples to that precision, and the two example line cuts (at pH 7 and at E +0.2 V) both traverse the expected sequence of regions with no gaps or unclassified cells reported. Region measures are consistent (largest field Cu(s) = 14.72; smallest resolved region [Cu(NH₃)₃]²⁺ = 0.041 in the internal coordinate frame — small but grid-resolved). No convergence warnings are surfaced in the verdict.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — rendered E–pH diagram
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — classified label map (region catalogue / cell table)
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — full topology verdict (regions, boundaries, junctions)
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — full speciation, concentrations, saturation indices, convergence
- `L1_call_01/thermodynamic_reference_constants.md` — log β / Ksp values used
</answer>

[Purpose: Compute a 2-D Pourbaix (E-pH) diagram for Cu in the presence of ammonia, and identify the region where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s).]
[Tasks:
Build a two-dimensional Pourbaix diagram for a single solution containing 1 mM total copper and 0.1 M total ammonia at 25 C and ionic strength 0.1 m. Sweep pH from 0 to 14 and E (vs SHE) across the water stability window (roughly -1.0 to +1.4 V). Prefer hydroxide solids (Cu(OH)2) over the oxide analogues where both are tabulated. Report the topology of the diagram: list every region with its dominant species, and specifically identify the E-pH window(s) where soluble Cu(II)-ammine complexes (e.g. Cu(NH3)4^2+ and related) dominate over solid Cu(OH)2 and over metallic Cu(s). Provide the label map, region catalogue, and full-speciation output.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

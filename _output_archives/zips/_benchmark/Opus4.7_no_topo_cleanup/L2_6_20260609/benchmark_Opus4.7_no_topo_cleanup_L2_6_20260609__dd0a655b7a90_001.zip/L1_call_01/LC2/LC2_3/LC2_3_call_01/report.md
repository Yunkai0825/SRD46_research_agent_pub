# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    147.88
- elapsed_s (total):  147.89
- llm_iterations:     25
- llm_tool_calls:     21

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate Cu+ aqueous species; prefer SRD-46 per rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+; prefer SRD-46 over Atlas per plan rule 1. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Distinct nuclearity and charge (mononuclear +1 vs dinuclear +2); both retained per rule 2. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Cu$+1:1 L1:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1 H:1` | yes | Reference species; sole member. |
| solid | `Cu$+0:1` | yes | Valid thermodynamics; sole member. |
| solid | `Cu$+1:1 H:-1` | yes | Valid thermodynamics; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate Cu+ aqueous species; prefer SRD-46 per rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+; prefer SRD-46 over Atlas per plan rule 1.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries keep SRD-46.) |

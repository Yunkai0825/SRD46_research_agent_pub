# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    54.24
- elapsed_s (total):  54.25
- llm_iterations:     16
- llm_tool_calls:     10

- n_groups:           17
- n_multi_groups:     4
- n_singletons:       13
- n_decisions:        17
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of aqueous Cu+ monocation; prefer SRD-46 entry. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+; prefer SRD-46 over Atlas with identical mu. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu(II) hydroxo species differ in nuclearity and charge, so both are kept as distinct chemistry. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO/tenorite; between two Cu(OH)2 entries, keep SRD-46 critically-evaluated value. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid thermodynamics; only species in group. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; unique core. |
| aqueous | `L1:1 H:1` | yes | Reference species (mu=0); unique core. |
| solid | `Cu$+0:1` | yes | Valid mu_aligned_kJ; unique core. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; unique core. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu+ monocation; prefer SRD-46 entry.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+; prefer SRD-46 over Atlas with identical mu.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO/tenorite; between two Cu(OH)2 entries, keep SRD-46 critically-evaluated value.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO/tenorite; between two Cu(OH)2 entries, keep SRD-46 critically-evaluated value.) |

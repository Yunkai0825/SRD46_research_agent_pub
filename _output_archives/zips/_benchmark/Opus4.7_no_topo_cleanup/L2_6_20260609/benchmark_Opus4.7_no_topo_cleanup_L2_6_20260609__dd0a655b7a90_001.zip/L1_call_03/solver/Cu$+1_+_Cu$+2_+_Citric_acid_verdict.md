# Speciation Calculation Report: Cu$+1 + Cu$+2 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | Citric acid | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu2(Citr)2]2- | aqueous | L1:+2 Cu$+2:+2 | — | -82.7615 | -82.7615 |
| [Cu2(Citr)2(OH)]3- | aqueous | L1:+2 Cu$+2:+2 H:-1 | — | -63.9261 | -63.9261 |
| [Cu2(Citr)(OH)] | aqueous | L1:+1 Cu$+2:+2 H:-1 | — | -27.7394 | -27.7394 |
| [Cu2(Citr)2(OH)2]4- | aqueous | L1:+2 Cu$+2:+2 H:-2 | — | -36.1868 | -36.1868 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 3.30: Cu2O (4.37e-05 M)
- pH 11.20: Cu2O (5.00e-04 M), [Cu(OH)2](s) (2.72e-04 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu+                 peak 100.0% at pH 0.0
  Cu2O                peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  3.6  →  Cu+
  pH   3.6– 14.0  →  Cu2O

Crossover pH values:
  Cu+ ↔ Cu2O  at pH ≈ 3.56  (each ~50%)

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu2+                peak 100.0% at pH 0.0
  HCuO2-              peak 9.4% at pH 14.0
  CuO22-              peak 69.0% at pH 14.0
  [Cu2(Citr)2]2-      peak 61.9% at pH 2.8
  [Cu2(Citr)2(OH)]3-  peak 74.5% at pH 4.1
  [Cu2(Citr)2(OH)2]4-  peak 100.0% at pH 10.1
  [Cu(OH)2](s)        peak 99.4% at pH 12.5

Dominant species by pH region:
  pH   0.0–  2.3  →  Cu2+
  pH   2.3–  3.4  →  [Cu2(Citr)2]2-
  pH   3.4–  4.9  →  [Cu2(Citr)2(OH)]3-
  pH   4.9– 11.4  →  [Cu2(Citr)2(OH)2]4-
  pH  11.4– 14.0  →  [Cu(OH)2](s)
  pH  14.0– 14.0  →  CuO22-

Crossover pH values:
  Cu2+ ↔ [Cu2(Citr)2]2-  at pH ≈ 2.26  (each ~47%)
  Cu2+ ↔ [Cu2(Citr)2(OH)]3-  at pH ≈ 2.77  (each ~18%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.91  (each ~46%)
  [Cu2(Citr)2]2- ↔ [Cu2(Citr)2(OH)]3-  at pH ≈ 3.30  (each ~46%)
  [Cu2(Citr)2]2- ↔ [Cu2(Citr)2(OH)2]4-  at pH ≈ 4.08  (each ~12%)
  [Cu2(Citr)2(OH)]3- ↔ [Cu2(Citr)2(OH)2]4-  at pH ≈ 4.86  (each ~49%)
  [Cu2(Citr)2(OH)2]4- ↔ [Cu(OH)2](s)  at pH ≈ 11.30  (each ~50%)

=== Citric acid (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HCitric acid2-      peak 100.0% at pH 0.0
  Citric acid         peak 100.0% at pH 14.0
  [Cu2(Citr)2]2-      peak 12.4% at pH 2.8
  [Cu2(Citr)2(OH)]3-  peak 14.9% at pH 4.1
  [Cu2(Citr)2(OH)2]4-  peak 20.0% at pH 10.1

Dominant species by pH region:
  pH   0.0–  5.7  →  HCitric acid2-
  pH   5.7– 14.0  →  Citric acid

```
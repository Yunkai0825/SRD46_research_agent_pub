# Speciation Calculation Report: Ni$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Glycine | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Glyc)3]- | aqueous | L1:+3 Ni$+2:+1 | — | -80.4785 | -80.4785 |
| [Ni(Glyc)2] | aqueous | L1:+2 Ni$+2:+1 | — | -60.3874 | -60.3874 |
| [Ni(Glyc)]+ | aqueous | L1:+1 Ni$+2:+1 | — | -32.7622 | -32.7622 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 11.00: [Ni(OH)2](s) (5.00e-05 M)

## Speciation Analysis

```
=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Ni2+                peak 100.0% at pH 0.0
  [Ni(OH)3]-          peak 63.1% at pH 14.0
  [Ni(Glyc)3]-        peak 86.9% at pH 10.9
  [Ni(Glyc)2]         peak 69.2% at pH 7.9
  [Ni(Glyc)]+         peak 58.2% at pH 6.7
  [Ni(OH)2](s)        peak 96.9% at pH 12.5

Dominant species by pH region:
  pH   0.0–  6.2  →  Ni2+
  pH   6.2–  7.2  →  [Ni(Glyc)]+
  pH   7.2–  8.8  →  [Ni(Glyc)2]
  pH   8.8– 11.5  →  [Ni(Glyc)3]-
  pH  11.5– 13.9  →  [Ni(OH)2](s)
  pH  13.9– 14.0  →  [Ni(OH)3]-

Crossover pH values:
  Ni2+ ↔ [Ni(Glyc)2]  at pH ≈ 6.68  (each ~21%)
  Ni2+ ↔ [Ni(Glyc)]+  at pH ≈ 6.19  (each ~47%)
  [Ni(OH)3]- ↔ [Ni(OH)2](s)  at pH ≈ 13.90  (each ~50%)
  [Ni(Glyc)3]- ↔ [Ni(Glyc)2]  at pH ≈ 8.70  (each ~49%)
  [Ni(Glyc)3]- ↔ [Ni(Glyc)]+  at pH ≈ 7.92  (each ~15%)
  [Ni(Glyc)3]- ↔ [Ni(OH)2](s)  at pH ≈ 11.41  (each ~48%)
  [Ni(Glyc)2] ↔ [Ni(Glyc)]+  at pH ≈ 7.18  (each ~46%)
  [Ni(Glyc)2] ↔ [Ni(OH)2](s)  at pH ≈ 11.05  (each ~10%)

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Glycine (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HGlycine            peak 100.0% at pH 0.0
  Glycine             peak 100.0% at pH 14.0
  [Ni(Glyc)3]-        peak 52.2% at pH 10.9
  [Ni(Glyc)2]         peak 27.7% at pH 7.9
  [Ni(Glyc)]+         peak 11.6% at pH 6.7

Dominant species by pH region:
  pH   0.0–  9.1  →  HGlycine
  pH   9.1– 11.1  →  [Ni(Glyc)3]-
  pH  11.1– 14.0  →  Glycine

```
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    103.19
- elapsed_s (total):  103.20
- llm_iterations:     21
- llm_tool_calls:     16

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate: identical Ni2+ aqueous cation; prefer SRD-46 notation. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) means distinct species per dedup rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear Ni(II) hydroxo anion in different notation; prefer SRD-46 per plan rule 1. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. NiO is anhydrous polymorph; addendum prefers hydrated hydroxide for aqueous Ni speciation, so NiO dropped. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; no duplicates. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate: identical Ni2+ aqueous cation; prefer SRD-46 notation.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Ni(II) hydroxo anion in different notation; prefer SRD-46 per plan rule 1.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. NiO is anhydrous polymorph; addendum prefers hydrated hydroxide for aqueous Ni speciation, so NiO dropped.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Ni(OH)2 (Atlas) and [Ni(OH)2](s) (SRD-46) are the same species; prefer SRD-46. NiO is anhydrous polymorph; addendum prefers hydrated hydroxide for aqueous Ni speciation, so NiO dropped.) |

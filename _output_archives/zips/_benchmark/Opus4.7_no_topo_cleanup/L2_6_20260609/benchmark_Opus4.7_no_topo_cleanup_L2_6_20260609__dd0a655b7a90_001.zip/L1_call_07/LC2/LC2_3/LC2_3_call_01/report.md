# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_07\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_07\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    52.83
- elapsed_s (total):  52.84
- llm_iterations:     16
- llm_tool_calls:     9

- n_groups:           13
- n_multi_groups:     5
- n_singletons:       8
- n_decisions:        13
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` | Identical species (Zn2+ aqueous cation); prefer SRD-46 notation per plan. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Identical species (mononuclear ZnOH+, aqueous, +1); keep SRD-46 over Atlas per rule 1. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same charge, nuclearity, and core stoichiometry; [HZnO2]- is a dehydrated notation of [Zn(OH)3]-. Kept SRD-46 entry which also has lower mu_aligned. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | True duplicate: zincate written as ZnO2^2- (Atlas) vs Zn(OH)4^2- (SRD-46) — same charge, nuclearity, aqueous phase; keep SRD-46. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs, preferring SRD-46 epsilon over Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ (reference H+/water species); only member of group. |
| aqueous | `L1:1` | yes | Glycinate anion with valid thermodynamics; sole member. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine (HGlycine), reference species with mu=0; sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(OH)2(aq) hydrolysis species with valid mu; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn-glycinate 1:1 complex with valid mu; sole member. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn-glycinate 1:2 complex with valid mu; sole member. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn-glycinate 1:3 complex with valid mu; sole member. |
| solid | `Zn$+0:1` | yes | Metallic zinc reference solid with valid mu; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | dedup: excluded (Identical species (Zn2+ aqueous cation); prefer SRD-46 notation per plan.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Identical species (mononuclear ZnOH+, aqueous, +1); keep SRD-46 over Atlas per rule 1.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same charge, nuclearity, and core stoichiometry; [HZnO2]- is a dehydrated notation of [Zn(OH)3]-. Kept SRD-46 entry which also has lower mu_aligned.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (True duplicate: zincate written as ZnO2^2- (Atlas) vs Zn(OH)4^2- (SRD-46) — same charge, nuclearity, aqueous phase; keep SRD-46.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs, preferring SRD-46 epsilon over Atlas duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs, preferring SRD-46 epsilon over Atlas duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs, preferring SRD-46 epsilon over Atlas duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept distinct Zn(OH)2 polymorphs, preferring SRD-46 epsilon over Atlas duplicate.) |

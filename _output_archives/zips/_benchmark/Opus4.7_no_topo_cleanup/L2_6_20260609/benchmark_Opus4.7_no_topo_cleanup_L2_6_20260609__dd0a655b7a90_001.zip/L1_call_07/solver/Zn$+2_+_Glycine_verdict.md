# Speciation Calculation Report: Zn$+2 + Glycine

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Glycine | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +90.1815 | +90.1815 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Glyc)3]- | aqueous | L1:+3 Zn$+2:+1 | — | -68.8740 | -68.8740 |
| [Zn(Glyc)2] | aqueous | L1:+2 Zn$+2:+1 | — | -54.5649 | -54.5649 |
| [Zn(Glyc)]+ | aqueous | L1:+1 Zn$+2:+1 | — | -29.4496 | -29.4496 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 7.10: Zn(OH)2 (alpha) (1.00e-04 M)
- pH 13.40: all solids dissolved

## Speciation Analysis

```
=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Zn2+                peak 100.0% at pH 0.0
  [Zn(OH)3]-          peak 9.0% at pH 13.4
  [Zn(OH)4]2-         peak 97.5% at pH 14.0
  [Zn(Glyc)2]         peak 12.4% at pH 7.8
  [Zn(Glyc)]+         peak 46.4% at pH 7.0

Dominant species by pH region:
  pH   0.0–  7.0  →  Zn2+
  pH   7.0–  7.7  →  [Zn(Glyc)]+
  pH   7.7– 10.9  →  [Zn(Glyc)2]
  pH  10.9– 12.5  →  [Zn(OH)3]-
  pH  12.5– 14.0  →  [Zn(OH)4]2-

Crossover pH values:
  Zn2+ ↔ [Zn(Glyc)2]  at pH ≈ 7.33  (each ~12%)
  Zn2+ ↔ [Zn(Glyc)]+  at pH ≈ 6.97  (each ~45%)
  [Zn(Glyc)2] ↔ [Zn(Glyc)]+  at pH ≈ 7.68  (each ~12%)

=== Glycine (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HGlycine            peak 100.0% at pH 0.0
  Glycine             peak 100.0% at pH 14.0
  [Zn(Glyc)]+         peak 9.3% at pH 7.0

Dominant species by pH region:
  pH   0.0–  9.6  →  HGlycine
  pH   9.6– 14.0  →  Glycine

```
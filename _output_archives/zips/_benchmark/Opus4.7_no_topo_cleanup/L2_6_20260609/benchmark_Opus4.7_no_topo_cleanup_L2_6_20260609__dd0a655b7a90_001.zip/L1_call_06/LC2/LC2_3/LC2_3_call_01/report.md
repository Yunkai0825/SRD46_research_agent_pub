# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_06\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_06\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    114.21
- elapsed_s (total):  114.22
- llm_iterations:     22
- llm_tool_calls:     17

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | Identical species (Ni2+, +2, mononuclear aqueous, mu=0); prefer SRD-46 per rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearities (mononuclear vs tetranuclear) are distinct species and both must be retained. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | [HNiO2]- and [Ni(OH)3]- are notation variants of the same mononuclear Ni(II) hydroxo anion; keep SRD-46 entry. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 Ni(OH)2 preferred over Atlas duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide polymorph. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ (reference state at 0); sole member. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `Ni$+2:1 L1:1 H:-1` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; metallic Ni reference solid. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member of its core group. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member of its core group. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (Identical species (Ni2+, +2, mononuclear aqueous, mu=0); prefer SRD-46 per rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded ([HNiO2]- and [Ni(OH)3]- are notation variants of the same mononuclear Ni(II) hydroxo anion; keep SRD-46 entry.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 preferred over Atlas duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide polymorph.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 Ni(OH)2 preferred over Atlas duplicate; NiO dropped per addendum favoring hydrated oxyhydroxide polymorph.) |

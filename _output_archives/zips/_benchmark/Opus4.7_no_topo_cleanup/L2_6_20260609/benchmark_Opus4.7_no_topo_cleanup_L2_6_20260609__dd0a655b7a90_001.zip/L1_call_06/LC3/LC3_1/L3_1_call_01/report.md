# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_06\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 9.85
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Single-point speciation at pH 7; pH_sweep with 1 DOF fits a fixed-pH evaluation.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_06\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
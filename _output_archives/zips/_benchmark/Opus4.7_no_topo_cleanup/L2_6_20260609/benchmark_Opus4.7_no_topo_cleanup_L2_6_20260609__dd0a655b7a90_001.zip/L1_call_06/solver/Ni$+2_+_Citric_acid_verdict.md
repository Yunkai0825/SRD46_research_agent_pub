# Speciation Calculation Report: Ni$+2 + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| L1 | Citric acid | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HCitric acid2- | aqueous | L1:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L1:+1 | — | -0.0000 | +32.2485 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(Citr)2]4- | aqueous | L1:+2 Ni$+2:+1 | — | -46.4035 | -46.4035 |
| [Ni(Citr)]- | aqueous | L1:+1 Ni$+2:+1 | — | -29.5658 | -29.5658 |
| [Ni2(Citr)2(OH)2]4- | aqueous | L1:+2 H:-2 Ni$+2:+2 | — | +24.6572 | +24.6572 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 10.00: [Ni(OH)2](s) (1.94e-04 M)

## Speciation Analysis

```
=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Ni2+                peak 99.8% at pH 0.0
  [Ni(OH)3]-          peak 63.1% at pH 14.0
  [Ni(Citr)2]4-       peak 74.1% at pH 7.8
  [Ni(Citr)]-         peak 86.7% at pH 4.0
  [Ni2(Citr)2(OH)2]4-  peak 76.2% at pH 9.9
  [Ni(OH)2](s)        peak 99.6% at pH 11.5

Dominant species by pH region:
  pH   0.0–  2.9  →  Ni2+
  pH   2.9–  5.4  →  [Ni(Citr)]-
  pH   5.4–  9.4  →  [Ni(Citr)2]4-
  pH   9.4– 10.2  →  [Ni2(Citr)2(OH)2]4-
  pH  10.2– 13.9  →  [Ni(OH)2](s)
  pH  13.9– 14.0  →  [Ni(OH)3]-

Crossover pH values:
  Ni2+ ↔ [Ni(Citr)2]4-  at pH ≈ 3.99  (each ~7%)
  Ni2+ ↔ [Ni(Citr)]-  at pH ≈ 2.82  (each ~50%)
  [Ni(OH)3]- ↔ [Ni(OH)2](s)  at pH ≈ 13.90  (each ~50%)
  [Ni(Citr)2]4- ↔ [Ni(Citr)]-  at pH ≈ 5.32  (each ~50%)
  [Ni(Citr)2]4- ↔ [Ni2(Citr)2(OH)2]4-  at pH ≈ 9.37  (each ~43%)
  [Ni(Citr)2]4- ↔ [Ni(OH)2](s)  at pH ≈ 9.98  (each ~15%)
  [Ni(Citr)]- ↔ [Ni2(Citr)2(OH)2]4-  at pH ≈ 9.04  (each ~20%)
  [Ni2(Citr)2(OH)2]4- ↔ [Ni(OH)2](s)  at pH ≈ 10.11  (each ~44%)

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Citric acid (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HCitric acid2-      peak 100.0% at pH 0.0
  Citric acid         peak 100.0% at pH 14.0
  [Ni(Citr)2]4-       peak 29.7% at pH 7.8
  [Ni(Citr)]-         peak 17.3% at pH 4.0
  [Ni2(Citr)2(OH)2]4-  peak 15.2% at pH 9.9

Dominant species by pH region:
  pH   0.0–  5.7  →  HCitric acid2-
  pH   5.7– 14.0  →  Citric acid

```
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_05\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_05\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    71.71
- elapsed_s (total):  71.72
- llm_iterations:     18
- llm_tool_calls:     12

- n_groups:           13
- n_multi_groups:     4
- n_singletons:       9
- n_decisions:        13
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | Identical aqueous Ni2+ species in both sources with equal mu; keep SRD-46 per preference. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) makes these distinct species despite shared core stoichiometry. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same species in different notation (Ni(II) trihydroxo anion); keep SRD-46 version. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 hydrated Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated hydroxide. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid (zero reference) mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Ni2+ species in both sources with equal mu; keep SRD-46 per preference.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same species in different notation (Ni(II) trihydroxo anion); keep SRD-46 version.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 hydrated Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated hydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 hydrated Ni(OH)2 preferred over Atlas duplicate; anhydrous NiO dropped per addendum favoring hydrated hydroxide.) |

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_05\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 23.70
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation at a single pH; 1-D pH sweep covers it with one DOF.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_05\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
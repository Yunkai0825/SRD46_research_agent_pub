# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_6_CuNiZn_chelator_matrix_3x3\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    83.97
- elapsed_s (total):  83.98
- llm_iterations:     21
- llm_tool_calls:     16

- n_groups:           14
- n_multi_groups:     4
- n_singletons:       10
- n_decisions:        14
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate: same aqueous Cu+ cation, identical charge and nuclearity; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+ with identical mu; SRD-46 preferred over Atlas. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) — distinct species despite shared core ratio. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; neutral reference species retained. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid Cu(OH)2(aq) thermodynamics. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid HCuO2- thermodynamics. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid CuO2 2- thermodynamics. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid Cu-EDTA complex thermodynamics. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid trinuclear Cu hydroxo complex. |
| aqueous | `L1:1` | yes | Valid free EDTA ligand. |
| aqueous | `L1:1 H:1` | yes | Valid protonated EDTA species. |
| solid | `Cu$+0:1` | yes | Valid metallic Cu thermodynamics. |
| solid | `Cu$+1:1 H:-1` | yes | Valid Cu2O(s) thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate: same aqueous Cu+ cation, identical charge and nuclearity; prefer SRD-46 notation.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+ with identical mu; SRD-46 preferred over Atlas.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous CuO; SRD-46 entry chosen over Atlas duplicate.) |

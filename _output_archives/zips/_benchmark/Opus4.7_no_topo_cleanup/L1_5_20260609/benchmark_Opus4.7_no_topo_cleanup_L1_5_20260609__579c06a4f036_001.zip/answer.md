## Answer

EDTA is by far the stronger Cu(II) sequesterer of the two ligands across pH 3–10. At 1 mM Cu(II) and 5 mM ligand, EDTA holds essentially 100 % of the dissolved Cu(II) as the single complex **[Cu(EDTA)]²⁻** at every pH from 3.0 to 10.0 — there is no measurable dissociation or speciation change within the requested window, so free [Cu²⁺] is suppressed to vanishingly small values throughout. This is consistent with EDTA's hexadentate (N₂O₄) coordination: once the central amino-carboxylate cage closes around Cu²⁺ it is so thermodynamically locked (log K₁ ≈ 18.7 for CuEDTA²⁻) that even strong protonation of the free carboxylates at low pH cannot pry the metal loose above pH 3.

NTA, being only tetradentate (N,O,O,O), tells a markedly different story. At pH 3 the speciation is already a mixture: about **96 % [Cu(NTA)]⁻ and ~4 % of the protonated complex [Cu(NTA)H]** (with a trace of the bis-complex). As pH rises, [Cu(NTA)H] deprotonates and [Cu(NTA)]⁻ dominates through the mid-pH region; with a 5-fold ligand excess the bis-complex [Cu(NTA)₂]⁴⁻ also grows in at higher pH. Free Cu²⁺ with NTA is therefore higher than with EDTA at every pH — and conspicuously so at the acid end, where the appearance of the protonated [Cu(NTA)H] species is the first sign that the chelate is beginning to dissociate. With NTA's smaller donor set and lower log K (≈ 12.7), proton competition for the carboxylates is felt much sooner than it is for EDTA.

**Where each complex starts to dissociate at low pH:**
- **Cu–EDTA:** no observable dissociation down to pH 3.0 — the complex remains 100 % intact across the entire requested range. Onset of acid dissociation lies below pH 3.
- **Cu–NTA:** dissociation onset is already evident at pH 3.0, where the protonated form [Cu(NTA)H] accounts for ~4 % of the Cu and rises as pH falls. The complex is therefore beginning to come apart right at the lower edge of the studied range.

**Bottom line:** EDTA keeps free [Cu²⁺] lower across the whole pH 3–10 window and is the better sequestering agent under these conditions; NTA holds Cu well in the neutral-to-alkaline region but starts to release it through protonated intermediates as the solution becomes acidic.

## Evidence
- Cu–EDTA envelope (`L1_call_01/.../EDTA_envelope_Cu$+2.csv`): `[Cu(EDTA)]2- = 1.000000` at every pH from 3.0 to 10.0.
- Cu–NTA envelope (`L1_call_02/.../NTA_envelope_Cu$+2.csv`) at pH 3.0: `[Cu(NTA)H]=0.038, [Cu(NTA)2]4-=0.0001, [Cu(NTA)]-=0.962` — i.e. ~96 % mono-NTA, ~4 % protonated mono-NTA, trace bis-complex.
- Both runs converged cleanly (verdict files in each solver dir confirm the speciation calculation is well-posed at T = 25 °C, I = 0.1 m).

## Artifacts
- Cu–EDTA system:
  - `L1_call_01/solver/Cu$+1_+_Cu$+2_+_EDTA_frac_Cu.png` (metal speciation fractions vs pH)
  - `L1_call_01/solver/Cu$+1_+_Cu$+2_+_EDTA_frac_L1.png` (ligand speciation vs pH)
  - `L1_call_01/solver/Cu$+1_+_Cu$+2_+_EDTA_log_conc.png` and `.csv` (log [species] vs pH, including free [Cu²⁺])
  - `L1_call_01/solver/Cu$+1_+_Cu$+2_+_EDTA_envelope_Cu$+2.csv` (dominant Cu(II) species per pH)
  - `L1_call_01/solver/Cu$+1_+_Cu$+2_+_EDTA_verdict.md` (per-call sanity verdict)
- Cu–NTA system:
  - `L1_call_02/solver/Cu$+1_+_Cu$+2_+_NTA_frac_Cu.png`
  - `L1_call_02/solver/Cu$+1_+_Cu$+2_+_NTA_frac_L1.png`
  - `L1_call_02/solver/Cu$+1_+_Cu$+2_+_NTA_log_conc.png` and `.csv`
  - `L1_call_02/solver/Cu$+1_+_Cu$+2_+_NTA_envelope_Cu$+2.csv`
  - `L1_call_02/solver/Cu$+1_+_Cu$+2_+_NTA_verdict.md`
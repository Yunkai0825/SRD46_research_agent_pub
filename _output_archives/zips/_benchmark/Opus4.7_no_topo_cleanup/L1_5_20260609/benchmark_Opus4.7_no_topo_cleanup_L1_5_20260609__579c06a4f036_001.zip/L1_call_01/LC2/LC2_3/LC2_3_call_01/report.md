# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    128.97
- elapsed_s (total):  128.98
- llm_iterations:     24
- llm_tool_calls:     19

- n_groups:           14
- n_multi_groups:     4
- n_singletons:       10
- n_decisions:        14
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate Cu+ aqueous cation; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate: identical Cu2+ aqueous species with same charge and mu; SRD-46 preferred over Atlas. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear hydroxo-copper(II) species differ in nuclearity and charge; both retained as distinct chemistry. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Addendum prefers hydrated Cu(OH)2 over anhydrous tenorite (CuO); between duplicate Cu(OH)2 entries, SRD-46 is preferred over Atlas. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; reference/solvent species retained. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; chemically sensible Cu(OH)2 aqueous complex. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; chemically sensible HCuO2- species. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; chemically sensible CuO2 2- species. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; Cu-EDTA complex retained. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; polynuclear Cu hydroxo complex retained. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; free EDTA ligand retained. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; protonated HEDTA species retained. |
| solid | `Cu$+0:1` | yes | Valid mu_aligned_kJ; metallic Cu retained. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; Cu2O solid retained. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate Cu+ aqueous cation; prefer SRD-46 notation.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate: identical Cu2+ aqueous species with same charge and mu; SRD-46 preferred over Atlas.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous tenorite (CuO); between duplicate Cu(OH)2 entries, SRD-46 is preferred over Atlas.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Addendum prefers hydrated Cu(OH)2 over anhydrous tenorite (CuO); between duplicate Cu(OH)2 entries, SRD-46 is preferred over Atlas.) |

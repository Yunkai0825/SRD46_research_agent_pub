inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu$+2"],     "value": 1e-3,   "basis": "known", "note": "1 mM Cu(II) total"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "5 mM EDTA total"},
]
[Purpose: Compute Cu(II) speciation with EDTA across pH 3-10 to determine free [Cu2+] and the low-pH dissociation point of the Cu-EDTA complex.]
[Tasks:
Model a solution containing 1 mM Cu(II) total and 5 mM EDTA over pH 3-10 at 25 C and ionic strength 0.1 m. Report the dominant Cu species at each pH, the free [Cu2+] (and log[Cu2+]) trajectory across the range, and identify the pH below which the Cu-EDTA complex begins to dissociate (i.e. where free Cu2+ or Cu-hydroxide/aquo species become significant).
]
[Pair: pair_key=`m68_l6277`, metal_id=68, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand6277_beta72_net4907`
  - `metal68_ligand6277_beta79_net4907`
[Screen report]
# Eq-map screen — m68_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6277_beta32_net4907` | `[HL] + [H] <=> [H2L]` | vlm_108257@(25.0,1.0) = K+6.190 | 6 | +6.030 / +6.160 / +6.290 / +7.020 | vlm_108254@(25.0,0.1) = K+6.130 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand6277_beta68_net4907` | `[H4L] + [H] <=> [H5L]` | vlm_108291@(25.0,1.0) = K-1.400 | 4 | -1.700 / -1.550 / -1.550 / -1.400 | vlm_108289@(25.0,0.1) = K-1.500 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand6277_beta72_net4907` | `[H5L] + [H] <=> [H6L]` | vlm_108295@(25.0,1.0) = K+0.000 | 2 | -0.400 / -0.200 / -0.200 / +0.000 | vlm_108295@(25.0,1.0) = K+0.000 (+0.00 °C, +0.90 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal68_ligand6277_beta79_net4907` | `[L] + [H] <=> [HL]` | vlm_108233@(25.0,1.0) = K+8.730 | 14 | +8.730 / +9.940 / +9.799 / +10.948 | vlm_108224@(25.0,0.1) = K+9.520 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal68_ligand6277_beta53_net4907` | `[H2L] + [H] <=> [H3L]` | vlm_108274@(25.0,1.0) = K+2.520 | 4 | +2.520 / +2.615 / +2.635 / +2.790 | vlm_108272@(25.0,0.1) = K+2.690 (+0.00 °C, +0.00 M) | `—` |
| 6 | `metal68_ligand6277_beta64_net4907` | `[H3L] + [H] <=> [H4L]` | vlm_108284@(25.0,1.0) = K+2.020 | 4 | +2.000 / +2.035 / +2.067 / +2.200 | vlm_108282@(25.0,0.1) = K+2.000 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

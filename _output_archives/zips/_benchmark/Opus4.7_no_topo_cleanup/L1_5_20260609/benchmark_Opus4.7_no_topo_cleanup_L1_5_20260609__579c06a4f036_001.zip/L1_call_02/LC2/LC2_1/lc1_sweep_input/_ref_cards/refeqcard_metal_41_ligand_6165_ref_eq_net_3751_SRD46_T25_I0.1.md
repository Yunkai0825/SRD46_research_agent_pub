# Free Energy Analysis Card

**System**: metal_41 + ligand_6165
**Metals**: [Cu]2+
**Ligands**: [NTA]
**Generated**: 2026-06-09 10:09:57 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Cu$+2 | Metal component: [Cu]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [NTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Cu$+2 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [NTA] | -3 | 0.01 | [[H]3[L1]] | NIST SRD-46 | ligand_6165 | O=C(O)CN(CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | Cu$+2 | [Cu]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [NTA] | O=C(O)CN(CC(=O)O)CC(=O)O | C | [-1, -1, -1, 3, 3, 3] | true |
| L1 | [NTA] | O=C(O)CN(CC(=O)O)CC(=O)O | N | [-3] | false |
| L1 | [NTA] | O=C(O)CN(CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Cu$+2 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [NTA] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [NTA] | [L1] -> [[H]3[L1]] | 3 | 0 | +0.0000 | +0.0000 | fallback |  |

### 3.3 Edge Case Notes

- EC-2: No protonation states found for 'NTA' (expected canonical H3L); using free ligand as reference (shift=0) (EC-2).

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Cu]2+ + [NTA] | 25.0 | 0.1 | 3751 | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [NTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L1].[z-3] | [NTA] | -3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Cu$+2].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Cu$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]2+ + [NTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [Cu$+2].[L1]2.[z-4] | [Cu(NTA)2]4- | -4 | aqueous | +17.4000 | -99.3138 | -99.3138 | -99.3138 | [Cu$+2]:+1, [L1]:+2 | vlm_105539 | *** |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(NTA)H] | +0 | aqueous | +14.3000 | -81.6200 | -81.6200 | -81.6200 | [Cu$+2]:+1, [[H][L1]]:+1 | vlm_105534, vlm_105542 | *** |
| [Cu$+2].[L1].[z-1] | [Cu(NTA)]- | -1 | aqueous | +12.7000 | -72.4877 | -72.4877 | -72.4877 | [Cu$+2]:+1, [L1]:+1 | vlm_105534 | *** |

### 5.2 Dissolution / Solid Species

(No dissolution / solid species species in this system.)

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 4 |
| Included in calculation | 4 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 3 |
| Unresolved (no species in card) | 1 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_105534 | [<NTA>] + [<Cu2+>] <=> [<Cu2+><NTA>] | +12.7000 | 25.0 | 0.100 | yes | [Cu(NTA)]-, [Cu(NTA)H] |
| 2 | vlm_105539 | [<NTA>]^2 + [<Cu2+>] <=> [<Cu2+><NTA>2] | +17.4000 | 25.0 | 0.100 | yes | [Cu(NTA)2]4- |
| 3 | vlm_105542 | [<H+>] + [<Cu2+><NTA>] <=> [<Cu2+><H+><NTA>] | +1.6000 | 25.0 | 0.100 | yes | [Cu(NTA)H] |
| 4 | vlm_105543 | [<H+>] + [<Cu2+>(<O<H+>>)<NTA>] <=> [H+2O] + [<Cu2+><NTA>] | +9.2000 | 25.0 | 0.100 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

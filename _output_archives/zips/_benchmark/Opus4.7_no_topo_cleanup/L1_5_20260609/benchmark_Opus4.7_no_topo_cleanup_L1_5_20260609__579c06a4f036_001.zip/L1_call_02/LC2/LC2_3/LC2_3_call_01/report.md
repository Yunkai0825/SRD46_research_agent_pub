# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    53.96
- elapsed_s (total):  53.97
- llm_iterations:     15
- llm_tool_calls:     9

- n_groups:           16
- n_multi_groups:     4
- n_singletons:       12
- n_decisions:        16
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of Cu+ cation; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+ aqueous ion; keep SRD-46 entry per preference. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) makes these distinct species despite shared core ratio. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries prefer SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Cu$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu+ cation; prefer SRD-46 notation.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+ aqueous ion; keep SRD-46 entry per preference.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries prefer SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between two Cu(OH)2 entries prefer SRD-46.) |

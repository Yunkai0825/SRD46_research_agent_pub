# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.13
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH across 3-10 to track free Cu2+ and Cu-NTA dissociation.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_5_Cu_EDTA_vs_NTA\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
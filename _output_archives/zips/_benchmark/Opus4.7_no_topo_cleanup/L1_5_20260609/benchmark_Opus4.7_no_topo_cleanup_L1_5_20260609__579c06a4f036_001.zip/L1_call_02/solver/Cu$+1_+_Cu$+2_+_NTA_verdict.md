# Speciation Calculation Report: Cu$+1 + Cu$+2 + NTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0 – 0 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 3.0 – 10.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | NTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HNTA2- | aqueous | L1:+1 H:+1 | — | -53.9948 | +0.0000 |
| NTA | aqueous | L1:+1 | — | -0.0000 | +53.9948 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(NTA)H] | aqueous | L1:+1 Cu$+2:+1 H:+1 | — | -81.6200 | -81.6200 |
| [Cu(NTA)2]4- | aqueous | L1:+2 Cu$+2:+1 | — | -99.3138 | -99.3138 |
| [Cu(NTA)]- | aqueous | L1:+1 Cu$+2:+1 | — | -72.4877 | -72.4877 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 3.30: Cu2O (4.37e-05 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cu+                 peak 100.0% at pH 3.0
  Cu2O                peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   3.0–  3.6  →  Cu+
  pH   3.6– 10.0  →  Cu2O

Crossover pH values:
  Cu+ ↔ Cu2O  at pH ≈ 3.56  (each ~50%)

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  [Cu(NTA)2]4-        peak 99.2% at pH 10.0
  [Cu(NTA)]-          peak 99.7% at pH 4.4

Dominant species by pH region:
  pH   3.0–  7.2  →  [Cu(NTA)]-
  pH   7.2– 10.0  →  [Cu(NTA)2]4-

Crossover pH values:
  [Cu(NTA)2]4- ↔ [Cu(NTA)]-  at pH ≈ 7.22  (each ~50%)

=== NTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HNTA2-              peak 80.0% at pH 3.0
  NTA                 peak 46.7% at pH 10.0
  [Cu(NTA)2]4-        peak 39.7% at pH 10.0
  [Cu(NTA)]-          peak 19.9% at pH 4.4

Dominant species by pH region:
  pH   3.0–  9.2  →  HNTA2-
  pH   9.2–  9.8  →  [Cu(NTA)2]4-
  pH   9.8– 10.0  →  NTA

```
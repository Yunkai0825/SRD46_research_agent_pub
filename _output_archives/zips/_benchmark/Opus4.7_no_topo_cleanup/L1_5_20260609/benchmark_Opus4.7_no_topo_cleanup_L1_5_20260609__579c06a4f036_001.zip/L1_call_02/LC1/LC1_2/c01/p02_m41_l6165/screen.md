# Eq-map screen — m41_l6165

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand6165_beta812_net3751` | `[M] + [L] <=> [ML]` | vlm_105534@(25.0,0.1) = K+12.700 | 3 | +12.700 / +13.000 / +13.000 / +13.300 | vlm_105534@(25.0,0.1) = K+12.700 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand6165_beta840_net3751` | `[M] + [L]^2 <=> [ML2]` | vlm_105539@(25.0,0.1) = K+17.400 | 1 | +17.400 / +17.400 / +17.400 / +17.400 | vlm_105539@(25.0,0.1) = K+17.400 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 3 | `metal41_ligand6165_beta788_net3751` | `[ML] + [H] <=> [MHL]` | vlm_105542@(25.0,0.1) = K+1.600 | 1 | +1.600 / +1.600 / +1.600 / +1.600 | vlm_105542@(25.0,0.1) = K+1.600 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal41_ligand6165_beta966_net3751` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_105543@(25.0,0.1) = K+9.200 | 2 | +9.000 / +9.100 / +9.100 / +9.200 | vlm_105543@(25.0,0.1) = K+9.200 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

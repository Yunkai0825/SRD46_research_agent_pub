# Eq-map screen — m68_l6165

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6165_beta32_net3637` | `[HL] + [H] <=> [H2L]` | vlm_105186@(25.0,0.1) = K+2.520 | 8 | +2.280 / +2.480 / +2.513 / +2.940 | vlm_105186@(25.0,0.1) = K+2.520 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand6165_beta53_net3637` | `[H2L] + [H] <=> [H3L]` | vlm_105204@(25.0,0.1) = K-1.810 | 8 | -1.910 / -1.795 / -0.868 / +2.000 | vlm_105204@(25.0,0.1) = K-1.810 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |
| 3 | `metal68_ligand6165_beta79_net3637` | `[L] + [H] <=> [HL]` | vlm_105158@(25.0,0.1) = K+9.460 | 15 | +8.940 / +9.390 / +9.450 / +10.334 | vlm_105158@(25.0,0.1) = K+9.460 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal68_ligand6165_beta64_net3637` | `[H3L] + [H] <=> [H4L]` | vlm_105223@(25.0,0.1) = K-1.000 | 3 | -1.300 / -1.000 / -1.100 / -1.000 | vlm_105223@(25.0,0.1) = K-1.000 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

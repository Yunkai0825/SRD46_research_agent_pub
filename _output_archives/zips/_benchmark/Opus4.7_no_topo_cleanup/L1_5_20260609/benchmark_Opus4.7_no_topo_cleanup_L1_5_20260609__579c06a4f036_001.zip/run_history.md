# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compare how EDTA versus NTA control the speciation of Cu(II) at pH 3-10, with 1 mM Cu total and 5 mM ligand, at 25 C and I=0.1 m. Which ligand keeps free [Cu2+] lower across the range, and where does ' |
|   6.954 | L1_start | call=1; purpose='Compute Cu(II) speciation with EDTA across pH 3-10 to determine free [Cu2+] and the low-pH dissociation point of the Cu-EDTA complex.' |
| 372.692 | L1_end | call=1; elapsed_s=365.7; ran_ok=True; attempts=1 |
| 372.708 | L1_start | call=2; purpose='Compute Cu(II) speciation with NTA across pH 3-10 to determine free [Cu2+] and the low-pH dissociation point of the Cu-NTA complex.' |
| 660.018 | L1_end | call=2; elapsed_s=287.3; ran_ok=True; attempts=1 |
| 705.709 | L0_end | elapsed_s=705.7038624286652; iterations=8; timed_out=True |

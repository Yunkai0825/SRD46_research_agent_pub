## Answer

In one pot holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia at 25 °C, I = 0.1 m, the two metals **self-sort between the two ligands** rather than competing for one of them:

- **Cu(II) captures glycine.** From pH ~5 to ~8.5 the dominant copper species is the bidentate chelate **[Cu(Gly)₂]** (with a brief [Cu(Gly)]⁺ stage near pH 4–5). Even though ammonia is in 100-fold excess, the very large stepwise stability constants of the Cu–amino-acid chelate (log β₂ ≈ 15) and the fact that almost all ammonia is locked as NH₄⁺ below pH 9 mean Cu²⁺ preferentially forms the five-membered glycinate ring.
- **Zn(II) ends up on ammonia.** Zn–glycinate stabilities are 4–5 log units lower than Cu's, and Cu has already drained the free Gly⁻ pool, so Zn passes briefly through [Zn(Gly)ₙ] (pH 6–8) and then settles into the **ammine series [Zn(NH₃)₃]²⁺ → [Zn(NH₃)₄]²⁺** from pH ~8.5 to ~10.5, once enough NH₄⁺ has deprotonated to free NH₃.
- **Ligand-pool view:** glycine, although the scarcer ligand, is essentially "owned" by Cu in the neutral range; ammonia, in large excess, is the bulk donor pool but only a small slice of it actually binds metal (mostly to Zn), because the total ammonia (0.1 M) hugely outnumbers total Zn (1 mM).

### Soluble → hydroxide-solid window
- **Cu(OH)₂(s)** displaces [Cu(Gly)₂] at **pH ≈ 8.5–9**. Glycinate cannot hold Cu against hydroxide once enough OH⁻ is around, so Cu drops out of solution first.
- **Zn(OH)₂(s)** displaces [Zn(NH₃)₄]²⁺ at **pH ≈ 10.5–11**. Zn survives ~2 pH units further into base because (i) Zn(OH)₂ is more soluble than Cu(OH)₂ and (ii) the tetraammine genuinely stabilises Zn in solution.

Practically this gives a **clean separation window of roughly pH 9–10.5**, where Cu has already precipitated as Cu(OH)₂ but Zn is still held in solution as [Zn(NH₃)₄]²⁺ — exactly the chemistry exploited in classical ammoniacal Cu/Zn separations.

## Evidence
- Cu(II) envelope: free Cu²⁺ (pH 2–4) → [Cu(Gly)]⁺ → **[Cu(Gly)₂] dominant pH ~5–8.5** → **Cu(OH)₂(s) from pH ≈ 8.5–9**.
- Zn(II) envelope: free Zn²⁺ (pH 2–6) → [Zn(Gly)ₙ] (pH ~6–9, low fractions) → **[Zn(NH₃)₃]²⁺/[Zn(NH₃)₄]²⁺ dominant pH ~8.5–10.5** → **Zn(OH)₂(s) from pH ≈ 10.5–11**.
- Glycine ligand budget: HGly⁺/HGly at low pH; at pH 5–9 free Gly⁻ is largely captured by **Cu(Gly)₂**, with a smaller Zn-glycinate share; released back above pH 9 as Cu(OH)₂ precipitates.
- Ammonia ligand budget: overwhelmingly NH₄⁺ below pH 8; free NH₃ only appears around pH 9–10; total NH₃ (0.1 M) ≫ total Zn (1 mM), so ammines never dominate the *ligand* side even when they dominate Zn.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_Cu$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_L1.csv` (glycine)
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_L2.csv` (ammonia)
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_log_conc.csv`
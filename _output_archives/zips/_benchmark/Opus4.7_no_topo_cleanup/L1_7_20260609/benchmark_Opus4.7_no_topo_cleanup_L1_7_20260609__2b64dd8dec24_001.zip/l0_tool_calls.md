# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute joint pH speciation for a single solution containing Cu(II), Zn(II), gly | Model a single pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with gl | 5657 | 466.0 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute joint pH speciation for a single solution containing Cu(II), Zn(II), glycine and ammonia, and determine how the two metals partition between glycinate and ammine complexes and where hydroxide solids take over.",
  "tasks": "Model a single pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, over pH 2-12 at 25 C and ionic strength 0.1 m. Solve all four components jointly so the two metals compete for the shared glycinate and ammine ligand pools. Report the dominant species for each metal across pH, indicate which metal preferentially binds glycine and which preferentially binds ammonia, and identify the pH window in which the soluble glycinate and ammine complexes give way to Cu(OH)2 and Zn(OH)2 solids. Provide envelope CSVs and species-fraction CSVs for both metals and for both ligands."
}
```

### Reasoning excerpt
```
<reasoning>
Single pot with two metals and two ligands. One L1 call.
</reasoning>
<summary>
Dispatching a single L1 pipeline call for the joint Cu/Zn/glycine/ammonia pot over pH 2-12.
</summary>
```

### Result (5657 chars)
```
## Doability
Doable — the SRD-46 catalog covered Cu(I)/Cu(II)/Zn(II) with glycine and ammonia, and the four-component pH sweep solved successfully.

## Result
Joint pH speciation of a single solution containing
* Cu(II) 1 mM, Zn(II) 1 mM, glycine 10 mM, ammonia 0.1 M
* T = 25 °C, I = 0.1 m, pH 2–12 (`pH_sweep`)
* Cu(I) was kept in the basis but at no point became significant — it stayed as free Cu⁺ throughout the window and is therefore not discussed further.

The solver converged across the full pH range; envelopes were produced for both metals and both ligands, and the verdict file flagged Cu(OH)₂(s) and Zn(OH)₂(s) precipitation at high pH.

## Analysis

### Cu(II) speciation across pH (`envelope_Cu$+2.csv`)
* **pH 2 – ~4**: dominated by free **Cu²⁺(aq)**. Glycine is still largely protonated (HGly⁺ / HGly), so it cannot coordinate effectively, and ammonia is almost entirely NH₄⁺ (pKa ≈ 9.25), so neither ligand competes with water.
* **pH ~4 – ~8.5**: **[Cu(Gly)]⁺** appears first as the glycinate fraction grows, then **[Cu(Gly)₂]** rapidly takes over and is the dominant Cu species across most of the near-neutral and mildly basic range. This is the classic outcome for Cu(II)/glycine: very high stepwise log K's (log β₂ ≈ 15) let Cu²⁺ scavenge glycinate even though ammonia is present at 10× higher total concentration, because at pH 5–8 only a tiny fraction of ammonia is the free NH₃ form.
* **pH ≳ 8.5 – 12**: **Cu(OH)₂(s)** becomes the dominant Cu sink. Even with 0.1 M total ammonia (so [NH₃] reaches the millimolar range above pH 9), Cu(II) ammine complexes never become the majority species in this run — hydroxide precipitation outcompetes them. So the soluble-to-solid transition for Cu sits around **pH ≈ 8.5–9**.

### Zn(II) speciation across pH (`envelope_Zn$+2.csv`)
* **pH 2 – ~6**: free **Zn²⁺(aq)** dominates; glycine is protonated and NH₃ is negligible.
* **pH ~6 – ~9**: a sequence of glycinate complexes appears — **[Zn(Gly)]⁺ → [Zn(Gly)₂] → [Zn(Gly)₃]⁻** — but the maximum fractions are much lower than for Cu, because Zn–glycine stability constants are roughly 4–5 log units smaller than Cu–glycine, and Cu has already drained the glycinate pool.
* **pH ~8 – ~10.5**: **ammine complexes [Zn(NH₃)ₙ]²⁺ (n = 1, 3, 4)** become the dominant soluble Zn species. By pH ≈ 9.5 free NH₃ is in large excess over free glycinate (which is consumed by Cu plus by protonation/zwitterion equilibria), so Zn switches to ammonia coordination, ultimately to **[Zn(NH₃)₄]²⁺**.
* **pH ≳ 10.5 – 12**: **Zn(OH)₂(s)** appears and, near the upper end of the window, competes with [Zn(NH₃)₄]²⁺. Zn hydroxide forms ~2 pH units later than Cu(OH)₂ because Zn(OH)₂ has a higher Ksp and Zn is genuinely stabilised in solution by tetraammine formation.

### Ligand partitioning (`envelope_L1.csv` glycine, `envelope_L2.csv` ammonia)
* **Glycine** at low pH is HGly⁺/HGly; at pH 5–9 the free Gly⁻ pool is largely captured into **Cu(Gly)₂** (with smaller contributions from Cu(Gly)⁺ and the Zn–glycinate ladder). Above pH ~9, as Cu(OH)₂ precipitates, glycine is released back to the free Gly⁻ form and to Zn–glycinate complexes that then themselves fade.
* **Ammonia** is overwhelmingly NH₄⁺ below pH 8 and only converts to free NH₃ around pH 9–10. The envelope shows that the only ammine that ever dominates *the ligand budget* is the Cu(I) [Cu(NH₃)₂]⁺ trace species; the Zn ammines, while dominant for Zn, are minor on the ligand side because total ammonia (0.1 M) hugely exceeds total Zn (1 mM). In other words, **ammonia is in large excess and is the main donor pool, but glycine, though scarcer, is preferentially eaten by Cu.**

### Who gets what
* **Cu(II) preferentially binds glycine** (Cu(Gly)₂ dominates Cu across pH 5–8.5). Cu's much higher affinity for the bidentate amino-carboxylate chelate wins over ammine formation even at 100× ammonia excess.
* **Zn(II) preferentially binds ammonia** (Zn(NH₃)₃²⁺/Zn(NH₃)₄²⁺ dominate Zn across pH 8.5–10.5). Zn–glycinate complexes only briefly dominate near pH 7 and never reach high fractions because Cu has first call on glycinate.

### Soluble → solid window
* **Cu(OH)₂(s)** takes over from soluble Cu(Gly)₂ at **pH ≈ 8.5–9**.
* **Zn(OH)₂(s)** takes over from soluble Zn(NH₃)₄²⁺ at **pH ≈ 10.5–11**.
* So the practical "soluble metal complex" window is roughly **pH 5–8.5 for Cu** (as glycinate) and **pH 6–10.5 for Zn** (as glycinate then tetraammine). Between pH ~9 and ~10.5 Cu has already precipitated while Zn is still held in solution by ammonia — a useful separation window.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_Cu$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_L1.csv` (glycine)
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_envelope_L2.csv` (ammonia)
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Zn$+2_+_Glycine_+_Ammonia_log_conc.csv`

Note: the hard stop was reached before I could submit through `record_analysis`; the full write-up above is the L1 report for this system.
```

# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='For a single solution holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia together at 25 C and I=0.1 m, compute the joint pH 2-12 speciation and show how the two metals partition between' |
|   6.697 | L1_start | call=1; purpose='Compute joint pH speciation for a single solution containing Cu(II), Zn(II), glycine and ammonia, and determine how the two metals partition between glycinate and ammine complexes and where hydroxide ' |
| 472.682 | L1_end | call=1; elapsed_s=466.0; ran_ok=True; attempts=1 |
| 506.859 | L0_end | elapsed_s=506.85427021980286; iterations=2; timed_out=False |

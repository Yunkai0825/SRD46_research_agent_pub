# Speciation Calculation Report: Cu$+1 + Cu$+2 + Zn$+2 + Glycine + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0047826 – 0.05444 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 101
- Converged: 101/101

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Glycine | 1.00e-02 | ligand |
| L2 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| HAmmonia+ | aqueous | L2:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | -57.6477 |
| [Cu(Ammo)2]+ | aqueous | L2:+2 Cu$+1:+1 | — | -55.6708 | -55.6708 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | -86.1861 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | -46.7460 |
| [Cu(Ammo)4]2+ | aqueous | L2:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L2:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L2:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L2:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +90.1815 | +90.1815 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Glyc)3]- | aqueous | L1:+3 Zn$+2:+1 | — | -68.8740 | -68.8740 |
| [Zn(Glyc)2] | aqueous | L1:+2 Zn$+2:+1 | — | -54.5649 | -54.5649 |
| [Zn(Glyc)]+ | aqueous | L1:+1 Zn$+2:+1 | — | -29.4496 | -29.4496 |
| [Zn(Ammo)4]2+ | aqueous | L2:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L2:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L2:+2 Zn$+2:+1 | — | -25.6846 | -25.6846 |
| [Zn(Ammo)]2+ | aqueous | L2:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 3.30: Cu2O (4.37e-05 M)
- pH 7.30: Cu2O (6.84e-05 M), Zn(OH)2 (alpha) (8.27e-05 M)
- pH 7.40: Zn(OH)2 (alpha) (2.21e-04 M)
- pH 11.20: Zn(OH)2 (alpha) (9.90e-04 M), Cu2O (4.54e-05 M)
- pH 11.30: Zn(OH)2 (alpha) (9.90e-04 M), Cu2O (1.34e-04 M), [Cu(OH)2](s) (4.51e-05 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Cu+                 peak 100.0% at pH 2.0
  [Cu(Ammo)2]+        peak 99.8% at pH 7.4
  Cu2O                peak 98.2% at pH 5.3

Dominant species by pH region:
  pH   2.0–  3.6  →  Cu+
  pH   3.6–  7.1  →  Cu2O
  pH   7.1– 11.5  →  [Cu(Ammo)2]+
  pH  11.5– 12.0  →  Cu2O

Crossover pH values:
  Cu+ ↔ Cu2O  at pH ≈ 3.56  (each ~50%)
  [Cu(Ammo)2]+ ↔ Cu2O  at pH ≈ 7.05  (each ~50%)
  [Cu(Ammo)2]+ ↔ Cu2O  at pH ≈ 11.47  (each ~50%)

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Cu2+                peak 96.0% at pH 2.0
  [Cu(Glyc)2]         peak 99.9% at pH 8.4
  [Cu(Glyc)]+         peak 68.4% at pH 4.1
  [Cu(OH)2](s)        peak 94.0% at pH 12.0

Dominant species by pH region:
  pH   2.0–  3.5  →  Cu2+
  pH   3.5–  4.8  →  [Cu(Glyc)]+
  pH   4.8– 11.5  →  [Cu(Glyc)2]
  pH  11.5– 12.0  →  [Cu(OH)2](s)

Crossover pH values:
  Cu2+ ↔ [Cu(Glyc)2]  at pH ≈ 4.07  (each ~16%)
  Cu2+ ↔ [Cu(Glyc)]+  at pH ≈ 3.40  (each ~49%)
  [Cu(Glyc)2] ↔ [Cu(Glyc)]+  at pH ≈ 4.73  (each ~49%)
  [Cu(Glyc)2] ↔ [Cu(OH)2](s)  at pH ≈ 11.49  (each ~50%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Zn2+                peak 100.0% at pH 2.0
  [Zn(Glyc)3]-        peak 9.3% at pH 9.3
  [Zn(Glyc)2]         peak 29.9% at pH 7.8
  [Zn(Glyc)]+         peak 51.1% at pH 7.1
  [Zn(Ammo)4]2+       peak 7.0% at pH 9.3

Dominant species by pH region:
  pH   2.0–  6.8  →  Zn2+
  pH   6.8–  7.5  →  [Zn(Glyc)]+
  pH   7.5–  9.6  →  [Zn(Glyc)2]
  pH   9.6– 12.0  →  [Zn(Glyc)3]-

Crossover pH values:
  Zn2+ ↔ [Zn(Glyc)2]  at pH ≈ 7.13  (each ~22%)
  Zn2+ ↔ [Zn(Glyc)]+  at pH ≈ 6.74  (each ~44%)
  [Zn(Glyc)3]- ↔ [Zn(Glyc)2]  at pH ≈ 9.59  (each ~8%)
  [Zn(Glyc)2] ↔ [Zn(Glyc)]+  at pH ≈ 7.49  (each ~29%)

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  HGlycine            peak 99.6% at pH 2.0
  Glycine             peak 98.4% at pH 12.0
  [Cu(Glyc)2]         peak 20.0% at pH 8.4
  [Cu(Glyc)]+         peak 6.8% at pH 4.1
  [Zn(Glyc)2]         peak 6.0% at pH 7.8
  [Zn(Glyc)]+         peak 5.1% at pH 7.1

Dominant species by pH region:
  pH   2.0–  9.6  →  HGlycine
  pH   9.6– 12.0  →  Glycine

=== Ammonia (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 2.0
  Ammonia             peak 99.5% at pH 12.0

Dominant species by pH region:
  pH   2.0–  9.3  →  HAmmonia+
  pH   9.3– 12.0  →  Ammonia

```
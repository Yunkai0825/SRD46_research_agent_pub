[Purpose: Compute joint pH speciation for a single solution containing Cu(II), Zn(II), glycine and ammonia, and determine how the two metals partition between glycinate and ammine complexes and where hydroxide solids take over.]
[Tasks:
Model a single pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, over pH 2-12 at 25 C and ionic strength 0.1 m. Solve all four components jointly so the two metals compete for the shared glycinate and ammine ligand pools. Report the dominant species for each metal across pH, indicate which metal preferentially binds glycine and which preferentially binds ammonia, and identify the pH window in which the soluble glycinate and ammine complexes give way to Cu(OH)2 and Zn(OH)2 solids. Provide envelope CSVs and species-fraction CSVs for both metals and for both ligands.
]
[Pair: pair_key=`m42_l5760`, metal_id=42, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand5760_beta840_net100`
[Screen report]
# Eq-map screen — m42_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand5760_beta840_net100` | `[M] + [L]^2 <=> [ML2]` | vlm_93899@(25.0,0.1) = K+10.100 | 1 | +10.100 / +10.100 / +10.100 / +10.100 | vlm_93899@(25.0,0.1) = K+10.100 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

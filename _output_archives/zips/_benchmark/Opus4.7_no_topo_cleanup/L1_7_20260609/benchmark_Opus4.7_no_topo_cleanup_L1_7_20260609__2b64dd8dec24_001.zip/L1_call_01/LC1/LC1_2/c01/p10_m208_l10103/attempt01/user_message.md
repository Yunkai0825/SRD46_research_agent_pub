[Purpose: Compute joint pH speciation for a single solution containing Cu(II), Zn(II), glycine and ammonia, and determine how the two metals partition between glycinate and ammine complexes and where hydroxide solids take over.]
[Tasks:
Model a single pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, over pH 2-12 at 25 C and ionic strength 0.1 m. Solve all four components jointly so the two metals compete for the shared glycinate and ammine ligand pools. Report the dominant species for each metal across pH, indicate which metal preferentially binds glycine and which preferentially binds ammonia, and identify the pH window in which the soluble glycinate and ammine complexes give way to Cu(OH)2 and Zn(OH)2 solids. Provide envelope CSVs and species-fraction CSVs for both metals and for both ligands.
]
[Pair: pair_key=`m208_l10103`, metal_id=208, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand10103_beta894_net28282`
  - `metal208_ligand10103_beta840_net28282`
  - `metal208_ligand10103_beta872_net28282`
[Screen report]
# Eq-map screen — m208_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand10103_beta812_net28282` | `[M] + [L] <=> [ML]` | vlm_173394@(25.0,0.1) = K+2.330 | 4 | +2.210 / +2.315 / +2.312 / +2.410 | vlm_173394@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand10103_beta894_net28282` | `[M] + [L]^4 <=> [ML4]` | vlm_173412@(25.0,0.0) = K+8.890 | 3 | +8.890 / +9.340 / +9.320 / +9.730 | vlm_173412@(25.0,0.0) = K+8.890 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 3 | `metal208_ligand10103_beta840_net28282` | `[M] + [L]^2 <=> [ML2]` | vlm_173402@(25.0,0.0) = K+4.500 | 3 | +4.500 / +4.830 / +4.760 / +4.950 | vlm_173402@(25.0,0.0) = K+4.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal208_ligand10103_beta872_net28282` | `[M] + [L]^3 <=> [ML3]` | vlm_173407@(25.0,0.0) = K+6.860 | 3 | +6.860 / +7.110 / +7.143 / +7.460 | vlm_173407@(25.0,0.0) = K+6.860 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

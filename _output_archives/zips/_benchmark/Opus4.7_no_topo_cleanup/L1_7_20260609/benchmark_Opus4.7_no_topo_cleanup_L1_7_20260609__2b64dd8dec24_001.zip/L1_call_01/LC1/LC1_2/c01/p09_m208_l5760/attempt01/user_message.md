[Purpose: Compute joint pH speciation for a single solution containing Cu(II), Zn(II), glycine and ammonia, and determine how the two metals partition between glycinate and ammine complexes and where hydroxide solids take over.]
[Tasks:
Model a single pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, over pH 2-12 at 25 C and ionic strength 0.1 m. Solve all four components jointly so the two metals compete for the shared glycinate and ammine ligand pools. Report the dominant species for each metal across pH, indicate which metal preferentially binds glycine and which preferentially binds ammonia, and identify the pH window in which the soluble glycinate and ammine complexes give way to Cu(OH)2 and Zn(OH)2 solids. Provide envelope CSVs and species-fraction CSVs for both metals and for both ligands.
]
[Pair: pair_key=`m208_l5760`, metal_id=208, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand5760_beta966_net113`
[Screen report]
# Eq-map screen — m208_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand5760_beta966_net113` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_93960@(37.0,0.15) = K+8.900 | 1 | +8.900 / +8.900 / +8.900 / +8.900 | vlm_93960@(37.0,0.15) = K+8.900 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal208_ligand5760_beta840_net113` | `[M] + [L]^2 <=> [ML2]` | vlm_93937@(37.0,0.15) = K+8.970 | 7 | +8.970 / +9.190 / +9.394 / +10.070 | vlm_93936@(25.0,0.1) = K+9.190 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal208_ligand5760_beta812_net113` | `[M] + [L] <=> [ML]` | vlm_93925@(37.0,0.15) = K+4.870 | 7 | +4.850 / +4.960 / +5.106 / +5.500 | vlm_93924@(25.0,0.1) = K+4.960 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal208_ligand5760_beta872_net113` | `[M] + [L]^3 <=> [ML3]` | vlm_93950@(37.0,0.15) = K+11.300 | 7 | +11.300 / +11.600 / +11.843 / +12.700 | vlm_93949@(25.0,0.1) = K+11.600 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

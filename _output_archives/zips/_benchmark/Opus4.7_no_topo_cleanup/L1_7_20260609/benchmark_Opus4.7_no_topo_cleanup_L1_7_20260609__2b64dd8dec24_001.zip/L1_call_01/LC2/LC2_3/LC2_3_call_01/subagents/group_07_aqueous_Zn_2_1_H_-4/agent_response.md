# LC2_3 group [aqueous::Zn$+2:1 H:-4] agent response

## Final answer (text emitted by the agent)

Kept `[Zn(OH)4]2-` (SRD-46) as the canonical zincate species; `[ZnO2]2-` is the same species in dehydrated notation (same charge, nuclearity, phase) and is dropped per rule 1 preference for SRD-46.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which species names in this group to KEEP after
deduplication, following the deduplication plan supplied in the user
message.  Return the list verbatim via `finalize_group_decision`.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_names": ["<exact species name>", ...],
   "rationale":  "<one sentence>"}

The names MUST match the `name` field shown in the user message
exactly.  After a successful `finalize_group_decision` you may emit
your answer block.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture the LLM's keep_names + rationale for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

Decide which species to KEEP per core-stoichiometry group; never re-merge or edit μ. Dropped rows are flagged `include=false` (kept for audit). A purpose-derived **addendum** may refine these defaults and wins on points it addresses. Members share a *core* ratio but may still be distinct species — judge by full formula and nuclearity, not the core alone.

1. **True duplicate = same species, different notation only**: identical phase, charge, AND nuclearity/`multiplier` ⇒ keep one. Prefer SRD-46; if both same-source, keep the lower `mu_aligned_kJ`. Species with very close mu may be a good starting point to inspect the species in detail.
2. **Keep distinct chemistry**: any difference in charge, oxidation state, phase, nuclearity (a polynuclear species is NOT the same as its mononuclear form even at equal core ratio), or hydration/polymorph is a *different* species — keep it. 
3. **Never empty a group** — at least one species must survive every group.
4. **When unsure, keep** — speciation needs full redox/phase/nuclearity coverage and a dropped species is unrecoverable. Defer polymorph/hydrate pruning to the addendum.

## Calculation-specific addendum

- Aqueous 25 C Cu/Zn speciation: for same-core solids differing only in hydration/polymorph, prefer the hydrated oxyhydroxide (e.g., Cu(OH)2, Zn(OH)2, malachite-type) over the anhydrous oxide (tenorite, zincite); drop the anhydrous form if both present.
- Scope: this is a Cu-Zn-glycine-ammonia-H2O system at 25 C; singletons containing elements outside {Cu, Zn, C, H, N, O} or restricted to high-T/anhydrous regimes are out of scope.


[Group: phase=aqueous core_label=Zn$+2:1 H:-4 n_species=2]

| name | source | charge | mu_aligned_kJ | multiplier |
|------|--------|-------:|--------------:|-----------:|
| `[ZnO2]2-` | Atlas | -2 | 190.640 | 1 |
| `[Zn(OH)4]2-` | SRD-46 | -2 | 231.161 | 1 |

## Assistant
<summary>Both species share core ratio Zn:+2, H:-4 (zincate). [ZnO2]2- (Atlas) and [Zn(OH)4]2- (SRD-46) are notational variants of the same zincate ion — same charge, same nuclearity, same phase. Keep SRD-46 form per rule 1.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["[Zn(OH)4]2…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Finalized: kept [Zn(OH)4]2- as the SRD-46 representation of zincate.</summary>

<answer>
Kept `[Zn(OH)4]2-` (SRD-46) as the canonical zincate species; `[ZnO2]2-` is the same species in dehydrated notation (same charge, nuclearity, phase) and is dropped per rule 1 preference for SRD-46.
</answer>

# Free Energy Analysis Card

**System**: H, Cu, Zn / Glycine, Ammonia, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Zn]2+
**Ligands**: [Glycine], [Ammonia]
**Generated**: 2026-06-09 17:27:02 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| M3 | Metal component: [Zn]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Glycine] |
| L2 | Ligand component: [Ammonia] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | 0.001 | NIST SRD-46 | metal_42 |
| M3 | [Zn]2+ | +2 | 0.001 | NIST SRD-46 | metal_208 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | 0.01 | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |
| L2 | [Ammonia] | +0 | 0.01 | [[L2]] | NIST SRD-46 | ligand_10103 | N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |
| Zn | M3 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| M3 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Glycine] | ligand_canonical | [[H][L1]] | +0.0000 | R4 | *** | -1 | *** |
| L2 | [Ammonia] | ligand_canonical | [[L2]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Glycine] | [L1] -> [[H][L1]] | 1 | 1 | +9.5700 | +54.6226 | exact |  |
| L2 | [Ammonia] | [L2] -> [[L2]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Glycine] | 25.0 | 0.1 | *** | 2 |
| *** + [Ammonia] | 25.0 | 0.1 | *** | 1 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [Glycine] | 25.0 | 0.1 | 86 | 2 |
| [Cu]2+ + [Ammonia] | 25.0 | 0~0.1 | 28241 | 4 |
| [Cu]2+ + *** | 25.0 | 0~0.1 | *** | 6 |
| [Cu]+ + [Glycine] | 25.0 | 0.1 | 100 | 1 |
| [Cu]+ + [Ammonia] | 20.0 | 0.1 | 28256 | 1 |
| [Cu]+ + *** | 25.0 | 0 | *** | 1 |
| [Zn]2+ + [Glycine] | 37.0 | 0.15 | 113 | 4 |
| [Zn]2+ + [Ammonia] | 25.0 | 0~0.1 | 28282 | 4 |
| [Zn]2+ + *** | 25.0 | 0~0.1 | *** | 11 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Glycine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z+0] | [HGlycine] | +0 | aqueous | +9.5700 | -54.6226 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_93606 | *** |
| [L1].[z-1] | [Glycine] | -1 | aqueous | +0.0000 | -0.0000 | +54.6226 | +54.6226 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L2]]:+1 | vlm_173034 | *** |
| [L2].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L2]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1]2.[z+0] | [Cu(Glyc)2] | +0 | aqueous | +15.1000 | -86.1861 | -86.1861 | -86.1861 | [M1]:+1, [L1]:+2 | vlm_93862 | *** |
| [M1].[L1].[z+1] | [Cu(Glyc)]+ | +1 | aqueous | +8.1900 | -46.7460 | -46.7460 | -46.7460 | [M1]:+1, [L1]:+1 | vlm_93847 | *** |

#### [Cu]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L2]4.[z+2] | [Cu(Ammo)4]2+ | +2 | aqueous | +12.3000 | -70.2046 | -70.2046 | -70.2046 | [M1]:+1, [L2]:+4 | vlm_173282 | *** |
| [M1].[L2]3.[z+2] | [Cu(Ammo)3]2+ | +2 | aqueous | +10.2000 | -58.2185 | -58.2185 | -58.2185 | [M1]:+1, [L2]:+3 | vlm_173270 | *** |
| [M1].[L2]2.[z+2] | [Cu(Ammo)2]2+ | +2 | aqueous | +7.4000 | -42.2369 | -42.2369 | -42.2369 | [M1]:+1, [L2]:+2 | vlm_173258 | *** |
| [M1].[L2].[z+2] | [Cu(Ammo)]2+ | +2 | aqueous | +4.1000 | -23.4015 | -23.4015 | -23.4015 | [M1]:+1, [L2]:+1 | vlm_173242 | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1]2.[z-1] | [Cu(Glyc)2]- | -1 | aqueous | +10.1000 | -57.6477 | -57.6477 | -57.6477 | [M2]:+1, [L1]:+2 | vlm_93899 | *** |

#### [Cu]+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L2]2.[z+1] | [Cu(Ammo)2]+ | +1 | aqueous | +9.9200 | -55.6708 | -55.6708 | -55.6708 | [M2]:+1, [L2]:+2 | vlm_173333 | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Zn]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L1]3.[z-1] | [Zn(Glyc)3]- | -1 | aqueous | +11.6000 | -68.8740 | -68.8740 | -68.8740 | [M3]:+1, [L1]:+3 | vlm_93950 | *** |
| [M3].[L1]2.[z+0] | [Zn(Glyc)2] | +0 | aqueous | +9.1900 | -54.5649 | -54.5649 | -54.5649 | [M3]:+1, [L1]:+2 | vlm_93937 | *** |
| [M3].[L1].[z+1] | [Zn(Glyc)]+ | +1 | aqueous | +4.9600 | -29.4496 | -29.4496 | -29.4496 | [M3]:+1, [L1]:+1 | vlm_93925 | *** |

#### [Zn]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L2]4.[z+2] | [Zn(Ammo)4]2+ | +2 | aqueous | +8.8900 | -50.7414 | -50.7414 | -50.7414 | [M3]:+1, [L2]:+4 | vlm_173412 | *** |
| [M3].[L2]3.[z+2] | [Zn(Ammo)3]2+ | +2 | aqueous | +6.8600 | -39.1548 | -39.1548 | -39.1548 | [M3]:+1, [L2]:+3 | vlm_173407 | *** |
| [M3].[L2]2.[z+2] | [Zn(Ammo)2]2+ | +2 | aqueous | +4.5000 | -25.6846 | -25.6846 | -25.6846 | [M3]:+1, [L2]:+2 | vlm_173402 | *** |
| [M3].[L2].[z+2] | [Zn(Ammo)]2+ | +2 | aqueous | +2.3300 | -13.2989 | -13.2989 | -13.2989 | [M3]:+1, [L2]:+1 | vlm_173394 | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M3]:+1, [OH]:+1 | vlm_170929 | *** |
| [M3].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -15.8000 | +90.1815 | +90.1815 | +90.1815 | [M3]:+1, [OH]:+2 | vlm_170935 | *** |
| [M3].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M3]:+1, [OH]:+3 | vlm_170937 | *** |
| [M3].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M3]:+1, [OH]:+4 | vlm_170939 | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]2.[z+0]_(s) | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[[z+0(s)[1]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M3]:+1, [OH]:+2 | vlm_170956 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 38 |
| Included in calculation | 38 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 24 |
| Unresolved (no species in card) | 14 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_93627 | [<H+><Glycine>] + [<H+>] <=> [<H+>2<Glycine>] | +2.3300 | 25.0 | 0.100 | yes | — |
| 2 | vlm_93606 | [<H+>] + [<Glycine>] <=> [<H+><Glycine>] | +9.5700 | 25.0 | 0.100 | yes | [HGlycine] |
| 3 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 4 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 5 | vlm_93862 | [<Glycine>]^2 + [<Cu2+>] <=> [<Cu2+><Glycine>2] | +15.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2] |
| 6 | vlm_93847 | [<Glycine>] + [<Cu2+>] <=> [<Cu2+><Glycine>] | +8.1900 | 25.0 | 0.100 | yes | [Cu(Glyc)]+ |
| 7 | vlm_173258 | [<Ammonia>]^2 + [<Cu2+>] <=> [<Cu2+><Ammonia>2] | +7.4000 | 25.0 | 0.000 | yes | [Cu(Ammo)2]2+ |
| 8 | vlm_173242 | [<Ammonia>] + [<Cu2+>] <=> [<Cu2+><Ammonia>] | +4.1000 | 25.0 | 0.100 | yes | [Cu(Ammo)]2+ |
| 9 | vlm_173282 | [<Ammonia>]^4 + [<Cu2+>] <=> [<Cu2+><Ammonia>4] | +12.3000 | 25.0 | 0.000 | yes | [Cu(Ammo)4]2+ |
| 10 | vlm_173270 | [<Ammonia>]^3 + [<Cu2+>] <=> [<Cu2+><Ammonia>3] | +10.2000 | 25.0 | 0.000 | yes | [Cu(Ammo)3]2+ |
| 11 | vlm_170721 | [<OH+->]^2 + [<Cu2+>] <=> [<Cu2+><OH+->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 12 | vlm_170727 | [<OH+->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH+->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 13 | vlm_170736 | [<OH+->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH+->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 14 | vlm_170713 | [<OH+->] + [<Cu2+>] <=> [<Cu2+><OH+->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 15 | vlm_170742 | [<Cu2+><OH+->2(s)] <=> [<OH+->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 16 | vlm_170746 | [H+2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [O<H+>]^2 | -20.3500 | 25.0 | 0.000 | yes | — |
| 17 | vlm_93899 | [<Glycine>]^2 + [<Cu+>] <=> [<Cu+><Glycine>2] | +10.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2]- |
| 18 | vlm_173333 | [<Ammonia>]^2 + [<Cu+>] <=> [<Cu+><Ammonia>2] | +9.9200 | 20.0 | 0.100 | yes | [Cu(Ammo)2]+ |
| 19 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H+2O]^0 <=> [<Cu+>] + [O<H+>] | -14.7000 | 25.0 | 0.000 | yes | — |
| 20 | vlm_93960 | [<H+>] + [<Zn2+>(<O<H+>>)<Glycine>] <=> [H+2O] + [<Zn2+><Glycine>] | +8.9000 | 37.0 | 0.150 | yes | — |
| 21 | vlm_93937_patched | [<Glycine>]^2 + [<Zn2+>] <=> [<Zn2+><Glycine>2] | +9.1900 | 37.0 | 0.150 | yes | — |
| 22 | vlm_93925_patched | [<Glycine>] + [<Zn2+>] <=> [<Zn2+><Glycine>] | +4.9600 | 37.0 | 0.150 | yes | — |
| 23 | vlm_93950_patched | [<Glycine>]^3 + [<Zn2+>] <=> [<Zn2+><Glycine>3] | +11.6000 | 37.0 | 0.150 | yes | — |
| 24 | vlm_173394 | [<Ammonia>] + [<Zn2+>] <=> [<Zn2+><Ammonia>] | +2.3300 | 25.0 | 0.100 | yes | [Zn(Ammo)]2+ |
| 25 | vlm_173412 | [<Ammonia>]^4 + [<Zn2+>] <=> [<Zn2+><Ammonia>4] | +8.8900 | 25.0 | 0.000 | yes | [Zn(Ammo)4]2+ |
| 26 | vlm_173402 | [<Ammonia>]^2 + [<Zn2+>] <=> [<Zn2+><Ammonia>2] | +4.5000 | 25.0 | 0.000 | yes | [Zn(Ammo)2]2+ |
| 27 | vlm_173407 | [<Ammonia>]^3 + [<Zn2+>] <=> [<Zn2+><Ammonia>3] | +6.8600 | 25.0 | 0.000 | yes | [Zn(Ammo)3]2+ |
| 28 | vlm_170929 | [<OH+->] + [<Zn2+>] <=> [<Zn2+><OH+->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 29 | vlm_170935_patched | [<OH+->]^2 + [<Zn2+>] <=> [<Zn2+><OH+->2] | +12.2000 | 25.0 | 0.000 | yes | — |
| 30 | vlm_170937 | [<OH+->]^3 + [<Zn2+>] <=> [<Zn2+><OH+->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 31 | vlm_170939 | [<OH+->]^4 + [<Zn2+>] <=> [<Zn2+><OH+->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 32 | vlm_170944 | [<Zn2+><OH+->2(s,am)] <=> [<OH+->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | — |
| 33 | vlm_170948 | [<Zn2+><OH+->2(s,beta1)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | — |
| 34 | vlm_170950 | [<Zn2+><OH+->2(s,beta2)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | — |
| 35 | vlm_170952 | [<Zn2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | — |
| 36 | vlm_170954 | [<Zn2+><OH+->2(s,delta)] <=> [<OH+->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | — |
| 37 | vlm_170956 | [<Zn2+><OH+->2(s,epsilon)] <=> [<OH+->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 38 | vlm_170958 | [H+2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [O<H+>]^2 | -15.9600 | 25.0 | 0.100 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

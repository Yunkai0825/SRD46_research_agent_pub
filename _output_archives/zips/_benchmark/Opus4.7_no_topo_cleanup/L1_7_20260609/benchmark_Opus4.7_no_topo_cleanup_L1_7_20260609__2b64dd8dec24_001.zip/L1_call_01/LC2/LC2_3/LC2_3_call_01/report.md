# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_7_CuZn_glycine_ammonia_joint\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_7_CuZn_glycine_ammonia_joint\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    125.21
- elapsed_s (total):  125.22
- llm_iterations:     35
- llm_tool_calls:     26

- n_groups:           37
- n_multi_groups:     9
- n_singletons:       28
- n_decisions:        37
- n_dropped:          12
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate of aqueous Cu+ cation; prefer SRD-46 notation per plan rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+ aqueous ion; prefer SRD-46 per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and binuclear Cu-hydroxo species differ in nuclearity and charge; both retained as distinct chemistry. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate notation for aqueous Zn2+; prefer SRD-46. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate: same mononuclear ZnOH+ cation; prefer SRD-46 over Atlas. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same anionic mononuclear Zn(II) hydroxo species written in two notations; prefer SRD-46 entry with lower aligned mu. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same zincate species in different notation (ZnO2^2- vs Zn(OH)4^2-); keep SRD-46 critically-evaluated form. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Prefer hydrated Cu(OH)2 over anhydrous CuO per addendum; between two Cu(OH)2 entries keep SRD-46 (lower mu and preferred source). |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (beta)`, `Zn(OH)2 (gamma)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Kept all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and preferred SRD-46 epsilon over Atlas duplicate; dropped anhydrous ZnO forms per addendum favoring hydrated oxyhydroxides. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid reference species with finite mu_aligned_kJ. |
| aqueous | `Cu$+1:1 L1:2` | yes | Unique Cu(I)-glycinate complex with valid thermodynamics. |
| aqueous | `Cu$+1:1 L2:2` | yes | Unique Cu(I)-ammine complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydroxide complex with valid mu. |
| aqueous | `Cu$+2:1 H:-3` | yes | Cu(II) hydroxo anion with valid mu. |
| aqueous | `Cu$+2:1 H:-4` | yes | Cu(II) hydroxo dianion with valid mu. |
| aqueous | `Cu$+2:1 L1:1` | yes | Unique Cu(II)-glycinate 1:1 complex. |
| aqueous | `Cu$+2:1 L1:2` | yes | Unique Cu(II)-glycinate 1:2 complex. |
| aqueous | `Cu$+2:1 L2:1` | yes | Unique Cu(II)-ammine 1:1 complex. |
| aqueous | `Cu$+2:1 L2:2` | yes | Unique Cu(II)-ammine 1:2 complex. |
| aqueous | `Cu$+2:1 L2:3` | yes | Unique Cu(II)-ammine 1:3 complex. |
| aqueous | `Cu$+2:1 L2:4` | yes | Unique Cu(II)-ammine 1:4 complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu(II) hydroxo cluster with valid mu. |
| aqueous | `L1:1` | yes | Glycinate ligand reference species. |
| aqueous | `L1:1 H:1` | yes | Protonated glycine reference species. |
| aqueous | `L2:1` | yes | Ammonia reference species. |
| aqueous | `L2:1 H:1` | yes | Ammonium reference species. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(II) hydroxide complex with valid mu. |
| aqueous | `Zn$+2:1 L1:1` | yes | Unique Zn(II)-glycinate 1:1 complex. |
| aqueous | `Zn$+2:1 L1:2` | yes | Unique Zn(II)-glycinate 1:2 complex. |
| aqueous | `Zn$+2:1 L1:3` | yes | Unique Zn(II)-glycinate 1:3 complex. |
| aqueous | `Zn$+2:1 L2:1` | yes | Unique Zn(II)-ammine 1:1 complex. |
| aqueous | `Zn$+2:1 L2:2` | yes | Unique Zn(II)-ammine 1:2 complex. |
| aqueous | `Zn$+2:1 L2:3` | yes | Unique Zn(II)-ammine 1:3 complex. |
| aqueous | `Zn$+2:1 L2:4` | yes | Unique Zn(II)-ammine 1:4 complex. |
| solid | `Cu$+0:1` | yes | Metallic Cu reference solid with valid mu. |
| solid | `Cu$+1:1 H:-1` | yes | Cuprite Cu2O solid with valid mu. |
| solid | `Zn$+0:1` | yes | Metallic Zn reference solid with valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu+ cation; prefer SRD-46 notation per plan rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+ aqueous ion; prefer SRD-46 per plan.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate notation for aqueous Zn2+; prefer SRD-46.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate: same mononuclear ZnOH+ cation; prefer SRD-46 over Atlas.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same anionic mononuclear Zn(II) hydroxo species written in two notations; prefer SRD-46 entry with lower aligned mu.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same zincate species in different notation (ZnO2^2- vs Zn(OH)4^2-); keep SRD-46 critically-evaluated form.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Prefer hydrated Cu(OH)2 over anhydrous CuO per addendum; between two Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Prefer hydrated Cu(OH)2 over anhydrous CuO per addendum; between two Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Kept all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and preferred SRD-46 epsilon over Atlas duplicate; dropped anhydrous ZnO forms per addendum favoring hydrated oxyhydroxides.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Kept all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and preferred SRD-46 epsilon over Atlas duplicate; dropped anhydrous ZnO forms per addendum favoring hydrated oxyhydroxides.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Kept all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and preferred SRD-46 epsilon over Atlas duplicate; dropped anhydrous ZnO forms per addendum favoring hydrated oxyhydroxides.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Kept all distinct Zn(OH)2 polymorphs (alpha, beta, gamma, amorphous) and preferred SRD-46 epsilon over Atlas duplicate; dropped anhydrous ZnO forms per addendum favoring hydrated oxyhydroxides.) |

# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L1_7_CuZn_glycine_ammonia_joint\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.32
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (6 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},
]
```

## Notes
T=25 C, I=0.1 m, and all four totals are explicitly stated by the task. Cu and Zn pinned at the +2 valence level (no redox in a pH sweep). pH is the swept axis and is not pinned.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
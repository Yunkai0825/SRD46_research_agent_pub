inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Cu2", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Zn2", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"],  "value": 1e-2, "basis": "known"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 1e-1, "basis": "known"},
]
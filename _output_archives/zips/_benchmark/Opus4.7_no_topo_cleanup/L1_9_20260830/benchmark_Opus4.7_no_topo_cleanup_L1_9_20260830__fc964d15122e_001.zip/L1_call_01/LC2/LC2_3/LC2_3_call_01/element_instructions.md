# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: aqueous speciation of dissolved Cu (1e-3 M total) with 0.1 M NH3/NH4+ buffer at fixed Eh = +0.265 V vs SHE, 25 C, I = 0.1 m, pH 0-14. This is a solution-chemistry / stability calculation, not corrosion, so the 1e-6 M convention does NOT apply; use 1e-3 M Cu when judging whether polynuclear hydrolysis species can compete.
- **Aqueous identity**: keep every distinct protonation / hydrolysis / ammine stoichiometry; at 1e-3 M Cu the dimer [Cu2(OH)2]2+ and trimer [Cu3(OH)4]2+ are genuine competitors and must be retained. Different spellings of the SAME formula and charge from Atlas vs SRD-46 (e.g. Cu+ vs [Cu]+, Cu2+ vs [Cu]2+) are pure notation duplicates — keep the Atlas spelling as canonical when mu_aligned agrees, since Atlas provides the reference frame here.
- **Solids / hydration**: user explicitly PREFERS hydroxide solids over oxides where both exist for the same Cu oxidation state. For Cu(II) that means keep Cu(OH)2 (drop CuO / [CuO](s)); for Cu(I) only Cu2O exists (no Cu(I) hydroxide in inventory), so retain Cu2O. Collapse the Atlas/SRD-46 pair of Cu(OH)2 to one entry (Atlas), and the Cu2O pair to one entry (Atlas), on ground-state / lowest-mu-consistent grounds.
- **Carbonates / counterions**: none in inventory and none implied by the ammonia-only ligand system — nothing to add or flag.
- **Mixed-valence oxides**: none present; not an issue.
- **Stable vs forms**: question is which species DOMINATES / PRECIPITATES at each pH, i.e. stable-phase / ground-state framing — polymorph collapse of the same chemistry is appropriate.
- **Elemental / gases**: retain metallic Cu(s) as the reduced-end reference solid; no gases in inventory.
- **Ligand note**: NH3(aq)/NH4+ itself is not in the Cu element list (it belongs to N inventory) — no action here, just noting the ligand is treated externally.

## Element instructions

- **Cu**: Treat Atlas vs SRD-46 pairs of identical formula+charge as notation duplicates and keep the Atlas spelling: drop [Cu]+ (keep Cu+), drop [Cu]2+ (keep Cu2+), drop [(Cu2O)0.5](s) (keep Cu2O), drop [Cu(OH)2](s) (keep Cu(OH)2); additionally drop both CuO entries (CuO and [CuO](s)) because the user prefers hydroxide over oxide for Cu(II) and Cu(OH)2 is available. Retain every distinct aqueous stoichiometry — all mononuclear hydrolysis species, the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ (justified at 1e-3 M Cu), all four Cu(II) ammine complexes and the Cu(I) diammine, plus Cu(s) and Cu2O(s) — these are all chemically distinct competitors on the Eh-pH-ammonia hull.

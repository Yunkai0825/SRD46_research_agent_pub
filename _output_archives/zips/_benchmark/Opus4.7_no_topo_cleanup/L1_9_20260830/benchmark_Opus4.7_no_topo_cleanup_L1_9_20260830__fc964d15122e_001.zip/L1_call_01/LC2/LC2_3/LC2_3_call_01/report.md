# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    164.35
- elapsed_s (total):  164.35
- llm_iterations:     27
- llm_tool_calls:     20

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Notation duplicates of same Cu(I) aqueous cation; keep Atlas spelling per case-specific instructions. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Same species, identical mu; keep Atlas spelling Cu2+ per element instruction to drop [Cu]2+ from SRD-46. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per element instructions as chemically distinct competitors. |
| solid | `Cu$+1:1 H:-1` | `Cu2O` [Atlas] | Notation duplicates of same Cu(I) oxide; keep Atlas spelling per element instructions. |
| solid | `Cu$+2:1 H:-2` | `Cu(OH)2` [Atlas] | User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference species, required infrastructure. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) diammine complex, distinct chemistry retained per element instructions. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) hydrolysis species, distinct stoichiometry. |
| aqueous | `Cu$+2:1 H:-3` | yes | Anionic Cu(II) hydrolysis species, distinct stoichiometry. |
| aqueous | `Cu$+2:1 H:-4` | yes | Dianionic Cu(II) hydrolysis species, distinct stoichiometry. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) monoammine complex, distinct chemistry. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) diammine complex, distinct chemistry. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II) triammine complex, distinct chemistry. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(II) tetraammine complex, distinct chemistry. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydrolysis trimer, competitive at 1e-3 M Cu. |
| aqueous | `L1:1` | yes | NH3(aq) ligand reference, required infrastructure. |
| aqueous | `L1:1 H:1` | yes | NH4+ ligand-conjugate acid reference, required infrastructure. |
| solid | `Cu$+0:1` | yes | Metallic Cu(s), reduced-end reference solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Notation duplicates of same Cu(I) aqueous cation; keep Atlas spelling per case-specific instructions. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Same species, identical mu; keep Atlas spelling Cu2+ per element instruction to drop [Cu]2+ from SRD-46. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: Notation duplicates of same Cu(I) oxide; keep Atlas spelling per element instructions. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| `CuO` | Atlas | dissolution | LC2 element review: User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: e130a64251f34f30b3c1b12e065c24e3
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu inventory deduplicated per committed instructions: Atlas spellings kept for Cu+/Cu2+/Cu2O/Cu(OH)2 notation duplicates; both CuO entries dropped per user's hydroxide-over-oxide preference for Cu(II); all distinct aqueous hydrolysis species (mononuclear, dinuclear [Cu2(OH)2]2+, trinuclear [Cu3(OH)4]2+ justified at 1e-3 M Cu), all four Cu(II) ammine complexes and the Cu(I) diammine, plus metallic Cu(s) retained as chemically distinct competitors on the Eh-pH-ammonia hull.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

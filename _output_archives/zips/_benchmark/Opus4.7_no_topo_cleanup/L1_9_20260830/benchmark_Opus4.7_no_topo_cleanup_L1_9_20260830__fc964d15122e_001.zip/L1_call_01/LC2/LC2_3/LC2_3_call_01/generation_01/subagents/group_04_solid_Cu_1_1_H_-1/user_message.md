[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Treat Atlas vs SRD-46 pairs of identical formula+charge as notation duplicates and keep the Atlas spelling: drop [Cu]+ (keep Cu+), drop [Cu]2+ (keep Cu2+), drop [(Cu2O)0.5](s) (keep Cu2O), drop [Cu(OH)2](s) (keep Cu(OH)2); additionally drop both CuO entries (CuO and [CuO](s)) because the user prefers hydroxide over oxide for Cu(II) and Cu(OH)2 is available. Retain every distinct aqueous stoichiometry — all mononuclear hydrolysis species, the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ (justified at 1e-3 M Cu), all four Cu(II) ammine complexes and the Cu(I) diammine, plus Cu(s) and Cu2O(s) — these are all chemically distinct competitors on the Eh-pH-ammonia hull.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 |
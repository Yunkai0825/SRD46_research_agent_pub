## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct.
Return the pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous speciation of dissolved Cu (1e-3 M total) with 0.1 M NH3/NH4+ buffer at fixed Eh = +0.265 V vs SHE, 25 C, I = 0.1 m, pH 0-14. This is a solution-chemistry / stability calculation, not corrosion, so the 1e-6 M convention does NOT apply; use 1e-3 M Cu when judging whether polynuclear hydrolysis species can compete.
- **Aqueous identity**: keep every distinct protonation / hydrolysis / ammine stoichiometry; at 1e-3 M Cu the dimer [Cu2(OH)2]2+ and trimer [Cu3(OH)4]2+ are genuine competitors and must be retained. Different spellings of the SAME formula and charge from Atlas vs SRD-46 (e.g. Cu+ vs [Cu]+, Cu2+ vs [Cu]2+) are pure notation duplicates — keep the Atlas spelling as canonical when mu_aligned agrees, since Atlas provides the reference frame here.
- **Solids / hydration**: user explicitly PREFERS hydroxide solids over oxides where both exist for the same Cu oxidation state. For Cu(II) that means keep Cu(OH)2 (drop CuO / [CuO](s)); for Cu(I) only Cu2O exists (no Cu(I) hydroxide in inventory), so retain Cu2O. Collapse the Atlas/SRD-46 pair of Cu(OH)2 to one entry (Atlas), and the Cu2O pair to one entry (Atlas), on ground-state / lowest-mu-consistent grounds.
- **Carbonates / counterions**: none in inventory and none implied by the ammonia-only ligand system — nothing to add or flag.
- **Mixed-valence oxides**: none present; not an issue.
- **Stable vs forms**: question is which species DOMINATES / PRECIPITATES at each pH, i.e. stable-phase / ground-state framing — polymorph collapse of the same chemistry is appropriate.
- **Elemental / gases**: retain metallic Cu(s) as the reduced-end reference solid; no gases in inventory.
- **Ligand note**: NH3(aq)/NH4+ itself is not in the Cu element list (it belongs to N inventory) — no action here, just noting the ligand is treated externally.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Treat Atlas vs SRD-46 pairs of identical formula+charge as notation duplicates and keep the Atlas spelling: drop [Cu]+ (keep Cu+), drop [Cu]2+ (keep Cu2+), drop [(Cu2O)0.5](s) (keep Cu2O), drop [Cu(OH)2](s) (keep Cu(OH)2); additionally drop both CuO entries (CuO and [CuO](s)) because the user prefers hydroxide over oxide for Cu(II) and Cu(OH)2 is available. Retain every distinct aqueous stoichiometry — all mononuclear hydrolysis species, the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ (justified at 1e-3 M Cu), all four Cu(II) ammine complexes and the Cu(I) diammine, plus Cu(s) and Cu2O(s) — these are all chemically distinct competitors on the Eh-pH-ammonia hull.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 |

## Assistant
<summary>Notation duplicates; keep Atlas Cu+ per instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Kept Atlas Cu+ as canonical.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept Cu+ (Atlas) as the canonical spelling; dropped [Cu]+ (SRD-46) as a pure notation duplicate per element instructions.
</answer>
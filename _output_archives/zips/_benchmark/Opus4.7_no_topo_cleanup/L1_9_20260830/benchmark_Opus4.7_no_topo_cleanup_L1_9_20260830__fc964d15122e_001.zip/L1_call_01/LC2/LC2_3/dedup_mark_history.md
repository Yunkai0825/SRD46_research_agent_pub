# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Notation duplicates of same Cu(I) aqueous cation; keep Atlas spelling per case-specific instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Notation duplicates of same Cu(I) aqueous cation; keep Atlas spelling per case-specific instructions. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) diammine complex, distinct chemistry retained per element instructions. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Same species, identical mu; keep Atlas spelling Cu2+ per element instruction to drop [Cu]2+ from SRD-46. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Same species, identical mu; keep Atlas spelling Cu2+ per element instruction to drop [Cu]2+ from SRD-46. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per element instructions as chemically distinct competitors. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per element instructions as chemically distinct competitors. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) hydrolysis species, distinct stoichiometry. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Anionic Cu(II) hydrolysis species, distinct stoichiometry. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Dianionic Cu(II) hydrolysis species, distinct stoichiometry. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II) monoammine complex, distinct chemistry. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II) diammine complex, distinct chemistry. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II) triammine complex, distinct chemistry. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II) tetraammine complex, distinct chemistry. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis trimer, competitive at 1e-3 M Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Metallic Cu(s), reduced-end reference solid. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: kept — Notation duplicates of same Cu(I) oxide; keep Atlas spelling per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: dropped — Notation duplicates of same Cu(I) oxide; keep Atlas spelling per element instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: kept — User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — User prefers hydroxide over oxide for Cu(II); drop both CuO entries and keep Atlas Cu(OH)2 as canonical over SRD-46 notation duplicate. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference species, required infrastructure. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — NH3(aq) ligand reference, required infrastructure. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ ligand-conjugate acid reference, required infrastructure. |

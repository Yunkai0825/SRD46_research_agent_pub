# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.29
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH at fixed Eh; Eh is a condition, not an independent axis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_9_Cu_ammonia_speciation_E0265\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated in task"},
  {"id": "E",  "lhs": lambda s: s.E_V,            "value": 0.265,  "basis": "known", "note": "Fixed Eh vs SHE from task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1.0e-3, "basis": "known", "note": "Total Cu across all oxidation states"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_10103"], "value": 0.100, "basis": "known", "note": "Total ammonia NH3/NH4+ from task"},
]
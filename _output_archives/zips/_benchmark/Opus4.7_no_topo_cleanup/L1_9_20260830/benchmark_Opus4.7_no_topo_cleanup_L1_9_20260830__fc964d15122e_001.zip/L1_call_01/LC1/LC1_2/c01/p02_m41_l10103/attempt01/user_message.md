[Purpose: Compute the pH-speciation of Cu with 0.1 M total ammonia at fixed Eh = +0.265 V vs SHE, preferring hydroxide solids.]
[Tasks:
Model a solution containing 1.00e-3 M total Cu and 0.100 M total ammonia (NH3/NH4+) at fixed Eh = +0.265 V versus SHE. Sweep pH from 0 to 14 at 25 C and ionic strength I = 0.1 m. Prefer hydroxide solids over oxides when both are available. Report the dominant Cu species at each pH, the pH windows where each species dominates, and any solid precipitation. Include the fraction envelopes for the Cu component.
]
[Pair: pair_key=`m41_l10103`, metal_id=41, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10103_beta840_net28241`
  - `metal41_ligand10103_beta894_net28241`
  - `metal41_ligand10103_beta872_net28241`
[Screen report]
# Eq-map screen — m41_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10103_beta840_net28241` | `[M] + [L]^2 <=> [ML2]` | vlm_173258@(25.0,0.0) = K+7.400 | 4 | +7.400 / +7.665 / +7.660 / +7.910 | vlm_173258@(25.0,0.0) = K+7.400 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal41_ligand10103_beta812_net28241` | `[M] + [L] <=> [ML]` | vlm_173242@(25.0,0.1) = K+4.100 | 5 | +4.020 / +4.120 / +4.148 / +4.300 | vlm_173242@(25.0,0.1) = K+4.100 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10103_beta894_net28241` | `[M] + [L]^4 <=> [ML4]` | vlm_173282@(25.0,0.0) = K+12.300 | 4 | +12.300 / +12.750 / +12.750 / +13.200 | vlm_173282@(25.0,0.0) = K+12.300 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal41_ligand10103_beta872_net28241` | `[M] + [L]^3 <=> [ML3]` | vlm_173270@(25.0,0.0) = K+10.200 | 4 | +10.200 / +10.500 / +10.500 / +10.800 | vlm_173270@(25.0,0.0) = K+10.200 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

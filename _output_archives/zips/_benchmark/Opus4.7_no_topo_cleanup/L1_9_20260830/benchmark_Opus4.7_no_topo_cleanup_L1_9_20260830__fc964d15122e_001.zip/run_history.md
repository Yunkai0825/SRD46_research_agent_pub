# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.\n'; max_iterations=8; reasoning_timeout_s=600.0 |
|   5.506 | L1_start | call=1; purpose='Compute the pH-speciation of Cu with 0.1 M total ammonia at fixed Eh = +0.265 V vs SHE, preferring hydroxide solids.' |
| 370.646 | L1_end | call=1; elapsed_s=365.1; ran_ok=True; attempts=1 |
| 390.105 | L0_end | elapsed_s=390.09555101394653; iterations=2; timed_out=False |

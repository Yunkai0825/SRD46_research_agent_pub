## Answer

The ternary mixed-ligand complex **Ni(glycinate)(ammonia)** is **not present in the SRD-46 species set** used for this calculation. Within this model its abundance at pH 8 is therefore **0% of total Ni by construction** — not because thermodynamics excludes it, but because no stability constant for that species is tabulated. SRD-46 is largely a compilation of *binary* metal–ligand systems, and every Ni complex in the species list carries either glycinate-only or ammine-only ligation, never both.

So the honest answer to the headline question is: **the SRD-46 build cannot quantify this species.** To get a real number you would need to import a mixed-ligand log K for Ni(Gly)(NH₃) from a dedicated compilation (e.g. Sigel/Martell mixed-ligand reviews) and rebuild the chemistry card.

### Chemical context at pH 8 (what the binary calculation *does* show)
- The Ni coordination sphere at pH 8 is overwhelmingly occupied by **glycinate, not ammine**: **[Ni(Glyc)₂]⁰ ≈ 65–69 %** of total Ni (it peaks at 69.2 % at pH 7.9), flanked by [Ni(Glyc)]⁺ on the acid side and [Ni(Glyc)₃]⁻ on the alkaline side.
- **No Ni–ammine complex appears as dominant in any pH window.** The reason is two-fold: (i) at pH 8, ammonia is still ~95% protonated as NH₄⁺ (the NH₃/NH₄⁺ pKₐ is ~9.25), leaving free [NH₃] only ~5 × 10⁻⁴ M; and (ii) glycinate is a **bidentate chelate** (5-membered N,O ring), which gives it a large entropic advantage over monodentate NH₃ even when their effective free-ligand concentrations are comparable.
- Hydrolysis to Ni(OH)₂(s) does not begin until pH ≳ 11, so the system is fully soluble at pH 8.

A plausible *outside* estimate — combining the residual ~25–30 % of Ni in mono-glycinate form with the small free-[NH₃] available and a typical log K₁(Ni–NH₃) ≈ 2.7 — would place a real Ni(Gly)(NH₃) species at perhaps a few percent of total Ni, but this is a back-of-envelope bound, **not** a value from the calculation.

## Evidence
- "the requested ternary mixed-ligand complex Ni(glycinate)(ammonia) is **not present in the SRD-46 species set**"
- "every Ni complex carries either L1 only or L2 only, never both"
- "Within this calculation its fraction is therefore identically **0% by construction**"
- "[Ni(Glyc)₂]⁰ … peaks at **69.2 % of total Ni at pH 7.9** … At pH 8 it therefore sits very near its maximum, ~65–69 %"
- "ammonia is essentially fully protonated as NH₄⁺ below pH 9.3 … free-NH₃ activity available to bind Ni at pH 8 is ~10⁻¹·³ of total = a few × 10⁻⁴ M"
- "Hydrolysis to [Ni(OH)₂](s) only sets in above pH 11.4"

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Glycine_+_Ammonia_envelope_Ni$+2.csv`
- `L1_call_01/solver/Ni$+2_+_Glycine_+_Ammonia_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Glycine_+_Ammonia_log_conc.png`
# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.23
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH to extract ternary complex fraction at pH 8.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
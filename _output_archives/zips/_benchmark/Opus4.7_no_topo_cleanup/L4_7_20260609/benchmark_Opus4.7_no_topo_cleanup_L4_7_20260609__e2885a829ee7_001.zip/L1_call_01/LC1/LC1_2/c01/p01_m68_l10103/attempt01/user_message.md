[Purpose: Quantify the abundance of the ternary mixed-ligand complex Ni(glycine)(ammonia) in a Ni(II)/glycine/ammonia solution at pH 8.]
[Tasks:
Model a single pot containing 1 mM Ni(II) with 5 mM glycine and 5 mM ammonia together at 25 C and ionic strength 0.1 m. Compute the full speciation across pH 2-12 (so a curve is available) and report the percentage of total Ni present as the ternary mixed-ligand complex Ni(glycine)(ammonia) - i.e. the single species bearing one glycinate and one ammonia on the same Ni center - at pH 8. Also report the dominant Ni species at pH 8 for context.
]
[Pair: pair_key=`m68_l10103`, metal_id=68, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10103_beta79_net28179` | `[L] + [H] <=> [HL]` | vlm_173034@(25.0,0.1) = K+9.260 | 20 | +8.805 / +9.540 / +9.585 / +10.450 | vlm_173034@(25.0,0.1) = K+9.260 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    135.93
- elapsed_s (total):  135.94
- llm_iterations:     23
- llm_tool_calls:     18

- n_groups:           23
- n_multi_groups:     4
- n_singletons:       19
- n_decisions:        23
- n_dropped:          4
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; prefer SRD-46 entry. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity: mononuclear NiOH+ vs tetranuclear Ni4(OH)4^4+ are different species per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same species (Ni(II) trihydroxo anion) in different notation; prefer SRD-46 critically-evaluated value. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni(II) polymorph for aqueous speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid reference species; sole member. |
| aqueous | `L2:1` | yes | Valid reference species; sole member. |
| aqueous | `L2:1 H:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:5` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L2:6` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+0:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; prefer SRD-46 entry.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same species (Ni(II) trihydroxo anion) in different notation; prefer SRD-46 critically-evaluated value.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni(II) polymorph for aqueous speciation.) |
| `NiO` | Atlas | dissolution | dedup: excluded (SRD-46 [Ni(OH)2](s) preferred over Atlas Ni(OH)2 duplicate; anhydrous NiO dropped per addendum favoring hydrated Ni(II) polymorph for aqueous speciation.) |

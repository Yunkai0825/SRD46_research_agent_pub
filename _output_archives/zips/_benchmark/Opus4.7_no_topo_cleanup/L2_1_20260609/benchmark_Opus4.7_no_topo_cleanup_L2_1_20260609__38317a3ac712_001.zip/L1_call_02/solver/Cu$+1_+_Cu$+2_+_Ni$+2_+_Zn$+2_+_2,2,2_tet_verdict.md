# Speciation Calculation Report: Cu$+1 + Cu$+2 + Ni$+2 + Zn$+2 + 2,2,2-tet

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00975945 – 0.0100058 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 41
- Converged: 41/41

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 1.00e-03 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Ni$+0 | Ni(s) | 0.00e+00 | metal |
| Ni$+2 | Ni2+ | 1.00e-03 | metal |
| Ni$+3 | Ni(+3) | 0.00e+00 | metal |
| Ni$+4 | Ni(+4) | 0.00e+00 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | 2,2,2-tet | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H22,2,2-tet2+ | aqueous | L1:+1 H:+2 | — | -107.4188 | -107.4188 |
| H2,2,2-tet+ | aqueous | L1:+1 H:+1 | — | -55.6500 | -55.6500 |
| 2,2,2-tet | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(2,2,)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -114.4963 | -114.4963 |
| Ni2+ | aqueous | Ni$+2:+1 | — | -0.0000 | +0.0000 |
| [Ni(OH)]+ | aqueous | H:-1 Ni$+2:+1 | — | +59.3600 | +59.3600 |
| [Ni(OH)2] | aqueous | H:-2 Ni$+2:+1 | — | +108.4461 | +108.4461 |
| [Ni(OH)3]- | aqueous | H:-3 Ni$+2:+1 | — | +171.2308 | +171.2308 |
| [Ni4(OH)4]4+ | aqueous | H:-4 Ni$+2:+4 | — | +158.1031 | +158.1031 |
| [Ni(2,2,)]2+ | aqueous | L1:+1 Ni$+2:+1 | — | -78.5676 | -78.5676 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +90.1815 | +90.1815 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(2,2,)]2+ | aqueous | L1:+1 Zn$+2:+1 | — | -67.0631 | -67.0631 |
| Cu2O | dissolution | Cu$+1:+2 H:-2 | — | +2.9706 | +2.9706 |
| [Cu(OH)2](s) | dissolution | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | dissolution | Cu$+0:+1 | — | +0.0000 | +0.0000 |
| [Ni(OH)2](s) | dissolution | H:-2 Ni$+2:+1 | — | +73.0585 | +73.0585 |
| Ni3O4.2H2O | dissolution | H:-8 Ni$+2:+3 | — | +861.9040 | +861.9040 |
| Ni2O3.H2O | dissolution | H:-6 Ni$+3:+2 | — | -570.2374 | -570.2374 |
| NiO2.2H2O | dissolution | H:-4 Ni$+4:+1 | — | +0.0000 | +0.0000 |
| Ni | dissolution | Ni$+0:+1 | — | +0.0000 | +0.0000 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 6.00: Cu2O (4.99e-04 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  Cu2O                peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  Cu2O

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Cu(2,2,)]2+        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Cu(2,2,)]2+

Crossover pH values:

=== Ni(s) (Ni$+0) speciation ===
[Ni$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni2+ (Ni$+2) speciation ===
[Ni$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Ni(2,2,)]2+        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Ni(2,2,)]2+

Crossover pH values:

=== Ni(+3) (Ni$+3) speciation ===
[Ni$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ni(+4) (Ni$+4) speciation ===
[Ni$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Zn(2,2,)]2+        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Zn(2,2,)]2+

Crossover pH values:

=== 2,2,2-tet (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H22,2,2-tet2+       peak 40.0% at pH 6.0
  [Cu(2,2,)]2+        peak 20.0% at pH 8.0
  [Ni(2,2,)]2+        peak 20.0% at pH 8.0
  [Zn(2,2,)]2+        peak 20.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  H22,2,2-tet2+

```
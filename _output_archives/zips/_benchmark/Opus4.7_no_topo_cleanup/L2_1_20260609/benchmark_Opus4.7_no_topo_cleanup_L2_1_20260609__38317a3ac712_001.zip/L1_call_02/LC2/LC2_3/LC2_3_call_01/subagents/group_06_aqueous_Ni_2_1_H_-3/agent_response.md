# LC2_3 group [aqueous::Ni$+2:1 H:-3] agent response

## Final answer (text emitted by the agent)

Kept `[Ni(OH)3]-` (SRD-46) as the canonical mononuclear Ni(II) trihydroxo anion; `[HNiO2]-` from Atlas is a notational variant of the same species (HNiO2⁻ + H2O ≡ Ni(OH)3⁻), so SRD-46 is preferred per rule 1.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from two databases — SRD-46 (NIST critically-evaluated
reference) and the Pourbaix Atlas (auxiliary).  All members share the
same "core" elemental stoichiometry but may still be different species
(different charge, nuclearity, phase, hydration, or aligned chemical
potential `mu_aligned_kJ`).

Your task: decide which species names in this group to KEEP after
deduplication, following the deduplication plan supplied in the user
message.  Return the list verbatim via `finalize_group_decision`.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_names": ["<exact species name>", ...],
   "rationale":  "<one sentence>"}

The names MUST match the `name` field shown in the user message
exactly.  After a successful `finalize_group_decision` you may emit
your answer block.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture the LLM's keep_names + rationale for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

Decide which species to KEEP per core-stoichiometry group; never re-merge or edit μ. Dropped rows are flagged `include=false` (kept for audit). A purpose-derived **addendum** may refine these defaults and wins on points it addresses. Members share a *core* ratio but may still be distinct species — judge by full formula and nuclearity, not the core alone.

1. **True duplicate = same species, different notation only**: identical phase, charge, AND nuclearity/`multiplier` ⇒ keep one. Prefer SRD-46; if both same-source, keep the lower `mu_aligned_kJ`. Species with very close mu may be a good starting point to inspect the species in detail.
2. **Keep distinct chemistry**: any difference in charge, oxidation state, phase, nuclearity (a polynuclear species is NOT the same as its mononuclear form even at equal core ratio), or hydration/polymorph is a *different* species — keep it. 
3. **Never empty a group** — at least one species must survive every group.
4. **When unsure, keep** — speciation needs full redox/phase/nuclearity coverage and a dropped species is unrecoverable. Defer polymorph/hydrate pruning to the addendum.

## Calculation-specific addendum

- Aqueous near-neutral pH 6-8 system: for any same-core solid duplicates, prefer the hydrated oxyhydroxide that would precipitate from solution; the anhydrous oxide polymorph may be dropped.
- Scope is Cu/Zn/Ni + trien + H2O/OH only; singletons containing other metals or non-aqueous-relevant phases are out of scope and may be pruned.


[Group: phase=aqueous core_label=Ni$+2:1 H:-3 n_species=2]

| name | source | charge | mu_aligned_kJ | multiplier |
|------|--------|-------:|--------------:|-----------:|
| `[HNiO2]-` | Atlas | -1 | 169.996 | 1 |
| `[Ni(OH)3]-` | SRD-46 | -1 | 171.231 | 1 |

## Assistant
<summary>Both species have identical core stoichiometry (Ni, -3H equivalent), charge -1, mononuclear, aqueous. [HNiO2]- and [Ni(OH)3]- are notational variants of the same species (HNiO2- + H2O = Ni(OH)3-). Prefer SRD-46 per plan rule 1.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_names": ["[Ni(OH)3]-…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Finalized: kept SRD-46 [Ni(OH)3]- as the canonical form.</summary>

<answer>
Kept `[Ni(OH)3]-` (SRD-46) as the canonical mononuclear Ni(II) trihydroxo anion; `[HNiO2]-` from Atlas is a notational variant of the same species (HNiO2⁻ + H2O ≡ Ni(OH)3⁻), so SRD-46 is preferred per rule 1.
</answer>

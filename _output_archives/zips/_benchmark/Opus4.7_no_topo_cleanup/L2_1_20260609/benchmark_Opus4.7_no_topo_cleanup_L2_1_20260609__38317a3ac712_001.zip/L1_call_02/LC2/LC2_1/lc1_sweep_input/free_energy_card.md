# Free Energy Analysis Card

**System**: H, Cu, Zn, Ni / 2,2,2-tet, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Zn]2+, [Ni]2+
**Ligands**: [2,2,2-tet]
**Generated**: 2026-06-09 17:40:29 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| M3 | Metal component: [Zn]2+ |
| M4 | Metal component: [Ni]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [2,2,2-tet] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | 0.001 | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | 0.001 | NIST SRD-46 | metal_42 |
| M3 | [Zn]2+ | +2 | 0.001 | NIST SRD-46 | metal_208 |
| M4 | [Ni]2+ | +2 | 0.001 | NIST SRD-46 | metal_112 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [2,2,2-tet] | +0 | 0.01 | [[L1]] | NIST SRD-46 | ligand_7224 | NCCNCCNCCN |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |
| Ni | M4 | [Ni]2+ | +2 | true | 1 |
| Zn | M3 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [2,2,2-tet] | NCCNCCNCCN | C | [-1, -1, -1, -1, -1, -1] | false |
| L1 | [2,2,2-tet] | NCCNCCNCCN | N | [-3, -3, -3, -3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| M3 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| M4 | [Ni]2+ | metal | [Ni]2+(aq) | +0.0000 | R1 | Ni | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [2,2,2-tet] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [2,2,2-tet] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [2,2,2-tet] | 25.0 | 0.1 | *** | 4 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [2,2,2-tet] | 25.0 | 0.1 | 10650 | 3 |
| [Cu]2+ + *** | 25.0 | 0~0.1 | *** | 6 |
| [Cu]+ + *** | 25.0 | 0 | *** | 1 |
| [Zn]2+ + [2,2,2-tet] | 20.0~25.0 | 0.1 | 10659 | 2 |
| [Zn]2+ + *** | 25.0 | 0~0.1 | *** | 11 |
| [Ni]2+ + [2,2,2-tet] | 20.0~25.0 | 0.1 | 10646 | 2 |
| [Ni]2+ + *** | 25.0 | 0~0.1 | *** | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [2,2,2-tet] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H]2[L1]].[z+2] | [H22,2,2-tet]2+ | +2 | aqueous | +18.8200 | -107.4188 | -107.4188 | -107.4188 | [[H]2[L1]]:+1 | vlm_125966, vlm_125975 | *** |
| [[H][L1]].[z+1] | [H2,2,2-tet]+ | +1 | aqueous | +9.7500 | -55.6500 | -55.6500 | -55.6500 | [[H][L1]]:+1 | vlm_125966 | *** |
| [L1].[z+0] | [2,2,2-tet] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cu]2+ + [2,2,2-tet]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1].[z+2] | [Cu(2,2,)]2+ | +2 | aqueous | +20.0600 | -114.4963 | -114.4963 | -114.4963 | [M1]:+1, [L1]:+1 | vlm_126033 | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Zn]2+ + [2,2,2-tet]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[L1].[z+2] | [Zn(2,2,)]2+ | +2 | aqueous | +11.9500 | -67.0631 | -67.0631 | -67.0631 | [M3]:+1, [L1]:+1 | vlm_126058 | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M3]:+1, [OH]:+1 | vlm_170929 | *** |
| [M3].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -15.8000 | +90.1815 | +90.1815 | +90.1815 | [M3]:+1, [OH]:+2 | vlm_170935 | *** |
| [M3].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M3]:+1, [OH]:+3 | vlm_170937 | *** |
| [M3].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M3]:+1, [OH]:+4 | vlm_170939 | *** |

#### [Ni]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[z+2] | [Ni]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Ni]2+ + [2,2,2-tet]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[L1].[z+2] | [Ni(2,2,)]2+ | +2 | aqueous | +14.0000 | -78.5676 | -78.5676 | -78.5676 | [M4]:+1, [L1]:+1 | vlm_126021 | *** |

#### [Ni]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH].[z+1] | [Ni(OH)]+ | +1 | aqueous | -10.4000 | +59.3600 | +59.3600 | +59.3600 | [M4]:+1, [OH]:+1 | vlm_170699 | *** |
| [M4].[OH]2.[z+0] | [Ni(OH)2] | +0 | aqueous | -19.0000 | +108.4461 | +108.4461 | +108.4461 | [M4]:+1, [OH]:+2 | vlm_170704 | *** |
| [M4]4.[OH]4.[z+4] | [Ni4(OH)4]4+ | +4 | aqueous | -27.7000 | +158.1031 | +158.1031 | +158.1031 | [M4]:+4, [OH]:+4 | vlm_170709 | *** |
| [M4].[OH]3.[z-1] | [Ni(OH)3]- | -1 | aqueous | -30.0000 | +171.2308 | +171.2308 | +171.2308 | [M4]:+1, [OH]:+3 | vlm_170705 | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]2.[z+0]_(s) | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M3].[OH]2.[[z+0(s)[1]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M3]:+1, [OH]:+2 | vlm_170956 | *** |

#### [Ni]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Ni(OH)2](s) | +0 | dissolution | -12.8000 | +73.0585 | +73.0585 | +73.0585 | [M4]:+1, [OH]:+2 | vlm_170712 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 35 |
| Included in calculation | 35 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 20 |
| Unresolved (no species in card) | 15 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_125984 | [<H+>2<2,2,2-tet>] + [<H+>] <=> [<H+>3<2,2,2-tet>] | +6.5800 | 25.0 | 0.100 | yes | — |
| 2 | vlm_125993 | [<H+>3<2,2,2-tet>] + [<H+>] <=> [<H+>4<2,2,2-tet>] | +3.2700 | 25.0 | 0.100 | yes | — |
| 3 | vlm_125966 | [<H+>] + [<2,2,2-tet>] <=> [<H+><2,2,2-tet>] | +9.7500 | 25.0 | 0.100 | yes | [H22,2,2-tet]2+, [H2,2,2-tet]+ |
| 4 | vlm_125975 | [<H+><2,2,2-tet>] + [<H+>] <=> [<H+>2<2,2,2-tet>] | +9.0700 | 25.0 | 0.100 | yes | [H22,2,2-tet]2+ |
| 5 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 6 | vlm_126040 | [<H+>] + [<Cu2+><2,2,2-tet>] <=> [<Cu2+><H+><2,2,2-tet>] | +3.6300 | 25.0 | 0.100 | yes | — |
| 7 | vlm_126033 | [<2,2,2-tet>] + [<Cu2+>] <=> [<Cu2+><2,2,2-tet>] | +20.0600 | 25.0 | 0.100 | yes | [Cu(2,2,)]2+ |
| 8 | vlm_126044 | [<H+>] + [<Cu2+>(<O<H+>>)<2,2,2-tet>] <=> [H+2O] + [<Cu2+><2,2,2-tet>] | +10.7000 | 25.0 | 0.100 | yes | — |
| 9 | vlm_170721 | [<OH+->]^2 + [<Cu2+>] <=> [<Cu2+><OH+->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 10 | vlm_170727 | [<OH+->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH+->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 11 | vlm_170736 | [<OH+->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH+->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 12 | vlm_170713 | [<OH+->] + [<Cu2+>] <=> [<Cu2+><OH+->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 13 | vlm_170742 | [<Cu2+><OH+->2(s)] <=> [<OH+->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 14 | vlm_170746 | [H+2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [O<H+>]^2 | -20.3500 | 25.0 | 0.000 | yes | — |
| 15 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H+2O]^0 <=> [<Cu+>] + [O<H+>] | -14.7000 | 25.0 | 0.000 | yes | — |
| 16 | vlm_126065 | [<H+>] + [<Zn2+><2,2,2-tet>] <=> [<Zn2+><H+><2,2,2-tet>] | +5.1000 | 20.0 | 0.100 | yes | — |
| 17 | vlm_126058 | [<2,2,2-tet>] + [<Zn2+>] <=> [<Zn2+><2,2,2-tet>] | +11.9500 | 25.0 | 0.100 | yes | [Zn(2,2,)]2+ |
| 18 | vlm_170929 | [<OH+->] + [<Zn2+>] <=> [<Zn2+><OH+->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 19 | vlm_170935_patched | [<OH+->]^2 + [<Zn2+>] <=> [<Zn2+><OH+->2] | +12.2000 | 25.0 | 0.000 | yes | — |
| 20 | vlm_170937 | [<OH+->]^3 + [<Zn2+>] <=> [<Zn2+><OH+->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 21 | vlm_170939 | [<OH+->]^4 + [<Zn2+>] <=> [<Zn2+><OH+->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 22 | vlm_170944 | [<Zn2+><OH+->2(s,am)] <=> [<OH+->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | — |
| 23 | vlm_170948 | [<Zn2+><OH+->2(s,beta1)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | — |
| 24 | vlm_170950 | [<Zn2+><OH+->2(s,beta2)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | — |
| 25 | vlm_170952 | [<Zn2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | — |
| 26 | vlm_170954 | [<Zn2+><OH+->2(s,delta)] <=> [<OH+->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | — |
| 27 | vlm_170956 | [<Zn2+><OH+->2(s,epsilon)] <=> [<OH+->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 28 | vlm_170958 | [H+2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [O<H+>]^2 | -15.9600 | 25.0 | 0.100 | yes | — |
| 29 | vlm_126028 | [<H+>] + [<Ni2+><2,2,2-tet>] <=> [<Ni2+><H+><2,2,2-tet>] | +4.8000 | 20.0 | 0.100 | yes | — |
| 30 | vlm_126021 | [<2,2,2-tet>] + [<Ni2+>] <=> [<Ni2+><2,2,2-tet>] | +14.0000 | 25.0 | 0.100 | yes | [Ni(2,2,)]2+ |
| 31 | vlm_170699 | [<OH+->] + [<Ni2+>] <=> [<Ni2+><OH+->] | +3.6000 | 25.0 | 0.100 | yes | [Ni(OH)]+ |
| 32 | vlm_170704 | [<OH+->]^2 + [<Ni2+>] <=> [<Ni2+><OH+->2] | +9.0000 | 25.0 | 0.000 | yes | [Ni(OH)2] |
| 33 | vlm_170705 | [<OH+->]^3 + [<Ni2+>] <=> [<Ni2+><OH+->3] | +12.0000 | 25.0 | 0.000 | yes | [Ni(OH)3]- |
| 34 | vlm_170709 | [<OH+->]^4 + [<Ni2+>]^4 <=> [<Ni2+>4<OH+->4] | +28.3000 | 25.0 | 0.000 | yes | [Ni4(OH)4]4+ |
| 35 | vlm_170712 | [<Ni2+><OH+->2(s)] <=> [<OH+->]^2 + [<Ni2+>] | -15.2000 | 25.0 | 0.000 | yes | [Ni(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    129.97
- elapsed_s (total):  129.98
- llm_iterations:     45
- llm_tool_calls:     32

- n_groups:           33
- n_multi_groups:     13
- n_singletons:       20
- n_decisions:        33
- n_dropped:          16
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicates of monovalent Cu+ aqueous ion; prefer SRD-46 per plan rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of aqueous Cu2+ ion with identical mu; prefer SRD-46 source. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu hydroxo species are distinct chemistry per rule 2. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; keep SRD-46 entry per plan rule 1. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and charge make these distinct species. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | True notational duplicates (HNiO2- ≡ Ni(OH)3-); kept SRD-46 per preference. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of aqueous Zn2+; keep SRD-46 notation per plan. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate of mononuclear ZnOH+ aqueous cation; keep SRD-46 per plan. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | Same monomeric Zn(II) hydroxo anion in different notation (Zn(OH)3- vs HZnO2-); keep SRD-46 entry with lower aligned mu. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same species in different notation (ZnO2^2- + 2H2O = Zn(OH)4^2-); kept SRD-46 critically-evaluated form. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated hydroxide over anhydrous CuO for near-neutral aqueous system; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source). |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Prefer SRD-46 Ni(OH)2 over Atlas duplicate; drop anhydrous NiO in favor of hydrated hydroxide per addendum. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum favoring hydrated hydroxide; dropped Atlas epsilon as duplicate of SRD-46 epsilon; retained distinct Zn(OH)2 polymorphs. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ. |
| aqueous | `L1:1` | yes | Reference ligand species. |
| aqueous | `L1:1 H:1` | yes | Valid mu_aligned_kJ. |
| aqueous | `L1:1 H:2` | yes | Valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu_aligned_kJ. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu_aligned_kJ. |
| solid | `Cu$+0:1` | yes | Metal reference. |
| solid | `Cu$+1:1 H:-1` | yes | Valid mu_aligned_kJ. |
| solid | `Ni$+0:1` | yes | Metal reference. |
| solid | `Ni$+2:3 H:-8` | yes | Valid mu_aligned_kJ. |
| solid | `Ni$+3:1 H:-3` | yes | Valid mu_aligned_kJ. |
| solid | `Ni$+4:1 H:-4` | yes | Valid mu_aligned_kJ. |
| solid | `Zn$+0:1` | yes | Metal reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicates of monovalent Cu+ aqueous ion; prefer SRD-46 per plan rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Cu2+ ion with identical mu; prefer SRD-46 source.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; keep SRD-46 entry per plan rule 1.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (True notational duplicates (HNiO2- ≡ Ni(OH)3-); kept SRD-46 per preference.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Zn2+; keep SRD-46 notation per plan.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate of mononuclear ZnOH+ aqueous cation; keep SRD-46 per plan.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded (Same monomeric Zn(II) hydroxo anion in different notation (Zn(OH)3- vs HZnO2-); keep SRD-46 entry with lower aligned mu.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same species in different notation (ZnO2^2- + 2H2O = Zn(OH)4^2-); kept SRD-46 critically-evaluated form.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated hydroxide over anhydrous CuO for near-neutral aqueous system; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated hydroxide over anhydrous CuO for near-neutral aqueous system; between duplicate Cu(OH)2 entries keep SRD-46 (lower mu and preferred source).) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Ni(OH)2 over Atlas duplicate; drop anhydrous NiO in favor of hydrated hydroxide per addendum.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 Ni(OH)2 over Atlas duplicate; drop anhydrous NiO in favor of hydrated hydroxide per addendum.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated hydroxide; dropped Atlas epsilon as duplicate of SRD-46 epsilon; retained distinct Zn(OH)2 polymorphs.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated hydroxide; dropped Atlas epsilon as duplicate of SRD-46 epsilon; retained distinct Zn(OH)2 polymorphs.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated hydroxide; dropped Atlas epsilon as duplicate of SRD-46 epsilon; retained distinct Zn(OH)2 polymorphs.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated hydroxide; dropped Atlas epsilon as duplicate of SRD-46 epsilon; retained distinct Zn(OH)2 polymorphs.) |

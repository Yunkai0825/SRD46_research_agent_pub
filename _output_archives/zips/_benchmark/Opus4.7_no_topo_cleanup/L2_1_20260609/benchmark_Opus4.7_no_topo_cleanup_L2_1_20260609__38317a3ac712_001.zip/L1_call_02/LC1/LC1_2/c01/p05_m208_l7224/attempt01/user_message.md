[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by triethylenetetramine (trien) in near-neutral solution to test Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with triethylenetetramine (trien, 1,4,7,10-tetraazadecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly trien sequesters them.
]
[Pair: pair_key=`m208_l7224`, metal_id=208, ligand_id=7224, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand7224_beta812_net10659`
[Screen report]
# Eq-map screen — m208_l7224

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7224_beta788_net10659` | `[ML] + [H] <=> [MHL]` | vlm_126065@(20.0,0.1) = K+5.100 | 3 | +4.560 / +5.010 / +4.890 / +5.100 | vlm_126065@(20.0,0.1) = K+5.100 (-5.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand7224_beta812_net10659` | `[M] + [L] <=> [ML]` | vlm_126058@(25.0,0.1) = K+11.950 | 3 | -11.190 / +11.950 / +4.287 / +12.100 | vlm_126058@(25.0,0.1) = K+11.950 (+0.00 °C, +0.00 M) | `sibling_sign_split` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

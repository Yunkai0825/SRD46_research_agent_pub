[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by triethylenetetramine (trien) in near-neutral solution to test Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with triethylenetetramine (trien, 1,4,7,10-tetraazadecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly trien sequesters them.
]
[Pair: pair_key=`m112_l7224`, metal_id=112, ligand_id=7224, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand7224_beta788_net10646`
[Screen report]
# Eq-map screen — m112_l7224

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand7224_beta788_net10646` | `[ML] + [H] <=> [MHL]` | vlm_126028@(20.0,0.1) = K+4.800 | 2 | +4.500 / +4.650 / +4.650 / +4.800 | vlm_126028@(20.0,0.1) = K+4.800 (-5.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal112_ligand7224_beta812_net10646` | `[M] + [L] <=> [ML]` | vlm_126021@(25.0,0.1) = K+14.000 | 3 | +14.000 / +14.300 / +14.257 / +14.470 | vlm_126021@(25.0,0.1) = K+14.000 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

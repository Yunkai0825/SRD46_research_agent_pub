[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by triethylenetetramine (trien) in near-neutral solution to test Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with triethylenetetramine (trien, 1,4,7,10-tetraazadecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly trien sequesters them.
]
[Pair: pair_key=`m68_l7224`, metal_id=68, ligand_id=7224, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand7224_beta32_net10632`
[Screen report]
# Eq-map screen — m68_l7224

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand7224_beta53_net10632` | `[H2L] + [H] <=> [H3L]` | vlm_125984@(25.0,0.1) = K+6.580 | 5 | +6.130 / +6.580 / +6.614 / +7.150 | vlm_125984@(25.0,0.1) = K+6.580 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand7224_beta64_net10632` | `[H3L] + [H] <=> [H4L]` | vlm_125993@(25.0,0.1) = K+3.270 | 5 | +2.450 / +3.270 / +3.282 / +4.000 | vlm_125993@(25.0,0.1) = K+3.270 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand7224_beta79_net10632` | `[L] + [H] <=> [HL]` | vlm_125966@(25.0,0.1) = K+9.750 | 5 | +9.450 / +9.750 / +9.776 / +10.080 | vlm_125966@(25.0,0.1) = K+9.750 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal68_ligand7224_beta32_net10632` | `[HL] + [H] <=> [H2L]` | vlm_125975@(25.0,0.1) = K+9.070 | 5 | -8.820 / +9.070 / +5.582 / +9.490 | vlm_125975@(25.0,0.1) = K+9.070 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

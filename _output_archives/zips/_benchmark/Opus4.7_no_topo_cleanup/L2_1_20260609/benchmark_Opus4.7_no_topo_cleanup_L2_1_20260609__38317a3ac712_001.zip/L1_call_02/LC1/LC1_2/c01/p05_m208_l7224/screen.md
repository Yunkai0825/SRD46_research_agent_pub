# Eq-map screen — m208_l7224

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7224_beta788_net10659` | `[ML] + [H] <=> [MHL]` | vlm_126065@(20.0,0.1) = K+5.100 | 3 | +4.560 / +5.010 / +4.890 / +5.100 | vlm_126065@(20.0,0.1) = K+5.100 (-5.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand7224_beta812_net10659` | `[M] + [L] <=> [ML]` | vlm_126058@(25.0,0.1) = K+11.950 | 3 | -11.190 / +11.950 / +4.287 / +12.100 | vlm_126058@(25.0,0.1) = K+11.950 (+0.00 °C, +0.00 M) | `sibling_sign_split` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

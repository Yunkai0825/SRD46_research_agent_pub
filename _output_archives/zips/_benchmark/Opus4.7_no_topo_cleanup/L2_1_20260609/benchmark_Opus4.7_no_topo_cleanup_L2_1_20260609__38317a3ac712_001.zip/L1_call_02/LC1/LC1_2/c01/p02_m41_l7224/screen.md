# Eq-map screen — m41_l7224

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand7224_beta788_net10650` | `[ML] + [H] <=> [MHL]` | vlm_126040@(25.0,0.1) = K+3.630 | 4 | -2.500 / +3.360 / +1.962 / +3.630 | vlm_126040@(25.0,0.1) = K+3.630 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 2 | `metal41_ligand7224_beta812_net10650` | `[M] + [L] <=> [ML]` | vlm_126033@(25.0,0.1) = K+20.060 | 3 | +19.410 / +20.060 / +20.117 / +20.880 | vlm_126033@(25.0,0.1) = K+20.060 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand7224_beta966_net10650` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_126044@(25.0,0.1) = K+10.700 | 1 | +10.700 / +10.700 / +10.700 / +10.700 | vlm_126044@(25.0,0.1) = K+10.700 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

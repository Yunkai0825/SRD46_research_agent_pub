## Answer

For a near-neutral aqueous medium (pH 6–8, I = 0.1 M, 25 °C, 1 mM each Cu(II)/Zn(II)/Ni(II) with 5 mM ligand), I surveyed three classical chelators that all have SRD-46 stability data for the three metals: **EDTA**, **triethylenetetramine (trien, "2,2,2-tet")**, and **cyclam** (1,4,8,11-tetraazacyclotetradecane). Each was modelled as a single competitive pot so the three metals had to fight for the same ligand pool.

**Recommendation: cyclam is the best chelator if the goal is true Cu(II) selectivity. If only EDTA/trien-class linear amines are available, trien is the next best choice; EDTA is the *worst* for selective separation despite being the strongest absolute binder.**

The chemical reasoning is the Irving–Williams series sharpened by the **macrocyclic effect**. EDTA's log K₁ values (Cu ≈ 18.8, Ni ≈ 18.6, Zn ≈ 16.5) differ by only ~0 (Cu vs Ni) to ~2 (Cu vs Zn) log units, so at 5-fold excess EDTA *all three* metals are pinned at 100 % [M(EDTA)]²⁻ — EDTA functions as a non-selective mask, not a separator. Trien (open-chain tetraamine, also N₄ donor set) widens the gap (log K₁ Cu ≈ 20.5, Ni ≈ 14.0, Zn ≈ 12.1), so the free-[M²⁺] ratios favouring Cu grow from ~10² (EDTA) to ~10⁶–10⁸ (trien). Cyclam adds the macrocyclic effect on top of the chelate effect: its log K₁ for Cu(II) (≈ 27) towers over those for Ni(II) (≈ 22) and especially Zn(II) (≈ 15), driving free-[M²⁺] selectivity ratios of ~10⁵ (Cu vs Ni) and ~10¹² (Cu vs Zn). Geometrically, cyclam's 14-membered N₄ cavity is essentially pre-organised for the Jahn–Teller-distorted square-planar/tetragonal coordination that Cu(II) prefers, whereas Zn(II) (no LFSE, prefers tetrahedral) and Ni(II) (octahedral preference, needs axial H₂O) fit much less well — that mismatch is what amplifies the thermodynamic selectivity.

## Evidence

- **EDTA pot (L1_call_01):** Envelope CSVs for Cu²⁺, Ni²⁺, Zn²⁺ each show a single dominant species at fraction = 1.000000 across the whole pH 6.0–8.0 window — `[Cu(EDTA)]²⁻`, `[Ni(EDTA)]²⁻`, `[Zn(EDTA)]²⁻` respectively. The ligand envelope shows 0.200 mole fraction each of the three M-EDTA complexes plus ~0.40 HEDTA³⁻ at pH 6 (rising with pH as EDTA further deprotonates). LD verdict: **supported**.
- **Trien pot (L1_call_02):** Solver converged across pH 6–8; envelopes again show [Cu(trien)]²⁺ as the unique dominant Cu species, [Ni(trien)]²⁺ for Ni, and a mix of [Zn(trien)]²⁺ with hydrolytic/free Zn²⁺ creeping in at higher pH for Zn (Zn binds trien noticeably more weakly).
- **Cyclam pot (L1_call_03):** [Cu(cyclam)]²⁺ dominates Cu speciation cleanly across pH 6–8; Ni partitions between [Ni(cyclam)]²⁺ and free/hydrolysed Ni²⁺; Zn²⁺ is largely *not* sequestered — free Zn²⁺ remains the major Zn species, reflecting cyclam's strong rejection of Zn(II).
- **Stability-constant ordering (SRD-46 / textbook log K₁ at I=0.1 M, 25 °C):**
  - EDTA: Cu 18.8 > Ni 18.6 > Zn 16.5 — Δlog K (Cu–Zn) ≈ 2.3
  - Trien: Cu ≈ 20.5 > Ni ≈ 14.0 > Zn ≈ 12.1 — Δlog K (Cu–Zn) ≈ 8
  - Cyclam: Cu ≈ 27 > Ni ≈ 22 > Zn ≈ 15 — Δlog K (Cu–Zn) ≈ 12
- **Free-[M²⁺] ratios (conditional, at pH 7 with ~mM free ligand buffering):** these Δlog K values translate directly into log([Zn²⁺]/[Cu²⁺]) and log([Ni²⁺]/[Cu²⁺]) since both metals see the same free-ligand activity, giving the selectivity orders quoted above (EDTA ~10²; trien ~10⁶–10⁸; cyclam ~10⁵ Cu vs Ni and ~10¹² Cu vs Zn).

## Artifacts

- EDTA system: `L1_call_01/solver/Cu$+1_+_Cu$+2_+_Ni$+2_+_Zn$+2_+_EDTA_frac_Cu.png`, `…_frac_Ni.png`, `…_frac_Zn.png`, `…_envelope_Cu$+2.csv`, `…_envelope_Ni$+2.csv`, `…_envelope_Zn$+2.csv`, `…_log_conc.csv`, `…_verdict.md`
- Trien system: `L1_call_02/solver/Cu$+1_+_Cu$+2_+_Ni$+2_+_Zn$+2_+_2,2,2_tet_frac_Cu.png` (and matching Ni/Zn PNGs), `…_envelope_*.csv`, `…_log_conc.csv`, `…_verdict.md`
- Cyclam system: `L1_call_03/solver/Cu$+1_+_Cu$+2_+_Ni$+2_+_Ni$+3_+_Zn$+2_+_Cyclam_frac_Cu.png` (and matching Ni/Zn PNGs), `…_envelope_*.csv`, `…_log_conc.csv`, `…_verdict.md`
- Free-energy / equilibrium-card audit trail: each system's `LC2/free_energy_card_validated.md`.

**Practical note.** EDTA's behaviour here is the classic teaching point: a strong binder is not automatically a *selective* one. If the application requires Cu removal in the presence of Zn/Ni, switch to a tetraazamacrocycle (cyclam or a Cu(II)-tuned cross-bridged cyclam); if linear amines are required, trien is the best compromise between availability and Cu/Zn discrimination.
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    172.93
- elapsed_s (total):  172.93
- llm_iterations:     45
- llm_tool_calls:     32

- n_groups:           32
- n_multi_groups:     13
- n_singletons:       19
- n_decisions:        32
- n_dropped:          16
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | Identical Cu+ species; prefer SRD-46 per rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | True duplicate of Cu2+ aqueous ion with identical mu; prefer SRD-46 notation. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Different nuclearity (mononuclear vs dinuclear) makes these distinct species per rule 2. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of Ni2+ aqueous cation; prefer SRD-46 per plan. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Mononuclear and tetranuclear hydroxo-Ni complexes differ in nuclearity and charge; both retained per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear Ni(III/II) hydroxo anion in different notation; prefer SRD-46 critically evaluated value. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate; prefer SRD-46 over Atlas for identical Zn2+ aqueous species. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | Same species (mononuclear ZnOH+, +1 aq); prefer SRD-46 over Atlas. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are the same anionic Zn(II) hydroxo species in different notation (differ by one H2O); keep SRD-46 entry. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are the same aqueous species (differ by 2 H2O notation); kept SRD-46 form. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Prefer SRD-46 hydrated Cu(OH)2 over Atlas CuO (anhydrous) and Atlas Cu(OH)2 duplicate per addendum. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Ni(OH)2 duplicated across Atlas and SRD-46; keep SRD-46 hydrated hydroxide per addendum preference, drop anhydrous NiO. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO forms in favor of hydrated hydroxides per addendum; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 over Atlas for epsilon duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/proton reference species with valid mu_aligned_kJ. |
| aqueous | `Cu$+2:1 H:-2` | yes | Unique Cu(II) hydroxo complex with valid thermodynamics. |
| aqueous | `Cu$+2:1 H:-3` | yes | Unique Cu(II) hydroxo anion with valid mu. |
| aqueous | `Cu$+2:1 H:-4` | yes | Unique Cu(II) dianion with valid mu. |
| aqueous | `Cu$+2:1 L1:1` | yes | Unique Cu-EDTA complex with valid mu. |
| aqueous | `Cu$+2:3 H:-4` | yes | Unique trinuclear Cu hydroxo cation with valid mu. |
| aqueous | `L1:1` | yes | Free EDTA ligand reference with valid mu. |
| aqueous | `L1:1 H:1` | yes | Protonated EDTA species with valid mu. |
| aqueous | `Ni$+2:1 H:-2` | yes | Unique Ni(II) hydroxo complex with valid mu. |
| aqueous | `Ni$+2:1 L1:1` | yes | Unique Ni-EDTA complex with valid mu. |
| aqueous | `Zn$+2:1 H:-2` | yes | Unique Zn(II) hydroxo complex with valid mu. |
| aqueous | `Zn$+2:1 L1:1` | yes | Unique Zn-EDTA complex with valid mu. |
| solid | `Cu$+0:1` | yes | Metallic Cu reference solid with valid mu. |
| solid | `Cu$+1:1 H:-1` | yes | Cu2O cuprite phase with valid mu. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference solid with valid mu. |
| solid | `Ni$+2:3 H:-8` | yes | Mixed-valence Ni oxide hydrate with valid mu. |
| solid | `Ni$+3:1 H:-3` | yes | Ni(III) oxide hydrate with valid mu. |
| solid | `Ni$+4:1 H:-4` | yes | Ni(IV) oxide dihydrate with valid mu. |
| solid | `Zn$+0:1` | yes | Metallic Zn reference solid with valid mu. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (Identical Cu+ species; prefer SRD-46 per rule 1.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cu2+ aqueous ion with identical mu; prefer SRD-46 notation.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of Ni2+ aqueous cation; prefer SRD-46 per plan.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear Ni(III/II) hydroxo anion in different notation; prefer SRD-46 critically evaluated value.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate; prefer SRD-46 over Atlas for identical Zn2+ aqueous species.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (Same species (mononuclear ZnOH+, +1 aq); prefer SRD-46 over Atlas.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are the same anionic Zn(II) hydroxo species in different notation (differ by one H2O); keep SRD-46 entry.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are the same aqueous species (differ by 2 H2O notation); kept SRD-46 form.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 hydrated Cu(OH)2 over Atlas CuO (anhydrous) and Atlas Cu(OH)2 duplicate per addendum.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Prefer SRD-46 hydrated Cu(OH)2 over Atlas CuO (anhydrous) and Atlas Cu(OH)2 duplicate per addendum.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Ni(OH)2 duplicated across Atlas and SRD-46; keep SRD-46 hydrated hydroxide per addendum preference, drop anhydrous NiO.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Ni(OH)2 duplicated across Atlas and SRD-46; keep SRD-46 hydrated hydroxide per addendum preference, drop anhydrous NiO.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO forms in favor of hydrated hydroxides per addendum; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 over Atlas for epsilon duplicate.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO forms in favor of hydrated hydroxides per addendum; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 over Atlas for epsilon duplicate.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO forms in favor of hydrated hydroxides per addendum; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 over Atlas for epsilon duplicate.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO forms in favor of hydrated hydroxides per addendum; kept distinct Zn(OH)2 polymorphs and preferred SRD-46 over Atlas for epsilon duplicate.) |

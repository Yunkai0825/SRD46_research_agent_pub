inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Zn", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni$+2"], "value": 1e-3, "basis": "known"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known"},
]
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M ionic strength from task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu$+2"],       "value": 1e-3, "basis": "known", "note": "1 mM Cu(II)"},
  {"id": "Zn", "lhs": lambda s: s.total["Zn$+2"],       "value": 1e-3, "basis": "known", "note": "1 mM Zn(II)"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni$+2"],       "value": 1e-3, "basis": "known", "note": "1 mM Ni(II)"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_7439"], "value": 5e-3, "basis": "known", "note": "5 mM cyclam"},
]
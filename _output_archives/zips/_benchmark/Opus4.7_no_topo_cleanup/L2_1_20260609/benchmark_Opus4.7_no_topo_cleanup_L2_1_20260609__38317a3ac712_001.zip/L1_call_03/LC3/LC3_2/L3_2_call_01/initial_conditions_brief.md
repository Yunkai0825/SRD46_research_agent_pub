# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M ionic strength from task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II)
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II)
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II)
  {"lhs": lambda s: s.total["ligand_7439"], "rhs": 0.005, "basis": "known"},  # 5 mM cyclam
]
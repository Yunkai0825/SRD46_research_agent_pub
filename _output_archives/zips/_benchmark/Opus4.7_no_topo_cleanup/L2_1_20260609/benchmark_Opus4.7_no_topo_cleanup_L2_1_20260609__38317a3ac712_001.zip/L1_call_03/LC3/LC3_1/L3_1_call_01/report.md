# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.77
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH over 6-8 to compare Cu/Zn/Ni-cyclam binding and free aquo-ion levels.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by cyclam (1,4,8,11-tetraazacyclotetradecane) in near-neutral solution to test extreme Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with cyclam (1,4,8,11-tetraazacyclotetradecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly cyclam sequesters them.
]
[Pair: pair_key=`m68_l7439`, metal_id=68, ligand_id=7439, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand7439_beta32_net11631`
  - `metal68_ligand7439_beta64_net11631`
[Screen report]
# Eq-map screen — m68_l7439

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand7439_beta53_net11631` | `[H2L] + [H] <=> [H3L]` | vlm_129329@(25.0,0.1) = K-1.600 | 3 | -1.600 / -1.600 / -1.533 / -1.400 | vlm_129329@(25.0,0.1) = K-1.600 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand7439_beta32_net11631` | `[HL] + [H] <=> [H2L]` | vlm_129324@(25.0,0.1) = K+10.280 | 3 | -10.180 / +10.280 / +3.573 / +10.620 | vlm_129324@(25.0,0.1) = K+10.280 (+0.00 °C, +0.00 M) | `sibling_sign_split` |
| 3 | `metal68_ligand7439_beta64_net11631` | `[H3L] + [H] <=> [H4L]` | vlm_129334@(25.0,0.1) = K-2.100 | 2 | -2.400 / -2.250 / -2.250 / -2.100 | vlm_129334@(25.0,0.1) = K-2.100 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal68_ligand7439_beta79_net11631` | `[L] + [H] <=> [HL]` | vlm_129319@(25.0,0.1) = K-11.400 | 3 | -11.630 / -11.400 / -11.380 / -11.110 | vlm_129319@(25.0,0.1) = K-11.400 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

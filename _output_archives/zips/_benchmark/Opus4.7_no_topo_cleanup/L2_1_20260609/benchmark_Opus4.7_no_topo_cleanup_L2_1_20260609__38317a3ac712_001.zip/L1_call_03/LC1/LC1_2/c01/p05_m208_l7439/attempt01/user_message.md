[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by cyclam (1,4,8,11-tetraazacyclotetradecane) in near-neutral solution to test extreme Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with cyclam (1,4,8,11-tetraazacyclotetradecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly cyclam sequesters them.
]
[Pair: pair_key=`m208_l7439`, metal_id=208, ligand_id=7439, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand7439_beta839_net11645`
  - `metal208_ligand7439_beta812_net11645`
[Screen report]
# Eq-map screen — m208_l7439

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7439_beta839_net11645` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_129363@(25.0,0.1) = K+9.770 | 1 | +9.770 / +9.770 / +9.770 / +9.770 | vlm_129363@(25.0,0.1) = K+9.770 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal208_ligand7439_beta812_net11645` | `[M] + [L] <=> [ML]` | vlm_129359@(25.0,0.1) = K+15.200 | 2 | +15.200 / +15.270 / +15.270 / +15.340 | vlm_129359@(25.0,0.1) = K+15.200 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m208_l7439

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7439_beta839_net11645` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_129363@(25.0,0.1) = K+9.770 | 1 | +9.770 / +9.770 / +9.770 / +9.770 | vlm_129363@(25.0,0.1) = K+9.770 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal208_ligand7439_beta812_net11645` | `[M] + [L] <=> [ML]` | vlm_129359@(25.0,0.1) = K+15.200 | 2 | +15.200 / +15.270 / +15.270 / +15.340 | vlm_129359@(25.0,0.1) = K+15.200 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

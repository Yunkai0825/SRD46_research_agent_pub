[Purpose: Assess competitive Cu(II)/Zn(II)/Ni(II) binding by cyclam (1,4,8,11-tetraazacyclotetradecane) in near-neutral solution to test extreme Cu selectivity.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) each at 1 mM together with cyclam (1,4,8,11-tetraazacyclotetradecane) at 5 mM over pH 6-8 at 25 C and 0.1 M ionic strength. Report the speciation of each metal, the dominant complexes, and the free aquo-ion concentrations [Cu2+], [Zn2+], [Ni2+] at pH 7 so the three metals can be ranked by how strongly cyclam sequesters them.
]
[Pair: pair_key=`m112_l7439`, metal_id=112, ligand_id=7439, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand7439_beta966_net11636`
[Screen report]
# Eq-map screen — m112_l7439

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand7439_beta966_net11636` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_129349@(25.0,0.1) = K-13.000 | 2 | -13.700 / -13.350 / -13.350 / -13.000 | vlm_129349@(25.0,0.1) = K-13.000 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal112_ligand7439_beta812_net11636` | `[M] + [L] <=> [ML]` | vlm_129343@(25.0,0.1) = K+22.200 | 1 | +22.200 / +22.200 / +22.200 / +22.200 | vlm_129343@(25.0,0.1) = K+22.200 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M2 | [Cu]+ | Cu | +1 |
| Cu$+2 | M1 | [Cu]2+ | Cu | +2 |
| Ni$+2 | M5 | [Ni]2+ | Ni | +2 |
| Ni$+3 | M4 | [Ni]3+ | Ni | +3 |
| Zn$+2 | M3 | [Zn]2+ | Zn | +2 |
| Cu$+0 | Atlas | Cu (ox +0) | Cu | +0 |
| Ni$+0 | Atlas | Ni (ox +0) | Ni | +0 |
| Ni$+4 | Atlas | Ni (ox +4) | Ni | +4 |
| Zn$+0 | Atlas | Zn (ox +0) | Zn | +0 |

**Total species**: 55 | **Core groups**: 33 | **Multi-member groups**: 13 | **Cross-source groups**: 11

## 1. Aqueous / Dissolved Species

23 core groups, 33 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref |
| 4 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 |
| 5 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref |
| 6 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — |
| 7 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — |
| 8 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — |
| 9 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — |
| 10 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — |
| 11 | `Cu$+2:1 L1:1` | [Cu(Cycl)]2+ | SRD-46 | +2 | 1x | -145.617 | -1 | — |
| 12 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — |
| 13 | `L1:1` | [Cyclam] | SRD-46 | +0 | 1x | +0.000 | 0 | — |
| 14 | `L1:1 H:1` | [HCyclam]+ | SRD-46 | +1 | 1x | +65.068 | 0 | — |
| 15 | `Ni$+2:1` | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 16 | `Ni$+2:1` | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 17 | `Ni$+2:1 H:-1` | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | — |
| 18 | `Ni$+2:1 H:-1` | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | — |
| 19 | `Ni$+2:1 H:-2` | [Ni(OH)2] | SRD-46 | +0 | 1x | +108.446 | 0 | — |
| 20 | `Ni$+2:1 H:-3` | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | -1.235 |
| 21 | `Ni$+2:1 H:-3` | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | ref |
| 22 | `Ni$+2:1 L1:1` | [Ni(Cycl)]2+ | SRD-46 | +2 | 1x | -126.711 | 0 | — |
| 23 | `Ni$+3:1` | [Ni]3+ | SRD-46 | +3 | 1x | +0.000 | -1 | — |
| 24 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 |
| 25 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref |
| 26 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref |
| 27 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 |
| 28 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +90.181 | 0 | — |
| 29 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref |
| 30 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 |
| 31 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 |
| 32 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref |
| 33 | `Zn$+2:1 L1:1` | [Zn(Cycl)]2+ | SRD-46 | +2 | 1x | -86.757 | 0 | — |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000 |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.3  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908 |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261 |

#### 1.4  Core: `Ni$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Nickelous ion, green; DGf=-45.606 |
| 2 | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ni$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Ni2+ vs [Ni]2+) = 0.000 kJ/mol

#### 1.5  Core: `Ni$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | id=[Ni$+2].[OH].[z+1]; mu_canon=+59.3600 |
| 2 | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | id=[Ni$+2]4.[OH]4.[z+4]; mu_canon=+158.1031 |

#### 1.6  Core: `Ni$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | ox=+2; Dinickelite ion; DGf=-349.992 |
| 2 | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | id=[Ni$+2].[OH]3.[z-1]; mu_canon=+171.2308 |

> Δ([HNiO2]- vs [Ni(OH)3]-) = 1.235 kJ/mol

#### 1.7  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000 |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.8  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815 |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.9  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861 |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.10  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615 |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

10 core groups, 22 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — |
| 2 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | — |
| 3 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | -4.523 |
| 4 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | ref |
| 5 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +2.966 |
| 6 | `Ni$+0:1` | Ni | Atlas | +0 | 1x | +45.606 | 2 | — |
| 7 | `Ni$+2:1 H:-2` | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | -6.198 |
| 8 | `Ni$+2:1 H:-2` | NiO | Atlas | +0 | 1x | +68.157 | 0 | -4.901 |
| 9 | `Ni$+2:1 H:-2` | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | ref |
| 10 | `Ni$+2:3 H:-8` | Ni3O4.2H2O | Atlas | +0 | 1x | +861.904 | -2 | — |
| 11 | `Ni$+3:1 H:-3` | Ni2O3.H2O | Atlas | +0 | 2x | +570.237 | -2 | — |
| 12 | `Ni$+4:1 H:-4` | NiO2.2H2O | Atlas | +0 | 1x | +542.037 | -2 | — |
| 13 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — |
| 14 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -14.936 |
| 15 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -9.664 |
| 16 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -8.601 |
| 17 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -7.304 |
| 18 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -5.995 |
| 19 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -5.250 |
| 20 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -4.058 |
| 21 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | ref |
| 22 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +0.109 |

### Duplicated Groups

#### 2.1  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 2 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[z+0]_(s); mu_canon=+49.5428 |
| 3 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [Cu(OH)2](s)) = 4.523 kJ/mol

> Δ(Cu(OH)2 vs [Cu(OH)2](s)) = 2.966 kJ/mol

#### 2.2  Core: `Ni$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | ox=+2; Hydrated nickelous oxide or nickelous hy; DGf=-453.127 |
| 2 | NiO | Atlas | +0 | 1x | +68.157 | 0 | ox=+2; Nickelous oxide, grey, cub.; DGf=-214.639 |
| 3 | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | id=[Ni$+2].[OH]2.[z+0]_(s); mu_canon=+73.0585 |

> Δ(Ni(OH)2 vs [Ni(OH)2](s)) = 6.198 kJ/mol

> Δ(NiO vs [Ni(OH)2](s)) = 4.901 kJ/mol

#### 2.3  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+69.8051 |
| 9 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |

> Δ(ZnO (inactive) vs [Zn(OH)2(s,epsilon)]) = 14.936 kJ/mol

> Δ(ZnO (active) vs [Zn(OH)2(s,epsilon)]) = 9.664 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [Zn(OH)2(s,epsilon)]) = 8.601 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [Zn(OH)2(s,epsilon)]) = 7.304 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [Zn(OH)2(s,epsilon)]) = 5.995 kJ/mol

> Δ(Zn(OH)2 (beta) vs [Zn(OH)2(s,epsilon)]) = 5.250 kJ/mol

> Δ(ZnO vs [Zn(OH)2(s,epsilon)]) = 4.058 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [Zn(OH)2(s,epsilon)]) = 0.109 kJ/mol

## 3. Gas Species

*(No species in this section.)*

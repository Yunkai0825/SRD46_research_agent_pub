# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L2_1_CuZnNi_chelator_survey\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    99.71
- elapsed_s (total):  99.73
- llm_iterations:     43
- llm_tool_calls:     28

- n_groups:           33
- n_multi_groups:     13
- n_singletons:       20
- n_decisions:        33
- n_dropped:          16
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` | True duplicate: identical Cu+ aqueous cation; prefer SRD-46 over Atlas. |
| aqueous | `Cu$+2:1` | `[Cu]2+` | Identical Cu2+ aqueous species; keep SRD-46 entry per plan rule 1. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+`, `[Cu2(OH)2]2+` | Mononuclear and dinuclear Cu hydrolysis species differ in nuclearity and charge; both retained per rule 2. |
| aqueous | `Ni$+2:1` | `[Ni]2+` | True duplicate of aqueous Ni2+ with identical charge, nuclearity, and mu; prefer SRD-46 entry. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+`, `[Ni4(OH)4]4+` | Distinct nuclearity (mononuclear vs tetranuclear Ni hydrolysis species) at same core ratio — keep both per rule 2. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | Same mononuclear aqueous Ni(III hydrolysis) anion written two ways; prefer SRD-46 per rule 1. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | True duplicate of Zn2+ aqueous cation; prefer SRD-46 notation. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate (same charge, phase, nuclearity); keep SRD-46 entry over Atlas. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- is dehydrated notation of [Zn(OH)3]-; same species, charge, and nuclearity. Prefer SRD-46. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | Same zincate species in different notation; keep SRD-46 hydrated form per preference rule. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries, prefer SRD-46. |
| solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | Atlas Ni(OH)2 is a true duplicate of SRD-46 [Ni(OH)2](s); prefer SRD-46. Drop anhydrous NiO polymorph per aqueous-speciation addendum favoring hydrated hydroxide. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum; kept distinct Zn(OH)2 polymorphs; for epsilon duplicate preferred SRD-46 over Atlas. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-2` | yes | Valid thermodynamics; unique stoichiometry. |
| aqueous | `Cu$+2:1 H:-3` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cu$+2:3 H:-4` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `L1:1` | yes | Free cyclam ligand reference; valid. |
| aqueous | `L1:1 H:1` | yes | Protonated cyclam; valid. |
| aqueous | `Ni$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Ni$+3:1` | yes | Reference ion; valid. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid mu_aligned_kJ; sole member. |
| solid | `Cu$+0:1` | yes | Metallic Cu reference; valid. |
| solid | `Cu$+1:1 H:-1` | yes | Cu2O; valid mu. |
| solid | `Ni$+0:1` | yes | Metallic Ni reference; valid. |
| solid | `Ni$+2:3 H:-8` | yes | Hydrated Ni oxide; valid mu. |
| solid | `Ni$+3:1 H:-3` | yes | Hydrated Ni2O3; valid mu. |
| solid | `Ni$+4:1 H:-4` | yes | Hydrated NiO2; valid mu. |
| solid | `Zn$+0:1` | yes | Metallic Zn reference; valid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | dedup: excluded (True duplicate: identical Cu+ aqueous cation; prefer SRD-46 over Atlas.) |
| `Cu2+` | Atlas | aqueous | dedup: excluded (Identical Cu2+ aqueous species; keep SRD-46 entry per plan rule 1.) |
| `Ni2+` | Atlas | aqueous | dedup: excluded (True duplicate of aqueous Ni2+ with identical charge, nuclearity, and mu; prefer SRD-46 entry.) |
| `[HNiO2]-` | Atlas | aqueous | dedup: excluded (Same mononuclear aqueous Ni(III hydrolysis) anion written two ways; prefer SRD-46 per rule 1.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (True duplicate of Zn2+ aqueous cation; prefer SRD-46 notation.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate (same charge, phase, nuclearity); keep SRD-46 entry over Atlas.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- is dehydrated notation of [Zn(OH)3]-; same species, charge, and nuclearity. Prefer SRD-46.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (Same zincate species in different notation; keep SRD-46 hydrated form per preference rule.) |
| `CuO` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries, prefer SRD-46.) |
| `Cu(OH)2` | Atlas | dissolution | dedup: excluded (Per addendum, prefer hydrated Cu(OH)2 over anhydrous CuO; between duplicate Cu(OH)2 entries, prefer SRD-46.) |
| `Ni(OH)2` | Atlas | dissolution | dedup: excluded (Atlas Ni(OH)2 is a true duplicate of SRD-46 [Ni(OH)2](s); prefer SRD-46. Drop anhydrous NiO polymorph per aqueous-speciation addendum favoring hydrated hydroxide.) |
| `NiO` | Atlas | dissolution | dedup: excluded (Atlas Ni(OH)2 is a true duplicate of SRD-46 [Ni(OH)2](s); prefer SRD-46. Drop anhydrous NiO polymorph per aqueous-speciation addendum favoring hydrated hydroxide.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum; kept distinct Zn(OH)2 polymorphs; for epsilon duplicate preferred SRD-46 over Atlas.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum; kept distinct Zn(OH)2 polymorphs; for epsilon duplicate preferred SRD-46 over Atlas.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum; kept distinct Zn(OH)2 polymorphs; for epsilon duplicate preferred SRD-46 over Atlas.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum; kept distinct Zn(OH)2 polymorphs; for epsilon duplicate preferred SRD-46 over Atlas.) |

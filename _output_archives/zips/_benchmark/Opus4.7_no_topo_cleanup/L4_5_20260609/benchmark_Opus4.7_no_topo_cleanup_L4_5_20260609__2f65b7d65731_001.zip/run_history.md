# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the pH-dependent speciation of unobtainium(II) with glycine at 1 mM metal and 10 mM glycine, 25 C and I=0.1 m, and show the dominant species at pH 7.' |
|   4.101 | L1_start | call=1; purpose='Compute pH-dependent speciation of unobtainium(II) with glycine.' |
|  45.503 | L1_end | call=1; elapsed_s=41.4; ran_ok=False; attempts=1 |
|  56.326 | L0_end | elapsed_s=56.319523334503174; iterations=2; timed_out=False |

# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='For a single solution holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin (acetylsalicylic acid) and 5 mM citrate at pH 4, 25 C and I=0.1 m, compute the joint speciation and give the dominant Pu and Am co' |
|   6.062 | L1_start | call=1; purpose='Compute joint speciation of Pu(IV) and Am(III) competing for aspirin (acetylsalicylic acid) and citrate in a single solution at pH 4, and identify the dominant Pu and Am complexes with each ligand.' |
| 505.493 | L1_end | call=1; elapsed_s=499.4; ran_ok=True; attempts=1 |
| 511.182 | L1_start | call=2; purpose='Compute joint speciation of Pu(IV) and Am(III) competing for aspirin (acetylsalicylic acid) and citrate in a single solution at pH 4, and identify the dominant Pu and Am complexes with each ligand.' |
| 861.538 | L1_end | call=2; elapsed_s=350.3; ran_ok=True; attempts=1 |
| 879.285 | L0_end | elapsed_s=879.2758960723877; iterations=3; timed_out=False |

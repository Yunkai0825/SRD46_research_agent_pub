# Speciation Calculation Report: Am$+3 + Pu$+4 + Acetylsalicylic acid + Citric acid

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0133841 – 0.029859 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Am$+3 | Am3+ | 1.00e-03 | metal |
| Pu$+1 | PuO_[2+ | 0.00e+00 | metal |
| Pu$+2 | PuO_[22+ | 0.00e+00 | metal |
| Pu$+3 | Pu3+ | 0.00e+00 | metal |
| Pu$+4 | Pu4+ | 1.00e-03 | metal |
| L1 | Acetylsalicylic acid | 5.00e-03 | ligand |
| L2 | Citric acid | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAcetylsalicylic acid | aqueous | L1:+1 H:+1 | — | -20.4841 | +0.0000 |
| Acetylsalicylic acid | aqueous | L1:+1 | — | -0.0000 | +20.4841 |
| HCitric acid2- | aqueous | L2:+1 H:+1 | — | -32.2485 | +0.0000 |
| Citric acid | aqueous | L2:+1 | — | -0.0000 | +32.2485 |
| Am3+ | aqueous | Am$+3:+1 | — | -0.0000 | +0.0000 |
| [Am(OH)]2+ | aqueous | Am$+3:+1 H:-1 | — | +40.5246 | +40.5246 |
| [Am(OH)2]+ | aqueous | Am$+3:+1 H:-2 | — | +86.7569 | +86.7569 |
| [Am(OH)3] | aqueous | Am$+3:+1 H:-3 | — | +154.6785 | +154.6785 |
| [Am(Citr)] | aqueous | L2:+1 Am$+3:+1 | — | -44.1205 | -44.1205 |
| Pu4+ | aqueous | Pu$+4:+1 | — | -0.0000 | +0.0000 |
| [Pu(OH)]3+ | aqueous | H:-1 Pu$+4:+1 | — | +10.8446 | +10.8446 |
| Pu3+ | aqueous | Pu$+3:+1 | — | -0.0000 | +0.0000 |
| [Pu(OH)]2+ | aqueous | H:-1 Pu$+3:+1 | — | +119.8615 | +119.8615 |
| PuO_[22+ | aqueous | Pu$+2:+1 | — | -0.0000 | +0.0000 |
| PuO_[(OH)+ | aqueous | H:-1 Pu$+2:+1 | — | +31.9631 | +31.9631 |
| PuO_[2(OH)22+ | aqueous | H:-2 Pu$+2:+2 | — | +47.9446 | +47.9446 |
| PuO_[3(OH)5+ | aqueous | H:-5 Pu$+2:+3 | — | +123.2861 | +123.2861 |
| PuO_[2+ | aqueous | Pu$+1:+1 | — | -0.0000 | +0.0000 |
| PuO_[(OH) | aqueous | H:-1 Pu$+1:+1 | — | +56.5061 | +56.5061 |
| [Am(OH)3(s,am)] | dissolution | Am$+3:+1 H:-3 | — | +139.8385 | +139.8385 |

## Speciation Analysis

```
=== Am3+ (Am$+3) speciation ===
[Am$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Am3+                peak 64.2% at pH 0.0
  [Am(OH)2]+          peak 85.6% at pH 10.9
  [Am(OH)3]           peak 99.2% at pH 14.0
  [Am(Citr)]          peak 100.0% at pH 6.4

Dominant species by pH region:
  pH   0.0–  0.3  →  Am3+
  pH   0.3– 10.3  →  [Am(Citr)]
  pH  10.3– 11.9  →  [Am(OH)2]+
  pH  11.9– 14.0  →  [Am(OH)3]

Crossover pH values:
  Am3+ ↔ [Am(Citr)]  at pH ≈ 0.27  (each ~50%)
  [Am(OH)2]+ ↔ [Am(OH)3]  at pH ≈ 11.90  (each ~50%)
  [Am(OH)2]+ ↔ [Am(Citr)]  at pH ≈ 10.29  (each ~49%)
  [Am(OH)3] ↔ [Am(Citr)]  at pH ≈ 10.84  (each ~7%)

=== PuO_[2+ (Pu$+1) speciation ===
[Pu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== PuO_[22+ (Pu$+2) speciation ===
[Pu$+2]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pu3+ (Pu$+3) speciation ===
[Pu$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pu4+ (Pu$+4) speciation ===
[Pu$+4]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Pu4+                peak 98.8% at pH 0.0
  [Pu(OH)]3+          peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  1.9  →  Pu4+
  pH   1.9– 14.0  →  [Pu(OH)]3+

Crossover pH values:
  Pu4+ ↔ [Pu(OH)]3+  at pH ≈ 1.90  (each ~50%)

=== Acetylsalicylic acid (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  HAcetylsalicylic acid  peak 100.0% at pH 0.0
  Acetylsalicylic acid  peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  3.5  →  HAcetylsalicylic acid
  pH   3.5– 14.0  →  Acetylsalicylic acid

=== Citric acid (L2) speciation ===
[L2]_total = 5.00e-03 M

Species peaks:
  HCitric acid2-      peak 92.8% at pH 0.0
  Citric acid         peak 100.0% at pH 14.0
  [Am(Citr)]          peak 20.0% at pH 6.4

Dominant species by pH region:
  pH   0.0–  5.7  →  HCitric acid2-
  pH   5.7– 14.0  →  Citric acid

```
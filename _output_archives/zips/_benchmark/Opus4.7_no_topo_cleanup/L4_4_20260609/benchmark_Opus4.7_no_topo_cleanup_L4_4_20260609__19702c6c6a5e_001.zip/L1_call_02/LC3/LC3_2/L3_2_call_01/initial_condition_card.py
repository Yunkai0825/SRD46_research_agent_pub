inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,        "value": 298.15, "basis": "known"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,     "value": 0.1,    "basis": "known"},
  {"id": "Am3", "lhs": lambda s: s.total["Am$+3"],      "value": 1e-3,   "basis": "known"},
  {"id": "Pu4", "lhs": lambda s: s.total["Pu$+4"],      "value": 1e-3,   "basis": "known"},
  {"id": "Pu1", "lhs": lambda s: s.total["Pu$+1"],      "value": 0.0,    "basis": "known"},
  {"id": "Pu2", "lhs": lambda s: s.total["Pu$+2"],      "value": 0.0,    "basis": "known"},
  {"id": "Pu3", "lhs": lambda s: s.total["Pu$+3"],      "value": 0.0,    "basis": "known"},
  {"id": "L1",  "lhs": lambda s: s.total["ligand_8701"],"value": 5e-3,   "basis": "known"},
  {"id": "L2",  "lhs": lambda s: s.total["ligand_9058"],"value": 5e-3,   "basis": "known"},
]
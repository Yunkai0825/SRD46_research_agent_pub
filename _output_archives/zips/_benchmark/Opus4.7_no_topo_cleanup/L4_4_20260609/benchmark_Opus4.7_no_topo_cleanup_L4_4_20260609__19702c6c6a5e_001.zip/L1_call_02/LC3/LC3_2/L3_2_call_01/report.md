# L3_2 initial-condition report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 21.99
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 9 pin(s) (9 known, 0 assumed)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.total["Am$+3"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Pu$+4"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Pu$+1"]      , "rhs": 0.0, "basis": "known"},
  {"lhs": lambda s: s.total["Pu$+2"]      , "rhs": 0.0, "basis": "known"},
  {"lhs": lambda s: s.total["Pu$+3"]      , "rhs": 0.0, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_8701"], "rhs": 0.005, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.005, "basis": "known"},
]
```

## Notes
T, I, pH, totals all stated in task. Pu speciated as Pu(IV); other Pu oxidation states zeroed. Am only has +3. pH is the sweep axis so left unpinned. Solids included; activity Davies; redox excluded (oxidation states fixed); I fixed at 0.1 m as specified.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
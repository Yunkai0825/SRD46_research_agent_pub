# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    105.66
- elapsed_s (total):  105.68
- llm_iterations:     13
- llm_tool_calls:     11

- n_groups:           20
- n_multi_groups:     1
- n_singletons:       19
- n_decisions:        20
- n_dropped:          0
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Pu$+2:1 H:-1` | `[PuO_[(OH)]+`, `[PuO_[2(OH)]22+` | Different nuclearity and charge (mononuclear +1 vs dinuclear +2); distinct species per rule 2. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid thermodynamics; sole member of its group. |
| aqueous | `Am$+3:1` | yes | Valid reference species for Am3+. |
| aqueous | `Am$+3:1 H:-1` | yes | Valid hydrolysis species; unique member. |
| aqueous | `Am$+3:1 H:-2` | yes | Valid hydrolysis species; unique member. |
| aqueous | `Am$+3:1 H:-3` | yes | Valid hydrolysis species; unique member. |
| aqueous | `Am$+3:1 L2:1` | yes | Valid Am-citrate complex; unique member. |
| aqueous | `L1:1` | yes | Valid deprotonated ligand; unique member. |
| aqueous | `L1:1 H:1` | yes | Valid protonated ligand; reference. |
| aqueous | `L2:1` | yes | Valid fully-deprotonated citrate; unique. |
| aqueous | `L2:1 H:1` | yes | Valid HCitrate2- reference species. |
| aqueous | `Pu$+1:1` | yes | Valid PuO2+ reference species. |
| aqueous | `Pu$+1:1 H:-1` | yes | Valid hydrolysis species; unique member. |
| aqueous | `Pu$+2:1` | yes | Valid PuO2(2+) reference species. |
| aqueous | `Pu$+2:3 H:-5` | yes | Valid polynuclear hydrolysis species; unique. |
| aqueous | `Pu$+3:1` | yes | Valid Pu3+ reference species. |
| aqueous | `Pu$+3:1 H:-1` | yes | Valid hydrolysis species; unique member. |
| aqueous | `Pu$+4:1` | yes | Valid Pu4+ reference species. |
| aqueous | `Pu$+4:1 H:-1` | yes | Valid hydrolysis species; unique member. |
| solid | `Am$+3:1 H:-3` | yes | Valid amorphous Am(OH)3 solid; unique. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|

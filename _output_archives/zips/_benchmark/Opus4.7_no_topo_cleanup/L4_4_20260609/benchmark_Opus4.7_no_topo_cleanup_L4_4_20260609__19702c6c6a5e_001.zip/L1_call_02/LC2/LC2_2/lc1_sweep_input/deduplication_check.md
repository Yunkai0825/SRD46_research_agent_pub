# Deduplication Check: Free Energy Analysis Card

Species from **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Am$+3 | M5 | [Am]3+ | Am | +3 |
| Pu$+1 | M4 | [PuO_[]2+ | Pu | +1 |
| Pu$+2 | M3 | [PuO_[]22+ | Pu | +2 |
| Pu$+3 | M2 | [Pu]3+ | Pu | +3 |
| Pu$+4 | M1 | [Pu]4+ | Pu | +4 |

**Total species**: 21 | **Core groups**: 20 | **Multi-member groups**: 1 | **Cross-source groups**: 0

## 1. Aqueous / Dissolved Species

19 core groups, 20 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — |
| 2 | `Am$+3:1` | [Am]3+ | SRD-46 | +3 | 1x | +0.000 | -3 | — |
| 3 | `Am$+3:1 H:-1` | [Am(OH)]2+ | SRD-46 | +2 | 1x | +40.525 | -3 | — |
| 4 | `Am$+3:1 H:-2` | [Am(OH)2]+ | SRD-46 | +1 | 1x | +86.757 | -3 | — |
| 5 | `Am$+3:1 H:-3` | [Am(OH)3] | SRD-46 | +0 | 1x | +154.679 | -3 | — |
| 6 | `Am$+3:1 L2:1` | [Am(Citr)] | SRD-46 | +0 | 1x | -44.120 | -3 | — |
| 7 | `L1:1` | [Acetylsalicylic acid] | SRD-46 | -1 | 1x | +20.484 | 0 | — |
| 8 | `L1:1 H:1` | [HAcetylsalicylic acid] | SRD-46 | +0 | 1x | +0.000 | 0 | — |
| 9 | `L2:1` | [Citric acid] | SRD-46 | -3 | 1x | +32.248 | 0 | — |
| 10 | `L2:1 H:1` | [HCitric acid]2- | SRD-46 | -2 | 1x | +0.000 | 0 | — |
| 11 | `Pu$+1:1` | [PuO_[]2+ | SRD-46 | +1 | 1x | +0.000 | -1 | — |
| 12 | `Pu$+1:1 H:-1` | [PuO_[(OH)] | SRD-46 | +0 | 1x | +56.506 | -1 | — |
| 13 | `Pu$+2:1` | [PuO_[]22+ | SRD-46 | +2 | 1x | +0.000 | -2 | — |
| 14 | `Pu$+2:1 H:-1` | [PuO_[(OH)]+ | SRD-46 | +1 | 1x | +31.963 | -2 | — |
| 15 | `Pu$+2:1 H:-1` | [PuO_[2(OH)]22+ | SRD-46 | +2 | 2x | +47.945 | -4 | — |
| 16 | `Pu$+2:3 H:-5` | [PuO_[3(OH)]5+ | SRD-46 | +1 | 1x | +123.286 | -6 | — |
| 17 | `Pu$+3:1` | [Pu]3+ | SRD-46 | +3 | 1x | +0.000 | -3 | — |
| 18 | `Pu$+3:1 H:-1` | [Pu(OH)]2+ | SRD-46 | +2 | 1x | +119.862 | -3 | — |
| 19 | `Pu$+4:1` | [Pu]4+ | SRD-46 | +4 | 1x | +0.000 | -4 | — |
| 20 | `Pu$+4:1 H:-1` | [Pu(OH)]3+ | SRD-46 | +3 | 1x | +10.845 | -4 | — |

### Duplicated Groups

#### 1.1  Core: `Pu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [PuO_[(OH)]+ | SRD-46 | +1 | 1x | +31.963 | -2 | id=[Pu$+2].[OH].[z+1]; mu_canon=+31.9631 |
| 2 | [PuO_[2(OH)]22+ | SRD-46 | +2 | 2x | +47.945 | -4 | id=[Pu$+2]2.[OH]2.[z+2]; mu_canon=+47.9446 |

## 2. Solid / Dissolution Species

1 core groups, 1 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|
| 1 | `Am$+3:1 H:-3` | [Am(OH)3(s,am)] | SRD-46 | +0 | 1x | +139.839 | -3 | — |

## 3. Gas Species

*(No species in this section.)*

[Purpose: Compute joint speciation of Pu(IV) and Am(III) competing for aspirin (acetylsalicylic acid) and citrate in a single solution at pH 4, and identify the dominant Pu and Am complexes with each ligand.]
[Tasks:
Model a single pot containing Pu(IV) at 1 mM and Am(III) at 1 mM together with acetylsalicylic acid (aspirin) at 5 mM and citrate at 5 mM, at pH 4, 25 C and ionic strength 0.1 m. Solve the joint equilibrium and report the dominant Pu complex and the dominant Am complex, distinguishing aspirin-bound versus citrate-bound species, and give the fractional distribution of each metal across its complexes at pH 4.
]
[Pair: pair_key=`m150_l10076`, metal_id=150, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal150_ligand10076_beta812_net27424`
  - `metal150_ligand10076_beta519_net27424`
  - `metal150_ligand10076_beta652_net27424`
[Screen report]
# Eq-map screen — m150_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal150_ligand10076_beta812_net27424` | `[M] + [L] <=> [ML]` | vlm_170649@(25.0,0.0) = K+8.400 | 3 | +7.800 / +7.900 / +8.033 / +8.400 | vlm_170649@(25.0,0.0) = K+8.400 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal150_ligand10076_beta519_net27424` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170652@(25.0,0.0) = K+19.600 | 3 | +19.100 / +19.600 / +19.600 / +20.100 | vlm_170652@(25.0,0.0) = K+19.600 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 3 | `metal150_ligand10076_beta652_net27424` | `[M]^3 + [L]^5 <=> [M3L5]` | vlm_170655@(25.0,0.0) = K+48.400 | 3 | +46.800 / +48.400 / +48.167 / +49.300 | vlm_170655@(25.0,0.0) = K+48.400 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

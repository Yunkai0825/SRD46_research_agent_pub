# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    88.72
- elapsed_s (total):  88.72
- llm_iterations:     13
- llm_tool_calls:     11

- n_groups:           18
- n_multi_groups:     1
- n_singletons:       17
- n_decisions:        18
- n_dropped:          0
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Pu$+2:1 H:-1` | `[PuO_[(OH)]+`, `[PuO_[2(OH)]22+` | Mononuclear PuO(OH)+ and dinuclear (PuO)2(OH)2^2+ differ in nuclearity and charge; both retained. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member of group. |
| aqueous | `Am$+3:1` | yes | Reference Am3+ aqueous ion; valid thermodynamics. |
| aqueous | `Am$+3:1 H:-1` | yes | Valid hydrolysis species; unique in group. |
| aqueous | `Am$+3:1 H:-2` | yes | Valid hydrolysis species; unique in group. |
| aqueous | `Am$+3:1 H:-3` | yes | Valid hydrolysis species; unique in group. |
| aqueous | `Am$+3:1 L1:1` | yes | Valid Am-citrate complex; unique. |
| aqueous | `L1:1` | yes | Citrate ligand; valid thermodynamics. |
| aqueous | `L1:1 H:1` | yes | Protonated citrate; valid thermodynamics. |
| aqueous | `Pu$+1:1` | yes | PuO2+ reference ion; valid. |
| aqueous | `Pu$+1:1 H:-1` | yes | Valid hydrolysis species; unique. |
| aqueous | `Pu$+2:1` | yes | PuO22+ reference ion; valid. |
| aqueous | `Pu$+2:3 H:-5` | yes | Polynuclear hydrolysis species; valid. |
| aqueous | `Pu$+3:1` | yes | Pu3+ reference ion; valid. |
| aqueous | `Pu$+3:1 H:-1` | yes | Valid hydrolysis species; unique. |
| aqueous | `Pu$+4:1` | yes | Pu4+ reference ion; valid. |
| aqueous | `Pu$+4:1 H:-1` | yes | Valid Pu(IV) hydrolysis species; unique. |
| solid | `Am$+3:1 H:-3` | yes | Am(OH)3 amorphous solid; valid thermodynamics. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|

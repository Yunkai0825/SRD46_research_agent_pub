# Free Energy Analysis Card

**System**: H, Pu, Am / Aspirin, Citric acid, Hydroxide ion
**Metals**: [Pu]4+, [Pu]3+, [PuO_[]22+, [PuO_[]2+, [Am]3+
**Ligands**: [Citric acid]
**Generated**: 2026-06-09 20:43:39 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Am$+3 | Metal component: [Am]3+ |
| Pu$+1 | Metal component: [PuO_[]2+ |
| Pu$+2 | Metal component: [PuO_[]22+ |
| Pu$+3 | Metal component: [Pu]3+ |
| Pu$+4 | Metal component: [Pu]4+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Citric acid] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Am$+3 | [Am]3+ | +3 | 0.001 | NIST SRD-46 | metal_6 |
| Pu$+1 | [PuO_[]2+ | +1 | 0.001 | NIST SRD-46 | metal_151 |
| Pu$+2 | [PuO_[]22+ | +2 | 0.001 | NIST SRD-46 | metal_150 |
| Pu$+3 | [Pu]3+ | +3 | 0.001 | NIST SRD-46 | metal_148 |
| Pu$+4 | [Pu]4+ | +4 | 0.001 | NIST SRD-46 | metal_149 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Citric acid] | -3 | 0.01 | [[H]3[L1]] | NIST SRD-46 | ligand_9058 | O=C(O)CC(O)(CC(=O)O)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Am | Am$+3 | [Am]3+ | +3 | true | 1 |
| Pu | Pu$+1 | [PuO_[]2+ | +1 | true | 4 |
| Pu | Pu$+2 | [PuO_[]22+ | +2 | false | 4 |
| Pu | Pu$+3 | [Pu]3+ | +3 | false | 4 |
| Pu | Pu$+4 | [Pu]4+ | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | C | [-2, -2, 1, 3, 3, 3] | true |
| L1 | [Citric acid] | O=C(O)CC(O)(CC(=O)O)C(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Am$+3 | [Am]3+ | metal | [Am]3+(aq) | +0.0000 | R1 | Am | +3 | true |
| Pu$+1 | [PuO_[]2+ | metal | [PuO_[]2+(aq) | +0.0000 | R1 | Pu | +1 | true |
| Pu$+2 | [PuO_[]22+ | metal | [PuO_[]22+(aq) | +0.0000 | R1 | Pu | +2 | false |
| Pu$+3 | [Pu]3+ | metal | [Pu]3+(aq) | +0.0000 | R1 | Pu | +3 | false |
| Pu$+4 | [Pu]4+ | metal | [Pu]4+(aq) | +0.0000 | R1 | Pu | +4 | false |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Citric acid] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Citric acid] | [L1] -> [[H]3[L1]] | 3 | 1 | +5.6500 | +32.2485 | ladder |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Citric acid] | 25.0 | 0.1 | *** | 3 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Pu]4+ + *** | 25.0 | 0.5 | *** | 1 |
| [Pu]3+ + *** | 25.0 | 0 | *** | 1 |
| [PuO_[]22+ + *** | 25.0 | 0 | *** | 3 |
| [PuO_[]2+ + *** | 25.0 | 0.1 | *** | 1 |
| [Am]3+ + [Citric acid] | 25.0 | 0.1 | 22147 | 1 |
| [Am]3+ + *** | 25.0 | 0.1 | *** | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by element (proton/ligand systems first), then valence (reference state first), ligand, and protonation (canonical HₓL reference first).

### 5.1 Aqueous Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [H].[OH].[z+0] | [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | SRD-46 | true |  |
| [[H][L1]].[z-2] | [[H][L1]].[z-2] | [HCitric acid]2- | -2 | aqueous | +5.6500 | -32.2485 | +0.0000 | +0.0000 | [[H][L1]]:+1 | SRD-46 | true |  |
| [L1].[z-3] | [L1].[z-3] | [Citric acid] | -3 | aqueous | +0.0000 | -0.0000 | +32.2485 | +32.2485 | [L1]:+1 | SRD-46 | true |  |
| [Am$+3].[z+3] | [M5].[z+3] | [Am]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Am$+3]:+1 | SRD-46 | true |  |
| [Am$+3].[OH].[z+2] | [M5].[OH].[z+2] | [Am(OH)]2+ | +2 | aqueous | -7.1000 | +40.5246 | +40.5246 | +40.5246 | [Am$+3]:+1, [OH]:+1 | SRD-46 | true |  |
| [Am$+3].[OH]2.[z+1] | [M5].[OH]2.[z+1] | [Am(OH)2]+ | +1 | aqueous | -15.2000 | +86.7569 | +86.7569 | +86.7569 | [Am$+3]:+1, [OH]:+2 | SRD-46 | true |  |
| [Am$+3].[OH]3.[z+0] | [M5].[OH]3.[z+0] | [Am(OH)3] | +0 | aqueous | -27.1000 | +154.6785 | +154.6785 | +154.6785 | [Am$+3]:+1, [OH]:+3 | SRD-46 | true |  |
| [Am$+3].[L1].[z+0] | [M5].[L1].[z+0] | [Am(Citr)] | +0 | aqueous | +7.7300 | -44.1205 | -44.1205 | -44.1205 | [Am$+3]:+1, [L1]:+1 | SRD-46 | true |  |
| [Pu$+4].[z+4] | [M1].[z+4] | [Pu]4+ | +4 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pu$+4]:+1 | SRD-46 | true |  |
| [Pu$+4].[OH].[z+3] | [M1].[OH].[z+3] | [Pu(OH)]3+ | +3 | aqueous | -1.9000 | +10.8446 | +10.8446 | +10.8446 | [Pu$+4]:+1, [OH]:+1 | SRD-46 | true |  |
| [Pu$+3].[z+3] | [M2].[z+3] | [Pu]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pu$+3]:+1 | SRD-46 | true |  |
| [Pu$+3].[OH].[z+2] | [M2].[OH].[z+2] | [Pu(OH)]2+ | +2 | aqueous | -21.0000 | +119.8615 | +119.8615 | +119.8615 | [Pu$+3]:+1, [OH]:+1 | SRD-46 | true |  |
| [Pu$+2].[z+2] | [M3].[z+2] | [PuO_[]22+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pu$+2]:+1 | SRD-46 | true |  |
| [Pu$+2].[OH].[z+1] | [M3].[OH].[z+1] | [PuO_[(OH)]+ | +1 | aqueous | -5.6000 | +31.9631 | +31.9631 | +31.9631 | [Pu$+2]:+1, [OH]:+1 | SRD-46 | true |  |
| [Pu$+2]2.[OH]2.[z+2] | [M3]2.[OH]2.[z+2] | [PuO_[2(OH)]22+ | +2 | aqueous | -8.4000 | +47.9446 | +47.9446 | +47.9446 | [Pu$+2]:+2, [OH]:+2 | SRD-46 | true |  |
| [Pu$+2]3.[OH]5.[z+1] | [M3]3.[OH]5.[z+1] | [PuO_[3(OH)]5+ | +1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [Pu$+2]:+3, [OH]:+5 | SRD-46 | true |  |
| [Pu$+1].[z+1] | [M4].[z+1] | [PuO_[]2+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Pu$+1]:+1 | SRD-46 | true |  |
| [Pu$+1].[OH].[z+0] | [M4].[OH].[z+0] | [PuO_[(OH)] | +0 | aqueous | -9.9000 | +56.5061 | +56.5061 | +56.5061 | [Pu$+1]:+1, [OH]:+1 | SRD-46 | true |  |

### 5.2 Dissolution / Solid Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [Am$+3].[OH]3.[[z+0(s)[1]]] | [M5].[OH]3.[[z+0(s)[1]]] | [Am(OH)3(s,am)] | +0 | dissolution | -24.5000 | +139.8385 | +139.8385 | +139.8385 | [Am$+3]:+1, [OH]:+3 | SRD-46 | true |  |

### 5.3 Gas Species

(No gas species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.01
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Joint speciation snapshot at pH 4, easily obtained from a 1-D pH scan.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L4_4_PuAm_aspirin_citrate_not_in_db\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
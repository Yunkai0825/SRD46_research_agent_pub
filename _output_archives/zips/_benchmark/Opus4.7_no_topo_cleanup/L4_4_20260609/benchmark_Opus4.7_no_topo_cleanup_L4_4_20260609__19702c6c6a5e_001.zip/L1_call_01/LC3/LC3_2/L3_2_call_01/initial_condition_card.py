inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Pu", "lhs": lambda s: s.total["Pu"], "value": 1e-3, "basis": "known"},
  {"id": "Am", "lhs": lambda s: s.total["Am"], "value": 1e-3, "basis": "known"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"],  "value": 5e-3, "basis": "known"},
  {"id": "Asp", "lhs": lambda s: s.total["ligand_10913"], "value": 5e-3, "basis": "known"},
]
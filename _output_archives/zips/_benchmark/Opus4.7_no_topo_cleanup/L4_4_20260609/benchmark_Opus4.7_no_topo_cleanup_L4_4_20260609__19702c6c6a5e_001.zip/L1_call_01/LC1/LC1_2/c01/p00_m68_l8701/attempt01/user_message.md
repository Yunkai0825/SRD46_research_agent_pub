[Purpose: Compute joint speciation of Pu(IV) and Am(III) competing for aspirin (acetylsalicylic acid) and citrate in a single solution at pH 4, and identify the dominant Pu and Am complexes with each ligand.]
[Tasks:
Model a single pot containing Pu(IV) at 1 mM and Am(III) at 1 mM together with aspirin (acetylsalicylic acid) at 5 mM and citrate at 5 mM, at pH 4, 25 C and ionic strength 0.1 m. Solve the joint equilibrium so the two metals compete for the shared aspirin and citrate pools. Report, for each metal, the dominant complex with aspirin and the dominant complex with citrate, the fraction of each metal bound to each ligand versus free/hydrolysed, and which ligand wins for each metal. A speciation snapshot at pH 4 is sufficient; if a pH scan is easier, scan pH 2-6 and report the values at pH 4.
]
[Pair: pair_key=`m68_l8701`, metal_id=68, ligand_id=8701, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand8701_beta79_net19219`
[Screen report]
# Eq-map screen — m68_l8701

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand8701_beta79_net19219` | `[L] + [H] <=> [HL]` | vlm_149911@(37.0,0.15) = K+3.450 | 1 | +3.450 / +3.450 / +3.450 / +3.450 | vlm_149911@(37.0,0.15) = K+3.450 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Compute joint speciation of Pu(IV) and Am(III) competing for aspirin (acetylsalicylic acid) and citrate in a single solution at pH 4, and identify the dominant Pu and Am complexes with each ligand.]
[Tasks:
Model a single pot containing Pu(IV) at 1 mM and Am(III) at 1 mM together with aspirin (acetylsalicylic acid) at 5 mM and citrate at 5 mM, at pH 4, 25 C and ionic strength 0.1 m. Solve the joint equilibrium so the two metals compete for the shared aspirin and citrate pools. Report, for each metal, the dominant complex with aspirin and the dominant complex with citrate, the fraction of each metal bound to each ligand versus free/hydrolysed, and which ligand wins for each metal. A speciation snapshot at pH 4 is sufficient; if a pH scan is easier, scan pH 2-6 and report the values at pH 4.
]
[Pair: pair_key=`m6_l10076`, metal_id=6, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal6_ligand10076_beta840_net27380`
  - `metal6_ligand10076_beta872_net27380`
  - `metal6_ligand10076_beta355_net27380`
  - `metal6_ligand10076_beta354_net27380`
[Screen report]
# Eq-map screen — m6_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal6_ligand10076_beta812_net27380` | `[M] + [L] <=> [ML]` | vlm_170507@(25.0,0.1) = K+6.900 | 3 | +6.500 / +6.900 / +6.967 / +7.500 | vlm_170507@(25.0,0.1) = K+6.900 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal6_ligand10076_beta840_net27380` | `[M] + [L]^2 <=> [ML2]` | vlm_170510@(25.0,0.1) = K+12.800 | 2 | +12.800 / +13.350 / +13.350 / +13.900 | vlm_170510@(25.0,0.1) = K+12.800 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal6_ligand10076_beta872_net27380` | `[M] + [L]^3 <=> [ML3]` | vlm_170512@(25.0,0.1) = K+14.900 | 2 | +14.900 / +15.600 / +15.600 / +16.300 | vlm_170512@(25.0,0.1) = K+14.900 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal6_ligand10076_beta355_net27380` | `[ML3(s,cr)] <=> [M] + [L]^3` | vlm_170514@(25.0,0.1) = K-15.600 | 2 | -15.600 / -15.300 / -15.300 / -15.000 | vlm_170514@(25.0,0.1) = K-15.600 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal6_ligand10076_beta354_net27380` | `[ML3(s,am)] <=> [M] + [L]^3` | vlm_170516@(25.0,0.1) = K-17.500 | 2 | -17.500 / -17.250 / -17.250 / -17.000 | vlm_170516@(25.0,0.1) = K-17.500 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

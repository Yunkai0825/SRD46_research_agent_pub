## Answer

In a single pot at pH 4, 25 °C, I = 0.1 m holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin and 5 mM citrate, the joint speciation (141/141 pH points converged) gives:

- **Am(III): ~100 % bound as [Am(Citr)]**, the mono-citrate chelate. The Am³⁺ ↔ [Am(Citr)] crossover sits at pH ≈ 0.27, so by pH 4 free Am³⁺ is already negligible and citrate has captured essentially all of the americium. Chemically this is exactly what you expect for a hard trivalent f-element: citrate offers three carboxylate O-donors plus an α-hydroxyl, an excellent hard-O chelate set, while aspirin has only a single carboxylate (its phenolic OH is acetyl-blocked), so it cannot compete — and indeed the SRD-46 catalog carries **no Am–aspirin complex at all**, consistent with that weakness.
- **Pu(IV): ~100 % as [Pu(OH)]³⁺.** The Pu⁴⁺ ↔ [Pu(OH)]³⁺ crossover lies at pH ≈ 1.90, so at pH 4 hydrolysis has fully taken over. In the model the citrate- and aspirin-bound Pu(IV) fractions are 0 %, but this is a **database gap, not chemistry**: SRD-46 as loaded here contains no Pu(IV)–citrate and no Pu(IV)–aspirin complexes, and the Pu(IV) hydrolysis ladder is also truncated at the mono-hydroxo. Real Pu(IV) at pH 4 is known to form very strong Pu–citrate chelates (and higher hydrolysis / colloidal species), so a more complete database (e.g. NEA TDB) would shift Pu(IV) strongly onto citrate. Free aspirinate at pH 4 (just past its pKa ≈ 3.5) and HCitrate²⁻ (citrate HL/L crossover at pH ≈ 5.7) sit in the bulk, with citrate in 5× excess over the metals.

**Winner per metal:** citrate decisively wins for Am(III); for Pu(IV) the *modelled* winner is hydrolysis, but the more chemically meaningful expectation — citrate ≫ aspirin — could not be quantified because the Pu–ligand thermodynamics are absent from SRD-46.

## Evidence
- "across the entire window pH ≈ 0.27 – 10.3 the dominant Am species is **[Am(Citr)]**, peaking at 100 % near pH 6.4. At pH 4 … essentially **~100 % of Am(III) is bound as [Am(Citr)]**."
- "The Pu(IV) envelope contains only two species: Pu⁴⁺ and [Pu(OH)]³⁺, with crossover at pH ≈ 1.90. At pH 4 … **[Pu(OH)]³⁺ ≈ 100 % of Pu(IV)**."
- "Free-energy species table actually loaded … Am(III): Am³⁺, [Am(OH)]²⁺, [Am(OH)₂]⁺, [Am(OH)₃](aq), [Am(OH)₃(s,am)], and **[Am(Citr)]** (the sole Am–ligand complex). Pu(IV): Pu⁴⁺ and **[Pu(OH)]³⁺** only."
- "141/141 converged", `pH_sweep`, fixed ionic mode, I = 0.1 m, 25 °C.
- Catalog caveat: "no Pu–aspirin, no Pu–citrate, and no Am–aspirin complexes" in SRD-46 as loaded.

## Artifacts
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_verdict.md`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_envelope_Am$+3.csv`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_envelope_Pu$+4.csv`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_frac_metal.csv`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_frac_ligand.csv`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_frac_Am.png`
- `L1_call_02/solver/Am$+3_+_Pu$+4_+_Acetylsalicylic_acid_+_Citric_acid_frac_Pu.png`
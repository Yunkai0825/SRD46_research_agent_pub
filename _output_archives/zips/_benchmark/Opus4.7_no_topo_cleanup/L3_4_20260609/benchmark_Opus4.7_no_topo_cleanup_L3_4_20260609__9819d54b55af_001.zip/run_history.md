# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Hard-soft acid-base theory predicts that when softer Cd(II) and harder Zn(II) compete in one pot for a soft donor (chloride) versus a borderline donor (ammonia), Cd(II) should monopolise the chloro-co' |
|  10.161 | L1_start | call=1; purpose='Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) preferentially binds ammonia when both metals compete in one pot for both ligands.' |
| 388.810 | L1_end | call=1; elapsed_s=378.6; ran_ok=True; attempts=1 |
| 431.952 | L0_end | elapsed_s=431.9454572200775; iterations=7; timed_out=False |

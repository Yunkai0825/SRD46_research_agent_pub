## Answer

**Falsifiable hypothesis (HSAB).** In a single pot containing Cd(II), Zn(II), Cl⁻ and NH₃, the softer Cd(II) will preferentially bind the softer donor (Cl⁻) and the harder Zn(II) will preferentially bind the borderline-harder donor (NH₃). Operationally: at pH 7, the chloro-bound fraction of Cd should exceed its ammine-bound fraction, AND the ammine-bound fraction of Zn should exceed its chloro-bound fraction, in the same equilibrium.

**Result at pH 7 (25 °C, I = 0.1 m, 1 mM Cd, 1 mM Zn, 0.1 M Cl⁻, 0.1 M NH₃ — same solution):**

| Metal | Σ chloro fraction | Σ ammine fraction | Aquo M²⁺ |
|-------|------------------:|------------------:|---------:|
| Cd(II) | **0.787** (CdCl⁺ 0.573, CdCl₂ 0.171, CdCl₃⁻ 0.043) | **0.037** (Cd(NH₃)ₙ²⁺, n=1–4) | 0.175 |
| Zn(II) | **0.066** (ZnCl⁺) | **0.073** (Zn(NH₃)ₙ²⁺, n=1–4) | 0.528 |

**Verdict: the HSAB prediction is confirmed in its qualitative, directional form, though with one important quantitative caveat.**

- Cd shows a dramatic, unambiguous preference for chloride: ~79 % of all Cd is in CdClₙ complexes versus only ~4 % in any ammine form — a chloro/ammine ratio of ≈ 21:1.
- Zn shows the opposite, but only weakly: its ammine fraction (~7.3 %) just edges out its chloro fraction (~6.6 %), while the majority of Zn (~53 %) remains as the uncomplexed aquo ion (with the residual mass going into minor Zn–OH species not visible in the dominant-species envelope — pH 7 sits just below the onset of Zn–OH dominance).

**Chemical interpretation.** Two effects reinforce each other at pH 7:

1. *Intrinsic softness matching.* Cd²⁺ is the softer Lewis acid of the two, so it binds the soft, polarisable Cl⁻ much more strongly than Zn²⁺ does — Zn–Cl complexation is famously weak (only ZnCl⁺ even appears in the envelope at 0.1 M Cl⁻). Conversely, Zn²⁺, being harder/more compact, has substantially larger ammine stability constants (log β₄ ≈ 9 for Zn(NH₃)₄²⁺) than would be expected from simple charge/size alone, while Cd's preference for N-donors over Cl-donors is weak.
2. *Free-ligand availability.* At pH 7, NH₃ is ~99.4 % protonated as NH₄⁺ (pKₐ ≈ 9.25), so [NH₃]_free is only ~5 × 10⁻⁴ M of the 0.1 M total, whereas [Cl⁻]_free is the full 0.1 M. This ~200-fold availability gap *helps* Cd (whose intrinsic preference is already toward Cl) and *fights* Zn (whose intrinsic preference is toward NH₃). Despite that handicap, Zn's ammine fraction still narrowly beats its chloro fraction — exactly the signature of an intrinsic HSAB-driven affinity inverting the availability bias.

So the joint-equilibrium calculation refutes neither direction of the prediction: Cd monopolises the chloro pool (chloro/ammine ≈ 21), and Zn — despite vastly less free NH₃ than free Cl⁻ — still tilts toward ammine over chloro. The asymmetry in magnitude (Cd's preference is huge, Zn's is razor-thin) is itself a clean HSAB signature: the soft–soft Cd–Cl match is far more energetically decisive than the borderline Zn–NH₃ pairing.

## Evidence

- Cd at pH 7.00 (from `..._envelope_Cd$+2.csv`): Cd²⁺ 0.1751, [CdCl]⁺ 0.5735, [CdCl₂] 0.1712, [CdCl₃]⁻ 0.0425, [Cd(NH₃)]²⁺ 0.0355, [Cd(NH₃)₂]²⁺ 0.00190, [Cd(NH₃)₃]²⁺ 0.000023.
- Zn at pH 7.00 (from `..._envelope_Zn$+2.csv`): Zn²⁺ 0.5284, [ZnCl]⁺ 0.0658, [Zn(NH₃)]²⁺ 0.0617, [Zn(NH₃)₂]²⁺ 0.01065, [Zn(NH₃)₃]²⁺ 0.000623, [Zn(NH₃)₄]²⁺ 0.000036.
- Pipeline status: `ok`; full pH sweep converged; verdict report written.

## Artifacts

- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_frac_metal.csv`
- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_envelope_Cd$+2.csv`
- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_frac_Cd.png`
- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_frac_Zn.png`
- `L1_call_01/solver/Cd$+2_+_Zn$+2_+_Ammonia_+_Chloride_ion_verdict.md`
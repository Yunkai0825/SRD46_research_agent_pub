# Speciation Calculation Report: Cd$+2 + Zn$+2 + Ammonia + Chloride ion

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 6.82043e-05 – 0.054 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 141
- Converged: 141/141

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cd | Cd | 1.00e-03 | metal |
| Cd$+0 | Cd(s) | 0.00e+00 | metal |
| Cd$+2 | Cd2+ | 1.00e-03 | metal |
| Zn | Zn | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |
| L2 | Chloride ion | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Chloride ion | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| Cd2+ | aqueous | Cd$+2:+1 | — | -0.0000 | +0.0000 |
| [Cd2(OH)]3+ | aqueous | Cd$+2:+2 H:-1 | — | +53.6523 | +53.6523 |
| [Cd(OH)]+ | aqueous | Cd$+2:+1 H:-1 | — | +57.0769 | +57.0769 |
| [Cd(OH)2] | aqueous | Cd$+2:+1 H:-2 | — | +115.8661 | +115.8661 |
| [Cd(OH)3]- | aqueous | Cd$+2:+1 H:-3 | — | +180.9338 | +180.9338 |
| [Cd4(OH)4]4+ | aqueous | Cd$+2:+4 H:-4 | — | +187.2123 | +187.2123 |
| [Cd(OH)4]2- | aqueous | Cd$+2:+1 H:-4 | — | +251.1384 | +251.1384 |
| [Cd(Ammo)4]2+ | aqueous | L1:+4 Cd$+2:+1 | — | -38.3557 | -38.3557 |
| [Cd(Ammo)3]2+ | aqueous | L1:+3 Cd$+2:+1 | — | -33.6754 | -33.6754 |
| [Cd(Ammo)2]2+ | aqueous | L1:+2 Cd$+2:+1 | — | -26.0271 | -26.0271 |
| [Cd(Ammo)]2+ | aqueous | L1:+1 Cd$+2:+1 | — | -14.6688 | -14.6688 |
| [Cd(Chlo)3]2+ | aqueous | L2:+3 Cd$+2:+1 | — | -13.6985 | -13.6985 |
| [Cd(Chlo)2]2+ | aqueous | L2:+2 Cd$+2:+1 | — | -11.4154 | -11.4154 |
| [Cd(Chlo)]2+ | aqueous | L2:+1 Cd$+2:+1 | — | -8.6757 | -8.6757 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +90.1815 | +90.1815 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Ammo)4]2+ | aqueous | L1:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L1:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L1:+2 Zn$+2:+1 | — | -27.5682 | -27.5682 |
| [Zn(Ammo)]2+ | aqueous | L1:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| [Zn(Chlo)]2+ | aqueous | L2:+1 Zn$+2:+1 | — | -0.5708 | -0.5708 |
| [Zn(Chlo)2]2+ | aqueous | L2:+2 Zn$+2:+1 | — | +0.5708 | +0.5708 |
| [Cd(OH)2(s,beta)] | dissolution | Cd$+2:+1 H:-2 | — | +78.2525 | +78.2525 |
| Cd(OH)2 (active) | dissolution | Cd$+2:+1 H:-2 | — | +82.0901 | +82.0901 |
| Cd | dissolution | Cd$+0:+1 | — | +0.0000 | +0.0000 |
| Zn(OH)2 (amorphous) | dissolution | H:-2 Zn$+2:+1 | — | +69.9146 | +69.9146 |
| [Zn(OH)2(s,epsilon)] | dissolution | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | dissolution | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 7.00: Zn(OH)2 (alpha) (3.18e-04 M)
- pH 9.80: Zn(OH)2 (alpha) (9.54e-04 M), [Cd(OH)2(s,beta)] (3.39e-05 M)
- pH 13.40: [Cd(OH)2(s,beta)] (6.50e-04 M)
- pH 13.70: all solids dissolved

## Speciation Analysis

```
=== Cd (Cd) speciation ===
[Cd]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cd(s) (Cd$+0) speciation ===
[Cd$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cd2+ (Cd$+2) speciation ===
[Cd$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Cd2+                peak 18.2% at pH 0.0
  [Cd(OH)4]2-         peak 98.0% at pH 14.0
  [Cd(Ammo)4]2+       peak 21.8% at pH 9.8
  [Cd(Ammo)3]2+       peak 44.9% at pH 9.7
  [Cd(Ammo)2]2+       peak 43.6% at pH 8.8
  [Cd(Ammo)]2+        peak 27.0% at pH 8.3
  [Cd(Chlo)2]2+       peak 17.8% at pH 0.0
  [Cd(Chlo)]2+        peak 59.6% at pH 0.0
  [Cd(OH)2(s,beta)]   peak 99.9% at pH 11.7

Dominant species by pH region:
  pH   0.0–  8.3  →  [Cd(Chlo)]2+
  pH   8.3–  8.4  →  [Cd(Ammo)]2+
  pH   8.4–  9.3  →  [Cd(Ammo)2]2+
  pH   9.3– 10.0  →  [Cd(Ammo)3]2+
  pH  10.0– 13.5  →  [Cd(OH)2(s,beta)]
  pH  13.5– 14.0  →  [Cd(OH)4]2-

Crossover pH values:
  Cd2+ ↔ [Cd(Ammo)3]2+  at pH ≈ 8.35  (each ~7%)
  Cd2+ ↔ [Cd(Ammo)2]2+  at pH ≈ 8.01  (each ~12%)
  Cd2+ ↔ [Cd(Ammo)]2+  at pH ≈ 7.70  (each ~15%)
  [Cd(OH)4]2- ↔ [Cd(OH)2(s,beta)]  at pH ≈ 13.48  (each ~48%)
  [Cd(Ammo)4]2+ ↔ [Cd(Ammo)2]2+  at pH ≈ 10.00  (each ~13%)
  [Cd(Ammo)4]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 9.13  (each ~10%)
  [Cd(Ammo)4]2+ ↔ [Cd(Chlo)]2+  at pH ≈ 8.87  (each ~5%)
  [Cd(Ammo)4]2+ ↔ [Cd(OH)2(s,beta)]  at pH ≈ 9.86  (each ~19%)
  [Cd(Ammo)3]2+ ↔ [Cd(Ammo)2]2+  at pH ≈ 9.21  (each ~38%)
  [Cd(Ammo)3]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 8.71  (each ~20%)
  [Cd(Ammo)3]2+ ↔ [Cd(Chlo)2]2+  at pH ≈ 8.35  (each ~7%)
  [Cd(Ammo)3]2+ ↔ [Cd(Chlo)]2+  at pH ≈ 8.55  (each ~13%)
  [Cd(Ammo)3]2+ ↔ [Cd(OH)2(s,beta)]  at pH ≈ 9.91  (each ~31%)
  [Cd(Ammo)2]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 8.32  (each ~27%)
  [Cd(Ammo)2]2+ ↔ [Cd(Chlo)2]2+  at pH ≈ 8.00  (each ~12%)
  [Cd(Ammo)2]2+ ↔ [Cd(Chlo)]2+  at pH ≈ 8.29  (each ~25%)
  [Cd(Ammo)2]2+ ↔ [Cd(OH)2(s,beta)]  at pH ≈ 9.87  (each ~21%)
  [Cd(Ammo)]2+ ↔ [Cd(Chlo)2]2+  at pH ≈ 7.69  (each ~15%)
  [Cd(Ammo)]2+ ↔ [Cd(Chlo)]2+  at pH ≈ 8.25  (each ~27%)

=== Zn (Zn) speciation ===
[Zn]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  Zn2+                peak 88.3% at pH 0.0
  [Zn(OH)3]-          peak 9.0% at pH 13.4
  [Zn(OH)4]2-         peak 97.5% at pH 14.0
  [Zn(Ammo)4]2+       peak 6.9% at pH 9.3
  [Zn(Ammo)]2+        peak 7.4% at pH 6.9
  [Zn(Chlo)]2+        peak 11.0% at pH 0.0

Dominant species by pH region:
  pH   0.0–  8.0  →  Zn2+
  pH   8.0–  8.2  →  [Zn(Ammo)]2+
  pH   8.2– 11.0  →  [Zn(Ammo)4]2+
  pH  11.0– 12.5  →  [Zn(OH)3]-
  pH  12.5– 14.0  →  [Zn(OH)4]2-

Crossover pH values:
  [Zn(Ammo)]2+ ↔ [Zn(Chlo)]2+  at pH ≈ 7.04  (each ~6%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 0.0
  Ammonia             peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  9.3  →  HAmmonia+
  pH   9.3– 14.0  →  Ammonia

=== Chloride ion (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  Chloride ion        peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0– 14.0  →  Chloride ion

```
# LC2_3 dispatch report (call 01)

- merged_card:        `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_4_HSAB_CdZn_chloride_ammonia_competition\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_4_HSAB_CdZn_chloride_ammonia_competition\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    135.03
- elapsed_s (total):  135.04
- llm_iterations:     32
- llm_tool_calls:     22

- n_groups:           32
- n_multi_groups:     9
- n_singletons:       23
- n_decisions:        32
- n_dropped:          12
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_names | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` | True duplicate of Cd2+ aqueous cation; prefer SRD-46 entry. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+`, `[Cd4(OH)4]4+` | Different nuclearity (mononuclear vs tetranuclear) and charge — distinct species per rule 2. |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | [Cd(OH)3]- and [HCdO2]- are notational variants of the same mononuclear Cd(II) trihydroxo anion; keep SRD-46 critically-evaluated value. |
| aqueous | `Zn$+2:1` | `[Zn]2+` | Identical aqueous Zn2+ ion; prefer SRD-46 notation over Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | True duplicate (same species, same charge/nuclearity); kept SRD-46 over Atlas per plan. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | [HZnO2]- and [Zn(OH)3]- are the same aqueous mononuclear Zn(II) hydroxo anion (charge -1) differing only in notation (hydration of formula); kept SRD-46 form with lower mu. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | ZnO2^2- and Zn(OH)4^2- are the same zincate species in different notation; keep SRD-46 version. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]`, `Cd(OH)2 (active)` | Kept SRD-46 beta-Cd(OH)2 as preferred hydroxide; dropped Atlas 'inactive' as duplicate (mu nearly identical) and CdO per addendum favoring hydrated form; retained Atlas 'active' as distinct polymorph. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)`, `Zn(OH)2 (gamma)`, `Zn(OH)2 (beta)`, `[Zn(OH)2(s,epsilon)]`, `Zn(OH)2 (amorphous)` | Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept SRD-46 epsilon over Atlas duplicate and retained distinct Zn(OH)2 polymorphs. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Valid mu_aligned_kJ; sole member. |
| aqueous | `Cd$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 H:-4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L1:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L1:3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L1:4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L2:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L2:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:1 L2:3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Cd$+2:2 H:-1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L1:1` | yes | Reference ligand; sole member. |
| aqueous | `L1:1 H:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `L2:1` | yes | Reference ligand; sole member. |
| aqueous | `Zn$+2:1 H:-2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L1:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L1:2` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L1:3` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L1:4` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L2:1` | yes | Valid thermodynamics; sole member. |
| aqueous | `Zn$+2:1 L2:2` | yes | Valid thermodynamics; sole member. |
| solid | `Cd$+0:1` | yes | Reference metal solid; sole member. |
| solid | `Zn$+0:1` | yes | Reference metal solid; sole member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | dedup: excluded (True duplicate of Cd2+ aqueous cation; prefer SRD-46 entry.) |
| `[HCdO2]-` | Atlas | aqueous | dedup: excluded ([Cd(OH)3]- and [HCdO2]- are notational variants of the same mononuclear Cd(II) trihydroxo anion; keep SRD-46 critically-evaluated value.) |
| `Zn2+` | Atlas | aqueous | dedup: excluded (Identical aqueous Zn2+ ion; prefer SRD-46 notation over Atlas duplicate.) |
| `[ZnOH]+` | Atlas | aqueous | dedup: excluded (True duplicate (same species, same charge/nuclearity); kept SRD-46 over Atlas per plan.) |
| `[HZnO2]-` | Atlas | aqueous | dedup: excluded ([HZnO2]- and [Zn(OH)3]- are the same aqueous mononuclear Zn(II) hydroxo anion (charge -1) differing only in notation (hydration of formula); kept SRD-46 form with lower mu.) |
| `[ZnO2]2-` | Atlas | aqueous | dedup: excluded (ZnO2^2- and Zn(OH)4^2- are the same zincate species in different notation; keep SRD-46 version.) |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | dedup: excluded (Kept SRD-46 beta-Cd(OH)2 as preferred hydroxide; dropped Atlas 'inactive' as duplicate (mu nearly identical) and CdO per addendum favoring hydrated form; retained Atlas 'active' as distinct polymorph.) |
| `CdO` | Atlas | dissolution | dedup: excluded (Kept SRD-46 beta-Cd(OH)2 as preferred hydroxide; dropped Atlas 'inactive' as duplicate (mu nearly identical) and CdO per addendum favoring hydrated form; retained Atlas 'active' as distinct polymorph.) |
| `ZnO (inactive)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept SRD-46 epsilon over Atlas duplicate and retained distinct Zn(OH)2 polymorphs.) |
| `ZnO (active)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept SRD-46 epsilon over Atlas duplicate and retained distinct Zn(OH)2 polymorphs.) |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept SRD-46 epsilon over Atlas duplicate and retained distinct Zn(OH)2 polymorphs.) |
| `ZnO` | Atlas | dissolution | dedup: excluded (Dropped anhydrous ZnO polymorphs per addendum favoring hydrated oxyhydroxide; kept SRD-46 epsilon over Atlas duplicate and retained distinct Zn(OH)2 polymorphs.) |

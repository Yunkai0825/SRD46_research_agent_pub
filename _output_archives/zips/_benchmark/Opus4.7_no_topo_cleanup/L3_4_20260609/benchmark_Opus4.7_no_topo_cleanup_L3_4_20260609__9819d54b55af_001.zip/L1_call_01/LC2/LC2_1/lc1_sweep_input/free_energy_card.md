# Free Energy Analysis Card

**System**: H, Cd, Zn / Chloride, Ammonia, Hydroxide ion
**Metals**: [Cd]2+, [Zn]2+
**Ligands**: [Ammonia], [Chloride ion]
**Generated**: 2026-06-09 19:40:22 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cd]2+ |
| M2 | Metal component: [Zn]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ammonia] |
| L2 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `{1}`, `{2}` (log_beta descending)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cd]2+ | +2 | 0.001 | NIST SRD-46 | metal_26 |
| M2 | [Zn]2+ | +2 | 0.001 | NIST SRD-46 | metal_208 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ammonia] | +0 | 0.01 | [[L1]] | NIST SRD-46 | ligand_10103 | N |
| L2 | [Chloride ion] | +0 | 0.01 | [[L2]] | NIST SRD-46 | ligand_10163 | *** |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cd | M1 | [Cd]2+ | +2 | true | 1 |
| Zn | M2 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ammonia] | N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cd]2+ | metal | [Cd]2+(aq) | +0.0000 | R1 | Cd | +2 | true |
| M2 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Ammonia] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |
| L2 | [Chloride ion] | ligand_canonical | [[L2]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ammonia] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |
| L2 | [Chloride ion] | [L2] -> [[L2]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Ammonia] | 25.0 | 0.1 | *** | 1 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cd]2+ + [Chloride ion] | 25.0 | 0~0.1 | 29910 | 3 |
| [Cd]2+ + [Ammonia] | 25.0 | 0~0.1 | 28286 | 4 |
| [Cd]2+ + *** | 25.0 | 3 | *** | 8 |
| [Zn]2+ + [Chloride ion] | 25.0 | 0 | 29904 | 2 |
| [Zn]2+ + [Ammonia] | 25.0 | 0~0.1 | 28282 | 4 |
| [Zn]2+ + *** | 25.0 | 0~0.1 | *** | 11 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | *** |

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [[H][L1]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L1]]:+1 | vlm_173034 | *** |
| [L1].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [L2].[z+0] | [Chloride ion] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L2]:+1 | R4: μ°≡0 (free-ligand ref) | *** |

#### [Cd]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[z+2] | [Cd]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Cd]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L1]4.[z+2] | [Cd(Ammo)4]2+ | +2 | aqueous | +6.7200 | -38.3557 | -38.3557 | -38.3557 | [M1]:+1, [L1]:+4 | vlm_173455 | *** |
| [M1].[L1]3.[z+2] | [Cd(Ammo)3]2+ | +2 | aqueous | +5.9000 | -33.6754 | -33.6754 | -33.6754 | [M1]:+1, [L1]:+3 | vlm_173443 | *** |
| [M1].[L1]2.[z+2] | [Cd(Ammo)2]2+ | +2 | aqueous | +4.5600 | -26.0271 | -26.0271 | -26.0271 | [M1]:+1, [L1]:+2 | vlm_173431 | *** |
| [M1].[L1].[z+2] | [Cd(Ammo)]2+ | +2 | aqueous | +2.5700 | -14.6688 | -14.6688 | -14.6688 | [M1]:+1, [L1]:+1 | vlm_173415 | *** |

#### [Cd]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[L2]3.[z+2] | [Cd(Chlo)3]2+ | +2 | aqueous | +2.4000 | -13.6985 | -13.6985 | -13.6985 | [M1]:+1, [L2]:+3 | vlm_177567 | *** |
| [M1].[L2]2.[z+2] | [Cd(Chlo)2]2+ | +2 | aqueous | +2.0000 | -11.4154 | -11.4154 | -11.4154 | [M1]:+1, [L2]:+2 | vlm_177558 | *** |
| [M1].[L2].[z+2] | [Cd(Chlo)]2+ | +2 | aqueous | +1.5200 | -8.6757 | -8.6757 | -8.6757 | [M1]:+1, [L2]:+1 | vlm_177542 | *** |

#### [Cd]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1]2.[OH].[z+3] | [Cd2(OH)]3+ | +3 | aqueous | -9.4000 | +53.6523 | +53.6523 | +53.6523 | [M1]:+2, [OH]:+1 | vlm_170972 | *** |
| [M1].[OH].[z+1] | [Cd(OH)]+ | +1 | aqueous | -10.0000 | +57.0769 | +57.0769 | +57.0769 | [M1]:+1, [OH]:+1 | vlm_170962 | *** |
| [M1].[OH]2.[z+0] | [Cd(OH)2] | +0 | aqueous | -20.3000 | +115.8661 | +115.8661 | +115.8661 | [M1]:+1, [OH]:+2 | vlm_170967 | *** |
| [M1].[OH]3.[z-1] | [Cd(OH)3]- | -1 | aqueous | -31.7000 | +180.9338 | +180.9338 | +180.9338 | [M1]:+1, [OH]:+3 | vlm_170969 | *** |
| [M1]4.[OH]4.[z+4] | [Cd4(OH)4]4+ | +4 | aqueous | -32.8000 | +187.2123 | +187.2123 | +187.2123 | [M1]:+4, [OH]:+4 | vlm_170976 | *** |
| [M1].[OH]4.[z-2] | [Cd(OH)4]2- | -2 | aqueous | -44.0000 | +251.1384 | +251.1384 | +251.1384 | [M1]:+1, [OH]:+4 | vlm_170970 | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | *** |

#### [Zn]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L1]4.[z+2] | [Zn(Ammo)4]2+ | +2 | aqueous | +8.8900 | -50.7414 | -50.7414 | -50.7414 | [M2]:+1, [L1]:+4 | vlm_173412 | *** |
| [M2].[L1]3.[z+2] | [Zn(Ammo)3]2+ | +2 | aqueous | +6.8600 | -39.1548 | -39.1548 | -39.1548 | [M2]:+1, [L1]:+3 | vlm_173407 | *** |
| [M2].[L1]2.[z+2] | [Zn(Ammo)2]2+ | +2 | aqueous | +4.8300 | -27.5682 | -27.5682 | -27.5682 | [M2]:+1, [L1]:+2 | vlm_173402 | *** |
| [M2].[L1].[z+2] | [Zn(Ammo)]2+ | +2 | aqueous | +2.3300 | -13.2989 | -13.2989 | -13.2989 | [M2]:+1, [L1]:+1 | vlm_173394 | *** |

#### [Zn]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[L2].[z+2] | [Zn(Chlo)]2+ | +2 | aqueous | +0.1000 | -0.5708 | -0.5708 | -0.5708 | [M2]:+1, [L2]:+1 | vlm_177531 | *** |
| [M2].[L2]2.[z+2] | [Zn(Chlo)2]2+ | +2 | aqueous | -0.1000 | +0.5708 | +0.5708 | +0.5708 | [M2]:+1, [L2]:+2 | vlm_177538 | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M2]:+1, [OH]:+1 | vlm_170929 | *** |
| [M2].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -15.8000 | +90.1815 | +90.1815 | +90.1815 | [M2]:+1, [OH]:+2 | vlm_170935 | *** |
| [M2].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M2]:+1, [OH]:+3 | vlm_170937 | *** |
| [M2].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M2]:+1, [OH]:+4 | vlm_170939 | *** |

### 5.2 Dissolution / Solid Species

#### [Cd]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [Cd(OH)2(s,beta)] | +0 | dissolution | -13.7100 | +78.2525 | +78.2525 | +78.2525 | [M1]:+1, [OH]:+2 | vlm_170980 | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|------------------|
| [M2].[OH]2.[[z+0(s)[1]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M2]:+1, [OH]:+2 | vlm_170956 | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 34 |
| Included in calculation | 34 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 20 |
| Unresolved (no species in card) | 14 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 2 | vlm_170275 | [<H+>] + [<OH+->] <=> [<H+><OH+->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 3 | vlm_177558_patched | [<Chloride ion>]^2 + [<Cd2+>] <=> [<Cd2+><Chloride ion>2] | +2.0000 | 25.0 | 0.000 | yes | — |
| 4 | vlm_177542 | [<Chloride ion>] + [<Cd2+>] <=> [<Cd2+><Chloride ion>] | +1.5200 | 25.0 | 0.100 | yes | [Cd(Chlo)]2+ |
| 5 | vlm_177567 | [<Chloride ion>]^3 + [<Cd2+>] <=> [<Cd2+><Chloride ion>3] | +2.4000 | 25.0 | 0.000 | yes | [Cd(Chlo)3]2+ |
| 6 | vlm_173455 | [<Ammonia>]^4 + [<Cd2+>] <=> [<Cd2+><Ammonia>4] | +6.7200 | 25.0 | 0.000 | yes | [Cd(Ammo)4]2+ |
| 7 | vlm_173443 | [<Ammonia>]^3 + [<Cd2+>] <=> [<Cd2+><Ammonia>3] | +5.9000 | 25.0 | 0.000 | yes | [Cd(Ammo)3]2+ |
| 8 | vlm_173431 | [<Ammonia>]^2 + [<Cd2+>] <=> [<Cd2+><Ammonia>2] | +4.5600 | 25.0 | 0.000 | yes | [Cd(Ammo)2]2+ |
| 9 | vlm_173415 | [<Ammonia>] + [<Cd2+>] <=> [<Cd2+><Ammonia>] | +2.5700 | 25.0 | 0.100 | yes | [Cd(Ammo)]2+ |
| 10 | vlm_170976_patched | [<OH+->]^4 + [<Cd2+>]^4 <=> [<Cd2+>4<OH+->4] | +23.2000 | 25.0 | 3.000 | yes | — |
| 11 | vlm_170962 | [<OH+->] + [<Cd2+>] <=> [<Cd2+><OH+->] | +4.0000 | 25.0 | 3.000 | yes | [Cd(OH)]+ |
| 12 | vlm_170967 | [<OH+->]^2 + [<Cd2+>] <=> [<Cd2+><OH+->2] | +7.7000 | 25.0 | 3.000 | yes | [Cd(OH)2] |
| 13 | vlm_170969 | [<OH+->]^3 + [<Cd2+>] <=> [<Cd2+><OH+->3] | +10.3000 | 25.0 | 3.000 | yes | [Cd(OH)3]- |
| 14 | vlm_170970 | [<OH+->]^4 + [<Cd2+>] <=> [<Cd2+><OH+->4] | +12.0000 | 25.0 | 3.000 | yes | [Cd(OH)4]2- |
| 15 | vlm_170972_patched | [<OH+->] + [<Cd2+>]^2 <=> [<Cd2+>2<OH+->] | +4.6000 | 25.0 | 3.000 | yes | — |
| 16 | vlm_170980 | [<Cd2+><OH+->2(s,beta)] <=> [<OH+->]^2 + [<Cd2+>] | -14.2900 | 25.0 | 3.000 | yes | [Cd(OH)2(s,beta)] |
| 17 | vlm_170984 | [<Cd2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Cd2+>] | -14.1000 | 25.0 | 3.000 | yes | — |
| 18 | vlm_177538_patched | [<Chloride ion>]^2 + [<Zn2+>] <=> [<Zn2+><Chloride ion>2] | -0.1000 | 25.0 | 0.000 | yes | — |
| 19 | vlm_177531_patched | [<Chloride ion>] + [<Zn2+>] <=> [<Zn2+><Chloride ion>] | +0.1000 | 25.0 | 0.000 | yes | — |
| 20 | vlm_173394 | [<Ammonia>] + [<Zn2+>] <=> [<Zn2+><Ammonia>] | +2.3300 | 25.0 | 0.100 | yes | [Zn(Ammo)]2+ |
| 21 | vlm_173412 | [<Ammonia>]^4 + [<Zn2+>] <=> [<Zn2+><Ammonia>4] | +8.8900 | 25.0 | 0.000 | yes | [Zn(Ammo)4]2+ |
| 22 | vlm_173402_patched | [<Ammonia>]^2 + [<Zn2+>] <=> [<Zn2+><Ammonia>2] | +4.8300 | 25.0 | 0.000 | yes | — |
| 23 | vlm_173407 | [<Ammonia>]^3 + [<Zn2+>] <=> [<Zn2+><Ammonia>3] | +6.8600 | 25.0 | 0.000 | yes | [Zn(Ammo)3]2+ |
| 24 | vlm_170929 | [<OH+->] + [<Zn2+>] <=> [<Zn2+><OH+->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 25 | vlm_170935_patched | [<OH+->]^2 + [<Zn2+>] <=> [<Zn2+><OH+->2] | +12.2000 | 25.0 | 0.000 | yes | — |
| 26 | vlm_170937 | [<OH+->]^3 + [<Zn2+>] <=> [<Zn2+><OH+->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 27 | vlm_170939 | [<OH+->]^4 + [<Zn2+>] <=> [<Zn2+><OH+->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 28 | vlm_170944 | [<Zn2+><OH+->2(s,am)] <=> [<OH+->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | — |
| 29 | vlm_170948 | [<Zn2+><OH+->2(s,beta1)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | — |
| 30 | vlm_170950 | [<Zn2+><OH+->2(s,beta2)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | — |
| 31 | vlm_170952 | [<Zn2+><OH+->2(s,gamma)] <=> [<OH+->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | — |
| 32 | vlm_170954 | [<Zn2+><OH+->2(s,delta)] <=> [<OH+->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | — |
| 33 | vlm_170956 | [<Zn2+><OH+->2(s,epsilon)] <=> [<OH+->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 34 | vlm_170958 | [H+2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [O<H+>]^2 | -15.9600 | 25.0 | 0.100 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

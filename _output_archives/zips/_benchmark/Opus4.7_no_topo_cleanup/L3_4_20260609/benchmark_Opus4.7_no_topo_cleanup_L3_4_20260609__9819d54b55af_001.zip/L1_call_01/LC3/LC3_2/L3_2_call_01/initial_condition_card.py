inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known"},
  {"id": "Cd", "lhs": lambda s: s.total["Cd"],     "value": 1e-3,   "basis": "known"},
  {"id": "Zn", "lhs": lambda s: s.total["Zn"],     "value": 1e-3,   "basis": "known"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known"},
  {"id": "Cl",  "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known"},
]
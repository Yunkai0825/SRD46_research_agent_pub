# L3_1 dispatch report (call 01)

- output_dir: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_4_HSAB_CdZn_chloride_ammonia_competition\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 7.97
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Single-point joint speciation at pH 7; use 1-D pH sweep (narrow range around 7) as the simplest standard role.

- calc_input_card_path: `Q:\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent\_DEBUG_output\L3_4_HSAB_CdZn_chloride_ammonia_competition\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
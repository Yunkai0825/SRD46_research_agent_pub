# LC2 element orchestration review phase agent response

## Final answer (text emitted by the agent)

Deduplication finalized. Atlas/SRD-46 duplicates of identical composition and charge collapsed to SRD-46 twins for Cu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) and Fe (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), and [HFeO2]-/[Fe(OH)3]- as the same Fe(III) anion). The ferric oxyhydroxide polymorph set (Atlas Fe2O3, Atlas Fe(OH)3, SRD-46 Fe(OH)3, SRD-46 FeOOH-alpha) was collapsed to the single lowest-mu representative (Fe2O3)0.5 SRD-46 since this is a "which phase is stable" study. All distinct ligand complexes (citrate, glycine, ammine 1-4, chloro 1-3+dimer), hydroxo monomers/dimers/trimers, both redox tiers of each metal, elemental Cu and Fe, Cu2O, CuO(s), Cu(OH)2(s), CuCl(s) nantokite, Fe3O4 magnetite, and ferrate(VI) [FeO4]2- were retained as each occupies a distinct region of the joint Cu-Fe Pourbaix field. No Fe(III)-ammine complexes are present in the source (Fe(III) hydrolysis outcompetes NH3 binding — acceptable); Cu(I) beyond [Cu(NH3)2]+, [Cu(Chlo)n], and [Cu(Glyc)2]- is not populated — flagged but not fabricated.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Orchestration session]
18d9141cb5b64d128bae2e174e0bc822

[Calculation purpose]
Compute the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II) and Fe(III) with citrate, glycine, chloride, and ammonia, and characterize how the two metals partition among aqueous complexes and solids across the field.

[Requested tasks]
Model a single pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V_SHE at reasonable resolution (about 71 x 51 grid). Report the topology: list every connected region with its dominant Cu-bearing and Fe-bearing species (aqueous complexes with citrate, glycine, ammonia, chloride, hydroxide as well as any predicted solids or metals), the pH/E extent of each region, the principal boundary segments and their triple-point junctions, and note which boundaries are redox-controlled versus pH/ligand-controlled. Cite the equilibrium constants and standard potentials the solver actually used for the reactions defining the major boundaries, and describe qualitatively how Cu and Fe partition between citrate, glycine, ammonia, chloride, hydroxide, and reduced/solid phases across the diagram.

[Committed case-specific recommendations — in every child system prompt]
- **Scenario**: joint Cu(II)+Fe(III) speciation/Pourbaix in one pot with excess citrate, glycine, ammonia, chloride at 25 C, I=0.1 m; not a corrosion 1e-6 M convention — metals are at 1 mM, ligands 10 mM (citrate, glycine, ammonia) and 0.1 M (chloride, ammonia). Retain the full ligand family and hydroxo family, all charge states, and both redox tiers of each metal.
- **Aqueous protonation/polynuclear**: keep every distinct stoichiometry (monomer vs dimer/trimer, protonated vs deprotonated citrate complexes, mono- through tetra-ammine, mono- through tri/tetra-chloro, mono/bis/tris glycine) — each competes in a distinct pH/ligand-activity window and can dominate a region. Only collapse when two rows are literally the same formula and charge from Atlas vs SRD-46.
- **Duplicates to collapse**: Atlas/SRD-46 pairs of identical composition and charge (e.g., Cu+, Cu2+, Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Cu2O, CuO, Cu(OH)2, Fe(OH)2(s)). Prefer the lower mu_aligned representative when close; if the gap exceeds ~5 kJ/mol keep the more internally consistent SRD-46 datum (matches the ligand complex source) to keep the diagram self-consistent.
- **Solids question**: this is a 'which phase is STABLE' study — collapse ferric oxyhydroxide polymorphs to the single lowest-mu representative (Fe2O3 alpha / FeOOH / Fe(OH)3 amorphous cover the same corner). Keep Fe3O4 as the distinct mixed-valence solid, keep elemental Fe and Cu, keep Cu2O and CuO/Cu(OH)2 pair (collapse CuO vs Cu(OH)2 only if same source and same mu; here retain one anhydrous CuO and one hydrated Cu(OH)2 since they can appear in different humidity/pH regimes — but drop the duplicate spelling within each).
- **Chloride solid**: CuCl(s) (nantokite) is in scope at 0.1 M Cl and reducing E; keep it.
- **Carbonates/other counterions**: none present in this pot; N/A.
- **Gases**: only H2O/H+/e-; no gaseous species listed and none needed as decorative.
- **Divergence**: Cu and Fe treated the same way — collapse Atlas vs SRD-46 duplicates, keep every distinct ligand/hydroxo/polynuclear stoichiometry, collapse ferric-oxide polymorphs on Fe side only.
- **Missing species flag**: no Fe(III)-ammine complexes are listed (Fe(III) hydrolyzes faster than it binds NH3 — acceptable omission); no Cu(I)-citrate or Cu(I)-glycine or Cu(I)-ammine beyond [Cu(NH3)2]+ listed — flag but do not fabricate.

[Committed element instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition and charge to a single entry, preferring SRD-46 when the ligand-complex chemistry is SRD-46-sourced so the diagram uses one self-consistent dataset (drop Atlas Cu+, Cu2+, CuO, Cu(OH)2, Cu2O in favor of their SRD-46 twins where mu agrees within a few kJ/mol; otherwise keep the lower-mu representative). Keep every other row — all Cu(I) and Cu(II) hydroxo monomers/dimers/trimer, every ammine (1–4), every chloro (1–3 plus dimer), every citrate/glycine complex, elemental Cu, Cu2O, CuO or Cu(OH)2 (one of each), and CuCl(s) — because each occupies a distinct pH/E/ligand-activity region of the joint diagram.
- Fe: Collapse Atlas/SRD-46 duplicates of identical composition and charge to one entry (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s)), preferring SRD-46 for self-consistency with the ligand complexes, and collapse the ferric oxyhydroxide polymorph set (Fe2O3 anh Atlas, (Fe2O3)0.5 SRD-46, Fe(OH)3 hydr Atlas, Fe(OH)3(s) SRD-46, FeOOH alpha SRD-46) to the single lowest-mu representative since this diagram asks which phase is stable, not which forms kinetically. Keep every other row — all Fe(II) and Fe(III) hydroxo mono/dimer/trimer species, every citrate/glycine/ammine/chloro complex, ferrate [FeO4]2-, Fe3O4 as the distinct mixed-valence solid, and elemental Fe — because each defines a distinct region of the joint Cu-Fe Pourbaix field.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |  |
| `DEDUP-282037ec98906bb1` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 | generation 1: kept — Distinct Cu(I) bis-glycinate complex. |  |
| `DEDUP-5826713fca0f819d` | true | kept | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 | generation 1: kept — Distinct Cu(I) diammine complex. |  |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 | generation 1: kept — Distinct Cu(I) monochloro complex. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu(Chlo)2]-` | SRD-46 | -34.589 | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -30.765 | generation 1: kept — Distinct Cu(I) trichloro complex. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — Distinct HCuO2- hydroxo species. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — Distinct CuO2 2- hydroxo species. |  |
| `DEDUP-19be21e964e99f8b` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | +94.036 | generation 1: kept — Distinct dinuclear Cu(II) citrate complex. |  |
| `DEDUP-e9bd8cea02e9ef19` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | +140.611 | generation 1: kept — Distinct hydroxo-dinuclear Cu(II) citrate. |  |
| `DEDUP-f8c7d987d5909246` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +35.545 | generation 1: kept — Distinct protonated Cu(II) citrate. |  |
| `DEDUP-f340634469432301` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 | generation 1: kept — Distinct Cu(II) mono-glycinate. |  |
| `DEDUP-005c7efaf139b504` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 | generation 1: kept — Distinct Cu(II) bis-glycinate. |  |
| `DEDUP-57e8daa9ccf0b2a2` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 | generation 1: kept — Distinct Cu(II) monoammine. |  |
| `DEDUP-cea12c0b6f396ab4` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 | generation 1: kept — Distinct Cu(II) diammine. |  |
| `DEDUP-153366f6feae80b7` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 | generation 1: kept — Distinct Cu(II) triammine. |  |
| `DEDUP-924bb0044556871a` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 | generation 1: kept — Distinct Cu(II) tetraammine. |  |
| `DEDUP-602158e7d04361c1` | true | kept | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +14.085 | generation 1: kept — Distinct Cu(II) monochloro. |  |
| `DEDUP-5b4c2e5b90b2574a` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +75.429 | generation 1: kept — Distinct dinuclear Cu(II) citrate-hydroxo. |  |
| `DEDUP-fd48f7cda37f7a35` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | +112.871 | generation 1: kept — Distinct dinuclear Cu2Citr2(OH) complex. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Distinct trinuclear Cu(II) hydroxo cluster. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). | Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 | generation 1: kept — CuCl(s) nantokite is in scope at 0.1 M Cl. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu required for low-E stability. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |  |

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. | Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Distinct Fe(II) monohydroxo. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Distinct Fe(II) dihydroxo. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. | [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. |  |
| `DEDUP-17eabf3a090b1c87` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +48.515 | generation 1: kept — Distinct Fe(II) citrate. |  |
| `DEDUP-c1005919640acd2c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 | generation 1: kept — Distinct dinuclear Fe(II) citrate-hydroxo. |  |
| `DEDUP-d6dc259da7a8dad8` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 | generation 1: kept — Distinct protonated Fe(II) citrate. |  |
| `DEDUP-cb0f7b97e4425385` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 | generation 1: kept — Distinct diprotonated Fe(II) citrate. |  |
| `DEDUP-da02a76e2d197424` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 | generation 1: kept — Distinct Fe(II) bis-citrate protonated. |  |
| `DEDUP-cf1160dc9504eb2a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +32.762 | generation 1: kept — Distinct Fe(II) mono-glycinate. |  |
| `DEDUP-1d8f50d12d89192a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +65.581 | generation 1: kept — Distinct Fe(II) bis-glycinate. |  |
| `DEDUP-11491a5268fb9a13` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | +113.241 | generation 1: kept — Distinct Fe(II) tris-glycinate. |  |
| `DEDUP-d044b8c62b54c4be` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | -7.991 | generation 1: kept — Distinct Fe(II) monoammine. |  |
| `DEDUP-801433485b3d9b5c` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | -12.842 | generation 1: kept — Distinct Fe(II) diammine. |  |
| `DEDUP-fa69a3f29ec6cf8a` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | -15.297 | generation 1: kept — Distinct Fe(II) triammine. |  |
| `DEDUP-40c8ded2bf5c101e` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | -15.696 | generation 1: kept — Distinct Fe(II) tetraammine. |  |
| `DEDUP-ba9c4263c6e90448` | true | kept | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 | generation 1: kept — Distinct Fe(II) monochloro. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. | Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. | Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. | Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.167 | generation 1: kept — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. |  |
| `DEDUP-b1eb803106b29936` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 | generation 1: kept — Distinct Fe(III) citrate. |  |
| `DEDUP-977369ffb378cf98` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |  |
| `DEDUP-0cc29ed24775130c` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |  |
| `DEDUP-c0bead80f3ce43c9` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 | generation 1: kept — Distinct protonated Fe(III) citrate. |  |
| `DEDUP-d8f65b4a69e194ec` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +177.887 | generation 1: kept — Distinct Fe(III) mono-glycinate. |  |
| `DEDUP-9a10196b107ab93c` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +64.247 | generation 1: kept — Distinct protonated Fe(III) glycinate. |  |
| `DEDUP-155d74fc42feb491` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +53.231 | generation 1: kept — Distinct Fe(III) bis-glycinate diprotonated. |  |
| `DEDUP-ebce5c1c1789032b` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 | generation 1: kept — Distinct Fe(III) monochloro. |  |
| `DEDUP-690d5b958c105643` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | SRD-46 | +62.192 | generation 1: kept — Distinct Fe(III) dichloro. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Distinct trinuclear Fe(III) hydroxo cluster. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate(VI) is the required high-E Fe species. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Fe3O4 magnetite retained as distinct mixed-valence solid. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe required for low-E stability. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. | Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-0b0637451c790e6b` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water/proton reference entry, retain. | Water/proton reference entry, retain. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+1:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) bis-glycinate complex. | Distinct Cu(I) bis-glycinate complex. |
| aqueous | `Cu$+1:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) diammine complex. | Distinct Cu(I) diammine complex. |
| aqueous | `Cu$+1:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) monochloro complex. | Distinct Cu(I) monochloro complex. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. | Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. | Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |
| aqueous | `Cu$+1:1 L4:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I) trichloro complex. | Distinct Cu(I) trichloro complex. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. | Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. | Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. | Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species. | Neutral Cu(II) dihydroxo aqueous species. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — Distinct HCuO2- hydroxo species. | Distinct HCuO2- hydroxo species. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — Distinct CuO2 2- hydroxo species. | Distinct CuO2 2- hydroxo species. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu2(Citr)2]2-` | SRD-46 | kept | true | generation 1: kept — Distinct dinuclear Cu(II) citrate complex. | Distinct dinuclear Cu(II) citrate complex. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Distinct hydroxo-dinuclear Cu(II) citrate. | Distinct hydroxo-dinuclear Cu(II) citrate. |
| aqueous | `Cu$+2:1 L1:1 H:1` | Cu | aqueous | `[Cu(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Cu(II) citrate. | Distinct protonated Cu(II) citrate. |
| aqueous | `Cu$+2:1 L2:1` | Cu | aqueous | `[Cu(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) mono-glycinate. | Distinct Cu(II) mono-glycinate. |
| aqueous | `Cu$+2:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) bis-glycinate. | Distinct Cu(II) bis-glycinate. |
| aqueous | `Cu$+2:1 L3:1` | Cu | aqueous | `[Cu(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) monoammine. | Distinct Cu(II) monoammine. |
| aqueous | `Cu$+2:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) diammine. | Distinct Cu(II) diammine. |
| aqueous | `Cu$+2:1 L3:3` | Cu | aqueous | `[Cu(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) triammine. | Distinct Cu(II) triammine. |
| aqueous | `Cu$+2:1 L3:4` | Cu | aqueous | `[Cu(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) tetraammine. | Distinct Cu(II) tetraammine. |
| aqueous | `Cu$+2:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(II) monochloro. | Distinct Cu(II) monochloro. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)(OH)]` | SRD-46 | kept | true | generation 1: kept — Distinct dinuclear Cu(II) citrate-hydroxo. | Distinct dinuclear Cu(II) citrate-hydroxo. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)]3-` | SRD-46 | kept | true | generation 1: kept — Distinct dinuclear Cu2Citr2(OH) complex. | Distinct dinuclear Cu2Citr2(OH) complex. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct trinuclear Cu(II) hydroxo cluster. | Distinct trinuclear Cu(II) hydroxo cluster. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. | Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. | Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) monohydroxo. | Distinct Fe(II) monohydroxo. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) dihydroxo. | Distinct Fe(II) dihydroxo. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. | [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. | [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. | Distinct Fe(II) tetrahydroxo anion. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Citr)]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) citrate. | Distinct Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Distinct dinuclear Fe(II) citrate-hydroxo. | Distinct dinuclear Fe(II) citrate-hydroxo. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(II) citrate. | Distinct protonated Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Fe | aqueous | `[Fe(Citr)H2]+` | SRD-46 | kept | true | generation 1: kept — Distinct diprotonated Fe(II) citrate. | Distinct diprotonated Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Fe | aqueous | `[Fe(Citr)2H]3-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) bis-citrate protonated. | Distinct Fe(II) bis-citrate protonated. |
| aqueous | `Fe$+2:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) mono-glycinate. | Distinct Fe(II) mono-glycinate. |
| aqueous | `Fe$+2:1 L2:2` | Fe | aqueous | `[Fe(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) bis-glycinate. | Distinct Fe(II) bis-glycinate. |
| aqueous | `Fe$+2:1 L2:3` | Fe | aqueous | `[Fe(Glyc)3]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) tris-glycinate. | Distinct Fe(II) tris-glycinate. |
| aqueous | `Fe$+2:1 L3:1` | Fe | aqueous | `[Fe(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) monoammine. | Distinct Fe(II) monoammine. |
| aqueous | `Fe$+2:1 L3:2` | Fe | aqueous | `[Fe(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) diammine. | Distinct Fe(II) diammine. |
| aqueous | `Fe$+2:1 L3:3` | Fe | aqueous | `[Fe(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) triammine. | Distinct Fe(II) triammine. |
| aqueous | `Fe$+2:1 L3:4` | Fe | aqueous | `[Fe(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) tetraammine. | Distinct Fe(II) tetraammine. |
| aqueous | `Fe$+2:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(II) monochloro. | Distinct Fe(II) monochloro. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. | Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. | Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. | Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. | Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. | Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. | Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. | Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. | Distinct Fe(III) tetrahydroxo anion. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Citr)]` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) citrate. | Distinct Fe(III) citrate. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | kept | true | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. | Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | kept | true | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. | Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]+` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(III) citrate. | Distinct protonated Fe(III) citrate. |
| aqueous | `Fe$+3:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) mono-glycinate. | Distinct Fe(III) mono-glycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | Fe | aqueous | `[Fe(Glyc)H]3+` | SRD-46 | kept | true | generation 1: kept — Distinct protonated Fe(III) glycinate. | Distinct protonated Fe(III) glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | Fe | aqueous | `[Fe(Glyc)2H2]3+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) bis-glycinate diprotonated. | Distinct Fe(III) bis-glycinate diprotonated. |
| aqueous | `Fe$+3:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]2+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) monochloro. | Distinct Fe(III) monochloro. |
| aqueous | `Fe$+3:1 L4:2` | Fe | aqueous | `[Fe(Chlo)2]+` | SRD-46 | kept | true | generation 1: kept — Distinct Fe(III) dichloro. | Distinct Fe(III) dichloro. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Distinct trinuclear Fe(III) hydroxo cluster. | Distinct trinuclear Fe(III) hydroxo cluster. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate(VI) is the required high-E Fe species. | Ferrate(VI) is the required high-E Fe species. |
| aqueous | `L1:1` | — | — | `[Citric acid]` | SRD-46 | kept | true | generation 1: kept — Fully deprotonated citrate ligand. | Fully deprotonated citrate ligand. |
| aqueous | `L1:1 H:1` | — | — | `[HCitric acid]2-` | SRD-46 | kept | true | generation 1: kept — Monoprotonated citrate. | Monoprotonated citrate. |
| aqueous | `L1:1 H:2` | — | — | `[H2Citric acid]-` | SRD-46 | kept | true | generation 1: kept — Diprotonated citrate. | Diprotonated citrate. |
| aqueous | `L1:1 H:3` | — | — | `[H3Citric acid]` | SRD-46 | kept | true | generation 1: kept — Fully protonated citric acid. | Fully protonated citric acid. |
| aqueous | `L2:1` | — | — | `[Glycine]` | SRD-46 | kept | true | generation 1: kept — Glycinate anion. | Glycinate anion. |
| aqueous | `L2:1 H:1` | — | — | `[HGlycine]` | SRD-46 | kept | true | generation 1: kept — Neutral glycine. | Neutral glycine. |
| aqueous | `L2:1 H:2` | — | — | `[H2Glycine]+` | SRD-46 | kept | true | generation 1: kept — Protonated glycinium cation. | Protonated glycinium cation. |
| aqueous | `L3:1` | — | — | `[Ammonia]` | SRD-46 | kept | true | generation 1: kept — Neutral ammonia. | Neutral ammonia. |
| aqueous | `L3:1 H:1` | — | — | `[HAmmonia]+` | SRD-46 | kept | true | generation 1: kept — Ammonium cation. | Ammonium cation. |
| aqueous | `L4:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Chloride ion. | Chloride ion. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Elemental Cu required for low-E stability. | Elemental Cu required for low-E stability. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). | Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). | Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| solid | `Cu$+1:1 L4:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — CuCl(s) nantokite is in scope at 0.1 M Cl. | CuCl(s) nantokite is in scope at 0.1 M Cl. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe required for low-E stability. | Elemental Fe required for low-E stability. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Fe3O4 magnetite retained as distinct mixed-valence solid. | Fe3O4 magnetite retained as distinct mixed-valence solid. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. | Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. | Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |


## Assistant
<summary>Reviewed the deduplicated table. All Atlas/SRD-46 identical-composition duplicates for Cu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) and Fe (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), [HFeO2]-/[Fe(OH)3]-) were collapsed to SRD-46. Ferric oxyhydroxide polymorph set collapsed to lowest-mu (Fe2O3)0.5 SRD-46. All distinct ligand/hydroxo/polynuclear stoichiometries, both redox tiers, elemental Cu/Fe, Cu2O, CuO, Cu(OH)2, CuCl(s), Fe3O4, and [FeO4]2- retained. Consistent with committed plan.</summary>
<tool_call>commit_final(summary="Dedup complete. Atlas/SRD-4…")</tool_call>

## User
<tool_result>
ERROR: invalid JSON: JSONDecodeError('Expecting value: line 1 column 1 (char 0)')
</tool_result>

## Assistant
<summary>Retrying commit_final with valid JSON payload.</summary>
<tool_call>commit_final(json_payload='{"summary": "Deduplication …')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<summary>Final commit accepted.</summary>

<answer>
Deduplication finalized. Atlas/SRD-46 duplicates of identical composition and charge collapsed to SRD-46 twins for Cu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) and Fe (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), and [HFeO2]-/[Fe(OH)3]- as the same Fe(III) anion). The ferric oxyhydroxide polymorph set (Atlas Fe2O3, Atlas Fe(OH)3, SRD-46 Fe(OH)3, SRD-46 FeOOH-alpha) was collapsed to the single lowest-mu representative (Fe2O3)0.5 SRD-46 since this is a "which phase is stable" study. All distinct ligand complexes (citrate, glycine, ammine 1-4, chloro 1-3+dimer), hydroxo monomers/dimers/trimers, both redox tiers of each metal, elemental Cu and Fe, Cu2O, CuO(s), Cu(OH)2(s), CuCl(s) nantokite, Fe3O4 magnetite, and ferrate(VI) [FeO4]2- were retained as each occupies a distinct region of the joint Cu-Fe Pourbaix field. No Fe(III)-ammine complexes are present in the source (Fe(III) hydrolysis outcompetes NH3 binding — acceptable); Cu(I) beyond [Cu(NH3)2]+, [Cu(Chlo)n], and [Cu(Glyc)2]- is not populated — flagged but not fabricated.
</answer>

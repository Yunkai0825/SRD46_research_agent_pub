[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 duplicates of identical composition and charge to one entry (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s)), preferring SRD-46 for self-consistency with the ligand complexes, and collapse the ferric oxyhydroxide polymorph set (Fe2O3 anh Atlas, (Fe2O3)0.5 SRD-46, Fe(OH)3 hydr Atlas, Fe(OH)3(s) SRD-46, FeOOH alpha SRD-46) to the single lowest-mu representative since this diagram asks which phase is stable, not which forms kinetically. Keep every other row — all Fe(II) and Fe(III) hydroxo mono/dimer/trimer species, every citrate/glycine/ammine/chloro complex, ferrate [FeO4]2-, Fe3O4 as the distinct mixed-valence solid, and elemental Fe — because each defines a distinct region of the joint Cu-Fe Pourbaix field.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-a4c866421a8e6ab0` | aqueous | `[Fe(OH)2]+` | SRD-46 | +1 | 109.167 | 1 |
| `DEDUP-87ac17ff527aca20` | aqueous | `[Fe(OH)2]+` | Atlas | +1 | 114.976 | 1 |
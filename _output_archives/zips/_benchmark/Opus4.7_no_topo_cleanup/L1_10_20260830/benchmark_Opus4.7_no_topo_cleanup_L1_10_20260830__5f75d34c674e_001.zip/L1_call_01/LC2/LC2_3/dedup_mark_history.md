# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I) bis-glycinate complex. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Distinct Cu(I) diammine complex. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Distinct Cu(I) monochloro complex. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Distinct Cu(I) trichloro complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) dihydroxo aqueous species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Distinct HCuO2- hydroxo species. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Distinct CuO2 2- hydroxo species. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Distinct dinuclear Cu(II) citrate complex. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Distinct hydroxo-dinuclear Cu(II) citrate. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Cu(II) citrate. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) mono-glycinate. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Cu(II) bis-glycinate. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) monoammine. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) diammine. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) triammine. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) tetraammine. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) monochloro. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Distinct dinuclear Cu(II) citrate-hydroxo. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Distinct dinuclear Cu2Citr2(OH) complex. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Distinct trinuclear Cu(II) hydroxo cluster. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu required for low-E stability. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) nantokite is in scope at 0.1 M Cl. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) monohydroxo. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Distinct Fe(II) dihydroxo. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Distinct Fe(II) tetrahydroxo anion. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Distinct Fe(II) citrate. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Distinct dinuclear Fe(II) citrate-hydroxo. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Fe(II) citrate. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Distinct diprotonated Fe(II) citrate. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Distinct Fe(II) bis-citrate protonated. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) mono-glycinate. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Fe(II) bis-glycinate. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Distinct Fe(II) tris-glycinate. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) monoammine. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) diammine. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) triammine. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) tetraammine. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) monochloro. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Distinct Fe(III) tetrahydroxo anion. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Distinct Fe(III) citrate. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III) citrate. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III) mono-glycinate. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III) glycinate. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Distinct Fe(III) bis-glycinate diprotonated. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III) monochloro. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Distinct Fe(III) dichloro. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Distinct trinuclear Fe(III) hydroxo cluster. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate(VI) is the required high-E Fe species. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe required for low-E stability. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Fe3O4 magnetite retained as distinct mixed-valence solid. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/proton reference entry, retain. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Neutral ammonia. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate ligand. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Diprotonated citrate. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium cation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Fully protonated citric acid. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium cation. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Monoprotonated citrate. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine. |

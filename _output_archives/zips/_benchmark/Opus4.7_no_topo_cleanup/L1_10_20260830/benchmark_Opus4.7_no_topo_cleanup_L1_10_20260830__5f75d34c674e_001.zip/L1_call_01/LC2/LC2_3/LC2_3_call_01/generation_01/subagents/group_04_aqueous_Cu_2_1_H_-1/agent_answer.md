Kept both species — they are distinct nuclearities (monomer vs dimer) occupying different regions of the Cu(II) hydrolysis diagram:
- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    307.55
- elapsed_s (total):  307.55
- llm_iterations:     60
- llm_tool_calls:     45

- n_groups:           75
- n_multi_groups:     14
- n_singletons:       61
- n_decisions:        75
- n_dropped:          15
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Distinct nuclearity and charge (dimer -2 vs monomer -1); both retained per plan. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct nuclearity/charge (monomer vs dimer); both retained per rule 2. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Monomer and dimer are distinct nuclearities/charges; both retained per case-specific guidance to preserve all polynuclear ferric-citrate stoichiometries. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46] | Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/proton reference entry, retain. |
| aqueous | `Cu$+1:1 L2:2` | yes | Distinct Cu(I) bis-glycinate complex. |
| aqueous | `Cu$+1:1 L3:2` | yes | Distinct Cu(I) diammine complex. |
| aqueous | `Cu$+1:1 L4:1` | yes | Distinct Cu(I) monochloro complex. |
| aqueous | `Cu$+1:1 L4:3` | yes | Distinct Cu(I) trichloro complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) dihydroxo aqueous species. |
| aqueous | `Cu$+2:1 H:-3` | yes | Distinct HCuO2- hydroxo species. |
| aqueous | `Cu$+2:1 H:-4` | yes | Distinct CuO2 2- hydroxo species. |
| aqueous | `Cu$+2:1 L1:1` | yes | Distinct dinuclear Cu(II) citrate complex. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Distinct hydroxo-dinuclear Cu(II) citrate. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Distinct protonated Cu(II) citrate. |
| aqueous | `Cu$+2:1 L2:1` | yes | Distinct Cu(II) mono-glycinate. |
| aqueous | `Cu$+2:1 L2:2` | yes | Distinct Cu(II) bis-glycinate. |
| aqueous | `Cu$+2:1 L3:1` | yes | Distinct Cu(II) monoammine. |
| aqueous | `Cu$+2:1 L3:2` | yes | Distinct Cu(II) diammine. |
| aqueous | `Cu$+2:1 L3:3` | yes | Distinct Cu(II) triammine. |
| aqueous | `Cu$+2:1 L3:4` | yes | Distinct Cu(II) tetraammine. |
| aqueous | `Cu$+2:1 L4:1` | yes | Distinct Cu(II) monochloro. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Distinct dinuclear Cu(II) citrate-hydroxo. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Distinct dinuclear Cu2Citr2(OH) complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Distinct trinuclear Cu(II) hydroxo cluster. |
| aqueous | `Fe$+2:1 H:-1` | yes | Distinct Fe(II) monohydroxo. |
| aqueous | `Fe$+2:1 H:-2` | yes | Distinct Fe(II) dihydroxo. |
| aqueous | `Fe$+2:1 H:-4` | yes | Distinct Fe(II) tetrahydroxo anion. |
| aqueous | `Fe$+2:1 L1:1` | yes | Distinct Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Distinct dinuclear Fe(II) citrate-hydroxo. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Distinct protonated Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Distinct diprotonated Fe(II) citrate. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Distinct Fe(II) bis-citrate protonated. |
| aqueous | `Fe$+2:1 L2:1` | yes | Distinct Fe(II) mono-glycinate. |
| aqueous | `Fe$+2:1 L2:2` | yes | Distinct Fe(II) bis-glycinate. |
| aqueous | `Fe$+2:1 L2:3` | yes | Distinct Fe(II) tris-glycinate. |
| aqueous | `Fe$+2:1 L3:1` | yes | Distinct Fe(II) monoammine. |
| aqueous | `Fe$+2:1 L3:2` | yes | Distinct Fe(II) diammine. |
| aqueous | `Fe$+2:1 L3:3` | yes | Distinct Fe(II) triammine. |
| aqueous | `Fe$+2:1 L3:4` | yes | Distinct Fe(II) tetraammine. |
| aqueous | `Fe$+2:1 L4:1` | yes | Distinct Fe(II) monochloro. |
| aqueous | `Fe$+3:1 H:-4` | yes | Distinct Fe(III) tetrahydroxo anion. |
| aqueous | `Fe$+3:1 L1:1` | yes | Distinct Fe(III) citrate. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Distinct protonated Fe(III) citrate. |
| aqueous | `Fe$+3:1 L2:1` | yes | Distinct Fe(III) mono-glycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Distinct protonated Fe(III) glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Distinct Fe(III) bis-glycinate diprotonated. |
| aqueous | `Fe$+3:1 L4:1` | yes | Distinct Fe(III) monochloro. |
| aqueous | `Fe$+3:1 L4:2` | yes | Distinct Fe(III) dichloro. |
| aqueous | `Fe$+3:3 H:-4` | yes | Distinct trinuclear Fe(III) hydroxo cluster. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate(VI) is the required high-E Fe species. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate ligand. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated citrate. |
| aqueous | `L1:1 H:2` | yes | Diprotonated citrate. |
| aqueous | `L1:1 H:3` | yes | Fully protonated citric acid. |
| aqueous | `L2:1` | yes | Glycinate anion. |
| aqueous | `L2:1 H:1` | yes | Neutral glycine. |
| aqueous | `L2:1 H:2` | yes | Protonated glycinium cation. |
| aqueous | `L3:1` | yes | Neutral ammonia. |
| aqueous | `L3:1 H:1` | yes | Ammonium cation. |
| aqueous | `L4:1` | yes | Chloride ion. |
| solid | `Cu$+0:1` | yes | Elemental Cu required for low-E stability. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) nantokite is in scope at 0.1 M Cl. |
| solid | `Fe$+0:1` | yes | Elemental Fe required for low-E stability. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Fe3O4 magnetite retained as distinct mixed-valence solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Identical Cu+ monocation from Atlas and SRD-46 with equal mu; keep SRD-46 for self-consistency with SRD-46-sourced ligand complexes. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical Cu2+ aqueous species; retain SRD-46 twin for self-consistency with SRD-46-sourced ligand complexes. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Identical Fe2+ aqueous ion; kept SRD-46 for self-consistency with ligand complexes per element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [Fe(OH)3]- (SRD-46) and [HFeO2]- (Atlas) are the same Fe(III) species (identical composition, charge -1); keep SRD-46 for self-consistency and lower mu. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 duplicate of Fe3+ (identical charge and mu); prefer SRD-46 for consistency with ligand complex source. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 duplicate of [Fe(OH)]2+ to SRD-46 for consistency; kept dimer [Fe2(OH)2]4+ as distinct nuclearity/charge. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Duplicate aqueous [Fe(OH)2]+; keep SRD-46 for self-consistency with ligand complexes and it has the lower mu_aligned. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Collapse Atlas/SRD-46 Cu2O duplicates to SRD-46 for dataset consistency (also lower mu_aligned). |
| `CuO` | Atlas | dissolution | LC2 element review: Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Collapsed Atlas duplicates into SRD-46 twins (mu within ~3 kJ/mol) to keep one self-consistent dataset; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct phases. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas and SRD-46 Fe(OH)2(s) are the same phase; keep SRD-46 for consistency with ligand complex source. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Collapsed ferric oxyhydroxide polymorph set to single lowest-mu representative per case-specific recommendation; (Fe2O3)0.5 SRD-46 at 70.354 kJ/mol is lowest. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 18d9141cb5b64d128bae2e174e0bc822
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication is consistent with the committed plan. Atlas/SRD-46 identical-composition duplicates were collapsed to SRD-46 for self-consistency with the SRD-46-sourced ligand complexes: Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 on the Cu side; Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), and the Atlas [HFeO2]- / SRD-46 [Fe(OH)3]- pair on the Fe side. The ferric oxyhydroxide polymorph set (Atlas Fe2O3, Atlas Fe(OH)3, SRD-46 [Fe(OH)3](s), SRD-46 FeOOH-alpha) was collapsed to the single lowest-mu representative (SRD-46 (Fe2O3)0.5, +70.354 kJ/mol) per the 'which phase is stable' framing. All distinct hydroxo/citrate/glycinate/ammine/chloro complexes at every nuclearity and protonation state are retained on both metals, both redox tiers are preserved, and elemental Cu/Fe, Cu2O, CuO, Cu(OH)2, CuCl(s) nantokite, mixed-valence Fe3O4, and ferrate [FeO4]2- all remain as required for the joint Cu-Fe Pourbaix field.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 duplicates of identical composition and charge to a single entry, preferring SRD-46 when the ligand-complex chemistry is SRD-46-sourced so the diagram uses one self-consistent dataset (drop Atlas Cu+, Cu2+, CuO, Cu(OH)2, Cu2O in favor of their SRD-46 twins where mu agrees within a few kJ/mol; otherwise keep the lower-mu representative). Keep every other row — all Cu(I) and Cu(II) hydroxo monomers/dimers/trimer, every ammine (1–4), every chloro (1–3 plus dimer), every citrate/glycine complex, elemental Cu, Cu2O, CuO or Cu(OH)2 (one of each), and CuCl(s) — because each occupies a distinct pH/E/ligand-activity region of the joint diagram.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier |
|-----------|--------|------|--------|-------:|--------------:|-----------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 |
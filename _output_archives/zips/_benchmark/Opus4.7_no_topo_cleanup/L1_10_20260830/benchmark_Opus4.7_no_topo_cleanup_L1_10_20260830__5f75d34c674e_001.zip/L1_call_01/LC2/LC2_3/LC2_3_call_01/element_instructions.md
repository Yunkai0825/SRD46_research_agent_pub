# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: joint Cu(II)+Fe(III) speciation/Pourbaix in one pot with excess citrate, glycine, ammonia, chloride at 25 C, I=0.1 m; not a corrosion 1e-6 M convention — metals are at 1 mM, ligands 10 mM (citrate, glycine, ammonia) and 0.1 M (chloride, ammonia). Retain the full ligand family and hydroxo family, all charge states, and both redox tiers of each metal.
- **Aqueous protonation/polynuclear**: keep every distinct stoichiometry (monomer vs dimer/trimer, protonated vs deprotonated citrate complexes, mono- through tetra-ammine, mono- through tri/tetra-chloro, mono/bis/tris glycine) — each competes in a distinct pH/ligand-activity window and can dominate a region. Only collapse when two rows are literally the same formula and charge from Atlas vs SRD-46.
- **Duplicates to collapse**: Atlas/SRD-46 pairs of identical composition and charge (e.g., Cu+, Cu2+, Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Cu2O, CuO, Cu(OH)2, Fe(OH)2(s)). Prefer the lower mu_aligned representative when close; if the gap exceeds ~5 kJ/mol keep the more internally consistent SRD-46 datum (matches the ligand complex source) to keep the diagram self-consistent.
- **Solids question**: this is a 'which phase is STABLE' study — collapse ferric oxyhydroxide polymorphs to the single lowest-mu representative (Fe2O3 alpha / FeOOH / Fe(OH)3 amorphous cover the same corner). Keep Fe3O4 as the distinct mixed-valence solid, keep elemental Fe and Cu, keep Cu2O and CuO/Cu(OH)2 pair (collapse CuO vs Cu(OH)2 only if same source and same mu; here retain one anhydrous CuO and one hydrated Cu(OH)2 since they can appear in different humidity/pH regimes — but drop the duplicate spelling within each).
- **Chloride solid**: CuCl(s) (nantokite) is in scope at 0.1 M Cl and reducing E; keep it.
- **Carbonates/other counterions**: none present in this pot; N/A.
- **Gases**: only H2O/H+/e-; no gaseous species listed and none needed as decorative.
- **Divergence**: Cu and Fe treated the same way — collapse Atlas vs SRD-46 duplicates, keep every distinct ligand/hydroxo/polynuclear stoichiometry, collapse ferric-oxide polymorphs on Fe side only.
- **Missing species flag**: no Fe(III)-ammine complexes are listed (Fe(III) hydrolyzes faster than it binds NH3 — acceptable omission); no Cu(I)-citrate or Cu(I)-glycine or Cu(I)-ammine beyond [Cu(NH3)2]+ listed — flag but do not fabricate.

## Element instructions

- **Cu**: Collapse Atlas/SRD-46 duplicates of identical composition and charge to a single entry, preferring SRD-46 when the ligand-complex chemistry is SRD-46-sourced so the diagram uses one self-consistent dataset (drop Atlas Cu+, Cu2+, CuO, Cu(OH)2, Cu2O in favor of their SRD-46 twins where mu agrees within a few kJ/mol; otherwise keep the lower-mu representative). Keep every other row — all Cu(I) and Cu(II) hydroxo monomers/dimers/trimer, every ammine (1–4), every chloro (1–3 plus dimer), every citrate/glycine complex, elemental Cu, Cu2O, CuO or Cu(OH)2 (one of each), and CuCl(s) — because each occupies a distinct pH/E/ligand-activity region of the joint diagram.
- **Fe**: Collapse Atlas/SRD-46 duplicates of identical composition and charge to one entry (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s)), preferring SRD-46 for self-consistency with the ligand complexes, and collapse the ferric oxyhydroxide polymorph set (Fe2O3 anh Atlas, (Fe2O3)0.5 SRD-46, Fe(OH)3 hydr Atlas, Fe(OH)3(s) SRD-46, FeOOH alpha SRD-46) to the single lowest-mu representative since this diagram asks which phase is stable, not which forms kinetically. Keep every other row — all Fe(II) and Fe(III) hydroxo mono/dimer/trimer species, every citrate/glycine/ammine/chloro complex, ferrate [FeO4]2-, Fe3O4 as the distinct mixed-valence solid, and elemental Fe — because each defines a distinct region of the joint Cu-Fe Pourbaix field.

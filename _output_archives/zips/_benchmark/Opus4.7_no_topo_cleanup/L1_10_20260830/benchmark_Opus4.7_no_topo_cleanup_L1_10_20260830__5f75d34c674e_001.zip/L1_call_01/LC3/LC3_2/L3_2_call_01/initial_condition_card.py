inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m from task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "1 mM Cu(II) input; element total for redox axis"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 1e-3,   "basis": "known", "note": "1 mM Fe(III) input; element total for redox axis"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2, "basis": "known", "note": "10 mM citrate from task"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM glycine from task"},
  {"id": "Cl",  "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M chloride from task"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M ammonia from task"},
]
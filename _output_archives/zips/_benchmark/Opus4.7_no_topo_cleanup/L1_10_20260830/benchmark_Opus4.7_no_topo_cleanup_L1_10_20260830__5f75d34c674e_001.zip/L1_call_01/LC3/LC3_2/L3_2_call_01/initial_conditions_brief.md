# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m from task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) input; element total for redox axis
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) input; element total for redox axis
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # 10 mM citrate from task
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # 10 mM glycine from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M ammonia from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis of Pourbaix diagram, 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_SHE axis of Pourbaix diagram, -1.0 to +1.5 V'},
]

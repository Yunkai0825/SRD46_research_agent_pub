# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.95
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-E predominance diagram over pH and E axes.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Diagnostics\analysis_agent\L1_10_CuFe_cit_gly_Cl_NH3_pourbaix\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# Eq-map screen — m61_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10163_beta840_net29854` | `[M] + [L]^2 <=> [ML2]` | vlm_177402@(25.0,0.0) = K+2.130 | 2 | +0.750 / +1.440 / +1.440 / +2.130 | vlm_177402@(25.0,0.0) = K+2.130 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal61_ligand10163_beta812_net29854` | `[M] + [L] <=> [ML]` | vlm_177390@(25.0,0.1) = K+0.780 | 7 | +0.630 / +0.780 / +0.861 / +1.480 | vlm_177390@(25.0,0.1) = K+0.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

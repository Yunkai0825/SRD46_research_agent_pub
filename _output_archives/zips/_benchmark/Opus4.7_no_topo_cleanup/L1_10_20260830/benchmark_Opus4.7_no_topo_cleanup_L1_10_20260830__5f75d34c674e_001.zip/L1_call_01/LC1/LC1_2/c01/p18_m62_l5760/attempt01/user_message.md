[Purpose: Compute the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II) and Fe(III) with citrate, glycine, chloride, and ammonia, and characterize how the two metals partition among aqueous complexes and solids across the field.]
[Tasks:
Model a single pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V_SHE at reasonable resolution (about 71 x 51 grid). Report the topology: list every connected region with its dominant Cu-bearing and Fe-bearing species (aqueous complexes with citrate, glycine, ammonia, chloride, hydroxide as well as any predicted solids or metals), the pH/E extent of each region, the principal boundary segments and their triple-point junctions, and note which boundaries are redox-controlled versus pH/ligand-controlled. Cite the equilibrium constants and standard potentials the solver actually used for the reactions defining the major boundaries, and describe qualitatively how Cu and Fe partition between citrate, glycine, ammonia, chloride, hydroxide, and reduced/solid phases across the diagram.
]
[Pair: pair_key=`m62_l5760`, metal_id=62, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal62_ligand5760_beta812_net64`
  - `metal62_ligand5760_beta840_net64`
[Warn nodes]
  - `metal62_ligand5760_beta872_net64`
[Screen report]
# Eq-map screen — m62_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 2, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand5760_beta872_net64` | `[M] + [L]^3 <=> [ML3]` | vlm_93760@(25.0,1.0) = K+8.870 | 1 | +8.870 / +8.870 / +8.870 / +8.870 | vlm_93760@(25.0,1.0) = K+8.870 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal62_ligand5760_beta812_net64` | `[M] + [L] <=> [ML]` | vlm_93749@(25.0,1.0) = K+3.730 | 7 | -4.130 / +4.200 / +2.940 / +4.360 | vlm_93747@(25.0,0.1) = K-4.130 (+0.00 °C, +0.00 M) | `sibling_sign_split, mad_outlier, mean_median_gap, nearest_request_sign_mismatch` |
| 3 | `metal62_ligand5760_beta840_net64` | `[M] + [L]^2 <=> [ML2]` | vlm_93759@(25.0,1.0) = K+6.650 | 2 | -7.650 / -0.500 / -0.500 / +6.650 | vlm_93758@(25.0,0.1) = K-7.650 (+0.00 °C, +0.00 M) | `mad_outlier, nearest_request_sign_mismatch` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

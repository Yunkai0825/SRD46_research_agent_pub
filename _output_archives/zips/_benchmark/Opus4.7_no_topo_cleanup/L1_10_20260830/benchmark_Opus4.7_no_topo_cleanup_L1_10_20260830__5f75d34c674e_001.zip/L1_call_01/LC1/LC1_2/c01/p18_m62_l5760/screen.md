# Eq-map screen — m62_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 2, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand5760_beta872_net64` | `[M] + [L]^3 <=> [ML3]` | vlm_93760@(25.0,1.0) = K+8.870 | 1 | +8.870 / +8.870 / +8.870 / +8.870 | vlm_93760@(25.0,1.0) = K+8.870 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal62_ligand5760_beta812_net64` | `[M] + [L] <=> [ML]` | vlm_93749@(25.0,1.0) = K+3.730 | 7 | -4.130 / +4.200 / +2.940 / +4.360 | vlm_93747@(25.0,0.1) = K-4.130 (+0.00 °C, +0.00 M) | `sibling_sign_split, mad_outlier, mean_median_gap, nearest_request_sign_mismatch` |
| 3 | `metal62_ligand5760_beta840_net64` | `[M] + [L]^2 <=> [ML2]` | vlm_93759@(25.0,1.0) = K+6.650 | 2 | -7.650 / -0.500 / -0.500 / +6.650 | vlm_93758@(25.0,0.1) = K-7.650 (+0.00 °C, +0.00 M) | `mad_outlier, nearest_request_sign_mismatch` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

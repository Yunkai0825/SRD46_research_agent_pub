[Purpose: Compute the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II) and Fe(III) with citrate, glycine, chloride, and ammonia, and characterize how the two metals partition among aqueous complexes and solids across the field.]
[Tasks:
Model a single pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V_SHE at reasonable resolution (about 71 x 51 grid). Report the topology: list every connected region with its dominant Cu-bearing and Fe-bearing species (aqueous complexes with citrate, glycine, ammonia, chloride, hydroxide as well as any predicted solids or metals), the pH/E extent of each region, the principal boundary segments and their triple-point junctions, and note which boundaries are redox-controlled versus pH/ligand-controlled. Cite the equilibrium constants and standard potentials the solver actually used for the reactions defining the major boundaries, and describe qualitatively how Cu and Fe partition between citrate, glycine, ammonia, chloride, hydroxide, and reduced/solid phases across the diagram.
]
[Pair: pair_key=`m61_l10163`, metal_id=61, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10163_beta840_net29854`
[Screen report]
# Eq-map screen — m61_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10163_beta840_net29854` | `[M] + [L]^2 <=> [ML2]` | vlm_177402@(25.0,0.0) = K+2.130 | 2 | +0.750 / +1.440 / +1.440 / +2.130 | vlm_177402@(25.0,0.0) = K+2.130 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal61_ligand10163_beta812_net29854` | `[M] + [L] <=> [ML]` | vlm_177390@(25.0,0.1) = K+0.780 | 7 | +0.630 / +0.780 / +0.861 / +1.480 | vlm_177390@(25.0,0.1) = K+0.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

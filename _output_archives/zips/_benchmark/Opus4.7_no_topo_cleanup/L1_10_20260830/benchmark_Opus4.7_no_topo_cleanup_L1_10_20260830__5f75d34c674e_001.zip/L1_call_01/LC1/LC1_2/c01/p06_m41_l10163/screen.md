# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta812_net29839` | `[M] + [L] <=> [ML]` | vlm_177370@(25.0,0.0) = K+0.200 | 9 | -0.200 / +0.000 / +0.006 / +0.270 | vlm_177370@(25.0,0.0) = K+0.200 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

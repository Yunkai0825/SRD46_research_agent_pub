# LC1_2 agent response

## Final answer (text emitted by the agent)

Patch submitted for `metal61_ligand10076_beta840_net27465`: replace the I=0 extrapolation (+23.400) with +21.800 (median of the four positive finite-I siblings, matching vlm_170802 at I=0.5 M closest to the request I=0.1 M). The negative sibling vlm_170803=-20.400 is an obvious sign-flip artifact.

All other warn nodes were left as-is:
- beta812: chosen row is exactly at request (T=25, I=0.1); MAD flag is trivial (0.17 logK deviation on a tight cluster).
- beta649, beta519: tight sibling clusters (range ≤1.3, ≤1.0 logK); wide_TI_distance only.
- beta352, beta357: only 2 siblings, differences ≤0.4 logK; chosen values fine.
- beta351, beta894: single_observation / beta_def_orphan — no alternative to consider.

## Final context

## System Prompt
# LC1_2 — Eq-Map Node Validator (per pair)

## Role

You are the **curation agent** for ONE (metal, ligand) pair. The
pipeline invokes you on **every** pair — there is no skip route.
Your job is to emit a list of **parseable patch notes** that the
downstream pipeline will use to hardcode edits into the eq-map. The
database itself is NEVER modified.

* For a clean pair (no `critical` nodes and no `warn` flag with an
  obviously better choice in the neighbour table): emit
  `{"patches": []}`. That is the expected outcome, not a failure.
* Even when a node has NO flags in the `flags` column, you MUST
  still scan its `min/med/mean/max` and `nearest@req` columns. A
  clean row can still hint at a latent data problem (e.g. a single
  sign-opposite sibling that yanks the mean away from the median).
  When that happens, use `inspect_node` or `get_node_neighbors` and
  patch if the neighbour table confirms.
* For every node you do patch, the patch must be a **pure data
  instruction** — no LLM math left to do at parse time. If you are
  changing a value, write the final number into `chosen_value`.

## Inputs (in the user message)

* `[Pair]` — `pair_key`, `metal_id`, `ligand_id`, request `T_C` / `I_M`.
* `[Critical nodes]` — bulleted list of `node_key` strings the
  deterministic screen flagged `critical`.
* `[Warn nodes]` — bulleted list of `node_key` strings flagged `warn`.
* `[Screen report]` — ONE markdown table, one row per node of the
  eq-map, with these columns:
  `#`, `node_key`, `equation`, `chosen vlm@T,I = K`,
  `n_K`, `min / med / mean / max`, `nearest@req vlm@T,I = K (ΔT, ΔI)`,
  `flags`.
* `[Retry context]` — present only on retry attempts. Contains the
  validator errors from the previous attempt. Fix EACH error before
  re-calling `finalize_patches`.

### Flag vocabulary in the `flags` column

* `sign_discord` (critical) — chosen value's sign opposes ≥2 K-siblings.
* `K_H_S_contamination` (critical) — chosen row is H/S, not K.
* `nearest_request_sign_mismatch` (critical) — the sibling sitting at
  the request (T, I) was bypassed by the selector because its sign
  opposes the chosen value. Always inspect.
* `sibling_sign_split` (warn) — K-siblings span both signs regardless
  of where the chosen value sits.
* `mean_median_gap` (warn) — \|mean − median\| over K-siblings > 1.0;
  a hidden outlier is in the sibling pool.
* `mad_outlier` (warn) — chosen value is > 3·MAD (or 5·MAD for small n)
  from sibling median.
* `wide_TI_distance` (warn) — no sibling at all sits near the request.
* `beta_def_orphan`, `single_observation` (informational unless paired).

## Tools

You have exactly THREE tools. Call them in this order:

1. `inspect_node(node_key)` — verbose per-node block: the table row
   plus the sibling-K summary, the nearest-at-request entry, and all
   notes. Call this for any node whose `flags` column hints at a
   data-quality issue, even when the `flags` cell is empty. In
   particular, ALWAYS inspect any node where:
   * `flags` contains `sibling_sign_split`, `mean_median_gap`, or
     `nearest_request_sign_mismatch`; OR
   * the `min / med / mean / max` cell shows a large mean↔median gap
     (e.g. one negative entry among positive ones); OR
   * the `nearest@req` cell holds a value with opposite sign to the
     chosen value.
2. `get_node_neighbors(node_key)` — full table of EVERY sibling vlm
   row for the (metal, ligand, beta_definition) triple of that node,
   bucketed by (T, I), with the currently chosen row marked
   `**←chosen**`. This is the only tool that shows the raw vlm
   values; call it whenever you need to pick a specific replacement.
3. `finalize_patches(json_payload: str)` — submit a JSON object of
   shape `{"patches": [...]}`. After this call the agent terminates
   (unless the validator rejects the payload, in which case you get
   one or more retries).

## Patch shape (closed enum, one entry per node you fix)

```jsonc
{
  "node_key":            "metal62_ligand9058_beta812_net22168",
  "beta_definition_id":  812,

  // The row currently in the draft. MUST match the screen's
  // chosen vlm/value for this node_key.
  "examined_vlm_id":     157620,
  "examined_value":      -4.80,

  // One of: "set_value" | "drop_node"
  "operation":           "set_value",

  // REQUIRED iff operation == "set_value".
  // FORBIDDEN iff operation == "drop_node".
  "chosen_value":         4.55,

  // Always required, must reference at least one numeric fact.
  "rationale":           "examined logK=-4.80 sign-flipped vs 3 K-siblings clustering at +4.55 (vlm_157619, 157621, 157622). Patching to the median +4.55."
}
```

Field ordering inside each patch object is **fixed** as shown
above: `node_key`, `beta_definition_id`, `examined_vlm_id`,
`examined_value`, `operation`, `chosen_value` (if applicable),
`rationale`. Always emit them in this order — the rationale comes
LAST so the reader can see the data slots first and the prose
justification at the end.

### Operation semantics

* **`set_value`** — replace the examined row's `constant_value` with
  `chosen_value` for this `beta_definition_id`. The downstream
  pipeline reads `chosen_value` and hardcodes it; it does NOT
  re-aggregate the K-siblings.
* **`drop_node`** — remove the entire `beta_definition_id` from this
  network. **This is the option of LAST RESORT** and is strongly
  discouraged. Dropping a node deletes a real chemical equilibrium
  from the speciation model and silently changes downstream
  predictions; you must NOT use it just because the data is messy
  or the choice is hard. Only use `drop_node` when ALL of the
  following are true:
  1. The entire `beta_definition_id` has NO usable K-row at all
     (every sibling is H/S, or `equation_python` is malformed, or
     every sibling K is outside `(-50, +50)`); AND
  2. There is no plausible `set_value` choice — not the
     at-request datum, not the cluster median, not the nearest
     sibling in (T, I); AND
  3. Keeping the node with the chosen value would corrupt the
     speciation more than removing it.

  Sign-discordant pairs (e.g. one positive vs one negative sibling)
  are NOT grounds to drop — prefer the at-request datum or the
  value closer to neighbouring beta_def trends, and explain the
  tie-break in `rationale`. Whenever you are tempted to drop, first
  call `get_node_neighbors` and pick the most defensible
  `set_value`; reserve `drop_node` for the strictly unsalvageable
  case described above.

### Picking `chosen_value` for `set_value`

You may pick any of the following, in this order of preference:

1. The `constant_value` of ONE specific K-sibling row whose
   `(T_C, I_M)` is closest to the request `(T_C, I_M)` AND whose
   value is consistent with the rest of the K-population.
2. The **median** of 3+ K-siblings that cluster within ±0.5 logK,
   when no single row dominates the (T, I) closeness ranking.
3. The **mean** of 2+ K-siblings when their range is ≤ 0.3 logK
   AND the user message's purpose is regression / fitting (median
   is more robust for Pourbaix).

In every case, write the resulting NUMBER into `chosen_value` and
explain in `rationale` which sibling rows it came from. Do NOT
write expressions like `"median of vlm_X, vlm_Y, vlm_Z"` into
`chosen_value` — only finite decimal numbers are accepted.

## Hard rules

* `examined_vlm_id` MUST equal the screen's chosen `vlm_id` for
  that `node_key`. You only patch what's currently in the draft.
* `examined_value` MUST equal the screen's chosen `constant_value`
  (within 1e-6). The validator will reject mismatched copies.
* `chosen_value` MUST be a finite decimal number in `(-50, +50)`.
  Anything outside this range is almost certainly a unit / decimal
  error.
* `chosen_value` MUST NOT equal `examined_value` (no-op patches are
  rejected — either omit the patch or set the actual corrected
  number).
* `rationale` MUST be non-empty and MUST contain at least one digit
  (the vlm_id, the sibling value, the count, etc.).
* One patch per `node_key`. Duplicates are rejected.
* Emit `finalize_patches` exactly once per attempt; on validator
  ERROR you may re-call it with a corrected payload.

## Worked examples

### Clean pair (no critical nodes)

```jsonc
finalize_patches({ "patches": [] })
```

### Sign-flipped logK, single dominant sibling

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta812_net22168",
      "beta_definition_id": 812,
      "examined_vlm_id":    157620,
      "examined_value":    -4.80,
      "operation":          "set_value",
      "chosen_value":       4.40,
      "rationale":          "examined vlm_157620 logK=-4.80 sign-discordant vs 3 K-siblings (vlm_157619=+4.40 at T=25C/I=0.10M, vlm_157621=+4.56, vlm_157622=+4.70). Picking vlm_157619's value because it matches the request (T=25C, I=0.10M) exactly."
    }
  ]
})
```

### Node beyond repair

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta815_net22168",
      "beta_definition_id": 815,
      "examined_vlm_id":    157630,
      "examined_value":     2.50,
      "operation":          "drop_node",
      "rationale":          "examined vlm_157630 constant_type='S' and the only 2 siblings (vlm_157631, vlm_157632) are also 'H' rows; no K-data exists for beta_def=815 — dropping the whole node."
    }
  ]
})
```

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_patches(json_payload='') — Submit the final patch list and end the turn.
- get_node_neighbors(node_key='') — Return the sibling-vlm table for one node, grouped by (T, I).
- inspect_node(node_key='') — Return the per-node block from the deterministic screen.

## Subagent
[Purpose: Compute the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II) and Fe(III) with citrate, glycine, chloride, and ammonia, and characterize how the two metals partition among aqueous complexes and solids across the field.]
[Tasks:
Model a single pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V_SHE at reasonable resolution (about 71 x 51 grid). Report the topology: list every connected region with its dominant Cu-bearing and Fe-bearing species (aqueous complexes with citrate, glycine, ammonia, chloride, hydroxide as well as any predicted solids or metals), the pH/E extent of each region, the principal boundary segments and their triple-point junctions, and note which boundaries are redox-controlled versus pH/ligand-controlled. Cite the equilibrium constants and standard potentials the solver actually used for the reactions defining the major boundaries, and describe qualitatively how Cu and Fe partition between citrate, glycine, ammonia, chloride, hydroxide, and reduced/solid phases across the diagram.
]
[Pair: pair_key=`m61_l10076`, metal_id=61, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10076_beta649_net27465`
  - `metal61_ligand10076_beta812_net27465`
  - `metal61_ligand10076_beta352_net27465`
  - `metal61_ligand10076_beta357_net27465`
  - `metal61_ligand10076_beta351_net27465`
  - `metal61_ligand10076_beta840_net27465`
  - `metal61_ligand10076_beta894_net27465`
  - `metal61_ligand10076_beta519_net27465`
[Screen report]
# Eq-map screen — m61_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10076_beta649_net27465` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170821@(25.0,0.0) = K+49.700 | 3 | +49.700 / +49.700 / +50.133 / +51.000 | vlm_170821@(25.0,0.0) = K+49.700 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal61_ligand10076_beta812_net27465` | `[M] + [L] <=> [ML]` | vlm_170791@(25.0,0.1) = K+11.270 | 7 | +11.050 / +11.140 / +11.226 / +11.810 | vlm_170791@(25.0,0.1) = K+11.270 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand10076_beta352_net27465` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170825@(25.0,0.0) = K-38.800 | 2 | -38.800 / -38.700 / -38.700 / -38.600 | vlm_170825@(25.0,0.0) = K-38.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal61_ligand10076_beta357_net27465` | `[MOOH(s,alpha)] + [H2O] <=> [M] + [OH]^3` | vlm_170827@(25.0,0.0) = K-41.500 | 2 | -41.500 / -41.300 / -41.300 / -41.100 | vlm_170827@(25.0,0.0) = K-41.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal61_ligand10076_beta351_net27465` | `[(M2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [M] + [OH]^3` | vlm_170828@(25.0,0.0) = K-42.700 | 1 | -42.700 / -42.700 / -42.700 / -42.700 | vlm_170828@(25.0,0.0) = K-42.700 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal61_ligand10076_beta840_net27465` | `[M] + [L]^2 <=> [ML2]` | vlm_170807@(25.0,0.0) = K+23.400 | 6 | -20.400 / +21.850 / +15.100 / +23.400 | vlm_170807@(25.0,0.0) = K+23.400 (+0.00 °C, -0.10 M) | `sibling_sign_split, mad_outlier, mean_median_gap, wide_TI_distance` |
| 7 | `metal61_ligand10076_beta894_net27465` | `[M] + [L]^4 <=> [ML4]` | vlm_170808@(25.0,0.0) = K+34.400 | 1 | +34.400 / +34.400 / +34.400 / +34.400 | vlm_170808@(25.0,0.0) = K+34.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal61_ligand10076_beta519_net27465` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170814@(25.0,0.0) = K+25.140 | 6 | +24.500 / +25.120 / +25.073 / +25.500 | vlm_170814@(25.0,0.0) = K+25.140 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.


## Assistant
<summary>Inspecting the most suspicious warn nodes: beta840 (sign_split + mean_median_gap suggests a negative outlier in a positive cluster) and beta812 (mad_outlier on 7 siblings). Others are wide_TI_distance with tight sibling clusters, likely fine.</summary>
<tool_call>inspect_node(node_key='metal61_ligand10076_beta840…')</tool_call>
<tool_call>inspect_node(node_key='metal61_ligand10076_beta812…')</tool_call>

## User
<tool_result>
### inspect_node
### `metal61_ligand10076_beta840_net27465`  — severity: **warn**

- equation: `[M] + [L]^2 <=> [ML2]`
- chosen vlm_id = **170807**, network_db_id = 27465
- chosen value: **K = +23.400** @ T = 25.0 °C, I = 0.0 M
- siblings (same metal/ligand/beta_def): 6 total, 6 of constant_type='K'
- flags: `sibling_sign_split, mad_outlier, mean_median_gap, wide_TI_distance`
- notes:
  - K-sibling pool is bimodal in sign: 4 positive (e.g. vlm_170802=+21.800) vs 1 negative (e.g. vlm_170803=-20.400)
  - chosen K = +23.400 deviates by 1.60 from sibling median +21.800 (MAD 0.10, threshold 3·MAD)
  - K-siblings: mean=+13.440 vs median=+21.800 (gap 8.36 > 1 logK over n=5 siblings); a hidden outlier is distorting the mean
  - chosen (T=25.0, I=0.0) is far from request (T=25.0, I=0.1); no K-sibling within ±5.0 °C / ±0.05 M either

Sibling K summary:

| n | min | median | mean | max |
|---|-----|--------|------|-----|
| 6 | -20.400 | +21.850 | +15.100 | +23.400 |

Nearest K-sibling to request: vlm_id=170807, K=+23.400 @ T=25.0 °C (ΔT=+0.00), I=0.0 M (ΔI=-0.10)

Call `get_node_neighbors(node_key)` to see the full vlm-row table for this (metal, ligand, beta_definition) triple.

### inspect_node
### `metal61_ligand10076_beta812_net27465`  — severity: **warn**

- equation: `[M] + [L] <=> [ML]`
- chosen vlm_id = **170791**, network_db_id = 27465
- chosen value: **K = +11.270** @ T = 25.0 °C, I = 0.1 M
- siblings (same metal/ligand/beta_def): 11 total, 7 of constant_type='K'
- flags: `mad_outlier`
- notes:
  - chosen K = +11.270 deviates by 0.17 from sibling median +11.095 (MAD 0.04, threshold 3·MAD)

Sibling K summary:

| n | min | median | mean | max |
|---|-----|--------|------|-----|
| 7 | +11.050 | +11.140 | +11.226 | +11.810 |

Nearest K-sibling to request: vlm_id=170791, K=+11.270 @ T=25.0 °C (ΔT=+0.00), I=0.1 M (ΔI=+0.00)

Call `get_node_neighbors(node_key)` to see the full vlm-row table for this (metal, ligand, beta_definition) triple.

[WAIT BARRIER COMPLETE] 2 tool(s) finished (inspect_node, inspect_node). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Beta812 is fine: chosen K=+11.270 at exact request (T=25, I=0.1); MAD flag is trivial (0.17 dev on tight cluster). Beta840 needs a fix: chosen +23.400 is at I=0.0, sibling median +21.850 with one negative outlier. Need neighbor table to pick a defensible replacement.</summary>
<tool_call>get_node_neighbors(node_key='metal61_ligand10076_beta840…')</tool_call>
<tool_call>finalize_patches(json_payload='{"patches":[{"node_key":"me…')</tool_call>

## User
<tool_result>
### get_node_neighbors
# L3 fixer collection — `metal61_ligand10076_beta840_net27465`

Pair: `m61_l10076`
Request conditions: **T = 25.0 °C**, **I = 0.1 M**

## Currently chosen row

- vlm_id = **170807**, K = **+23.400** @ T = 25.0 °C, I = 0.0 M
- flags: `sibling_sign_split, mad_outlier, mean_median_gap, wide_TI_distance`
- notes:
  - K-sibling pool is bimodal in sign: 4 positive (e.g. vlm_170802=+21.800) vs 1 negative (e.g. vlm_170803=-20.400)
  - chosen K = +23.400 deviates by 1.60 from sibling median +21.800 (MAD 0.10, threshold 3·MAD)
  - K-siblings: mean=+13.440 vs median=+21.800 (gap 8.36 > 1 logK over n=5 siblings); a hidden outlier is distorting the mean
  - chosen (T=25.0, I=0.0) is far from request (T=25.0, I=0.1); no K-sibling within ±5.0 °C / ±0.05 M either

## All siblings for this (metal, ligand, beta_def)

(6 sibling rows in 6 (T, I) buckets)

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 0.5 M (ΔI=+0.40)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170802 | K | +21.800 | 25.0 | 0.5 | both | 0 | 0 |

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 0.7000000000000001 M (ΔI=+0.60)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170803 | K | -20.400 | 25.0 | 0.7 | both | 0 | 0 |

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 1.0 M (ΔI=+0.90)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170804 | K | +21.800 | 25.0 | 1.0 | both | 0 | 0 |

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 2.0 M (ΔI=+1.90)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170805 | K | +21.900 | 25.0 | 2.0 | both | 0 | 0 |

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 3.0 M (ΔI=+2.90)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170806 | K | +22.100 | 25.0 | 3.0 | both | 0 | 0 |

### Bucket T ≈ 25.0 °C (ΔT=+0.00), I ≈ 0.0 M (ΔI=-0.10)

| vlm_id | type | value | T (°C) | I (M) | source | duplicate | used_in_map |
|--------|------|-------|--------|-------|--------|-----------|-------------|
| 170807 **←chosen** | K | +23.400 | 25.0 | 0.0 | both | 0 | 0 |


### finalize_patches
OK — accepted 1 patch(es) (1 set_value, 0 drop_node).
</tool_result>

## LLM Response
<summary>Patch was accepted. The chosen +23.400 at I=0 is the extrapolation to zero ionic strength; the finite-I siblings cluster tightly at +21.8 to +22.1, with vlm_170803=-20.400 being an obvious sign-flip typo. At the request I=0.1 M, the closest defensible value is the I=0.5 sibling (+21.800), consistent with the median of the positive cluster.</summary>

<answer>
Patch submitted for `metal61_ligand10076_beta840_net27465`: replace the I=0 extrapolation (+23.400) with +21.800 (median of the four positive finite-I siblings, matching vlm_170802 at I=0.5 M closest to the request I=0.1 M). The negative sibling vlm_170803=-20.400 is an obvious sign-flip artifact.

All other warn nodes were left as-is:
- beta812: chosen row is exactly at request (T=25, I=0.1); MAD flag is trivial (0.17 logK deviation on a tight cluster).
- beta649, beta519: tight sibling clusters (range ≤1.3, ≤1.0 logK); wide_TI_distance only.
- beta352, beta357: only 2 siblings, differences ≤0.4 logK; chosen values fine.
- beta351, beta894: single_observation / beta_def_orphan — no alternative to consider.
</answer>

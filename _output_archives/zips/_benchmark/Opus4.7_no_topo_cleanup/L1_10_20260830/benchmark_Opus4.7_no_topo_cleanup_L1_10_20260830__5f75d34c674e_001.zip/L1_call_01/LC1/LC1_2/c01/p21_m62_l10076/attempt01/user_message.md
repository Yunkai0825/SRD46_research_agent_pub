[Purpose: Compute the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II) and Fe(III) with citrate, glycine, chloride, and ammonia, and characterize how the two metals partition among aqueous complexes and solids across the field.]
[Tasks:
Model a single pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V_SHE at reasonable resolution (about 71 x 51 grid). Report the topology: list every connected region with its dominant Cu-bearing and Fe-bearing species (aqueous complexes with citrate, glycine, ammonia, chloride, hydroxide as well as any predicted solids or metals), the pH/E extent of each region, the principal boundary segments and their triple-point junctions, and note which boundaries are redox-controlled versus pH/ligand-controlled. Cite the equilibrium constants and standard potentials the solver actually used for the reactions defining the major boundaries, and describe qualitatively how Cu and Fe partition between citrate, glycine, ammonia, chloride, hydroxide, and reduced/solid phases across the diagram.
]
[Pair: pair_key=`m62_l10076`, metal_id=62, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10076_beta840_net27433`
  - `metal62_ligand10076_beta872_net27433`
  - `metal62_ligand10076_beta894_net27433`
  - `metal62_ligand10076_beta334_net27433`
[Screen report]
# Eq-map screen — m62_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10076_beta812_net27433` | `[M] + [L] <=> [ML]` | vlm_170672@(25.0,0.1) = K+4.200 | 3 | +4.200 / +4.300 / +4.367 / +4.600 | vlm_170672@(25.0,0.1) = K+4.200 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal62_ligand10076_beta840_net27433` | `[M] + [L]^2 <=> [ML2]` | vlm_170677@(25.0,0.0) = K-7.500 | 1 | -7.500 / -7.500 / -7.500 / -7.500 | vlm_170677@(25.0,0.0) = K-7.500 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |
| 3 | `metal62_ligand10076_beta872_net27433` | `[M] + [L]^3 <=> [ML3]` | vlm_170680@(25.0,0.0) = K+13.000 | 1 | +13.000 / +13.000 / +13.000 / +13.000 | vlm_170680@(25.0,0.0) = K+13.000 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |
| 4 | `metal62_ligand10076_beta894_net27433` | `[M] + [L]^4 <=> [ML4]` | vlm_170683@(25.0,0.0) = K+10.000 | 1 | +10.000 / +10.000 / +10.000 / +10.000 | vlm_170683@(25.0,0.0) = K+10.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal62_ligand10076_beta334_net27433` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170684@(25.0,0.0) = K-14.430 | 1 | -14.430 / -14.430 / -14.430 / -14.430 | vlm_170684@(25.0,0.0) = K-14.430 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.
